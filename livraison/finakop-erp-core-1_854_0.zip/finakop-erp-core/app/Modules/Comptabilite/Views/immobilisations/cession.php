<?php /** @var array $immos @var array $comptes @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card">
	<div class="card-head"><h2>Céder une immobilisation</h2></div>
	<div class="card-body">
		<?php if ( ! $immos ) : ?>
			<p class="muted" style="margin:0">Aucune immobilisation en service à céder.</p>
		<?php else : ?>
		<p class="help" style="margin-top:0">La cession solde la valeur d'origine et les amortissements (812/28/2x), enregistre l'encaissement et constate la plus ou moins-value (822).</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/ceder' ) ) ?>" id="cession-form" onsubmit="return confirm('Enregistrer la cession ?');">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid">
				<label class="fld" style="grid-column:1/-1"><span>Immobilisation</span>
					<select name="immo_id" required>
						<option value="">— Sélectionner —</option>
						<?php foreach ( $immos as $im ) : ?>
							<option value="<?= (int) $im['id'] ?>"><?= e( $im['libelle'] ) ?> — <?= e( fkc_money( $im['valeur_acquisition'] ) ) ?> FCFA (<?= e( $im['date_acquisition'] ) ?>)</option>
						<?php endforeach; ?>
					</select></label>
				<label class="fld"><span>Date de cession</span>
					<input type="date" name="date_cession" value="<?= e( date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>Prix de cession (FCFA)</span>
					<input type="number" name="valeur_cession" min="0" value="0" required></label>
				<label class="fld"><span>Trésorerie (encaissement)</span>
					<select name="tresorerie_id" required>
						<?php foreach ( $comptes as $c ) : ?><option value="<?= (int) $c['id'] ?>"><?= e( $c['libelle'] ) ?></option><?php endforeach; ?>
					</select></label>
			</div>
			<div class="actions" style="margin-top:8px">
				<button class="btn btn-primary" type="submit">Enregistrer la cession</button>
			</div>
		</form>
		<?php endif; ?>
	</div>
</div>
