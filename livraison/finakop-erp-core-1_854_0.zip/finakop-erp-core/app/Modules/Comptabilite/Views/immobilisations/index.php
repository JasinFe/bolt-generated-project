<?php /** @var array $immos @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted"><?= count($immos) ?> immobilisation(s)<?php if ( ! empty( $seuil ) ) : ?> · <span style="color:var(--orange)">seuil d'immobilisation <?= e( fkc_money( $seuil ) ) ?> FCFA</span><?php endif; ?></span>
	<a class="btn btn-primary btn-sm" href="<?= e( url('comptabilite/immobilisations/nouvelle') ) ?>">+ Nouvelle immobilisation</a></div>
<?php if ( ! empty( $isAdmin ) ) : ?>
<div class="card" style="margin-bottom:12px"><div class="card-body">
	<form method="post" action="<?= e( url('comptabilite/immobilisations/seuil') ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:0">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:220px"><span>Seuil d'immobilisation (FCFA)</span><input class="num" name="seuil" value="<?= e( $seuil ? fkc_money( $seuil ) : '' ) ?>" placeholder="0 = désactivé"></label>
		<button class="btn btn-ghost btn-sm" type="submit">Enregistrer le seuil</button>
		<span class="help" style="max-width:520px">En-dessous de ce montant, un bien est proposé en charges directes (SYSCOHADA — biens de faible valeur) plutôt qu'immobilisé et amorti. Fixez la valeur selon les règles DGI en vigueur. <strong>0 = aucun seuil.</strong></span>
	</form>
</div></div>
<?php endif; ?>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : code, libellé, compte…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Immobilisation</th><th>Acquisition</th><th class="num">Valeur</th><th class="num">Amorti</th><th class="num">VNC</th><th>Statut</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $immos ) : ?><tr><td colspan="7" class="empty">Aucune immobilisation.</td></tr>
	<?php else : foreach ( $immos as $im ) : ?>
		<tr><td><strong><?= e($im['libelle']) ?></strong><?php if($im['code']):?> <span class="code"><?= e($im['code']) ?></span><?php endif;?><?php if ( ! empty( $pieces[ $im['id'] ] ) ) : ?> <span class="pj-flag" title="<?= (int) $pieces[ $im['id'] ] ?> pièce(s) jointe(s)">📎<?= (int) $pieces[ $im['id'] ] > 1 ? '<sup>' . (int) $pieces[ $im['id'] ] . '</sup>' : '' ?></span><?php endif; ?><br><span class="muted" style="font-size:11px">immo <?= e($im['compte_immo']) ?> · amort <?= e($im['compte_amort']) ?></span></td>
		<td class="num"><?= e( date('d/m/Y',strtotime($im['date_acquisition'])) ) ?></td>
		<td class="num"><?= e( fkc_money($im['valeur_acquisition']) ) ?></td>
		<td class="num muted"><?= e( fkc_money($im['cumul']) ) ?></td>
		<td class="num"><strong><?= e( fkc_money($im['vnc']) ) ?></strong></td>
		<td><?php $etat = (string) $im['statut']; ?>
			<span class="modbadge <?= 'cede'===$etat?'b-off':('annulee'===$etat?'b-err':'b-on') ?>"><?= 'cede'===$etat?'Cédée':('annulee'===$etat?'Annulée':'En service') ?></span></td>
		<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/immobilisations/'.$im['id']) ) ?>">Voir</a></td></tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
