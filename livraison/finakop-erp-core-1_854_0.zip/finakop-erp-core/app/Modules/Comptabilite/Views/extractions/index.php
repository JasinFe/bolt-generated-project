<?php
/**
 * Extractions comptables — hub multi-onglets.
 * @var string $vue @var string $etat @var string $du @var string $au @var string $arrete
 * @var int $tiersId @var int $compteId
 * @var array $clients @var array $fournisseurs @var array $comptes
 * @var array $rows @var array $tot @var array $lignes @var string $tiers
 * @var array $gl @var array|null $tiersSel @var array|null $compteSel
 * @var array $mouvements @var float $ouverture @var array $journaux
 * @var array $immos @var array $amorts
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f    = function ( $v ) { return fkc_money( (float) $v ); };
$dmy  = function ( $d ) { return ( $d && strtotime( (string) $d ) ) ? date( 'd/m/Y', strtotime( (string) $d ) ) : '—'; };
$base = url( 'comptabilite/extractions' );

/* Onglets principaux */
$tabs = array(
	'balance'         => array( 'Balance générale', '⚖️' ),
	'clients'         => array( 'Clients', '👥' ),
	'fournisseurs'    => array( 'Fournisseurs', '🚚' ),
	'gl'              => array( 'GL · Centralisation', '📚' ),
	'immobilisations' => array( 'Immobilisations', '🏭' ),
);
/* États par onglet : clé => [label, description] */
$etats = array(
	'balance' => array(
				'generale' => array( 'Balance générale', 'Mouvements & soldes par compte, sous-totaux par classe (1 à 9).' ),
	),
	'clients' => array(
		'aux'  => array( 'Balance auxiliaire', 'Soldes individuels des comptes clients (411).' ),
		'agee' => array( 'Balance âgée', 'Créances non lettrées ventilées par ancienneté.' ),
		'gl'   => array( 'Grand livre client', 'Détail chronologique des mouvements d\'un client.' ),
	),
	'fournisseurs' => array(
		'aux'  => array( 'Balance auxiliaire', 'Soldes individuels des comptes fournisseurs (401).' ),
		'agee' => array( 'Balance âgée', 'Dettes non lettrées ventilées par ancienneté.' ),
		'gl'   => array( 'Grand livre fournisseur', 'Détail chronologique des mouvements d\'un fournisseur.' ),
	),
	'gl' => array(
		'balance'        => array( 'Balance générale', 'Tous comptes, mouvements & soldes.' ),
		'grandlivre'     => array( 'Grand livre général', 'Détail des écritures par compte du plan.' ),
		'centralisation' => array( 'Centralisation', 'Totaux débit / crédit par journal.' ),
	),
	'immobilisations' => array(
		'registre'       => array( 'Registre des immobilisations', 'Valeur, amortissements cumulés et VNC.' ),
		'amortissements' => array( 'Tableau d\'amortissement', 'Plan de dotations prévisionnel par exercice.' ),
	),
);

/* Période courante / libellé pour l'en-tête */
$useArrete = ( in_array( $vue, array( 'clients', 'fournisseurs' ), true ) && 'agee' === $etat );
$noDate    = ( 'immobilisations' === $vue );
$etatLabel = $etats[ $vue ][ $etat ][0] ?? 'Extraction';
if ( $noDate ) { $periodeLabel = 'Au ' . date( 'd/m/Y' ); }
elseif ( $useArrete ) { $periodeLabel = 'Arrêté au ' . date( 'd/m/Y', strtotime( $arrete ) ); }
else { $periodeLabel = 'Du ' . date( 'd/m/Y', strtotime( $du ) ) . ' au ' . date( 'd/m/Y', strtotime( $au ) ); }

/* Construit l'URL d'export en conservant les paramètres pertinents */
$expUrl = function () use ( $vue, $etat, $du, $au, $arrete, $tiersId, $compteId, $useArrete, $noDate ) {
	$q = array( 'vue' => $vue, 'etat' => $etat );
	if ( $noDate ) { /* rien */ }
	elseif ( $useArrete ) { $q['arrete'] = $arrete; }
	else { $q['du'] = $du; $q['au'] = $au; }
	if ( $tiersId )  { $q['tiers_id'] = $tiersId; }
	if ( $compteId ) { $q['compte_id'] = $compteId; }
	return url( 'comptabilite/extractions/export' ) . '?' . http_build_query( $q );
};
/* URL de bascule d'onglet (conserve les dates) */
$tabUrl = function ( $v ) use ( $base, $du, $au, $arrete ) {
	return $base . '?' . http_build_query( array( 'vue' => $v, 'du' => $du, 'au' => $au, 'arrete' => $arrete ) );
};
/* URL de bascule d'état dans l'onglet courant */
$etatUrl = function ( $e ) use ( $base, $vue, $du, $au, $arrete, $tiersId, $compteId ) {
	return $base . '?' . http_build_query( array( 'vue' => $vue, 'etat' => $e, 'du' => $du, 'au' => $au, 'arrete' => $arrete, 'tiers_id' => $tiersId, 'compte_id' => $compteId ) );
};

/* Raccourcis de période : exercice, mois et trimestre en cours, exercice précédent. */
$ex = $exercice ?? array( date( 'Y' ) . '-01-01', date( 'Y' ) . '-12-31' );
$tri = (int) ceil( (int) date( 'n' ) / 3 );
$presets = array(
	'Exercice'       => $ex,
	'Mois en cours'  => array( date( 'Y-m-01' ), date( 'Y-m-t' ) ),
	'Trimestre'      => array( date( 'Y' ) . '-' . sprintf( '%02d', ( $tri - 1 ) * 3 + 1 ) . '-01', date( 'Y-m-t', strtotime( date( 'Y' ) . '-' . sprintf( '%02d', $tri * 3 ) . '-01' ) ) ),
	'Exercice N-1'   => array( date( 'Y-m-d', strtotime( $ex[0] . ' -1 year' ) ), date( 'Y-m-d', strtotime( $ex[1] . ' -1 year' ) ) ),
);
$presetUrl = function ( $p ) use ( $base, $vue, $etat, $tiersId, $compteId ) {
	return $base . '?' . http_build_query( array( 'vue' => $vue, 'etat' => $etat, 'du' => $p[0], 'au' => $p[1], 'tiers_id' => $tiersId, 'compte_id' => $compteId ) );
};
/* Liens de consultation croisée (grand livre d'un compte / d'un tiers). */
$glCompteUrl = function ( $id ) use ( $base, $du, $au ) {
	return $base . '?' . http_build_query( array( 'vue' => 'gl', 'etat' => 'grandlivre', 'compte_id' => (int) $id, 'du' => $du, 'au' => $au ) );
};
$glTiersUrl = function ( $id ) use ( $base, $vue, $du, $au ) {
	return $base . '?' . http_build_query( array( 'vue' => $vue, 'etat' => 'gl', 'tiers_id' => (int) $id, 'du' => $du, 'au' => $au ) );
};
$classesLib = array( '1' => 'Ressources durables', '2' => 'Actif immobilisé', '3' => 'Stocks', '4' => 'Tiers', '5' => 'Trésorerie',
	'6' => 'Charges des activités ordinaires', '7' => 'Produits des activités ordinaires', '8' => 'Autres charges et produits (HAO)', '9' => 'Engagements & analytique' );

/* Indique si l'état courant a des données exportables (pour activer/désactiver le bouton) */
$exportReady = true;
if ( in_array( $etat, array( 'gl' ), true ) && in_array( $vue, array( 'clients', 'fournisseurs' ), true ) ) { $exportReady = ! empty( $tiersSel ); }
if ( 'gl' === $vue && 'grandlivre' === $etat ) { $exportReady = ! empty( $compteSel ); }
?>

<?php FKC_View::partial( 'comptabilite::_etat_entete', array( 'etat' => 'Extraction — ' . $etatLabel, 'periode' => $periodeLabel ) ); ?>

<?php if ( ! empty( $attente['nb'] ) && ! $noDate ) : ?>
	<div class="ext-alert warn">ⓘ <strong><?= (int) $attente['nb'] ?> écriture(s)</strong> de la période attendent au journal temporaire<?= ! empty( $attente['montant'] ) ? ' (' . e( $f( $attente['montant'] ) ) . ' F CFA au débit)' : '' ?> : elles ne figurent dans aucune extraction.
		<a href="<?= e( url( 'comptabilite/brouillard' ) ) ?>">Valider le brouillard →</a></div>
<?php endif; ?>

<div class="ext-head">
	<div class="ext-title">📦 <span>Extractions comptables</span> — SYSCOHADA révisé / DGI</div>
	<?php if ( $exportReady ) : ?>
		<a class="btn btn-primary btn-sm" href="<?= e( $expUrl() ) ?>">⬇ Exporter en CSV</a>
	<?php else : ?>
		<button class="btn btn-primary btn-sm" disabled title="Sélectionnez un tiers / compte" style="opacity:.5;cursor:not-allowed">⬇ Exporter en CSV</button>
	<?php endif; ?>
</div>

<!-- Onglets principaux -->
<div class="ext-tabs">
	<?php foreach ( $tabs as $k => $t ) : ?>
		<a class="ext-tab <?= $vue === $k ? 'on' : '' ?>" href="<?= e( $tabUrl( $k ) ) ?>"><span class="ico"><?= $t[1] ?></span><?= e( $t[0] ) ?></a>
	<?php endforeach; ?>
</div>

<!-- Cartes CTA des états de l'onglet -->
<div class="ext-states">
	<?php foreach ( $etats[ $vue ] as $k => $info ) : $on = ( $etat === $k ); ?>
		<a class="ext-state <?= $on ? 'on' : '' ?>" href="<?= e( $etatUrl( $k ) ) ?>">
			<div class="es-top">
				<span class="es-name"><?= e( $info[0] ) ?></span>
				<?php if ( $on ) : ?><span class="es-badge">Affiché</span><?php endif; ?>
			</div>
			<span class="es-desc"><?= e( $info[1] ) ?></span>
		</a>
	<?php endforeach; ?>
</div>

<!-- Barre de filtres contextuelle -->
<form method="get" action="<?= e( $base ) ?>" class="ext-filters">
	<input type="hidden" name="vue" value="<?= e( $vue ) ?>">
	<input type="hidden" name="etat" value="<?= e( $etat ) ?>">

	<?php /* Sélecteur de tiers (grand livre clients / fournisseurs) */ ?>
	<?php if ( in_array( $vue, array( 'clients', 'fournisseurs' ), true ) && 'gl' === $etat ) :
		$liste = 'clients' === $vue ? $clients : $fournisseurs; ?>
		<label class="fld" style="margin:0;min-width:240px">
			<span><?= 'clients' === $vue ? 'Client' : 'Fournisseur' ?></span>
			<select name="tiers_id" onchange="this.form.submit()">
				<option value="0">— Sélectionner —</option>
				<?php foreach ( $liste as $c ) : ?>
					<option value="<?= (int) $c['id'] ?>" <?= $tiersId === (int) $c['id'] ? 'selected' : '' ?>><?= e( $c['nom'] ) ?></option>
				<?php endforeach; ?>
			</select>
		</label>
	<?php endif; ?>

	<?php /* Sélecteur de compte (grand livre général) */ ?>
	<?php if ( 'gl' === $vue && 'grandlivre' === $etat ) : ?>
		<label class="fld" style="margin:0;min-width:300px">
			<span>Compte</span>
			<select name="compte_id" onchange="this.form.submit()">
				<option value="0">— Sélectionner un compte —</option>
				<?php foreach ( $comptes as $c ) : ?>
					<option value="<?= (int) $c['id'] ?>" <?= $compteId === (int) $c['id'] ? 'selected' : '' ?>><?= e( $c['numero'] . ' — ' . $c['libelle'] ) ?></option>
				<?php endforeach; ?>
			</select>
		</label>
	<?php endif; ?>

	<?php if ( $useArrete ) : ?>
		<label class="fld" style="margin:0"><span>Arrêté au</span><input type="date" name="arrete" value="<?= e( $arrete ) ?>"></label>
		<button class="btn btn-ghost btn-sm" type="submit">Actualiser</button>
		<a class="ext-preset" href="<?= e( $base . '?' . http_build_query( array( 'vue' => $vue, 'etat' => $etat, 'arrete' => $ex[1] ) ) ) ?>">Clôture de l'exercice</a>
	<?php elseif ( ! $noDate ) : ?>
		<?php if ( $tiersId ) : ?><input type="hidden" name="tiers_id" value="<?= (int) $tiersId ?>"><?php endif; ?>
		<?php if ( $compteId ) : ?><input type="hidden" name="compte_id" value="<?= (int) $compteId ?>"><?php endif; ?>
		<label class="fld" style="margin:0"><span>Du</span><input type="date" name="du" value="<?= e( $du ) ?>"></label>
		<label class="fld" style="margin:0"><span>Au</span><input type="date" name="au" value="<?= e( $au ) ?>"></label>
		<button class="btn btn-ghost btn-sm" type="submit">Actualiser</button>
		<span class="ext-presets">
			<?php foreach ( $presets as $lib => $p ) : ?>
				<a class="ext-preset <?= ( $p[0] === $du && $p[1] === $au ) ? 'on' : '' ?>" href="<?= e( $presetUrl( $p ) ) ?>"><?= e( $lib ) ?></a>
			<?php endforeach; ?>
		</span>
	<?php else : ?>
		<span class="muted" style="font-size:13px">État arrêté à la date du jour — aucun filtre de période.</span>
	<?php endif; ?>
</form>

<?php
/* ════════════════ RENDU DES ÉTATS ════════════════ */
$key = $vue . ':' . $etat;

/* --- Tables de type BALANCE (générale + auxiliaires) --- */
if ( in_array( $key, array( 'balance:generale', 'gl:balance', 'clients:aux', 'fournisseurs:aux' ), true ) ) :
	$isAux = in_array( $etat, array( 'aux' ), true );
	$colHead = $isAux ? ( 'clients' === $vue ? 'Client' : 'Fournisseur' ) : 'Compte';
	$libHead = $isAux ? 'Compte coll.' : 'Intitulé';
	$prevClasse = null;
	$ecartBal = round( (float) ( $tot['debit'] ?? 0 ) - (float) ( $tot['credit'] ?? 0 ), 2 );
?>
	<?php if ( ! $isAux && ! empty( $ctxO ) && array_key_exists( 'fiable', $ctxO ) && ! $ctxO['fiable'] && ! empty( $ctxO['alerte'] ) ) : ?>
		<?php /* L'export CSV portait cette alerte ; l'écran, lui, la taisait. */ ?>
		<div class="ext-alert ko">⚠ <?= e( $ctxO['alerte'] ) ?></div>
	<?php endif; ?>
	<?php if ( $isAux && ! empty( $collectif ) ) : $okC = abs( (float) $collectif['ecart'] ) < 1; ?>
		<div class="ext-alert <?= $okC ? 'ok' : 'warn' ?>">
			<?php if ( $okC ) : ?>
				✓ Balance auxiliaire rapprochée du collectif <?= e( $collectif['racine'] ) ?> du grand livre : solde <?= e( $f( $collectif['gl'] ) ) ?> F CFA.
			<?php else : ?>
				⚠ Écart de <strong><?= e( $f( $collectif['ecart'] ) ) ?> F CFA</strong> entre la balance auxiliaire (<?= e( $f( $collectif['aux'] ) ) ?>) et le collectif <?= e( $collectif['racine'] ) ?> du grand livre (<?= e( $f( $collectif['gl'] ) ) ?>) :
				facture non comptabilisée, règlement saisi en OD, ou écriture manuelle sur le compte collectif.
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<div class="card card-flush table-wrap"><table class="table ext-tbl">
		<thead><tr>
			<th><?= e( $colHead ) ?></th><th><?= e( $libHead ) ?></th>
			<th class="num">Ouv. débit</th><th class="num">Ouv. crédit</th>
			<th class="num">Mvt débit</th><th class="num">Mvt crédit</th>
			<th class="num">Solde débiteur</th><th class="num">Solde créditeur</th>
		</tr></thead>
		<tbody>
		<?php if ( empty( $rows ) ) : ?>
			<tr><td colspan="8" class="empty">Aucun mouvement sur la période.</td></tr>
		<?php else :
			/*
			 * Sous-totaux par classe : le code les annonçait (« séparateur
			 * visuel ») sans jamais les produire. Une balance SYSCOHADA se
			 * lit classe par classe — c'est là qu'on voit une classe 6
			 * créditrice ou une classe 5 anormale.
			 */
			$sousTotal = function ( $c ) use ( $classes, $classesLib, $f ) {
				$t = $classes[ $c ] ?? null; if ( ! $t ) { return ''; }
				return '<tr class="ext-subtot"><td class="code">' . e( $c ) . '</td><td>Total classe ' . e( $c ) . ' — ' . e( $classesLib[ $c ] ?? '' ) . '</td>'
					. '<td class="num">' . e( $f( $t['ouv_debit'] ) ) . '</td><td class="num">' . e( $f( $t['ouv_credit'] ) ) . '</td>'
					. '<td class="num">' . e( $f( $t['debit'] ) ) . '</td><td class="num">' . e( $f( $t['credit'] ) ) . '</td>'
					. '<td class="num">' . e( $f( $t['sd'] ) ) . '</td><td class="num">' . e( $f( $t['sc'] ) ) . '</td></tr>';
			};
			foreach ( $rows as $r ) :
			if ( ! $isAux && isset( $r['numero'] ) ) {
				$classe = substr( (string) $r['numero'], 0, 1 );
				if ( null !== $prevClasse && $classe !== $prevClasse ) { echo $sousTotal( $prevClasse ); }
				$prevClasse = $classe;
			}
			$nom  = $isAux ? $r['nom'] : $r['numero'];
			$lib  = $isAux ? $r['compte'] : $r['libelle'];
			$lnk  = ! empty( $r['id'] ) ? ( $isAux ? $glTiersUrl( $r['id'] ) : $glCompteUrl( $r['id'] ) ) : '';
		?>
			<tr class="<?= ! empty( $r['ouverture_non_fiable'] ) ? 'ext-nf' : '' ?>">
				<td class="code"><?php if ( $lnk ) : ?><a href="<?= e( $lnk ) ?>" title="Ouvrir le grand livre"><?= e( $nom ) ?></a><?php else : ?><?= e( $nom ) ?><?php endif; ?></td>
				<td class="<?= $isAux ? 'muted' : '' ?>"><?= e( $lib ) ?><?php if ( ! empty( $r['ouverture_non_fiable'] ) ) : ?> <span class="ext-flag" title="Ouverture attendue <?= e( $f( $r['ouverture_attendue'] ) ) ?> — effective <?= e( $f( $r['ouverture_effective'] ) ) ?>">ouverture à vérifier</span><?php endif; ?></td>
				<td class="num muted"><?= $r['ouv_debit'] > 0 ? e( $f( $r['ouv_debit'] ) ) : '' ?></td>
				<td class="num muted"><?= $r['ouv_credit'] > 0 ? e( $f( $r['ouv_credit'] ) ) : '' ?></td>
				<td class="num"><?= e( $f( $r['debit'] ) ) ?></td>
				<td class="num"><?= e( $f( $r['credit'] ) ) ?></td>
				<td class="num"><?= $r['solde_debiteur'] > 0 ? e( $f( $r['solde_debiteur'] ) ) : '' ?></td>
				<td class="num"><?= $r['solde_crediteur'] > 0 ? e( $f( $r['solde_crediteur'] ) ) : '' ?></td>
			</tr>
		<?php endforeach; if ( ! $isAux && null !== $prevClasse ) { echo $sousTotal( $prevClasse ); } endif; ?>
		</tbody>
		<?php if ( ! empty( $rows ) ) : ?>
		<tfoot><tr class="total">
			<td></td><td>TOTAUX<?php if ( ! $isAux ) : ?> <span class="ext-eq <?= abs( $ecartBal ) < 1 ? 'ok' : 'ko' ?>"><?= abs( $ecartBal ) < 1 ? '✓ Σ débit = Σ crédit' : '⚠ écart ' . e( $f( $ecartBal ) ) ?></span><?php endif; ?></td>
			<td class="num"><?= e( $f( $tot['ouv_debit'] ) ) ?></td><td class="num"><?= e( $f( $tot['ouv_credit'] ) ) ?></td>
			<td class="num"><?= e( $f( $tot['debit'] ) ) ?></td><td class="num"><?= e( $f( $tot['credit'] ) ) ?></td>
			<td class="num"><?= e( $f( $tot['sd'] ) ) ?></td><td class="num"><?= e( $f( $tot['sc'] ) ) ?></td>
		</tr></tfoot>
		<?php endif; ?>
	</table></div>
	<p class="help" style="margin-top:10px">
		<?php if ( $isAux ) : ?>
			Balance auxiliaire (<?= 'clients' === $vue ? 'comptes 411' : 'comptes 401' ?>) : un solde par tiers, reconstitué à partir des factures et des règlements. Le total doit concorder avec le compte collectif de la balance générale.
		<?php else : ?>
			Balance générale (SYSCOHADA) : mouvements et soldes par compte sur la période. La somme des débits égale la somme des crédits.
		<?php endif; ?>
	</p>

<?php /* --- Tables de type BALANCE ÂGÉE --- */
elseif ( in_array( $key, array( 'clients:agee', 'fournisseurs:agee' ), true ) ) :
	$tf = $tl = $ts = 0; $tb = array( 'non_echu' => 0, 'b30' => 0, 'b60' => 0, 'b90' => 0, 'b90p' => 0 );
	foreach ( $lignes as $l ) { $tf += $l['facture']; $tl += $l['lettre']; $ts += $l['solde']; foreach ( $tb as $k => $v ) { $tb[ $k ] += $l['buckets'][ $k ]; } }
?>
	<div class="card card-flush table-wrap"><table class="table ext-tbl">
		<thead><tr>
			<th><?= e( rtrim( $tiers, 's' ) ) ?></th>
			<th class="num">Facturé</th><th class="num">Réglé / lettré</th><th class="num">Solde</th>
			<th class="num">Non échu</th><th class="num">0-30 j</th><th class="num">31-60 j</th><th class="num">61-90 j</th><th class="num">+90 j</th>
		</tr></thead>
		<tbody>
		<?php if ( empty( $lignes ) ) : ?>
			<tr><td colspan="9" class="empty">Aucun <?= e( strtolower( rtrim( $tiers, 's' ) ) ) ?> avec mouvement.</td></tr>
		<?php else : foreach ( $lignes as $l ) : $b = $l['buckets']; ?>
			<tr>
				<td><strong><?= ! empty( $l['id'] ) ? '<a href="' . e( $glTiersUrl( $l['id'] ) ) . '" style="color:inherit">' . e( $l['nom'] ) . '</a>' : e( $l['nom'] ) ?></strong>
					<?php if ( ! empty( $l['credit'] ) && $l['credit'] >= 0.5 ) : ?> <span class="ext-flag" title="Réglé sans facture en face : avance, acompte ou double saisie">crédit <?= e( $f( $l['credit'] ) ) ?></span><?php endif; ?></td>
				<td class="num"><?= e( $f( $l['facture'] ) ) ?></td>
				<td class="num muted" title="<?= isset( $l['impute'] ) ? 'Dont ' . e( $f( $l['impute'] ) ) . ' imputé nommément (règlement ou avoir d\'origine), le reste au plus ancien' : '' ?>"><?= e( $f( $l['lettre'] ) ) ?></td>
				<td class="num" style="color:<?= $l['solde'] > 0 ? 'var(--orange)' : 'var(--ok)' ?>"><strong><?= e( $f( $l['solde'] ) ) ?></strong></td>
				<td class="num muted"><?= $b['non_echu'] > 0 ? e( $f( $b['non_echu'] ) ) : '' ?></td>
				<td class="num"><?= $b['b30'] > 0 ? e( $f( $b['b30'] ) ) : '' ?></td>
				<td class="num"><?= $b['b60'] > 0 ? e( $f( $b['b60'] ) ) : '' ?></td>
				<td class="num" style="<?= $b['b90'] > 0 ? 'color:var(--orange)' : '' ?>"><?= $b['b90'] > 0 ? e( $f( $b['b90'] ) ) : '' ?></td>
				<td class="num" style="<?= $b['b90p'] > 0 ? 'color:var(--danger)' : '' ?>"><?= $b['b90p'] > 0 ? e( $f( $b['b90p'] ) ) : '' ?></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( ! empty( $lignes ) ) : ?>
		<tfoot><tr class="total">
			<td>TOTAUX</td>
			<td class="num"><?= e( $f( $tf ) ) ?></td><td class="num"><?= e( $f( $tl ) ) ?></td><td class="num"><?= e( $f( $ts ) ) ?></td>
			<td class="num"><?= e( $f( $tb['non_echu'] ) ) ?></td><td class="num"><?= e( $f( $tb['b30'] ) ) ?></td>
			<td class="num"><?= e( $f( $tb['b60'] ) ) ?></td><td class="num"><?= e( $f( $tb['b90'] ) ) ?></td><td class="num"><?= e( $f( $tb['b90p'] ) ) ?></td>
		</tr></tfoot>
		<?php endif; ?>
	</table></div>
	<p class="help" style="margin-top:10px">Balance auxiliaire âgée (<?= e( $tiers ) ?>) : même moteur que le recouvrement — chaque règlement éteint d'abord la facture sur laquelle il a été <strong>imputé</strong>, chaque avoir sa facture d'origine, et seul le reliquat est lettré au plus ancien. Le restant dû est ventilé par ancienneté. L'ancienneté part de la date d'échéance, ou de la date de facture si aucune échéance n'est renseignée. Seules les pièces datées au plus tard de l'arrêté sont prises en compte.</p>

<?php /* --- GRAND LIVRE TIERS (clients / fournisseurs) --- */
elseif ( in_array( $key, array( 'clients:gl', 'fournisseurs:gl' ), true ) ) : ?>
	<?php if ( empty( $tiersSel ) ) : ?>
		<div class="card card-flush"><div class="empty" style="padding:34px">Sélectionnez un <?= 'clients' === $vue ? 'client' : 'fournisseur' ?> pour afficher son grand livre.</div></div>
	<?php else :
		$mvts = $gl['mouvements']; $ouv = (float) $gl['ouverture'];
		$tdb = 0; $tcr = 0; foreach ( $mvts as $m ) { $tdb += $m['debit']; $tcr += $m['credit']; }
	?>
		<div class="gl-tiers-head"><span class="gl-tiers-name"><?= e( $tiersSel['nom'] ) ?></span>
			<?php if ( ! empty( $tiersSel['ncc'] ) ) : ?><span class="muted">NCC <?= e( $tiersSel['ncc'] ) ?></span><?php endif; ?></div>
		<div class="card card-flush table-wrap"><table class="table ext-tbl">
			<thead><tr><th>Date</th><th>Jrnl</th><th>Pièce</th><th>Libellé</th><th class="num">Débit</th><th class="num">Crédit</th><th class="num">Solde</th></tr></thead>
			<tbody>
				<?php if ( abs( $ouv ) >= 0.005 ) : ?>
					<tr class="gl-ouv"><td><?= e( $dmy( $du ) ) ?></td><td></td><td></td><td>Solde au <?= e( $dmy( date( 'Y-m-d', strtotime( $du . ' -1 day' ) ) ) ) ?> (factures et règlements antérieurs)</td>
						<td class="num"><?= $ouv > 0 ? e( $f( $ouv ) ) : '' ?></td><td class="num"><?= $ouv < 0 ? e( $f( -$ouv ) ) : '' ?></td><td class="num"><?= e( $f( $ouv ) ) ?></td></tr>
				<?php endif; ?>
				<?php if ( empty( $mvts ) && abs( $ouv ) < 0.005 ) : ?>
					<tr><td colspan="7" class="empty">Aucun mouvement sur la période.</td></tr>
				<?php else : foreach ( $mvts as $m ) : ?>
					<tr><td><?= e( $dmy( $m['date'] ) ) ?></td><td><span class="code"><?= e( $m['journal'] ) ?></span></td>
						<td class="muted"><?= e( $m['piece'] ) ?></td><td><?= e( $m['libelle'] ) ?></td>
						<td class="num"><?= $m['debit'] > 0 ? e( $f( $m['debit'] ) ) : '' ?></td>
						<td class="num"><?= $m['credit'] > 0 ? e( $f( $m['credit'] ) ) : '' ?></td>
						<td class="num"><?= e( $f( $m['solde'] ) ) ?></td></tr>
				<?php endforeach; endif; ?>
			</tbody>
			<tfoot><tr class="total"><td colspan="4">TOTAUX MOUVEMENTS</td><td class="num"><?= e( $f( $tdb ) ) ?></td><td class="num"><?= e( $f( $tcr ) ) ?></td>
				<td class="num"><?= e( $f( $ouv + $tdb - $tcr ) ) ?></td></tr></tfoot>
		</table></div>
		<p class="help" style="margin-top:10px">Grand livre auxiliaire : factures (<?= 'clients' === $vue ? 'débit' : 'crédit' ?>) et règlements (<?= 'clients' === $vue ? 'crédit' : 'débit' ?>) classés chronologiquement, avec solde progressif.</p>
	<?php endif; ?>

<?php /* --- GRAND LIVRE GÉNÉRAL --- */
elseif ( 'gl:grandlivre' === $key ) : ?>
	<?php if ( empty( $compteSel ) ) : ?>
		<div class="card card-flush"><div class="empty" style="padding:34px">Sélectionnez un compte du plan comptable pour afficher son grand livre.</div></div>
	<?php else :
		$ouv = (float) $ouverture; $tdb = 0; $tcr = 0; foreach ( $mouvements as $m ) { $tdb += $m['debit']; $tcr += $m['credit']; }
	?>
		<div class="gl-tiers-head"><span class="gl-tiers-name"><span class="code"><?= e( $compteSel['numero'] ) ?></span> <?= e( $compteSel['libelle'] ) ?></span></div>
		<div class="card card-flush table-wrap"><table class="table ext-tbl">
			<thead><tr><th>Date</th><th>Jrnl</th><th>Pièce</th><th>Libellé</th><th class="num">Débit</th><th class="num">Crédit</th><th class="num">Solde</th></tr></thead>
			<tbody>
				<?php if ( abs( $ouv ) >= 0.005 ) : ?>
					<tr class="gl-ouv"><td><?= e( $dmy( $du ) ) ?></td><td></td><td></td><td><?php $ctxO = FKC_Rapport::contexteOuverture(); echo e( $ctxO ? $ctxO['libelle'] : "Solde d'ouverture" ); ?></td>
						<td class="num"><?= $ouv > 0 ? e( $f( $ouv ) ) : '' ?></td><td class="num"><?= $ouv < 0 ? e( $f( -$ouv ) ) : '' ?></td><td class="num"><?= e( $f( $ouv ) ) ?></td></tr>
				<?php endif; ?>
				<?php if ( empty( $mouvements ) && abs( $ouv ) < 0.005 ) : ?>
					<tr><td colspan="7" class="empty">Aucun mouvement sur la période.</td></tr>
				<?php else : foreach ( $mouvements as $m ) : ?>
					<tr><td><?= e( $dmy( $m['date_ecriture'] ) ) ?></td><td><span class="code"><?= e( $m['journal_code'] ) ?></span></td>
						<td class="muted"><?php if ( ! empty( $m['ecriture_id'] ) ) : ?><a href="<?= e( url( 'comptabilite/ecritures/' . (int) $m['ecriture_id'] ) ) ?>" title="Voir l'écriture"><?= e( $m['piece'] ?: '#' . (int) $m['ecriture_id'] ) ?></a><?php else : ?><?= e( $m['piece'] ) ?><?php endif; ?></td><td><?= e( $m['libelle'] ) ?></td>
						<td class="num"><?= $m['debit'] > 0 ? e( $f( $m['debit'] ) ) : '' ?></td>
						<td class="num"><?= $m['credit'] > 0 ? e( $f( $m['credit'] ) ) : '' ?></td>
						<td class="num <?= $m['solde'] < 0 ? 'neg' : '' ?>"><?= e( $f( $m['solde'] ) ) ?></td></tr>
				<?php endforeach; endif; ?>
			</tbody>
			<tfoot><tr class="total"><td colspan="4">TOTAUX MOUVEMENTS</td><td class="num"><?= e( $f( $tdb ) ) ?></td><td class="num"><?= e( $f( $tcr ) ) ?></td>
				<td class="num"><?= e( $f( $ouv + $tdb - $tcr ) ) ?></td></tr></tfoot>
		</table></div>
		<p class="help" style="margin-top:10px">Grand livre général : détail de toutes les écritures imputées au compte, avec solde d'ouverture (gestionnaire des À-nouveaux) et solde progressif.</p>
	<?php endif; ?>

<?php /* --- CENTRALISATION DES JOURNAUX --- */
elseif ( 'gl:centralisation' === $key ) :
	$td = 0; $tc = 0; $tn = 0; foreach ( $journaux as $j ) { $td += $j['d']; $tc += $j['c']; $tn += (int) $j['nb']; } $ecJ = round( $td - $tc, 2 ); ?>
	<div class="card card-flush table-wrap"><table class="table ext-tbl">
		<thead><tr><th>Journal</th><th>Libellé</th><th class="num">Écritures</th><th class="num">Total débit</th><th class="num">Total crédit</th></tr></thead>
		<tbody>
		<?php foreach ( $journaux as $j ) : $vide = 0 === (int) $j['nb']; $desq = abs( (float) $j['d'] - (float) $j['c'] ) >= 1; ?>
			<tr class="<?= $vide ? 'ext-vide' : '' ?>"><td class="code"><?= e( $j['code'] ) ?></td><td><?= e( $j['libelle'] ) ?><?php if ( $desq ) : ?> <span class="ext-flag ko">déséquilibré</span><?php endif; ?></td>
				<td class="num muted"><?= (int) $j['nb'] ?></td><td class="num"><?= e( $f( $j['d'] ) ) ?></td><td class="num"><?= e( $f( $j['c'] ) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr class="total"><td></td><td>TOTAUX <span class="ext-eq <?= abs( $ecJ ) < 1 ? 'ok' : 'ko' ?>"><?= abs( $ecJ ) < 1 ? '✓ équilibré' : '⚠ écart ' . e( $f( $ecJ ) ) ?></span></td><td class="num"><?= (int) $tn ?></td><td class="num"><?= e( $f( $td ) ) ?></td><td class="num"><?= e( $f( $tc ) ) ?></td></tr></tfoot>
	</table></div>
	<p class="help" style="margin-top:10px">Centralisation : totaux des mouvements par journal sur la période. L'équilibre global (∑ débit = ∑ crédit) garantit la cohérence de la saisie.</p>

<?php /* --- REGISTRE DES IMMOBILISATIONS --- */
elseif ( 'immobilisations:registre' === $key ) :
	$tva = $tcu = $tvnc = 0; foreach ( $immos as $i ) { $tva += $i['va']; $tcu += $i['cumul']; $tvnc += $i['vnc']; }
	$stLabel = array( 'en_service' => 'En service', 'cede' => 'Cédée' ); ?>
	<div class="card card-flush table-wrap"><table class="table ext-tbl">
		<thead><tr><th>Code</th><th>Libellé</th><th>Acquisition</th><th class="num">Durée</th><th class="num">Valeur acq.</th><th class="num">Cumul amort.</th><th class="num">VNC</th><th>Statut</th></tr></thead>
		<tbody>
		<?php if ( empty( $immos ) ) : ?>
			<tr><td colspan="8" class="empty">Aucune immobilisation enregistrée.</td></tr>
		<?php else : foreach ( $immos as $i ) : ?>
			<tr><td class="code"><?= e( $i['code'] ) ?></td><td><?= e( $i['libelle'] ) ?></td>
				<td class="muted"><?= e( $dmy( $i['date_acq'] ) ) ?></td>
				<td class="num muted"><?= e( rtrim( rtrim( number_format( $i['duree'], 1, ',', ' ' ), '0' ), ',' ) ) ?> ans</td>
				<td class="num"><?= e( $f( $i['va'] ) ) ?></td><td class="num"><?= e( $f( $i['cumul'] ) ) ?></td>
				<td class="num"><strong><?= e( $f( $i['vnc'] ) ) ?></strong></td>
				<td><span class="modbadge <?= 'cede' === $i['statut'] ? 'b-off' : 'b-on' ?>"><?= e( $stLabel[ $i['statut'] ] ?? $i['statut'] ) ?></span></td></tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( ! empty( $immos ) ) : ?>
		<tfoot><tr class="total"><td></td><td>TOTAUX</td><td></td><td></td><td class="num"><?= e( $f( $tva ) ) ?></td><td class="num"><?= e( $f( $tcu ) ) ?></td><td class="num"><?= e( $f( $tvnc ) ) ?></td><td></td></tr></tfoot>
		<?php endif; ?>
	</table></div>
	<p class="help" style="margin-top:10px">Registre des immobilisations : valeur d'origine, amortissements effectivement comptabilisés et valeur nette comptable (VNC = valeur d'acquisition − cumul des dotations).</p>

<?php /* --- TABLEAU D'AMORTISSEMENT --- */
elseif ( 'immobilisations:amortissements' === $key ) :
	$grouped = array(); foreach ( $amorts as $a ) { $grouped[ $a['code'] . '|' . $a['libelle'] ][] = $a; } ?>
	<div class="card card-flush table-wrap"><table class="table ext-tbl">
		<thead><tr><th>Code</th><th>Immobilisation</th><th class="num">Exercice</th><th class="num">Dotation</th><th class="num">Cumul</th><th class="num">VNC fin</th></tr></thead>
		<tbody>
		<?php if ( empty( $amorts ) ) : ?>
			<tr><td colspan="6" class="empty">Aucun plan d'amortissement à calculer.</td></tr>
		<?php else : foreach ( $grouped as $cle => $plan ) : list( $code, $lib ) = explode( '|', $cle, 2 ); $n = count( $plan ); $first = true; ?>
			<?php foreach ( $plan as $a ) : ?>
				<tr>
					<?php if ( $first ) : ?><td class="code" rowspan="<?= $n ?>"><?= e( $code ) ?></td><td rowspan="<?= $n ?>"><?= e( $lib ) ?></td><?php endif; ?>
					<td class="num"><?= (int) $a['exercice'] ?></td>
					<td class="num"><?= e( $f( $a['dotation'] ) ) ?></td>
					<td class="num muted"><?= e( $f( $a['cumul'] ) ) ?></td>
					<td class="num"><?= e( $f( $a['vnc'] ) ) ?></td>
				</tr>
			<?php $first = false; endforeach; ?>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
	<p class="help" style="margin-top:10px">Tableau d'amortissement linéaire (prorata temporis, base 360) : dotation prévisionnelle par exercice, cumul et valeur nette comptable en fin de période.</p>

<?php endif; ?>

<style>
.ext-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.ext-title{font-family:Syne,sans-serif;font-weight:700;font-size:16px}.ext-title span{color:var(--orange)}
.table .code{font-family:ui-monospace,monospace;color:var(--orange);font-weight:700}

/* Onglets principaux */
.ext-tabs{display:flex;gap:6px;align-items:center;border-bottom:1px solid var(--line);margin-bottom:16px;flex-wrap:wrap}
.ext-tab{display:flex;align-items:center;gap:7px;padding:9px 15px;border-radius:9px 9px 0 0;color:var(--muted);font-weight:600;font-size:13.5px;border:1px solid transparent;border-bottom:none;transition:.12s}
.ext-tab:hover{color:var(--text);background:var(--panel2)}
.ext-tab .ico{font-size:14px}
.ext-tab.on{color:var(--text);background:var(--panel);border-color:var(--line);position:relative;top:1px}
.ext-tab.on::after{content:"";position:absolute;left:0;right:0;bottom:-1px;height:2px;background:var(--orange)}

/* Cartes CTA des états */
.ext-states{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px;margin-bottom:16px}
.ext-state{display:flex;flex-direction:column;gap:5px;padding:13px 15px;border:1px solid var(--line);border-radius:11px;background:var(--bg2);transition:.12s}
.ext-state:hover{border-color:var(--line2);background:var(--panel)}
.ext-state.on{border-color:var(--orange);background:linear-gradient(135deg,rgba(243,154,18,.10),var(--panel));box-shadow:0 0 0 1px rgba(243,154,18,.25)}
.es-top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.es-name{font-family:Syne,sans-serif;font-weight:700;font-size:13.5px;color:var(--text)}
.es-badge{font-size:9.5px;font-weight:700;letter-spacing:.4px;text-transform:uppercase;color:var(--orange);border:1px solid var(--orange);border-radius:20px;padding:1px 8px}
.es-desc{font-size:11.5px;color:var(--muted);line-height:1.4}

/* Filtres */
.ext-filters{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-bottom:14px}
/* La grille automatique des formulaires (app.css, « form:has(> .fld ~ .fld) »)
   étirait chaque filtre sur une ligne entière : on garde une barre compacte. */
.content form.ext-filters,.ext-filters{display:flex!important;gap:10px;align-items:flex-end;flex-wrap:wrap}
.content form.ext-filters>*{grid-column:auto}
.ext-filters>.fld{flex:0 0 auto;width:auto;margin:0}
.ext-filters>.fld input[type=date]{width:170px}
.ext-filters>.btn{flex:0 0 auto;width:auto}

/* Alertes, raccourcis, rapprochements */
.ext-alert{padding:10px 14px;border-radius:10px;font-size:12.8px;margin-bottom:12px;border:1px solid var(--line);border-left-width:3px;background:var(--panel)}
.ext-alert.ok{border-left-color:var(--ok);color:var(--ok)}
.ext-alert.warn{border-left-color:var(--orange);color:var(--text)}
.ext-alert.ko{border-left-color:var(--danger);color:var(--danger)}
.ext-alert a{color:var(--orange);font-weight:600;margin-left:6px}
.ext-presets{display:flex;gap:6px;flex-wrap:wrap;align-self:flex-end;margin-bottom:6px}
.content form.ext-filters>.btn{align-self:flex-end!important;margin:0 0 2px!important}
.ext-preset{font-size:12px;padding:5px 11px;border-radius:99px;border:1px solid var(--line);color:var(--muted);background:var(--panel)}
.ext-preset:hover{color:var(--text);border-color:var(--line2)}
.ext-preset.on{color:var(--orange);border-color:var(--orange)}
.ext-tbl .num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.ext-tbl td.code a{color:inherit;text-decoration:none;border-bottom:1px dashed rgba(243,154,18,.45)}
.ext-tbl td.code a:hover{border-bottom-style:solid}
.ext-tbl td a{color:inherit}
.ext-tbl .neg{color:var(--danger)}
.ext-tbl tr.ext-subtot td{background:rgba(127,168,255,.06);font-weight:700;font-size:12.5px;border-top:1px solid var(--line2)}
.ext-tbl tr.ext-nf td{background:rgba(229,103,95,.05)}
.ext-tbl tr.ext-vide td{color:var(--muted2)}
.ext-flag{font-size:10px;font-weight:800;letter-spacing:.3px;padding:1px 7px;border-radius:99px;color:var(--orange);border:1px solid var(--orange);white-space:nowrap}
.ext-flag.ko{color:var(--danger);border-color:var(--danger)}
.ext-eq{font-size:10.5px;font-weight:800;padding:1px 8px;border-radius:99px;margin-left:8px}
.ext-eq.ok{background:rgba(57,184,126,.14);color:var(--ok)}.ext-eq.ko{background:rgba(229,103,95,.14);color:var(--danger)}
@media print{.ext-tabs,.ext-states,.ext-filters,.ext-head .btn,.ext-alert a{display:none!important}}

/* Grand livre */
.gl-tiers-head{display:flex;align-items:baseline;gap:12px;margin-bottom:10px}
.gl-tiers-name{font-family:Syne,sans-serif;font-weight:700;font-size:15px}
.table tr.gl-ouv td{background:rgba(243,154,18,.05);font-style:italic;color:var(--muted)}
.table tr.gl-ouv .code{font-style:normal}
</style>
