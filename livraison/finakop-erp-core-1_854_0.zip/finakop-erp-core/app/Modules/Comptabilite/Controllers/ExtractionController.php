<?php
/**
 * Extractions comptables normées SYSCOHADA/DGI.
 * Onglets : Balance générale · Clients · Fournisseurs · GL (centralisation) · Immobilisations.
 * Chaque onglet expose plusieurs états consultables et exportables en CSV :
 *   - Balance générale
 *   - Balances auxiliaires (clients / fournisseurs)
 *   - Balances âgées (clients / fournisseurs)
 *   - Grand livre (clients / fournisseurs / général)
 *   - Centralisation des journaux
 *   - Registre & tableau d'amortissement des immobilisations
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ExtractionController {

	/** Onglets disponibles. */
	const VUES = array( 'balance', 'clients', 'fournisseurs', 'gl', 'immobilisations' );

	/** États valides par onglet (le premier est l'état par défaut). */
	const ETATS = array(
		'balance'         => array( 'generale' ),
		'clients'         => array( 'aux', 'agee', 'gl' ),
		'fournisseurs'    => array( 'aux', 'agee', 'gl' ),
		'gl'              => array( 'balance', 'grandlivre', 'centralisation' ),
		'immobilisations' => array( 'registre', 'amortissements' ),
	);

	protected function vue() {
		$v = $_GET['vue'] ?? 'balance';
		return in_array( $v, self::VUES, true ) ? $v : 'balance';
	}
	protected function etat( $vue ) {
		$valides = self::ETATS[ $vue ];
		$e = $_GET['etat'] ?? $valides[0];
		return in_array( $e, $valides, true ) ? $e : $valides[0];
	}
	/**
	 * Période demandée — à défaut, l'EXERCICE EN COURS (1.853.0).
	 *
	 * Le défaut était l'année civile, comme l'était celui des états DGI avant
	 * la 1.544.0 : chez un dossier clôturant au 30 juin, la balance s'ouvrait
	 * sur six mois d'un exercice et six du suivant. Une date invalide
	 * (« 2025-02-31 ») ou une période inversée retombent aussi sur des bornes
	 * saines au lieu de produire une balance vide sans explication.
	 */
	protected function periode() {
		list( $d0, $f0 ) = $this->bornesDefaut();
		$du = (string) ( $_GET['du'] ?? $d0 );
		$au = (string) ( $_GET['au'] ?? $f0 );
		$du = self::dateValide( $du ) ? $du : $d0;
		$au = self::dateValide( $au ) ? $au : $f0;
		if ( $du > $au ) { list( $du, $au ) = array( $au, $du ); }
		return array( $du, $au );
	}

	/** Bornes de l'exercice courant (année civile si aucun exercice n'est déclaré). */
	protected function bornesDefaut() {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'bornes' ) ) {
			try { return FKC_Exercice::bornes( (int) FKC_Exercice::courant() ); } catch ( \Throwable $e ) {}
		}
		$y = (int) date( 'Y' );
		return array( $y . '-01-01', $y . '-12-31' );
	}

	protected static function dateValide( $d ) {
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $d, $m ) ) { return false; }
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	}
	protected function asOf() {
		$d = (string) ( $_GET['arrete'] ?? date( 'Y-m-d' ) );
		return self::dateValide( $d ) ? $d : date( 'Y-m-d' );
	}

	/* ───────────────────────── Affichage ───────────────────────── */
	public function index() {
		$vue    = $this->vue();
		$etat   = $this->etat( $vue );
		list( $du, $au ) = $this->periode();
		$arrete = $this->asOf();
		$tiersId  = (int) ( $_GET['tiers_id'] ?? 0 );
		$compteId = (int) ( $_GET['compte_id'] ?? 0 );

		$data = array(
			'title' => 'Comptabilité · Extractions', 'tab' => 'extractions',
			'vue' => $vue, 'etat' => $etat, 'du' => $du, 'au' => $au, 'arrete' => $arrete,
			'tiersId' => $tiersId, 'compteId' => $compteId,
			'clients' => FKC_Client::all(), 'fournisseurs' => FKC_Fournisseur::all(),
			'comptes' => FKC_Compte::all(),
			'exercice' => $this->bornesDefaut(),
			/*
			 * PONT BROUILLARD (1.853.0). Les écritures du journal temporaire
			 * ne sont dans aucune extraction ; la liasse le disait déjà, les
			 * extractions non — une balance « juste » pouvait donc ignorer une
			 * semaine de saisie sans que rien ne le signale.
			 */
			'attente' => FKC_EtatsDgi::enAttente( $du, $au ),
		);

		switch ( $vue . ':' . $etat ) {
			case 'balance:generale':
			case 'gl:balance':
				$data['rows'] = FKC_Rapport::balance( $du, $au );
				$data['tot']  = $this->totauxBalance( $data['rows'] );
				$data['ctxO'] = FKC_Rapport::contexteOuverture();
				$data['classes'] = $this->sousTotauxClasses( $data['rows'] );
				break;

			case 'clients:aux':
				$data['rows'] = FKC_Rapport::balanceAuxClients( $du, $au );
				$data['tot']  = $this->totauxBalance( $data['rows'] );
				$data['collectif'] = $this->collectif( '411', $du, $au, $data['tot'] );
				break;
			case 'fournisseurs:aux':
				$data['rows'] = FKC_Rapport::balanceAuxFournisseurs( $du, $au );
				$data['tot']  = $this->totauxBalance( $data['rows'] );
				$data['collectif'] = $this->collectif( '401', $du, $au, $data['tot'] );
				break;

			case 'clients:agee':
				$data['lignes'] = FKC_Rapport::balanceAgeeClients( $arrete );
				$data['tiers']  = 'Clients';
				break;
			case 'fournisseurs:agee':
				$data['lignes'] = FKC_Rapport::balanceAgeeFournisseurs( $arrete );
				$data['tiers']  = 'Fournisseurs';
				break;

			case 'clients:gl':
				$data['gl'] = $tiersId ? FKC_Rapport::grandLivreTiers( 'client', $tiersId, $du, $au ) : null;
				$data['tiersSel'] = $tiersId ? FKC_Client::find( $tiersId ) : null;
				break;
			case 'fournisseurs:gl':
				$data['gl'] = $tiersId ? FKC_Rapport::grandLivreTiers( 'fournisseur', $tiersId, $du, $au ) : null;
				$data['tiersSel'] = $tiersId ? FKC_Fournisseur::find( $tiersId ) : null;
				break;

			case 'gl:grandlivre':
				$data['compteSel'] = $compteId ? FKC_Compte::find( $compteId ) : null;
				$data['mouvements'] = $compteId ? FKC_Rapport::grandLivre( $compteId, $du, $au ) : array();
				$data['ouverture']  = $compteId ? FKC_Rapport::grandLivreOuverture( $compteId, $du ) : 0;
				break;
			case 'gl:centralisation':
				$data['journaux'] = FKC_Rapport::centralisationJournaux( $du, $au );
				break;

			case 'immobilisations:registre':
				$data['immos'] = FKC_Rapport::registreImmobilisations();
				break;
			case 'immobilisations:amortissements':
				$data['amorts'] = FKC_Rapport::tableauAmortissements();
				break;
		}
		FKC_View::render( 'comptabilite::extractions.index', $data );
	}

	/** Sous-totaux par classe de la balance générale (classe => totaux). */
	protected function sousTotauxClasses( $rows ) {
		$out = array();
		foreach ( $rows as $r ) {
			$c = substr( (string) ( $r['numero'] ?? '' ), 0, 1 );
			if ( '' === $c ) { continue; }
			if ( ! isset( $out[ $c ] ) ) { $out[ $c ] = array(); }
			$out[ $c ][] = $r;
		}
		foreach ( $out as $c => $rs ) { $out[ $c ] = $this->totauxBalance( $rs ); }
		return $out;
	}

	/**
	 * RAPPROCHEMENT AUXILIAIRE ↔ COLLECTIF (1.853.0).
	 *
	 * L'écran affirmait « le total doit concorder avec le compte collectif de
	 * la balance générale » sans jamais le vérifier. La balance auxiliaire est
	 * reconstituée depuis la Facturation et les règlements ; le collectif vit
	 * au grand livre. Les rapprocher est le seul moyen de voir une facture non
	 * comptabilisée, un règlement saisi en OD ou une écriture manuelle sur 411.
	 */
	protected function collectif( $racine, $du, $au, array $totAux ) {
		$gl = 0.0; $trouve = false;
		foreach ( FKC_Rapport::balance( $du, $au ) as $r ) {
			if ( 0 === strpos( (string) $r['numero'], $racine ) ) {
				$gl += (float) $r['solde_debiteur'] - (float) $r['solde_crediteur'];
				$trouve = true;
			}
		}
		$aux = (float) $totAux['sd'] - (float) $totAux['sc'];
		return array( 'racine' => $racine, 'gl' => round( $gl, 2 ), 'aux' => round( $aux, 2 ),
			'ecart' => round( $aux - $gl, 2 ), 'trouve' => $trouve );
	}

	protected function totauxBalance( $rows ) {
		$t = array( 'ouv_debit' => 0, 'ouv_credit' => 0, 'debit' => 0, 'credit' => 0, 'sd' => 0, 'sc' => 0 );
		foreach ( $rows as $r ) {
			$t['ouv_debit']  += $r['ouv_debit'];  $t['ouv_credit'] += $r['ouv_credit'];
			$t['debit']      += $r['debit'];      $t['credit']     += $r['credit'];
			$t['sd']         += $r['solde_debiteur']; $t['sc']     += $r['solde_crediteur'];
		}
		return $t;
	}

	/* ───────────────────────── En-tête CSV ───────────────────────── */
	/** Lignes de métadonnées en tête d'export (société, NCC, état, période). */
	protected function metaCsv( $etatLabel, $periodeLabel, $du = null, $au = null ) {
		$soc    = FKC_Tenant::current();
		$raison = FKC_License::param( 'fne_company_name', '' ) ?: ( $soc['raison_sociale'] ?? '—' );
		$ncc    = FKC_License::param( 'fne_ncc', '' ) ?: ( $soc['ncc'] ?? '' );
		$out = array(
			array( $raison . ( ! empty( $soc['sigle'] ) ? ' (' . $soc['sigle'] . ')' : '' ) ),
			array( 'NCC', $ncc ),
			array( 'État', $etatLabel ),
			array( 'Période', $periodeLabel ),
			array( 'Édité le', date( 'd/m/Y H:i' ) ),
		);
		// Le fichier dit lui-même ce qui manque : son lecteur n'a pas l'écran.
		if ( $du && $au ) {
			$att = FKC_EtatsDgi::enAttente( $du, $au );
			if ( $att['nb'] > 0 ) {
				$out[] = array( 'RÉSERVE', $att['nb'] . ' écriture(s) de la période au journal temporaire, absentes de cet état.' );
			}
		}
		$out[] = array( '' );
		return $out;
	}
	protected function libPeriode( $du, $au ) { return 'Du ' . date( 'd/m/Y', strtotime( $du ) ) . ' au ' . date( 'd/m/Y', strtotime( $au ) ); }
	/** Nom de fichier sûr — les accents sont translittérés au lieu d'être perdus. */
	protected function slug( $s ) {
		$s = (string) $s;
		if ( function_exists( 'iconv' ) ) { $t = @iconv( 'UTF-8', 'ASCII//TRANSLIT//IGNORE', $s ); if ( false !== $t ) { $s = $t; } }
		$s = trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( $s ) ), '-' );
		return '' !== $s ? $s : 'tiers';
	}

	/* ───────────────────────── Export CSV ───────────────────────── */
	public function csv() {
		$vue    = $this->vue();
		$etat   = $this->etat( $vue );
		list( $du, $au ) = $this->periode();
		$arrete = $this->asOf();
		$tiersId  = (int) ( $_GET['tiers_id'] ?? 0 );
		$compteId = (int) ( $_GET['compte_id'] ?? 0 );

		switch ( $vue . ':' . $etat ) {
			case 'balance:generale':
			case 'gl:balance':
				return $this->csvBalance( FKC_Rapport::balance( $du, $au ), 'Balance générale', $du, $au, 'balance-generale' );
			case 'clients:aux':
				return $this->csvBalance( FKC_Rapport::balanceAuxClients( $du, $au ), 'Balance auxiliaire clients', $du, $au, 'balance-aux-clients', 'Client' );
			case 'fournisseurs:aux':
				return $this->csvBalance( FKC_Rapport::balanceAuxFournisseurs( $du, $au ), 'Balance auxiliaire fournisseurs', $du, $au, 'balance-aux-fournisseurs', 'Fournisseur' );

			case 'clients:agee':
				return $this->csvAgee( FKC_Rapport::balanceAgeeClients( $arrete ), 'Client', $arrete );
			case 'fournisseurs:agee':
				return $this->csvAgee( FKC_Rapport::balanceAgeeFournisseurs( $arrete ), 'Fournisseur', $arrete );

			case 'clients:gl':
				return $this->csvGlTiers( 'client', $tiersId, $du, $au );
			case 'fournisseurs:gl':
				return $this->csvGlTiers( 'fournisseur', $tiersId, $du, $au );

			case 'gl:grandlivre':
				return $this->csvGlGeneral( $compteId, $du, $au );
			case 'gl:centralisation':
				return $this->csvCentralisation( $du, $au );

			case 'immobilisations:registre':
				return $this->csvRegistreImmo();
			case 'immobilisations:amortissements':
				return $this->csvAmortissements();
		}
		redirect( 'comptabilite/extractions' );
	}

	protected function csvBalance( $rows, $label, $du, $au, $file, $colTiers = 'Compte' ) {
		$out = $this->metaCsv( $label, $this->libPeriode( $du, $au ), $du, $au );
		// Un export ne perd pas l'alerte que l'écran affiche (1.799.0).
		$ctxO = 'Compte' === $colTiers && class_exists( 'FKC_Rapport' ) ? FKC_Rapport::contexteOuverture() : null;
		if ( $ctxO && array_key_exists( 'fiable', $ctxO ) && ! $ctxO['fiable'] ) { $out[] = array( $ctxO['alerte'] ); }
		$intitule = ( 'Compte' === $colTiers ) ? 'Intitulé' : 'Nom';
		$out[] = array( $colTiers, $intitule, 'Ouv. débit', 'Ouv. crédit', 'Mvt débit', 'Mvt crédit', 'Solde débiteur', 'Solde créditeur' );
		$t = $this->totauxBalance( $rows );
		foreach ( $rows as $r ) {
			$code = $r['numero'] ?? ( $r['compte'] ?? '' );
			$lib  = $r['libelle'] ?? ( $r['nom'] ?? '' );
			$out[] = array( $code, $lib, $r['ouv_debit'], $r['ouv_credit'], $r['debit'], $r['credit'], $r['solde_debiteur'], $r['solde_crediteur'] );
		}
		$out[] = array( '', 'TOTAUX', $t['ouv_debit'], $t['ouv_credit'], $t['debit'], $t['credit'], $t['sd'], $t['sc'] );
		fkc_csv( $file . '-' . $du . '_' . $au . '.csv', $out );
	}

	protected function csvAgee( $lignes, $col, $arrete ) {
		$label = 'Balance âgée ' . strtolower( $col ) . 's';
		$out = $this->metaCsv( $label, 'Arrêté au ' . date( 'd/m/Y', strtotime( $arrete ) ) );
		$out[] = array( $col, 'Facturé', 'Réglé / lettré', 'Dont imputé nommément', 'Solde', 'Crédit non affecté', 'Non échu', '0-30 j', '31-60 j', '61-90 j', '+90 j' );
		$tf = $tl = $ts = 0; $tb = array( 'non_echu' => 0, 'b30' => 0, 'b60' => 0, 'b90' => 0, 'b90p' => 0 );
		foreach ( $lignes as $l ) {
			$b = $l['buckets'];
			$out[] = array( $l['nom'], $l['facture'], $l['lettre'], $l['impute'] ?? '', $l['solde'], $l['credit'] ?? '', $b['non_echu'], $b['b30'], $b['b60'], $b['b90'], $b['b90p'] );
			$tf += $l['facture']; $tl += $l['lettre']; $ts += $l['solde'];
			foreach ( $tb as $k => $v ) { $tb[ $k ] += $b[ $k ]; }
		}
		$out[] = array( 'TOTAUX', $tf, $tl, '', $ts, '', $tb['non_echu'], $tb['b30'], $tb['b60'], $tb['b90'], $tb['b90p'] );
		fkc_csv( 'balance-agee-' . strtolower( $col ) . 's-' . $arrete . '.csv', $out );
	}

	protected function csvGlTiers( $type, $tiersId, $du, $au ) {
		$tiers = ( 'client' === $type ) ? FKC_Client::find( $tiersId ) : FKC_Fournisseur::find( $tiersId );
		if ( ! $tiers ) { redirect( 'comptabilite/extractions?vue=' . ( 'client' === $type ? 'clients' : 'fournisseurs' ) . '&etat=gl' ); }
		$res   = FKC_Rapport::grandLivreTiers( $type, $tiersId, $du, $au );
		$label = 'Grand livre ' . $type . ' — ' . $tiers['nom'];
		$out   = $this->metaCsv( $label, $this->libPeriode( $du, $au ), $du, $au );
		$out[] = array( 'Date', 'Journal', 'Pièce', 'Libellé', 'Débit', 'Crédit', 'Solde' );
		if ( abs( (float) $res['ouverture'] ) >= 0.005 ) {
			$o = (float) $res['ouverture'];
			$out[] = array( $du, '', '', FKC_SoldeOuverture::libelleOuverture( $du && $du === FKC_SoldeOuverture::debutDe( FKC_SoldeOuverture::exerciceDe( $du ) ) ? 'ouverture' : 'report', $du, FKC_SoldeOuverture::exerciceDe( $du ?: date( 'Y-m-d' ) ) ), $o > 0 ? $o : 0, $o < 0 ? -$o : 0, $o );
		}
		foreach ( $res['mouvements'] as $m ) {
			$out[] = array( $m['date'], $m['journal'], $m['piece'], $m['libelle'], $m['debit'], $m['credit'], $m['solde'] );
		}
		fkc_csv( 'grand-livre-' . $type . '-' . $this->slug( $tiers['nom'] ) . '.csv', $out );
	}

	protected function csvGlGeneral( $compteId, $du, $au ) {
		$compte = $compteId ? FKC_Compte::find( $compteId ) : null;
		if ( ! $compte ) { redirect( 'comptabilite/extractions?vue=gl&etat=grandlivre' ); }
		$mvts = FKC_Rapport::grandLivre( $compteId, $du, $au );
		$ouv  = FKC_Rapport::grandLivreOuverture( $compteId, $du );
		$label = 'Grand livre — ' . $compte['numero'] . ' ' . $compte['libelle'];
		$out   = $this->metaCsv( $label, $this->libPeriode( $du, $au ), $du, $au );
		$out[] = array( 'Date', 'Journal', 'Pièce', 'Libellé', 'Débit', 'Crédit', 'Solde' );
		if ( abs( (float) $ouv ) >= 0.005 ) {
			$ctxO = FKC_Rapport::contexteOuverture();
			$out[] = array( $du, '', '', $ctxO ? $ctxO['libelle'] : 'Solde d\'ouverture', $ouv > 0 ? $ouv : 0, $ouv < 0 ? -$ouv : 0, $ouv );
		}
		foreach ( $mvts as $m ) {
			$out[] = array( $m['date_ecriture'], $m['journal_code'], $m['piece'], $m['libelle'], $m['debit'], $m['credit'], $m['solde'] );
		}
		fkc_csv( 'grand-livre-' . $compte['numero'] . '.csv', $out );
	}

	protected function csvCentralisation( $du, $au ) {
		$out = $this->metaCsv( 'Centralisation des journaux', $this->libPeriode( $du, $au ), $du, $au );
		$out[] = array( 'Journal', 'Libellé', 'Écritures', 'Total débit', 'Total crédit' );
		$td = $tc = 0; $tn = 0;
		foreach ( FKC_Rapport::centralisationJournaux( $du, $au ) as $j ) {
			$out[] = array( $j['code'], $j['libelle'], (int) $j['nb'], $j['d'], $j['c'] );
			$td += $j['d']; $tc += $j['c']; $tn += (int) $j['nb'];
		}
		$out[] = array( '', 'TOTAUX', $tn, $td, $tc );
		fkc_csv( 'centralisation-journaux-' . $du . '_' . $au . '.csv', $out );
	}

	protected function csvRegistreImmo() {
		$out = $this->metaCsv( 'Registre des immobilisations', 'Au ' . date( 'd/m/Y' ) );
		$out[] = array( 'Code', 'Libellé', 'Date acquisition', 'Durée (ans)', 'Valeur acquisition', 'Valeur résiduelle', 'Cumul amortissements', 'VNC', 'Statut' );
		$tva = $tcu = $tvnc = 0;
		foreach ( FKC_Rapport::registreImmobilisations() as $i ) {
			$out[] = array( $i['code'], $i['libelle'], $i['date_acq'], $i['duree'], $i['va'], $i['vr'], $i['cumul'], $i['vnc'], $i['statut'] );
			$tva += $i['va']; $tcu += $i['cumul']; $tvnc += $i['vnc'];
		}
		$out[] = array( '', 'TOTAUX', '', '', $tva, '', $tcu, $tvnc, '' );
		fkc_csv( 'registre-immobilisations-' . date( 'Y-m-d' ) . '.csv', $out );
	}

	protected function csvAmortissements() {
		$out = $this->metaCsv( 'Tableau des amortissements', 'Plan prévisionnel' );
		$out[] = array( 'Code', 'Libellé', 'Exercice', 'Dotation', 'Cumul', 'VNC' );
		foreach ( FKC_Rapport::tableauAmortissements() as $a ) {
			$out[] = array( $a['code'], $a['libelle'], $a['exercice'], $a['dotation'], $a['cumul'], $a['vnc'] );
		}
		fkc_csv( 'tableau-amortissements-' . date( 'Y-m-d' ) . '.csv', $out );
	}
}
