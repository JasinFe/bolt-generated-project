<?php
/** États financiers DGI : liasses SMT et SN (bilan, compte de résultat, charges) + exports. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EtatsDgiController {

	/** Mention portée par le document en cours d'export ('' si déposable). */
	protected $mention = '';

	/** Suffixe de nom de fichier : une liasse provisoire ne doit pas se confondre
	 *  avec la définitive dans un dossier de téléchargements six mois plus tard. */
	protected function nomFichier( $base ) {
		$suffixe = '';
		if ( 'PROVISOIRE' === $this->mention )   { $suffixe = '-PROVISOIRE'; }
		if ( 'NON CONFORME' === $this->mention ) { $suffixe = '-NON-CONFORME'; }
		return $base . $suffixe . '.csv';
	}

	/**
	 * Millésime demandé.
	 *
	 * Le défaut était `date('Y')` — l'année civile. Sur un dossier clôturant
	 * au 30 juin, ouvrir l'écran en février proposait un exercice qui n'a pas
	 * encore commencé. FKC_Exercice::courant() répond « à quel exercice
	 * sommes-nous », ce qui est la question posée.
	 */
	protected function annee() {
		$defaut = class_exists( 'FKC_Exercice' ) ? (int) FKC_Exercice::courant() : (int) date( 'Y' );
		$a = (int) ( $_GET['annee'] ?? $_POST['annee'] ?? $defaut );
		return ( $a >= 2000 && $a <= 2100 ) ? $a : $defaut;
	}
	/**
	 * Système demandé — à défaut, celui DU DOSSIER (1.853.0).
	 *
	 * L'écran s'ouvrait toujours sur le SMT : un dossier au Système Normal
	 * devait rebasculer à chaque visite, et le Centre de Pilotage, la page
	 * « États financiers » et le pack Cabinet l'envoyaient tous sur la
	 * mauvaise liasse. Le choix se mémorise désormais (paramètre dgi_systeme).
	 */
	protected function systeme() {
		$demande = $_GET['systeme'] ?? $_POST['systeme'] ?? null;
		if ( null === $demande ) { $demande = self::systemeDossier(); }
		return ( 'sn' === $demande ) ? 'sn' : 'smt';
	}

	/** Système comptable enregistré pour le dossier ('smt' par défaut). */
	public static function systemeDossier() {
		$v = class_exists( 'FKC_License' ) ? (string) FKC_License::param( 'dgi_systeme', 'smt' ) : 'smt';
		return 'sn' === $v ? 'sn' : 'smt';
	}

	/** Enregistre le système comptable du dossier (SMT / SN). */
	public function definirSysteme() {
		$sys = ( 'sn' === ( $_POST['systeme'] ?? '' ) ) ? 'sn' : 'smt';
		FKC_License::setParam( 'dgi_systeme', $sys );
		$this->setFlash( 'Système comptable du dossier : ' . ( 'sn' === $sys ? 'Système Normal' : 'Système Minimal de Trésorerie' ) . '.' );
		$retour = (string) ( $_POST['retour'] ?? '' );
		redirect( 'etats-financiers' === $retour
			? 'comptabilite/etats-financiers?systeme=' . $sys . '&annee=' . $this->annee()
			: 'comptabilite/etats-dgi?systeme=' . $sys . '&annee=' . $this->annee() );
	}
	protected function vue() {
		$v = $_GET['vue'] ?? 'bilan';
		// Le tableau des flux n'existe qu'au Système Normal : c'est un état de
		// synthèse du SN, le SMT ne le produit pas.
		$permis = array( 'bilan', 'resultat', 'charges' );
		if ( 'sn' === $this->systeme() ) { $permis[] = 'flux'; }
		$permis[] = 'notes';       // les notes détaillent les deux systèmes
		$permis[] = 'teleliasse';  // la liasse à plat, par code de référence
		return in_array( $v, $permis, true ) ? $v : 'bilan';
	}
	/** Un seul en-tête pour les deux écrans : FKC_EtatsDgi::entete(). */
	protected function entete( $an ) {
		return FKC_EtatsDgi::entete( $an );
	}

	/** L'utilisateur a-t-il demandé à passer outre un refus d'édition ? */
	protected function forcer() {
		return ! empty( $_GET['forcer'] );
	}

	/**
	 * Barrage à l'édition d'une liasse incohérente.
	 *
	 * Un bilan déséquilibré ou trois résultats qui divergent ne produisent pas
	 * une liasse imparfaite mais un document faux, et un document faux qui
	 * sort du logiciel ne revient jamais : il part à la DGI, à la banque, à
	 * l'expert-comptable. Le produit refuse donc de l'éditer.
	 *
	 * Il refuse, il n'interdit pas. Le refus porte un lien « éditer quand
	 * même », comme la suppression forcée de l'Analytique : c'est le dossier
	 * qui décide, pas le logiciel — mais il décide en connaissance de cause,
	 * et le document forcé part estampillé NON CONFORME.
	 *
	 * @return bool Vrai si l'édition doit être interrompue.
	 */
	protected function barrage( $ctrl, $an, $sys, $quoi = null ) {
		if ( ! empty( $ctrl['coherent'] ) || $this->forcer() ) { return false; }
		$retour = 'comptabilite/etats-dgi?systeme=' . $sys . '&annee=' . $an;
		/*
		 * Le fichier EDI a sa propre route (1.853.0) : « éditer quand même »
		 * renvoyait vers /export?quoi=edi, que csv() ne connaît pas — le
		 * dossier qui forçait le XML recevait… le CSV du bilan.
		 */
		if ( null === $quoi ) {
			$forcer = 'comptabilite/etats-dgi/imprimer?systeme=' . $sys . '&annee=' . $an . '&forcer=1';
		} elseif ( 'edi' === $quoi ) {
			$forcer = 'comptabilite/etats-dgi/edi?systeme=' . $sys . '&annee=' . $an . '&forcer=1';
		} else {
			$forcer = 'comptabilite/etats-dgi/export?systeme=' . $sys . '&quoi=' . rawurlencode( (string) $quoi ) . '&annee=' . $an . '&forcer=1';
		}
		FKC_View::render( 'comptabilite::etats_dgi.refus', array(
			'controle' => $ctrl, 'annee' => $an, 'systeme' => $sys,
			'retour' => $retour, 'forcer' => $forcer,
		), false );
		return true;
	}

	/** Millésimes réellement disponibles, exercices décalés compris. */
	protected function annees() {
		if ( class_exists( 'FKC_Exercice' ) ) {
			$y = FKC_Exercice::annees();
			if ( $y ) { return array_map( 'intval', $y ); }
		}
		$cur = (int) date( 'Y' );
		return array( $cur, $cur - 1 );
	}

	public function index() {
		$an  = $this->annee();
		$sys = $this->systeme();
		$vue = $this->vue();
		$data = array(
			'title' => 'États financiers DGI', 'tab' => 'etats-dgi',
			'annee' => $an, 'systeme' => $sys, 'vue' => $vue, 'entete' => $this->entete( $an ),
			'annees' => $this->annees(),
			'controle' => FKC_EtatsDgi::controle( $an ),
			'charges' => FKC_EtatsDgi::compCharges( $an ),
			'notes' => FKC_EtatsDgi::notes( $an, $sys ),
			'notes_texte' => FKC_EtatsDgi::notesTexte( $an ),
			// Note 2 vide : une PROPOSITION tirée des paramètres du dossier,
			// affichée dans le champ, jamais enregistrée d'office.
			'proposition_note2' => FKC_EtatsDgi::proposerNote2( $an ),
			'codes' => FKC_EtatsDgi::codesLiasse( $an, $sys ),
			'edi' => FKC_EtatsDgi::edi( $an, $sys ),
			'societe' => FKC_Tenant::current(),
			'flash' => $this->flash(),
			'synthese' => FKC_EtatsDgi::synthese( $an, $sys ),
			'systeme_dossier' => self::systemeDossier(),
		);
		if ( 'sn' === $sys ) {
			$data['bilan'] = FKC_EtatsDgi::bilanSN( $an );
			$data['crsn']  = FKC_EtatsDgi::resultatSN( $an );
			$data['flux']  = FKC_EtatsDgi::fluxTresorerie( $an );
		} else {
			$data['bilan'] = FKC_EtatsDgi::bilan( $an );
			$data['cr']    = FKC_EtatsDgi::resultat( $an );
		}
		FKC_View::render( 'comptabilite::etats_dgi.index', $data );
	}

	/**
	 * Impression.
	 *
	 * L'écran proposait les deux systèmes ; le bouton « Imprimer » ne
	 * transmettait pas le sien et cette méthode ne le lisait pas. Un dossier
	 * au Système Normal imprimait donc, en toute confiance, la liasse du
	 * Système Minimal de Trésorerie.
	 */
	public function imprimer() {
		$an  = $this->annee();
		$sys = $this->systeme();
		$e   = $this->entete( $an );
		$ctrl = FKC_EtatsDgi::controle( $an );
		if ( $this->barrage( $ctrl, $an, $sys ) ) { return; }
		$data = array(
			'annee' => $an, 'systeme' => $sys, 'entete' => $e,
			'societe' => $e['societe'], 'ncc' => $e['ncc'],
			'controle' => $ctrl, 'mention' => FKC_EtatsDgi::mention( $ctrl ),
			'notes' => FKC_EtatsDgi::notes( $an, $sys ),
			'notes_texte' => FKC_EtatsDgi::notesTexte( $an ),
		);
		if ( 'sn' === $sys ) {
			$data['bilan'] = FKC_EtatsDgi::bilanSN( $an );
			$data['crsn']  = FKC_EtatsDgi::resultatSN( $an );
			$data['flux']  = FKC_EtatsDgi::fluxTresorerie( $an );
		} else {
			$data['bilan'] = FKC_EtatsDgi::bilan( $an );
			$data['cr']    = FKC_EtatsDgi::resultat( $an );
		}
		FKC_View::render( 'comptabilite::etats_dgi.print', $data, false );
	}

	public function csv() {
		$an = $this->annee();
		$sys = $this->systeme();
		$quoi = (string) ( $_GET['quoi'] ?? 'bilan' );
		// Le tableau des flux n'existe qu'au Système Normal : un lien SMT
		// vers « flux » exportait silencieusement le bilan sous ce nom.
		if ( ! in_array( $quoi, array( 'bilan', 'resultat', 'charges', 'flux', 'notes', 'teleliasse' ), true ) ) { $quoi = 'bilan'; }
		$e = $this->entete( $an );
		$ctrl = FKC_EtatsDgi::controle( $an );
		if ( $this->barrage( $ctrl, $an, $sys, $quoi ) ) { return; }
		$this->mention = FKC_EtatsDgi::mention( $ctrl );
		$head = array(
			array( 'État', ( 'sn' === $sys ? 'Système Normal (SN)' : 'Système Minimal de Trésorerie (SMT)' ) ),
			array( 'Société', $e['societe'] ), array( 'NCC', $e['ncc'] ), array( 'NTD', $e['ntd'] ),
			array( 'Exercice', $e['libelle'] . ' — du ' . $e['ouvert'] . ' au ' . $e['cloture'] . ' (' . $e['duree'] . ' mois)' ),
			array( 'Édité le', $e['edite'] ),
		);
		if ( '' !== $this->mention ) { array_unshift( $head, array( 'MENTION', $this->mention ) ); }
		/*
		 * Un export part par courriel et survit à l'écran qui l'a produit.
		 * S'il repose sur un exercice non clôturé, sur des à-nouveaux absents
		 * ou sur des écritures encore au journal temporaire, le fichier doit
		 * le dire lui-même : son lecteur n'aura pas le bandeau sous les yeux.
		 */
		foreach ( $ctrl['anomalies'] as $a ) {
			$head[] = array( 'bloquant' === $a['niveau'] ? 'RÉSERVE' : 'Note', $a['texte'] );
		}
		$head[] = array();

		if ( 'sn' === $sys ) {
			if ( 'resultat' === $quoi ) {
				$cr = FKC_EtatsDgi::resultatSN( $an );
				$rows = array_merge( $head, array( array( 'Réf', 'Solde intermédiaire de gestion', 'Exercice N', 'Exercice N-1' ) ) );
				foreach ( $cr['lignes'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
				return fkc_csv( $this->nomFichier( 'compte-resultat-SN-' . $an ), $rows );
			}
			if ( 'flux' === $quoi ) {
				$t = FKC_EtatsDgi::fluxTresorerie( $an );
				$rows = array_merge( $head, array( array( 'Réf', 'Flux de trésorerie', 'Note', 'Exercice N', 'Exercice N-1' ) ) );
				foreach ( $t['lignes'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['note'], $l['valeur'], $l['n1'] ); }
				return fkc_csv( $this->nomFichier( 'flux-tresorerie-' . $an ), $rows );
			}
			if ( 'teleliasse' === $quoi ) { return $this->csvCodes( $an, $sys, $head ); }
			if ( 'notes' === $quoi ) { return $this->csvNotes( $an, $head ); }
			if ( 'charges' === $quoi ) { return $this->csvCharges( $an, $head ); }
			$b = FKC_EtatsDgi::bilanSN( $an );
			$rows = array_merge( $head, array( array( 'Réf', 'Masse', 'Exercice N', 'Exercice N-1' ), array( '', '— ACTIF —' ) ) );
			foreach ( $b['actif'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['net'], $l['n1'] ); }
			$rows[] = array( '', 'TOTAL ACTIF', $b['total_actif']['n'], $b['total_actif']['n1'] );
			$rows[] = array( '', '— PASSIF —' );
			foreach ( $b['passif'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['net'], $l['n1'] ); }
			$rows[] = array( '', 'TOTAL PASSIF', $b['total_passif']['n'], $b['total_passif']['n1'] );
			return fkc_csv( $this->nomFichier( 'bilan-SN-' . $an ), $rows );
		}

		// SMT
		if ( 'resultat' === $quoi ) {
			$cr = FKC_EtatsDgi::resultat( $an );
			$rows = array_merge( $head, array( array( 'Réf', 'Poste', 'Exercice N', 'Exercice N-1' ) ) );
			foreach ( $cr['produits'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			foreach ( $cr['charges'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			$rows[] = array( $cr['kz']['code'], $cr['kz']['libelle'], $cr['kz']['n'], $cr['kz']['n1'] );
			foreach ( $cr['variations'] as $v ) { $rows[] = array( $v['code'], $v['libelle'], $v['n'], $v['n1'] ); }
			$rows[] = array( $cr['jg']['code'], $cr['jg']['libelle'], $cr['jg']['n'], $cr['jg']['n1'] );
			$rows[] = array( $cr['kzc']['code'], $cr['kzc']['libelle'], $cr['kzc']['n'], $cr['kzc']['n1'] );
			return fkc_csv( $this->nomFichier( 'compte-resultat-SMT-' . $an ), $rows );
		}
		if ( 'teleliasse' === $quoi ) { return $this->csvCodes( $an, $sys, $head ); }
		if ( 'notes' === $quoi ) { return $this->csvNotes( $an, $head ); }
		if ( 'charges' === $quoi ) { return $this->csvCharges( $an, $head ); }
		$b = FKC_EtatsDgi::bilan( $an );
		$rows = array_merge( $head, array( array( 'Réf', 'Poste', 'Note', 'Exercice N', 'Exercice N-1' ), array( '', '— ACTIF —' ) ) );
		foreach ( $b['actif'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['note'], $l['n'], $l['n1'] ); }
		$rows[] = array( 'GZ', 'TOTAL ACTIF', '', $b['total_actif']['n'], $b['total_actif']['n1'] );
		$rows[] = array( '', '— PASSIF —' );
		foreach ( $b['passif'] as $l ) { $rows[] = array( $l['code'], $l['libelle'], $l['note'], $l['n'], $l['n1'] ); }
		$rows[] = array( 'HZ', 'TOTAL PASSIF', '', $b['total_passif']['n'], $b['total_passif']['n1'] );
		fkc_csv( $this->nomFichier( 'bilan-SMT-' . $an ), $rows );
	}

	/** Enregistrement de l'annexe descriptive — une note par champ soumis. */
	public function enregistrerNotes() {
		$an = $this->annee();
		$champs = (array) ( $_POST['note'] ?? array() );
		$ok = 0; $err = array();
		foreach ( $champs as $cle => $contenu ) {
			list( $r, $msg ) = FKC_EtatsDgi::enregistrerNoteTexte( $an, (string) $cle, (string) $contenu );
			if ( $r ) { $ok++; } else { $err[] = $msg; }
		}
		$this->setFlash( $err ? implode( ' ', $err ) : 'Annexe descriptive enregistrée.', $err ? 'err' : 'ok' );
		redirect( 'comptabilite/etats-dgi?systeme=' . $this->systeme() . '&vue=notes&annee=' . $an );
	}

	/** Numéro de télédéclarant — réclamé par chaque feuillet de la liasse. */
	public function ntd() {
		FKC_License::setParam( 'dgi_ntd', trim( (string) ( $_POST['ntd'] ?? '' ) ) );
		$this->setFlash( 'Numéro de télédéclarant enregistré.' );
		redirect( 'comptabilite/etats-dgi?systeme=' . $this->systeme() . '&vue=notes&annee=' . $this->annee() );
	}

	/** Reprise des notes descriptives de l'exercice précédent. */
	public function reprendreNotes() {
		$an = $this->annee();
		list( $ok, $msg ) = FKC_EtatsDgi::reprendreNotesTexte( $an );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/etats-dgi?systeme=' . $this->systeme() . '&vue=notes&annee=' . $an );
	}

	protected function setFlash( $msg, $type = 'ok' ) { $_SESSION['__flash_dgi'] = array( 'msg' => $msg, 'type' => $type ); }
	protected function flash() { $m = $_SESSION['__flash_dgi'] ?? null; unset( $_SESSION['__flash_dgi'] ); return $m; }

	/**
	 * Fichier EDI XML pour e-impots.
	 *
	 * L'import écrase tout ce qui est déjà saisi sur le portail : on refuse
	 * donc de produire le fichier d'une liasse incohérente, sauf forçage —
	 * même barrage que l'impression, pour la même raison, en plus sérieuse.
	 */
	public function edi() {
		$an  = $this->annee();
		$sys = $this->systeme();
		$ctrl = FKC_EtatsDgi::controle( $an );
		if ( $this->barrage( $ctrl, $an, $sys, 'edi' ) ) { return; }
		$r = FKC_EtatsDgi::edi( $an, $sys );
		$mention = FKC_EtatsDgi::mention( $ctrl );
		$suffixe = ( '' === $mention ) ? '' : ( 'PROVISOIRE' === $mention ? '-PROVISOIRE' : '-NON-CONFORME' );
		$nom = 'EDI-' . $r['type'] . '-' . ( $r['ncc'] ? $r['ncc'] . '-' : '' ) . $an . $suffixe . '.xml';
		if ( ! headers_sent() ) {
			header( 'Content-Type: application/xml; charset=UTF-8' );
			header( 'Content-Disposition: attachment; filename="' . $nom . '"' );
		}
		echo $r['xml'];
		exit;
	}

	/**
	 * Export de la liasse à plat, une ligne par code de référence.
	 *
	 * Destiné à la saisie sur le module Téléliasse : chaque champ du
	 * formulaire porte l'un de ces codes. Le nom du fichier annonce ce que
	 * c'est — une aide à la saisie, pas un fichier d'import.
	 */
	protected function csvCodes( $an, $sys, $head ) {
		$c = FKC_EtatsDgi::codesLiasse( $an, $sys );
		$rows = array_merge( $head, array(
			array( 'Usage', "Saisie assistée du module Téléliasse (e-impots.gouv.ci) — une ligne par code de référence, dans l'ordre des feuillets." ),
			array( 'Avertissement', "Ce fichier n'est PAS un fichier d'import : le format d'import du module Téléliasse n'est pas publié." ),
			array(),
			array( 'Ordre', 'Feuillet', 'Code', 'Libellé', 'Exercice N', 'Exercice N-1' ),
		) );
		foreach ( $c['lignes'] as $l ) {
			$rows[] = array( $l['ordre'], $l['feuillet'], $l['code'], $l['libelle'],
				isset( $l['texte'] ) ? $l['texte'] : $l['n'], $l['n1'] );
		}
		fkc_csv( $this->nomFichier( 'liasse-codes-' . strtoupper( $sys ) . '-' . $an ), $rows );
	}

	protected function csvNotes( $an, $head ) {
		$n = FKC_EtatsDgi::notes( $an, $this->systeme() );
		$rows = array_merge( $head, array( array( 'Note', 'Compte', 'Libellé', 'Exercice N', 'Exercice N-1' ) ) );
		foreach ( $n['notes'] as $note ) {
			$rows[] = array( 'NOTE ' . $note['numero'], '', $note['titre'] );
			foreach ( $note['lignes'] as $l ) { $rows[] = array( '', $l['numero'], $l['libelle'], $l['n'], $l['n1'] ); }
			$rows[] = array( '', '', 'TOTAL NOTE ' . $note['numero'], $note['total'], $note['total_n1'] );
			if ( ! empty( $note['mouvements'] ) ) {
				$rows[] = array( '', '', 'Variation', 'Ouverture', 'Entrées', 'Sorties', 'Clôture' );
				foreach ( $note['mouvements'] as $m ) {
					$rows[] = array( '', $m['numero'], $m['libelle'] . ' (' . $m['nature'] . ')', $m['ouverture'], $m['entrees'], $m['sorties'], $m['cloture'] );
				}
			}
			$rows[] = array();
		}
		// L'annexe descriptive part avec le reste : elle fait partie de la liasse.
		$txt = FKC_EtatsDgi::notesTexte( $an );
		foreach ( $txt['notes'] as $note ) {
			if ( '' === $note['contenu'] ) { continue; }
			$rows[] = array( 'NOTE ' . $note['cle'], '', $note['titre'] );
			$rows[] = array( '', '', $note['contenu'] );
			$rows[] = array();
		}
		fkc_csv( $this->nomFichier( 'notes-annexes-' . $an ), $rows );
	}

	protected function csvCharges( $an, $head ) {
		$ch = FKC_EtatsDgi::compCharges( $an );
		$rows = array_merge( $head, array( array( 'Réf/Compte', 'Détail des charges (FCFA)', 'Exercice N', 'Exercice N-1', 'Variation valeur', 'Variation %' ) ) );
		foreach ( $ch['groupes'] as $g ) {
			foreach ( $g['lignes'] as $l ) {
				$rows[] = array( $l['numero'], $l['libelle'] . ( ! empty( $l['repli'] ) ? ' [ligne de repli]' : '' ), $l['n'], $l['n1'], $l['var']['val'], null === $l['var']['pct'] ? '' : $l['var']['pct'] . ' %' );
			}
			$rows[] = array( $g['code'], $g['libelle'], $g['n'], $g['n1'], $g['var']['val'], null === $g['var']['pct'] ? '' : $g['var']['pct'] . ' %' );
		}
		$rows[] = array( '', 'TOTAL DES CHARGES', $ch['total'], $ch['total_n1'], $ch['var_total']['val'], null === $ch['var_total']['pct'] ? '' : $ch['var_total']['pct'] . ' %' );
		fkc_csv( $this->nomFichier( 'comp-charges-' . $an ), $rows );
	}
}
