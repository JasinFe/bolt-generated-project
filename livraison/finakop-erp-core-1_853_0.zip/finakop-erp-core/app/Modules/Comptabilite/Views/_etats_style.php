<?php
/**
 * FEUILLE DE STYLE COMMUNE DES ÉTATS DE SYNTHÈSE (1.853.0).
 *
 * « États financiers » et « Liasse DGI » portaient chacun leur copie des
 * mêmes règles — et elles avaient divergé (tailles, couleurs de totaux,
 * points de rupture). Un seul fichier : les deux écrans ont désormais la
 * même grammaire visuelle, et une correction ne se fait qu'une fois.
 *
 * Principes : chiffres en tabular-nums alignés à droite, hiérarchie
 * détail → sous-total → total → total général lisible sans couleur,
 * en-têtes collants, défilement horizontal sur mobile au lieu d'un
 * tableau écrasé, et une mise en page d'impression sobre.
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<style>
/* ── En-tête de page ─────────────────────────────────────────────── */
.ef-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px}
.ef-title{font-family:Syne,sans-serif;font-weight:800;font-size:19px;letter-spacing:-.2px}.ef-title span{color:var(--orange)}
.ef-exports{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.ef-mention{display:inline-block;padding:3px 10px;border-radius:99px;font-size:11px;font-weight:800;letter-spacing:.6px;background:var(--warn-bg,rgba(243,154,18,.14));color:var(--orange)}
.ef-mention.ko{background:var(--danger-bg,rgba(229,103,95,.14));color:var(--danger)}

/* ── Sélecteur d'exercice ────────────────────────────────────────── */
.ef-years{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:16px}
.ef-pill{padding:6px 14px;border-radius:99px;font-weight:700;font-size:12.5px;background:var(--panel);border:1px solid var(--line);color:var(--muted);transition:border-color .12s,color .12s}
.ef-pill:hover{border-color:var(--line2);color:var(--text)}
.ef-pill.on{background:linear-gradient(135deg,var(--orange),var(--orange-d));color:#1a1205;border-color:transparent;box-shadow:0 2px 10px rgba(243,154,18,.28)}
.ef-years input[type=number]{width:88px;padding:6px 10px;border-radius:99px;border:1px solid var(--line);background:var(--panel);color:var(--text);font:inherit;font-size:12.5px}
.ef-period{color:var(--muted);font-size:12.5px;margin-left:auto}.ef-period strong{color:var(--text)}.ef-period .ok{color:var(--ok);font-weight:700}

/* ── Bande d'indicateurs ─────────────────────────────────────────── */
.ef-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}
.ef-kpi{background:var(--panel);border:1px solid var(--line);border-top:3px solid var(--line2);border-radius:13px;padding:14px 16px;display:flex;flex-direction:column;gap:6px;min-width:0}
.ef-kpi-lbl{font-size:10.5px;text-transform:uppercase;letter-spacing:.6px;color:var(--muted2);font-weight:700}
.ef-kpi-lbl em{font-style:normal;font-family:var(--mono);color:var(--orange);opacity:.8;margin-left:4px;letter-spacing:0}
.ef-kpi-val{font-family:Syne,sans-serif;font-weight:800;font-size:21px;font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ef-kpi-val small{font-family:inherit;font-size:11px;color:var(--muted2);font-weight:600}
.ef-kpi-foot{font-size:11.5px;display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.ef-trend{font-weight:800;padding:1px 7px;border-radius:99px;font-size:11px}
.ef-trend.up{background:var(--ok-bg,rgba(57,184,126,.14));color:var(--ok)}
.ef-trend.down{background:var(--danger-bg,rgba(229,103,95,.14));color:var(--danger)}
.ef-kpi.kpi-ca{border-top-color:var(--orange)}
.ef-kpi.kpi-pos{border-top-color:var(--ok)}.ef-kpi.kpi-pos .ef-kpi-val{color:var(--ok)}
.ef-kpi.kpi-neg{border-top-color:var(--danger)}.ef-kpi.kpi-neg .ef-kpi-val{color:var(--danger)}
.ef-kpi.kpi-treso{border-top-color:var(--blue,#3D6FE0)}
.ef-kpi.kpi-bilan{border-top-color:#8B7FE0}

/* ── Fiche d'identification ──────────────────────────────────────── */
.ef-entete{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:12px;margin-bottom:18px}
.ef-entete .el{display:block;font-size:10px;letter-spacing:1.2px;text-transform:uppercase;color:var(--muted2);margin-bottom:6px}
.ef-entete .ev{background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:11px 14px;font-weight:700;font-family:Syne,sans-serif;font-size:14.5px}
.ef-entete .ev.vide{color:var(--danger);font-family:inherit;font-weight:600;font-size:13px}

/* ── Onglets système & états ─────────────────────────────────────── */
.sys-tabs{display:inline-flex;gap:4px;padding:4px;margin-bottom:12px;background:var(--bg2);border:1px solid var(--line);border-radius:12px;flex-wrap:wrap}
.sys-tab{padding:8px 18px;border-radius:9px;font-family:Syne,sans-serif;font-weight:800;font-size:13px;color:var(--muted);transition:background .12s,color .12s}
.sys-tab:hover{color:var(--text)}
.sys-tab.on{background:var(--panel2);color:var(--text);box-shadow:inset 0 -2px 0 var(--orange),0 1px 3px rgba(0,0,0,.25)}
.dgi-tabs{display:flex;gap:4px;align-items:center;border-bottom:1px solid var(--line);margin-bottom:14px;flex-wrap:wrap}
.dgi-tab{padding:9px 15px;color:var(--muted);font-weight:600;font-size:13.5px;border-bottom:2px solid transparent;margin-bottom:-1px;transition:color .12s,border-color .12s}
.dgi-tab:hover{color:var(--text)}
.dgi-tab.on{color:var(--text);border-bottom-color:var(--orange)}
.dgi-eq{margin-left:auto;font-size:12px;font-weight:700;padding:4px 11px;border-radius:99px}
.dgi-eq.ok{background:var(--ok-bg,rgba(57,184,126,.14));color:var(--ok)}.dgi-eq.ko{background:var(--danger-bg,rgba(229,103,95,.14));color:var(--danger)}

/* ── Cartes & tableaux ───────────────────────────────────────────── */
.ef-card{background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;margin-bottom:18px;box-shadow:var(--shadow-sm,none)}
.ef-band{display:flex;justify-content:center;align-items:center;gap:10px;text-align:center;font-family:Syne,sans-serif;font-weight:800;letter-spacing:.6px;font-size:13.5px;text-transform:uppercase;padding:14px 16px;border-bottom:1px solid var(--line);background:linear-gradient(180deg,var(--panel2),var(--panel))}
.ef-scroll{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
.ef-bilan,.sn-bilan{display:grid;grid-template-columns:1fr 1fr;gap:0}
.ef-bilan>.ef-scroll:first-child,.sn-bilan>.ef-scroll:first-child{border-right:1px solid var(--line)}
.table.ef-tbl{margin:0;min-width:520px}
.table.ef-tbl td,.table.ef-tbl th{padding:8px 14px;font-size:12.8px}
.table.ef-tbl th{white-space:nowrap}
.table.ef-tbl .num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.table.ef-tbl .th-cote{text-align:center;color:var(--orange);font-family:Syne,sans-serif;font-weight:800;letter-spacing:2px;font-size:12.5px;padding-top:13px}
.table.ef-tbl .grp{text-align:center;border-bottom:1px solid var(--line)}
.table.ef-tbl .code{font-family:var(--mono);color:var(--orange);font-weight:700;font-size:11.5px;width:52px}
.table.ef-tbl .note,.table.ef-tbl .ctr{text-align:center;color:var(--muted2)}
.table.ef-tbl .sgn{font-weight:700;color:var(--muted)}
.table.ef-tbl .num small{font-size:9.5px;color:var(--muted2);font-weight:400}
.table.ef-tbl .val{color:var(--text)}
.table.ef-tbl .muted{color:var(--muted2)}
.table.ef-tbl .pos{color:var(--ok);font-weight:700}.table.ef-tbl .neg{color:var(--danger);font-weight:700}
.table.ef-tbl tbody tr:hover{background:rgba(255,255,255,.025)}
.table.ef-tbl .subtotal{background:rgba(127,168,255,.06)}.table.ef-tbl .subtotal td{font-weight:700}
.table.ef-tbl .ef-spacer td{padding:4px;background:var(--bg2)}
.table.ef-tbl tbody .total td,.table.ef-tbl tfoot .total td{font-weight:800;color:var(--orange);border-top:1px solid var(--line2);background:rgba(243,154,18,.06)}
.table.ef-tbl .total td:first-child,.table.ef-tbl .grand td:first-child{box-shadow:inset 3px 0 0 var(--orange)}
.table.ef-tbl .grand td{font-size:13.8px;background:rgba(243,154,18,.13);border-top:1px solid var(--orange);font-weight:800;color:var(--orange)}
.table.ef-tbl .corr td{color:var(--muted);font-style:italic}
.table.ef-tbl .repli{font-size:10px;font-weight:800;color:var(--orange);border:1px solid var(--orange);border-radius:99px;padding:0 6px;margin-left:6px;font-style:normal}
.tag{font-size:10px;font-weight:700;padding:1px 7px;border-radius:99px;margin-left:4px}
.tag.pos{background:var(--ok-bg,rgba(57,184,126,.14));color:var(--ok)}.tag.neg{background:var(--danger-bg,rgba(229,103,95,.14));color:var(--danger)}
.ef-eqbar{padding:12px 18px;font-size:13px;font-weight:600;border-top:1px solid var(--line)}
.ef-eqbar.ok{background:rgba(57,184,126,.08);color:var(--ok)}.ef-eqbar.ko{background:rgba(229,103,95,.08);color:var(--danger)}
.ef-foot{margin-top:6px;font-size:12.5px;color:var(--muted);line-height:1.6}
.ef-foot a{color:var(--orange)}
.cc .code{font-size:11px}

/* ── Notes annexes ───────────────────────────────────────────────── */
.note-blk{border-bottom:1px solid var(--line);padding-bottom:10px;margin-bottom:6px}
.note-hd{display:flex;align-items:baseline;gap:10px;padding:12px 18px 6px;flex-wrap:wrap}
.note-num{font-family:Syne,sans-serif;font-weight:800;font-size:11.5px;background:rgba(243,154,18,.12);color:var(--orange);padding:2px 10px;border-radius:99px}
.note-ttl{font-weight:700;font-size:13.5px}
.note-tot{margin-left:auto;font-family:var(--mono);font-size:13px;font-weight:700;font-variant-numeric:tabular-nums}
.note-txt{padding:12px 18px;border-bottom:1px solid var(--line)}
.note-txt.vide{background:rgba(243,154,18,.05);box-shadow:inset 3px 0 0 var(--orange)}
.note-txt label{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap;cursor:pointer}
.note-oblig{font-size:10.5px;font-weight:800;letter-spacing:.4px;color:var(--orange);background:rgba(243,154,18,.14);padding:2px 8px;border-radius:99px}
.note-maj{font-size:11px;color:var(--muted);margin-left:auto}
.note-aide{margin:5px 0 7px;font-size:12px;color:var(--muted)}
.note-prop{color:var(--orange-l,#FFB23E)}
.note-txt textarea{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:9px;font:inherit;font-size:13px;line-height:1.6;resize:vertical;background:var(--bg2);color:var(--text)}
.note-txt textarea:focus,.note-acts input:focus{outline:none;border-color:var(--orange);box-shadow:0 0 0 3px rgba(243,154,18,.18)}
.note-acts{display:flex;align-items:center;gap:12px;padding:12px 18px;flex-wrap:wrap}
.note-acts input{padding:7px 11px;border:1px solid var(--line);border-radius:8px;font:inherit;font-size:13px;background:var(--bg2);color:var(--text);width:200px}
.note-flash{margin:12px 18px 0;padding:9px 14px;border-radius:8px;font-size:12.5px}
.note-flash.ok{background:rgba(57,184,126,.10);color:var(--ok)}.note-flash.ko{background:rgba(229,103,95,.10);color:var(--danger)}
.note-ko{margin:6px 18px 0;padding:8px 12px;border-radius:8px;font-size:12.5px;background:rgba(229,103,95,.10);color:var(--danger)}

/* ── Codes de liasse (Téléliasse) ────────────────────────────────── */
.tl-note{margin:12px 18px;padding:11px 15px;border-radius:9px;font-size:12.5px;line-height:1.6;background:rgba(255,255,255,.02);border-left:3px solid var(--line2)}
.tl-edi{border-left-color:var(--ok);background:rgba(57,184,126,.06)}
.tl .code{font-family:var(--mono)}
.tl-bar{display:flex;gap:12px;align-items:center;padding:0 18px 10px;flex-wrap:wrap}
.tl-bar input[type=search]{flex:1;min-width:220px;padding:8px 12px;border:1px solid var(--line);border-radius:9px;font:inherit;font-size:13px;background:var(--bg2);color:var(--text)}
.tl-chk{display:flex;align-items:center;gap:6px;font-size:12.5px;color:var(--muted);cursor:pointer}
.tl-prog{font-size:12.5px;color:var(--muted);font-family:var(--mono)}
.tl-jauge{height:4px;background:var(--line);margin:0 18px 10px;border-radius:99px;overflow:hidden}
.tl-jauge span{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--ok),#6fd3a4);transition:width .18s ease}
.tl-row.fait{opacity:.45}
.tl-copie{border:1px solid transparent;background:none;font:inherit;font-family:var(--mono);font-size:13px;color:var(--text);cursor:pointer;padding:2px 7px;border-radius:6px;font-variant-numeric:tabular-nums}
.tl-copie:hover{border-color:var(--line2);background:rgba(255,255,255,.04)}
.tl-copie.neg{color:var(--danger)}.tl-copie.copie{color:var(--ok);border-color:var(--ok)}
.tl-texte{font-size:11.5px;color:var(--muted);margin-top:3px;line-height:1.5}

/* ── Tableau des flux ────────────────────────────────────────────── */
.tft-check{margin:10px 18px 12px;padding:9px 14px;border-radius:8px;font-size:12.5px}
.tft-check.ok{background:rgba(57,184,126,.10);color:var(--ok)}.tft-check.ko{background:rgba(229,103,95,.10);color:var(--danger)}

/* ── Adaptatif ───────────────────────────────────────────────────── */
@media(max-width:1100px){.ef-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:1000px){
	.ef-bilan,.sn-bilan{grid-template-columns:1fr}
	.ef-bilan>.ef-scroll:first-child,.sn-bilan>.ef-scroll:first-child{border-right:none;border-bottom:1px solid var(--line)}
	.ef-period{margin-left:0;width:100%}
}
@media(max-width:700px){.ef-entete{grid-template-columns:1fr 1fr}.ef-kpis{grid-template-columns:1fr}.dgi-eq{margin-left:0}}

/* ── Impression (Ctrl+P depuis l'écran) ─────────────────────────── */
@media print{
	.ef-exports,.ef-years,.sys-tabs,.dgi-tabs,.note-acts,.tl-bar,.tl-jauge,form{display:none!important}
	.ef-card,.ef-kpi{box-shadow:none;border-color:#ccc;break-inside:avoid}
	.table.ef-tbl{min-width:0}
}
</style>
