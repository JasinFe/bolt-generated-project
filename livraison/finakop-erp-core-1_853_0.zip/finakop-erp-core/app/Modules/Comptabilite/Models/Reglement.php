<?php
/**
 * Règlements : encaissements (client), paiements (fournisseur), mouvements divers,
 * virements internes. Chaque règlement génère une écriture en partie double.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Reglement {

	/**
	 * Moyens de règlement proposables.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * « MOBILE MONEY » N'EST PLUS UN MOYEN (1.625.0).
	 *
	 * Cette liste proposait « mobile » comme moyen final. Ce n'en est pas
	 * un : c'est une FAMILLE. Personne n'encaisse « du mobile money » — on
	 * encaisse sur Wave, sur Orange Money, sur MTN ou sur Moov, et chacun a
	 * son relevé, ses frais, son délai de reversement et ses litiges. Un
	 * règlement enregistré sous « mobile » ne se rapproche d'aucun relevé :
	 * le jour où un opérateur conteste un montant, l'entreprise sait qu'elle
	 * a encaissé, pas chez qui.
	 *
	 * ON NE REDÉCLARE RIEN. `FKC_MoyenPaiement` porte déjà le référentiel
	 * complet depuis 1.589.0 — les quatre opérateurs ivoiriens, leurs comptes
	 * 552100 à 552400, le générique 552700 pour l'opérateur non identifié, le
	 * chèque en portefeuille sur 513000. Ce module l'ignorait purement et
	 * simplement et tenait sa propre liste à côté. Deux listes finissent
	 * toujours par diverger ; on supprime la seconde.
	 *
	 * LA LECTURE DE L'HISTORIQUE N'EST PAS TOUCHÉE : `FKC_MoyenPaiement`
	 * résout déjà « mobile » vers le générique, ce qui laisse les milliers de
	 * lignes déjà en base parfaitement lisibles. On resserre l'entrée, on ne
	 * réécrit pas le passé.
	 *
	 * @return array code => libellé
	 */
	public static function modes() {
		if ( ! class_exists( 'FKC_MoyenPaiement' ) ) {
			// Repli minimal, sans « mobile » : mieux vaut une liste courte
			// qu'une catégorie qu'on ne saura pas rapprocher.
			return array( 'espece' => 'Espèces', 'cheque' => 'Chèque', 'virement' => 'Virement', 'carte' => 'Carte' );
		}
		$out = array();
		foreach ( FKC_MoyenPaiement::tous() as $code => $d ) {
			$out[ $code ] = $d['label'];
		}
		return $out;
	}

	/**
	 * Libellé d'un moyen, HISTORIQUE COMPRIS.
	 *
	 * Les écrans lisaient `modes()[ $r['mode'] ]`. Retirer « mobile » de
	 * cette liste aurait donc affiché le code brut sur tous les règlements
	 * déjà en base — une régression d'affichage causée par un resserrement
	 * de saisie, ce qui est le contraire du but. `FKC_MoyenPaiement` sait
	 * nommer les codes hérités ; on lui demande.
	 */
	public static function labelMode( $mode ) {
		$mode = (string) $mode;
		if ( '' === $mode ) { return '—'; }
		if ( class_exists( 'FKC_MoyenPaiement' ) ) { return FKC_MoyenPaiement::label( $mode ); }
		return self::modes()[ $mode ] ?? $mode;
	}

	/**
	 * Valide le moyen d'un NOUVEAU règlement.
	 *
	 * Le refus porte sur ce qui s'enregistre aujourd'hui, jamais sur ce qui
	 * l'a été hier : une donnée en base ne devient pas illégale parce que la
	 * règle s'est précisée.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function validerMode( $mode ) {
		$mode = trim( (string) $mode );
		if ( '' === $mode ) { return array( true, '' ); } // moyen facultatif : un virement interne n'en a pas.
		if ( ! class_exists( 'FKC_MoyenPaiement' ) ) { return array( true, '' ); }
		$code = FKC_MoyenPaiement::normaliser( $mode );
		if ( '' === $code ) {
			return array( false, 'Moyen de paiement inconnu : « ' . $mode . ' ».' );
		}
		if ( 'mobile_money' === $code ) {
			$ops = array();
			foreach ( FKC_MoyenPaiement::tous() as $c => $d ) {
				if ( 'mobile' === $d['nature'] ) { $ops[] = $d['label']; }
			}
			return array( false, '« Mobile Money » est une famille, pas un moyen de paiement : un relevé se '
				. 'rapproche par opérateur, jamais par catégorie. Précisez : ' . implode( ', ', $ops ) . '.' );
		}
		return array( true, '' );
	}

	/**
	 * Règlements enregistrés sous une famille au lieu d'un opérateur.
	 *
	 * CE CONTRÔLE N'A PAS DE PASTILLE D'ALERTE, ET C'EST VOULU. Il compte un
	 * ARRIÉRÉ : des lignes saisies avant que la règle ne se précise, qui ne
	 * descendront que si quelqu'un reprend l'historique. Un chiffre rouge
	 * permanent sur une donnée ancienne n'apprend qu'une chose — l'ignorer.
	 * C'est de l'information, pas une anomalie du jour.
	 *
	 * Le sous-total « récents » est le seul réellement actionnable : au-delà
	 * de quelques semaines, la référence de transaction n'est plus
	 * retrouvable chez l'opérateur, et préciser l'opérateur à froid
	 * reviendrait à deviner.
	 *
	 * @return array{total:int,montant:float,recents:int,par_mode:array}
	 */
	public static function sansOperateur( $joursRecents = 45 ) {
		$out = array( 'total' => 0, 'montant' => 0.0, 'recents' => 0, 'par_mode' => array() );
		$codes = array( 'mobile', 'mobile_money', 'momo_generique' );
		$place = implode( ',', array_fill( 0, count( $codes ), '?' ) );
		try {
			$r = FKC_DB::q(
				'SELECT COUNT(*) AS n, COALESCE(SUM(montant),0) AS m FROM reglements WHERE mode IN (' . $place . ')',
				$codes
			)->fetch();
			$out['total']   = (int) $r['n'];
			$out['montant'] = (float) $r['m'];
			$out['par_mode'] = FKC_DB::q(
				'SELECT mode, COUNT(*) AS n, COALESCE(SUM(montant),0) AS total FROM reglements
				 WHERE mode IN (' . $place . ') GROUP BY mode ORDER BY n DESC',
				$codes
			)->fetchAll();
			$out['recents'] = (int) FKC_DB::q(
				'SELECT COUNT(*) FROM reglements WHERE mode IN (' . $place . ') AND date_reglement >= ?',
				array_merge( $codes, array( date( 'Y-m-d', time() - max( 1, (int) $joursRecents ) * 86400 ) ) )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return $out; }
		return $out;
	}

	public static function all( $tresId = null, $limit = 200 ) {
		$limit = (int) $limit;
		if ( $tresId ) {
			return FKC_DB::q( "SELECT * FROM reglements WHERE tresorerie_id=? OR tresorerie_dest_id=? ORDER BY date_reglement DESC, id DESC LIMIT {$limit}", array( (int) $tresId, (int) $tresId ) )->fetchAll();
		}
		return FKC_DB::q( "SELECT * FROM reglements ORDER BY date_reglement DESC, id DESC LIMIT {$limit}" )->fetchAll();
	}

	protected static function journalFor( $type ) {
		$code = ( 'caisse' === $type ) ? 'CA' : 'BQ';
		foreach ( FKC_Journal::all() as $j ) { if ( $code === $j['code'] ) { return (int) $j['id']; } }
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		return 0;
	}

	/**
	 * Enregistre un règlement + son écriture.
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null id )
	 */
	/**
	 * Imputation analytique d'une ligne de contrepartie.
	 *
	 * Une ligne de détail peut porter SA propre division : un même
	 * décaissement règle parfois deux natures relevant de deux divisions.
	 * À défaut, celle du mouvement s'applique — sans quoi il faudrait la
	 * ressaisir sur chaque ligne pour le cas courant, qui est l'uniformité.
	 */
	protected static function analytiqueLigne( array $c, array $ana ) {
		$out = $ana;
		if ( ! empty( $c['division_id'] ) ) { $out['division_id'] = (int) $c['division_id']; }
		return $out;
	}

	public static function create( $d ) {
		$sens    = $d['sens'];
		$montant = round( (float) $d['montant'], 2 );
		// Le montant peut n'être porté que par le détail (1.754.0) : on ne le
		// refuse qu'une fois le détail connu, quelques lignes plus bas.
		$avecDetail = ! empty( $d['detail'] ) && is_array( $d['detail'] );
		if ( $montant <= 0 && ! $avecDetail ) { return array( false, 'Le montant doit être positif.', null ); }
		$tres = FKC_Tresorerie::find( (int) $d['tresorerie_id'] );
		if ( ! $tres ) { return array( false, 'Compte de trésorerie introuvable.', null ); }
		$date = ( $d['date_reglement'] ?? '' ) ?: date( 'Y-m-d' );

		/*
		 * MOYEN DE PAIEMENT PRÉCIS (1.625.0). On refuse une famille, et on
		 * normalise le reste : « orange », « OM », « Orange Money » et
		 * « orange_money » désignent le même opérateur et doivent s'écrire
		 * pareil en base, sans quoi aucun regroupement ne tiendra.
		 */
		list( $modeOk, $modeMsg ) = self::validerMode( $d['mode'] ?? '' );
		if ( ! $modeOk ) { return array( false, $modeMsg, null ); }
		if ( ! empty( $d['mode'] ) && class_exists( 'FKC_MoyenPaiement' ) ) {
			$norm = FKC_MoyenPaiement::normaliser( (string) $d['mode'] );
			if ( '' !== $norm ) { $d['mode'] = $norm; }
		}

		/*
		 * RÉPARTITION PAR FACTURE — CONTRÔLÉE AVANT TOUTE ÉCRITURE.
		 *
		 * `imputations` (facture_id => montant) dit sur quelles factures
		 * l'encaissement s'impute. Elle est FACULTATIVE : sans elle, le
		 * lettrage FIFO continue de s'appliquer comme avant, et les appelants
		 * existants (caisse, packs métier, imports) ne changent pas d'un
		 * caractère.
		 *
		 * Le contrôle est ici et pas dans l'écran : un import ou un futur
		 * appelant doit buter sur la même règle. On refuse une répartition
		 * qui dépasse la somme reçue — sinon on éteindrait au poste client
		 * plus de créance que d'argent entré, et la différence ne se verrait
		 * nulle part.
		 */
		$imputations = array();
		if ( ! empty( $d['imputations'] ) && is_array( $d['imputations'] ) ) {
			$sommeImp = 0.0;
			foreach ( $d['imputations'] as $fid => $m ) {
				$fid = (int) $fid; $m = round( (float) $m, 2 );
				if ( $fid <= 0 || $m <= 0 ) { continue; }
				$imputations[ $fid ] = ( $imputations[ $fid ] ?? 0.0 ) + $m;
				$sommeImp += $m;
			}
			if ( $sommeImp > $montant + 0.005 ) {
				return array( false, sprintf(
					'La répartition par facture (%s F) dépasse le montant encaissé (%s F).',
					fkc_money( $sommeImp ), fkc_money( $montant )
				), null );
			}
		}

		/*
		 * VENTILATION PAR LIGNE DE DÉTAIL (1.754.0).
		 *
		 * `detail` (désignation, montant, contrepartie facultative) décrit ce
		 * que le mouvement contient réellement. Elle est FACULTATIVE : sans
		 * elle, le mouvement reste d'un seul tenant et les appelants existants
		 * ne changent pas d'un caractère.
		 *
		 * Elle n'a de sens que sur un encaissement ou un décaissement LIBRE :
		 * sur un virement interne, les deux côtés sont des comptes de
		 * trésorerie ; sur un règlement de tiers, la contrepartie est le compte
		 * du client ou du fournisseur, et la ventiler ailleurs laisserait son
		 * solde auxiliaire faux. Le détail y est donc REFUSÉ, pas ignoré : une
		 * saisie silencieusement perdue est pire qu'une saisie refusée.
		 */
		$detail = array(); $detailTotal = 0.0;
		if ( ! empty( $d['detail'] ) && is_array( $d['detail'] ) && class_exists( 'FKC_ReglementDetail' ) ) {
			$contrepartieDefaut = (int) ( $d['contrepartie_compte_id'] ?? 0 );
			list( $detail, $detailTotal, $errDetail ) = FKC_ReglementDetail::preparer( $d['detail'], $contrepartieDefaut );
			if ( $errDetail ) { return array( false, $errDetail, null ); }
			if ( $detail ) {
				if ( 'virement' === $sens ) {
					return array( false, 'Un virement interne ne se ventile pas : les deux côtés sont des comptes de trésorerie.', null );
				}
				if ( 'autre' !== ( $d['tiers_type'] ?? 'autre' ) ) {
					return array( false, 'Le détail par ligne ne s\'applique pas à un règlement de tiers : sa contrepartie est le compte du client ou du fournisseur. Utilisez la répartition par facture.', null );
				}
				// Le montant saisi et la somme des lignes doivent coïncider —
				// sinon l'écriture serait déséquilibrée, ou le détail mentirait.
				if ( $montant > 0 && abs( $montant - $detailTotal ) > 0.005 ) {
					return array( false, sprintf(
						'Le détail (%s F) ne correspond pas au montant du mouvement (%s F).',
						fkc_money( $detailTotal ), fkc_money( $montant )
					), null );
				}
				$montant = $detailTotal;
			}
		}

		if ( $montant <= 0 ) { return array( false, 'Le montant doit être positif.', null ); }

		// Résolution de la contrepartie + libellé + lignes d'écriture.
		$lignes = array(); $tiers_type = 'autre'; $tiers_id = null; $tiers_nom = null;
		$tres_dest_id = null;

		if ( 'virement' === $sens ) {
			$dest = FKC_Tresorerie::find( (int) ( $d['tresorerie_dest_id'] ?? 0 ) );
			if ( ! $dest ) { return array( false, 'Compte de destination introuvable.', null ); }
			if ( $dest['id'] === $tres['id'] ) { return array( false, 'Les deux comptes doivent être différents.', null ); }
			$tres_dest_id = $dest['id'];
			$lib = 'Virement ' . $tres['libelle'] . ' → ' . $dest['libelle'];
			$lignes[] = array( 'compte_id' => $dest['compte_id'], 'libelle' => $lib, 'debit' => $montant, 'credit' => 0 );
			$lignes[] = array( 'compte_id' => $tres['compte_id'], 'libelle' => $lib, 'debit' => 0, 'credit' => $montant );
		} else {
			// Contrepartie
			$contrepartieId = null;
			if ( 'client' === ( $d['tiers_type'] ?? '' ) ) {
				$tiers_type = 'client'; $tiers_id = (int) $d['tiers_id'];
				$cli = FKC_Client::find( $tiers_id );
				$tiers_nom = $cli ? $cli['nom'] : 'Client';
				// Compte de tiers du client — 411100, ou son compte auxiliaire
				// s'il en a un, exactement comme pour un fournisseur deux
				// lignes plus bas. « 411 » résolvait 411000, le compte
				// principal, sur lequel on n'impute pas : le règlement
				// atterrissait donc ailleurs que la facture qu'il soldait.
				$cp = FKC_Compte::byNumero( ( $cli && ! empty( $cli['compte'] ) ) ? $cli['compte'] : FKC_PlanMetier::COMPTE_CLIENT );
				$contrepartieId = $cp ? $cp['id'] : null;
			} elseif ( 'fournisseur' === ( $d['tiers_type'] ?? '' ) ) {
				$tiers_type = 'fournisseur'; $tiers_id = (int) $d['tiers_id'];
				$frn = FKC_Fournisseur::find( $tiers_id );
				$tiers_nom = $frn ? $frn['nom'] : 'Fournisseur';
				$cp = FKC_Compte::byNumero( $frn ? $frn['compte'] : '401' );
				$contrepartieId = $cp ? $cp['id'] : null;

				// GARDE-FOU — on ne règle pas un fournisseur sur un bon de
				// livraison. Si la somme dépasse ce qui est réellement facturé
				// ALORS QUE des réceptions attendent leur facture, le paiement
				// est refusé : sinon le 401 serait débité pendant que la dette
				// reste logée en 408, et les deux comptes divergeraient sans
				// que personne ne s'en aperçoive. Un acompte sur un fournisseur
				// sans réception en attente reste possible.
				if ( 'paiement' === $sens && $tiers_id && class_exists( 'FKC_AchatReception' ) ) {
					$att = FKC_AchatReception::montantEnAttente( $tiers_id );
					if ( $att > 0 ) {
						$exigible = self::soldeFournisseur( $tiers_id )['exigible'];
						if ( $montant > $exigible + 0.005 ) {
							return array( false, sprintf(
								'Montant supérieur au facturé. %s F sont exigibles ; %s F de marchandises reçues attendent leur facture fournisseur. Saisissez la facture avant de régler.',
								fkc_money( max( 0, $exigible ) ), fkc_money( $att )
							), null );
						}
					}
				}
			} else {
				$contrepartieId = (int) ( $d['contrepartie_compte_id'] ?? 0 ) ?: null;
			}
			if ( ! $contrepartieId ) { return array( false, 'Contrepartie comptable manquante.', null ); }

			$lib = ( $d['libelle'] ?? '' ) ?: ( ( 'encaissement' === $sens ? 'Encaissement ' : 'Paiement ' ) . ( $tiers_nom ?: '' ) );
			// La ligne de contrepartie porte le tiers : c'est elle qui apure le
			// solde auxiliaire ouvert par la facture ou la reception.
			$aux = ( 'autre' !== $tiers_type && $tiers_id )
				? array( 'tiers_type' => $tiers_type, 'tiers_id' => (int) $tiers_id )
				: array();
			/*
			 * ─────────────────────────────────────────────────────────────
			 * LE COMPTE DÉSIGNÉ PRIME SUR LE MOYEN, ET C'EST DÉFINITIF.
			 *
			 * La recette de bout en bout (1.668.0) a signalé que le terminal
			 * de vente route son écriture sur le MOYEN — un ticket Wave
			 * débite 552100 — tandis que ce module emploie le compte de la
			 * trésorerie choisie. J'ai voulu aligner les deux en 1.669.0.
			 * C'ÉTAIT UNE ERREUR, et deux harnais du pack Artiste l'ont dit
			 * avant qu'elle ne sorte.
			 *
			 * Les deux cas ne sont pas comparables. Au terminal, AUCUN compte
			 * n'est désigné : le schéma porte un repli générique, et router
			 * sur le moyen est un gain net. Ici, l'utilisateur a CHOISI son
			 * compte de trésorerie — sa banque, sa caisse, celle de tel
			 * établissement. Un moyen ne peut pas contredire ce choix :
			 * « banque » comme synonyme de virement pointe sur 521100, et
			 * dévierait l'écriture d'une société qui tient sa banque sur un
			 * autre compte. On effacerait une décision explicite au nom d'une
			 * cohérence de façade.
			 *
			 * L'incohérence entre les deux moteurs est donc APPARENTE : ils
			 * répondent à deux questions différentes. La recette la signale
			 * en avertissement, ce qui est le bon niveau — c'est une chose à
			 * savoir, pas une chose à corriger.
			 */
			/*
			 * Un seul mouvement de trésorerie en face, autant de lignes de
			 * contrepartie que le détail en compte (1.754.0). Chaque ligne
			 * porte SA désignation : c'est elle qu'on relira au grand livre,
			 * pas le libellé général du mouvement.
			 */
			$contreparties = $detail
				? $detail
				: array( array( 'designation' => $lib, 'compte_id' => $contrepartieId, 'montant' => $montant ) );

			/*
			 * ═══════════════════════════════════════════════════════════
			 *  IMPUTATION ANALYTIQUE (1.758.0)
			 * ═══════════════════════════════════════════════════════════
			 *  Un mouvement de trésorerie saisi à la main échappait à toute
			 *  analytique : ni division, ni axe, ni valeur. Or c'est par lui
			 *  que passent le loyer, les frais de mission, les achats réglés
			 *  comptant — des charges qui pèsent lourd dans le résultat d'une
			 *  division et qui n'y apparaissaient jamais. Le résultat
			 *  analytique était donc structurellement incomplet, sans que
			 *  rien à l'écran ne le laisse deviner.
			 *
			 *  L'imputation ne porte QUE sur les lignes de contrepartie — la
			 *  charge ou le produit. La ligne de trésorerie elle-même n'a pas
			 *  d'existence analytique : une sortie de caisse n'appartient à
			 *  aucune division, c'est ce qu'on achète avec qui lui appartient.
			 *
			 *  Une valeur n'est retenue que si un axe l'est : seule, elle ne
			 *  désigne rien.
			 */
			$ana = array();
			if ( ! empty( $d['division_id'] ) ) { $ana['division_id'] = (int) $d['division_id']; }
			if ( ! empty( $d['axe_id'] ) && ! empty( $d['valeur_id'] ) ) {
				$ana['affectations'] = array( (int) $d['axe_id'] => (int) $d['valeur_id'] );
			}
			if ( 'encaissement' === $sens ) {
				$lignes[] = array( 'compte_id' => $tres['compte_id'], 'libelle' => $lib, 'debit' => $montant, 'credit' => 0 );
				foreach ( $contreparties as $c ) {
					$lignes[] = array( 'compte_id' => (int) $c['compte_id'], 'libelle' => (string) $c['designation'], 'debit' => 0, 'credit' => (float) $c['montant'] ) + self::analytiqueLigne( $c, $ana ) + $aux;
				}
			} else { // paiement
				foreach ( $contreparties as $c ) {
					$lignes[] = array( 'compte_id' => (int) $c['compte_id'], 'libelle' => (string) $c['designation'], 'debit' => (float) $c['montant'], 'credit' => 0 ) + self::analytiqueLigne( $c, $ana ) + $aux;
				}
				$lignes[] = array( 'compte_id' => $tres['compte_id'], 'libelle' => $lib, 'debit' => 0, 'credit' => $montant );
			}
		}

		// Insère d'abord le règlement (sans écriture), pour disposer de son identifiant.
		try {
			FKC_DB::q(
				'INSERT INTO reglements(sens,tiers_type,tiers_id,tiers_nom,tresorerie_id,tresorerie_dest_id,date_reglement,montant,mode,reference,libelle,contrepartie_compte_id,ecriture_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
				array( $sens, $tiers_type, $tiers_id, $tiers_nom, $tres['id'], $tres_dest_id, $date, $montant, $d['mode'] ?? null, $d['reference'] ?? null, $lib, $lignes[0]['compte_id'] === $tres['compte_id'] ? ( $lignes[1]['compte_id'] ?? null ) : $lignes[0]['compte_id'], null )
			);
			$rid = (int) FKC_DB::conn()->lastInsertId();
		} catch ( Throwable $e ) {
			fkc_log( 'Reglement::create ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de l\'enregistrement.', null );
		}

		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer(
			array(
				'journal_id' => self::journalFor( $tres['type'] ), 'date_ecriture' => $date,
				'libelle' => $lib, 'piece' => ( $d['reference'] ?? '' ) ?: null, 'created_by' => FKC_Auth::id(),
			),
			$lignes,
			array( 'source' => 'reglement', 'lien' => array( 'table' => 'reglements', 'colonne' => 'ecriture_id', 'ids' => array( $rid ) ) )
		);
		if ( ! $ok ) {
			FKC_DB::q( 'DELETE FROM reglements WHERE id=?', array( $rid ) );
			return array( false, $msg, null );
		}
		/*
		 * L'IMPUTATION EST ENREGISTRÉE APRÈS L'ÉCRITURE, JAMAIS AVANT.
		 *
		 * Si l'écriture est refusée, le règlement est supprimé quelques
		 * lignes plus haut : une imputation posée avant aurait survécu à un
		 * règlement qui n'existe plus, et aurait éteint une créance sans
		 * qu'aucun argent ne soit entré.
		 *
		 * Son échec, lui, n'annule rien : l'encaissement est réel et
		 * comptabilisé. Il se lettrera en FIFO, comme avant ce correctif.
		 */
		// Le détail suit l'écriture, jamais l'inverse : si elle est refusée, le
		// règlement est supprimé plus haut, et des lignes orphelines seraient
		// restées derrière lui.
		if ( $detail && class_exists( 'FKC_ReglementDetail' ) ) {
			FKC_ReglementDetail::enregistrer( $rid, $detail );
		}

		if ( $imputations && class_exists( 'FKC_Imputation' )
			&& ( ( 'encaissement' === $sens && 'client' === $tiers_type )
				|| ( 'paiement' === $sens && 'fournisseur' === $tiers_type ) ) ) {
			// Le type suit le tiers : sans lui, un paiement fournisseur
			// éteindrait la facture CLIENT portant le même identifiant.
			list( $impOk, $impMsg ) = FKC_Imputation::enregistrer( $rid, $imputations, $tiers_type );
			if ( ! $impOk && $impMsg ) { fkc_log( 'Reglement::create imputation — ' . $impMsg, 'WARN' ); }
		}

		/*
		 * CRÉANCES DOUTEUSES (1.792.0). Une facture reclassée en 416 et
		 * dépréciée n'est plus au compte client : l'encaissement qui la vise
		 * doit diminuer la créance douteuse et reprendre la provision devenue
		 * sans objet. Sans répartition par facture, le rattachement se fait
		 * depuis la fiche de dépréciation, qui détecte l'encaissement.
		 */
		if ( $imputations && 'encaissement' === $sens && 'client' === $tiers_type && class_exists( 'FKC_Depreciation' ) ) {
			foreach ( $imputations as $fid => $m ) {
				list( $okD, $msgD ) = FKC_Depreciation::constaterEncaissement( (int) $fid, (float) $m, $date, $rid );
				if ( ! $okD ) { fkc_log( 'Reglement::create — créance douteuse facture #' . (int) $fid . ' : ' . $msgD, 'WARN' ); }
			}
		}

		// Pont vers le bus d'événements : le recouvrement (DSO, relances), la
		// trésorerie prévisionnelle et les packs réagissent au règlement.
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'reglement_enregistre', array(
				'reglement_id' => $rid, 'sens' => (string) $sens,
				'tiers_type' => (string) $tiers_type, 'tiers_id' => $tiers_id ? (int) $tiers_id : null,
				'tiers' => (string) ( $tiers_nom ?? '' ), 'montant' => $montant,
				'date' => $date, 'mode' => (string) ( $d['mode'] ?? '' ),
				'tresorerie_id' => (int) $tres['id'],
				'ecriture_id' => $eid ? (int) $eid : null, 'brouillon_id' => $bid ? (int) $bid : null,
			), array( 'poster' => false ) );
		}
		// Le poste client vient de bouger : l'instantané mémorisé par le moteur
		// de recouvrement pour cette requête ne vaut plus.
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }
		if ( $bid ) {
			return array( true, 'Règlement enregistré — écriture déposée au brouillard (à vérifier avant comptabilisation).', $rid );
		}
		return array( true, 'Règlement enregistré (écriture n°' . $eid . ').', $rid );
	}

	public static function togglePointe( $id ) {
		// Un règlement annulé ne se pointe pas : la banque ne peut pas avoir
		// confirmé un mouvement qui n'a pas eu lieu.
		FKC_DB::q( "UPDATE reglements SET pointe = CASE pointe WHEN 1 THEN 0 ELSE 1 END WHERE id=? AND (COALESCE(statut,'actif')<>'annule' OR pointe=1)", array( (int) $id ) );
	}

	/** Règlements d'un tiers, les plus récents d'abord (annulés compris, pour l'histoire). */
	public static function duTiers( $type, $tiersId, $limit = 20 ) {
		$type = 'fournisseur' === $type ? 'fournisseur' : 'client';
		$sens = 'fournisseur' === $type ? 'paiement' : 'encaissement';
		try {
			$rows = FKC_DB::q(
				'SELECT * FROM reglements WHERE tiers_type=? AND tiers_id=? AND sens=? ORDER BY date_reglement DESC, id DESC LIMIT ' . max( 1, (int) $limit ),
				array( $type, (int) $tiersId, $sens )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		foreach ( $rows as $k => $r ) { $rows[ $k ]['factures'] = self::facturesSoldees( (int) $r['id'] ); }
		return $rows;
	}

	/** État lisible d'un règlement : annule | au_journal | comptabilise | sans_ecriture. */
	public static function etat( array $r ) {
		if ( self::estAnnule( $r ) ) { return 'annule'; }
		if ( ! empty( $r['ecriture_id'] ) ) { return 'comptabilise'; }
		if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'reglements', (int) $r['id'] ) ) { return 'au_journal'; }
		return 'sans_ecriture';
	}

	/** Un règlement est-il annulé ? */
	public static function estAnnule( $r ) {
		return is_array( $r ) && 'annule' === (string) ( $r['statut'] ?? '' );
	}

	/**
	 * ANNULER UN RÈGLEMENT (1.745.0).
	 *
	 * « Ce paiement n'a pas eu lieu » — chèque impayé, virement rejeté,
	 * saisie en double. Le module n'offrait aucun geste pour le dire : il
	 * fallait contre-passer l'écriture à la main, et même alors la facture
	 * restait « payée », parce que le règlement, lui, continuait d'exister et
	 * de compter.
	 *
	 * Selon l'état de l'écriture :
	 *   • au grand livre → contre-passation (qui suit la politique de
	 *     comptabilisation : elle peut attendre au journal temporaire) ; le
	 *     règlement passe « annulé » par la même opération ;
	 *   • encore au journal temporaire → le brouillon est retiré (il n'a rien
	 *     touché, il n'y a rien à contre-passer) ;
	 *   • sans écriture → le règlement est simplement annulé.
	 *
	 * Dans tous les cas la facture se rouvre : l'imputation est conservée
	 * pour l'histoire, mais un règlement annulé n'éteint plus rien.
	 *
	 * REFUSÉ si le règlement a été pointé au rapprochement bancaire : la
	 * banque a confirmé ce mouvement ; on dépointe d'abord, en connaissance
	 * de cause.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function annuler( $id, $motif = '', $date = null ) {
		$r = FKC_DB::q( 'SELECT * FROM reglements WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return array( false, 'Règlement introuvable.' ); }
		if ( self::estAnnule( $r ) ) { return array( false, 'Ce règlement est déjà annulé.' ); }
		if ( ! empty( $r['pointe'] ) ) {
			return array( false, 'Ce règlement a été pointé au rapprochement bancaire : la banque l\'a confirmé. Dépointez-le d\'abord si le relevé a changé.' );
		}
		$motif = trim( (string) $motif );
		$factures = self::facturesSoldees( (int) $id );

		if ( ! empty( $r['ecriture_id'] ) ) {
			list( $ok, $msg ) = FKC_EcritureAnnulation::contrepasser( (int) $r['ecriture_id'], $date );
			if ( ! $ok ) { return array( false, 'Annulation refusée : ' . $msg ); }
			// La contre-passation a annulé le règlement ; on complète le motif.
			FKC_DB::q( "UPDATE reglements SET statut='annule', annule_at=COALESCE(annule_at, datetime('now','localtime')), annule_motif=? WHERE id=?",
				array( '' !== $motif ? $motif : 'Écriture n°' . (int) $r['ecriture_id'] . ' contre-passée', (int) $id ) );
			$quoi = $msg;
		} else {
			$retires = 0;
			if ( class_exists( 'FKC_Brouillard' ) ) {
				foreach ( FKC_Brouillard::pendingFor( 'reglements', (int) $id ) as $bid ) {
					FKC_Brouillard::delete( (int) $bid );
					$retires++;
				}
			}
			FKC_DB::q( "UPDATE reglements SET statut='annule', annule_at=datetime('now','localtime'), annule_motif=? WHERE id=?",
				array( '' !== $motif ? $motif : 'Annulé avant comptabilisation', (int) $id ) );
			$quoi = $retires ? 'Son écriture attendait au journal temporaire : elle en a été retirée.' : 'Il n\'avait pas d\'écriture.';
		}
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'reglement_annule', 'Règlement #' . (int) $id . ' (' . fkc_money( $r['montant'] ) . ' F, ' . (string) $r['tiers_nom'] . ')'
				. ( '' !== $motif ? ' — ' . $motif : '' ) );
		}
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'reglement_annule', array(
				'reglement_id' => (int) $id, 'sens' => (string) $r['sens'],
				'tiers_type' => (string) $r['tiers_type'], 'tiers_id' => $r['tiers_id'] ? (int) $r['tiers_id'] : null,
				'montant' => (float) $r['montant'], 'motif' => $motif,
			), array( 'poster' => false ) );
		}
		$rouvertes = $factures ? ' Facture(s) rouverte(s) : ' . implode( ', ', $factures ) . '.' : '';
		$quel = 'client' === $r['tiers_type'] ? 'La créance' : ( 'fournisseur' === $r['tiers_type'] ? 'La dette' : 'Le mouvement' );
		return array( true, 'Règlement annulé. ' . $quel . ' est repositionné' . ( 'Le mouvement' === $quel ? '' : 'e' ) . '. ' . $quoi . $rouvertes );
	}

	/** Numéros des factures que ce règlement soldait nommément. */
	public static function facturesSoldees( $reglementId ) {
		$out = array();
		try {
			$rows = FKC_DB::q(
				"SELECT i.facture_id, COALESCE(i.type,'client') type FROM reglement_imputations i WHERE i.reglement_id=?",
				array( (int) $reglementId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( $rows as $i ) {
			$t = 'fournisseur' === $i['type'] ? 'factures_fournisseurs' : 'factures';
			try {
				$n = FKC_DB::q( "SELECT numero FROM {$t} WHERE id=?", array( (int) $i['facture_id'] ) )->fetchColumn();
				if ( $n ) { $out[] = (string) $n; }
			} catch ( \Throwable $e ) {}
		}
		return $out;
	}
	/**
	 * Mouvements que la banque n'a jamais confirmés, passé un délai.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UN ÉCART DE RAPPROCHEMENT EST NORMAL ; UN ÉCART QUI DURE NE L'EST PAS
	 *
	 * Le solde comptable et le solde pointé diffèrent tout le temps, et c'est
	 * sain : un chèque remis met quelques jours à être encaissé, un virement
	 * émis en fin de journée passe le lendemain. Compter tous les
	 * non-pointés serait donc un compteur allumé en permanence, qu'on
	 * apprendrait à ignorer — l'erreur que `fiscalite_1557` a servi à ne plus
	 * commettre.
	 *
	 * PASSÉ SOIXANTE JOURS, LA LECTURE CHANGE. Un chèque que la banque n'a
	 * pas encaissé après deux mois n'est plus en route : il est égaré, sans
	 * provision, ou la remise n'a jamais été faite. Le solde comptable
	 * annonce alors un argent que l'entreprise n'a pas, et elle engage des
	 * dépenses dessus.
	 *
	 * ON NE JUGE PAS DE LA CAUSE. Le contrôle nomme le mouvement, son
	 * ancienneté et son moyen ; c'est au comptable de dire si le chèque est
	 * perdu, impayé, ou simplement jamais remis. Trois issues, dont aucune
	 * ne relève du logiciel.
	 *
	 * @param int $jours Ancienneté au-delà de laquelle l'attente devient anormale.
	 * @return array
	 */
	public static function nonPointesAnciens( $jours = 60, $limit = 50 ) {
		$limit = max( 1, min( 200, (int) $limit ) );
		$avant = date( 'Y-m-d', time() - max( 1, (int) $jours ) * 86400 );
		try {
			return FKC_DB::q(
				"SELECT r.id, r.sens, r.date_reglement, r.montant, r.mode, r.reference,
				        r.libelle, r.tiers_nom, t.libelle AS tresorerie
				 FROM reglements r
				 LEFT JOIN tresorerie_comptes t ON t.id = r.tresorerie_id
				 WHERE COALESCE(r.pointe,0) = 0 AND r.date_reglement <= ? AND COALESCE(r.statut,'actif')<>'annule'
				 ORDER BY r.date_reglement ASC LIMIT " . $limit,
				array( $avant )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/**
	 * Écart de rapprochement d'un compte, et sa part ancienne.
	 *
	 * L'écart TOTAL est une information — il vit et se résorbe. Ce qui doit
	 * alerter, c'est la part qui ne bouge plus. Rendre les deux permet de
	 * dire « 800 000 en attente, dont 200 000 depuis plus de deux mois », ce
	 * qui est une phrase actionnable là où un seul chiffre ne l'est pas.
	 *
	 * @return array{comptable:float,pointe:float,ecart:float,ancien:float,nb_anciens:int}
	 */
	public static function ecartRapprochement( $tresId, $jours = 60 ) {
		$t = class_exists( 'FKC_Tresorerie' ) ? FKC_Tresorerie::find( $tresId ) : null;
		$comptable = ( $t && class_exists( 'FKC_Tresorerie' ) ) ? (float) FKC_Tresorerie::solde( (int) $t['compte_id'] ) : 0.0;
		$pointe    = self::soldePointe( $tresId );
		$avant     = date( 'Y-m-d', time() - max( 1, (int) $jours ) * 86400 );
		$ancien    = 0.0; $nb = 0;
		try {
			$rows = FKC_DB::q(
				"SELECT sens, montant, tresorerie_id, tresorerie_dest_id FROM reglements
				 WHERE COALESCE(pointe,0)=0 AND date_reglement <= ? AND COALESCE(statut,'actif')<>'annule'
				   AND (tresorerie_id=? OR tresorerie_dest_id=?)",
				array( $avant, (int) $tresId, (int) $tresId )
			)->fetchAll();
			foreach ( $rows as $r ) {
				// Même règle de signe que soldePointe() : un virement compte
				// selon le sens dans lequel il traverse CE compte.
				if ( 'virement' === $r['sens'] ) {
					$ancien += ( (int) $r['tresorerie_dest_id'] === (int) $tresId ) ? (float) $r['montant'] : -(float) $r['montant'];
				} elseif ( 'encaissement' === $r['sens'] ) { $ancien += (float) $r['montant']; }
				else { $ancien -= (float) $r['montant']; }
				$nb++;
			}
		} catch ( \Throwable $e ) { /* compte illisible : écart non chiffré */ }
		return array(
			'comptable'  => round( $comptable, 2 ),
			'pointe'     => round( $pointe, 2 ),
			'ecart'      => round( $comptable - $pointe, 2 ),
			'ancien'     => round( $ancien, 2 ),
			'nb_anciens' => $nb,
		);
	}

	public static function soldePointe( $tresId ) {
		$rows = FKC_DB::q( 'SELECT sens,montant,tresorerie_id,tresorerie_dest_id FROM reglements WHERE pointe=1 AND (tresorerie_id=? OR tresorerie_dest_id=?)', array( (int) $tresId, (int) $tresId ) )->fetchAll();
		$s = 0;
		foreach ( $rows as $r ) {
			if ( 'virement' === $r['sens'] ) { $s += ( (int) $r['tresorerie_dest_id'] === (int) $tresId ) ? $r['montant'] : -$r['montant']; }
			elseif ( 'encaissement' === $r['sens'] ) { $s += $r['montant']; }
			else { $s -= $r['montant']; }
		}
		return (float) $s;
	}

	/**
	 * Solde client = facturé (émis, non annulé) − encaissé.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * DEUX CORRECTIONS DE PÉRIMÈTRE (1.731.0), ET POURQUOI ELLES COMPTENT
	 *
	 * 1. LES BROUILLONS ÉTAIENT COMPTÉS COMME DES CRÉANCES. Le filtre
	 *    écartait les annulées, rien d'autre : un devis enregistré, une
	 *    facture en préparation, une proforma gonflaient le « total créances
	 *    clients » affiché en tête d'écran. On relançait un client sur un
	 *    document qu'il n'avait jamais reçu. Le moteur de recouvrement, lui,
	 *    appliquait déjà le bon filtre — d'où deux totaux différents pour le
	 *    même poste client selon l'écran ouvert.
	 *
	 * 2. LES REÇUS N'ÉTAIENT PAS COMPTÉS COMME DES ENCAISSEMENTS. Le module
	 *    Encaissement crédite pourtant le 411 pour de bon. Une société qui
	 *    encaisse au reçu voyait donc ses factures rester dues ici alors
	 *    qu'elles étaient payées, réglées au grand livre et soldées dans le
	 *    recouvrement. C'est ce qui rendait l'écran d'encaissement
	 *    inexploitable : il proposait d'encaisser ce qui l'était déjà.
	 *
	 * Les deux chiffres proviennent maintenant du MÊME périmètre que
	 * FKC_Recouvrement. Un seul poste client, une seule vérité.
	 *
	 * @return array{facture:float,encaisse:float,solde:float,reglements:float,recus:float}
	 */
	public static function soldeClient( $clientId ) {
		$id = (int) $clientId;
		$emis = "SELECT COALESCE(SUM(montant_ttc),0) AS s FROM factures
		         WHERE client_id=?
		           AND ( statut IS NULL OR (
		                 statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
		                 AND ( LOWER(statut) NOT IN ('brouillon','devis','proforma')
		                       OR COALESCE(ecriture_id,0) <> 0 ) ) )";
		try {
			$fact = (float) FKC_DB::q( $emis, array( $id ) )->fetch()['s'];
		} catch ( \Throwable $e ) {
			// Base antérieure à la colonne de liaison comptable.
			$fact = (float) FKC_DB::q(
				"SELECT COALESCE(SUM(montant_ttc),0) AS s FROM factures
				 WHERE client_id=? AND ( statut IS NULL OR (
				       statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
				       AND LOWER(statut) NOT IN ('brouillon','devis','proforma') ) )",
				array( $id )
			)->fetch()['s'];
		}
		$reg = (float) FKC_DB::q( "SELECT COALESCE(SUM(montant),0) AS s FROM reglements WHERE sens='encaissement' AND tiers_type='client' AND tiers_id=? AND COALESCE(statut,'actif')<>'annule'", array( $id ) )->fetch()['s'];

		// Reçus comptabilisés qui soldent la créance. Même règle que le
		// recouvrement : les acomptes (419) ne comptent qu'une fois imputés.
		$rec = 0.0;
		try {
			$rec = (float) FKC_DB::q(
				"SELECT COALESCE(SUM(CASE WHEN sens='decaissement' THEN -montant_ttc ELSE montant_ttc END),0) AS s
				 FROM recus
				 WHERE client_id=? AND ecriture_id IS NOT NULL AND statut NOT IN ('annule')
				   AND ( type_operation IN ('paiement_facture','vente_comptant','remboursement')
				         OR (type_operation IN ('acompte_client','avance_commande') AND rapproche_at IS NOT NULL) )",
				array( $id )
			)->fetch()['s'];
		} catch ( \Throwable $e ) { /* module Encaissement absent */ }

		$enc = $reg + $rec;
		return array(
			'facture'    => round( $fact, 2 ),
			'encaisse'   => round( $enc, 2 ),
			'solde'      => round( $fact - $enc, 2 ),
			'reglements' => round( $reg, 2 ),
			'recus'      => round( $rec, 2 ),
		);
	}

	/**
	 * Solde dû à un fournisseur.
	 *
	 * Contrairement au solde client, qui se lit sur les factures émises, la
	 * dette fournisseur naît de trois sources : les factures d'achat saisies,
	 * les réceptions comptabilisées directement par les packs métier, et toute
	 * écriture manuelle imputée au tiers. C'est pourquoi le calcul s'appuie sur
	 * la COMPTABILITÉ AUXILIAIRE — les lignes d'écriture portant le tiers — et
	 * non sur une seule table de documents : une réception non facturée doit
	 * apparaître, sinon elle reste un suspens invisible.
	 *
	 * @param int $fournisseurId Identifiant dans le référentiel fournisseurs.
	 * @return array{du: float, paye: float, solde: float, attente: float, exigible: float}
	 *         attente = reçu non encore facturé (408) ; exigible = facturé et payable.
	 */
	public static function soldeFournisseur( $fournisseurId ) {
		$id = (int) $fournisseurId;
		$du = 0.0; $paye = 0.0;
		try {
			// Crédit = dette née, débit = dette éteinte (paiement, avoir).
			$r = FKC_DB::q(
				"SELECT COALESCE(SUM(credit),0) AS c, COALESCE(SUM(debit),0) AS d
				 FROM ecriture_lignes WHERE tiers_type='fournisseur' AND tiers_id=?",
				array( $id )
			)->fetch();
			$du   = (float) ( $r['c'] ?? 0 );
			$paye = (float) ( $r['d'] ?? 0 );
		} catch ( \Throwable $e ) { /* base antérieure à la comptabilité auxiliaire */ }

		// Règlements enregistrés hors comptabilité auxiliaire (bases anciennes,
		// ou écriture déposée au brouillard donc pas encore ventilée).
		try {
			$horsAux = (float) FKC_DB::q(
				"SELECT COALESCE(SUM(r.montant),0) AS s FROM reglements r
				 WHERE r.sens='paiement' AND r.tiers_type='fournisseur' AND r.tiers_id=? AND r.ecriture_id IS NULL AND COALESCE(r.statut,'actif')<>'annule'",
				array( $id )
			)->fetch()['s'];
			$paye += $horsAux;
		} catch ( \Throwable $e ) {}

		/*
		 * 1.745.0 — un paiement ANNULÉ dont la contre-passation attend au
		 * journal temporaire figure encore au grand livre. Le fournisseur,
		 * lui, n'est plus payé : on le retire dès maintenant, comme la liste
		 * des factures le fait déjà. À la validation, la contre-passation
		 * prend le relais et cette correction s'éteint d'elle-même.
		 */
		try {
			$paye -= (float) FKC_DB::q(
				"SELECT COALESCE(SUM(r.montant),0) FROM reglements r
				 WHERE r.sens='paiement' AND r.tiers_type='fournisseur' AND r.tiers_id=? AND r.statut='annule'
				   AND EXISTS (SELECT 1 FROM ecriture_annulations a WHERE a.table_source='reglements' AND a.ligne_id=r.id AND a.brouillon_id IS NOT NULL)",
				array( $id )
			)->fetchColumn();
		} catch ( \Throwable $e ) { /* journal des annulations absent : aucune annulation en attente */ }

		// Part non encore facturee (comptes 408) : elle est due, mais elle n'est
		// pas payable — on ne regle pas un fournisseur sur un bon de livraison.
		$attente = 0.0;
		try {
			$attente = (float) FKC_DB::q(
				"SELECT COALESCE(SUM(l.credit - l.debit),0) s
				 FROM ecriture_lignes l JOIN comptes c ON c.id = l.compte_id
				 WHERE l.tiers_type='fournisseur' AND l.tiers_id=? AND c.numero LIKE '408%'",
				array( $id )
			)->fetch()['s'];
		} catch ( \Throwable $e ) {}

		$solde = round( $du - $paye, 2 );
		return array(
			'du'       => $du,
			'paye'     => $paye,
			'solde'    => $solde,
			'attente'  => round( $attente, 2 ),          // recu, pas encore facture
			'exigible' => round( $solde - $attente, 2 ), // facture et payable
		);
	}
}
