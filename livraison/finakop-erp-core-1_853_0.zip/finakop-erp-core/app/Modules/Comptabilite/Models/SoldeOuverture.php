<?php
/**
 * GESTIONNAIRE DES À-NOUVEAUX / SOLDE D'OUVERTURE (1.798.0).
 *
 * ═════════════════════════════════════════════════════════════════════════
 * LE DÉFAUT QUE CE SERVICE FERME
 *
 * Le Grand Livre et la Balance calculaient le solde d'ouverture d'une
 * période par un simple cumul :
 *
 *     SUM(débit − crédit) WHERE date_ecriture < :du
 *
 * c'est-à-dire TOUT l'historique, à-nouveaux des années précédentes
 * compris. Au 1er janvier 2026, le capital de 5 000 000 F apparaissait donc
 * une première fois dans une ligne virtuelle « Report à nouveau » (le
 * cumul de 2025), puis une seconde fois dans la vraie écriture
 * d'À-nouveaux datée du même jour : 10 000 000 F. En troisième année,
 * 15 000 000 F. Et la balance restait équilibrée — actif et passif
 * doublaient ensemble —, donc aucun contrôle ne s'allumait.
 *
 * Le Bilan, lui, lisait la période de l'exercice : juste quand les
 * À-nouveaux existent, amputé de tout le passé quand ils n'existent pas.
 * Trois écrans, trois définitions du solde d'ouverture.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * UNE SEULE DÉFINITION, ÉCRITE ICI
 *
 * Pour une date D appartenant à l'exercice N (ouvert le D₀) :
 *
 *   • comptes de GESTION (classes 6, 7, 8) : mouvements de [D₀, D[ —
 *     l'indépendance des exercices ne reporte jamais un compte de charge ;
 *
 *   • comptes de BILAN (classes 1 à 5) : mouvements de [S, D[, où S est
 *     le premier jour du dernier exercice ≤ N qui possède ses À-nouveaux.
 *     Les À-nouveaux de S reprennent tout ce qui précède ; ce qui précède
 *     n'est donc plus jamais relu. Si N possède ses À-nouveaux, S = D₀ et
 *     l'écriture d'À-nouveaux EST le mouvement d'ouverture. Sinon, le
 *     solde d'ouverture est CALCULÉ depuis la clôture de N-1, et le dit.
 *
 * Sur une plage qui traverse plusieurs exercices, les À-nouveaux des
 * exercices commencés APRÈS le début de la plage sont exclus des
 * mouvements : ils reprendraient des soldes déjà présents.
 *
 * Grand Livre, Balance, Bilan et états financiers lisent tous ce service :
 * « Balance = Grand Livre = Bilan » n'est plus un objectif, c'est une
 * conséquence.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * TERMINOLOGIE (définitive)
 *
 *   À-nouveaux ............ l'écriture générée à l'ouverture de l'exercice
 *   Solde d'ouverture ..... le montant initial d'un compte
 *   Report à nouveau ...... l'affectation du résultat antérieur (121/129),
 *                           JAMAIS le nom d'un solde d'ouverture
 *   Audit des À-nouveaux .. l'écran de contrôle
 *
 * Règle fondamentale : les À-nouveaux servent à ouvrir l'exercice ; le
 * Report à nouveau sert à reporter un résultat antérieur. Un « Report à
 * nouveau » virtuel ne vient jamais s'ajouter à une véritable écriture
 * d'À-nouveaux.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SoldeOuverture {

	/** Préfixe de référence des écritures d'À-nouveaux générées par FinaKop. */
	const REF = 'AN-';

	/** Tolérance d'arrondi, en francs. */
	const TOLERANCE = 1.0;

	/** Classes de bilan, lues sur le premier chiffre du numéro (convention des états). */
	const SQL_BILAN = "substr(c.numero,1,1) IN ('1','2','3','4','5')";

	/** Fenêtre, en jours après l'ouverture, où l'on cherche des reprises de soldes. */
	const FENETRE_REPRISE = 31;

	/** Types de sources d'ouverture. */
	const T_OFFICIEL  = 'an_officiel';
	const T_JOURNAL   = 'an_journal';
	const T_MIGRATION = 'migration';
	const T_OD        = 'od_reprise';

	/**
	 * États d'ouverture d'un exercice (1.799.0) — un seul, calculé ici :
	 *
	 *   initial       aucune origine : premier exercice, rien à reprendre ;
	 *   calcule       aucune écriture d'ouverture, un passé : le solde est
	 *                 calculé depuis la clôture N-1 (c'est lui, l'origine) ;
	 *   an            une seule origine : l'À-nouveaux officiel ;
	 *   autre_source  une seule origine, qui n'est pas un À-nouveaux FinaKop
	 *                 (reprise de migration d'un premier exercice…) ;
	 *   ambigu        PLUS D'UNE origine. Le solde d'ouverture n'est pas
	 *                 fiable et n'est jamais présenté comme normal.
	 */
	const E_INITIAL = 'initial';
	const E_CALCULE = 'calcule';
	const E_AN      = 'an';
	const E_AUTRE   = 'autre_source';
	const E_AMBIGU  = 'ambigu';

	/**
	 * Comment une source a été reconnue — de la preuve la plus forte à la
	 * plus faible. Le libellé n'est plus qu'un dernier recours (1.799.0) :
	 * une OD intitulée « Mise en conformité bilan » qui reprend réellement
	 * les soldes est reconnue à ses MONTANTS.
	 */
	const D_OFFICIEL  = 'officiel';      // référence AN-AAAA, journal AN au 1er jour, pointeur de l'exercice
	const D_MARQUEUR  = 'marqueur';      // origine / fait / source posés à l'écriture (migration, ouverture)
	const D_QUALIFIEE = 'qualifiee';     // qualifiée « source d'ouverture » par un utilisateur, avec motif
	const D_MONTANTS  = 'montants';      // ses lignes reprennent les soldes de clôture N-1
	const D_LIBELLE   = 'libelle';       // son libellé le dit, sans autre preuve

	/** Qualifications posées par l'utilisateur. */
	const Q_SOURCE = 'source';
	const Q_EXCLUE = 'exclue';

	/** Part minimale des lignes d'une OD qui doivent reprendre un solde de clôture. */
	const SEUIL_MONTANTS = 0.6;

	protected static $memo = array();
	protected static $memoCle = null;
	protected static $pret = false;

	/* ══ Mémoïsation ═══════════════════════════════════════════════════════
	 *
	 * Les écrans appellent ce service des dizaines de fois par affichage
	 * (une fois par compte, par colonne N et N-1…). La mémoïsation est
	 * indexée sur `total_changes()` de la connexion SQLite : toute écriture,
	 * où qu'elle soit faite, invalide le cache sans qu'aucun appelant ait à
	 * y penser. C'est la leçon de `FKC_EtatsDgi::oublierSoldes()`, dont
	 * l'oubli d'un appel avait laissé des états périmés à l'écran.
	 */
	protected static function cle() {
		try {
			$pdo = FKC_DB::conn();
			return spl_object_id( $pdo ) . ':' . (int) $pdo->query( 'SELECT total_changes()' )->fetchColumn();
		} catch ( \Throwable $e ) { return 'x'; }
	}

	protected static function memo( $k, callable $fn ) {
		$cle = self::cle();
		if ( $cle !== self::$memoCle ) { self::$memo = array(); self::$memoCle = $cle; }
		if ( ! array_key_exists( $k, self::$memo ) ) { self::$memo[ $k ] = $fn(); }
		return self::$memo[ $k ];
	}

	/** Purge explicite (changement de société, tests). */
	public static function oublier() { self::$memo = array(); self::$memoCle = null; }

	/* ══ Traçabilité : colonnes de l'exercice ══════════════════════════════ */

	/**
	 * Chaque À-nouveaux garde la trace de sa source : exercice N-1 repris,
	 * empreinte de la balance de clôture reprise, total, date de génération.
	 * L'empreinte permet de savoir, des mois plus tard, si la clôture de N-1
	 * a bougé depuis que l'ouverture de N a été faite.
	 */
	public static function ensure() {
		if ( self::$pret ) { return; }
		self::$pret = true;
		try {
			$cols = array();
			foreach ( FKC_DB::conn()->query( 'PRAGMA table_info(exercices)' ) as $c ) { $cols[ $c['name'] ] = true; }
			if ( ! $cols ) { return; }
			$aj = array(
				'an_source_exercice' => 'INTEGER',
				'an_empreinte'       => "TEXT DEFAULT ''",
				'an_total'           => 'REAL',
				'an_genere_le'       => 'TEXT',
			);
			foreach ( $aj as $nom => $def ) {
				if ( ! isset( $cols[ $nom ] ) ) { FKC_DB::conn()->exec( "ALTER TABLE exercices ADD COLUMN $nom $def" ); }
			}
		} catch ( \Throwable $e ) { /* base indisponible : la traçabilité attendra */ }
		self::ensureQualifications();
	}

	/**
	 * Registre des qualifications (1.799.0) : ce que l'utilisateur a dit
	 * d'une écriture — « c'est une source d'ouverture » / « ce n'en est pas
	 * une » — avec son motif, son auteur et sa date. C'est la voie
	 * STRUCTURÉE pour les OD que ni leurs marqueurs ni leurs montants ne
	 * désignent.
	 *
	 * Les anciennes reprises de migration (pièce MIGRATION-AN-*) y sont
	 * inscrites d'office, une fois : elles cessent de dépendre de la
	 * détection et portent leur origine en clair à l'audit. Aucune écriture
	 * n'est modifiée — seul ce registre est écrit.
	 */
	protected static $qualifPret = array();
	public static function ensureQualifications() {
		$cle = 'x';
		try { $cle = (string) FKC_DB::file(); } catch ( \Throwable $e ) {}
		if ( isset( self::$qualifPret[ $cle ] ) ) { return; }
		self::$qualifPret[ $cle ] = true;
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS ouverture_qualifications(
					ecriture_id INTEGER PRIMARY KEY,
					qualification TEXT NOT NULL,
					motif TEXT NOT NULL DEFAULT '',
					par INTEGER,
					par_nom TEXT DEFAULT '',
					le TEXT DEFAULT(datetime('now','localtime')),
					/* Empreinte de l'écriture qualifiée : SQLite peut réattribuer
					   l'identifiant d'une écriture supprimée. Sans elle, une
					   qualification périmée s'appliquerait à une écriture sans
					   rapport, qui aurait hérité du même numéro interne. */
					empreinte TEXT NOT NULL DEFAULT ''
				);
			" );
			FKC_DB::conn()->exec( "
				INSERT OR IGNORE INTO ouverture_qualifications(ecriture_id, qualification, motif, par_nom, empreinte)
				SELECT id, 'source', 'Ancienne reprise de bilan par migration (pièce ' || piece || ') — inscrite automatiquement', 'FinaKop 1.799.0',
				       date_ecriture || '|' || journal_id || '|' || COALESCE(libelle,'')
				FROM ecritures WHERE piece LIKE 'MIGRATION-AN-%'
			" );
		} catch ( \Throwable $e ) { /* registre indisponible : la détection reste */ }
	}

	/** @return array<int, array> ecriture_id => qualification */
	public static function qualifications() {
		self::ensureQualifications();
		return self::memo( 'qualif', function () {
			$out = array();
			try {
				// Seules comptent les qualifications dont l'écriture existe ENCORE, et est bien la même.
				foreach ( FKC_DB::q(
					"SELECT q.* FROM ouverture_qualifications q JOIN ecritures e ON e.id = q.ecriture_id
					 WHERE q.empreinte = e.date_ecriture || '|' || e.journal_id || '|' || COALESCE(e.libelle,'')"
				)->fetchAll() as $r ) { $out[ (int) $r['ecriture_id'] ] = $r; }
			} catch ( \Throwable $e ) {}
			return $out;
		} );
	}

	/**
	 * Qualifie une écriture de l'exercice : source d'ouverture, ou non.
	 * Motif obligatoire — c'est lui qui répondra, dans deux ans, à la
	 * question « pourquoi cette OD a-t-elle été écartée ? ».
	 */
	public static function qualifier( $ecritureId, $qualification, $motif ) {
		$ecritureId = (int) $ecritureId;
		$motif = trim( (string) $motif );
		if ( ! in_array( $qualification, array( self::Q_SOURCE, self::Q_EXCLUE ), true ) ) { return array( false, 'Qualification inconnue.' ); }
		if ( mb_strlen( $motif ) < 10 ) { return array( false, 'Indiquez le motif de la qualification (une phrase) : il sera conservé à l\'audit.' ); }
		$e = FKC_DB::q( 'SELECT id, date_ecriture, journal_id, libelle FROM ecritures WHERE id=?', array( $ecritureId ) )->fetch();
		if ( ! $e ) { return array( false, 'Écriture #' . $ecritureId . ' introuvable.' ); }
		$an = self::exerciceDe( $e['date_ecriture'] );
		if ( self::Q_EXCLUE === $qualification && in_array( $ecritureId, self::ecrituresAN( $an ), true ) ) {
			return array( false, 'L\'écriture #' . $ecritureId . ' est un À-nouveaux (référence, journal AN ou pointeur de l\'exercice) : '
				. 'elle ne s\'écarte pas par qualification. Utilisez la réparation guidée de l\'Audit des À-nouveaux.' );
		}
		self::ensureQualifications();
		FKC_DB::q( 'INSERT OR REPLACE INTO ouverture_qualifications(ecriture_id, qualification, motif, par, par_nom, le, empreinte) VALUES(?,?,?,?,?,?,?)', array(
			$ecritureId, $qualification, $motif,
			class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
			class_exists( 'FKC_Auth' ) && method_exists( 'FKC_Auth', 'user' ) ? (string) ( FKC_Auth::user()['nom'] ?? '' ) : '',
			date( 'Y-m-d H:i:s' ),
			$e['date_ecriture'] . '|' . $e['journal_id'] . '|' . (string) $e['libelle'],
		) );
		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $an, 'ouverture_qualification', array(
				'libelle' => 'Écriture #' . $ecritureId . ' qualifiée ' . ( self::Q_SOURCE === $qualification ? '« source d\'ouverture »' : '« pas une source d\'ouverture »' ),
				'motif' => $motif, 'ecriture_id' => $ecritureId,
			) );
		}
		self::oublier();
		return array( true, 'Écriture #' . $ecritureId . ' qualifiée ' . ( self::Q_SOURCE === $qualification ? 'source d\'ouverture' : 'hors ouverture' ) . '.' );
	}

	/**
	 * Écritures contre-passées et contre-passations (marqueur ANN#id de
	 * FKC_EcritureAnnulation). Une source contre-passée est NEUTRALISÉE :
	 * elle et son inverse cessent d'être des sources d'ouverture — que la
	 * contre-passation vienne de la réparation guidée ou de l'écran des
	 * écritures.
	 *
	 * @return array{annulees:array<int,int>, contrepassations:array<int,int>}
	 */
	public static function neutralisations() {
		return self::memo( 'neutr', function () {
			$out = array( 'annulees' => array(), 'contrepassations' => array() );
			$m = class_exists( 'FKC_EcritureAnnulation' ) ? FKC_EcritureAnnulation::MARQUEUR : 'ANN#';
			try {
				foreach ( FKC_DB::q( 'SELECT id, reference FROM ecritures WHERE reference LIKE ?', array( $m . '%' ) )->fetchAll() as $r ) {
					$src = (int) substr( (string) $r['reference'], strlen( $m ) );
					if ( $src > 0 ) { $out['annulees'][ $src ] = (int) $r['id']; $out['contrepassations'][ (int) $r['id'] ] = $src; }
				}
			} catch ( \Throwable $e ) {}
			return $out;
		} );
	}

	/** L'écriture est-elle neutralisée (contre-passée) ou une contre-passation ? */
	public static function estNeutralisee( $id ) {
		$n = self::neutralisations();
		return isset( $n['annulees'][ (int) $id ] ) || isset( $n['contrepassations'][ (int) $id ] );
	}

	/* ══ Bornes ════════════════════════════════════════════════════════════ */

	public static function bornes( $annee ) {
		if ( class_exists( 'FKC_Exercice' ) ) { return FKC_Exercice::bornes( (int) $annee ); }
		return array( sprintf( '%04d-01-01', (int) $annee ), sprintf( '%04d-12-31', (int) $annee ) );
	}
	public static function debutDe( $annee ) { $b = self::bornes( $annee ); return $b[0]; }
	public static function finDe( $annee )   { $b = self::bornes( $annee ); return $b[1]; }
	public static function exerciceDe( $date ) {
		if ( class_exists( 'FKC_Exercice' ) ) { return (int) FKC_Exercice::annee( $date ); }
		return (int) substr( (string) $date, 0, 4 );
	}

	/* ══ À-nouveaux officiels ══════════════════════════════════════════════ */

	/**
	 * Toutes les écritures d'À-nouveaux, indexées par exercice.
	 *
	 * Une écriture est « À-nouveaux » de l'exercice N si l'une de ces trois
	 * voies indépendantes la désigne : sa référence AN-N, son journal AN à la
	 * date d'ouverture de N, ou le pointeur `exercices.an_ecriture_id`. Une
	 * seule suffit — c'est ce qui rend le doublon impossible à cacher.
	 *
	 * @return array<int, int[]> annee => ids
	 */
	public static function carteAN() {
		return self::memo( 'carteAN', function () {
			$out = array();
			$add = function ( $annee, $id ) use ( &$out ) {
				$annee = (int) $annee; $id = (int) $id;
				if ( $annee <= 0 || $id <= 0 ) { return; }
				if ( ! isset( $out[ $annee ] ) ) { $out[ $annee ] = array(); }
				if ( ! in_array( $id, $out[ $annee ], true ) ) { $out[ $annee ][] = $id; }
			};
			try {
				foreach ( FKC_DB::q( "SELECT id, reference FROM ecritures WHERE reference LIKE 'AN-%'" )->fetchAll() as $r ) {
					if ( preg_match( '/^AN-(\d{4})$/', (string) $r['reference'], $m ) ) { $add( $m[1], $r['id'] ); }
				}
			} catch ( \Throwable $e ) { /* colonne absente */ }
			try {
				foreach ( FKC_DB::q(
					"SELECT e.id, e.date_ecriture FROM ecritures e JOIN journaux j ON j.id=e.journal_id WHERE j.code='AN'"
				)->fetchAll() as $r ) {
					$an = self::exerciceDe( $r['date_ecriture'] );
					if ( (string) $r['date_ecriture'] === self::debutDe( $an ) ) { $add( $an, $r['id'] ); }
				}
			} catch ( \Throwable $e ) { /* ignore */ }
			try {
				/*
				 * Le pointeur ne vaut que pour une écriture qui EST un
				 * À-nouveaux (journal AN, référence AN-, origine « anouveaux ») :
				 * un pointeur divergent vers une écriture ordinaire la ferait
				 * sinon disparaître des mouvements. Il est signalé par
				 * pointeur(), pas cru sur parole.
				 */
				foreach ( FKC_DB::q(
					"SELECT x.annee, x.an_ecriture_id FROM exercices x JOIN ecritures e ON e.id = x.an_ecriture_id
					 JOIN journaux j ON j.id = e.journal_id
					 WHERE x.an_ecriture_id IS NOT NULL
					   AND ( j.code = 'AN' OR e.reference LIKE 'AN-%' OR COALESCE(e.origine,'') = 'anouveaux' )"
				)->fetchAll() as $r ) { $add( $r['annee'], $r['an_ecriture_id'] ); }
			} catch ( \Throwable $e ) { /* ignore */ }
			// Une écriture contre-passée n'ouvre plus rien, et son inverse non plus.
			foreach ( $out as $a => $ids ) {
				$ids = array_values( array_filter( $ids, function ( $id ) { return ! self::estNeutralisee( $id ); } ) );
				sort( $ids );
				if ( $ids ) { $out[ $a ] = $ids; } else { unset( $out[ $a ] ); }
			}
			ksort( $out );
			return $out;
		} );
	}

	/** Écritures d'À-nouveaux de l'exercice (source unique, utilisée par FKC_ANouveaux). */
	public static function ecrituresAN( $annee ) {
		$c = self::carteAN();
		return $c[ (int) $annee ] ?? array();
	}

	public static function aDesANouveaux( $annee ) { return array() !== self::ecrituresAN( $annee ); }

	/**
	 * L'À-nouveaux OFFICIEL de l'exercice : une écriture et une seule.
	 * null s'il n'y en a pas — ou s'il y en a plusieurs, car alors aucune
	 * n'est officielle tant que le doublon n'est pas levé.
	 */
	public static function anOfficiel( $annee ) {
		$ids = self::ecrituresAN( $annee );
		return 1 === count( $ids ) ? (int) $ids[0] : null;
	}

	/**
	 * Premier jour du dernier exercice ≤ $annee qui possède ses À-nouveaux,
	 * ou '0000-01-01' si aucun n'en a : c'est le point d'où les comptes de
	 * bilan se relisent.
	 */
	public static function departBilan( $annee ) {
		$annee = (int) $annee; $meilleur = null;
		foreach ( array_keys( self::carteAN() ) as $a ) {
			if ( $a <= $annee && ( null === $meilleur || $a > $meilleur ) ) { $meilleur = $a; }
		}
		return null === $meilleur ? '0000-01-01' : self::debutDe( $meilleur );
	}

	/* ══ Clauses SQL — le cœur du service ══════════════════════════════════
	 *
	 * Les écrans ajoutent leurs propres filtres (plage de comptes, tiers,
	 * journal) ; ils ne réécrivent jamais la règle. Alias attendus : `e`
	 * pour ecritures, `c` pour comptes.
	 */

	/**
	 * Lignes qui composent le solde STRICTEMENT AVANT $du.
	 * @return array{0:string,1:array}
	 */
	public static function clauseAvant( $du ) {
		$n = self::exerciceDe( $du );
		return array(
			'( e.date_ecriture < ? AND ( ( ' . self::SQL_BILAN . ' AND e.date_ecriture >= ? )'
				. ' OR ( NOT ' . self::SQL_BILAN . ' AND e.date_ecriture >= ? ) ) )',
			array( (string) $du, self::departBilan( $n ), self::debutDe( $n ) ),
		);
	}

	/**
	 * Lignes qui composent le solde AU SOIR de $date (incluse), lu dans
	 * l'exercice auquel $date appartient. Sert à la clôture.
	 */
	public static function clauseJusqua( $date ) {
		$n = self::exerciceDe( $date );
		return array(
			'( e.date_ecriture <= ? AND ( ( ' . self::SQL_BILAN . ' AND e.date_ecriture >= ? )'
				. ' OR ( NOT ' . self::SQL_BILAN . ' AND e.date_ecriture >= ? ) ) )',
			array( (string) $date, self::departBilan( $n ), self::debutDe( $n ) ),
		);
	}

	/**
	 * Mouvements de la plage [$du, $au], sans les À-nouveaux des exercices
	 * commencés après $du : ceux-là reprendraient des soldes déjà présents
	 * dans la plage.
	 *
	 * @param bool $sansANDuJour Exclure aussi les À-nouveaux datés de $du
	 *                           (la Balance les range en colonnes d'ouverture).
	 */
	public static function clauseMouvements( $du, $au, $sansANDuJour = false ) {
		$w = array(); $p = array();
		if ( $du ) { $w[] = 'e.date_ecriture >= ?'; $p[] = (string) $du; }
		if ( $au ) { $w[] = 'e.date_ecriture <= ?'; $p[] = (string) $au; }
		$excl = self::anAExclure( $du, $au, $sansANDuJour );
		if ( $excl ) { $w[] = 'e.id NOT IN (' . implode( ',', array_map( 'intval', $excl ) ) . ')'; }
		return array( $w ? '( ' . implode( ' AND ', $w ) . ' )' : '1=1', $p );
	}

	/** Identifiants d'À-nouveaux à écarter des mouvements d'une plage. */
	public static function anAExclure( $du, $au, $sansANDuJour = false ) {
		$ids = array();
		foreach ( self::carteAN() as $annee => $lst ) {
			$d0 = self::debutDe( $annee );
			if ( $au && $d0 > $au ) { continue; }
			$apres = $du ? ( $d0 > $du ) : ( $annee > self::premierExercice() );
			if ( $apres || ( $sansANDuJour && $du && $d0 === $du ) ) {
				foreach ( $lst as $id ) { $ids[] = (int) $id; }
			}
		}
		return $ids;
	}

	/** Premier exercice mouvementé du dossier. */
	public static function premierExercice() {
		return self::memo( 'premier', function () {
			try {
				$d = FKC_DB::q( 'SELECT MIN(date_ecriture) FROM ecritures' )->fetchColumn();
				return $d ? self::exerciceDe( $d ) : ( class_exists( 'FKC_Exercice' ) ? FKC_Exercice::courant() : (int) date( 'Y' ) );
			} catch ( \Throwable $e ) { return (int) date( 'Y' ); }
		} );
	}

	/**
	 * Date de début effective d'une plage : $du s'il est donné, sinon le
	 * premier jour du premier exercice mouvementé. « Toutes périodes » ne
	 * veut plus dire « tout sommer depuis l'origine », ce qui relisait
	 * chaque À-nouveaux par-dessus les soldes qu'il reprend.
	 */
	public static function duEffectif( $du ) {
		return $du ? (string) $du : self::debutDe( self::premierExercice() );
	}

	/* ══ Soldes ════════════════════════════════════════════════════════════ */

	/**
	 * Soldes par compte selon une clause, avec filtre supplémentaire.
	 * @return array<int,float> compte_id => débit − crédit
	 */
	public static function soldesParCompte( array $clause, $filtre = '', array $pf = array() ) {
		list( $sql, $p ) = $clause;
		$out = array();
		$rows = FKC_DB::q(
			'SELECT l.compte_id cid, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
			 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
			 WHERE ' . $sql . ( $filtre ? ' AND ' . $filtre : '' ) . ' GROUP BY l.compte_id',
			array_merge( $p, $pf )
		)->fetchAll();
		foreach ( $rows as $r ) {
			$s = round( (float) $r['s'], 2 );
			if ( abs( $s ) >= 0.005 ) { $out[ (int) $r['cid'] ] = $s; }
		}
		return $out;
	}

	/**
	 * LE SOLDE D'OUVERTURE d'une date, compte par compte.
	 *
	 * @param string $du     Date (Y-m-d).
	 * @param string $filtre Filtre SQL additionnel (alias l, e, c).
	 * @return array{
	 *   date:string, exercice:int, debut:string, mode:string, an_ids:int[],
	 *   soldes:array<int,float>, an:array<int,float>, alerte:string,
	 *   libelle:string, sources_multiples:bool
	 * }
	 *
	 * `soldes` : ce qui précède $du. `an` : l'écriture d'À-nouveaux datée de
	 * $du elle-même, que le Grand Livre montre en mouvement réel et que la
	 * Balance range en colonnes d'ouverture — jamais les deux à la fois.
	 *
	 * `mode` :
	 *   an       — $du ouvre l'exercice et ses À-nouveaux existent ;
	 *   calcule  — $du ouvre l'exercice, sans À-nouveaux, sur un passé : le
	 *              solde est calculé depuis la clôture de N-1, et le dit ;
	 *   initial  — $du ouvre l'exercice, sans passé : rien à reprendre ;
	 *   report   — $du est en cours d'exercice : solde antérieur.
	 */
	public static function ouverture( $du, $filtre = '', array $pf = array() ) {
		$du = self::duEffectif( $du );
		$n  = self::exerciceDe( $du );
		$d0 = self::debutDe( $n );
		$an = self::ecrituresAN( $n );

		$soldes = self::soldesParCompte( self::clauseAvant( $du ), $filtre, $pf );
		$anDuJour = array();
		if ( $an && $d0 === $du ) {
			$anDuJour = self::soldesParCompte(
				array( 'e.id IN (' . implode( ',', array_map( 'intval', $an ) ) . ')', array() ), $filtre, $pf
			);
		}

		/*
		 * L'ÉTAT DE L'OUVERTURE EST CELUI DE L'EXERCICE, QUELLE QUE SOIT LA DATE.
		 *
		 * En 1.798.0, le mode était « an » dès qu'un À-nouveaux existait —
		 * même quand une reprise de migration s'y ajoutait. L'alerte était
		 * produite, mais l'état restait normal, et un écran qui ne lisait que
		 * l'état présentait comme normal un solde doublé. Désormais l'état
		 * vient de etat() — une seule règle —, et une ouverture ambiguë
		 * reste ambiguë jusque dans un Grand Livre ouvert au 15 mai.
		 */
		$fb   = self::fiabilite( $n );
		$etat = $fb['etat'];
		if ( $du !== $d0 )                      { $mode = 'report'; }
		elseif ( self::E_AMBIGU === $etat )     { $mode = self::E_AMBIGU; }
		elseif ( $an )                          { $mode = 'an'; }
		elseif ( self::E_AUTRE === $etat )      { $mode = self::E_AUTRE; }
		elseif ( self::E_CALCULE === $etat )    { $mode = 'calcule'; }
		else                                    { $mode = 'initial'; }

		$alerte = '';
		if ( ! $fb['fiable'] ) {
			$alerte = 'OUVERTURE NON FIABLE — ' . implode( ' ', $fb['raisons'] )
				. ' Les soldes d\'ouverture de ' . $n . ' ne sont pas considérés comme fiables : voir l\'Audit des À-nouveaux.';
		} elseif ( 'calcule' === $mode || ( 'report' === $mode && self::E_CALCULE === $etat ) ) {
			$alerte = 'Aucun À-nouveaux pour l\'exercice ' . $n . ' : le solde d\'ouverture est CALCULÉ depuis la clôture de '
				. ( $n - 1 ) . '. Générez les À-nouveaux (Clôture & Ouverture des exercices) pour l\'officialiser.';
		}

		// Écart par compte, pour que chaque état marque la ligne en cause.
		$ecartsComptes = array(); $totaux = null;
		if ( ! $fb['fiable'] ) {
			$totaux = self::decomposition( $n )['totaux'];
			foreach ( self::decomposition( $n )['comptes'] as $c ) {
				if ( null !== $c['ecart'] && abs( $c['ecart'] ) > self::TOLERANCE ) {
					$ecartsComptes[ (int) $c['compte_id'] ] = array( 'attendu' => $c['attendu'], 'officiel' => $c['officiel'],
						'effectif' => $c['effectif'], 'ecart' => $c['ecart'] );
				}
			}
		}

		return array(
			'date' => $du, 'exercice' => $n, 'debut' => $d0, 'mode' => $mode, 'an_ids' => $an,
			'soldes' => $soldes, 'an' => $anDuJour, 'alerte' => $alerte,
			'libelle' => self::libelleOuverture( $fb['fiable'] ? $mode : self::E_AMBIGU, $du, $n ),
			'etat' => $etat, 'fiable' => $fb['fiable'], 'raisons' => $fb['raisons'], 'herite' => $fb['herite'],
			'sources' => self::sources( $n ), 'ecarts_comptes' => $ecartsComptes, 'totaux' => $totaux,
			'report_calcule' => self::reportCalcule( $n ),
			'sources_multiples' => self::E_AMBIGU === $etat,
		);
	}

	/** Libellé de la ligne d'ouverture d'un état, selon le mode. */
	public static function libelleOuverture( $mode, $du, $n ) {
		switch ( $mode ) {
			case self::E_AMBIGU: return 'Solde d\'ouverture NON FIABLE (' . (int) $n . ')';
			case 'calcule': return 'Solde d\'ouverture calculé (aucun À-nouveaux ' . (int) $n . ')';
			case 'report':  return 'Solde antérieur au ' . date( 'd/m/Y', strtotime( (string) $du ) );
			default:        return 'Solde d\'ouverture';
		}
	}

	/** Y a-t-il des écritures avant cette date ? */
	protected static function passeAvant( $date ) {
		return self::memo( 'passe:' . $date, function () use ( $date ) {
			try { return (bool) FKC_DB::q( 'SELECT 1 FROM ecritures WHERE date_ecriture < ? LIMIT 1', array( (string) $date ) )->fetch(); }
			catch ( \Throwable $e ) { return false; }
		} );
	}

	/**
	 * Soldes de CLÔTURE d'un exercice, classes 1 à 5, tels que le Bilan de
	 * cet exercice les montre — à-nouveaux compris s'il en a, solde
	 * d'ouverture calculé sinon. Indexés par numéro.
	 *
	 * C'est la moitié gauche de « Clôture N = Ouverture N+1 ».
	 *
	 * @return array<string, array{solde:float, libelle:string, compte_id:int}>
	 */
	public static function soldesCloture( $annee ) {
		$annee = (int) $annee;
		return self::memo( 'cloture:' . $annee, function () use ( $annee ) {
			list( $sql, $p ) = self::clauseJusqua( self::finDe( $annee ) );
			$out = array();
			$rows = FKC_DB::q(
				'SELECT c.id cid, c.numero, c.libelle, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
				 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
				 WHERE ' . $sql . ' AND ' . self::SQL_BILAN . ' GROUP BY c.id ORDER BY c.numero', $p
			)->fetchAll();
			foreach ( $rows as $r ) {
				$s = round( (float) $r['s'], 2 );
				if ( abs( $s ) < 0.005 ) { continue; }
				$out[ (string) $r['numero'] ] = array( 'solde' => $s, 'libelle' => (string) $r['libelle'], 'compte_id' => (int) $r['cid'] );
			}
			return $out;
		} );
	}

	/**
	 * Soldes des comptes de bilan (classes 1 à 5) AU SOIR d'une date,
	 * indexés par numéro, chaque À-nouveaux compté une fois (1.800.0).
	 *
	 * C'est la lecture qui manquait aux écrans qui affichent un solde « à
	 * date » sans passer par la Balance : le Cockpit et le module Trésorerie
	 * sommaient tout l'historique, et comptaient donc chaque solde une fois
	 * par exercice ouvert.
	 *
	 * @return array<string, float>
	 */
	public static function soldesAu( $date ) {
		$date = (string) $date;
		return self::memo( 'au:' . $date, function () use ( $date ) {
			list( $sql, $p ) = self::clauseJusqua( $date );
			$out = array();
			try {
				foreach ( FKC_DB::q(
					'SELECT c.numero n, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
					 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
					 WHERE ' . $sql . ' AND ' . self::SQL_BILAN . ' GROUP BY c.numero', $p
				)->fetchAll() as $r ) {
					$v = round( (float) $r['s'], 2 );
					if ( abs( $v ) >= 0.005 ) { $out[ (string) $r['n'] ] = $v; }
				}
			} catch ( \Throwable $e ) {}
			return $out;
		} );
	}

	/** Solde d'un compte (par identifiant) au soir d'une date. */
	public static function soldeCompteAu( $compteId, $date ) {
		list( $sql, $p ) = self::clauseJusqua( (string) $date );
		try {
			return round( (float) FKC_DB::q(
				'SELECT COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) FROM ecriture_lignes l
				 JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
				 WHERE ' . $sql . ' AND l.compte_id=?', array_merge( $p, array( (int) $compteId ) )
			)->fetchColumn(), 2 );
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/**
	 * Solde d'ouverture de l'exercice, classes 1 à 5, par numéro : l'écriture
	 * d'À-nouveaux s'il y en a, la clôture de N-1 sinon (mode calculé).
	 */
	public static function soldesOuvertureBilan( $annee ) {
		$annee = (int) $annee;
		$ids = self::ecrituresAN( $annee );
		if ( ! $ids ) {
			$out = array();
			foreach ( self::soldesCloture( $annee - 1 ) as $num => $r ) { $out[ $num ] = $r + array( 'origine' => 'calcule' ); }
			return $out;
		}
		$rows = FKC_DB::q(
			'SELECT c.id cid, c.numero, c.libelle, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
			 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
			 WHERE l.ecriture_id IN (' . implode( ',', array_map( 'intval', $ids ) ) . ') GROUP BY c.id ORDER BY c.numero'
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$s = round( (float) $r['s'], 2 );
			if ( abs( $s ) < 0.005 ) { continue; }
			$out[ (string) $r['numero'] ] = array( 'solde' => $s, 'libelle' => (string) $r['libelle'], 'compte_id' => (int) $r['cid'], 'origine' => 'an' );
		}
		return $out;
	}

	/**
	 * Net (débit − crédit) du solde d'ouverture de l'exercice sur des
	 * préfixes de comptes. Sert aux états DGI pour ne pas lire un résultat
	 * antérieur reporté comme le résultat de l'année.
	 */
	public static function netOuverture( $annee, array $prefixes ) {
		$t = 0.0;
		foreach ( self::soldesOuvertureBilan( $annee ) as $num => $r ) {
			foreach ( $prefixes as $p ) {
				if ( 0 === strpos( (string) $num, (string) $p ) ) { $t += $r['solde']; break; }
			}
		}
		return $t;
	}

	/**
	 * Solde d'ouverture CALCULÉ à ajouter à une période qui commence le
	 * premier jour d'un exercice sans À-nouveaux. Vide si l'exercice a ses
	 * À-nouveaux (ils sont dans la période) ou s'il n'a pas de passé.
	 *
	 * @return array<string,float> numéro => solde
	 */
	public static function complementCalcule( $d1 ) {
		$n = self::exerciceDe( $d1 );
		if ( (string) $d1 !== self::debutDe( $n ) || self::aDesANouveaux( $n ) || ! self::passeAvant( $d1 ) ) { return array(); }
		$out = array();
		foreach ( self::soldesCloture( $n - 1 ) as $num => $r ) { $out[ $num ] = $r['solde']; }
		return $out;
	}

	/* ══ Sources d'ouverture ═══════════════════════════════════════════════ */

	/**
	 * TOUTES les écritures qui constituent une ouverture de l'exercice.
	 *
	 * Le doublon constaté ne venait pas d'une seconde génération — refusée
	 * depuis la 1.778.0 — mais d'une ouverture faite par un autre chemin :
	 * reprise de balance par la migration, OD saisie pour reprendre les
	 * soldes, écriture importée au journal AN. Chacune, seule, est
	 * légitime. Deux ensemble doublent le bilan d'ouverture.
	 *
	 * RECONNAISSANCE STRUCTURÉE D'ABORD (1.799.0). Dans l'ordre :
	 *   1. officiel   — référence AN-AAAA, journal AN au 1er jour, pointeur ;
	 *   2. marqueur   — origine « ouverture » / fait « reprise_bilan » /
	 *                   source « migration » posés à l'écriture ;
	 *   3. qualifiée  — un utilisateur l'a dite source, avec motif ;
	 *   4. montants   — ses lignes reprennent les soldes de clôture N-1 ;
	 *   5. libellé    — son libellé le dit, sans autre preuve.
	 * Une qualification « exclue » retire une écriture reconnue aux niveaux
	 * 4 et 5 (jamais un À-nouveaux). Une écriture contre-passée, et sa
	 * contre-passation, ne sont plus des sources.
	 *
	 * @return array<int, array> une ligne par écriture, avec `type` et `detection`
	 */
	public static function sources( $annee ) {
		$annee = (int) $annee;
		return self::memo( 'sources:' . $annee, function () use ( $annee ) {
			list( $d0, $f ) = self::bornes( $annee );
			$lim = date( 'Y-m-d', strtotime( $d0 . ' +' . self::FENETRE_REPRISE . ' days' ) );
			$officiels = self::ecrituresAN( $annee );
			$pointe = null;
			try { $pointe = (int) FKC_DB::q( 'SELECT an_ecriture_id FROM exercices WHERE annee=?', array( $annee ) )->fetchColumn() ?: null; }
			catch ( \Throwable $e ) { $pointe = null; }
			$affect = self::ecrituresAffectation();
			$qualif = self::qualifications();
			$qualIds = array();
			foreach ( $qualif as $id => $q ) { if ( self::Q_SOURCE === $q['qualification'] ) { $qualIds[] = (int) $id; } }
			$inQual = $qualIds ? ' OR e.id IN (' . implode( ',', $qualIds ) . ')' : '';

			$avecTrace = true;
			try {
				$rows = FKC_DB::q(
					"SELECT e.id, e.date_ecriture, e.libelle, e.piece, e.reference, e.numero, j.code journal,
					        COALESCE(e.source,'') source, COALESCE(e.origine,'') origine, COALESCE(e.fait,'') fait,
					        COALESCE(SUM(l.debit),0) montant, COUNT(l.id) nb_lignes,
					        SUM(CASE WHEN " . self::SQL_BILAN . " THEN 0 ELSE 1 END) hors_bilan
					 FROM ecritures e JOIN journaux j ON j.id=e.journal_id
					 LEFT JOIN ecriture_lignes l ON l.ecriture_id=e.id LEFT JOIN comptes c ON c.id=l.compte_id
					 WHERE e.date_ecriture BETWEEN ? AND ?
					   AND ( j.code='AN' OR e.reference LIKE 'AN-%' OR COALESCE(e.source,'')='migration'
					         OR COALESCE(e.origine,'') IN ('ouverture','reprise_bilan')
					         OR COALESCE(e.fait,'') IN ('reprise_bilan','ouverture_exercice')
					         OR e.piece LIKE 'MIGRATION-AN-%' OR e.date_ecriture <= ?" . $inQual . " )
					 GROUP BY e.id ORDER BY e.date_ecriture, e.id",
					array( $d0, $f, $lim )
				)->fetchAll();
			} catch ( \Throwable $e ) {
				// Base ancienne sans colonnes de traçabilité : lecture minimale.
				$avecTrace = false;
				$rows = FKC_DB::q(
					"SELECT e.id, e.date_ecriture, e.libelle, e.piece, e.reference, NULL numero, j.code journal,
					        '' source, '' origine, '' fait, COALESCE(SUM(l.debit),0) montant, COUNT(l.id) nb_lignes,
					        SUM(CASE WHEN " . self::SQL_BILAN . " THEN 0 ELSE 1 END) hors_bilan
					 FROM ecritures e JOIN journaux j ON j.id=e.journal_id
					 LEFT JOIN ecriture_lignes l ON l.ecriture_id=e.id LEFT JOIN comptes c ON c.id=l.compte_id
					 WHERE e.date_ecriture BETWEEN ? AND ?
					   AND ( j.code='AN' OR e.reference LIKE 'AN-%' OR e.piece LIKE 'MIGRATION-AN-%' OR e.date_ecriture <= ?" . $inQual . " )
					 GROUP BY e.id ORDER BY e.date_ecriture, e.id",
					array( $d0, $f, $lim )
				)->fetchAll();
			}

			$attendu = self::soldesCloture( $annee - 1 );
			$out = array();
			foreach ( $rows as $r ) {
				$id = (int) $r['id'];
				if ( self::estNeutralisee( $id ) ) { continue; }
				$q = $qualif[ $id ]['qualification'] ?? null;
				$migration = ( 'migration' === $r['source'] && 0 === (int) $r['hors_bilan'] )
					|| 0 === strpos( (string) $r['piece'], 'MIGRATION-AN-' ) || 'reprise_bilan' === $r['fait'];
				$marqueur = $migration || in_array( $r['origine'], array( 'ouverture', 'reprise_bilan' ), true )
					|| ( 'ouverture_exercice' === $r['fait'] && ! in_array( $id, $officiels, true ) );
				$type = null; $det = null; $preuve = '';

				if ( in_array( $id, $officiels, true ) ) {
					$genere = 0 === strpos( (string) $r['reference'], self::REF ) || $id === $pointe;
					$type = $migration ? self::T_MIGRATION : ( $genere ? self::T_OFFICIEL : self::T_JOURNAL );
					$det  = self::D_OFFICIEL;
					$preuve = self::T_OFFICIEL === $type ? 'Référence ' . $r['reference'] : 'Journal AN au premier jour de l\'exercice';
				} elseif ( $marqueur && 0 === (int) $r['hors_bilan'] ) {
					$type = $migration ? self::T_MIGRATION : self::T_OD;
					$det  = self::D_MARQUEUR;
					$preuve = $migration ? ( $r['piece'] ? 'Pièce ' . $r['piece'] : 'Source « migration »' ) : 'Origine « ' . ( $r['origine'] ?: $r['fait'] ) . ' »';
				} elseif ( self::Q_SOURCE === $q ) {
					$type = self::T_OD; $det = self::D_QUALIFIEE;
					$preuve = 'Qualifiée par ' . ( $qualif[ $id ]['par_nom'] ?: 'un utilisateur' ) . ' : ' . $qualif[ $id ]['motif'];
					if ( 0 === strpos( (string) $r['piece'], 'MIGRATION-AN-' ) ) { $type = self::T_MIGRATION; }
				} elseif ( 'AN' === $r['journal'] && self::Q_EXCLUE !== $q ) {
					$type = self::T_JOURNAL; $det = self::D_MARQUEUR; $preuve = 'Journal AN';
				} elseif ( self::Q_EXCLUE !== $q && self::candidatOD( $r, $lim, $affect ) ) {
					$m = self::correspondanceCloture( $id, $attendu );
					if ( $m['reprend'] ) {
						$type = self::T_OD; $det = self::D_MONTANTS;
						$preuve = $m['lignes_ok'] . ' ligne(s) sur ' . $m['lignes'] . ' reprennent exactement un solde de clôture ' . ( $annee - 1 );
					} elseif ( self::libelleDeReprise( $r ) ) {
						$type = self::T_OD; $det = self::D_LIBELLE;
						$preuve = 'Libellé « ' . $r['libelle'] . ' » (aucune autre preuve)';
					}
				}
				if ( ! $type ) { continue; }
				$out[] = array(
					'id' => $id, 'type' => $type, 'libelle_type' => self::libelleType( $type ),
					'detection' => $det, 'preuve' => $preuve, 'officielle' => self::D_OFFICIEL === $det && self::T_OFFICIEL === $type,
					'date' => (string) $r['date_ecriture'], 'journal' => (string) $r['journal'],
					'piece' => (string) $r['piece'], 'reference' => (string) $r['reference'], 'numero' => (string) ( $r['numero'] ?? '' ),
					'libelle' => (string) $r['libelle'], 'source' => (string) $r['source'], 'origine' => (string) $r['origine'],
					'montant' => round( (float) $r['montant'], 2 ), 'nb_lignes' => (int) $r['nb_lignes'],
					'qualification' => $qualif[ $id ] ?? null,
				);
			}
			return $out;
		} );
	}

	/**
	 * Une OD peut-elle être une reprise ? Datée du premier mois, sur des
	 * comptes de bilan seulement, au moins deux lignes. Exclues : extournes,
	 * affectation du résultat, écritures du moteur de clôture et de
	 * revalorisation — elles touchent le bilan au premier jour sans
	 * reprendre aucun solde.
	 */
	protected static function candidatOD( array $r, $lim, array $affect ) {
		if ( (string) $r['date_ecriture'] > $lim ) { return false; }
		if ( (int) $r['hors_bilan'] > 0 || (int) $r['nb_lignes'] < 2 ) { return false; }
		if ( in_array( (int) $r['id'], $affect, true ) ) { return false; }
		if ( in_array( (string) $r['source'], array( 'cloture', 'regularisation', 'extourne', 'revalorisation_devise', 'annulation' ), true ) ) { return false; }
		$txt = ' ' . $r['libelle'] . ' ' . $r['piece'] . ' ' . $r['reference'] . ' ';
		return ! preg_match( '/extourn|contre[\s-]?pass|annulation/iu', $txt );
	}

	/** Dernier recours : le libellé annonce une reprise ou une ouverture. */
	protected static function libelleDeReprise( array $r ) {
		$txt = ' ' . $r['libelle'] . ' ' . $r['piece'] . ' ' . $r['reference'] . ' ';
		return (bool) preg_match(
			'/(?:à|a)[\s-]*nouveaux?|reprise|ouverture|situation\s+initiale|soldes?\s+(?:initia|d.ouverture|report)|bilan\s+d.ouverture|report\s+(?:des\s+)?soldes|\bRAN\b|\bAN\b/iu',
			$txt
		);
	}

	/**
	 * L'OD reprend-elle les soldes de clôture N-1 ? Compte par compte, le
	 * solde de la ligne (débit − crédit) doit valoir EXACTEMENT le solde de
	 * clôture du compte. C'est la preuve qui ne dépend d'aucun libellé :
	 * « Mise en conformité bilan » qui reporte le capital, la banque et le
	 * client au franc près est une reprise, quel que soit son nom.
	 */
	public static function correspondanceCloture( $ecritureId, array $attendu ) {
		$out = array( 'lignes' => 0, 'lignes_ok' => 0, 'part' => 0.0, 'reprend' => false );
		if ( ! $attendu ) { return $out; }
		$rows = FKC_DB::q(
			'SELECT c.numero, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
			 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id WHERE l.ecriture_id=? GROUP BY c.id',
			array( (int) $ecritureId )
		)->fetchAll();
		foreach ( $rows as $r ) {
			$out['lignes']++;
			$a = $attendu[ (string) $r['numero'] ]['solde'] ?? null;
			if ( null !== $a && abs( (float) $r['s'] - (float) $a ) <= self::TOLERANCE ) { $out['lignes_ok']++; }
		}
		$out['part'] = $out['lignes'] ? $out['lignes_ok'] / $out['lignes'] : 0.0;
		$out['reprend'] = $out['lignes_ok'] >= 2 && $out['part'] >= self::SEUIL_MONTANTS;
		return $out;
	}

	protected static function ecrituresAffectation() {
		return self::memo( 'affect', function () {
			try {
				return array_map( 'intval', array_column(
					FKC_DB::q( 'SELECT ecriture_id FROM affectations_resultat WHERE ecriture_id IS NOT NULL' )->fetchAll(), 'ecriture_id'
				) );
			} catch ( \Throwable $e ) { return array(); }
		} );
	}

	public static function libelleType( $type ) {
		$l = array(
			self::T_OFFICIEL  => 'À-nouveaux officiel',
			self::T_JOURNAL   => 'Écriture au journal AN non générée par FinaKop',
			self::T_MIGRATION => 'Reprise de bilan (migration)',
			self::T_OD        => 'OD de reprise des soldes',
		);
		return $l[ $type ] ?? $type;
	}

	public static function libelleDetection( $d ) {
		$l = array(
			self::D_OFFICIEL => 'officielle', self::D_MARQUEUR => 'marqueur structuré', self::D_QUALIFIEE => 'qualifiée par un utilisateur',
			self::D_MONTANTS => 'reprend les soldes de clôture', self::D_LIBELLE => 'libellé seulement',
		);
		return $l[ $d ] ?? (string) $d;
	}

	/** Plusieurs origines d'ouverture pour cet exercice ? */
	public static function pluralite( $annee ) {
		return self::E_AMBIGU === self::etat( $annee );
	}

	/** Sources (écritures) autres que l'À-nouveaux officiel. */
	public static function autresSources( $annee ) {
		return array_values( array_filter( self::sources( $annee ), function ( $s ) {
			return empty( $s['officielle'] );
		} ) );
	}

	/* ══ État et fiabilité de l'ouverture ══════════════════════════════════ */

	/**
	 * Le solde d'ouverture est-il CALCULÉ dans cet exercice ? C'est le cas
	 * quand l'exercice n'a pas d'À-nouveaux et qu'il a un passé : le Grand
	 * Livre y relit alors la clôture de N-1. Ce report calculé est une
	 * ORIGINE d'ouverture à part entière — une reprise de migration posée
	 * par-dessus le double exactement comme le ferait un second À-nouveaux.
	 * C'est le cas que la 1.798.0 ne voyait pas.
	 */
	public static function reportCalcule( $annee ) {
		$annee = (int) $annee;
		return ! self::aDesANouveaux( $annee ) && self::passeAvant( self::debutDe( $annee ) )
			&& (bool) self::soldesCloture( $annee - 1 );
	}

	/**
	 * L'état d'ouverture de l'exercice. Une seule règle, pour tous les écrans :
	 *
	 *   0 origine                      → initial
	 *   1 origine : le report calculé  → calcule
	 *   1 origine : l'À-nouveaux       → an
	 *   1 origine : une autre écriture → autre_source
	 *   plus d'une origine             → ambigu
	 */
	public static function etat( $annee ) {
		$annee = (int) $annee;
		return self::memo( 'etat:' . $annee, function () use ( $annee ) {
			$src = self::sources( $annee );
			$nb = count( $src ) + ( self::reportCalcule( $annee ) ? 1 : 0 );
			if ( 0 === $nb ) { return self::E_INITIAL; }
			if ( $nb > 1 ) { return self::E_AMBIGU; }
			if ( ! $src ) { return self::E_CALCULE; }
			return ! empty( $src[0]['officielle'] ) ? self::E_AN : self::E_AUTRE;
		} );
	}

	/**
	 * Le solde d'ouverture de l'exercice est-il FIABLE ?
	 *
	 * Non, s'il a plus d'une origine ; non, si son ouverture effective ne
	 * reprend pas la clôture de N-1 ; non, s'il HÉRITE d'une ouverture non
	 * fiable — un bilan d'ouverture doublé en 2026 donne une clôture 2026
	 * doublée, que les À-nouveaux 2027 reprennent fidèlement, et donc un
	 * rapprochement 2027 parfaitement concordant sur des chiffres faux.
	 *
	 * @return array{fiable:bool, etat:string, raisons:string[], herite:bool}
	 */
	public static function fiabilite( $annee ) {
		$annee = (int) $annee;
		return self::memo( 'fiab:' . $annee, function () use ( $annee ) {
			$etat = self::etat( $annee );
			$r = array();
			if ( self::E_AMBIGU === $etat ) {
				$lib = array();
				foreach ( self::sources( $annee ) as $s ) { $lib[] = $s['libelle_type'] . ' #' . $s['id']; }
				if ( self::reportCalcule( $annee ) ) { array_unshift( $lib, 'report calculé de la clôture ' . ( $annee - 1 ) ); }
				$r[] = 'Plusieurs sources d\'ouverture détectées (' . implode( ', ', $lib ) . ').';
			}
			$d = self::decomposition( $annee );
			if ( $d['attendu_defini'] && $d['nb_ecarts'] > 0 ) {
				$r[] = 'L\'ouverture effective (' . fkc_money( $d['totaux']['effectif'] ) . ') diffère de la clôture ' . ( $annee - 1 )
					. ' (' . fkc_money( $d['totaux']['attendu'] ) . ') sur ' . $d['nb_ecarts'] . ' compte(s).';
			}
			$herite = false;
			if ( $annee > self::premierExercice() && self::passeAvant( self::debutDe( $annee ) ) ) {
				$prec = self::fiabilite( $annee - 1 );
				if ( ! $prec['fiable'] ) {
					$herite = true;
					$r[] = 'Il reprend la clôture de ' . ( $annee - 1 ) . ', dont l\'ouverture n\'est pas fiable.';
				}
			}
			return array( 'fiable' => ! $r, 'etat' => $etat, 'raisons' => $r, 'herite' => $herite );
		} );
	}

	public static function estFiable( $annee ) { return self::fiabilite( $annee )['fiable']; }

	/* ══ Solde attendu / officiel / effectif / écart ═══════════════════════ */

	/**
	 * Les quatre soldes d'ouverture, compte par compte.
	 *
	 *   attendu   la clôture de N-1 — ce que l'ouverture DOIT reprendre ;
	 *             indéfini sans passé (premier exercice, reprise initiale) ;
	 *   officiel  l'À-nouveaux officiel, ou le report calculé s'il n'y en a pas ;
	 *   effectif  ce que les états montrent réellement : report calculé
	 *             éventuel + TOUTES les sources, chacune détaillée ;
	 *   écart     effectif − attendu.
	 *
	 * La somme des sources ne devient JAMAIS une définition du solde normal :
	 * elle n'existe que pour mesurer l'écart. « Clôture 2025 : 5 M · AN
	 * officiel : 5 M · Migration : 5 M · Ouverture effective : 10 M ·
	 * Écart : +5 M » — c'est ce tableau.
	 *
	 * @return array{comptes:array, sources:array, totaux:array, attendu_defini:bool, nb_ecarts:int, report_calcule:bool}
	 */
	public static function decomposition( $annee ) {
		$annee = (int) $annee;
		return self::memo( 'decomp:' . $annee, function () use ( $annee ) {
			$attendu = self::soldesCloture( $annee - 1 );
			$defini  = self::passeAvant( self::debutDe( $annee ) ) && (bool) $attendu;
			$calc    = self::reportCalcule( $annee );
			$src     = self::sources( $annee );
			$offIds  = array(); foreach ( $src as $x ) { if ( ! empty( $x['officielle'] ) ) { $offIds[] = (int) $x['id']; } }

			$c = array();
			$lib = function ( $num, $l, $cid ) use ( &$c ) {
				if ( ! isset( $c[ $num ] ) ) {
					$c[ $num ] = array( 'numero' => (string) $num, 'libelle' => (string) $l, 'compte_id' => (int) $cid,
						'attendu' => 0.0, 'officiel' => 0.0, 'calcule' => 0.0, 'sources' => array(), 'effectif' => 0.0, 'ecart' => null );
				}
			};
			foreach ( $attendu as $num => $r ) {
				$lib( $num, $r['libelle'], $r['compte_id'] );
				$c[ $num ]['attendu'] = $r['solde'];
				if ( $calc ) { $c[ $num ]['calcule'] = $r['solde']; $c[ $num ]['officiel'] = $r['solde']; }
			}
			if ( $src ) {
				$ids = array_map( 'intval', array_column( $src, 'id' ) );
				foreach ( FKC_DB::q(
					'SELECT l.ecriture_id eid, c.id cid, c.numero, c.libelle, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
					 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
					 WHERE l.ecriture_id IN (' . implode( ',', $ids ) . ') AND ' . self::SQL_BILAN . ' GROUP BY l.ecriture_id, c.id'
				)->fetchAll() as $r ) {
					$lib( (string) $r['numero'], $r['libelle'], $r['cid'] );
					$v = round( (float) $r['s'], 2 );
					$c[ (string) $r['numero'] ]['sources'][ (int) $r['eid'] ] = $v;
					if ( in_array( (int) $r['eid'], $offIds, true ) ) { $c[ (string) $r['numero'] ]['officiel'] += $v; }
				}
			}
			$tot = array( 'attendu' => 0.0, 'officiel' => 0.0, 'calcule' => 0.0, 'effectif' => 0.0, 'ecart' => 0.0, 'sources' => array() );
			$nbE = 0;
			// Les totaux sont des masses de bilan : la somme des soldes débiteurs.
			$masse = function ( $v ) { return $v > 0 ? $v : 0.0; };
			foreach ( $c as $num => &$r ) {
				$r['effectif'] = round( $r['calcule'] + array_sum( $r['sources'] ), 2 );
				$r['officiel'] = round( $r['officiel'], 2 );
				if ( $defini ) {
					$r['ecart'] = round( $r['effectif'] - $r['attendu'], 2 );
					if ( abs( $r['ecart'] ) > self::TOLERANCE ) { $nbE++; }
				}
				$tot['attendu'] += $masse( $r['attendu'] ); $tot['officiel'] += $masse( $r['officiel'] );
				$tot['calcule'] += $masse( $r['calcule'] ); $tot['effectif'] += $masse( $r['effectif'] );
				foreach ( $r['sources'] as $id => $v ) { $tot['sources'][ $id ] = ( $tot['sources'][ $id ] ?? 0.0 ) + $masse( $v ); }
			}
			unset( $r );
			ksort( $c, SORT_STRING );
			$tot['ecart'] = $defini ? round( $tot['effectif'] - $tot['attendu'], 2 ) : 0.0;
			foreach ( $tot as $k => $v ) { if ( is_float( $v ) ) { $tot[ $k ] = round( $v, 2 ); } }
			return array( 'comptes' => array_values( $c ), 'sources' => $src, 'totaux' => $tot,
				'attendu_defini' => $defini, 'nb_ecarts' => $nbE, 'report_calcule' => $calc );
		} );
	}

	/** Écritures au journal AN datées du premier jour de l'exercice. */
	public static function anPremierJour( $annee ) {
		try {
			$ids = array_map( 'intval', array_column( FKC_DB::q(
				"SELECT e.id FROM ecritures e JOIN journaux j ON j.id=e.journal_id WHERE j.code='AN' AND e.date_ecriture=? ORDER BY e.id",
				array( self::debutDe( $annee ) )
			)->fetchAll(), 'id' ) );
			return array_values( array_filter( $ids, function ( $id ) { return ! self::estNeutralisee( $id ); } ) );
		} catch ( \Throwable $e ) { return array(); }
	}

	/* ══ Cohérence du pointeur an_ecriture_id ══════════════════════════════ */

	/**
	 * `exercices.an_ecriture_id` désigne-t-il bien l'écriture réellement
	 * générée ?
	 *
	 * @return array{etat:string, pointeur:int|null, reelles:int[], message:string}
	 *   etat : ok | aucun | non_reference | orphelin | divergent | multiples
	 */
	public static function pointeur( $annee ) {
		$annee = (int) $annee;
		$ptr = null; $ligne = false;
		try {
			$r = FKC_DB::q( 'SELECT an_ecriture_id FROM exercices WHERE annee=?', array( $annee ) )->fetch();
			if ( $r ) { $ligne = true; $ptr = ! empty( $r['an_ecriture_id'] ) ? (int) $r['an_ecriture_id'] : null; }
		} catch ( \Throwable $e ) { /* table absente */ }

		// Écritures reconnues SANS le pointeur : référence ou journal/date.
		$reelles = array();
		try {
			foreach ( FKC_DB::q( 'SELECT id FROM ecritures WHERE reference=?', array( self::REF . $annee ) )->fetchAll() as $x ) { $reelles[] = (int) $x['id']; }
		} catch ( \Throwable $e ) { /* ignore */ }
		foreach ( self::anPremierJour( $annee ) as $id ) { if ( ! in_array( $id, $reelles, true ) ) { $reelles[] = $id; } }
		sort( $reelles );

		$existe = false;
		if ( $ptr ) {
			try { $existe = (bool) FKC_DB::q( 'SELECT 1 FROM ecritures WHERE id=?', array( $ptr ) )->fetch(); } catch ( \Throwable $e ) { $existe = false; }
		}

		if ( count( $reelles ) > 1 ) {
			$etat = 'multiples';
			$msg = count( $reelles ) . ' écritures d\'À-nouveaux pour ' . $annee . ' (#' . implode( ', #', $reelles ) . ') : une seule peut être officielle.';
		} elseif ( $ptr && ! $existe ) {
			$etat = 'orphelin';
			$msg = 'L\'exercice ' . $annee . ' référence l\'écriture d\'À-nouveaux #' . $ptr . ', qui n\'existe plus.';
		} elseif ( $ptr && ! in_array( $ptr, $reelles, true ) ) {
			$etat = 'divergent';
			$msg = 'L\'exercice ' . $annee . ' référence l\'écriture #' . $ptr . ', qui n\'est pas une écriture d\'À-nouveaux'
				. ( $reelles ? ' (l\'À-nouveaux réel est #' . $reelles[0] . ')' : '' ) . '.';
		} elseif ( ! $ptr && $reelles ) {
			$etat = 'non_reference';
			$msg = 'L\'écriture d\'À-nouveaux #' . $reelles[0] . ' existe mais n\'est pas référencée par l\'exercice ' . $annee
				. ( $ligne ? '.' : ' (exercice non enregistré).' );
		} elseif ( ! $ptr && ! $reelles ) {
			$etat = 'aucun';
			$msg = 'Aucune écriture d\'À-nouveaux pour ' . $annee . '.';
		} else {
			$etat = 'ok';
			$msg = 'À-nouveaux #' . $ptr . ' correctement référencé par l\'exercice ' . $annee . '.';
		}
		return array( 'etat' => $etat, 'pointeur' => $ptr, 'reelles' => $reelles, 'message' => $msg, 'exercice_enregistre' => $ligne );
	}

	/* ══ Empreinte de la balance source ════════════════════════════════════ */

	/** Empreinte des soldes de clôture d'un exercice (classes 1 à 5). */
	public static function empreinteCloture( $annee ) {
		$m = array();
		foreach ( self::soldesCloture( $annee ) as $num => $r ) { $m[ $num ] = number_format( $r['solde'], 2, '.', '' ); }
		ksort( $m );
		return substr( sha1( (string) json_encode( $m ) ), 0, 16 );
	}

	/** Consigne sur l'exercice l'origine de ses À-nouveaux. */
	public static function tracerGeneration( $annee, $ecritureId, $total ) {
		self::ensure();
		if ( null === $total ) {
			try { $total = (float) FKC_DB::q( 'SELECT COALESCE(SUM(debit),0) FROM ecriture_lignes WHERE ecriture_id=?', array( (int) $ecritureId ) )->fetchColumn(); }
			catch ( \Throwable $e ) { $total = 0.0; }
		}
		try {
			FKC_DB::q(
				'UPDATE exercices SET an_source_exercice=?, an_empreinte=?, an_total=?, an_genere_le=? WHERE annee=?',
				array( (int) $annee - 1, self::empreinteCloture( (int) $annee - 1 ), (float) $total, date( 'Y-m-d H:i:s' ), (int) $annee )
			);
		} catch ( \Throwable $e ) { /* traçabilité best-effort : l'écriture porte déjà sa référence */ }
	}

	/** Trace conservée sur l'exercice, ou null. */
	public static function trace( $annee ) {
		self::ensure();
		try {
			$r = FKC_DB::q( 'SELECT * FROM exercices WHERE annee=?', array( (int) $annee ) )->fetch();
			return $r ?: null;
		} catch ( \Throwable $e ) { return null; }
	}

	/* ══ Rapprochement « ouverture effective » ═════════════════════════════ */

	/**
	 * Confronte la clôture de N-1 à l'ouverture EFFECTIVE de N — report
	 * calculé éventuel et toutes les sources additionnées. C'est ce contrôle
	 * qui voit une reprise de migration posée par-dessus un À-nouveaux (ou
	 * par-dessus un report calculé) : l'À-nouveaux seul concorde, l'ouverture
	 * réelle vaut le double. Lu sur decomposition() depuis la 1.799.0.
	 */
	public static function rapprochementEffectif( $annee ) {
		$annee = (int) $annee;
		$d = self::decomposition( $annee );
		$affect = class_exists( 'FKC_AffectationResultat' ) ? (array) FKC_AffectationResultat::comptesConcernes( $annee - 1 ) : array();
		$ecarts = array();
		if ( $d['attendu_defini'] ) {
			foreach ( $d['comptes'] as $c ) {
				if ( null === $c['ecart'] || abs( $c['ecart'] ) <= self::TOLERANCE || in_array( $c['numero'], $affect, true ) ) { continue; }
				$ecarts[] = array( 'numero' => $c['numero'], 'libelle' => $c['libelle'], 'cloture' => $c['attendu'],
					'ouverture' => $c['effectif'], 'ecart' => round( $c['attendu'] - $c['effectif'], 2 ) );
			}
		}
		return array( 'concordant' => ! $ecarts, 'ecarts' => $ecarts, 'nb_sources' => count( $d['sources'] ),
			'calcule' => $d['report_calcule'] && ! $d['sources'], 'totaux' => $d['totaux'] );
	}

	/* ══ Réparation guidée d'une ouverture ambiguë ═════════════════════════ */

	/**
	 * Ce que donnerait chaque réparation possible, SANS rien écrire.
	 *
	 * Réparer, c'est choisir UNE origine à conserver et contre-passer les
	 * autres. Une option n'est proposée comme valable que si l'ouverture qui
	 * en résulte reprend exactement la clôture de N-1. Conserver la reprise
	 * de migration d'un exercice qui a un passé, par exemple, est refusé :
	 * sans À-nouveaux, le report calculé réapparaît, et la migration s'y
	 * ajoute — le doublon resterait, sous une autre forme.
	 *
	 * `conserver` vaut 0 pour « ne garder que le report calculé » (toutes les
	 * écritures d'ouverture contre-passées), proposé quand il existe un passé.
	 *
	 * @return array<int, array{conserver:int, libelle:string, contrepasser:int[], valable:bool, nb_ecarts:int, effectif:float, raison:string}>
	 */
	public static function optionsReparation( $annee ) {
		$annee = (int) $annee;
		$src = self::sources( $annee );
		$attendu = self::soldesCloture( $annee - 1 );
		$passe = self::passeAvant( self::debutDe( $annee ) ) && (bool) $attendu;
		$carte = self::ecrituresAN( $annee );
		$lignes = array();
		if ( $src ) {
			foreach ( FKC_DB::q(
				'SELECT l.ecriture_id eid, c.numero, COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) s
				 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
				 WHERE l.ecriture_id IN (' . implode( ',', array_map( 'intval', array_column( $src, 'id' ) ) ) . ') AND ' . self::SQL_BILAN . '
				 GROUP BY l.ecriture_id, c.id'
			)->fetchAll() as $r ) { $lignes[ (int) $r['eid'] ][ (string) $r['numero'] ] = round( (float) $r['s'], 2 ); }
		}
		$candidats = array_column( $src, null, 'id' );
		if ( $passe ) { $candidats[0] = array( 'id' => 0, 'libelle_type' => 'Report calculé de la clôture ' . ( $annee - 1 ) ); }
		$out = array();
		foreach ( $candidats as $k => $x ) {
			$k = (int) $k;
			$autres = array_values( array_diff( array_map( 'intval', array_column( $src, 'id' ) ), array( $k ) ) );
			$avecAN = $k > 0 && in_array( $k, $carte, true );
			$eff = array();
			if ( ! $avecAN && $passe ) { foreach ( $attendu as $n => $r ) { $eff[ $n ] = $r['solde']; } }
			if ( $k > 0 ) { foreach ( $lignes[ $k ] ?? array() as $n => $v ) { $eff[ $n ] = ( $eff[ $n ] ?? 0.0 ) + $v; } }
			$nbE = 0; $masse = 0.0;
			foreach ( $eff as $v ) { if ( $v > 0 ) { $masse += $v; } }
			if ( $passe ) {
				foreach ( array_unique( array_merge( array_keys( $attendu ), array_keys( $eff ) ) ) as $n ) {
					if ( abs( (float) ( $eff[ $n ] ?? 0 ) - (float) ( $attendu[ $n ]['solde'] ?? 0 ) ) > self::TOLERANCE ) { $nbE++; }
				}
			}
			$raison = '';
			if ( $nbE ) {
				$raison = ( $k > 0 && ! $avecAN && $passe )
					? 'Sans À-nouveaux, l\'exercice relit la clôture ' . ( $annee - 1 ) . ' : cette écriture s\'y ajouterait — ' . $nbE . ' compte(s) resteraient en écart.'
					: $nbE . ' compte(s) resteraient en écart avec la clôture ' . ( $annee - 1 ) . '.';
			}
			$out[] = array(
				'conserver' => $k, 'libelle' => ( $k > 0 ? $x['libelle_type'] . ' #' . $k : $x['libelle_type'] ),
				'contrepasser' => $autres, 'valable' => 0 === $nbE && ( $autres || $k > 0 ), 'nb_ecarts' => $nbE,
				'effectif' => round( $masse, 2 ), 'raison' => $raison,
			);
		}
		// La recommandation d'abord : l'option valable qui garde l'À-nouveaux officiel.
		usort( $out, function ( $a, $b ) use ( $carte ) {
			$ka = ( $a['valable'] ? 0 : 2 ) + ( in_array( $a['conserver'], $carte, true ) ? 0 : 1 );
			$kb = ( $b['valable'] ? 0 : 2 ) + ( in_array( $b['conserver'], $carte, true ) ? 0 : 1 );
			return $ka <=> $kb;
		} );
		return $out;
	}

	/**
	 * RÉPARE une ouverture ambiguë : conserve une origine, contre-passe les
	 * autres, dans une seule transaction.
	 *
	 * Chaque contre-passation est datée comme sa source, dans son journal,
	 * avec le même numéro et le type « annulation » — la convention de
	 * FKC_EcritureAnnulation, dont elle porte le marqueur : l'écran des
	 * écritures la reconnaît comme telle. Rien n'est supprimé : la source
	 * fautive et son inverse restent visibles au Grand Livre, et c'est ce
	 * couple qui prouve ce qui a été fait.
	 *
	 * Gardes : administrateur, motif écrit, exercice non clôturé, option
	 * valable (l'ouverture résultante reprend la clôture N-1), et contrôle
	 * APRÈS écriture — si l'ouverture n'est pas redevenue unique et
	 * concordante, tout est annulé.
	 *
	 * @param int    $annee
	 * @param int    $conserver id de l'écriture à conserver (0 : le report calculé)
	 * @param string $motif
	 * @return array{bool, string, int[]} ( ok, message, contre-passations créées )
	 */
	public static function reparer( $annee, $conserver, $motif ) {
		$annee = (int) $annee; $conserver = (int) $conserver; $motif = trim( (string) $motif );
		if ( class_exists( 'FKC_Auth' ) && ! FKC_Auth::isAdmin() ) {
			return array( false, 'La réparation d\'une ouverture est réservée à l\'administrateur du dossier.', array() );
		}
		if ( mb_strlen( $motif ) < 20 ) {
			return array( false, 'La réparation contre-passe des écritures d\'ouverture : indiquez le motif (vingt caractères au moins). '
				. 'Il sera consigné au journal de clôture.', array() );
		}
		if ( class_exists( 'FKC_ClotureProcessus' ) && FKC_ClotureProcessus::exerciceClos( $annee ) ) {
			return array( false, 'L\'exercice ' . $annee . ' est clôturé : rouvrez d\'abord sa clôture annuelle. '
				. 'Une ouverture ne se répare pas sous un exercice arrêté.', array() );
		}
		$fb = self::fiabilite( $annee );
		if ( self::E_AMBIGU !== $fb['etat'] && self::decomposition( $annee )['nb_ecarts'] === 0 ) {
			return array( false, 'L\'ouverture de ' . $annee . ' n\'a qu\'une origine et reprend la clôture ' . ( $annee - 1 ) . ' : rien à réparer.', array() );
		}
		$opt = null;
		foreach ( self::optionsReparation( $annee ) as $o ) { if ( $o['conserver'] === $conserver ) { $opt = $o; } }
		if ( ! $opt ) { return array( false, 'L\'écriture #' . $conserver . ' n\'est pas une source d\'ouverture de ' . $annee . '.', array() ); }
		if ( ! $opt['valable'] ) {
			return array( false, 'Réparation refusée : conserver « ' . $opt['libelle'] . ' » ne rétablit pas l\'ouverture. ' . $opt['raison'], array() );
		}

		$src = array_column( self::sources( $annee ), null, 'id' );
		$m = class_exists( 'FKC_EcritureAnnulation' ) ? FKC_EcritureAnnulation::MARQUEUR : 'ANN#';
		try {
			$crees = FKC_Tx::executer( function () use ( $annee, $conserver, $motif, $opt, $src, $m ) {
				$crees = array();
				foreach ( $opt['contrepasser'] as $id ) {
					$e = FKC_DB::q( 'SELECT * FROM ecritures WHERE id=?', array( (int) $id ) )->fetch();
					if ( ! $e ) { throw new \RuntimeException( 'Écriture #' . $id . ' introuvable.' ); }
					$rev = array();
					foreach ( FKC_DB::q( 'SELECT * FROM ecriture_lignes WHERE ecriture_id=? ORDER BY id', array( (int) $id ) )->fetchAll() as $l ) {
						$rev[] = array(
							'compte_id' => (int) $l['compte_id'], 'libelle' => 'Contre-passation — ' . (string) ( $l['libelle'] ?? '' ),
							'debit' => (float) $l['credit'], 'credit' => (float) $l['debit'],
							'division_id' => $l['division_id'] ?? null,
							'tiers_type' => $l['tiers_type'] ?? null, 'tiers_id' => $l['tiers_id'] ?? null,
							'devise' => $l['devise'] ?? null, 'montant_devise' => isset( $l['montant_devise'] ) ? -1 * (float) $l['montant_devise'] : null,
							'taux_change' => $l['taux_change'] ?? null, 'echeance' => $l['echeance'] ?? null,
						);
					}
					$piece = trim( (string) ( $e['piece'] ?? '' ) );
					list( $ok, $msg, $rid ) = FKC_Ecriture::save( array(
						'journal_id' => (int) $e['journal_id'], 'date_ecriture' => (string) $e['date_ecriture'],
						'piece' => '' !== $piece ? 'ANN-' . $piece : null,
						'libelle' => fkc_tronquer( 'Contre-passation — source d\'ouverture en double #' . $id . ' (' . ( $src[ $id ]['libelle_type'] ?? '' ) . ')', 240 ),
						'reference' => $m . $id,
						'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
						'numero' => ! empty( $e['numero'] ) ? (string) $e['numero'] : null,
						'type_ecriture' => class_exists( 'FKC_EcritureNumero' ) ? FKC_EcritureNumero::TYPE_ANNULATION : 'annulation',
						'source' => 'annulation', 'origine' => 'ouverture', 'fait' => 'contrepassation_source',
						// Même garde que les À-nouveaux : refusée si l'exercice est clos.
						'inventaire' => true,
					), $rev );
					if ( ! $ok ) { throw new \RuntimeException( 'Contre-passation de #' . $id . ' impossible : ' . $msg ); }
					$crees[] = (int) $rid;
				}
				self::oublier();

				// L'exercice référence désormais l'À-nouveaux conservé (ou plus rien).
				try {
					$carte = self::ecrituresAN( $annee );
					FKC_DB::q( 'UPDATE exercices SET an_ecriture_id=? WHERE annee=?', array( 1 === count( $carte ) ? (int) $carte[0] : null, $annee ) );
				} catch ( \Throwable $e ) { /* exercice non enregistré */ }
				self::oublier();

				// Le contrôle qui compte : APRÈS écriture, pas avant.
				$apres = self::fiabilite( $annee );
				$dec = self::decomposition( $annee );
				if ( self::E_AMBIGU === $apres['etat'] || $dec['nb_ecarts'] > 0 ) {
					throw new \RuntimeException( 'après contre-passation, l\'ouverture resterait '
						. ( self::E_AMBIGU === $apres['etat'] ? 'ambiguë' : 'en écart sur ' . $dec['nb_ecarts'] . ' compte(s)' ) . '. Rien n\'a été conservé.' );
				}
				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $annee, 'ouverture_reparee', array(
						'issue' => 'avertissement',
						'libelle' => 'Ouverture ' . $annee . ' réparée : conservé ' . $opt['libelle'] . ' ; contre-passé #' . implode( ', #', $opt['contrepasser'] )
							. ' par #' . implode( ', #', $crees ),
						'motif' => $motif,
						'detail' => array( 'conserve' => $conserver, 'contrepasses' => $opt['contrepasser'], 'contrepassations' => $crees ),
					) );
				}
				return $crees;
			} );
		} catch ( \Throwable $e ) {
			self::oublier();
			if ( class_exists( 'FKC_ClotureJournal' ) ) { FKC_ClotureJournal::tracerRefus( $annee, 'ouverture_reparee', $e->getMessage() ); }
			return array( false, 'Réparation refusée : ' . $e->getMessage(), array() );
		}
		self::oublier();
		return array( true, 'Ouverture ' . $annee . ' réparée : ' . $opt['libelle'] . ' conservé ; ' . count( $crees )
			. ' écriture(s) contre-passée(s) (#' . implode( ', #', $opt['contrepasser'] ) . '). L\'ouverture reprend la clôture ' . ( $annee - 1 ) . '.', $crees );
	}

	/* ══ Diagnostic complet — l'Audit des À-nouveaux ═══════════════════════ */

	/**
	 * Tout ce qu'on sait de l'ouverture d'un exercice, en une lecture.
	 *
	 * `statut` : initial | calcule | officiel | anomalie | autre_source | ambigu
	 * (« anomalie » : À-nouveaux officiel unique, mais un autre défaut —
	 * référence, empreinte, écart, héritage).
	 */
	public static function diagnostic( $annee ) {
		$annee = (int) $annee;
		$sources = self::sources( $annee );
		$ptr = self::pointeur( $annee );
		$an = self::ecrituresAN( $annee );
		$fb = self::fiabilite( $annee );
		$dec = self::decomposition( $annee );
		$eff = self::rapprochementEffectif( $annee );
		$rap = ( $an && class_exists( 'FKC_ANouveaux' ) ) ? FKC_ANouveaux::rapprochement( $annee, false ) : null;
		$trace = self::trace( $annee );
		$empAct = self::empreinteCloture( $annee - 1 );
		$empOk = ( $trace && ! empty( $trace['an_empreinte'] ) ) ? ( $trace['an_empreinte'] === $empAct ) : null;
		$premier = self::anPremierJour( $annee );

		$anom = array();
		$add = function ( $niveau, $code, $texte ) use ( &$anom ) { $anom[] = array( 'niveau' => $niveau, 'code' => $code, 'texte' => $texte ); };

		if ( self::E_AMBIGU === $fb['etat'] ) {
			$add( 'critique', 'sources_multiples', $fb['raisons'][0] . ' Le solde d\'ouverture n\'est pas fiable : il n\'est jamais présenté comme normal.' );
		}
		if ( count( $premier ) > 1 ) {
			$add( 'critique', 'an_premier_jour', count( $premier ) . ' écritures au journal AN le ' . date( 'd/m/Y', strtotime( self::debutDe( $annee ) ) ) . ' (#' . implode( ', #', $premier ) . ').' );
		}
		if ( in_array( $ptr['etat'], array( 'orphelin', 'divergent', 'non_reference' ), true ) ) {
			$add( 'haute', 'pointeur_' . $ptr['etat'], $ptr['message'] );
		}
		if ( $rap && empty( $rap['concordant'] ) ) {
			$add( 'critique', 'cloture_ouverture', 'Clôture ' . ( $annee - 1 ) . ' ≠ À-nouveaux ' . $annee . ' : ' . $rap['message'] );
		}
		if ( ! $eff['concordant'] && ( ! $rap || ! empty( $rap['concordant'] ) ) ) {
			$t = $dec['totaux'];
			$add( 'critique', 'ouverture_effective', 'Ouverture effective ' . $annee . ' ≠ clôture ' . ( $annee - 1 ) . ' : attendu '
				. fkc_money( $t['attendu'] ) . ', effectif ' . fkc_money( $t['effectif'] ) . ', écart ' . ( $t['ecart'] >= 0 ? '+' : '' ) . fkc_money( $t['ecart'] )
				. ' sur ' . count( $eff['ecarts'] ) . ' compte(s).' );
		}
		if ( $fb['herite'] ) {
			$add( 'critique', 'herite', 'L\'ouverture reprend la clôture de ' . ( $annee - 1 ) . ', dont l\'ouverture n\'est pas fiable : réparez d\'abord ' . ( $annee - 1 ) . '.' );
		}
		foreach ( $sources as $s ) {
			if ( self::D_LIBELLE === $s['detection'] ) {
				$add( 'moyenne', 'detection_libelle', 'L\'écriture #' . $s['id'] . ' n\'est reconnue comme source d\'ouverture que par son libellé ('
					. $s['libelle'] . ') : qualifiez-la (source ou non) pour que la décision ne dépende plus d\'un texte.' );
			}
		}
		if ( self::E_CALCULE === $fb['etat'] && self::exerciceMouvemente( $annee ) ) {
			$add( 'moyenne', 'solde_calcule', 'Aucun À-nouveaux : les états de ' . $annee . ' utilisent un solde d\'ouverture calculé depuis la clôture de ' . ( $annee - 1 ) . '.' );
		}
		if ( false === $empOk ) {
			$add( 'haute', 'empreinte', 'La balance de clôture de ' . ( $annee - 1 ) . ' a changé depuis la génération des À-nouveaux ('
				. date( 'd/m/Y', strtotime( (string) $trace['an_genere_le'] ) ) . ').' );
		}

		switch ( $fb['etat'] ) {
			case self::E_AN:     $statut = $anom ? 'anomalie' : 'officiel'; break;
			case self::E_AMBIGU: $statut = 'ambigu'; break;
			default:             $statut = ( $fb['herite'] || ! $eff['concordant'] ) ? 'anomalie' : $fb['etat'];
		}

		return array(
			'exercice' => $annee, 'debut' => self::debutDe( $annee ), 'statut' => $statut, 'etat' => $fb['etat'],
			'fiable' => $fb['fiable'], 'raisons' => $fb['raisons'], 'herite' => $fb['herite'],
			'an_officiel' => self::anOfficiel( $annee ), 'sources' => $sources, 'pointeur' => $ptr,
			'rapprochement' => $rap, 'effectif' => $eff, 'decomposition' => $dec, 'trace' => $trace,
			'empreinte_actuelle' => $empAct, 'empreinte_a_jour' => $empOk,
			'anomalies' => $anom, 'lignes' => self::lignesAudit( $annee ),
			'reparation' => ( self::E_AMBIGU === $fb['etat'] || ! $eff['concordant'] ) ? self::optionsReparation( $annee ) : array(),
		);
	}

	/**
	 * Lignes de toutes les sources d'ouverture : compte, montant, journal,
	 * référence, exercice et origine de chaque À-nouveaux.
	 */
	public static function lignesAudit( $annee ) {
		$src = array();
		foreach ( self::sources( $annee ) as $s ) { $src[ $s['id'] ] = $s; }
		if ( ! $src ) { return array(); }
		$rows = FKC_DB::q(
			'SELECT l.ecriture_id, c.numero, c.libelle compte, l.libelle, l.debit, l.credit, l.tiers_type, l.tiers_id, l.devise
			 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
			 WHERE l.ecriture_id IN (' . implode( ',', array_map( 'intval', array_keys( $src ) ) ) . ')
			 ORDER BY c.numero, l.ecriture_id, l.id'
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$s = $src[ (int) $r['ecriture_id'] ];
			$out[] = array(
				'numero' => (string) $r['numero'], 'compte' => (string) $r['compte'], 'libelle' => (string) $r['libelle'],
				'debit' => (float) $r['debit'], 'credit' => (float) $r['credit'],
				'journal' => $s['journal'], 'reference' => $s['reference'] ?: $s['piece'], 'ecriture_id' => $s['id'],
				'exercice' => (int) $annee, 'origine' => $s['libelle_type'], 'type' => $s['type'],
				'tiers' => ! empty( $r['tiers_id'] ) ? ( $r['tiers_type'] . ' #' . (int) $r['tiers_id'] ) : '',
				'devise' => (string) ( $r['devise'] ?? '' ),
			);
		}
		return $out;
	}

	protected static function exerciceMouvemente( $annee ) {
		list( $d, $f ) = self::bornes( $annee );
		try { return (bool) FKC_DB::q( 'SELECT 1 FROM ecritures WHERE date_ecriture BETWEEN ? AND ? LIMIT 1', array( $d, $f ) )->fetch(); }
		catch ( \Throwable $e ) { return false; }
	}

	/** Exercices à passer en revue à l'écran d'audit, du plus récent au plus ancien. */
	public static function exercicesAudites() {
		$ys = array();
		if ( class_exists( 'FKC_Exercice' ) ) { foreach ( FKC_Exercice::annees() as $y ) { $ys[] = (int) $y; } }
		foreach ( array_keys( self::carteAN() ) as $y ) { $ys[] = (int) $y; }
		$ys = array_values( array_unique( array_filter( $ys ) ) );
		rsort( $ys );
		return $ys;
	}
}
