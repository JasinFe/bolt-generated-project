<?php
/** Comptes du cabinet & rôles (accès par module + par société). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_User {

	/** Modèles de rôles (fonction → modules par défaut). 'admin'=true => accès total. */
	public static function roles() {
		return array(
			'admin'        => array( 'label' => 'Administrateur', 'admin' => true,  'modules' => null ),
			'comptable'    => array( 'label' => 'Comptable',      'admin' => false, 'modules' => array( 'comptabilite', 'fiscalite', 'facturation' ) ),
			'tresorier'    => array( 'label' => 'Trésorier / Caissier', 'admin' => false, 'modules' => array( 'comptabilite', 'facturation' ) ),
			'fiscaliste'   => array( 'label' => 'Fiscaliste',     'admin' => false, 'modules' => array( 'fiscalite', 'comptabilite' ) ),
			'commercial'   => array( 'label' => 'Commercial',     'admin' => false, 'modules' => array( 'facturation', 'recouvrement', 'inventaire' ) ),
			'caissier'     => array( 'label' => 'Caissier / Caissière', 'admin' => false, 'modules' => array( 'caisse', 'scan' ) ),
			'rh_paie'      => array( 'label' => 'RH & Paie',      'admin' => false, 'modules' => array( 'rh', 'paie' ) ),
			'direction'    => array( 'label' => 'Direction',      'admin' => false, 'modules' => array( 'comptabilite', 'fiscalite', 'facturation', 'inventaire', 'recouvrement', 'rh', 'paie', 'royalties' ) ),
			'personnalise' => array( 'label' => 'Personnalisé',   'admin' => false, 'modules' => array() ),
		);
	}
	public static function roleLabel( $key, $fallback = '' ) {
		$r = self::roles(); return isset( $r[ $key ] ) ? $r[ $key ]['label'] : ( $fallback ?: ucfirst( (string) $key ) );
	}

	public static function all() {
		return FKC_Master::q( 'SELECT id,login,nom_complet,email,role,role_libelle,modules,cockpits,actif,derniere_cnx FROM cabinet_users ORDER BY role!=\'admin\', nom_complet ASC' )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_Master::q( 'SELECT * FROM cabinet_users WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function loginExists( $login, $exceptId = 0 ) {
		return (bool) FKC_Master::q( 'SELECT 1 FROM cabinet_users WHERE login=? AND id<>?', array( $login, (int) $exceptId ) )->fetch();
	}
	public static function countAdmins( $actifOnly = true ) {
		$w = $actifOnly ? 'AND actif=1' : '';
		return (int) FKC_Master::q( "SELECT COUNT(*) FROM cabinet_users WHERE role='admin' {$w}" )->fetchColumn();
	}
	/** Nombre total d'utilisateurs (pour les quotas de licence). */
	public static function count( $actifOnly = false ) {
		$w = $actifOnly ? 'WHERE actif=1' : '';
		return (int) FKC_Master::q( "SELECT COUNT(*) FROM cabinet_users {$w}" )->fetchColumn();
	}
	public static function modulesOf( $row ) {
		if ( 'admin' === ( $row['role'] ?? '' ) ) { return array_keys( FKC_Modules::catalog() ); }
		$m = ! empty( $row['modules'] ) ? json_decode( $row['modules'], true ) : array();
		return is_array( $m ) ? $m : array();
	}

	/**
	 * Cockpits du Centre de Pilotage attribués à l'utilisateur (Paramètres →
	 * Utilisateurs). Liste vide = aucun choix explicite : les cockpits sont
	 * alors déduits du rôle (comportement automatique).
	 */
	public static function cockpitsOf( $row ) {
		$c = ! empty( $row['cockpits'] ) ? json_decode( $row['cockpits'], true ) : array();
		return is_array( $c ) ? array_values( array_filter( array_map( 'strval', $c ) ) ) : array();
	}

	/** Assainit une liste de codes de cockpits postée (a-z, 0-9, _). */
	protected static function cockpitsPropres( $liste ) {
		$out = array();
		foreach ( (array) $liste as $c ) {
			$c = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) $c ) );
			if ( '' !== $c ) { $out[ $c ] = $c; }
		}
		return array_values( $out );
	}

	/* ── Accès par société (utilisateurs non-admin) ── */

	/** Identifiants des sociétés autorisées pour un utilisateur. */
	public static function societesOf( $userId ) {
		$rows = FKC_Master::q( 'SELECT societe_id FROM societe_acces WHERE user_id=?', array( (int) $userId ) )->fetchAll();
		return array_map( function ( $r ) { return (int) $r['societe_id']; }, $rows );
	}
	/** Remplace la liste des sociétés autorisées d'un utilisateur. */
	public static function setSocietes( $userId, $ids ) {
		$userId = (int) $userId;
		FKC_Master::q( 'DELETE FROM societe_acces WHERE user_id=?', array( $userId ) );
		$ins = FKC_Master::conn()->prepare( 'INSERT OR IGNORE INTO societe_acces(user_id,societe_id) VALUES(?,?)' );
		foreach ( (array) $ids as $sid ) { $ins->execute( array( $userId, (int) $sid ) ); }
	}

	/**
	 * Comptes du cabinet ayant accès à une société donnée — administrateurs
	 * (accès total, implicite) + utilisateurs explicitement autorisés. C'est
	 * le vivier dans lequel l'écran « Rôles » (FKC_RoleEngine) puise pour
	 * proposer une attribution : un rôle n'a de sens que pour quelqu'un qui
	 * peut déjà entrer dans le dossier.
	 */
	public static function utilisateursDeSociete( $societeId ) {
		$admins = FKC_Master::q( "SELECT * FROM cabinet_users WHERE role='admin' AND actif=1 ORDER BY nom_complet" )->fetchAll();
		$autres = FKC_Master::q(
			"SELECT u.* FROM cabinet_users u
			 JOIN societe_acces sa ON sa.user_id=u.id
			 WHERE sa.societe_id=? AND u.role<>'admin' AND u.actif=1 ORDER BY u.nom_complet",
			array( (int) $societeId )
		)->fetchAll();
		return array_merge( $admins, $autres );
	}

	public static function create( $d ) {
		$isAdmin = 'admin' === ( $d['role'] ?? '' );
		FKC_Master::q(
			'INSERT INTO cabinet_users(login,nom_complet,email,password_hash,role,role_libelle,modules,cockpits,actif) VALUES(?,?,?,?,?,?,?,?,?)',
			array(
				trim( (string) $d['login'] ), trim( (string) $d['nom_complet'] ), trim( (string) ( $d['email'] ?? '' ) ) ?: null,
				password_hash( (string) $d['password'], PASSWORD_DEFAULT ),
				$isAdmin ? 'admin' : 'user',
				self::roleLabel( $d['role'] ?? 'personnalise' ),
				$isAdmin ? null : json_encode( array_values( (array) ( $d['modules'] ?? array() ) ) ),
				$isAdmin ? null : ( ( $ckps = self::cockpitsPropres( $d['cockpits'] ?? array() ) ) ? json_encode( $ckps ) : null ),
				empty( $d['actif'] ) ? 0 : 1,
			)
		);
		$id = (int) FKC_Master::conn()->lastInsertId();
		if ( ! $isAdmin ) { self::setSocietes( $id, $d['societes'] ?? array() ); }
		return $id;
	}

	public static function update( $id, $d ) {
		$isAdmin = 'admin' === ( $d['role'] ?? '' );
		$sql = 'UPDATE cabinet_users SET nom_complet=?, email=?, role=?, role_libelle=?, modules=?, cockpits=?, actif=?';
		$args = array(
			trim( (string) $d['nom_complet'] ), trim( (string) ( $d['email'] ?? '' ) ) ?: null,
			$isAdmin ? 'admin' : 'user', self::roleLabel( $d['role'] ?? 'personnalise' ),
			$isAdmin ? null : json_encode( array_values( (array) ( $d['modules'] ?? array() ) ) ),
			$isAdmin ? null : ( ( $ckps = self::cockpitsPropres( $d['cockpits'] ?? array() ) ) ? json_encode( $ckps ) : null ),
			empty( $d['actif'] ) ? 0 : 1,
		);
		if ( ! empty( $d['password'] ) ) {
			$sql .= ', password_hash=?'; $args[] = password_hash( (string) $d['password'], PASSWORD_DEFAULT );
		}
		$sql .= ' WHERE id=?'; $args[] = (int) $id;
		FKC_Master::q( $sql, $args );
		if ( $isAdmin ) { FKC_Master::q( 'DELETE FROM societe_acces WHERE user_id=?', array( (int) $id ) ); }
		else { self::setSocietes( $id, $d['societes'] ?? array() ); }
	}

	public static function delete( $id ) {
		FKC_Master::q( 'DELETE FROM societe_acces WHERE user_id=?', array( (int) $id ) );
		FKC_Master::q( 'DELETE FROM cabinet_users WHERE id=?', array( (int) $id ) );
	}

	/** Devine la clé de rôle depuis le libellé enregistré (pour pré-sélection du formulaire). */
	public static function roleKey( $row ) {
		if ( 'admin' === ( $row['role'] ?? '' ) ) { return 'admin'; }
		foreach ( self::roles() as $k => $r ) {
			if ( ! $r['admin'] && $r['label'] === ( $row['role_libelle'] ?? '' ) ) { return $k; }
		}
		return 'personnalise';
	}
}
