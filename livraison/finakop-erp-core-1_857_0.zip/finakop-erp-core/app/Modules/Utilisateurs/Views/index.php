<?php /** @var array $users @var array $roles @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$cat = FKC_Modules::catalog(); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<div><span class="stat-label">Comptes utilisateurs</span> <strong style="font-size:18px"><?= count($users) ?></strong></div>
	<a class="btn btn-primary btn-sm" href="<?= e( url('utilisateurs/nouveau') ) ?>">+ Nouvel utilisateur</a>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : nom, e-mail, rôle…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Utilisateur</th><th>Identifiant</th><th>Rôle / fonction</th><th>Accès modules</th><th>Statut</th><th>Dernière connexion</th><th></th></tr></thead>
	<tbody>
	<?php foreach ( $users as $u ) : $isAdmin='admin'===$u['role']; $mods=FKC_User::modulesOf($u); ?>
		<tr>
			<td><strong><?= e($u['nom_complet']) ?></strong><?php if($u['email']):?><br><span class="muted" style="font-size:11px"><?= e($u['email']) ?></span><?php endif;?></td>
			<td><span class="code"><?= e($u['login']) ?></span></td>
			<td><span class="modbadge <?= $isAdmin?'b-on':'b-off' ?>"><?= e($u['role_libelle'] ?: ($isAdmin?'Administrateur':'Utilisateur')) ?></span></td>
			<td><?php if($isAdmin):?><span class="muted">Tous les modules</span><?php else: foreach($mods as $m): if(isset($cat[$m])):?><span class="mtag"><?= $cat[$m]['icon'] ?> <?= e($cat[$m]['label']) ?></span><?php endif; endforeach; if(!$mods):?><span class="muted">—</span><?php endif; endif;?></td>
			<td><span class="modbadge <?= $u['actif']?'b-on':'b-off' ?>"><?= $u['actif']?'Actif':'Inactif' ?></span></td>
			<td class="muted"><?= $u['derniere_cnx']?e(date('d/m/Y H:i',strtotime($u['derniere_cnx']))):'jamais' ?></td>
			<td class="right">
				<a class="btn btn-ghost btn-sm" href="<?= e( url('utilisateurs/'.$u['id'].'/modifier') ) ?>">Éditer</a>
				<?php if((int)$u['id']!==(int)FKC_Auth::id()):?>
				<form method="post" action="<?= e( url('utilisateurs/'.$u['id'].'/supprimer') ) ?>" onsubmit="return confirm('Supprimer cet utilisateur ?')" style="display:inline;margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" style="border-color:var(--danger);color:var(--danger)">Suppr.</button></form>
				<?php endif;?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table></div>
<p class="help" style="margin-top:12px">L'administrateur attribue à chaque utilisateur un rôle (sa fonction) et les modules auxquels il a accès. Un utilisateur ne voit et n'utilise que les modules autorisés ; seul l'administrateur gère les comptes.</p>
<style>.mtag{display:inline-block;background:var(--bg2);border:1px solid var(--line);border-radius:6px;padding:2px 7px;font-size:11px;margin:2px 3px 2px 0}</style>
