<?php /** @var array|null $u @var array $errors @var array $roles @var array $catalog @var array $dispo @var string $sel_role @var array $sel_mods @var array $societes @var array $sel_soc @var array $cockpits @var array $sel_ckps */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); $ed=(bool)$u; ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:780px"><div class="card-head"><h2><?= $ed?'Modifier l\'utilisateur':'Nouvel utilisateur' ?></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url('utilisateurs') ) ?>">← Retour</a></div><div class="card-body">
<form method="post" action="<?= e( $ed?url('utilisateurs/'.$u['id']):url('utilisateurs') ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
		<label class="fld"><span>Identifiant (login)</span><input name="login" value="<?= e($ed?$u['login']:'') ?>" <?= $ed?'readonly style="opacity:.6"':'required' ?>></label>
		<label class="fld"><span>Nom complet</span><input name="nom_complet" value="<?= e($ed?$u['nom_complet']:'') ?>" required></label>
		<label class="fld"><span>Email</span><input type="email" name="email" value="<?= e($ed?$u['email']:'') ?>"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Mot de passe <?= $ed?'(laisser vide pour conserver)':'' ?></span><input type="password" name="password" <?= $ed?'':'required' ?> autocomplete="new-password"></label>
		<label class="fld"><span>Rôle / fonction</span><select name="role" id="roleSel">
			<?php foreach ( $roles as $k=>$r ): ?><option value="<?= e($k) ?>" <?= $sel_role===$k?'selected':'' ?>><?= e($r['label']) ?></option><?php endforeach; ?>
		</select></label>
	</div>

	<div class="mod-block" id="modBlock">
		<div class="stat-label" style="margin-bottom:8px">Accès aux modules</div>
		<div class="mod-grid">
		<?php foreach ( $dispo as $code ): if(!isset($catalog[$code])) continue; $isSub = ! empty( $catalog[$code]['sub'] ); ?>
			<label class="mod-check<?= $isSub ? ' mod-sub' : '' ?>" data-code="<?= e($code) ?>" <?= $isSub ? 'data-parent="'.e($catalog[$code]['parent']).'" style="margin-left:22px;opacity:.95"' : '' ?>><input type="checkbox" name="modules[]" value="<?= e($code) ?>" <?= in_array($code,$sel_mods,true)?'checked':'' ?>> <span><?= $isSub ? '↳ ' : '' ?><?= $catalog[$code]['icon'] ?> <?= e($catalog[$code]['label']) ?></span></label>
		<?php endforeach; ?>
		</div>
		<p class="help" style="margin-top:6px">Sous la Comptabilité, vous pouvez attribuer des <strong>sous‑modules</strong> (Comptabilité Clients, Comptabilité Fournisseurs, Service Achat, Trésorerie) pour des rôles ciblés. Cocher la Comptabilité sans sous‑module = accès complet ; cocher un ou plusieurs sous‑modules = accès restreint à ces domaines (le grand livre et les états restent réservés à la Comptabilité complète).</p>
		<p class="help" id="adminNote" style="display:none;margin-top:8px">Le rôle Administrateur donne accès à <strong>tous les modules</strong>, à la gestion des utilisateurs et à <strong>toutes les entités</strong>.</p>
	</div>

	<div class="mod-block" id="socBlock" style="margin-top:14px">
		<div class="stat-label" style="margin-bottom:8px">Entités accessibles</div>
		<?php if ( ! $societes ) : ?>
			<p class="help" style="margin:0">Aucune entité créée pour l'instant.</p>
		<?php else : ?>
			<div class="mod-grid">
			<?php foreach ( $societes as $so ): if ( ! $so['actif'] ) continue; ?>
				<label class="mod-check"><input type="checkbox" name="societes[]" value="<?= e($so['id']) ?>" <?= in_array((int)$so['id'],array_map('intval',$sel_soc),true)?'checked':'' ?>> <span>🏢 <?= e($so['raison_sociale']) ?></span></label>
			<?php endforeach; ?>
			</div>
			<p class="help" id="socAdminNote" style="display:none;margin-top:8px">Les administrateurs accèdent automatiquement à toutes les entités.</p>
		<?php endif; ?>
	</div>

	<div class="mod-block" id="ckpBlock" style="margin-top:14px">
		<div class="stat-label" style="margin-bottom:8px">Cockpits du Centre de Pilotage</div>
		<?php if ( empty( $cockpits ) ) : ?>
			<p class="help" style="margin:0">Aucun cockpit déclaré.</p>
		<?php else : ?>
			<div class="mod-grid">
			<?php foreach ( $cockpits as $ck => $cdef ) : ?>
				<label class="mod-check"><input type="checkbox" name="cockpits[]" value="<?= e( $ck ) ?>" <?= in_array( $ck, $sel_ckps, true ) ? 'checked' : '' ?>> <span><?= e( $cdef['icone'] ?? '🧭' ) ?> <?= e( $cdef['label'] ?? $ck ) ?></span></label>
			<?php endforeach; ?>
			</div>
			<p class="help" style="margin-top:6px">Vous pouvez attribuer <strong>plusieurs cockpits</strong> à un même utilisateur : il naviguera entre eux par onglets, le <strong>premier</strong> (dans l'ordre ci‑dessus) étant son écran d'accueil. <strong>Aucune case cochée</strong> = attribution automatique selon le rôle (Comptable/Trésorier/Fiscaliste → Finance, Commercial → Commercial + Stock, RH &amp; Paie → RH, Direction → tous). Un cockpit dont le module n'est pas couvert par la licence reste masqué.</p>
			<p class="help" id="ckpAdminNote" style="display:none;margin-top:8px">Les administrateurs accèdent automatiquement à <strong>tous les cockpits</strong>.</p>
		<?php endif; ?>
	</div>

	<label class="chk" style="margin-top:12px"><input type="checkbox" name="actif" value="1" <?= (!$ed || $u['actif'])?'checked':'' ?>> Compte actif</label>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $ed?'Enregistrer':'Créer l\'utilisateur' ?></button><a class="btn btn-ghost" href="<?= e( url('utilisateurs') ) ?>">Annuler</a></div>
</form>
</div></div>
<script>
(function(){
	var presets = <?= json_encode( array_map( function($r){ return $r['admin'] ? '__ALL__' : $r['modules']; }, $roles ) ) ?>;
	var sel=document.getElementById('roleSel'), block=document.getElementById('modBlock'), note=document.getElementById('adminNote');
	var socBlock=document.getElementById('socBlock'), socNote=document.getElementById('socAdminNote');
	var ckpBlock=document.getElementById('ckpBlock'), ckpNote=document.getElementById('ckpAdminNote');
	var boxes=function(){return block.querySelectorAll('input[type=checkbox]');};
	var socBoxes=function(){return socBlock?socBlock.querySelectorAll('input[type=checkbox]'):[];};
	var ckpBoxes=function(){return ckpBlock?ckpBlock.querySelectorAll('input[type=checkbox]'):[];};
	function apply(preset, fromChange){
		var isAdmin = (preset==='__ALL__');
		if(isAdmin){ boxes().forEach(function(b){b.checked=true;b.disabled=true;}); note.style.display='block'; }
		else { note.style.display='none'; boxes().forEach(function(b){ b.disabled=false; if(fromChange){ b.checked = Array.isArray(preset) && preset.indexOf(b.value)>=0; } }); }
		if(socBlock){
			socBoxes().forEach(function(b){ b.disabled=isAdmin; if(isAdmin){ b.checked=false; } });
			if(socNote) socNote.style.display = isAdmin?'block':'none';
		}
		if(ckpBlock){
			ckpBoxes().forEach(function(b){ b.disabled=isAdmin; if(isAdmin){ b.checked=false; } });
			if(ckpNote) ckpNote.style.display = isAdmin?'block':'none';
		}
	}
	sel.addEventListener('change', function(){ apply(presets[sel.value], true); });
	// état initial
	var isNew = <?= $ed ? 'false' : 'true' ?>;
	if(presets[sel.value]==='__ALL__'){ apply('__ALL__', false); }
	else if(isNew){ apply(presets[sel.value], true); }
})();
</script>
<style>
.mod-block{background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:14px;margin-top:6px}
.mod-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px}
.mod-check{display:flex;align-items:center;gap:8px;font-size:14px;padding:6px 8px;background:var(--panel);border:1px solid var(--line);border-radius:8px;cursor:pointer}
.chk{display:flex;align-items:center;gap:8px;font-size:14px}
</style>
