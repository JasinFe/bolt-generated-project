<?php
/** Gestion des utilisateurs (réservé à l'administrateur). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_UserController {

	public function index() {
		FKC_View::render( 'utilisateurs::index', array(
			'title' => 'Utilisateurs', 'users' => FKC_User::all(),
			'roles' => FKC_User::roles(), 'flash' => $this->flash(),
		) );
	}

	public function create() {
		$this->form( null, array() );
	}
	public function edit( $id ) {
		$u = FKC_User::find( $id );
		if ( ! $u ) { redirect( 'utilisateurs' ); }
		$this->form( $u, array() );
	}
	protected function form( $u, $errors ) {
		$licence = FKC_License::resolve();
		$licMods = $licence['modules'] ?? array();
		// Catalogue enrichi des sous-modules (pour libellés/icônes dans le formulaire).
		$catalog = FKC_Modules::catalog();
		foreach ( FKC_Modules::subModulesMap() as $code => $info ) {
			$catalog[ $code ] = array( 'label' => $info['label'], 'icon' => $info['icon'], 'order' => $info['order'], 'sub' => true, 'parent' => $info['parent'] );
		}
		FKC_View::render( 'utilisateurs::form', array(
			'title'    => $u ? "Modifier l'utilisateur" : 'Nouvel utilisateur',
			'u'        => $u, 'errors' => $errors,
			'roles'    => FKC_User::roles(),
			'catalog'  => $catalog,
			'dispo'    => FKC_Modules::assignable( $licMods ),
			'sel_role' => $u ? FKC_User::roleKey( $u ) : 'comptable',
			'sel_mods' => $u ? FKC_User::modulesOf( $u ) : array(),
			'societes' => FKC_Societe::all(),
			'sel_soc'  => $u ? FKC_User::societesOf( $u['id'] ) : array(),
			'cockpits' => class_exists( 'FKC_Cockpit' ) ? FKC_Cockpit::tous() : array(),
			'sel_ckps' => $u ? FKC_User::cockpitsOf( $u ) : array(),
		) );
	}

	public function store() {
		$errors = $this->validate( $_POST, 0, true );
		if ( ! FKC_License::within( 'utilisateurs', FKC_User::count() ) ) {
			$errors[] = 'Limite atteinte : votre licence autorise ' . FKC_License::limit( 'utilisateurs' ) . ' utilisateur(s). Passez à un palier supérieur pour en ajouter.';
		}
		if ( $errors ) { return $this->form( null, $errors ); }
		FKC_User::create( $_POST );
		$this->setFlash( 'Utilisateur « ' . trim( $_POST['nom_complet'] ) . ' » créé.' );
		if ( class_exists( 'FKC_Notification' ) && class_exists( 'FKC_Tenant' ) && FKC_Tenant::current() ) {
			try {
				FKC_Notification::notifyAdmins( 'Nouvel utilisateur créé', trim( (string) ( $_POST['nom_complet'] ?? '' ) ) . ' · rôle ' . ( $_POST['role'] ?? '' ), 'alerte', 'utilisateurs' );
			} catch ( \Throwable $e ) { /* contexte sans entité active : on ignore */ }
		}
		redirect( 'utilisateurs' );
	}

	public function update( $id ) {
		$u = FKC_User::find( $id );
		if ( ! $u ) { redirect( 'utilisateurs' ); }
		$errors = $this->validate( $_POST, (int) $id, false );
		// Garde-fou : ne pas rétrograder / désactiver le dernier administrateur.
		$resteAdmin = 'admin' === ( $_POST['role'] ?? '' ) && ! empty( $_POST['actif'] );
		if ( 'admin' === $u['role'] && ! $resteAdmin && FKC_User::countAdmins() <= 1 ) {
			$errors[] = 'Impossible : il doit rester au moins un administrateur actif.';
		}
		if ( $errors ) { return $this->form( $u, $errors ); }
		FKC_User::update( $id, $_POST );
		$this->setFlash( 'Utilisateur mis à jour.' );
		redirect( 'utilisateurs' );
	}

	public function delete( $id ) {
		$u = FKC_User::find( $id );
		if ( ! $u ) { redirect( 'utilisateurs' ); }
		if ( (int) $id === (int) FKC_Auth::id() ) {
			$this->setFlash( 'Vous ne pouvez pas supprimer votre propre compte.', 'err' );
			redirect( 'utilisateurs' );
		}
		if ( 'admin' === $u['role'] && FKC_User::countAdmins( false ) <= 1 ) {
			$this->setFlash( 'Impossible de supprimer le dernier administrateur.', 'err' );
			redirect( 'utilisateurs' );
		}
		FKC_User::delete( $id );
		$this->setFlash( 'Utilisateur supprimé.' );
		redirect( 'utilisateurs' );
	}

	protected function validate( $d, $id, $isNew ) {
		$e = array();
		if ( '' === trim( (string) ( $d['login'] ?? '' ) ) && $isNew ) { $e[] = "L'identifiant est requis."; }
		if ( '' === trim( (string) ( $d['nom_complet'] ?? '' ) ) ) { $e[] = 'Le nom complet est requis.'; }
		if ( $isNew ) {
			if ( strlen( (string) ( $d['password'] ?? '' ) ) < 6 ) { $e[] = 'Le mot de passe doit faire au moins 6 caractères.'; }
			if ( FKC_User::loginExists( trim( (string) ( $d['login'] ?? '' ) ), 0 ) ) { $e[] = 'Cet identifiant est déjà utilisé.'; }
		} elseif ( ! empty( $d['password'] ) && strlen( (string) $d['password'] ) < 6 ) {
			$e[] = 'Le nouveau mot de passe doit faire au moins 6 caractères.';
		}
		if ( empty( $d['role'] ) ) { $e[] = 'Sélectionnez un rôle.'; }
		return $e;
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_usr'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_usr'] ?? null; unset( $_SESSION['__flash_usr'] ); return $m; }
}
