<?php /** @var string $tab */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$onglets = array(
	'workspace'  => array( '🧭', 'Scan Workspace', 'scan/workspace' ), // 1.828.0 — tout le geste de scan sur un écran
	'console'    => array( '🔍', 'Console de scan', 'scan' ),
	'smart'      => array( '📡', 'Smart Scan', 'scan/smart' ),
	'generateur' => array( '🏷️', 'Générateur', 'scan/generateur' ),
	'etiquettes' => array( '🖨️', 'Étiquettes', 'scan/etiquettes' ),
	'processus'  => array( '⛓️', 'Processus', 'scan/processus' ),
	'journal'    => array( '📜', 'Historique', 'scan/journal' ),
);
?>
<div class="subnav">
	<div class="subnav-title"><span class="subnav-ico">🔍</span> Scan &amp; Identification</div>
	<nav class="subnav-tabs">
		<?php foreach ( $onglets as $k => $o ) : ?>
			<a class="subnav-tab<?= $tab === $k ? ' on' : '' ?>" href="<?= e( url( $o[2] ) ) ?>"><?= $o[0] ?> <?= e( $o[1] ) ?></a>
		<?php endforeach; ?>
	</nav>
</div>
<?php /* Mise en forme : voir « Subnav » dans assets/css/app.css. Elle vivait ici,
   en double avec le partiel du Scan, et redéfinissait .subnav sans redonner de
   `display` — la règle globale `display:flex` survivait et couchait le titre à
   côté des onglets. Une seule source, désormais. */ ?>
