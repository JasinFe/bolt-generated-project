<?php
/**
 * Boîte « Scanner ou rechercher… » — le composant partagé.
 *
 * @var string|null $contexte  Contexte forcé ; laissé vide, le moteur le devine.
 * @var string|null $route     Route de l'écran appelant (sinon devinée).
 * @var string|null $invite    Texte de l'invite (sinon celui du contexte).
 * @var string|null $cible     Fonction JS appelée avec le résultat : window[$cible](res).
 * @var bool|null   $autofocus
 *
 * POURQUOI UN SEUL CHAMP
 *
 * Les écrans avaient jusqu'ici deux boîtes — « scanner » et « rechercher » —
 * alors que l'utilisateur ne fait qu'une chose : désigner un article. Le
 * partage lui imposait de savoir à l'avance s'il avait une étiquette lisible,
 * et de recommencer dans l'autre champ quand ce n'était pas le cas.
 *
 * Ici, le moteur tranche : il lit d'abord la saisie comme un code — c'est le
 * cas pressé, un scanner de comptoir envoie sa chaîne suivie d'un retour
 * chariot sans laisser le temps de choisir — puis, à défaut, comme du texte.
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$sbCtx    = isset( $contexte ) ? (string) $contexte : '';
$sbRoute  = isset( $route ) ? (string) $route : ( class_exists( 'FKC_ScanContexte' ) ? FKC_ScanContexte::routeCourante() : '' );
$sbDev    = class_exists( 'FKC_ScanContexte' ) ? FKC_ScanContexte::deviner( $sbCtx, $sbRoute ) : array( 'contexte' => 'controle', 'source' => 'defaut' );
$sbInvite = isset( $invite ) ? (string) $invite : ( class_exists( 'FKC_ScanContexte' ) ? FKC_ScanContexte::invite( $sbDev['contexte'] ) : 'Scanner ou rechercher…' );
$sbCible  = isset( $cible ) ? preg_replace( '/[^A-Za-z0-9_]/', '', (string) $cible ) : '';
$sbId     = 'sb' . substr( md5( $sbRoute . $sbDev['contexte'] . $sbCible ), 0, 6 );
?>
<div class="scanbox" id="<?= e( $sbId ) ?>" data-contexte="<?= e( $sbDev['contexte'] ) ?>" data-route="<?= e( $sbRoute ) ?>" style="position:relative;margin-bottom:10px">
	<div style="display:flex;gap:6px;align-items:center">
		<input type="text" class="sb-q" placeholder="<?= e( $sbInvite ) ?>" autocomplete="off"
			<?= ! empty( $autofocus ) ? 'autofocus' : '' ?> style="flex:1;padding:9px 12px">
		<span class="tag sb-ctx" title="Contexte <?= e( $sbDev['source'] ) ?> : la même saisie déclenche l'action de cet écran."><?= e( $sbDev['contexte'] ) ?></span>
	</div>
	<div class="sb-liste" style="display:none;position:absolute;z-index:40;left:0;right:0;background:var(--panel,#fff);border:1px solid var(--line);border-radius:8px;margin-top:4px;max-height:280px;overflow:auto"></div>
	<div class="sb-msg muted" style="font-size:.85em;margin-top:4px;min-height:1.2em"></div>
</div>
<script>
(function () {
	var box = document.getElementById('<?= e( $sbId ) ?>');
	if (!box || box.dataset.pret) { return; }
	box.dataset.pret = '1';
	var q = box.querySelector('.sb-q'),
	    liste = box.querySelector('.sb-liste'),
	    msg = box.querySelector('.sb-msg'),
	    cible = '<?= e( $sbCible ) ?>',
	    url = '<?= e( url( 'scan/chercher' ) ) ?>',
	    csrf = '<?= e( FKC_Csrf::token() ) ?>',
	    timer = null, dernier = '';

	function envoyer(params) {
		var body = new URLSearchParams(params);
		body.set('_csrf', csrf); // 1.811.0 : nom de champ unique (_csrf), comme partout
		body.set('contexte', box.dataset.contexte);
		body.set('route', box.dataset.route);
		return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body })
			.then(function (r) { return r.json(); });
	}

	function rendre(res) {
		liste.innerHTML = ''; liste.style.display = 'none';
		msg.textContent = res.message || '';
		if (res.mode === 'scan' && res.resultat) {
			// Le résultat part à l'écran appelant : le composant ne connaît
			// rien du métier, il ne fait que désigner.
			if (cible && typeof window[cible] === 'function') { window[cible](res.resultat); }
			q.value = ''; q.focus();
			return;
		}
		if (res.mode === 'candidats' && res.candidats && res.candidats.length) {
			res.candidats.forEach(function (c) {
				var d = document.createElement('div');
				d.style.cssText = 'padding:8px 11px;cursor:pointer;border-bottom:1px solid var(--line)';
				d.innerHTML = '<strong></strong> <span class="muted" style="font-size:.85em"></span>';
				d.querySelector('strong').textContent = c.libelle;
				d.querySelector('span').textContent = c.sous_titre || c.code || '';
				d.addEventListener('mousedown', function (ev) {
					ev.preventDefault();
					// Choisir dans la liste vaut scan : le journal garde la même
					// trace, sans trou là où l'étiquette était illisible.
					envoyer({ entite_type: c.entite_type, entite_id: c.id }).then(rendre);
				});
				liste.appendChild(d);
			});
			liste.style.display = '';
		}
	}

	q.addEventListener('keydown', function (e) {
		// Entrée = geste du scanner : on résout tout de suite, sans attendre
		// le délai de frappe. Un lecteur de comptoir termine toujours ainsi.
		if (e.key === 'Enter') {
			e.preventDefault();
			clearTimeout(timer);
			if (q.value.trim()) { envoyer({ q: q.value, canal: 'clavier' }).then(rendre); }
		}
		if (e.key === 'Escape') { liste.style.display = 'none'; }
	});
	q.addEventListener('input', function () {
		clearTimeout(timer);
		var v = q.value.trim();
		if (v.length < 2) { liste.style.display = 'none'; msg.textContent = ''; return; }
		// La frappe au clavier cherche ; le scan, lui, arrive d'un bloc avec
		// son retour chariot et passe par la branche ci-dessus.
		timer = setTimeout(function () {
			if (v === dernier) { return; }
			dernier = v;
			envoyer({ q: v, canal: 'clavier' }).then(rendre);
		}, 220);
	});
	q.addEventListener('blur', function () { setTimeout(function () { liste.style.display = 'none'; }, 150); });
})();
</script>
