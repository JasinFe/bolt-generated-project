<?php /** @var array $definitions @var array $ouvertes @var array|null $etat @var array $entrepots @var string|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'scan::_subnav', array( 'tab' => 'processus' ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( is_array( $flash ) ? ( $flash['msg'] ?? '' ) : $flash ) ?></div><?php endif; ?>

<?php if ( ! $etat ) : ?>

	<div class="card card-flush">
		<div class="card-head"><h2>⛓️ Processus pilotés au scan</h2><span class="muted">Une séquence, tenue par le moteur</span></div>
		<div style="padding:12px;line-height:1.7">
			Une réception, un comptage, un transfert ne sont pas des scans isolés : ce sont des
			<strong>séquences</strong>. Sans mémoire de l'étape en cours, chaque bip repart de zéro et c'est
			à l'opérateur de tenir le fil dans sa tête — c'est là que naissent les erreurs de préparation.
			<br><br>
			<strong>Rien n'est écrit pendant le parcours.</strong> Le moteur collecte ; l'effet part à la clôture,
			en une fois. Une interruption au milieu ne laisse donc jamais de demi-opération — et sur un quai,
			on est interrompu tout le temps.
		</div>
	</div>

	<div class="form-grid">
		<?php foreach ( $definitions as $code => $d ) : ?>
			<div class="card card-flush">
				<div class="card-head"><h2><?= e( $d['libelle'] ) ?></h2></div>
				<div style="padding:12px">
					<p class="muted" style="margin-top:0"><?= e( (string) ( $d['description'] ?? '' ) ) ?></p>
					<ol style="margin:0 0 12px;padding-left:20px;line-height:1.7">
						<?php foreach ( $d['etapes'] as $e ) : ?>
							<li><?= e( $e['libelle'] ) ?>
								<span class="muted" style="font-size:.85em">
									<?= $e['attend'] ? '— ' . e( implode( ' ou ', (array) $e['attend'] ) ) : '' ?>
									<?= ! empty( $e['repetable'] ) ? ' · répétable' : '' ?>
									<?= 0 === (int) $e['min'] ? ' · facultatif' : '' ?>
								</span>
							</li>
						<?php endforeach; ?>
					</ol>
					<form method="post" action="<?= e( url( 'scan/processus' ) ) ?>">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="action" value="ouvrir">
						<input type="hidden" name="code" value="<?= e( $code ) ?>">
						<button class="btn btn-primary btn-sm" type="submit">Démarrer</button>
					</form>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<?php
	/*
	 * Les sessions ouvertes sont listées EN PREMIER dans l'esprit de
	 * l'opérateur : celui qui revient après une interruption cherche à
	 * reprendre, pas à recommencer. Les cacher l'obligerait à redémarrer un
	 * processus et à rescanner ce qu'il avait déjà compté.
	 */
	?>
	<?php if ( $ouvertes ) : ?>
	<div class="card card-flush">
		<div class="card-head"><h2>Reprendre un travail en cours</h2><span class="muted"><?= count( $ouvertes ) ?></span></div>
		<table class="table">
			<thead><tr><th>Processus</th><th>Ouvert le</th><th>Poste</th><th style="width:180px"></th></tr></thead>
			<tbody>
			<?php foreach ( $ouvertes as $o ) : ?>
				<tr>
					<td><?= e( (string) ( $definitions[ $o['code'] ]['libelle'] ?? $o['code'] ) ) ?></td>
					<td class="muted"><?= e( (string) $o['created_at'] ) ?></td>
					<td class="muted"><?= e( (string) $o['poste'] ) ?></td>
					<td class="right">
						<a class="btn btn-ghost btn-sm" href="<?= e( url( 'scan/processus?session=' . (int) $o['id'] ) ) ?>">Reprendre</a>
						<form method="post" action="<?= e( url( 'scan/processus' ) ) ?>" style="display:inline"
							onsubmit="return confirm('Abandonner ? Rien n\'aura été enregistré.')">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="action" value="abandonner">
							<input type="hidden" name="session" value="<?= (int) $o['id'] ?>">
							<button class="btn btn-ghost btn-sm" type="submit">Abandonner</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endif; ?>

<?php else : ?>

	<?php $s = $etat['session']; $cour = $etat['courante']; ?>
	<div class="card card-flush">
		<div class="card-head">
			<h2><?= e( $etat['libelle'] ) ?></h2>
			<span class="muted">Étape <?= min( (int) $etat['index'] + 1, count( $etat['etapes'] ) ) ?> sur <?= count( $etat['etapes'] ) ?></span>
		</div>
		<div style="padding:12px">
			<ol style="margin:0 0 14px;padding-left:20px;line-height:1.9">
				<?php foreach ( $etat['etapes'] as $i => $e ) :
					$fait = $i < (int) $etat['index'];
					$active = $i === (int) $etat['index'];
					$col = $etat['collecte'][ $e['cle'] ] ?? null;
					$n = is_array( $col ) && isset( $col[0] ) ? count( $col ) : ( $col ? 1 : 0 );
				?>
					<li style="<?= $active ? 'font-weight:700' : ( $fait ? 'color:var(--ok)' : 'color:var(--muted)' ) ?>">
						<?= $fait ? '✓ ' : ( $active ? '▶ ' : '' ) ?><?= e( $e['libelle'] ) ?>
						<?= $n ? '<span class="muted" style="font-weight:400;font-size:.85em"> — ' . (int) $n . ' scanné(s)</span>' : '' ?>
					</li>
				<?php endforeach; ?>
			</ol>

			<?php if ( $cour ) : ?>
				<?php
				/*
				 * On rappelle CE QUE L'ÉTAPE ATTEND. Scanner un article quand
				 * le moteur attend un emplacement veut souvent dire qu'on s'est
				 * trompé de processus : le dire à l'avance évite le refus.
				 */
				?>
				<form method="post" action="<?= e( url( 'scan/processus' ) ) ?>" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
					<?= FKC_Csrf::field() ?>
					<input type="hidden" name="session" value="<?= (int) $s['id'] ?>">
					<input type="text" name="q" placeholder="<?= e( (string) $cour['invite'] ) ?>" autofocus autocomplete="off" style="flex:1;min-width:240px;padding:9px 12px">
					<button class="btn btn-primary" type="submit">Scanner</button>
					<?php if ( 0 === (int) $cour['min'] ) : ?>
						<?php /* Beaucoup d'entrepôts ne gèrent pas d'emplacement : sans ce bouton, le processus serait bloqué dès sa première étape. */ ?>
						<button class="btn btn-ghost" type="submit" name="passer" value="1">Passer cette étape</button>
					<?php endif; ?>
					<?php if ( ! empty( $cour['repetable'] ) ) : ?>
						<button class="btn btn-ghost" type="submit" name="suivante" value="1"
							title="Passer à l'étape suivante : c'est vous qui savez que vous avez fini de scanner.">Étape suivante →</button>
					<?php endif; ?>
					<span class="muted" style="font-size:.85em">Attendu : <?= e( implode( ' ou ', (array) $cour['attend'] ) ?: 'tout objet' ) ?></span>
				</form>
			<?php else : ?>
				<div class="alert alert-ok" style="margin:0">Toutes les étapes sont faites — la clôture peut être demandée.</div>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( $etat['collecte'] ) : ?>
	<div class="card card-flush">
		<div class="card-head"><h2>Collecté</h2><span class="muted">Rien n'est encore enregistré</span></div>
		<table class="table">
			<thead><tr><th>Étape</th><th>Objet</th><th class="num">Quantité</th><th>Lot</th><th>Péremption</th></tr></thead>
			<tbody>
			<?php foreach ( $etat['collecte'] as $cle => $val ) :
				$items = ( is_array( $val ) && isset( $val[0] ) ) ? $val : array( $val );
				foreach ( $items as $it ) : ?>
				<tr>
					<td class="muted"><?= e( (string) $cle ) ?></td>
					<td><?= e( (string) ( $it['libelle'] ?? '' ) ) ?></td>
					<td class="num"><?= e( (string) ( $it['quantite'] ?? '' ) ) ?></td>
					<td class="code"><?= e( (string) ( $it['lot'] ?? '' ) ) ?></td>
					<td class="code<?= ! empty( $it['expiration'] ) && strtotime( $it['expiration'] ) < time() ? ' " style="color:var(--danger)' : '' ?>"><?= e( (string) ( $it['expiration'] ?? '' ) ) ?></td>
				</tr>
			<?php endforeach; endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php endif; ?>

	<div class="card card-flush">
		<div class="card-head"><h2>Clore le processus</h2><span class="muted">C'est ici, et seulement ici, que quelque chose s'écrit</span></div>
		<form method="post" action="<?= e( url( 'scan/processus' ) ) ?>" style="padding:12px;display:flex;gap:8px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="action" value="cloturer">
			<input type="hidden" name="session" value="<?= (int) $s['id'] ?>">
			<?php if ( 'reception_terrain' === $s['code'] && $entrepots ) : ?>
				<label class="fld" style="margin:0"><span>Entrepôt de réception</span>
					<select name="entrepot_id" required>
						<option value="">—</option>
						<?php foreach ( $entrepots as $en ) : ?>
							<option value="<?= (int) $en['id'] ?>"><?= e( $en['code'] . ' · ' . $en['libelle'] ) ?></option>
						<?php endforeach; ?>
					</select>
				</label>
			<?php endif; ?>
			<button class="btn btn-primary" type="submit">Valider et enregistrer</button>
			<a class="btn btn-ghost" href="<?= e( url( 'scan/processus' ) ) ?>">Laisser en cours</a>
		</form>
	</div>

<?php endif; ?>
