<?php
/**
 * Étiquette métier d'un article (1.827.0) : libellé, référence, prix, EAN,
 * QR GS1 (lot, péremption, quantité) relu tel quel par le moteur de scan.
 * @var array $art @var array $etiquette @var int $copies
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$et = $etiquette;
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><title>Étiquette — <?= e( $et['libelle'] ) ?></title>
<style>
*{box-sizing:border-box}body{font-family:system-ui,Arial,sans-serif;margin:0;padding:8mm}
.grille{display:grid;grid-template-columns:repeat(auto-fill,minmax(62mm,1fr));gap:4mm}
.etq{border:1px dashed #bbb;border-radius:4px;padding:3mm;page-break-inside:avoid;display:grid;grid-template-columns:1fr 24mm;gap:2mm;align-items:center}
.lib{font-size:12px;font-weight:700;line-height:1.15}.ref{font-size:9px;color:#555}.prix{font-size:16px;font-weight:800;margin-top:1mm}
.meta{font-size:9px;margin-top:1mm}.ean{grid-column:1/-1}.ean svg,.qr svg{max-width:100%;height:auto;display:block}
.toolbar{margin-bottom:6mm}@media print{.toolbar{display:none}body{padding:0}}
</style></head><body>
<div class="toolbar"><button onclick="window.print()">🖨️ Imprimer</button> <span style="color:#666"><?= (int) $copies ?> étiquette(s) · QR <?= $et['gs1'] ? 'GS1 (GTIN' . ( $et['lot'] ? ', lot' : '' ) . ( $et['peremption'] ? ', péremption' : '' ) . ( $et['quantite'] ? ', quantité' : '' ) . ')' : 'FinaKop (article sans GTIN)' ?></span></div>
<div class="grille">
<?php for ( $i = 0; $i < $copies; $i++ ) : ?>
	<div class="etq">
		<div>
			<div class="lib"><?= e( $et['libelle'] ) ?></div>
			<div class="ref"><?= e( $et['reference'] ) ?></div>
			<?php if ( $et['prix'] > 0 ) : ?><div class="prix"><?= e( fkc_money( $et['prix'] ) ) ?> F</div><?php endif; ?>
			<div class="meta"><?= $et['lot'] ? 'Lot ' . e( $et['lot'] ) . ' · ' : '' ?><?= $et['peremption'] ? 'À utiliser avant le ' . e( date( 'd/m/Y', strtotime( $et['peremption'] ) ) ) : '' ?><?= $et['quantite'] ? ' · ' . (int) $et['quantite'] . ' u.' : '' ?></div>
		</div>
		<div class="qr"><?= FKC_Barcode::rendre( $et['qr'], array( 'symbologie' => 'qr', 'hauteur' => 90 ) ) ?></div>
		<?php if ( $et['ean'] ) : ?><div class="ean"><?= FKC_Barcode::rendre( $et['ean'], array( 'hauteur' => 34, 'module' => 2 ) ) ?></div><?php endif; ?>
	</div>
<?php endfor; ?>
</div>
</body></html>
