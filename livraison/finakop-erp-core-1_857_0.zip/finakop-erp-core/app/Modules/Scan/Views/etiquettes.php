<?php /** @var array $articles @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'scan::_subnav', array( 'tab' => 'etiquettes' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card card-flush">
	<div class="card-head"><h2>🖨️ Impression d'étiquettes</h2></div>
	<div class="card-body">
		<p class="muted" style="margin-top:0">Sélectionnez les articles à étiqueter et le nombre d'étiquettes par article, puis générez une planche prête à imprimer sur votre imprimante d'étiquettes ou en A4.</p>
		<?php if ( ! $articles ) : ?>
			<div class="empty" style="padding:24px;text-align:center">Aucun code enregistré. Affectez d'abord des codes à vos articles (formulaire article ou console de scan).</div>
		<?php else : ?>
		<form method="post" action="<?= e( url( 'scan/planche' ) ) ?>" target="_blank">
			<div style="display:flex;gap:12px;align-items:flex-end;margin-bottom:12px;flex-wrap:wrap">
				<label style="display:flex;flex-direction:column;gap:4px"><span class="muted" style="font-size:12px;font-weight:600">Étiquettes par article</span>
					<input type="number" name="qte" value="1" min="1" max="100" style="width:120px;padding:8px;border:1px solid var(--line);border-radius:8px"></label>
				<button class="btn btn-primary" type="submit">🖨️ Générer la planche</button>
				<button class="btn btn-ghost" type="button" id="selAll">Tout cocher</button>
			</div>
			<div class="form-grid form-compact" style="margin-bottom:12px">
				<div class="fld"><label>Lot (étiquette métier)</label><input id="etqLot" maxlength="20"></div>
				<div class="fld"><label>Péremption</label><input type="date" id="etqPer"></div>
				<div class="fld"><label>Quantité par colis</label><input type="number" id="etqQte" min="0"></div>
			</div>
			<table class="table"><thead><tr><th style="width:36px"></th><th>Code</th><th>Article</th><th>Type</th><th>Conditionnement</th><th>Étiquette métier</th></tr></thead><tbody>
			<?php foreach ( $articles as $a ) : ?>
				<tr>
					<td><input type="checkbox" name="codes[]" value="<?= e( $a['code'] ) ?>"></td>
					<td style="font-family:monospace"><?= e( $a['code'] ) ?></td>
					<td><?= e( $a['libelle'] ?: '—' ) ?></td>
					<td><?= e( FKC_Scan::symbologieLabel( $a['symbologie'] ) ) ?></td>
					<td><?= e( 'unite' === $a['unite'] ? 'Unité' : ucfirst( $a['unite'] ) ) ?></td>
					<td><?php if ( 'unite' === $a['unite'] ) : ?><a class="btn btn-ghost btn-sm js-etq" target="_blank" rel="noopener" data-base="<?= e( url( 'scan/etiquette-article?article_id=' . (int) $a['entite_id'] ) ) ?>" href="<?= e( url( 'scan/etiquette-article?article_id=' . (int) $a['entite_id'] ) ) ?>">🏷️ Prix + QR GS1</a><?php endif; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		</form>
		<script>
		// 1.827.0 : le lot, la péremption et la quantité saisis partent dans le QR GS1 de l'étiquette métier.
		document.querySelectorAll('.js-etq').forEach(function(a){ a.addEventListener('click',function(){
			var q='&copies='+encodeURIComponent(document.querySelector('input[name="qte"]').value||1)+'&lot='+encodeURIComponent(document.getElementById('etqLot').value)+'&peremption='+encodeURIComponent(document.getElementById('etqPer').value)+'&qte='+encodeURIComponent(document.getElementById('etqQte').value);
			a.href=a.dataset.base+q;
		}); });
		document.getElementById('selAll').addEventListener('click',function(){
			var cbs=document.querySelectorAll('input[name="codes[]"]'), all=[].every.call(cbs,function(c){return c.checked;});
			cbs.forEach(function(c){c.checked=!all;});
		});
		</script>
		<?php endif; ?>
	</div>
</div>
