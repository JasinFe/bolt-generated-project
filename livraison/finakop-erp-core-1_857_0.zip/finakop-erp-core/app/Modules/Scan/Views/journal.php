<?php /** @var array $lignes @var array $stats @var array $analytics @var array $contextes @var array $filtre @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$badge = array( 'ok' => array( 'var(--ok)', 'Résolu' ), 'inconnu' => array( 'var(--orange)', 'Inconnu' ), 'refuse' => array( 'var(--danger)', 'Refusé' ) );
$canaux = array( 'clavier' => '⌨️ Lecteur', 'camera' => '📷 Caméra', 'api' => '🔌 API' ); ?>
<?php FKC_View::partial( 'scan::_subnav', array( 'tab' => 'journal' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Scans ce mois</span><div style="font-size:1.5em;font-weight:700"><?= (int) $stats['total'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Résolus</span><div style="font-size:1.5em;font-weight:700;color:var(--ok)"><?= (int) $stats['resolus'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Inconnus</span><div style="font-size:1.5em;font-weight:700;color:var(--orange)"><?= (int) $stats['inconnus'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Taux de résolution</span><div style="font-size:1.5em;font-weight:700"><?= e( $stats['taux'] ) ?> %</div></div></div>
</div>

<?php $an = $analytics ?? null; if ( $an ) : ?>
<div class="cards-grid" style="margin-bottom:16px">
	<div class="card card-flush"><div class="card-head"><h2>📊 Par contexte — 30 jours</h2></div>
		<div style="overflow-x:auto"><table class="table"><thead><tr><th>Contexte</th><th class="num">Scans</th><th class="num">Résolus</th><th class="num">Refusés</th><th class="num">Inconnus</th></tr></thead><tbody>
		<?php if ( ! $an['contextes'] ) : ?><tr><td colspan="5" class="empty">Aucun scan.</td></tr><?php endif; ?>
		<?php foreach ( $an['contextes'] as $c ) : ?><tr><td><?= e( $contextes[ $c['contexte'] ] ?? $c['contexte'] ) ?></td><td class="num"><?= (int) $c['total'] ?></td><td class="num"><?= (int) $c['total'] ? round( 100 * (int) $c['resolus'] / (int) $c['total'] ) : 0 ?> %</td><td class="num"><?= (int) $c['refuses'] ?></td><td class="num"><?= (int) $c['inconnus'] ?></td></tr><?php endforeach; ?>
		</tbody></table></div></div>
	<div class="card card-flush"><div class="card-head"><h2>👷 Productivité par opérateur</h2><span class="muted" style="font-size:12px">cadence globale : <?= null === $an['cadence'] ? '—' : e( (string) $an['cadence'] ) . ' scan/min active' ?></span></div>
		<div style="overflow-x:auto"><table class="table"><thead><tr><th>Opérateur</th><th class="num">Scans</th><th class="num">Résolus</th><th class="num">Cadence</th></tr></thead><tbody>
		<?php if ( ! $an['operateurs'] ) : ?><tr><td colspan="4" class="empty">Aucun scan.</td></tr><?php endif; ?>
		<?php foreach ( $an['operateurs'] as $o ) : ?><tr><td><?= e( $o['nom'] ) ?></td><td class="num"><?= (int) $o['total'] ?></td><td class="num"><?= (int) $o['total'] ? round( 100 * (int) $o['resolus'] / (int) $o['total'] ) : 0 ?> %</td><td class="num"><?= null === $o['cadence'] ? '—' : e( (string) $o['cadence'] ) . '/min' ?></td></tr><?php endforeach; ?>
		</tbody></table></div></div>
	<div class="card card-flush"><div class="card-head"><h2>❓ Codes inconnus à affecter</h2></div>
		<div style="overflow-x:auto"><table class="table"><tbody>
		<?php if ( ! $an['inconnus'] ) : ?><tr><td class="empty">Aucun code inconnu récurrent.</td></tr><?php endif; ?>
		<?php foreach ( $an['inconnus'] as $u ) : ?><tr><td><code><?= e( $u['code'] ) ?></code></td><td class="num"><?= (int) $u['fois'] ?>×</td><td><a class="btn btn-sm" href="<?= e( url( 'scan/generateur?valeur=' . rawurlencode( $u['code'] ) ) ) ?>">Affecter</a></td></tr><?php endforeach; ?>
		</tbody></table></div></div>
</div>
<?php endif; ?>

<div class="card card-flush">
	<div class="card-head"><h2>📜 Journal des scans</h2>
		<form method="get" style="display:flex;gap:8px">
			<select name="contexte" onchange="this.form.submit()" style="padding:6px 10px;border:1px solid var(--line);border-radius:8px">
				<option value="">Tous les contextes</option>
				<?php foreach ( $contextes as $k => $l ) : ?><option value="<?= e( $k ) ?>"<?= ( $filtre['contexte'] ?? '' ) === $k ? ' selected' : '' ?>><?= e( $l ) ?></option><?php endforeach; ?>
			</select>
			<select name="statut" onchange="this.form.submit()" style="padding:6px 10px;border:1px solid var(--line);border-radius:8px">
				<option value="">Tous les statuts</option>
				<option value="ok"<?= ( $filtre['statut'] ?? '' ) === 'ok' ? ' selected' : '' ?>>Résolus</option>
				<option value="inconnu"<?= ( $filtre['statut'] ?? '' ) === 'inconnu' ? ' selected' : '' ?>>Inconnus</option>
				<option value="refuse"<?= ( $filtre['statut'] ?? '' ) === 'refuse' ? ' selected' : '' ?>>Refusés</option>
			</select>
		</form>
	</div>
	<table class="table"><thead><tr><th>Horodatage</th><th>Code</th><th>Type</th><th>Contexte</th><th>Objet</th><th>Canal</th><th>Statut</th></tr></thead><tbody>
	<?php if ( ! $lignes ) : ?><tr><td colspan="7" class="empty">Aucun scan enregistré.</td></tr>
	<?php else : foreach ( $lignes as $l ) : $b = $badge[ $l['statut'] ] ?? array( 'var(--muted)', $l['statut'] ); ?>
		<tr>
			<td style="white-space:nowrap;font-size:12.5px"><?= e( $l['scanned_at'] ) ?></td>
			<td style="font-family:monospace"><?= e( $l['code'] ) ?></td>
			<td style="font-size:12px"><?= e( FKC_Scan::symbologieLabel( $l['symbologie'] ?: 'auto' ) ) ?></td>
			<td style="font-size:12.5px"><?= e( $contextes[ $l['contexte'] ] ?? ( $l['contexte'] ?: '—' ) ) ?></td>
			<td style="font-size:12.5px"><?= $l['entite_type'] ? e( ucfirst( $l['entite_type'] ) . ( $l['entite_id'] ? ' #' . $l['entite_id'] : '' ) ) : '<span class="muted">—</span>' ?></td>
			<td style="font-size:12px"><?= e( $canaux[ $l['canal'] ] ?? $l['canal'] ) ?></td>
			<td><span style="color:<?= $b[0] ?>;font-weight:600;font-size:12.5px"><?= e( $b[1] ) ?></span></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody></table>
</div>
