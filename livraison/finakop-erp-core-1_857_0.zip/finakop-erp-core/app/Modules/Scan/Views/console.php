<?php /** @var array $contextes @var array $stats @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'scan::_subnav', array( 'tab' => 'console' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="scan-wrap">
	<div class="scan-left">
		<div class="card card-flush">
			<div class="card-head"><h2>🔍 Console de scan universelle</h2>
				<span id="scanState" class="scan-state scan-idle">Prêt</span>
			</div>
			<div class="card-body">
				<div class="scan-row">
					<label class="scan-f">
						<span>Opération</span>
						<select id="scanContexte">
							<?php foreach ( $contextes as $k => $lbl ) : ?><option value="<?= e( $k ) ?>"<?= 'vente' === $k ? ' selected' : '' ?>><?= e( $lbl ) ?></option><?php endforeach; ?>
						</select>
					</label>
					<label class="scan-f scan-f-sm">
						<span>Quantité / cartons</span>
						<input type="number" id="scanQte" value="1" min="1" step="1">
					</label>
					<label class="scan-f scan-f-chk">
						<span>Mode</span>
						<label class="scan-toggle"><input type="checkbox" id="scanContinu" checked> Scan continu</label>
					</label>
				</div>
				<div class="scan-input-row">
					<input type="text" id="scanInput" class="scan-input" autocomplete="off" placeholder="Scannez ou saisissez un code, puis Entrée…" autofocus>
					<button class="btn btn-primary" id="scanBtn">Valider</button>
					<button class="btn btn-ghost" id="scanCam" title="Scanner avec la caméra">📷 Caméra</button>
				</div>
				<div id="scanCamZone" class="scan-cam" hidden><video id="scanVideo" playsinline muted autoplay></video><button class="btn btn-ghost btn-sm" id="scanCamStop">Arrêter la caméra</button> <button class="btn btn-ghost btn-sm" id="scanCamTorche" hidden>💡 Lampe</button></div>
				<div id="scanApercu" class="muted" style="font-size:12px;min-height:16px;margin:6px 2px 0" aria-live="polite"></div>
				<div id="scanIntent" class="scan-intent" hidden></div>
				<div id="scanResult" class="scan-result"></div>
			</div>
		</div>

		<div class="card card-flush" style="margin-top:16px">
			<div class="card-head"><h2>🧾 Panier / lignes en cours</h2>
				<div><span class="muted" id="scanCartCount">0 ligne(s)</span> · <strong id="scanCartTotal">0 F</strong>
					<button class="btn btn-ghost btn-sm" id="scanClear">Vider</button></div>
			</div>
			<table class="table"><thead><tr><th>Article</th><th class="num">Qté</th><th class="num">PU</th><th class="num">Total</th><th></th></tr></thead>
				<tbody id="scanCart"><tr id="scanCartEmpty"><td colspan="5" class="empty">Aucune ligne. Scannez un article pour l'ajouter.</td></tr></tbody>
			</table>
		</div>
	</div>

	<div class="scan-right">
		<div class="card"><div class="card-body">
			<div class="muted" style="font-size:12px;font-weight:700">AUJOURD'HUI</div>
			<div class="scan-stat"><span>Scans</span><strong id="stTotal"><?= (int) $stats['total'] ?></strong></div>
			<div class="scan-stat"><span>Résolus</span><strong style="color:var(--ok)" id="stOk"><?= (int) $stats['resolus'] ?></strong></div>
			<div class="scan-stat"><span>Inconnus</span><strong style="color:var(--orange)" id="stInc"><?= (int) $stats['inconnus'] ?></strong></div>
			<div class="scan-stat"><span>Refusés</span><strong style="color:var(--danger)" id="stRef"><?= (int) $stats['refuses'] ?></strong></div>
			<div class="scan-stat"><span>Taux</span><strong id="stTaux"><?= e( $stats['taux'] ) ?> %</strong></div>
		</div></div>
		<div class="card" style="margin-top:12px"><div class="card-body">
			<div class="muted" style="font-size:12px;font-weight:700;margin-bottom:6px">MODE HORS CONNEXION</div>
			<p style="font-size:12.5px;margin:0 0 8px" class="muted">Les scans effectués sans connexion sont mis en file et synchronisés automatiquement au retour du réseau.</p>
			<div class="scan-stat"><span>En attente de synchro</span><strong id="scanQueue">0</strong></div>
			<button class="btn btn-ghost btn-sm" id="scanSync" style="margin-top:6px" disabled>Synchroniser maintenant</button>
			<div id="scanNet" class="scan-net"></div>
		</div></div>
	</div>
</div>

<style>
.scan-wrap{display:grid;grid-template-columns:1fr 260px;gap:16px}
@media(max-width:900px){.scan-wrap{grid-template-columns:1fr}}
.scan-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px}
.scan-f{display:flex;flex-direction:column;gap:4px;flex:1;min-width:150px}
.scan-f-sm{max-width:150px}.scan-f-chk{max-width:170px}
.scan-f>span{font-size:12px;color:var(--muted);font-weight:600}
.scan-f select,.scan-f input{padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--panel,#fff);color:inherit;font:inherit}
.scan-toggle{display:flex;align-items:center;gap:6px;font-size:13px;padding:8px 0}
.scan-input-row{display:flex;gap:8px}
.scan-input{flex:1;padding:14px 16px;font-size:18px;font-family:monospace;letter-spacing:1px;border:2px solid var(--blue);border-radius:10px;background:var(--panel,#fff);color:inherit}
.scan-state{font-size:12px;font-weight:700;padding:3px 10px;border-radius:20px}
.scan-idle{background:rgba(127,127,127,.15);color:var(--muted)}
.scan-ok{background:rgba(34,197,94,.15);color:var(--ok)}
.scan-err{background:rgba(239,68,68,.15);color:var(--danger)}
.scan-result{margin-top:12px;min-height:22px;font-size:14px}
.scan-line{padding:10px 12px;border-radius:8px;margin-top:6px;font-size:13.5px}
.scan-line-ok{background:rgba(34,197,94,.1);border-left:3px solid var(--ok)}
.scan-line-err{background:rgba(239,68,68,.1);border-left:3px solid var(--danger)}
.scan-line-warn{background:rgba(245,158,11,.12);border-left:3px solid var(--orange)}
.scan-cam{margin-top:12px;text-align:center}
.scan-cam video{width:100%;max-width:420px;border-radius:10px;background:#000}
.scan-stat{display:flex;justify-content:space-between;padding:5px 0;font-size:13px;border-bottom:1px solid var(--line)}
.scan-stat:last-child{border-bottom:none}
.scan-net{font-size:12px;margin-top:8px;font-weight:600}
</style>

<script src="<?= e( fkc_asset( 'js/vendor/zxing.min.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>" defer></script>
<script src="<?= e( fkc_asset( 'js/scanner.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>" defer></script>
<script>
(function(){
	var urlResolve = <?= json_encode( url( 'scan/resolve' ) ) ?>;
	var input=document.getElementById('scanInput'), state=document.getElementById('scanState'), result=document.getElementById('scanResult');
	var cart=[], cartBody=document.getElementById('scanCart');
	var LSKEY='fkc_scan_queue';

	function setState(txt,cls){ state.textContent=txt; state.className='scan-state '+cls; }
	function money(n){ return new Intl.NumberFormat('fr-FR').format(Math.round(n))+' F'; }

	/* ── File hors connexion ── */
	function queue(){ try{ return JSON.parse(localStorage.getItem(LSKEY)||'[]'); }catch(e){ return []; } }
	function setQueue(q){ try{ localStorage.setItem(LSKEY,JSON.stringify(q)); }catch(e){} refreshQueue(); }
	function refreshQueue(){ var n=queue().length; document.getElementById('scanQueue').textContent=n; document.getElementById('scanSync').disabled=(n===0||!navigator.onLine); }
	function enqueue(payload){ var q=queue(); q.push(payload); setQueue(q); }

	function netStatus(){ var el=document.getElementById('scanNet'); if(navigator.onLine){ el.textContent='● En ligne'; el.style.color='var(--ok)'; } else { el.textContent='● Hors connexion — les scans sont mis en file'; el.style.color='var(--orange)'; } refreshQueue(); }
	window.addEventListener('online',function(){ netStatus(); syncQueue(); });
	window.addEventListener('offline',netStatus);

	/* 1.811.0 — chaque scan porte un identifiant unique, créé AU MOMENT du
	   scan et conservé dans la file : un envoi rejoué après une coupure est
	   reconnu par le serveur et n'est jamais compté deux fois. Le jeton CSRF
	   est joint explicitement (plus seulement par csrf.js). */
	function uuid(){ if(window.crypto&&crypto.randomUUID){ return crypto.randomUUID(); } return 'c'+Date.now().toString(36)+Math.random().toString(36).slice(2,12); }
	function csrf(){ var m=document.querySelector('meta[name="csrf-token"]'); return m?m.getAttribute('content'):''; }
	function post(payload){
		payload._csrf=csrf();
		var body=Object.keys(payload).map(function(k){return encodeURIComponent(k)+'='+encodeURIComponent(payload[k]);}).join('&');
		return fetch(urlResolve,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},body:body}).then(function(r){return r.json();});
	}

	function syncQueue(){
		var q=queue(); if(!q.length||!navigator.onLine) return;
		var next=q.shift(); setQueue(q);
		// En cas d'échec réseau, le scan est remis en tête de file (même identifiant) : rien n'est perdu.
		post(next).then(function(){ if(queue().length) syncQueue(); }).catch(function(){ var q2=queue(); q2.unshift(next); setQueue(q2); refreshQueue(); });
	}
	document.getElementById('scanSync').addEventListener('click',syncQueue);

	/* ── Traitement d'un scan ── */
	function handle(code){
		code=(code||'').trim(); if(!code) return;
		var payload={ code:code, contexte:document.getElementById('scanContexte').value, quantite:document.getElementById('scanQte').value||1, poste:'Console web', canal:'clavier', event_uuid:uuid() };
		if(!navigator.onLine){ enqueue(payload); addResult({ok:true,statut:'file',message:'Hors connexion : scan « '+code+' » mis en file.'}); return; }
		setState('Recherche…','scan-idle');
		post(payload).then(function(res){ render(res); }).catch(function(){ enqueue(payload); addResult({ok:false,statut:'file',message:'Réseau indisponible : scan mis en file.'}); });
	}

	function render(res){
		if(res.ok){ setState('✓ '+ (res.symbologie||'').toUpperCase(),'scan-ok'); }
		else { setState(res.statut==='refuse'?'✗ Refusé':'? Inconnu','scan-err'); }
		addResult(res);
		carteIntent(res); document.getElementById('scanApercu').textContent='';
		refreshStats();
		var a=res.action;
		if(res.ok && a && (a.type==='ligne_ticket'||a.type==='ligne_reception')){
			addToCart(a, res);
		}
	}
	/* ── 1.817.0 : carte d'intention après chaque scan + « Ce scan va… » ── */
	var URL_APERCU=<?= json_encode( url( 'scan/apercu' ) ) ?>, URL_LOT=<?= json_encode( url( 'scan/lot' ) ) ?>;
	function esc(t){ var d=document.createElement('div'); d.textContent=(t==null?'':String(t)); return d.innerHTML; }
	function carteIntent(res){
		var box=document.getElementById('scanIntent'), it=res.intent;
		if(!it){ box.hidden=true; return; }
		var tons={warn:'var(--warn)',danger:'var(--danger)',ok:'var(--ok)'};
		var h='<div style="border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-top:10px;background:var(--panel)">';
		h+='<div style="font-weight:700;margin-bottom:6px">'+esc(it.phrase)+'</div>';
		if(it.indicateurs&&it.indicateurs.length){
			h+='<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:6px">';
			it.indicateurs.forEach(function(i){ h+='<div><div class="muted" style="font-size:11px">'+esc(i.libelle)+'</div><strong style="color:'+(tons[i.ton]||'inherit')+'">'+esc(i.valeur)+'</strong></div>'; });
			h+='</div>';
		}
		(it.alertes||[]).forEach(function(a){ h+='<div style="color:var(--warn);font-size:13px">⚠ '+esc(a)+'</div>'; });
		if(it.actions&&it.actions.length){
			h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">';
			it.actions.forEach(function(a,i){ h+='<button type="button" class="btn btn-sm'+(a.principale?' btn-primary':'')+'" data-ia="'+i+'">'+esc(a.libelle)+'</button>'; });
			h+='</div>';
		}
		box.innerHTML=h+'</div>'; box.hidden=false;
		box.querySelectorAll('button[data-ia]').forEach(function(b){ b.addEventListener('click',function(){
			var a=it.actions[+b.dataset.ia];
			if(a.post){ var f=new URLSearchParams(a.donnees||{}); f.set('_csrf',csrf());
				fetch(a.post,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},body:f.toString()}).then(function(r){return r.json();}).then(function(d){ addResult({ok:d.ok,statut:d.ok?'ok':'refuse',message:d.message}); if(d.ok&&d.url){ window.location=d.url; } }); return; }
			if(a.url){ window.location=a.url; return; }
			input.focus();
		}); });
	}
	var apercuT=null;
	input.addEventListener('input',function(){
		clearTimeout(apercuT); var v=input.value.trim(), el=document.getElementById('scanApercu');
		// Seulement pour une saisie à la main qui a la forme d'un code : une douchette envoie tout d'un coup puis Entrée.
		if(!/^([0-9]{8,14}|\(0[01]\)|FKC:)/.test(v)){ el.textContent=''; return; }
		apercuT=setTimeout(function(){
			fetch(URL_APERCU+'?code='+encodeURIComponent(v)+'&contexte='+encodeURIComponent(document.getElementById('scanContexte').value)+'&quantite='+encodeURIComponent(document.getElementById('scanQte').value||1))
				.then(function(r){return r.json();}).then(function(d){ if(input.value.trim()===v){ el.textContent=(d.connu?'→ ':'')+(d.phrase||''); } }).catch(function(){});
		},350);
	});

	function addResult(res){
		var cls=res.ok?'scan-line-ok':(res.statut==='refuse'?'scan-line-err':'scan-line-warn');
		var div=document.createElement('div'); div.className='scan-line '+cls; div.textContent=res.message||'';
		result.insertBefore(div,result.firstChild);
		while(result.children.length>4) result.removeChild(result.lastChild);
	}

	function addToCart(a,res){
		var pu=(a.prix_unitaire!==undefined?a.prix_unitaire:(a.pu||0));
		var q=(a.quantite||res.quantite||1);
		var key=(a.article_id||a.entite_id||res.code);
		var found=cart.find(function(l){return l.key===key;});
		if(found){ found.qte+=q; } else { cart.push({key:key,lib:(a.libelle||res.libelle||res.code),qte:q,pu:pu}); }
		renderCart();
	}
	function renderCart(){
		var e=document.getElementById('scanCartEmpty'); if(e) e.remove();
		cartBody.innerHTML='';
		if(!cart.length){ cartBody.innerHTML='<tr id="scanCartEmpty"><td colspan="5" class="empty">Aucune ligne. Scannez un article pour l\'ajouter.</td></tr>'; }
		var total=0;
		cart.forEach(function(l,i){
			var lt=l.qte*l.pu; total+=lt;
			var tr=document.createElement('tr');
			tr.innerHTML='<td>'+esc(l.lib)+'</td><td class="num">'+l.qte+'</td><td class="num">'+money(l.pu)+'</td><td class="num">'+money(lt)+'</td><td class="num"><button class="btn btn-ghost btn-sm" data-i="'+i+'">✕</button></td>';
			cartBody.appendChild(tr);
		});
		document.getElementById('scanCartCount').textContent=cart.length+' ligne(s)';
		document.getElementById('scanCartTotal').textContent=money(total);
		cartBody.querySelectorAll('button[data-i]').forEach(function(b){ b.addEventListener('click',function(){ cart.splice(+b.dataset.i,1); renderCart(); }); });
	}
	function esc(s){ var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
	document.getElementById('scanClear').addEventListener('click',function(){ cart=[]; renderCart(); });

	function refreshStats(){
		post({code:'',contexte:'controle',quantite:0,__stat:1}); // no-op ; stats rafraîchies via prochain chargement
	}

	/* ── Saisie clavier (lecteurs USB/Bluetooth HID = clavier + Entrée) ── */
	document.getElementById('scanBtn').addEventListener('click',function(){ handle(input.value); input.value=''; input.focus(); });
	input.addEventListener('keydown',function(ev){ if(ev.key==='Enter'){ ev.preventDefault(); handle(input.value); input.value=''; if(document.getElementById('scanContinu').checked) input.focus(); } });

	/* ── Caméra (module partagé FKCScanner) ── */
	var camSession=null;
	document.getElementById('scanCam').addEventListener('click',function(){
		var zone=document.getElementById('scanCamZone');
		if(camSession){ stopCam(); return; }
		if(typeof FKCScanner==='undefined'){ addResult({ok:false,statut:'inconnu',message:'Lecteur caméra en cours de chargement, réessayez dans un instant.'}); return; }
		zone.hidden=false;
		FKCScanner.demarrer({
			video:'scanVideo',
			onCode:function(code){ handle(code); },
			onErreur:function(msg){ addResult({ok:false,statut:'inconnu',message:msg}); }
		}).then(function(s){
			camSession=s;
			var t=document.getElementById('scanCamTorche');
			if(t){ t.hidden=!s.torcheDisponible; }
		}).catch(function(e){
			addResult({ok:false,statut:'inconnu',message:e.message});
			zone.hidden=true;
		});
	});
	function stopCam(){ if(camSession){ camSession.arreter(); camSession=null; } document.getElementById('scanCamZone').hidden=true; }
	document.getElementById('scanCamStop').addEventListener('click',stopCam);
	(function(){
		var t=document.getElementById('scanCamTorche');
		if(!t){ return; }
		var on=false;
		t.addEventListener('click',function(){
			if(!camSession){ return; }
			on=!on;
			camSession.torche(on).then(function(ok){ t.textContent = (ok&&on) ? '💡 Éteindre' : '💡 Lampe'; });
		});
	})();

	netStatus(); refreshQueue(); input.focus();
})();
</script>
