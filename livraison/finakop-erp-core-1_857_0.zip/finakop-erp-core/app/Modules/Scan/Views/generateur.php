<?php /** @var string $valeur @var string $type @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'scan::_subnav', array( 'tab' => 'generateur' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card card-flush">
	<div class="card-head"><h2>🏷️ Générateur de codes</h2></div>
	<div class="card-body">
		<p class="muted" style="margin-top:0">Générez un code-barres ou un QR Code pour n'importe quelle valeur : code article interne, référence, URL de fiche, ou identifiant FinaKop. Idéal pour les produits sans code fabricant, les immobilisations, les badges.</p>
		<div class="gen-row">
			<label class="gen-f"><span>Valeur à encoder</span>
				<input type="text" id="genVal" value="<?= e( $valeur ) ?>" placeholder="Ex. 3017620422003 ou ART-001">
			</label>
			<label class="gen-f gen-f-sm"><span>Type de code</span>
				<select id="genType">
					<option value="auto"<?= 'auto' === $type ? ' selected' : '' ?>>Détection automatique</option>
					<option value="ean13"<?= 'ean13' === $type ? ' selected' : '' ?>>EAN-13</option>
					<option value="ean8"<?= 'ean8' === $type ? ' selected' : '' ?>>EAN-8</option>
					<option value="upc"<?= 'upc' === $type ? ' selected' : '' ?>>UPC-A</option>
					<option value="code128"<?= 'code128' === $type ? ' selected' : '' ?>>Code 128</option>
					<option value="qr"<?= 'qr' === $type ? ' selected' : '' ?>>QR Code</option>
				</select>
			</label>
			<div class="gen-actions">
				<button class="btn btn-primary" id="genBtn">Générer</button>
				<button class="btn btn-ghost" id="genInterne" title="Générer un EAN-13 interne unique">🎲 EAN-13 interne</button>
				<button class="btn btn-ghost" id="genIdent" type="button" title="Que désigne ce code ? À quoi le rattacher ?">🔎 Identifier ce code</button>
			</div>
		</div>
		<div id="genDiag" class="alert" hidden style="margin-bottom:10px"></div>
		<div id="genIdentRes" hidden style="margin-bottom:10px;border:1px solid var(--line);border-radius:10px;padding:10px 12px"></div>
		<div id="genPreview" class="gen-preview"></div>
		<div id="genTools" class="gen-tools" hidden>
			<a class="btn btn-ghost btn-sm" id="genDownload" download="code.svg">⬇️ Télécharger (SVG)</a>
			<button class="btn btn-ghost btn-sm" id="genPrint">🖨️ Imprimer</button>
		</div>
	</div>
</div>

<style>
.gen-row{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin-bottom:16px}
.gen-f{display:flex;flex-direction:column;gap:4px;flex:1;min-width:200px}
.gen-f-sm{max-width:200px}
.gen-f>span{font-size:12px;color:var(--muted);font-weight:600}
.gen-f input,.gen-f select{padding:9px 11px;border:1px solid var(--line);border-radius:8px;background:var(--panel,#fff);color:inherit;font:inherit}
.gen-actions{display:flex;gap:8px}
.gen-preview{text-align:center;padding:24px;background:#fff;border-radius:10px;border:1px solid var(--line);min-height:80px;display:flex;align-items:center;justify-content:center}
.gen-preview svg{max-width:100%}
.gen-tools{margin-top:12px;display:flex;gap:8px;justify-content:center}
</style>

<script>
/* 1.827.0 — assistant d'identification : format, clé, plage GS1, fiches candidates. */
(function(){
	var URL_ID=<?= json_encode( url( 'scan/assistant' ) ) ?>, URL_AFF=<?= json_encode( url( 'scan/affecter' ) ) ?>;
	function esc(t){ var d=document.createElement('div'); d.textContent=(t==null?'':String(t)); return d.innerHTML; }
	var b=document.getElementById('genIdent'); if(!b) return;
	b.addEventListener('click',function(){
		var v=document.getElementById('genVal').value.trim(), box=document.getElementById('genIdentRes'); if(!v) return;
		fetch(URL_ID+'?code='+encodeURIComponent(v)).then(function(r){return r.json();}).then(function(d){
			var h=(d.diagnostic||[]).map(function(x){ return '<div>• '+esc(x)+'</div>'; }).join('');
			(d.actions||[]).forEach(function(a,i){ if(a.post){ h+='<button type="button" class="btn btn-sm'+(i===0?' btn-primary':'')+'" data-i="'+i+'" style="margin:6px 6px 0 0">'+esc(a.libelle)+'</button>'; } });
			box.innerHTML=h||'—'; box.hidden=false;
			box.querySelectorAll('button[data-i]').forEach(function(bt){ bt.addEventListener('click',function(){
				var a=d.actions[+bt.dataset.i], f=new URLSearchParams(a.donnees||{}), m=document.querySelector('meta[name="csrf-token"]'); if(m){ f.set('_csrf',m.getAttribute('content')); }
				fetch(URL_AFF,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:f.toString()}).then(function(r){return r.json();}).then(function(x){
					box.insertAdjacentHTML('beforeend','<div style="margin-top:6px;font-weight:600;color:'+(x.ok?'var(--ok)':'var(--danger)')+'">'+esc(x.message||(x.ok?'Code rattaché.':'Rattachement refusé.'))+'</div>');
				});
			}); });
		});
	});
})();
</script>
<script>
(function(){
	var img=<?= json_encode( url( 'scan/image' ) ) ?>, interne=<?= json_encode( url( 'scan/generer-interne' ) ) ?>, verif=<?= json_encode( url( 'scan/verifier' ) ) ?>;
	var val=document.getElementById('genVal'), type=document.getElementById('genType'), prev=document.getElementById('genPreview'), tools=document.getElementById('genTools');
	function render(){
		var v=val.value.trim(); if(!v){ prev.innerHTML='<span class="muted">Saisissez une valeur…</span>'; tools.hidden=true; return; }
		var src=img+'?code='+encodeURIComponent(v)+'&type='+encodeURIComponent(type.value)+'&h=70';
		prev.innerHTML='<img src="'+src+'" alt="code">';
		// Diagnostic : dire ce qui sera réellement encodé. Une clé refaite ou un
		// accent retiré change la valeur lue en rayon — l'utilisateur doit le voir
		// AVANT d'imprimer une planche d'étiquettes.
		var diag=document.getElementById('genDiag');
		fetch(verif+'?code='+encodeURIComponent(v)+'&type='+encodeURIComponent(type.value))
			.then(function(r){return r.json();}).then(function(d){
				if(!d || !d.corrige){ diag.hidden=true; return; }
				diag.hidden=false;
				diag.innerHTML='<strong>Valeur encodée : '+String(d.encode).replace(/[&<>]/g,'')+'</strong>'
					+ (d.message ? '<br><span class="muted">'+String(d.message).replace(/[<>]/g,'')+'</span>' : '');
			}).catch(function(){ diag.hidden=true; });
		document.getElementById('genDownload').href=src;
		tools.hidden=false;
	}
	document.getElementById('genBtn').addEventListener('click',render);
	val.addEventListener('keydown',function(e){ if(e.key==='Enter') render(); });
	document.getElementById('genInterne').addEventListener('click',function(){
		fetch(interne).then(function(r){return r.json();}).then(function(d){ val.value=d.code; type.value='ean13'; render(); });
	});
	document.getElementById('genPrint').addEventListener('click',function(){
		var w=window.open('','_blank'); w.document.write('<html><body style="text-align:center;padding:40px">'+prev.innerHTML+'</body></html>'); w.document.close(); w.print();
	});
	<?php if ( '' !== $valeur ) : ?>render();<?php endif; ?>
})();
</script>
