<?php
/**
 * SCAN WORKSPACE (1.828.0) — tout le geste de scan sur un seul écran.
 *
 * @var array $contextes @var array $stats @var array $definitions @var array $ouvertes
 * @var array $historique @var array $inconnus @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'scan::_subnav', array( 'tab' => 'workspace' ) );
$st = $stats ?: array();
?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( is_array( $flash ) ? ( $flash['msg'] ?? '' ) : $flash ) ?></div><?php endif; ?>

<div class="page-stack">
	<div class="cards-grid">
		<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Scans aujourd'hui</div><strong style="font-size:22px" id="wsN"><?= (int) ( $st['total'] ?? 0 ) ?></strong></div></div>
		<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Taux de résolution</div><strong style="font-size:22px"><?= isset( $st['taux'] ) ? (int) $st['taux'] . ' %' : '—' ?></strong></div></div>
		<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Codes inconnus (7 j)</div><strong style="font-size:22px;color:<?= $inconnus ? 'var(--warn)' : 'var(--ok)' ?>"><?= count( $inconnus ) ?></strong></div></div>
		<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Opérations ouvertes</div><strong style="font-size:22px"><?= count( $ouvertes ) ?></strong></div></div>
	</div>

	<div class="card">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
			<h2>🧭 Scanner</h2>
			<span id="wsMode" class="muted" style="font-size:13px">Mode : scan libre</span>
		</div>
		<div class="card-body">
			<div class="form-grid">
				<div class="fld" style="grid-column:1/-1"><label>Code (douchette, clavier, lecteur PDA)</label>
					<input id="wsCode" autocomplete="off" autofocus placeholder="Scannez ou saisissez un code, puis Entrée" style="font-size:20px;padding:12px"></div>
				<div class="fld"><label>Contexte</label><select id="wsCtx"><?php foreach ( $contextes as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></div>
				<div class="fld"><label>Quantité par scan</label><input id="wsQte" type="number" min="1" value="1"></div>
				<div class="fld"><label>&nbsp;</label><a class="btn btn-ghost" href="<?= e( url( 'scan/smart' ) ) ?>">📱 Scanner avec un téléphone</a></div>
			</div>
			<div id="wsApercu" class="muted" style="font-size:13px;min-height:18px;margin-top:6px" aria-live="polite"></div>
			<div id="wsCarte" hidden></div>
		</div>
	</div>

	<div class="card" id="wsOp">
		<div class="card-head"><h2>⛓️ Opération en cours</h2></div>
		<div class="card-body">
			<div id="wsOpVide">
				<p class="muted" style="margin-top:0">Aucune opération : les scans sont résolus dans le contexte choisi. Démarrez une opération pour que les scans la fassent avancer.</p>
				<div style="display:flex;gap:6px;flex-wrap:wrap">
					<?php foreach ( $definitions as $code => $d ) : ?>
						<button type="button" class="btn btn-sm" data-ouvrir="<?= e( $code ) ?>" title="<?= e( $d['description'] ?? '' ) ?>"><?= e( $d['libelle'] ) ?></button>
					<?php endforeach; ?>
				</div>
				<?php if ( $ouvertes ) : ?>
				<p class="muted" style="font-size:12px;margin:10px 0 4px">Reprendre :</p>
				<div style="display:flex;gap:6px;flex-wrap:wrap">
					<?php foreach ( $ouvertes as $o ) : ?>
						<button type="button" class="btn btn-sm btn-ghost" data-reprendre="<?= (int) $o['id'] ?>"><?= e( ( $definitions[ $o['code'] ]['libelle'] ?? $o['code'] ) . ' · #' . (int) $o['id'] ) ?></button>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</div>
			<div id="wsOpEtat" hidden></div>
		</div>
	</div>

	<div class="cards-grid">
		<div class="card card-flush">
			<div class="card-head"><h2>🕘 Mes derniers scans</h2></div>
			<div style="overflow-x:auto"><table class="table"><tbody id="wsHisto">
				<?php if ( ! $historique ) : ?><tr><td class="empty">Aucun scan récent.</td></tr><?php endif; ?>
				<?php foreach ( $historique as $h ) : ?>
					<tr><td style="font-family:monospace;font-size:12px"><?= e( $h['code'] ) ?></td><td><?= e( $h['message'] ) ?></td><td class="muted" style="font-size:11px;white-space:nowrap"><?= e( substr( (string) $h['scanned_at'], 11, 5 ) ) ?></td></tr>
				<?php endforeach; ?>
			</tbody></table></div>
		</div>
		<div class="card card-flush">
			<div class="card-head"><h2>❓ Codes inconnus à rattacher</h2></div>
			<div style="overflow-x:auto"><table class="table"><tbody>
				<?php if ( ! $inconnus ) : ?><tr><td class="empty">Aucun code inconnu récurrent.</td></tr><?php endif; ?>
				<?php foreach ( $inconnus as $u ) : ?>
					<tr><td style="font-family:monospace"><?= e( $u['code'] ) ?></td><td class="num"><?= (int) $u['fois'] ?>×</td>
					<td><button type="button" class="btn btn-sm" data-identifier="<?= e( $u['code'] ) ?>">🔎 Identifier</button></td></tr>
				<?php endforeach; ?>
			</tbody></table></div>
		</div>
	</div>
</div>

<script>
(function(){
	var U={ scan:<?= json_encode( url( 'scan/workspace/scan' ) ) ?>, op:<?= json_encode( url( 'scan/workspace/processus' ) ) ?>,
		apercu:<?= json_encode( url( 'scan/apercu' ) ) ?>, assistant:<?= json_encode( url( 'scan/assistant' ) ) ?> };
	var input=document.getElementById('wsCode'), carte=document.getElementById('wsCarte'), SESSION=0;
	function esc(t){ var d=document.createElement('div'); d.textContent=(t==null?'':String(t)); return d.innerHTML; }
	function csrf(){ var m=document.querySelector('meta[name="csrf-token"]'); return m?m.getAttribute('content'):''; }
	function uuid(){ if(window.crypto&&crypto.randomUUID){ return crypto.randomUUID(); } return 'w'+Date.now().toString(36)+Math.random().toString(36).slice(2,12); }
	function post(url,data){
		var f=new URLSearchParams(data); f.set('_csrf',csrf());
		return fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},body:f.toString()}).then(function(r){return r.json();});
	}
	function focus(){ setTimeout(function(){ input.focus(); input.select(); },30); }
	var tons={warn:'var(--warn)',danger:'var(--danger)',ok:'var(--ok)'};

	/* Carte après chaque scan : phrase, indicateurs, alertes, actions. */
	function afficherCarte(ok,titre,it){
		var h='<div style="border:1px solid '+(ok?'var(--line)':'var(--danger)')+';border-radius:12px;padding:12px 14px;margin-top:10px">';
		h+='<div style="font-weight:700;font-size:16px;margin-bottom:6px">'+(ok?'✓ ':'✗ ')+esc(titre)+'</div>';
		if(it&&it.indicateurs&&it.indicateurs.length){ h+='<div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:6px">'; it.indicateurs.forEach(function(i){ h+='<div><div class="muted" style="font-size:11px">'+esc(i.libelle)+'</div><strong style="color:'+(tons[i.ton]||'inherit')+'">'+esc(i.valeur)+'</strong></div>'; }); h+='</div>'; }
		((it&&it.alertes)||[]).forEach(function(a){ h+='<div style="color:var(--warn);font-size:13px">⚠ '+esc(a)+'</div>'; });
		if(it&&it.actions&&it.actions.length){ h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">'; it.actions.forEach(function(a,i){ h+='<button type="button" class="btn btn-sm'+(a.principale?' btn-primary':'')+'" data-ia="'+i+'">'+esc(a.libelle)+'</button>'; }); h+='</div>'; }
		carte.innerHTML=h+'</div>'; carte.hidden=false;
		carte.querySelectorAll('button[data-ia]').forEach(function(b){ b.addEventListener('click',function(){
			var a=it.actions[+b.dataset.ia];
			if(a.post){ post(a.post,a.donnees||{}).then(function(d){ if(d.ok&&d.url&&a.code!=='processus'){ window.location=d.url; return; } if(a.code==='processus'&&d.ok){ var m=/session=(\d+)/.exec(d.url||''); if(m){ reprendre(+m[1]); } } toast(d.message||(d.ok?'Fait.':'Refusé.'),d.ok); }); return; }
			if(a.url){ window.location=a.url; return; }
			focus();
		}); });
	}
	function toast(msg,ok){ var d=document.createElement('div'); d.style.cssText='margin-top:6px;font-weight:600;color:'+(ok?'var(--ok)':'var(--danger)'); d.textContent=msg; carte.appendChild(d); carte.hidden=false; }
	function histo(code,msg){ var tb=document.getElementById('wsHisto'); var tr=document.createElement('tr'); tr.innerHTML='<td style="font-family:monospace;font-size:12px">'+esc(code)+'</td><td>'+esc(msg)+'</td><td class="muted" style="font-size:11px">'+new Date().toTimeString().slice(0,5)+'</td>'; tb.insertBefore(tr,tb.firstChild); var n=document.getElementById('wsN'); n.textContent=(+n.textContent||0)+1; }

	/* Opération en cours. */
	function afficherEtat(etat){
		var vide=document.getElementById('wsOpVide'), box=document.getElementById('wsOpEtat'), mode=document.getElementById('wsMode');
		if(!etat||!SESSION){ vide.hidden=false; box.hidden=true; mode.textContent='Mode : scan libre'; return; }
		vide.hidden=true; box.hidden=false; mode.innerHTML='Mode : <strong>'+esc(etat.libelle)+'</strong> — les scans font avancer l\'opération';
		var h='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">';
		(etat.etapes||[]).forEach(function(e,i){
			var n=etat.collecte&&etat.collecte[e.cle]; var c=Array.isArray(n)?n.length:(n?1:0);
			var st=i<etat.index?'✓':(i===etat.index?'▶':'·');
			h+='<span style="padding:4px 10px;border-radius:999px;border:1px solid var(--line);'+(i===etat.index?'font-weight:700;border-color:var(--blue)':'')+'">'+st+' '+esc(e.libelle)+(c?' ('+c+')':'')+'</span>';
		});
		h+='</div>';
		h+='<p style="margin:0 0 8px">'+(etat.termine?'<strong>Toutes les étapes sont faites : clôturez.</strong>':esc((etat.courante&&etat.courante.invite)||'Scanner…'))+'</p>';
		h+='<div style="display:flex;gap:6px;flex-wrap:wrap">';
		if(!etat.termine){ h+='<button type="button" class="btn btn-sm" data-op="suivante">Étape suivante</button><button type="button" class="btn btn-sm btn-ghost" data-op="passer">Passer</button>'; }
		h+='<button type="button" class="btn btn-sm btn-primary" data-op="cloturer">✓ Clôturer</button><button type="button" class="btn btn-sm btn-ghost" data-op="abandonner" style="color:var(--danger)">Abandonner</button></div>';
		box.innerHTML=h;
		box.querySelectorAll('button[data-op]').forEach(function(b){ b.addEventListener('click',function(){
			var act=b.dataset.op;
			if(act==='abandonner'&&!confirm('Abandonner l\'opération ? Rien ne sera enregistré.')) return;
			post(U.op,{action:act,session:SESSION}).then(function(d){
				afficherCarte(d.ok,d.message,null);
				if((act==='cloturer'&&d.ok)||(act==='abandonner'&&d.ok)){ SESSION=0; afficherEtat(null); } else { afficherEtat(d.etat); }
				focus();
			});
		}); });
	}
	function reprendre(sid){ post(U.op,{action:'reprendre',session:sid}).then(function(d){ if(d.ok){ SESSION=sid; afficherEtat(d.etat); } focus(); }); }
	document.querySelectorAll('[data-ouvrir]').forEach(function(b){ b.addEventListener('click',function(){
		post(U.op,{action:'ouvrir',code:b.dataset.ouvrir}).then(function(d){ if(d.ok&&d.session){ SESSION=d.session; afficherEtat(d.etat); } afficherCarte(d.ok,d.message,null); focus(); });
	}); });
	document.querySelectorAll('[data-reprendre]').forEach(function(b){ b.addEventListener('click',function(){ reprendre(+b.dataset.reprendre); }); });

	/* Codes inconnus : assistant d'identification. */
	document.querySelectorAll('[data-identifier]').forEach(function(b){ b.addEventListener('click',function(){
		fetch(U.assistant+'?code='+encodeURIComponent(b.dataset.identifier)).then(function(r){return r.json();}).then(function(d){
			afficherCarte(false,'Code '+d.code+(d.connu?' — déjà rattaché':' — inconnu'),{alertes:d.diagnostic||[],actions:d.actions||[],indicateurs:[]});
		});
	}); });

	/* Scan. */
	function scanner(){
		var code=input.value.trim(); if(!code) return;
		input.value=''; document.getElementById('wsApercu').textContent='';
		post(U.scan,{code:code,session:SESSION,contexte:document.getElementById('wsCtx').value,quantite:document.getElementById('wsQte').value||1,event_uuid:uuid()}).then(function(d){
			if(d.mode==='processus'){ afficherCarte(d.ok,d.message,null); afficherEtat(d.etat); histo(code,d.message); }
			else { afficherCarte(!!d.ok,(d.intent&&d.intent.phrase)||d.message||d.libelle||code,d.intent); histo(code,(d.intent&&d.intent.phrase)||d.message||''); }
			focus();
		}).catch(function(){ afficherCarte(false,'Réseau indisponible : scan non envoyé, rescannez au retour du réseau.',null); focus(); });
	}
	input.addEventListener('keydown',function(ev){ if(ev.key==='Enter'){ ev.preventDefault(); scanner(); } });
	var t=null;
	input.addEventListener('input',function(){
		clearTimeout(t); var v=input.value.trim(), el=document.getElementById('wsApercu');
		if(SESSION||!/^([0-9]{8,14}|\(0[01]\)|FKC:)/.test(v)){ el.textContent=''; return; }
		t=setTimeout(function(){ fetch(U.apercu+'?code='+encodeURIComponent(v)+'&contexte='+encodeURIComponent(document.getElementById('wsCtx').value)+'&quantite='+encodeURIComponent(document.getElementById('wsQte').value||1)).then(function(r){return r.json();}).then(function(d){ if(input.value.trim()===v){ el.textContent=(d.connu?'→ ':'')+(d.phrase||''); } }).catch(function(){}); },350);
	});
	// La page garde le focus sur le champ : une douchette tape toujours au bon endroit.
	document.addEventListener('click',function(ev){ var tg=ev.target; if(!tg.closest('input,select,textarea,a,button')){ focus(); } });
	focus();
})();
</script>
