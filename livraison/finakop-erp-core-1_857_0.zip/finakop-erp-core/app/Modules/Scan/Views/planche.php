<?php /** @var array $items */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><title>Planche d'étiquettes</title>
<style>
*{box-sizing:border-box}body{font-family:system-ui,Arial,sans-serif;margin:0;padding:8mm}
.grille{display:grid;grid-template-columns:repeat(3,1fr);gap:4mm}
.etq{border:1px dashed #bbb;border-radius:4px;padding:6px;text-align:center;page-break-inside:avoid}
.etq .lib{font-size:11px;font-weight:600;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.etq svg{max-width:100%;height:auto}
.toolbar{margin-bottom:8mm}
@media print{.toolbar{display:none}body{padding:0}}
</style></head><body>
<div class="toolbar"><button onclick="window.print()">🖨️ Imprimer</button> <span style="color:#666"><?= count( $items ) ?> étiquette(s)</span></div>
<?php if ( ! $items ) : ?><p>Aucune étiquette sélectionnée.</p><?php else : ?>
<div class="grille">
	<?php foreach ( $items as $it ) : $opt = array( 'hauteur' => 44, 'module' => 2 ); if ( 'auto' !== ( $it['symbologie'] ?? 'auto' ) ) { $opt['symbologie'] = $it['symbologie']; } ?>
		<div class="etq">
			<?php if ( ! empty( $it['libelle'] ) ) : ?><div class="lib"><?= e( $it['libelle'] ) ?></div><?php endif; ?>
			<?= FKC_Barcode::rendre( $it['code'], $opt ) ?>
		</div>
	<?php endforeach; ?>
</div>
<?php endif; ?>
</body></html>
