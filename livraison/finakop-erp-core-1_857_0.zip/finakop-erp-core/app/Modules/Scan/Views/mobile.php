<?php /** FinaKop Scan Mobile — page téléphone/PDA. @var string $token @var string $user_nom */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<!DOCTYPE html>
<html lang="fr"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>FinaKop Scan Mobile</title>
<style>
:root{--bg:#0f1115;--panel:#1a1d24;--line:#2a2f3a;--text:#e8eaed;--muted:#9aa0aa;--ok:#2ecc71;--warn:#e6a700;--danger:#e74c3c;--accent:#3b82f6}
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--text)}
.wrap{max-width:480px;margin:0 auto;padding:16px;min-height:100vh}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:12px}
h1{font-size:18px;margin:0 0 4px}.sub{color:var(--muted);font-size:13px;margin:0 0 14px}
label{display:block;font-size:13px;color:var(--muted);margin:10px 0 4px}
input,select,button{width:100%;padding:12px;border-radius:10px;border:1px solid var(--line);background:#12151b;color:var(--text);font-size:16px}
button{background:var(--accent);border:none;font-weight:700;margin-top:12px}
button.sec{background:#232833}
.hidden{display:none}
.badge{display:inline-block;background:#12351f;color:var(--ok);padding:4px 10px;border-radius:20px;font-size:13px;font-weight:700}
#scanbox{font-size:22px;text-align:center;letter-spacing:2px;font-weight:800}
.feed{margin-top:10px;max-height:44vh;overflow-y:auto}
.row{border-left:4px solid var(--ok);padding:8px 10px;margin-bottom:6px;background:#12151b;border-radius:8px}
.row.err{border-color:var(--danger)}.row.warn{border-color:var(--warn)}.row.danger{border-color:var(--danger)}
.al{font-size:12px;margin-top:3px}
#cam{width:100%;border-radius:12px;background:#000;margin-top:8px}
.mut{color:var(--muted);font-size:12px}
.aff-item{padding:11px;border:1px solid var(--line);border-radius:10px;margin-bottom:8px;cursor:pointer;background:#12151b}
.aff-item:active{background:#1b2130}
</style>
</head><body>
<div class="wrap">
	<h1>📡 FinaKop Scan Mobile</h1>
	<p class="sub">Transformez ce téléphone en scanner connecté à l'ERP.</p>

	<div class="card" id="pair">
		<div id="pair-form">
			<label>Code de session (ou scannez le QR du PC)</label>
			<input id="code" placeholder="Ex. 7K2P9Q" value="<?= e( $token ) ?>" autocapitalize="characters">
			<label>Votre nom</label>
			<input id="nom" placeholder="Ex. Awa" value="<?= e( $user_nom ) ?>">
			<label>Rôle</label>
			<select id="role">
				<option value="operateur">Opérateur</option>
				<option value="magasinier">Magasinier</option>
				<option value="controleur">Contrôleur</option>
				<option value="caissier">Caissier</option>
			</select>
			<button onclick="joindre()">Connecter</button>
			<p class="mut" id="pair-msg"></p>
		</div>
		<div id="pair-ok" class="hidden">
			<span class="badge">✓ Téléphone connecté</span>
			<p class="mut" style="margin-top:8px">Session : <strong id="s-lib"></strong><br>Utilisateur : <strong id="s-user"></strong></p>
			<p class="mut" id="file-etat" style="margin-top:6px;display:none"></p>
		</div>
	</div>

	<div class="card hidden" id="scan">
		<div id="https-warn" style="display:none;background:#3a2a12;border:1px solid #7a5a1a;border-radius:10px;padding:12px;margin-bottom:12px;font-size:13px;line-height:1.5">
			⚠️ La caméra nécessite une connexion sécurisée (HTTPS). Cette page est ouverte en HTTP.
			<a id="https-link" href="#" style="display:inline-block;margin-top:8px;color:#ffd479;font-weight:700">→ Rouvrir en HTTPS</a>
		</div>
		<label>Contexte du scan</label>
		<select id="contexte">
			<option value="controle">🔍 Identification</option>
			<option value="inventaire">📋 Inventaire</option>
			<option value="reception">📥 Réception</option>
			<option value="vente">🛒 Vente</option>
			<option value="sortie">📤 Sortie</option>
		</select>

		<button class="sec" id="cam-btn" onclick="toggleCam()">📷 Activer la caméra</button>
		<button class="sec" id="cam-torche" onclick="basculerTorche()" hidden>💡 Lampe</button>
		<p id="cam-msg" class="mut" style="display:none;margin-top:8px;line-height:1.4"></p>
		<video id="cam" class="hidden" playsinline muted autoplay></video>

		<label>Ou saisir / douchette le code</label>
		<input id="scanbox" placeholder="Code…" autocomplete="off" onkeydown="if(event.key==='Enter')envoyer(true)">
		<details id="pda-reglages" style="margin-top:8px;font-size:13px"><summary>⚙️ Mode PDA / douchette (Zebra, Honeywell, Datalogic…)</summary>
			<label style="display:block;margin:6px 0"><input type="checkbox" id="pda-actif"> Capturer les lectures du scanner intégré même quand le champ n'a pas le focus</label>
			<label style="display:block;margin:4px 0">Préfixe envoyé par le scanner (à retirer) <input id="pda-prefixe" maxlength="8" style="width:80px"></label>
			<label style="display:block;margin:4px 0">Suffixe (à retirer, en plus d'Entrée/Tab) <input id="pda-suffixe" maxlength="8" style="width:80px"></label>
			<span class="mut">Réglez le scanner en « keystroke output » (DataWedge : sortie clavier, suffixe Entrée). Les réglages restent sur cet appareil.</span>
		</details>

		<label>Quantité par scan</label>
		<div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
			<button type="button" onclick="qte(-1)" style="width:52px;font-size:22px;padding:8px;background:#232833">−</button>
			<input id="qte" type="number" min="1" step="1" value="1" inputmode="numeric" style="text-align:center;font-size:20px;font-weight:800;flex:1">
			<button type="button" onclick="qte(1)" style="width:52px;font-size:22px;padding:8px;background:#232833">+</button>
		</div>
		<button onclick="envoyer(true)">Envoyer le scan</button>

		<div class="feed" id="feed"></div>
	</div>
</div>

<div id="aff-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:50;align-items:flex-end;justify-content:center">
	<div style="background:var(--panel);border:1px solid var(--line);border-radius:16px 16px 0 0;width:100%;max-width:480px;max-height:80vh;display:flex;flex-direction:column;padding:16px">
		<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
			<strong>Affecter le code <span id="aff-code" style="color:var(--accent)"></span></strong>
			<button onclick="fermerAffect()" style="width:auto;padding:6px 12px;background:#232833">✕</button>
		</div>
		<input id="aff-q" placeholder="Scanner ou rechercher…" oninput="chercherArticles()" autocomplete="off" style="margin-bottom:10px">
		<div id="aff-list" style="overflow-y:auto;flex:1"><p class="mut">Tapez au moins 2 caractères…</p></div>
		<div style="border-top:1px solid var(--line);margin-top:10px;padding-top:10px">
			<p class="mut" style="margin-bottom:6px">Ou créer un nouvel article :</p>
			<input id="aff-new-nom" placeholder="Désignation du nouvel article" autocomplete="off" style="margin-bottom:6px">
			<input id="aff-new-prix" type="number" min="0" step="1" inputmode="numeric" placeholder="Prix de vente (optionnel)" style="margin-bottom:8px">
			<button onclick="creerArticle()">➕ Créer et affecter</button>
		</div>
	</div>
</div>

<script src="<?= e( fkc_asset( 'js/vendor/zxing.min.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>"></script>
<script src="<?= e( fkc_asset( 'js/scanner.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>"></script>
<script>
var JOIN=<?= json_encode( url( 'scan/mobile/join' ) ) ?>, PUSH=<?= json_encode( url( 'scan/mobile/push' ) ) ?>;
var SRV_HTTPS = <?= ! empty( $https ) ? 'true' : 'false' ?>;

function checkSecure(){
	var secure = window.isSecureContext || location.protocol==='https:' || location.hostname==='localhost';
	var warn=document.getElementById('https-warn');
	if(!secure){
		warn.style.display='block';
		var link=document.getElementById('https-link');
		link.href='https://'+location.host+location.pathname+location.search;
	} else { warn.style.display='none'; }
}
var DEV=null, JETON=null, CTXDEF='controle', SOC=0;
/* Échappe TOUT ce qui peut sortir d'un texte HTML ou d'une valeur d'attribut.
   Les guillemets manquaient : une désignation d'article contenant un " fermait
   l'attribut onclick construit plus bas et permettait d'injecter du script
   (l'article étant créable depuis /scan/mobile/creer, route publique). */
function esc(s){return(s==null?'':''+s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}

/* ═══ MODE PDA (1.827.0) ════════════════════════════════════════════════
   Les terminaux industriels (Zebra DataWedge, Honeywell, Datalogic…)
   « tapent » la lecture comme un clavier très rapide, suivie d'Entrée ou
   Tab. Si l'opérateur a touché un bouton, le champ perd le focus et la
   lecture partait dans le vide. En mode PDA, une rafale de frappes (moins
   de 60 ms entre deux touches) est captée où que soit le focus, nettoyée du
   préfixe/suffixe réglé, puis envoyée comme un scan. */
var PDA=(function(){ try{ return JSON.parse(localStorage.getItem('fkc_pda')||'{}'); }catch(e){ return {}; } })();
function pdaSauver(){ PDA={actif:document.getElementById('pda-actif').checked, prefixe:document.getElementById('pda-prefixe').value, suffixe:document.getElementById('pda-suffixe').value}; try{ localStorage.setItem('fkc_pda',JSON.stringify(PDA)); }catch(e){} }
function pdaNettoyer(v){
	if(PDA.prefixe&&v.indexOf(PDA.prefixe)===0){ v=v.slice(PDA.prefixe.length); }
	if(PDA.suffixe&&v.length>=PDA.suffixe.length&&v.slice(-PDA.suffixe.length)===PDA.suffixe){ v=v.slice(0,-PDA.suffixe.length); }
	return v.trim();
}
(function(){
	var a=document.getElementById('pda-actif'); if(!a) return;
	a.checked=!!PDA.actif; document.getElementById('pda-prefixe').value=PDA.prefixe||''; document.getElementById('pda-suffixe').value=PDA.suffixe||'';
	['pda-actif','pda-prefixe','pda-suffixe'].forEach(function(id){ document.getElementById(id).addEventListener('change',pdaSauver); });
	var buf='', dernier=0, fin=null;
	function livrer(){ var v=pdaNettoyer(buf); buf=''; if(v.length>=3&&DEV){ var box=document.getElementById('scanbox'); box.value=v; envoyer(true); } }
	document.addEventListener('keydown',function(ev){
		if(!PDA.actif) return;
		var t=ev.target, champ=t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT');
		if(champ && t.id==='scanbox') return;           // le champ de scan gère déjà sa lecture
		if(champ) return;                               // saisie normale dans un autre champ : on n'y touche pas
		var now=Date.now();
		if(now-dernier>60){ buf=''; }                   // pause : ce n'était pas une rafale de scanner
		dernier=now;
		if(ev.key==='Enter'||ev.key==='Tab'){ if(buf.length){ ev.preventDefault(); clearTimeout(fin); livrer(); } return; }
		if(ev.key&&ev.key.length===1){ buf+=ev.key; clearTimeout(fin); fin=setTimeout(function(){ if(buf.length>=6){ livrer(); } else { buf=''; } },120); }
	},true);
	if(PDA.actif){ document.getElementById('pda-reglages').open=false; }
})();

function joindre(){
	var f=new FormData();
	f.append('token', document.getElementById('code').value.trim());
	f.append('nom', (document.getElementById('nom').value.trim()||'Téléphone'));
	f.append('user_nom', document.getElementById('nom').value.trim());
	f.append('role', document.getElementById('role').value);
	f.append('plateforme',PDA.actif?'pda':'smartphone'); // 1.827.0 : l'appareil se déclare PDA
	fetch(JOIN,{method:'POST',body:f}).then(function(r){return r.json();}).then(function(d){
		if(!d.ok){ document.getElementById('pair-msg').textContent=d.message||'Échec.'; return; }
		DEV=d.device_id; JETON=d.jeton; CTXDEF=d.contexte||'controle'; SOC=d.societe_id||0;
		document.getElementById('pair-form').classList.add('hidden');
		document.getElementById('pair-ok').classList.remove('hidden');
		document.getElementById('s-lib').textContent=d.session_libelle||'—';
		document.getElementById('s-user').textContent=document.getElementById('nom').value.trim()||'—';
		document.getElementById('scan').classList.remove('hidden');
		checkSecure();
		if(CTXDEF){ document.getElementById('contexte').value=CTXDEF; }
		document.getElementById('scanbox').focus();
		majEtatFile(); viderFile();
	}).catch(function(){ document.getElementById('pair-msg').textContent='Erreur réseau.'; });
}

function qte(delta){
	var el=document.getElementById('qte'); var v=parseInt(el.value,10)||1; v=Math.max(1,v+delta); el.value=v;
}
var LAST_SENT='', LAST_SENT_T=0;
function envoyer(force){
	var box=document.getElementById('scanbox'), code=box.value.trim();
	if(!DEV){ alert('Appareil non connecté. Reconnectez-vous à la session.'); return; }
	if(!code){ box.focus(); box.style.borderColor='#e74c3c'; setTimeout(function(){ box.style.borderColor=''; },1200); return; }
	var now=Date.now();
	if(!force && code===LAST_SENT && (now-LAST_SENT_T)<2500){ box.value=''; return; }
	LAST_SENT=code; LAST_SENT_T=now;
	var q=parseInt(document.getElementById('qte').value,10)||1; if(q<1) q=1;
	var item={ event_uuid:uuid(), code:code, quantite:q, contexte:document.getElementById('contexte').value, t:Date.now() };
	box.value=''; box.focus();
	if(!navigator.onLine){ mettreEnFile(item); return; }
	pousser(item).then(function(d){
		afficher(d);
		if(navigator.vibrate) navigator.vibrate(d.ok?40:[60,40,60]);
	}).catch(function(){ mettreEnFile(item); });
}

/* ═══ FILE HORS LIGNE (1.811.0) ═══════════════════════════════════════════
   Avant : sans réseau, « Erreur réseau — scan non envoyé » et le scan était
   PERDU — dans un entrepôt, c'est le cas ordinaire, pas l'exception.
   Désormais chaque scan reçoit un identifiant unique au moment du geste ;
   s'il ne part pas, il est rangé dans IndexedDB (qui survit à la mise en
   veille et au rechargement de la page) et renvoyé dès le retour du réseau,
   puis toutes les 20 s, avec le MÊME identifiant : le serveur reconnaît un
   envoi déjà reçu et ne le compte jamais deux fois. Les scans de plus de
   7 jours sont purgés (session de toute façon expirée). */
function uuid(){ if(window.crypto&&crypto.randomUUID){ return crypto.randomUUID(); } return 'm'+Date.now().toString(36)+Math.random().toString(36).slice(2,12); }
var IDB=null;
function base(){
	return new Promise(function(ok,ko){
		if(IDB){ return ok(IDB); }
		if(!window.indexedDB){ return ko(new Error('indexeddb')); }
		var r=indexedDB.open('fkc-scan-mobile',1);
		r.onupgradeneeded=function(){ r.result.createObjectStore('file',{keyPath:'event_uuid'}); };
		r.onsuccess=function(){ IDB=r.result; ok(IDB); };
		r.onerror=function(){ ko(r.error); };
	});
}
function fileOp(mode,fn){ return base().then(function(db){ return new Promise(function(ok,ko){ var tx=db.transaction('file',mode); var st=tx.objectStore('file'); var res=fn(st); tx.oncomplete=function(){ ok(res&&res.result!==undefined?res.result:res); }; tx.onerror=function(){ ko(tx.error); }; }); }); }
var FILE_MEM=[]; // repli si IndexedDB est indisponible (navigation privée)
function mettreEnFile(item){
	item.device_id=DEV; item.societe_id=SOC;
	fileOp('readwrite',function(st){ st.put(item); }).catch(function(){ FILE_MEM.push(item); }).then(majEtatFile);
	afficher({ok:true,statut:'file',message:'Hors connexion : « '+item.code+' » gardé et renvoyé au retour du réseau.'});
}
function lireFile(){ return fileOp('readonly',function(st){ return st.getAll(); }).then(function(l){ return (l||[]).concat(FILE_MEM); }).catch(function(){ return FILE_MEM.slice(); }); }
function retirerDeFile(u){ FILE_MEM=FILE_MEM.filter(function(i){ return i.event_uuid!==u; }); return fileOp('readwrite',function(st){ st.delete(u); }).catch(function(){}); }
function majEtatFile(){
	lireFile().then(function(l){ var el=document.getElementById('file-etat'); if(!el) return;
		if(!l.length){ el.style.display='none'; return; }
		el.style.display='block'; el.textContent='⏳ '+l.length+' scan(s) en attente d\'envoi'+(navigator.onLine?' — envoi en cours…':' — hors connexion');
	});
}
function pousser(item){
	var f=new FormData();
	f.append('device_id',DEV); f.append('jeton',JETON); f.append('code',item.code); f.append('societe_id',SOC);
	f.append('quantite',item.quantite); f.append('contexte',item.contexte); f.append('event_uuid',item.event_uuid);
	return fetch(PUSH,{method:'POST',body:f}).then(function(r){ return r.json(); }).then(function(d){
		if(d && d.jeton){ JETON=d.jeton; } // rotation du jeton d'appareil
		return d;
	});
}
var VIDAGE=false;
function viderFile(){
	if(VIDAGE||!DEV||!navigator.onLine) return;
	VIDAGE=true;
	lireFile().then(function(l){
		var limite=Date.now()-7*86400000;
		l.sort(function(a,b){ return a.t-b.t; });
		var suivant=function(i){
			if(i>=l.length){ VIDAGE=false; majEtatFile(); return; }
			var it=l[i];
			if(it.t<limite||it.device_id!==DEV){ retirerDeFile(it.event_uuid).then(function(){ suivant(i+1); }); return; }
			pousser(it).then(function(d){
				// Toute réponse du serveur (acceptée, refusée ou déjà reçue) sort le scan de la file.
				if(d&&!d.doublon){ afficher(d); }
				return retirerDeFile(it.event_uuid);
			}).then(function(){ suivant(i+1); })
			  .catch(function(){ VIDAGE=false; majEtatFile(); }); // réseau encore absent : on réessaiera
		};
		suivant(0);
	});
}
window.addEventListener('online',function(){ majEtatFile(); viderFile(); });
window.addEventListener('offline',majEtatFile);
setInterval(viderFile,20000);
var FEED_N=0;
function afficher(d){
	var cls = d.ok?'':'err', al=d.alertes||[];
	al.forEach(function(a){ if(a.niveau==='danger')cls='danger'; else if(a.niveau==='warn'&&cls!=='danger')cls='warn'; });
	var id='row'+(++FEED_N);
	var h='<div class="row '+cls+'" id="'+id+'"><strong>'+esc(d.libelle||d.code||'?')+'</strong>'
		+'<div class="mut">'+esc(d.message||'')+'</div>';
	// Niveau de conditionnement : carton/pack/palette → conversion en unités.
	if(d.unite && d.unite!=='unite' && (parseFloat(d.facteur)||1)>1){
		h+='<div style="font-size:12px;color:#6aa8ff;margin-top:2px">📦 '+esc(d.unite)+' → '+esc(d.quantite)+' unités</div>';
	}
	al.forEach(function(a){ h+='<div class="al" style="color:'+(a.niveau==='danger'?'#e74c3c':a.niveau==='warn'?'#e6a700':'#3b82f6')+'">⚠ '+esc(a.message)+'</div>'; });
	// 1.817.0 — intention : comptage de la session, écart, péremption, lot…
	if(d.intent&&d.intent.indicateurs&&d.intent.indicateurs.length){
		h+='<div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:6px;font-size:12px">';
		d.intent.indicateurs.forEach(function(i){ h+='<span><span class="mut">'+esc(i.libelle)+'</span> <strong style="color:'+(i.ton==='danger'?'#e74c3c':i.ton==='warn'?'#e6a700':i.ton==='ok'?'#2ecc71':'inherit')+'">'+esc(i.valeur)+'</strong></span>'; });
		h+='</div>';
	}
	if(d.intent&&d.intent.alertes){ d.intent.alertes.forEach(function(a){ h+='<div class="al" style="color:#e6a700">⚠ '+esc(a)+'</div>'; }); }
	// Code inconnu → proposer de l'affecter à un article, directement au téléphone.
	if(d.statut==='inconnu' && d.code){
		// data-code + délégation d'événement : la donnée n'est plus concaténée
		// dans du code JS, donc plus aucune séquence de caractères ne peut en
		// sortir pour devenir une instruction.
		h+='<button class="lnk js-affecter" data-code="'+esc(d.code)+'" style="margin-top:8px;width:100%;padding:9px;border-radius:8px;border:1px solid #3b82f6;background:transparent;color:#3b82f6;font-weight:700">🔗 Affecter ce code à un article</button>';
	}
	h+='</div>';
	document.getElementById('feed').insertAdjacentHTML('afterbegin',h);
}

/* ── Affectation d'un code inconnu à un article (depuis le mobile) ── */
var ART_URL=<?= json_encode( url( 'scan/mobile/articles' ) ) ?>, AFF_URL=<?= json_encode( url( 'scan/mobile/affecter' ) ) ?>, CREER_URL=<?= json_encode( url( 'scan/mobile/creer' ) ) ?>;
var affectCode='';
function ouvrirAffect(code){
	affectCode=code;
	document.getElementById('aff-code').textContent=code;
	document.getElementById('aff-q').value='';
	document.getElementById('aff-list').innerHTML='';
	document.getElementById('aff-modal').style.display='flex';
	document.getElementById('aff-q').focus();
}
function fermerAffect(){ document.getElementById('aff-modal').style.display='none'; }
/* Délégation : remplace les anciens attributs onclick construits par
   concaténation. Le contenu reste une DONNÉE (dataset), jamais du code. */
document.addEventListener('click', function (ev) {
	var b = ev.target.closest ? ev.target.closest('.js-affecter') : null;
	if (b) { ouvrirAffect(b.getAttribute('data-code') || ''); return; }
	var it = ev.target.closest ? ev.target.closest('.js-choisir-article') : null;
	if (it) { affecter(parseInt(it.getAttribute('data-id'), 10) || 0, it.getAttribute('data-nom') || ''); }
});
var affTimer=null;
function chercherArticles(){
	clearTimeout(affTimer);
	affTimer=setTimeout(function(){
		var q=document.getElementById('aff-q').value.trim();
		if(q.length<2){ document.getElementById('aff-list').innerHTML='<p class="mut">Tapez au moins 2 caractères…</p>'; return; }
		var u=ART_URL+'?device_id='+DEV+'&jeton='+encodeURIComponent(JETON)+'&societe_id='+SOC+'&q='+encodeURIComponent(q);
		fetch(u).then(function(r){return r.json();}).then(function(d){
			var box=document.getElementById('aff-list');
			if(!d.ok||!d.articles||!d.articles.length){ box.innerHTML='<p class="mut">Aucun article trouvé.</p>'; return; }
			box.innerHTML=d.articles.map(function(a){
				return '<div class="aff-item js-choisir-article" data-id="'+(parseInt(a.id,10)||0)+'" data-nom="'+esc(a.designation)+'">'
					+'<strong>'+esc(a.designation)+'</strong><br><span class="mut">'+esc(a.code||'')+'</span></div>';
			}).join('');
		}).catch(function(){});
	},250);
}
function affecter(artId,nom){
	var f=new FormData();
	f.append('device_id',DEV); f.append('jeton',JETON); f.append('societe_id',SOC);
	f.append('code',affectCode); f.append('article_id',artId);
	fetch(AFF_URL,{method:'POST',body:f}).then(function(r){return r.json();}).then(function(d){
		fermerAffect();
		if(d.ok){
			var h='<div class="row" style="border-color:#2ecc71"><strong>🔗 '+esc(nom)+'</strong><div class="mut">'+esc(d.message)+' Comptabilisé automatiquement.</div></div>';
			document.getElementById('feed').insertAdjacentHTML('afterbegin',h);
			if(navigator.vibrate) navigator.vibrate(60);
			repush(affectCode); // enregistre aussitôt le scan (plus besoin de rescanner)
		} else { alert(d.message||'Échec.'); }
	}).catch(function(){ alert('Erreur réseau.'); });
}
function creerArticle(){
	var nom=document.getElementById('aff-new-nom').value.trim();
	if(nom.length<2){ alert('Saisissez la désignation.'); return; }
	var prix=parseFloat(document.getElementById('aff-new-prix').value)||0;
	var f=new FormData();
	f.append('device_id',DEV); f.append('jeton',JETON); f.append('societe_id',SOC);
	f.append('code',affectCode); f.append('designation',nom); f.append('prix_vente',prix);
	fetch(CREER_URL,{method:'POST',body:f}).then(function(r){return r.json();}).then(function(d){
		fermerAffect();
		if(d.ok){
			var h='<div class="row" style="border-color:#2ecc71"><strong>➕ '+esc(nom)+'</strong><div class="mut">'+esc(d.message)+' Comptabilisé automatiquement.</div></div>';
			document.getElementById('feed').insertAdjacentHTML('afterbegin',h);
			if(navigator.vibrate) navigator.vibrate(60);
			repush(affectCode); // enregistre aussitôt le scan
		} else { alert(d.message||'Échec.'); }
	}).catch(function(){ alert('Erreur réseau.'); });
}
/* Renvoie un code au serveur sans passer par le champ de saisie (après affectation). */
function repush(code){
	if(!code||!DEV) return;
	var q=parseInt(document.getElementById('qte').value,10)||1; if(q<1) q=1;
	var f=new FormData();
	f.append('device_id',DEV); f.append('jeton',JETON); f.append('code',code); f.append('societe_id',SOC);
	f.append('quantite',q); f.append('contexte',document.getElementById('contexte').value);
	f.append('event_uuid',uuid());
	fetch(PUSH,{method:'POST',body:f}).then(function(r){return r.json();}).then(function(d){ if(d&&d.jeton){ JETON=d.jeton; } afficher(d); }).catch(function(){});
}

/* Caméra : déléguée au module partagé assets/js/scanner.js — décodeur natif
   quand le navigateur en a un, repli ZXing sinon (indispensable sur iPhone). */
var session=null, torcheOn=false;

function camMessage(txt){ var el=document.getElementById('cam-msg'); if(el){ el.textContent=txt; el.style.display=txt?'block':'none'; } }

function toggleCam(){
	var v=document.getElementById('cam'), btn=document.getElementById('cam-btn');
	if(session){ session.arreter(); session=null; v.classList.add('hidden'); btn.textContent='📷 Activer la caméra'; camMessage(''); return; }
	if(typeof FKCScanner==='undefined'){ camMessage('Lecteur en cours de chargement, réessayez dans un instant.'); return; }

	camMessage("Autorisez l'accès à la caméra dans la fenêtre du navigateur…");
	btn.disabled=true;
	v.classList.remove('hidden');

	FKCScanner.demarrer({
		video: v,
		onCode: function(code){ document.getElementById('scanbox').value=code; envoyer(); },
		onErreur: function(msg){ camMessage(msg); }
	}).then(function(s){
		session=s; btn.disabled=false; btn.textContent='📷 Couper la caméra'; camMessage('');
		var t=document.getElementById('cam-torche');
		if(t){ t.hidden=!s.torcheDisponible; }
	}).catch(function(e){
		btn.disabled=false; v.classList.add('hidden');
		// Le message porte la cause exacte : HTTPS manquant, permission refusée,
		// caméra occupée… au lieu d'un « impossible » qui n'aide personne.
		camMessage(e.message);
	});
}

function basculerTorche(){
	if(!session){ return; }
	var t=document.getElementById('cam-torche');
	torcheOn=!torcheOn;
	session.torche(torcheOn).then(function(ok){ if(t){ t.textContent=(ok&&torcheOn)?'💡 Éteindre':'💡 Lampe'; } });
}

</script>
</body></html>
