<?php
/**
 * Credit management — niveau 3 de la dépréciation des créances.
 *
 * CE QUE CE NIVEAU APPORTE, ET POURQUOI IL VIENT EN DERNIER
 *
 * Les niveaux 1 et 2 répondent à une question rétrospective : cette créance-ci
 * vaut-elle encore ce qu'elle dit, et l'administration l'admettra-t-elle ? Le
 * niveau 3 pose la question dans l'autre sens — à quoi l'entreprise s'expose,
 * et de combien.
 *
 * Il ne pouvait pas venir avant, parce qu'il repose sur des données que rien ne
 * collectait : ce qu'on a ACCEPTÉ de faire porter à chaque client (la limite de
 * crédit), et ce qu'on a obtenu en face (les garanties). Sans ces deux
 * éléments, tout calcul d'exposition est une fiction.
 *
 * LA RÈGLE QUI RELIE CE NIVEAU AU PREMIER
 *
 * Une créance garantie ne se déprécie pas à cent pour cent. La dépréciation
 * mesure une perte PROBABLE : si une caution bancaire couvre six millions sur
 * une créance de dix, la perte probable porte sur quatre. Déprécier les dix
 * revient à constater une charge qu'on ne subira pas — et la fraction
 * correspondante n'est pas déductible, l'administration considérant qu'une
 * créance garantie n'est pas compromise à hauteur de sa garantie.
 *
 * C'est le seul endroit du module où le niveau 3 CORRIGE le niveau 1 plutôt que
 * de l'enrichir. Le plafond qu'il impose est un garde-fou, pas une suggestion.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_CreditManagement {

	/**
	 * Natures de garantie, avec leur TAUX DE COUVERTURE RETENU.
	 *
	 * Une garantie ne vaut pas son montant nominal : elle vaut ce qu'on peut
	 * réellement en tirer, et dans le délai où on en aura besoin. Une caution
	 * bancaire à première demande se réalise en quelques jours pour la totalité ;
	 * une hypothèque suppose une procédure de plusieurs mois et une vente qui
	 * décote. Retenir le nominal pour toutes reviendrait à croire qu'une
	 * promesse de payer vaut de l'argent.
	 *
	 * Les taux sont paramétrables : ils dépendent du marché local et de
	 * l'expérience de l'entreprise, pas d'une vérité universelle.
	 */
	public static function typesGarantie() {
		return array(
			'caution_bancaire' => array( 'Caution bancaire à première demande', 100 ),
			'depot_garantie'   => array( 'Dépôt de garantie encaissé', 100 ),
			'aval'             => array( 'Aval ou lettre de garantie', 80 ),
			'hypotheque'       => array( 'Hypothèque', 70 ),
			'nantissement'     => array( 'Nantissement de matériel ou de stock', 50 ),
			'caution_perso'    => array( 'Caution personnelle du dirigeant', 30 ),
			'assurance_credit' => array( 'Assurance-crédit', 90 ),
			'autre'            => array( 'Autre garantie', 50 ),
		);
	}

	public static function tauxCouverture( $type ) {
		$t = self::typesGarantie();
		$defaut = isset( $t[ $type ] ) ? $t[ $type ][1] : 0;
		return (float) FKC_License::param( 'credit_taux_' . $type, $defaut );
	}

	/* ═══════════════ Limites de crédit ═══════════════ */

	public static function limite( $clientId ) {
		try {
			$r = FKC_DB::q( 'SELECT * FROM credit_limites WHERE client_id=?', array( (int) $clientId ) )->fetch();
		} catch ( \Throwable $e ) { return null; }
		return $r ?: null;
	}

	public static function definirLimite( $clientId, $montant, $motif = '' ) {
		$montant = round( (float) $montant );
		if ( $montant < 0 ) { return array( false, 'La limite ne peut pas être négative.' ); }
		try {
			$ex = self::limite( $clientId );
			if ( $ex ) {
				FKC_DB::q( "UPDATE credit_limites SET montant=?, motif=?, updated_at=datetime('now','localtime') WHERE client_id=?",
					array( $montant, trim( (string) $motif ) ?: null, (int) $clientId ) );
			} else {
				FKC_DB::q( 'INSERT INTO credit_limites(client_id,montant,motif,created_by) VALUES(?,?,?,?)',
					array( (int) $clientId, $montant, trim( (string) $motif ) ?: null, FKC_Auth::id() ) );
			}
		} catch ( \Throwable $e ) { return array( false, 'Enregistrement impossible : ' . $e->getMessage() ); }
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'credit_limite', 'Client #' . (int) $clientId . ' → ' . fkc_money( $montant ) . ' F' );
		}
		return array( true, 'Limite de crédit enregistrée.' );
	}

	/* ═══════════════ Garanties ═══════════════ */

	public static function garanties( $clientId ) {
		try {
			return FKC_DB::q(
				"SELECT * FROM credit_garanties WHERE client_id=? AND statut='active'
				 AND ( echeance IS NULL OR echeance >= date('now') ) ORDER BY id DESC",
				array( (int) $clientId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	public static function ajouterGarantie( $clientId, $type, $montant, $echeance = null, $reference = '', $note = '' ) {
		if ( ! isset( self::typesGarantie()[ $type ] ) ) { return array( false, 'Type de garantie inconnu.' ); }
		if ( (float) $montant <= 0 ) { return array( false, 'Montant obligatoire.' ); }
		try {
			FKC_DB::q(
				'INSERT INTO credit_garanties(client_id,type,montant,echeance,reference,note,statut,created_by)
				 VALUES(?,?,?,?,?,?,?,?)',
				array( (int) $clientId, $type, round( (float) $montant ), $echeance ?: null,
					trim( (string) $reference ) ?: null, trim( (string) $note ) ?: null, 'active', FKC_Auth::id() )
			);
		} catch ( \Throwable $e ) { return array( false, 'Enregistrement impossible : ' . $e->getMessage() ); }
		return array( true, 'Garantie enregistrée.' );
	}

	/**
	 * Valeur RETENUE des garanties d'un client, échues exclues.
	 *
	 * Une garantie expirée ne couvre plus rien. Le filtre sur l'échéance n'est
	 * pas un détail : une caution bancaire annuelle non renouvelée laisse
	 * l'entreprise découverte alors que le dossier affiche toujours « garanti ».
	 */
	public static function couverture( $clientId ) {
		$total = 0.0; $detail = array();
		foreach ( self::garanties( $clientId ) as $g ) {
			$taux = self::tauxCouverture( $g['type'] );
			$val  = round( (float) $g['montant'] * $taux / 100 );
			$total += $val;
			$detail[] = array( 'type' => $g['type'], 'nominal' => (float) $g['montant'],
				'taux' => $taux, 'retenu' => $val, 'echeance' => $g['echeance'] );
		}
		return array( 'total' => $total, 'detail' => $detail );
	}

	/* ═══════════════ Exposition et perte attendue ═══════════════ */

	/**
	 * Situation de crédit d'un client : encours, limite, garanties, exposition.
	 *
	 * L'EXPOSITION NETTE EST LE SEUL CHIFFRE QUI COMPTE VRAIMENT.
	 *
	 * L'encours dit ce que le client doit. L'exposition nette dit ce que
	 * l'entreprise perdrait s'il disparaissait demain — encours moins garanties
	 * réalisables. C'est sur elle qu'on décide d'accorder une commande de plus,
	 * pas sur l'encours brut.
	 */
	/**
	 * @param int        $clientId
	 * @param array|null $donnees instantané FKC_Recouvrement::compute() déjà
	 *                            calculé par l'appelant. Sans lui, l'analyse du
	 *                            portefeuille relançait le moteur complet UNE
	 *                            FOIS PAR CLIENT : trois cent un calculs de la
	 *                            balance âgée pour afficher trois cents lignes.
	 *                            L'écran devenait inutilisable bien avant que
	 *                            l'entreprise ne devienne grande.
	 */
	public static function situation( $clientId, $donnees = null ) {
		$enc = 0.0; $retard = 0.0; $score = 100; $jours = 0;
		if ( class_exists( 'FKC_Recouvrement' ) ) {
			try {
				$d = ( is_array( $donnees ) && isset( $donnees['clients'] ) ) ? $donnees : FKC_Recouvrement::compute();
				$c = $d['clients'][ (int) $clientId ] ?? null;
				if ( $c ) {
					$enc = (float) $c['encours']; $retard = (float) $c['retard'];
					$score = (int) $c['score']; $jours = (int) $c['jours_max'];
				}
			} catch ( \Throwable $e ) {}
		}
		$cov = self::couverture( $clientId );
		$lim = self::limite( $clientId );
		$limite = $lim ? (float) $lim['montant'] : null;

		$expo = max( 0.0, $enc - $cov['total'] );
		$prob = self::probabiliteRecuperation( $score, $jours, $enc, $cov['total'] );

		return array(
			'client_id' => (int) $clientId,
			'encours' => round( $enc ), 'retard' => round( $retard ),
			'score' => $score, 'jours_max' => $jours,
			'garanties' => round( $cov['total'] ), 'garanties_detail' => $cov['detail'],
			'exposition_nette' => round( $expo ),
			'limite' => null === $limite ? null : round( $limite ),
			'depassement' => ( null !== $limite && $enc > $limite ) ? round( $enc - $limite ) : 0,
			'disponible' => null === $limite ? null : round( max( 0, $limite - $enc ) ),
			'probabilite_recuperation' => $prob,
			// Perte attendue = exposition nette × probabilité de NE PAS récupérer.
			'perte_attendue' => round( $expo * ( 100 - $prob ) / 100 ),
		);
	}

	/**
	 * Probabilité de récupération, en pourcentage.
	 *
	 * CE N'EST PAS UN MODÈLE STATISTIQUE, ET IL NE FAUT PAS LE PRÉSENTER AINSI.
	 *
	 * C'est une combinaison explicite de trois facteurs observables : le
	 * comportement de paiement passé (le score du recouvrement), l'ancienneté du
	 * plus vieil impayé, et la part garantie. Un vrai modèle demanderait un
	 * historique de défauts que l'entreprise n'a pas — et prétendre en avoir un
	 * donnerait à un chiffre inventé l'autorité d'une mesure.
	 *
	 * Cette estimation sert au PILOTAGE : provisionnement prévisionnel, décision
	 * d'accorder une commande. Elle ne remplace jamais l'analyse individuelle,
	 * qui reste seule opposable à l'administration.
	 */
	public static function probabiliteRecuperation( $score, $joursRetard, $encours, $garanties ) {
		// Le score payeur donne la base : il résume le comportement passé.
		$p = 40 + ( (int) $score ) * 0.5;   // 40 % à 90 % selon le score

		// L'ancienneté érode cette base, et de plus en plus vite.
		if ( $joursRetard >= 720 )      { $p -= 40; }
		elseif ( $joursRetard >= 360 )  { $p -= 28; }
		elseif ( $joursRetard >= 180 )  { $p -= 18; }
		elseif ( $joursRetard >= 90 )   { $p -= 10; }
		elseif ( $joursRetard >= 30 )   { $p -= 4; }

		// La part garantie est récupérable quel que soit le comportement du
		// client : c'est précisément ce qu'on achète en prenant une garantie.
		if ( $encours > 0 && $garanties > 0 ) {
			$partGarantie = min( 1.0, $garanties / $encours );
			$p = $p + ( 100 - $p ) * $partGarantie;
		}
		return (int) max( 0, min( 100, round( $p ) ) );
	}

	/**
	 * PLAFOND DE DÉPRÉCIATION IMPOSÉ PAR LES GARANTIES.
	 *
	 * Retourne le taux maximal admissible pour une créance donnée. Une créance
	 * couverte à soixante pour cent ne peut pas être dépréciée au-delà de
	 * quarante : la fraction garantie n'est pas compromise, et la déprécier
	 * constate une charge qu'on ne subira pas — non déductible de surcroît.
	 *
	 * @return array{taux_max:float, garanties:float, motif:string}
	 */
	public static function plafondDepreciation( $clientId, $montantHt ) {
		$cov = self::couverture( $clientId );
		if ( $montantHt <= 0 || $cov['total'] <= 0 ) {
			return array( 'taux_max' => 100.0, 'garanties' => 0.0, 'motif' => '' );
		}
		$part = min( 1.0, $cov['total'] / $montantHt );
		$max  = round( ( 1 - $part ) * 100, 1 );
		return array(
			'taux_max'   => $max,
			'garanties'  => round( $cov['total'] ),
			'motif'      => 'Créance couverte à ' . round( $part * 100, 1 ) . ' % par des garanties '
				. '(' . fkc_money( $cov['total'] ) . ' F retenus) : la part garantie n\'est pas compromise.',
		);
	}

	/* ═══════════════ Portefeuille ═══════════════ */

	/**
	 * Analyse du portefeuille : exposition et perte attendue, tous clients.
	 *
	 * La perte attendue agrégée est une PRÉVISION, pas une provision. Elle
	 * anticipe ce que l'exercice coûtera si rien ne change ; la provision, elle,
	 * ne se constate que créance par créance, avec un motif. Les confondre
	 * produirait exactement la provision forfaitaire que le fisc réintègre.
	 */
	public static function portefeuille() {
		$out = array( 'clients' => array(), 'encours' => 0.0, 'garanties' => 0.0,
			'exposition' => 0.0, 'perte_attendue' => 0.0, 'depassements' => 0, 'sans_limite' => 0 );
		if ( ! class_exists( 'FKC_Recouvrement' ) ) { return $out; }
		try { $d = FKC_Recouvrement::compute(); } catch ( \Throwable $e ) { return $out; }

		foreach ( $d['clients'] as $cid => $c ) {
			if ( (float) $c['encours'] <= 0 ) { continue; }
			if ( 0 === (int) $cid ) { continue; } // poste collectif : pas de limite possible
			$s = self::situation( (int) $cid, $d );
			$s['nom'] = $c['nom'];
			$out['clients'][] = $s;
			$out['encours'] += $s['encours'];
			$out['garanties'] += $s['garanties'];
			$out['exposition'] += $s['exposition_nette'];
			$out['perte_attendue'] += $s['perte_attendue'];
			if ( $s['depassement'] > 0 ) { $out['depassements']++; }
			if ( null === $s['limite'] ) { $out['sans_limite']++; }
		}
		usort( $out['clients'], function ( $a, $b ) { return $b['perte_attendue'] <=> $a['perte_attendue']; } );
		foreach ( array( 'encours', 'garanties', 'exposition', 'perte_attendue' ) as $k ) {
			$out[ $k ] = round( $out[ $k ] );
		}
		return $out;
	}

	/**
	 * Le client peut-il recevoir une commande de plus ?
	 *
	 * Réponse à trois états plutôt qu'à deux : refuser sèchement un client qui
	 * dépasse de peu sa limite ferait perdre des ventes que l'entreprise peut
	 * assumer. C'est un avis, adressé à quelqu'un qui décide.
	 */
	public static function avisCommande( $clientId, $montant, $donnees = null ) {
		/*
		 * ICI, ET SEULEMENT ICI, ON REFUSE L'INSTANTANÉ.
		 *
		 * Le moteur de recouvrement mémorise son calcul pour la durée de la
		 * requête — ce qu'il faut pour les écrans, qui doivent tous parler du
		 * même instant. Mais cet avis-ci est une DÉCISION prise juste après une
		 * écriture : deux ventes à crédit enchaînées, et la seconde jugerait la
		 * limite du client sur un encours qui ignore la première.
		 *
		 * Un encours périmé de quelques secondes suffit à faire passer une
		 * commande qui aurait dû être refusée.
		 */
		$frais = ( is_array( $donnees ) && isset( $donnees['clients'] ) )
			? $donnees
			: ( class_exists( 'FKC_Recouvrement' ) ? FKC_Recouvrement::compute( true ) : null );
		$s = self::situation( $clientId, $frais );
		$apres = $s['encours'] + (float) $montant;

		if ( null === $s['limite'] ) {
			return array( 'avis' => 'attention', 'message' => 'Aucune limite de crédit définie pour ce client : '
				. 'l\'encours passerait à ' . fkc_money( $apres ) . ' F sans plafond convenu.' );
		}
		if ( $apres <= $s['limite'] ) {
			return array( 'avis' => 'ok', 'message' => 'Dans la limite : ' . fkc_money( $apres )
				. ' F sur ' . fkc_money( $s['limite'] ) . ' F autorisés.' );
		}
		$dep = $apres - $s['limite'];
		if ( $s['retard'] <= 0 && $dep <= $s['limite'] * 0.2 ) {
			return array( 'avis' => 'attention', 'message' => 'Dépassement de ' . fkc_money( $dep )
				. ' F, mais aucun impayé en cours : un accord ponctuel est défendable.' );
		}
		return array( 'avis' => 'refus', 'message' => 'Dépassement de ' . fkc_money( $dep ) . ' F'
			. ( $s['retard'] > 0 ? ' avec ' . fkc_money( $s['retard'] ) . ' F déjà en retard' : '' )
			. ' — exposition nette ' . fkc_money( $s['exposition_nette'] ) . ' F.' );
	}
}
