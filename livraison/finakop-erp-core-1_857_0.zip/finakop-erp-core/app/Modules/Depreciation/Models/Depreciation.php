<?php
/**
 * Dépréciation des créances clients — créances douteuses et litigieuses.
 *
 * CE QUE CE MODULE FAIT, ET CE QU'IL SE REFUSE À FAIRE
 *
 * Le recouvrement dit qu'une créance est en retard. Il ne dit pas ce qu'elle
 * VAUT. Une créance de dix millions sur un client en liquidation ne vaut pas
 * dix millions, et la porter à l'actif pour ce montant fausse le bilan dans le
 * sens le plus dangereux : celui qui rassure.
 *
 * Ce module conduit la chaîne complète :
 *
 *   recouvrement → identification du risque → ANALYSE INDIVIDUELLE →
 *   estimation de la perte probable → traitement comptable SYSCOHADA →
 *   qualification fiscale DGI → justification → validation →
 *   comptabilisation → suivi des reprises
 *
 * L'ANALYSE INDIVIDUELLE N'EST PAS UNE FORMALITÉ, C'EST LA CONDITION.
 *
 * Le système PROPOSE un taux à partir de l'ancienneté ; il n'en fait jamais une
 * dépréciation. Deux raisons, et la seconde est la plus contraignante :
 *
 *   — comptablement, une dépréciation mesure une perte PROBABLE, appréciée
 *     créance par créance. Un client à 120 jours qui a toujours payé et un
 *     client à 120 jours qui ne répond plus n'ont pas la même valeur probable,
 *     et aucune formule ne les distingue ;
 *   — fiscalement, une provision calculée de façon FORFAITAIRE ou STATISTIQUE
 *     n'est pas déductible. Une dépréciation générée automatiquement à partir
 *     d'un pourcentage d'ancienneté est exactement cela : elle serait
 *     réintégrée au résultat imposable, et l'entreprise paierait l'impôt sur
 *     une charge qu'elle a réellement subie.
 *
 * C'est pourquoi rien ne se comptabilise sans un motif écrit et une validation.
 *
 * LA DÉPRÉCIATION SE CALCULE SUR LE MONTANT HORS TAXES.
 *
 * La TVA facturée n'est pas une perte pour l'entreprise : elle est récupérable
 * auprès de l'État lorsque la créance devient définitivement irrécouvrable.
 * Déprécier le TTC surévalue la charge d'environ dix-huit pour cent et rend la
 * fraction correspondante non déductible.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Depreciation {

	/* ═══════════════ Comptes SYSCOHADA du mécanisme ═══════════════ */

	const C_CLIENT      = '411100'; // Clients
	const C_LITIGIEUX   = '416100'; // Créances litigieuses
	const C_DOUTEUX     = '416200'; // Créances douteuses
	const C_DEPRECIATION = '491200'; // Dépréciations des créances douteuses
	const C_DOTATION    = '659400'; // Charges pour dépréciations sur créances
	const C_REPRISE     = '759400'; // Reprises de charges pour dépréciations sur créances
	const C_PERTE       = '651100'; // Pertes sur créances clients

	/** Justificatifs qui PROUVENT l'irrécouvrabilité (passage en perte déductible). */
	const PREUVES_PERTE = array( 'liquidation', 'insolvabilite', 'huissier', 'action_judiciaire', 'accord' );

	protected static $schema = false;

	/**
	 * Registre des MOUVEMENTS (1.792.0) — dotation, reprise, encaissement,
	 * passage en perte, chacun à SA date.
	 *
	 * La fiche portait un seul exercice : celui du jour où l'analyse avait été
	 * ouverte. Une provision analysée en janvier N+1 et comptabilisée au
	 * 31/12/N tombait donc dans le relevé de N+1 ; celui de N — l'exercice
	 * dont elle réduit le résultat — était vide, et sa part non déductible ne
	 * remontait pas au tableau de passage. Une reprise de l'année suivante
	 * n'était datée nulle part. Le relevé se lit désormais sur les mouvements.
	 */
	public static function ensureSchema() {
		if ( self::$schema ) { return; }
		self::$schema = true;
		try {
			FKC_DB::conn()->exec( "CREATE TABLE IF NOT EXISTS depreciation_mouvements(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				depreciation_id INTEGER NOT NULL,
				type TEXT NOT NULL,          -- dotation | reprise | encaissement | perte
				date_mouvement TEXT NOT NULL,
				montant REAL NOT NULL DEFAULT 0,
				ttc REAL NOT NULL DEFAULT 0,
				ecriture_id INTEGER, brouillon_id INTEGER,
				motif TEXT,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_depmv ON depreciation_mouvements(depreciation_id, date_mouvement);" );
			$cols = array_column( FKC_DB::q( 'PRAGMA table_info(depreciations)' )->fetchAll(), 'name' );
			foreach ( array( 'reclasse_ttc' => 'REAL NOT NULL DEFAULT 0', 'montant_encaisse' => 'REAL NOT NULL DEFAULT 0',
				'montant_perte' => 'REAL NOT NULL DEFAULT 0', 'perte_deductible' => 'INTEGER', 'motif_perte' => 'TEXT' ) as $c => $def ) {
				if ( $cols && ! in_array( $c, $cols, true ) ) { FKC_DB::conn()->exec( "ALTER TABLE depreciations ADD COLUMN $c $def" ); }
			}
		} catch ( \Throwable $e ) {}
	}

	protected static function mouvement( $id, $type, $date, $montant, $ttc = 0.0, $eid = null, $bid = null, $motif = '' ) {
		self::ensureSchema();
		try {
			FKC_DB::q( 'INSERT INTO depreciation_mouvements(depreciation_id,type,date_mouvement,montant,ttc,ecriture_id,brouillon_id,motif) VALUES(?,?,?,?,?,?,?,?)',
				array( (int) $id, $type, $date, round( (float) $montant, 2 ), round( (float) $ttc, 2 ), $eid, $bid, (string) $motif ) );
		} catch ( \Throwable $e ) {}
	}

	public static function mouvements( $id ) {
		self::ensureSchema();
		try { return FKC_DB::q( 'SELECT * FROM depreciation_mouvements WHERE depreciation_id=? ORDER BY date_mouvement, id', array( (int) $id ) )->fetchAll(); }
		catch ( \Throwable $e ) { return array(); }
	}

	protected static function exerciceDe( $date ) {
		return class_exists( 'FKC_Exercice' ) ? (int) FKC_Exercice::annee( $date ) : (int) substr( (string) $date, 0, 4 );
	}

	/* ═══════════════ Vocabulaire ═══════════════ */

	public static function natures() {
		return array(
			'douteuse'   => 'Douteuse — le recouvrement est compromis',
			'litigieuse' => 'Litigieuse — la créance est contestée',
		);
	}

	public static function statuts() {
		return array(
			'analyse'   => 'En analyse',
			'a_valider' => 'À valider',
			'validee'   => 'Validée',
			/*
			 * 1.542.0 — état intermédiaire introduit avec le contrôle avant
			 * comptabilisation. La dépréciation est engagée, son écriture est
			 * écrite, mais elle attend au journal temporaire : le bilan ne
			 * porte pas encore la provision. Afficher « Comptabilisée » à ce
			 * stade ferait croire à un provisionnement qui n'a pas eu lieu.
			 */
			'en_attente' => 'Au journal temporaire',
			'comptabilisee' => 'Comptabilisée',
			'reprise'   => 'Reprise',
			'perte'     => 'Passée en perte',
			'abandonnee' => 'Abandonnée',
		);
	}

	/**
	 * Qualification fiscale — le vocabulaire de la DGI, pas celui du bilan.
	 *
	 * Une dépréciation comptablement justifiée peut être fiscalement refusée.
	 * Le cas le plus fréquent n'est pas la mauvaise foi : c'est l'absence de
	 * DILIGENCES. L'administration demande la preuve que l'entreprise a agi —
	 * relance écrite, mise en demeure, action judiciaire. Une créance qu'on a
	 * laissée vieillir sans rien faire n'ouvre pas droit à déduction, quelle
	 * que soit son ancienneté.
	 */
	public static function qualifications() {
		return array(
			'deductible'     => 'Déductible',
			'non_deductible' => 'Non déductible — à réintégrer',
			'partielle'      => 'Partiellement déductible',
			'a_qualifier'    => 'À qualifier',
		);
	}

	/** Types de justificatif reconnus par l'administration. */
	public static function justificatifs() {
		return array(
			'relance'          => 'Relance écrite',
			'mise_en_demeure'  => 'Mise en demeure',
			'huissier'         => 'Commandement d\'huissier',
			'action_judiciaire' => 'Action judiciaire engagée',
			'liquidation'      => 'Jugement de liquidation ou redressement',
			'insolvabilite'    => 'Procès-verbal de carence / insolvabilité',
			'accord'           => 'Accord transactionnel',
			'autre'            => 'Autre pièce',
		);
	}

	/* ═══════════════ Paramètres ═══════════════ */

	/** Ancienneté à partir de laquelle une créance mérite d'être examinée. */
	public static function seuilExamen() {
		return (int) FKC_License::param( 'depreciation_seuil_jours', 90 );
	}

	/** Montant en deçà duquel l'analyse individuelle ne se justifie pas. */
	public static function seuilMontant() {
		return (float) FKC_License::param( 'depreciation_seuil_montant', 50000 );
	}

	/**
	 * Taux INDICATIFS par ancienneté.
	 *
	 * Ce sont des repères d'usage, pas un barème. Ils servent à pré-remplir un
	 * champ que l'analyste doit confirmer ou corriger — jamais à décider.
	 * Retenir le taux proposé sans l'examiner produirait précisément la
	 * provision forfaitaire que le fisc réintègre.
	 */
	public static function tauxIndicatif( $jours ) {
		if ( $jours >= 720 ) { return 100; }
		if ( $jours >= 360 ) { return 75; }
		if ( $jours >= 180 ) { return 50; }
		if ( $jours >= 90 )  { return 25; }
		return 0;
	}

	/* ═══════════════ Niveau 1 — identification ═══════════════ */

	/**
	 * Créances qui méritent un examen, tirées du moteur de recouvrement.
	 *
	 * On ne recalcule pas l'ancienneté ici : ce serait une seconde source de
	 * vérité, qui divergerait le jour où l'un des deux modules changerait sa
	 * règle d'échéance. Le recouvrement est le seul à la connaître.
	 *
	 * Les créances DÉJÀ dépréciées sont exclues : la liste est une liste de
	 * travail, pas un inventaire.
	 */
	public static function candidats() {
		if ( ! class_exists( 'FKC_Recouvrement' ) ) { return array(); }
		$seuilJ = self::seuilExamen();
		$seuilM = self::seuilMontant();
		$deja   = self::facturesDejaTraitees();
		$out    = array();
		try {
			$d = FKC_Recouvrement::compute();
		} catch ( \Throwable $e ) { return array(); }

		foreach ( $d['factures'] as $f ) {
			if ( (int) $f['jours'] < $seuilJ ) { continue; }
			if ( (float) $f['montant'] < $seuilM ) { continue; }
			if ( isset( $deja[ (int) $f['facture_id'] ] ) ) { continue; }
			/*
			 * Une créance sans client rattaché ne peut pas faire l'objet d'une
			 * analyse individuelle : on ne peut apprécier ni la solvabilité ni
			 * les diligences d'un tiers qu'on n'identifie pas. Elle doit
			 * d'abord être raccrochée à un client.
			 */
			if ( 0 === (int) $f['client_id'] ) { continue; }
			/*
			 * Les créances des sources (cotisations, loyers, scolarité, pièces
			 * de dossier — 1.841.2) n'ont pas de facture : la dépréciation
			 * individuelle, qui se rattache à une facture et à son HT, ne les
			 * couvre pas encore.
			 */
			if ( empty( $f['facture_id'] ) ) { continue; }

			$ht  = self::montantHt( (int) $f['facture_id'], (float) $f['montant'] );
			/*
			 * LE PLAFOND IMPOSÉ PAR LES GARANTIES (niveau 3).
			 *
			 * Une créance couverte à soixante pour cent ne peut pas être
			 * dépréciée au-delà de quarante : la part garantie n'est pas
			 * compromise. Le taux indicatif est donc écrêté ici, avant même
			 * d'être proposé — proposer un taux qu'on refusera ensuite serait
			 * une invitation à se tromper.
			 */
			$plafond = class_exists( 'FKC_CreditManagement' )
				? FKC_CreditManagement::plafondDepreciation( (int) $f['client_id'], $ht )
				: array( 'taux_max' => 100.0, 'garanties' => 0.0, 'motif' => '' );
			$out[] = array(
				'facture_id'  => (int) $f['facture_id'],
				'client_id'   => (int) $f['client_id'],
				'client_nom'  => $f['client_nom'],
				'date_facture' => $f['date_facture'],
				'echeance'    => $f['echeance'],
				'jours'       => (int) $f['jours'],
				'montant_ttc' => (float) $f['montant'],
				'montant_ht'  => $ht,
				'taux_indicatif' => min( self::tauxIndicatif( (int) $f['jours'] ), $plafond['taux_max'] ),
				'taux_max'       => $plafond['taux_max'],
				'garanties'      => $plafond['garanties'],
				'motif_plafond'  => $plafond['motif'],
				// Le suivi de recouvrement qualifie déjà la situation : une
				// créance sous promesse n'est pas douteuse, elle est en cours.
				'suspendu'    => $f['suspendu'] ?? null,
			);
		}
		return $out;
	}

	/**
	 * Base dépréciable d'une facture : son montant HORS TAXES restant dû.
	 *
	 * La TVA facturée n'est pas une perte : elle se récupère auprès de l'État
	 * quand la créance devient définitivement irrécouvrable. La déprécier
	 * surévalue la charge d'environ dix-huit pour cent, et cette fraction est
	 * de surcroît non déductible.
	 *
	 * Quand le solde restant est partiel, on applique le même rapport HT/TTC
	 * que la facture d'origine : un règlement partiel s'impute proportionnellement
	 * sur la taxe et sur la base.
	 */
	public static function montantHt( $factureId, $resteTtc ) {
		try {
			$f = FKC_DB::q( 'SELECT montant_ht, montant_ttc FROM factures WHERE id=?', array( (int) $factureId ) )->fetch();
		} catch ( \Throwable $e ) { return (float) $resteTtc; }
		if ( ! $f || (float) $f['montant_ttc'] <= 0 ) { return (float) $resteTtc; }
		$ratio = (float) $f['montant_ht'] / (float) $f['montant_ttc'];
		return round( (float) $resteTtc * $ratio );
	}

	/** Factures déjà portées à une dépréciation vivante. */
	protected static function facturesDejaTraitees() {
		$out = array();
		try {
			$rows = FKC_DB::q(
				"SELECT facture_id FROM depreciations
				 WHERE facture_id IS NOT NULL AND statut NOT IN ('abandonnee','reprise')"
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( $rows as $r ) { $out[ (int) $r['facture_id'] ] = true; }
		return $out;
	}

	/* ═══════════════ Niveau 1 — analyse individuelle ═══════════════ */

	/**
	 * Ouvre une analyse. Rien n'est comptabilisé à ce stade.
	 *
	 * @param array $d facture_id, client_id, nature, montant_ht, taux, motif
	 * @return array{0:bool,1:string,2:int|null}
	 */
	public static function ouvrir( array $d ) {
		$factureId = (int) ( $d['facture_id'] ?? 0 );
		$clientId  = (int) ( $d['client_id'] ?? 0 );
		$nature    = (string) ( $d['nature'] ?? 'douteuse' );
		$ht        = round( (float) ( $d['montant_ht'] ?? 0 ) );
		$taux      = (float) ( $d['taux'] ?? 0 );
		$motif     = trim( (string) ( $d['motif'] ?? '' ) );

		if ( ! $clientId )                  { return array( false, 'Client obligatoire.', null ); }
		if ( ! isset( self::natures()[ $nature ] ) ) { return array( false, 'Nature inconnue.', null ); }
		if ( $ht <= 0 )                     { return array( false, 'Montant hors taxes obligatoire.', null ); }
		if ( $taux < 0 || $taux > 100 )     { return array( false, 'Le taux doit être compris entre 0 et 100 %.', null ); }
		/*
		 * LE MOTIF EST OBLIGATOIRE, ET C'EST LE CŒUR DU DISPOSITIF.
		 *
		 * Sans lui, la dépréciation redevient forfaitaire : rien ne distingue
		 * plus une créance analysée d'une créance passée au barème. C'est ce
		 * motif que l'administration lira, et c'est lui qui fera la différence
		 * entre une charge déduite et une charge réintégrée.
		 */
		if ( strlen( $motif ) < 10 ) {
			return array( false, 'Un motif d\'au moins dix caractères est requis : c\'est lui qui '
				. 'justifie l\'analyse individuelle, sans laquelle la provision n\'est pas déductible.', null );
		}

		/*
		 * LE PLAFOND EST UN REFUS, PAS UN AVERTISSEMENT.
		 *
		 * Déprécier au-delà de la part non garantie constate une charge qu'on
		 * ne subira pas, et l'administration la réintègre : elle considère
		 * qu'une créance garantie n'est pas compromise à hauteur de sa
		 * garantie. Laisser passer avec un simple message reviendrait à laisser
		 * l'utilisateur fabriquer un redressement.
		 *
		 * Une garantie ÉCHUE ne compte pas — c'est FKC_CreditManagement qui
		 * l'écarte, pas ce contrôle.
		 */
		if ( class_exists( 'FKC_CreditManagement' ) ) {
			$plafond = FKC_CreditManagement::plafondDepreciation( $clientId, $ht );
			if ( $taux > $plafond['taux_max'] + 0.01 ) {
				return array( false, 'Taux plafonné à ' . $plafond['taux_max'] . ' % : ' . $plafond['motif']
					. ' Réduisez le taux, ou levez la garantie au dossier si elle n\'est plus mobilisable.', null );
			}
		}

		$montant = round( $ht * $taux / 100 );
		try {
			FKC_DB::q(
				'INSERT INTO depreciations(facture_id,client_id,nature,montant_ht,taux,montant_depreciation,
				 statut,qualification,motif,exercice,created_by)
				 VALUES(?,?,?,?,?,?,?,?,?,?,?)',
				array( $factureId ?: null, $clientId, $nature, $ht, $taux, $montant,
					'analyse', 'a_qualifier', $motif, self::exercice(), FKC_Auth::id() )
			);
			$id = (int) FKC_DB::conn()->lastInsertId();
		} catch ( \Throwable $e ) { return array( false, 'Enregistrement impossible : ' . $e->getMessage(), null ); }

		self::tracer( $id, 'ouverture', 'Analyse ouverte — ' . $nature . ', taux ' . $taux . ' %' );
		return array( true, 'Analyse ouverte.', $id );
	}

	/** Exercice de rattachement : l'année de la date du jour. */
	/**
	 * Exercice de rattachement d'une dépréciation.
	 *
	 * L'EXERCICE en cours, pas l'année en cours (1.544.0) : chez un dossier
	 * clôturant au 30/06, une provision constatée en septembre appartient à
	 * l'exercice suivant, et le relevé des provisions joint à la déclaration
	 * la rangeait dans le mauvais.
	 */
	public static function exercice() {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'courant' ) ) {
			return (int) FKC_Exercice::courant();
		}
		return (int) date( 'Y' );
	}

	/**
	 * Recale le statut d'une dépréciation dont l'écriture vient d'être validée.
	 *
	 * POURQUOI CE RECALAGE EXISTE (1.542.0)
	 *
	 * Quand l'écriture attend au journal temporaire, la dépréciation passe en
	 * `en_attente`. Sa comptabilisation effective survient ailleurs — dans
	 * FKC_Brouillard::valider() —, qui renseigne `ecriture_id` par le
	 * mécanisme de lien générique mais ne connaît RIEN aux statuts métier de
	 * chaque module : c'est précisément ce qui le rend générique.
	 *
	 * Plutôt que d'apprendre au brouillard le vocabulaire de tous les modules,
	 * on lit la vérité là où elle est : une dépréciation dont l'écriture
	 * existe EST comptabilisée. Le statut se recale donc à la lecture, une
	 * fois, sans que personne ait à y penser.
	 */
	protected static function recaler( $d ) {
		if ( ! is_array( $d ) ) { return $d; }
		if ( 'en_attente' === ( $d['statut'] ?? '' ) && ! empty( $d['ecriture_id'] ) ) {
			$d['statut'] = 'comptabilisee';
			try {
				FKC_DB::q( "UPDATE depreciations SET statut='comptabilisee' WHERE id=? AND statut='en_attente'",
					array( (int) $d['id'] ) );
			} catch ( \Throwable $e ) {}
		}
		return $d;
	}

	public static function find( $id ) {
		self::ensureSchema();
		try {
			$d = FKC_DB::q( 'SELECT * FROM depreciations WHERE id=?', array( (int) $id ) )->fetch() ?: null;
		} catch ( \Throwable $e ) { return null; }
		return $d ? self::recaler( $d ) : null;
	}

	public static function lister( $statut = null, $exercice = null ) {
		self::ensureSchema();
		$sql = 'SELECT d.*, c.nom client_nom FROM depreciations d LEFT JOIN clients c ON c.id=d.client_id';
		$w = array(); $p = array();
		if ( $statut )   { $w[] = 'd.statut=?';   $p[] = $statut; }
		if ( $exercice ) { $w[] = 'd.exercice=?'; $p[] = (int) $exercice; }
		if ( $w ) { $sql .= ' WHERE ' . implode( ' AND ', $w ); }
		$sql .= ' ORDER BY d.id DESC';
		try { $rows = FKC_DB::q( $sql, $p )->fetchAll(); } catch ( \Throwable $e ) { return array(); }
		return array_map( array( __CLASS__, 'recaler' ), $rows );
	}

	/* ═══════════════ Niveau 2 — qualification fiscale ═══════════════ */

	/**
	 * Qualifie fiscalement une dépréciation et calcule la part à réintégrer.
	 *
	 * LA RÉINTÉGRATION N'EST PAS UNE SANCTION, C'EST UNE MÉCANIQUE.
	 *
	 * La charge reste en comptabilité — le bilan doit dire la vérité sur ce que
	 * vaut la créance. Ce qui change, c'est le résultat FISCAL : la fraction non
	 * déductible y est rajoutée, et l'impôt se calcule dessus. Confondre les
	 * deux conduit soit à un bilan flatteur, soit à un redressement.
	 *
	 * @param int    $id
	 * @param string $qualification deductible | non_deductible | partielle
	 * @param float  $partDeductible pourcentage, utilisé si « partielle »
	 * @param string $justification  ce que l'entreprise opposera au contrôle
	 */
	public static function qualifier( $id, $qualification, $partDeductible = 100, $justification = '' ) {
		$d = self::find( $id );
		if ( ! $d ) { return array( false, 'Dépréciation introuvable.' ); }
		if ( ! isset( self::qualifications()[ $qualification ] ) ) { return array( false, 'Qualification inconnue.' ); }

		$part = 'deductible' === $qualification ? 100.0
			: ( 'non_deductible' === $qualification ? 0.0 : max( 0.0, min( 100.0, (float) $partDeductible ) ) );

		/*
		 * Une déduction sans justificatif ne tient pas devant un contrôle.
		 * L'administration ne conteste presque jamais le MONTANT : elle
		 * conteste l'absence de diligences. On refuse donc de qualifier une
		 * dépréciation de déductible tant qu'aucune pièce n'est attachée.
		 */
		if ( $part > 0 && 0 === self::nbJustificatifs( $id ) ) {
			return array( false, 'Aucun justificatif attaché : une provision déductible suppose des '
				. 'diligences prouvées (relance écrite, mise en demeure, action judiciaire). '
				. 'Attachez la pièce avant de qualifier.' );
		}
		if ( $part < 100 && strlen( trim( (string) $justification ) ) < 10 ) {
			return array( false, 'Une part non déductible doit être motivée : c\'est ce texte qui '
				. 'figurera au relevé des provisions joint à la déclaration.' );
		}

		$reintegration = round( (float) $d['montant_depreciation'] * ( 100 - $part ) / 100 );
		try {
			FKC_DB::q(
				'UPDATE depreciations SET qualification=?, part_deductible=?, montant_reintegration=?,
				 justification_fiscale=? WHERE id=?',
				array( $qualification, $part, $reintegration, trim( (string) $justification ) ?: null, (int) $id )
			);
		} catch ( \Throwable $e ) { return array( false, 'Mise à jour impossible : ' . $e->getMessage() ); }

		self::tracer( $id, 'qualification', self::qualifications()[ $qualification ]
			. ( $reintegration > 0 ? ' — à réintégrer : ' . fkc_money( $reintegration ) . ' F' : '' ) );
		return array( true, 'Qualification enregistrée.' );
	}

	public static function nbJustificatifs( $id ) {
		try {
			return (int) FKC_DB::q( 'SELECT COUNT(*) FROM depreciation_justificatifs WHERE depreciation_id=?',
				array( (int) $id ) )->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	public static function ajouterJustificatif( $id, $type, $reference, $date, $note = '' ) {
		if ( ! isset( self::justificatifs()[ $type ] ) ) { return array( false, 'Type de pièce inconnu.' ); }
		if ( ! self::find( $id ) ) { return array( false, 'Dépréciation introuvable.' ); }
		try {
			FKC_DB::q(
				'INSERT INTO depreciation_justificatifs(depreciation_id,type,reference,date_piece,note,created_by)
				 VALUES(?,?,?,?,?,?)',
				array( (int) $id, $type, trim( (string) $reference ) ?: null,
					$date ?: date( 'Y-m-d' ), trim( (string) $note ) ?: null, FKC_Auth::id() )
			);
		} catch ( \Throwable $e ) { return array( false, 'Enregistrement impossible : ' . $e->getMessage() ); }
		self::tracer( $id, 'justificatif', self::justificatifs()[ $type ]
			. ( $reference ? ' — ' . $reference : '' ) );
		return array( true, 'Justificatif attaché.' );
	}

	public static function justificatifsDe( $id ) {
		try {
			return FKC_DB::q( 'SELECT * FROM depreciation_justificatifs WHERE depreciation_id=? ORDER BY date_piece ASC',
				array( (int) $id ) )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/* ═══════════════ Validation puis comptabilisation ═══════════════ */

	/**
	 * Validation — l'étape qui sépare l'analyse de l'écriture.
	 *
	 * Elle existe parce qu'une dotation modifie le résultat de l'exercice. La
	 * personne qui analyse une créance et celle qui engage le résultat ne sont
	 * pas nécessairement la même, et l'écart entre les deux est précisément ce
	 * qu'un commissaire aux comptes vient vérifier.
	 */
	public static function valider( $id ) {
		$d = self::find( $id );
		if ( ! $d ) { return array( false, 'Dépréciation introuvable.' ); }
		if ( 'analyse' !== $d['statut'] && 'a_valider' !== $d['statut'] ) {
			return array( false, 'Seule une dépréciation en analyse peut être validée.' );
		}
		if ( 'a_qualifier' === $d['qualification'] ) {
			return array( false, 'Qualifiez d\'abord la dépréciation au regard de la DGI : '
				. 'sans cela, le relevé des provisions serait incomplet.' );
		}
		/*
		 * LE SEUIL DE VALIDATION APPARTIENT À LA SOCIÉTÉ, PAS AU LOGICIEL.
		 *
		 * Une dotation modifie le résultat de l'exercice. À partir de quel
		 * montant la décision cesse-t-elle d'être individuelle ? Une SARL
		 * familiale et un groupe n'ont pas la même réponse, et aucune valeur
		 * écrite ici ne conviendrait aux deux. FKC_WorkflowValidation lit les
		 * seuils du dossier courant.
		 */
		if ( class_exists( 'FKC_WorkflowValidation' ) ) {
			list( $autorise, $motif ) = FKC_WorkflowValidation::peutValider( (float) $d['montant_depreciation'] );
			if ( ! $autorise ) { return array( false, $motif ); }
		}
		try {
			FKC_DB::q( "UPDATE depreciations SET statut='validee', valide_par=?, valide_at=datetime('now','localtime') WHERE id=?",
				array( FKC_Auth::id(), (int) $id ) );
		} catch ( \Throwable $e ) { return array( false, 'Validation impossible : ' . $e->getMessage() ); }
		$niv = class_exists( 'FKC_WorkflowValidation' )
			? FKC_WorkflowValidation::niveauRequis( (float) $d['montant_depreciation'] ) : null;
		self::tracer( $id, 'validation', 'Validée pour comptabilisation'
			. ( $niv ? ' — niveau requis : ' . $niv['libelle'] : '' ) );
		return array( true, 'Dépréciation validée.' );
	}

	/**
	 * Comptabilise le transfert en douteux ET la dotation.
	 *
	 * DEUX ÉCRITURES, ET PAS UNE.
	 *
	 *   1. Reclassement : D 416 « Créances litigieuses ou douteuses » / C 411.
	 *      La créance sort du poste clients ordinaire. C'est ce reclassement que
	 *      la liasse attend, et il porte sur le montant TTC : c'est bien cette
	 *      somme que le client doit.
	 *   2. Dotation : D 6594 / C 4912, sur le montant HORS TAXES déprécié.
	 *      La TVA n'est pas une perte — elle se récupère si la créance devient
	 *      définitivement irrécouvrable.
	 *
	 * Les fusionner en une seule écriture est l'erreur la plus courante : elle
	 * fait disparaître le reclassement, et le poste clients continue d'afficher
	 * une créance saine.
	 */
	public static function comptabiliser( $id, $date = null ) {
		$d = self::find( $id );
		if ( ! $d ) { return array( false, 'Dépréciation introuvable.' ); }
		if ( 'validee' !== $d['statut'] ) { return array( false, 'La dépréciation doit être validée au préalable.' ); }
		$date = $date ?: date( 'Y-m-d' );
		// Écriture d'inventaire : c'est la clôture de l'EXERCICE qui l'arrête,
		// pas le verrou d'un mois (cf. FKC_Cloture::isExerciceClos()).
		if ( class_exists( 'FKC_Cloture' ) && FKC_Cloture::isExerciceClos( $date ) ) {
			return array( false, 'L\'exercice couvrant le ' . $date . ' est clos : cette dépréciation '
				. 'modifierait un résultat déjà déterminé.' );
		}

		$ttc = self::resteTtc( $d );
		$dot = (float) $d['montant_depreciation'];
		$nom = self::clientNom( (int) $d['client_id'] );

		$lignes = array();
		if ( $ttc > 0 ) {
			$compteDouteux = 'litigieuse' === $d['nature'] ? self::C_LITIGIEUX : self::C_DOUTEUX;
			/*
			 * Le TIERS sur les deux lignes (1.792.0) : le compte auxiliaire du
			 * client reste juste — la créance change de poste, pas de débiteur —
			 * et un encaissement ultérieur se lettre contre elle.
			 */
			$tiers = array( 'tiers_type' => 'client', 'tiers_id' => (int) $d['client_id'] );
			$lignes[] = array( 'compte' => $compteDouteux, 'debit' => $ttc, 'credit' => 0,
				'libelle' => 'Reclassement en créance ' . $d['nature'] . ' — ' . $nom ) + $tiers;
			$lignes[] = array( 'compte' => self::client( (int) $d['client_id'] ), 'debit' => 0, 'credit' => $ttc,
				'libelle' => 'Reclassement en créance ' . $d['nature'] . ' — ' . $nom ) + $tiers;
		}
		if ( $dot > 0 ) {
			$lignes[] = array( 'compte' => self::C_DOTATION, 'debit' => $dot, 'credit' => 0,
				'libelle' => 'Dotation dépréciation — ' . $nom );
			$lignes[] = array( 'compte' => self::C_DEPRECIATION, 'debit' => 0, 'credit' => $dot,
				'libelle' => 'Dépréciation créance — ' . $nom );
		}
		if ( ! $lignes ) { return array( false, 'Rien à comptabiliser : ni reclassement ni dotation.' ); }

		list( $ok, $msg, $eid, $bid ) = self::passer( $lignes, $date,
			'Dépréciation créance ' . $nom, 'DEP-' . $id, (int) $id );
		if ( ! $ok ) { return array( false, $msg ); }

		/*
		 * Le statut ne dit « comptabilisée » que si elle l'est. Tant que
		 * l'écriture attend au journal temporaire, la dépréciation est
		 * ENGAGÉE mais pas comptabilisée : afficher le contraire ferait
		 * croire à un provisionnement que le bilan ne porte pas encore.
		 * `ecriture_id` est renseigné par le brouillard à la validation.
		 */
		try {
			// L'exercice est celui de la DATE de l'écriture (1.792.0), pas celui
			// du jour où l'analyse a été ouverte : c'est ce résultat-là qu'elle réduit.
			FKC_DB::q( 'UPDATE depreciations SET statut=?, ecriture_id=?, date_comptabilisation=?, exercice=?, reclasse_ttc=? WHERE id=?',
				array( $bid ? 'en_attente' : 'comptabilisee', $eid, $date, self::exerciceDe( $date ), $ttc, (int) $id ) );
		} catch ( \Throwable $e ) {}
		self::mouvement( $id, 'dotation', $date, $dot, $ttc, $eid, $bid, 'Reclassement et dotation' );
		self::tracer( $id, $bid ? 'depot_journal_temporaire' : 'comptabilisation',
			'Reclassement ' . fkc_money( $ttc ) . ' F, dotation ' . fkc_money( $dot ) . ' F' );
		$chiffres = 'reclassement ' . fkc_money( $ttc ) . ' F, dotation ' . fkc_money( $dot ) . ' F.';
		if ( $bid ) {
			return array( true, 'Dépréciation déposée au journal temporaire — à vérifier avant '
				. 'comptabilisation : ' . $chiffres );
		}
		return array( true, 'Dépréciation comptabilisée : ' . $chiffres );
	}

	/**
	 * Reprise — totale ou partielle.
	 *
	 * Une reprise se justifie autant qu'une dotation. Deux cas seulement : le
	 * client a payé, ou la perte s'est révélée moindre qu'estimée. Reprendre
	 * une dépréciation pour améliorer un résultat est le motif classique de
	 * redressement, et le motif écrit est ce qui distingue les deux.
	 */
	public static function reprendre( $id, $montant = null, $motif = '', $date = null ) {
		$d = self::find( $id );
		if ( ! $d ) { return array( false, 'Dépréciation introuvable.' ); }
		if ( 'comptabilisee' !== $d['statut'] ) {
			return array( false, 'Seule une dépréciation comptabilisée peut être reprise.' );
		}
		$max = (float) $d['montant_depreciation'] - (float) $d['montant_repris'];
		$montant = null === $montant ? $max : round( (float) $montant );
		if ( $montant <= 0 || $montant > $max ) {
			return array( false, 'Montant de reprise hors limites : au plus ' . fkc_money( $max ) . ' F.' );
		}
		if ( strlen( trim( (string) $motif ) ) < 10 ) {
			return array( false, 'Un motif est requis : une reprise non motivée est le premier '
				. 'motif de redressement sur les provisions.' );
		}
		$date = $date ?: date( 'Y-m-d' );
		if ( class_exists( 'FKC_Cloture' ) && FKC_Cloture::isExerciceClos( $date ) ) {
			return array( false, 'L\'exercice couvrant le ' . $date . ' est clos : cette reprise '
				. 'modifierait un résultat déjà déterminé.' );
		}
		$nom = self::clientNom( (int) $d['client_id'] );
		list( $ok, $msg, $eid, $bid ) = self::passer( array(
			array( 'compte' => self::C_DEPRECIATION, 'debit' => $montant, 'credit' => 0,
				'libelle' => 'Reprise dépréciation — ' . $nom ),
			array( 'compte' => self::C_REPRISE, 'debit' => 0, 'credit' => $montant,
				'libelle' => 'Reprise dépréciation — ' . $nom ),
		), $date, 'Reprise dépréciation ' . $nom, 'REP-' . $id );
		if ( ! $ok ) { return array( false, $msg ); }

		self::mouvement( $id, 'reprise', $date, $montant, 0.0, $eid, $bid, trim( (string) $motif ) );
		$repris = (float) $d['montant_repris'] + $montant;
		$statut = $repris >= (float) $d['montant_depreciation'] ? 'reprise' : 'comptabilisee';
		try {
			FKC_DB::q( 'UPDATE depreciations SET montant_repris=?, statut=?, motif_reprise=? WHERE id=?',
				array( $repris, $statut, trim( (string) $motif ), (int) $id ) );
		} catch ( \Throwable $e ) {}
		self::tracer( $id, 'reprise', fkc_money( $montant ) . ' F — ' . $motif );
		if ( $bid ) {
			return array( true, 'Reprise de ' . fkc_money( $montant ) . ' F déposée au journal temporaire — '
				. 'à vérifier avant comptabilisation.' );
		}
		return array( true, 'Reprise de ' . fkc_money( $montant ) . ' F comptabilisée.' );
	}

	/* ═══════════════ Encaissement d'une créance reclassée (1.792.0) ═══════════════ */

	/**
	 * Le client paie une créance déjà reclassée en douteuse.
	 *
	 * LE DÉFAUT CORRIGÉ. Le règlement ne sait rien de la dépréciation : il
	 * crédite le compte client (411100). Or la créance n'y est plus — elle a
	 * été transférée en 416. Résultat : 411 créditeur du montant payé, 416
	 * toujours débiteur de la créance entière, et une provision qui continue de
	 * couvrir une somme encaissée. Bilan équilibré, donc silencieux, et deux
	 * fois faux.
	 *
	 * Deux gestes, tous deux objectifs — c'est l'argent reçu qui les dicte :
	 *   1. D 411 / C 416 sur la part encaissée : la créance douteuse diminue de
	 *      ce qui a été payé, le compte client retrouve l'équilibre ;
	 *   2. reprise de la provision devenue sans objet : la provision requise
	 *      n'est plus que le taux appliqué au HT RESTANT dû. Le motif est
	 *      l'encaissement lui-même, daté et chiffré.
	 *
	 * Appelé par FKC_Reglement::create() pour chaque facture nommée dans la
	 * répartition ; appelable à la main pour un règlement non réparti.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function constaterEncaissement( $factureId, $montantTtc, $date = null, $reglementId = null ) {
		self::ensureSchema();
		$date = $date ?: date( 'Y-m-d' );
		$montantTtc = round( (float) $montantTtc, 2 );
		if ( $montantTtc <= 0 ) { return array( false, 'Montant nul.' ); }
		try {
			$d = FKC_DB::q( "SELECT * FROM depreciations WHERE facture_id=? AND statut IN ('comptabilisee','en_attente') ORDER BY id DESC LIMIT 1", array( (int) $factureId ) )->fetch();
		} catch ( \Throwable $e ) { $d = null; }
		if ( ! $d ) { return array( true, 'Aucune créance douteuse sur cette facture.' ); }
		$d = self::recaler( $d );
		$reclasse = (float) $d['reclasse_ttc'] > 0 ? (float) $d['reclasse_ttc'] : self::resteTtc( $d );
		$restant = round( $reclasse - (float) $d['montant_encaisse'], 2 );
		if ( $restant <= 0 ) { return array( true, 'Créance douteuse déjà entièrement encaissée.' ); }
		$part = min( $montantTtc, $restant );
		$nom = self::clientNom( (int) $d['client_id'] );
		$tiers = array( 'tiers_type' => 'client', 'tiers_id' => (int) $d['client_id'] );
		$compte416 = 'litigieuse' === $d['nature'] ? self::C_LITIGIEUX : self::C_DOUTEUX;
		$lib = 'Encaissement sur créance ' . $d['nature'] . ' — ' . $nom . ( $reglementId ? ' (règlement #' . (int) $reglementId . ')' : '' );
		list( $ok, $msg, $eid, $bid ) = self::passer( array(
			array( 'compte' => self::client( (int) $d['client_id'] ), 'debit' => $part, 'credit' => 0, 'libelle' => $lib ) + $tiers,
			array( 'compte' => $compte416, 'debit' => 0, 'credit' => $part, 'libelle' => $lib ) + $tiers,
		), $date, $lib, 'ENC-DEP-' . (int) $d['id'] );
		if ( ! $ok ) { return array( false, $msg ); }
		$encaisse = round( (float) $d['montant_encaisse'] + $part, 2 );
		try { FKC_DB::q( 'UPDATE depreciations SET montant_encaisse=? WHERE id=?', array( $encaisse, (int) $d['id'] ) ); } catch ( \Throwable $e ) {}
		self::mouvement( $d['id'], 'encaissement', $date, $part, $part, $eid, $bid, $lib );
		self::tracer( $d['id'], 'encaissement', fkc_money( $part ) . ' F encaissés — créance douteuse ramenée à ' . fkc_money( $reclasse - $encaisse ) . ' F' );

		// Reprise de la provision devenue sans objet.
		$msgR = '';
		if ( 'comptabilisee' === $d['statut'] ) {
			$htRestant = $reclasse > 0 ? (float) $d['montant_ht'] * max( 0.0, $reclasse - $encaisse ) / $reclasse : 0.0;
			$requis = round( $htRestant * (float) $d['taux'] / 100 );
			$stock = (float) $d['montant_depreciation'] - (float) $d['montant_repris'];
			$aReprendre = round( $stock - $requis );
			if ( $aReprendre >= 1 ) {
				list( $okR, $mR ) = self::reprendre( (int) $d['id'], $aReprendre,
					'Encaissement de ' . fkc_money( $part ) . ' F le ' . date( 'd/m/Y', strtotime( $date ) ) . ' : la provision n\'est plus requise que sur le reste dû', $date );
				$msgR = $okR ? ' ' . $mR : ' Reprise non passée : ' . $mR;
			}
		} else {
			$msgR = ' La dotation attend au journal temporaire : la reprise sera à passer après sa validation.';
		}
		return array( true, 'Créance douteuse diminuée de ' . fkc_money( $part ) . ' F.' . $msgR );
	}

	/**
	 * Encaissement reçu mais pas encore porté sur la créance douteuse : le
	 * client a payé par un règlement NON réparti par facture (lettrage FIFO).
	 * On le lit sur le reste dû de la facture, que le recouvrement connaît.
	 */
	public static function encaissementNonConstate( $id ) {
		$d = self::find( $id );
		if ( ! $d || empty( $d['facture_id'] ) || ! in_array( $d['statut'], array( 'comptabilisee', 'en_attente' ), true ) ) { return 0.0; }
		if ( ! class_exists( 'FKC_Imputation' ) ) { return 0.0; }
		$reste = null;
		try {
			FKC_Imputation::oublier();
			foreach ( FKC_Imputation::postesClient( (int) $d['client_id'] )['factures'] as $f ) {
				if ( (int) $f['id'] === (int) $d['facture_id'] ) { $reste = (float) $f['reste']; break; }
			}
		} catch ( \Throwable $e ) { return 0.0; }
		if ( null === $reste ) { $reste = 0.0; }
		$reclasse = (float) $d['reclasse_ttc'] > 0 ? (float) $d['reclasse_ttc'] : self::resteTtc( $d );
		return max( 0.0, round( ( $reclasse - (float) $d['montant_encaisse'] ) - $reste, 2 ) );
	}

	/** Toutes les créances douteuses sur lesquelles un encaissement attend d'être constaté. */
	public static function encaissementsNonConstates() {
		$out = array();
		foreach ( self::lister() as $d ) {
			if ( ! in_array( $d['statut'], array( 'comptabilisee', 'en_attente' ), true ) ) { continue; }
			$m = self::encaissementNonConstate( (int) $d['id'] );
			if ( $m >= 1 ) { $out[] = array( 'id' => (int) $d['id'], 'client' => $d['client_nom'], 'montant' => $m, 'facture_id' => (int) $d['facture_id'] ); }
		}
		return $out;
	}

	/* ═══════════════ Passage en perte (1.792.0) ═══════════════ */

	/**
	 * Constate une créance DÉFINITIVEMENT irrécouvrable.
	 *
	 * Le statut « Passée en perte » existait au vocabulaire du module ; aucune
	 * fonction ne le produisait. Une créance perdue restait donc éternellement
	 * provisionnée en 416/491 — une perte certaine traitée comme une perte
	 * probable, et un poste client qui ne se nettoyait jamais.
	 *
	 * Une seule écriture, trois mouvements :
	 *   D 651 « Pertes sur créances » ........ HT restant dû
	 *   D 443 « TVA facturée » ............... TVA de la part perdue, si elle
	 *                                          est récupérée (sinon en 651)
	 *   C 416 « Créances douteuses » ......... TTC restant dû
	 *   D 491 / C 759 ........................ reprise de la provision restante,
	 *                                          devenue sans objet
	 *
	 * DÉDUCTIBILITÉ. La perte n'est déductible que si l'irrécouvrabilité est
	 * PROUVÉE : jugement de liquidation, procès-verbal de carence, commandement
	 * d'huissier resté vain, action judiciaire, accord transactionnel. Sans
	 * l'une de ces pièces, la perte se constate — le bilan doit dire la vérité —
	 * mais elle est qualifiée non déductible et remonte au tableau de passage.
	 * La TVA ne se récupère, elle aussi, que sur une irrécouvrabilité prouvée.
	 */
	public static function passerEnPerte( $id, $motif, $date = null, $recupererTva = true ) {
		self::ensureSchema();
		$d = self::find( $id );
		if ( ! $d ) { return array( false, 'Dépréciation introuvable.' ); }
		if ( 'comptabilisee' !== $d['statut'] ) {
			return array( false, 'Seule une créance douteuse comptabilisée peut être passée en perte (statut actuel : '
				. ( self::statuts()[ $d['statut'] ] ?? $d['statut'] ) . ').' );
		}
		$motif = trim( (string) $motif );
		if ( mb_strlen( $motif ) < 10 ) { return array( false, 'Un motif est requis : pourquoi la créance est-elle définitivement perdue ?' ); }
		$date = $date ?: date( 'Y-m-d' );
		if ( class_exists( 'FKC_Cloture' ) && FKC_Cloture::isExerciceClos( $date ) ) {
			return array( false, 'L\'exercice couvrant le ' . $date . ' est clos.' );
		}
		$reclasse = (float) $d['reclasse_ttc'] > 0 ? (float) $d['reclasse_ttc'] : self::resteTtc( $d );
		$ttc = round( $reclasse - (float) $d['montant_encaisse'], 2 );
		if ( $ttc <= 0 ) { return array( false, 'La créance est entièrement encaissée : il n\'y a rien à passer en perte.' ); }
		$ht = $reclasse > 0 ? round( (float) $d['montant_ht'] * $ttc / $reclasse ) : $ttc;
		$tva = round( $ttc - $ht );

		$preuves = 0;
		foreach ( self::justificatifsDe( $id ) as $j ) { if ( in_array( $j['type'], self::PREUVES_PERTE, true ) ) { $preuves++; } }
		$deductible = $preuves > 0;
		$recup = $recupererTva && $deductible && $tva > 0;

		$nom = self::clientNom( (int) $d['client_id'] );
		$tiers = array( 'tiers_type' => 'client', 'tiers_id' => (int) $d['client_id'] );
		$compte416 = 'litigieuse' === $d['nature'] ? self::C_LITIGIEUX : self::C_DOUTEUX;
		$lib = 'Créance irrécouvrable — ' . $nom;
		$lignes = array( array( 'compte' => self::C_PERTE, 'debit' => $recup ? $ht : $ttc, 'credit' => 0, 'libelle' => $lib ) );
		if ( $recup ) {
			$cTva = class_exists( 'FKC_DeclarationFiscale' ) ? FKC_DeclarationFiscale::comptes()['tva_collectee'][0] : '443100';
			$lignes[] = array( 'compte' => $cTva, 'debit' => $tva, 'credit' => 0, 'libelle' => 'TVA récupérée sur créance irrécouvrable — ' . $nom );
		}
		$lignes[] = array( 'compte' => $compte416, 'debit' => 0, 'credit' => $ttc, 'libelle' => $lib ) + $tiers;
		$stock = round( (float) $d['montant_depreciation'] - (float) $d['montant_repris'] );
		if ( $stock > 0 ) {
			$lignes[] = array( 'compte' => self::C_DEPRECIATION, 'debit' => $stock, 'credit' => 0, 'libelle' => 'Reprise de la dépréciation — perte constatée' );
			$lignes[] = array( 'compte' => self::C_REPRISE, 'debit' => 0, 'credit' => $stock, 'libelle' => 'Reprise de la dépréciation — perte constatée' );
		}
		list( $ok, $msg, $eid, $bid ) = self::passer( $lignes, $date, $lib, 'PERTE-' . (int) $id );
		if ( ! $ok ) { return array( false, $msg ); }
		try {
			FKC_DB::q( "UPDATE depreciations SET statut='perte', montant_perte=?, perte_deductible=?, motif_perte=?, montant_repris=montant_repris+? WHERE id=?",
				array( $recup ? $ht : $ttc, $deductible ? 1 : 0, $motif, $stock, (int) $id ) );
		} catch ( \Throwable $e ) {}
		self::mouvement( $id, 'perte', $date, $recup ? $ht : $ttc, $ttc, $eid, $bid, $motif );
		if ( $stock > 0 ) { self::mouvement( $id, 'reprise', $date, $stock, 0.0, $eid, $bid, 'Reprise sur passage en perte' ); }
		self::tracer( $id, 'perte', 'Perte ' . fkc_money( $recup ? $ht : $ttc ) . ' F' . ( $recup ? ', TVA récupérée ' . fkc_money( $tva ) . ' F' : '' )
			. ', reprise ' . fkc_money( $stock ) . ' F — ' . ( $deductible ? 'déductible (irrécouvrabilité prouvée)' : 'NON déductible (aucune preuve d\'irrécouvrabilité)' ) );
		return array( true, 'Créance passée en perte : ' . fkc_money( $recup ? $ht : $ttc ) . ' F en 651'
			. ( $recup ? ', ' . fkc_money( $tva ) . ' F de TVA récupérée' : ( $tva > 0 ? ' (TVA comprise, non récupérée)' : '' ) )
			. ', provision de ' . fkc_money( $stock ) . ' F reprise.'
			. ( $deductible ? '' : ' Aucune pièce ne prouve l\'irrécouvrabilité : la perte est NON déductible et sera réintégrée au résultat fiscal.' )
			. ( $bid ? ' Écriture au journal temporaire.' : '' ) );
	}

	/** Abandonne une analyse qui n'a produit aucune écriture. */
	public static function abandonner( $id, $motif ) {
		$d = self::find( $id );
		if ( ! $d ) { return array( false, 'Dépréciation introuvable.' ); }
		if ( ! in_array( $d['statut'], array( 'analyse', 'a_valider', 'validee' ), true ) ) {
			return array( false, 'Une dépréciation comptabilisée ne s\'abandonne pas : elle se reprend (le client a payé) ou se passe en perte.' );
		}
		if ( mb_strlen( trim( (string) $motif ) ) < 10 ) { return array( false, 'Un motif est requis.' ); }
		try { FKC_DB::q( "UPDATE depreciations SET statut='abandonnee', motif_reprise=? WHERE id=?", array( trim( (string) $motif ), (int) $id ) ); } catch ( \Throwable $e ) {}
		self::tracer( $id, 'abandon', trim( (string) $motif ) );
		return array( true, 'Analyse abandonnée.' );
	}

	/** Compte du client : son compte auxiliaire s'il en a un, sinon 411100. */
	protected static function client( $clientId ) {
		try {
			$c = FKC_DB::q( 'SELECT compte FROM clients WHERE id=?', array( (int) $clientId ) )->fetchColumn();
			if ( $c && preg_match( '/^411/', (string) $c ) ) { return (string) $c; }
		} catch ( \Throwable $e ) {}
		return self::C_CLIENT;
	}

	/* ═══════════════ Outils internes ═══════════════ */

	protected static function resteTtc( $d ) {
		// Le reclassement porte sur ce que le client doit encore, taxe comprise.
		if ( ! empty( $d['facture_id'] ) ) {
			try {
				$f = FKC_DB::q( 'SELECT montant_ttc, montant_ht FROM factures WHERE id=?',
					array( (int) $d['facture_id'] ) )->fetch();
				if ( $f && (float) $f['montant_ht'] > 0 ) {
					return round( (float) $d['montant_ht'] * (float) $f['montant_ttc'] / (float) $f['montant_ht'] );
				}
			} catch ( \Throwable $e ) {}
		}
		return round( (float) $d['montant_ht'] );
	}

	protected static function clientNom( $clientId ) {
		try {
			$n = FKC_DB::q( 'SELECT nom FROM clients WHERE id=?', array( (int) $clientId ) )->fetchColumn();
			return $n ?: ( 'Client #' . $clientId );
		} catch ( \Throwable $e ) { return 'Client #' . $clientId; }
	}

	/** Passe une écriture au journal OD, en comptabilité et non au brouillard. */
	/**
	 * Passe l'écriture d'une dépréciation.
	 *
	 * 1.542.0 — CE QUI CHANGE, ET POURQUOI C'ÉTAIT LE PLUS URGENT.
	 *
	 * Ce code forçait `brouillard = false` : dotations et reprises de
	 * dépréciation partaient DIRECTEMENT au grand livre, sans jamais passer
	 * par le contrôle avant comptabilisation. C'était l'exception la moins
	 * défendable de toutes : une dépréciation est une ESTIMATION — combien de
	 * cette créance ne rentrera pas — et ce fichier écrit lui-même, quelques
	 * lignes plus haut, qu'« une reprise non motivée est le premier motif de
	 * redressement sur les provisions ». Ce que l'administration regarde en
	 * premier était ce qui échappait au regard du comptable.
	 *
	 * @param int|null $lienId Ligne `depreciations` à raccorder à l'écriture,
	 *                         renseignée à la comptabilisation (immédiate ou
	 *                         après validation) par FKC_Brouillard::backfill().
	 * @return array{bool, string, int|null, int|null} ok, msg, ecriture, brouillon
	 */
	protected static function passer( array $lignes, $date, $libelle, $piece, $lienId = null ) {
		if ( ! class_exists( 'FKC_Ecriture' ) || ! class_exists( 'FKC_Posting' ) ) {
			return array( false, 'Module comptable indisponible.', null );
		}
		try {
			$jid = (int) FKC_DB::q( "SELECT id FROM journaux WHERE code='OD' LIMIT 1" )->fetchColumn();
		} catch ( \Throwable $e ) { $jid = 0; }
		if ( ! $jid ) { return array( false, 'Journal OD introuvable.', null ); }

		$l = array();
		foreach ( $lignes as $x ) {
			$cid = FKC_Posting::compteId( $x['compte'] );
			if ( ! $cid ) { return array( false, 'Compte ' . $x['compte'] . ' introuvable.', null ); }
			$l[] = array( 'compte_id' => $cid, 'libelle' => $x['libelle'],
				'debit' => (float) $x['debit'], 'credit' => (float) $x['credit'] )
				+ ( ! empty( $x['tiers_id'] ) ? array( 'tiers_type' => (string) $x['tiers_type'], 'tiers_id' => (int) $x['tiers_id'] ) : array() );
		}
		$opts = array( 'source' => 'depreciation' );
		if ( $lienId ) {
			$opts['lien'] = array( 'table' => 'depreciations', 'colonne' => 'ecriture_id', 'ids' => array( (int) $lienId ) );
		}
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer(
			array(
				'journal_id' => $jid, 'date_ecriture' => $date, 'libelle' => $libelle,
				'piece' => $piece, 'reference' => 'Dépréciation des créances',
				/*
				 * Écriture d'inventaire : une dépréciation se constate aux
				 * travaux de fin d'exercice, donc APRÈS les mois qu'elle
				 * concerne. Datée du 31/12, elle butait sur une clôture
				 * mensuelle de décembre — même impasse que les dotations
				 * d'amortissement. Elle reste refusée si l'exercice est clos.
				 */
				'inventaire' => true,
			),
			$l,
			$opts
		);
		return array( $ok, $ok ? 'ok' : ( 'Écriture refusée : ' . $msg ), $ok ? (int) $eid : null, $bid ? (int) $bid : null );
	}

	protected static function tracer( $id, $action, $detail ) {
		try {
			FKC_DB::q(
				'INSERT INTO depreciation_historique(depreciation_id,action,detail,created_by) VALUES(?,?,?,?)',
				array( (int) $id, $action, $detail, FKC_Auth::id() )
			);
		} catch ( \Throwable $e ) {}
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'depreciation_' . $action, '#' . $id . ' — ' . $detail );
		}
	}

	public static function historique( $id ) {
		try {
			return FKC_DB::q( 'SELECT * FROM depreciation_historique WHERE depreciation_id=? ORDER BY id ASC',
				array( (int) $id ) )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/* ═══════════════ Relevé fiscal et indicateurs ═══════════════ */

	/**
	 * Relevé des provisions — la pièce à joindre à la déclaration.
	 *
	 * Elle n'a d'utilité que si elle est complète : l'administration compare la
	 * charge comptabilisée en 6594 au total du relevé. Un écart, même justifié,
	 * ouvre la discussion.
	 */
	public static function releveFiscal( $exercice = null ) {
		self::ensureSchema();
		$exercice = (int) ( $exercice ?: self::exercice() );
		list( $d1, $d2 ) = class_exists( 'FKC_Exercice' ) ? FKC_Exercice::bornes( $exercice ) : array( $exercice . '-01-01', $exercice . '-12-31' );
		$out = array( 'exercice' => $exercice, 'lignes' => array(),
			'total_dotation' => 0.0, 'total_deductible' => 0.0, 'total_reintegration' => 0.0,
			'total_reprise' => 0.0, 'total_reprise_reintegree' => 0.0, 'total_perte' => 0.0,
			'total_perte_non_deductible' => 0.0, 'sans_justificatif' => 0 );
		/*
		 * PAR MOUVEMENT DATÉ (1.792.0). Une fiche entre au relevé de l'exercice
		 * où elle a été DOTÉE, reprise ou passée en perte — pas de celui où son
		 * analyse a été ouverte. Les fiches antérieures à cette version, sans
		 * mouvement enregistré, restent lues comme avant (dotation à la date de
		 * comptabilisation, reprise cumulée).
		 */
		$par = array();
		try {
			foreach ( FKC_DB::q( 'SELECT * FROM depreciation_mouvements WHERE date_mouvement BETWEEN ? AND ?', array( $d1, $d2 ) )->fetchAll() as $m ) {
				$k = (int) $m['depreciation_id'];
				$par[ $k ][ $m['type'] ] = ( $par[ $k ][ $m['type'] ] ?? 0.0 ) + (float) $m['montant'];
			}
			foreach ( FKC_DB::q( "SELECT d.id, d.date_comptabilisation, d.montant_depreciation, d.montant_repris FROM depreciations d
				WHERE d.statut NOT IN ('analyse','a_valider','validee','abandonnee') AND d.date_comptabilisation BETWEEN ? AND ?
				AND NOT EXISTS (SELECT 1 FROM depreciation_mouvements m WHERE m.depreciation_id=d.id)", array( $d1, $d2 ) )->fetchAll() as $h ) {
				$par[ (int) $h['id'] ]['dotation'] = (float) $h['montant_depreciation'];
				$par[ (int) $h['id'] ]['reprise'] = (float) $h['montant_repris'];
			}
		} catch ( \Throwable $e ) {}
		foreach ( $par as $depId => $mv ) {
			$l = self::find( $depId );
			if ( ! $l ) { continue; }
			$nb = self::nbJustificatifs( $depId );
			$nonDed = max( 0.0, 100.0 - (float) $l['part_deductible'] ) / 100;
			$dot = (float) ( $mv['dotation'] ?? 0 );
			$rep = (float) ( $mv['reprise'] ?? 0 );
			$perte = (float) ( $mv['perte'] ?? 0 );
			$rei = round( $dot * $nonDed );
			$repRei = round( $rep * $nonDed );
			$perteNd = ( $perte > 0 && empty( $l['perte_deductible'] ) ) ? $perte : 0.0;
			$out['lignes'][] = array(
				'id' => (int) $depId, 'client' => self::clientNom( (int) $l['client_id'] ), 'nature' => $l['nature'],
				'montant_ht' => (float) $l['montant_ht'], 'taux' => (float) $l['taux'],
				'dotation' => $dot, 'qualification' => $l['qualification'],
				'reintegration' => $rei, 'reprise' => $rep, 'reprise_reintegree' => $repRei,
				'encaisse' => (float) ( $mv['encaissement'] ?? 0 ), 'perte' => $perte, 'perte_deductible' => $perte > 0 ? ! empty( $l['perte_deductible'] ) : null,
				'justificatifs' => $nb, 'motif' => $l['motif'], 'statut' => $l['statut'],
				'justification_fiscale' => $l['justification_fiscale'],
			);
			$out['total_dotation'] += $dot;
			$out['total_reintegration'] += $rei;
			$out['total_deductible'] += ( $dot - $rei );
			$out['total_reprise'] += $rep;
			$out['total_reprise_reintegree'] += $repRei;
			$out['total_perte'] += $perte;
			$out['total_perte_non_deductible'] += $perteNd;
			if ( $dot > 0 && 0 === $nb ) { $out['sans_justificatif']++; }
		}
		return $out;
	}

	/** Indicateurs de pilotage. */
	public static function kpis( $exercice = null ) {
		$r = self::releveFiscal( $exercice );
		$enc = 0.0;
		if ( class_exists( 'FKC_Recouvrement' ) ) {
			try { $enc = (float) FKC_Recouvrement::compute()['kpis']['encours']; } catch ( \Throwable $e ) {}
		}
		// Le STOCK est celui de toutes les provisions vivantes, quel que soit
		// l'exercice de leur dotation (1.792.0) : une provision de N reste au
		// bilan de N+1 tant qu'elle n'est ni reprise ni passée en perte.
		$stock = 0.0;
		try {
			$stock = (float) FKC_DB::q( "SELECT COALESCE(SUM(montant_depreciation-montant_repris),0) FROM depreciations WHERE statut IN ('comptabilisee','en_attente')" )->fetchColumn();
		} catch ( \Throwable $e ) {}
		return array(
			'stock_depreciation' => round( $stock ),
			'dotation_exercice'  => round( $r['total_dotation'] ),
			'reprise_exercice'   => round( $r['total_reprise'] ),
			'reintegration'      => round( $r['total_reintegration'] ),
			// Part de l'encours client couverte par une dépréciation. C'est
			// l'indicateur que lit un banquier : il dit ce que l'entreprise
			// pense réellement valoir de son poste clients.
			'taux_couverture'    => $enc > 0 ? round( $stock / $enc * 100, 1 ) : 0,
			'sans_justificatif'  => (int) $r['sans_justificatif'],
			'a_analyser'         => count( self::candidats() ),
		);
	}
}
