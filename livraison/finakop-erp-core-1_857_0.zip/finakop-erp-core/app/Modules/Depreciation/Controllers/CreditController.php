<?php
/**
 * Écrans du credit management : portefeuille, limites, garanties.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_CreditController {

	protected function flash() { $f = $_SESSION['fkc_flash'] ?? null; unset( $_SESSION['fkc_flash'] ); return $f; }
	protected function setFlash( $m ) { $_SESSION['fkc_flash'] = $m; }

	public function portefeuille() {
		FKC_View::render( 'depreciation::credit_portefeuille', array(
			'title' => 'Credit management · Portefeuille', 'tab' => 'credit',
			'p' => FKC_CreditManagement::portefeuille(),
			'flash' => $this->flash(),
		) );
	}

	public function client() {
		$id = (int) ( $_GET['id'] ?? 0 );
		$c  = FKC_Client::find( $id );
		if ( ! $c ) { $this->setFlash( 'Client introuvable.' ); return redirect( 'credit' ); }
		FKC_View::render( 'depreciation::credit_client', array(
			'title' => 'Crédit · ' . $c['nom'], 'tab' => 'credit',
			'c' => $c,
			's' => FKC_CreditManagement::situation( $id ),
			'garanties' => FKC_CreditManagement::garanties( $id ),
			'types' => FKC_CreditManagement::typesGarantie(),
			'flash' => $this->flash(),
		) );
	}

	public function limite() {
		$id = (int) ( $_POST['client_id'] ?? 0 );
		list( , $msg ) = FKC_CreditManagement::definirLimite( $id, (float) ( $_POST['montant'] ?? 0 ), $_POST['motif'] ?? '' );
		$this->setFlash( $msg );
		redirect( 'credit/client?id=' . $id );
	}

	public function garantie() {
		$id = (int) ( $_POST['client_id'] ?? 0 );
		list( , $msg ) = FKC_CreditManagement::ajouterGarantie(
			$id, $_POST['type'] ?? 'autre', (float) ( $_POST['montant'] ?? 0 ),
			trim( (string) ( $_POST['echeance'] ?? '' ) ) ?: null,
			$_POST['reference'] ?? '', $_POST['note'] ?? '' );
		$this->setFlash( $msg );
		redirect( 'credit/client?id=' . $id );
	}

	/**
	 * Avis sur une commande — appelé depuis l'écran client, ou en AJAX depuis
	 * une saisie de commande.
	 *
	 * On rend l'avis en JSON autant qu'en HTML : le contrôle de crédit n'a de
	 * valeur qu'AVANT la commande, et c'est au moment de la saisie qu'il doit
	 * s'afficher — pas dans un écran qu'on consulte après coup.
	 */
	public function avis() {
		$id = (int) ( $_GET['id'] ?? $_POST['client_id'] ?? 0 );
		$mt = (float) ( $_GET['montant'] ?? $_POST['montant'] ?? 0 );
		$a  = FKC_CreditManagement::avisCommande( $id, $mt );
		if ( ! empty( $_GET['json'] ) || ! empty( $_POST['json'] ) ) {
			header( 'Content-Type: application/json; charset=utf-8' );
			echo json_encode( $a, JSON_UNESCAPED_UNICODE );
			return;
		}
		$this->setFlash( strtoupper( $a['avis'] ) . ' — ' . $a['message'] );
		redirect( 'credit/client?id=' . $id );
	}
}
