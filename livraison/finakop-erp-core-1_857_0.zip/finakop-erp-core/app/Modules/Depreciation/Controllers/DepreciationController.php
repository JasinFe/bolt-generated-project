<?php
/**
 * Écrans de la dépréciation des créances clients.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_DepreciationController {

	protected function flash() { $f = $_SESSION['fkc_flash'] ?? null; unset( $_SESSION['fkc_flash'] ); return $f; }
	protected function setFlash( $m ) { $_SESSION['fkc_flash'] = $m; }

	public function index() {
		FKC_View::render( 'depreciation::index', array(
			'title' => 'Créances douteuses · Dépréciation', 'tab' => 'depreciation',
			'kpis' => FKC_Depreciation::kpis(),
			'candidats' => FKC_Depreciation::candidats(),
			'lignes' => FKC_Depreciation::lister(),
			'natures' => FKC_Depreciation::natures(),
			'statuts' => FKC_Depreciation::statuts(),
			'quals' => FKC_Depreciation::qualifications(),
			'flash' => $this->flash(),
		) );
	}

	public function ouvrir() {
		list( , $msg ) = FKC_Depreciation::ouvrir( array(
			'facture_id' => (int) ( $_POST['facture_id'] ?? 0 ),
			'client_id'  => (int) ( $_POST['client_id'] ?? 0 ),
			'nature'     => $_POST['nature'] ?? 'douteuse',
			'montant_ht' => (float) ( $_POST['montant_ht'] ?? 0 ),
			'taux'       => (float) ( $_POST['taux'] ?? 0 ),
			'motif'      => $_POST['motif'] ?? '',
		) );
		$this->setFlash( $msg );
		redirect( 'depreciation' );
	}

	public function justifier() {
		list( , $msg ) = FKC_Depreciation::ajouterJustificatif(
			(int) ( $_POST['id'] ?? 0 ), $_POST['type'] ?? 'autre',
			$_POST['reference'] ?? '', $_POST['date_piece'] ?? '', $_POST['note'] ?? '' );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . (int) ( $_POST['id'] ?? 0 ) );
	}

	public function qualifier() {
		list( , $msg ) = FKC_Depreciation::qualifier(
			(int) ( $_POST['id'] ?? 0 ), $_POST['qualification'] ?? 'a_qualifier',
			(float) ( $_POST['part_deductible'] ?? 100 ), $_POST['justification'] ?? '' );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . (int) ( $_POST['id'] ?? 0 ) );
	}

	public function valider() {
		list( , $msg ) = FKC_Depreciation::valider( (int) ( $_POST['id'] ?? 0 ) );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . (int) ( $_POST['id'] ?? 0 ) );
	}

	public function comptabiliser() {
		list( , $msg ) = FKC_Depreciation::comptabiliser(
			(int) ( $_POST['id'] ?? 0 ), trim( (string) ( $_POST['date'] ?? '' ) ) ?: null );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . (int) ( $_POST['id'] ?? 0 ) );
	}

	public function reprendre() {
		$m = trim( (string) ( $_POST['montant'] ?? '' ) );
		list( , $msg ) = FKC_Depreciation::reprendre(
			(int) ( $_POST['id'] ?? 0 ), '' === $m ? null : (float) $m,
			$_POST['motif'] ?? '', trim( (string) ( $_POST['date'] ?? '' ) ) ?: null );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . (int) ( $_POST['id'] ?? 0 ) );
	}

	/** Passage en perte d'une créance définitivement irrécouvrable (1.792.0). */
	public function perte() {
		$id = (int) ( $_POST['id'] ?? 0 );
		list( , $msg ) = FKC_Depreciation::passerEnPerte( $id, (string) ( $_POST['motif'] ?? '' ),
			trim( (string) ( $_POST['date'] ?? '' ) ) ?: null, ! empty( $_POST['recuperer_tva'] ) );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . $id );
	}

	/** Constate sur la créance douteuse un encaissement reçu sans répartition par facture (1.792.0). */
	public function encaissement() {
		$id = (int) ( $_POST['id'] ?? 0 );
		$d = FKC_Depreciation::find( $id );
		$m = FKC_Depreciation::encaissementNonConstate( $id );
		list( , $msg ) = ( $d && $m > 0 )
			? FKC_Depreciation::constaterEncaissement( (int) $d['facture_id'], $m, trim( (string) ( $_POST['date'] ?? '' ) ) ?: null )
			: array( false, 'Aucun encaissement à constater sur cette créance.' );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . $id );
	}

	public function abandonner() {
		$id = (int) ( $_POST['id'] ?? 0 );
		list( , $msg ) = FKC_Depreciation::abandonner( $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg );
		redirect( 'depreciation/fiche?id=' . $id );
	}

	public function fiche() {
		$id = (int) ( $_GET['id'] ?? 0 );
		$d = FKC_Depreciation::find( $id );
		if ( ! $d ) { $this->setFlash( 'Dépréciation introuvable.' ); return redirect( 'depreciation' ); }
		FKC_View::render( 'depreciation::fiche', array(
			'title' => 'Dépréciation #' . $id, 'tab' => 'depreciation', 'd' => $d,
			'justificatifs' => FKC_Depreciation::justificatifsDe( $id ),
			'historique' => FKC_Depreciation::historique( $id ),
			'mouvements' => FKC_Depreciation::mouvements( $id ),
			'encaisse_attente' => FKC_Depreciation::encaissementNonConstate( $id ),
			'preuves_perte' => FKC_Depreciation::PREUVES_PERTE,
			'types' => FKC_Depreciation::justificatifs(),
			'quals' => FKC_Depreciation::qualifications(),
			'statuts' => FKC_Depreciation::statuts(),
			'flash' => $this->flash(),
		) );
	}

	public function releve() {
		$ex = (int) ( $_GET['exercice'] ?? 0 ) ?: FKC_Depreciation::exercice();
		FKC_View::render( 'depreciation::releve', array(
			'title' => 'Relevé des provisions ' . $ex, 'tab' => 'depreciation',
			'r' => FKC_Depreciation::releveFiscal( $ex ),
			'quals' => FKC_Depreciation::qualifications(),
			'flash' => $this->flash(),
		) );
	}
}
