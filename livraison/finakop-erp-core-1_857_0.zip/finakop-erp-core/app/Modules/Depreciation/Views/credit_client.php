<?php defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php /** @var array $c @var array $s @var array $garanties @var array $types @var string|null $flash */ ?>
<h1><?= e( $c['nom'] ) ?> — situation de crédit</h1>
<?php if ( $flash ) : ?><div class="alert"><?= e( $flash ) ?></div><?php endif; ?>

<div class="cards">
	<div class="card"><div class="card-body"><span class="muted">Encours</span>
		<strong style="font-size:1.3em"><?= fkc_money( $s['encours'] ) ?> F</strong>
		<span class="muted">dont <?= fkc_money( $s['retard'] ) ?> F en retard</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Exposition nette</span>
		<strong style="font-size:1.3em;color:var(--orange)"><?= fkc_money( $s['exposition_nette'] ) ?> F</strong>
		<span class="muted">après <?= fkc_money( $s['garanties'] ) ?> F de garanties</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Limite de crédit</span>
		<strong style="font-size:1.3em"><?= null === $s['limite'] ? 'non définie' : fkc_money( $s['limite'] ) . ' F' ?></strong>
		<?php if ( $s['depassement'] > 0 ) : ?><span style="color:var(--orange)">dépassée de <?= fkc_money( $s['depassement'] ) ?> F</span>
		<?php elseif ( null !== $s['disponible'] ) : ?><span class="muted"><?= fkc_money( $s['disponible'] ) ?> F disponibles</span><?php endif; ?>
	</div></div>
	<div class="card"><div class="card-body"><span class="muted">Perte attendue</span>
		<strong style="font-size:1.3em"><?= fkc_money( $s['perte_attendue'] ) ?> F</strong>
		<span class="muted">P(récupération) <?= (int) $s['probabilite_recuperation'] ?> % · score <?= (int) $s['score'] ?></span></div></div>
</div>
<p class="muted" style="max-width:70ch">
	La probabilité de récupération combine trois facteurs observables — comportement de paiement passé,
	ancienneté du plus vieil impayé, part garantie. Ce n'est pas un modèle statistique : elle sert au
	pilotage, jamais à justifier une dépréciation devant l'administration.
</p>

<div class="card">
	<div class="card-head"><h2>Limite de crédit</h2></div>
	<form method="post" action="<?= e( url( 'credit/limite' ) ) ?>" style="padding:10px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
		<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= (int) $c['id'] ?>">
		<input type="number" name="montant" value="<?= (int) ( $s['limite'] ?? 0 ) ?>" style="width:160px"> F
		<input type="text" name="motif" placeholder="Motif (accord comité, ancienneté…)" style="min-width:280px">
		<button class="btn btn-primary btn-sm" type="submit">Enregistrer</button>
	</form>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Garanties</h2><span class="muted"><?= fkc_money( $s['garanties'] ) ?> F retenus</span></div>
	<div style="padding:0 12px 8px" class="muted">
		Une garantie vaut ce qu'on peut en tirer, et dans le délai où on en aura besoin — d'où le taux de
		réalisation. Une garantie <strong>échue</strong> ne couvre plus rien et sort du calcul.
	</div>
	<table class="table">
		<thead><tr><th>Nature</th><th class="num">Nominal</th><th class="num">Taux</th><th class="num">Retenu</th><th>Échéance</th></tr></thead>
		<tbody>
		<?php foreach ( $s['garanties_detail'] as $g ) : ?>
			<tr>
				<td><?= e( $types[ $g['type'] ][0] ?? $g['type'] ) ?></td>
				<td class="num"><?= fkc_money( $g['nominal'] ) ?></td>
				<td class="num"><?= e( $g['taux'] ) ?> %</td>
				<td class="num"><strong><?= fkc_money( $g['retenu'] ) ?></strong></td>
				<td class="muted"><?= $g['echeance'] ? e( $g['echeance'] ) : 'sans terme' ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( ! $s['garanties_detail'] ) : ?>
			<tr><td colspan="5" class="muted">Aucune garantie active. L'exposition est égale à l'encours.</td></tr>
		<?php endif; ?>
		</tbody>
	</table>
	<form method="post" action="<?= e( url( 'credit/garantie' ) ) ?>" style="padding:10px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
		<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= (int) $c['id'] ?>">
		<select name="type"><?php foreach ( $types as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v[0] ) ?> (<?= (int) $v[1] ?> %)</option><?php endforeach; ?></select>
		<input type="number" name="montant" placeholder="Nominal" style="width:150px">
		<input type="date" name="echeance" title="Échéance : au-delà, la garantie ne couvre plus">
		<input type="text" name="reference" placeholder="Référence">
		<button class="btn btn-ghost btn-sm" type="submit">Ajouter</button>
	</form>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Avis sur une commande</h2></div>
	<div style="padding:0 12px 8px" class="muted">
		Le contrôle de crédit n'a de valeur qu'<strong>avant</strong> la commande.
	</div>
	<form method="post" action="<?= e( url( 'credit/avis' ) ) ?>" style="padding:10px;display:flex;gap:6px;align-items:center">
		<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= (int) $c['id'] ?>">
		<input type="number" name="montant" placeholder="Montant de la commande" style="width:200px">
		<button class="btn btn-ghost btn-sm" type="submit">Demander l'avis</button>
	</form>
</div>
