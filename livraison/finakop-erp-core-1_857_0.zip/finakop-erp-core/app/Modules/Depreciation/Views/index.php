<?php defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php /** @var array $kpis @var array $candidats @var array $lignes @var array $natures @var array $statuts @var array $quals @var string|null $flash */ ?>
<h1>Créances douteuses et litigieuses</h1>
<?php if ( $flash ) : ?><div class="alert"><?= e( $flash ) ?></div><?php endif; ?>

<div class="cards">
	<div class="card"><div class="card-body">
		<span class="muted">Stock de dépréciation</span>
		<strong style="font-size:1.4em"><?= fkc_money( $kpis['stock_depreciation'] ) ?> F</strong>
		<span class="muted">Couverture du poste clients : <?= e( $kpis['taux_couverture'] ) ?> %</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Dotation de l'exercice</span>
		<strong style="font-size:1.4em"><?= fkc_money( $kpis['dotation_exercice'] ) ?> F</strong>
		<span class="muted">Reprises : <?= fkc_money( $kpis['reprise_exercice'] ) ?> F</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">À réintégrer (DGI)</span>
		<strong style="font-size:1.4em;color:var(--orange)"><?= fkc_money( $kpis['reintegration'] ) ?> F</strong>
		<span class="muted"><?= (int) $kpis['sans_justificatif'] ?> ligne(s) sans justificatif</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">À analyser</span>
		<strong style="font-size:1.4em"><?= (int) $kpis['a_analyser'] ?></strong>
		<span class="muted">créances au-delà du seuil d'examen</span>
	</div></div>
</div>
<p>
	<a class="btn btn-ghost" href="<?= e( url( 'depreciation/releve' ) ) ?>">Relevé des provisions →</a>
	<a class="btn btn-ghost" href="<?= e( url( 'credit' ) ) ?>">Credit management →</a>
</p>

<div class="card">
	<div class="card-head"><h2>Créances à analyser</h2><span class="muted"><?= count( $candidats ) ?></span></div>
	<?php if ( ! $candidats ) : ?>
		<div style="padding:12px" class="muted">Aucune créance n'atteint le seuil d'examen.</div>
	<?php else : ?>
	<div style="padding:0 12px 10px" class="muted">
		Le taux proposé est un REPÈRE, pas un barème : une provision calculée de façon forfaitaire
		n'est pas déductible. Corrigez-le après examen du dossier, et motivez.
	</div>
	<table class="table">
		<thead><tr><th>Client</th><th>Échéance</th><th class="num">Retard</th><th class="num">Reste TTC</th><th class="num">Base HT</th><th>Analyse</th></tr></thead>
		<tbody>
		<?php foreach ( $candidats as $c ) : ?>
			<tr>
				<td><?= e( $c['client_nom'] ) ?>
					<?php if ( ! empty( $c['suspendu'] ) ) : ?><br><span class="muted" style="font-size:.82em">⏸ <?= e( $c['suspendu'] ) ?></span><?php endif; ?></td>
				<td class="muted"><?= e( $c['echeance'] ) ?></td>
				<td class="num"><?= (int) $c['jours'] ?> j</td>
				<td class="num"><?= fkc_money( $c['montant_ttc'] ) ?></td>
				<td class="num"><strong><?= fkc_money( $c['montant_ht'] ) ?></strong></td>
				<td>
					<form method="post" action="<?= e( url( 'depreciation/ouvrir' ) ) ?>" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="facture_id" value="<?= (int) $c['facture_id'] ?>">
						<input type="hidden" name="client_id" value="<?= (int) $c['client_id'] ?>">
						<input type="hidden" name="montant_ht" value="<?= (int) $c['montant_ht'] ?>">
						<select name="nature"><?php foreach ( $natures as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( strtok( $v, ' —' ) ) ?></option><?php endforeach; ?></select>
						<input type="number" name="taux" min="0" max="100" step="1" style="width:70px"
							value="<?= (int) $c['taux_indicatif'] ?>" title="Taux de dépréciation, à confirmer après examen"> %
						<input type="text" name="motif" placeholder="Motif de l'analyse individuelle (obligatoire)" style="min-width:260px">
						<button class="btn btn-primary btn-sm" type="submit">Ouvrir</button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Dépréciations</h2><span class="muted"><?= count( $lignes ) ?></span></div>
	<table class="table">
		<thead><tr><th>#</th><th>Client</th><th>Nature</th><th class="num">Base HT</th><th class="num">Taux</th><th class="num">Dotation</th><th class="num">Repris</th><th>Statut</th><th>Fiscal</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $lignes as $l ) : ?>
			<tr>
				<td class="code"><?= (int) $l['id'] ?></td>
				<td><?= e( $l['client_nom'] ?: ( 'Client #' . $l['client_id'] ) ) ?></td>
				<td class="muted"><?= e( $l['nature'] ) ?></td>
				<td class="num"><?= fkc_money( $l['montant_ht'] ) ?></td>
				<td class="num"><?= e( (float) $l['taux'] ) ?> %</td>
				<td class="num"><strong><?= fkc_money( $l['montant_depreciation'] ) ?></strong></td>
				<td class="num"><?= fkc_money( $l['montant_repris'] ) ?></td>
				<td><span class="tag"><?= e( $statuts[ $l['statut'] ] ?? $l['statut'] ) ?></span></td>
				<td class="muted" style="font-size:.85em"><?= e( $quals[ $l['qualification'] ] ?? $l['qualification'] ) ?></td>
				<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'depreciation/fiche?id=' . (int) $l['id'] ) ) ?>">Ouvrir</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
