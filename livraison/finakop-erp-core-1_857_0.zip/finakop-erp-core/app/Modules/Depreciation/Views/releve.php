<?php defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php /** @var array $r @var array $quals @var string|null $flash */ ?>
<h1>Relevé des provisions — exercice <?= (int) $r['exercice'] ?></h1>
<?php if ( $flash ) : ?><div class="alert"><?= e( $flash ) ?></div><?php endif; ?>
<div style="padding:0 0 12px" class="muted">
	Pièce à joindre à la déclaration de résultat. L'administration compare la charge comptabilisée
	en 6594 au total de ce relevé : un écart, même justifié, ouvre la discussion.
</div>
<?php if ( $r['sans_justificatif'] > 0 ) : ?>
	<div class="alert alert-warn">
		⚠️ <strong><?= (int) $r['sans_justificatif'] ?> ligne(s)</strong> sans justificatif attaché.
		L'administration ne conteste presque jamais le montant : elle conteste l'absence de diligences.
	</div>
<?php endif; ?>
<div class="cards">
	<div class="card"><div class="card-body"><span class="muted">Dotation</span>
		<strong style="font-size:1.3em"><?= fkc_money( $r['total_dotation'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Part déductible</span>
		<strong style="font-size:1.3em;color:var(--ok)"><?= fkc_money( $r['total_deductible'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">À réintégrer</span>
		<strong style="font-size:1.3em;color:var(--orange)"><?= fkc_money( $r['total_reintegration'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Reprises</span>
		<strong style="font-size:1.3em"><?= fkc_money( $r['total_reprise'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Reprises à déduire (déjà réintégrées)</span>
		<strong style="font-size:1.3em;color:var(--ok)"><?= fkc_money( $r['total_reprise_reintegree'] ?? 0 ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Pertes sur créances</span>
		<strong style="font-size:1.3em"><?= fkc_money( $r['total_perte'] ?? 0 ) ?> F</strong>
		<?php if ( ! empty( $r['total_perte_non_deductible'] ) ) : ?><div style="color:var(--orange);font-size:.85em">dont non déductibles : <?= fkc_money( $r['total_perte_non_deductible'] ) ?> F</div><?php endif; ?></div></div>
</div>
<table class="table">
	<thead><tr><th>#</th><th>Client</th><th>Nature</th><th class="num">Base HT</th><th class="num">Taux</th><th class="num">Dotation</th><th>Qualification</th><th class="num">Réintégration</th><th class="num">Reprise</th><th class="num">Perte</th><th class="num">Pièces</th><th>Motif</th></tr></thead>
	<tbody>
	<?php foreach ( $r['lignes'] as $l ) : ?>
		<tr>
			<td class="code"><?= (int) $l['id'] ?></td>
			<td><?= e( $l['client'] ) ?></td>
			<td class="muted"><?= e( $l['nature'] ) ?></td>
			<td class="num"><?= fkc_money( $l['montant_ht'] ) ?></td>
			<td class="num"><?= e( $l['taux'] ) ?> %</td>
			<td class="num"><?= fkc_money( $l['dotation'] ) ?></td>
			<td><?= e( $quals[ $l['qualification'] ] ?? $l['qualification'] ) ?></td>
			<td class="num"><?= $l['reintegration'] > 0 ? '<strong>' . fkc_money( $l['reintegration'] ) . '</strong>' : '—' ?></td>
			<td class="num"><?= ! empty( $l['reprise'] ) ? fkc_money( $l['reprise'] ) : '—' ?></td>
			<td class="num"><?= ! empty( $l['perte'] ) ? fkc_money( $l['perte'] ) . ( $l['perte_deductible'] ? '' : ' <span style="color:var(--orange)">ND</span>' ) : '—' ?></td>
			<td class="num"><?= $l['justificatifs'] ? (int) $l['justificatifs'] : '<span style="color:var(--orange)">0</span>' ?></td>
			<td class="muted" style="font-size:.85em"><?= e( $l['motif'] ) ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
