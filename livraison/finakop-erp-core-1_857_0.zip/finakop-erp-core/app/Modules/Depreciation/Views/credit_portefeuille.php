<?php defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php /** @var array $p @var string|null $flash */ ?>
<h1>Credit management — portefeuille clients</h1>
<?php if ( $flash ) : ?><div class="alert"><?= e( $flash ) ?></div><?php endif; ?>

<div style="padding:0 0 12px" class="muted">
	L'encours dit ce que les clients doivent. L'<strong>exposition nette</strong> dit ce que l'entreprise
	perdrait s'ils disparaissaient demain — encours moins garanties réalisables. C'est sur elle qu'on
	décide d'accorder une commande de plus.
</div>

<div class="cards">
	<div class="card"><div class="card-body"><span class="muted">Encours</span>
		<strong style="font-size:1.3em"><?= fkc_money( $p['encours'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Garanties retenues</span>
		<strong style="font-size:1.3em;color:var(--ok)"><?= fkc_money( $p['garanties'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Exposition nette</span>
		<strong style="font-size:1.3em;color:var(--orange)"><?= fkc_money( $p['exposition'] ) ?> F</strong></div></div>
	<div class="card"><div class="card-body"><span class="muted">Perte attendue</span>
		<strong style="font-size:1.3em"><?= fkc_money( $p['perte_attendue'] ) ?> F</strong>
		<span class="muted">prévision, pas provision</span></div></div>
</div>

<?php if ( $p['sans_limite'] > 0 ) : ?>
	<div class="alert alert-warn">
		<?= (int) $p['sans_limite'] ?> client(s) avec un encours mais <strong>aucune limite de crédit définie</strong>.
		C'est le véritable angle mort d'un poste clients : rien ne s'oppose à ce que l'encours enfle.
	</div>
<?php endif; ?>
<?php if ( $p['depassements'] > 0 ) : ?>
	<div class="alert alert-warn"><?= (int) $p['depassements'] ?> client(s) au-delà de leur limite.</div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Clients</h2><span class="muted">triés par perte attendue</span></div>
	<table class="table">
		<thead><tr><th>Client</th><th class="num">Encours</th><th class="num">Garanties</th>
			<th class="num">Exposition</th><th class="num">Limite</th><th class="num">Score</th>
			<th class="num">P(récup.)</th><th class="num">Perte attendue</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $p['clients'] as $c ) : ?>
			<tr>
				<td><?= e( $c['nom'] ) ?></td>
				<td class="num"><?= fkc_money( $c['encours'] ) ?></td>
				<td class="num"><?= $c['garanties'] > 0 ? fkc_money( $c['garanties'] ) : '<span class="muted">—</span>' ?></td>
				<td class="num"><strong><?= fkc_money( $c['exposition_nette'] ) ?></strong></td>
				<td class="num">
					<?php if ( null === $c['limite'] ) : ?><span style="color:var(--orange)">non définie</span>
					<?php else : ?><?= fkc_money( $c['limite'] ) ?>
						<?php if ( $c['depassement'] > 0 ) : ?><br><span style="color:var(--orange);font-size:.82em">+<?= fkc_money( $c['depassement'] ) ?></span><?php endif; ?>
					<?php endif; ?>
				</td>
				<td class="num"><?= (int) $c['score'] ?></td>
				<td class="num"><?= (int) $c['probabilite_recuperation'] ?> %</td>
				<td class="num"><strong><?= fkc_money( $c['perte_attendue'] ) ?></strong></td>
				<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'credit/client?id=' . (int) $c['client_id'] ) ) ?>">Ouvrir</a></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
