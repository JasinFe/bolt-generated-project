<?php defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php /** @var array $d @var array $justificatifs @var array $historique @var array $types @var array $quals @var array $statuts @var string|null $flash @var array $mouvements @var float $encaisse_attente @var array $preuves_perte */ ?>
<h1>Dépréciation #<?= (int) $d['id'] ?> — <span class="muted"><?= e( $statuts[ $d['statut'] ] ?? $d['statut'] ) ?></span></h1>
<?php if ( $flash ) : ?><div class="alert"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card"><div class="card-body">
	<p><strong>Base HT</strong> <?= fkc_money( $d['montant_ht'] ) ?> F ·
	   <strong>Taux</strong> <?= e( (float) $d['taux'] ) ?> % ·
	   <strong>Dotation</strong> <?= fkc_money( $d['montant_depreciation'] ) ?> F ·
	   <strong>Repris</strong> <?= fkc_money( $d['montant_repris'] ) ?> F
	   <?php if ( (float) ( $d['reclasse_ttc'] ?? 0 ) > 0 ) : ?> · <strong>Créance douteuse TTC</strong> <?= fkc_money( (float) $d['reclasse_ttc'] - (float) ( $d['montant_encaisse'] ?? 0 ) ) ?> F
	   (encaissé <?= fkc_money( $d['montant_encaisse'] ?? 0 ) ?> F)<?php endif; ?>
	   <?php if ( (float) ( $d['montant_perte'] ?? 0 ) > 0 ) : ?> · <strong>Perte</strong> <?= fkc_money( $d['montant_perte'] ) ?> F — <?= ! empty( $d['perte_deductible'] ) ? 'déductible' : '<span style="color:var(--orange)">non déductible</span>' ?><?php endif; ?></p>
	<p class="muted"><strong>Motif de l'analyse individuelle :</strong> <?= e( $d['motif'] ) ?></p>
	<?php if ( $d['justification_fiscale'] ) : ?>
		<p class="muted"><strong>Justification fiscale :</strong> <?= e( $d['justification_fiscale'] ) ?></p>
	<?php endif; ?>
	<?php if ( $d['montant_reintegration'] > 0 ) : ?>
		<p style="color:var(--orange)"><strong>À réintégrer au résultat fiscal :</strong> <?= fkc_money( $d['montant_reintegration'] ) ?> F</p>
	<?php endif; ?>
</div></div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Justificatifs</h2><span class="muted"><?= count( $justificatifs ) ?></span></div>
	<div style="padding:0 12px 8px" class="muted">
		Une provision déductible suppose des DILIGENCES prouvées. L'administration ne conteste presque
		jamais le montant : elle conteste l'absence de pièces.
	</div>
	<table class="table"><tbody>
	<?php foreach ( $justificatifs as $j ) : ?>
		<tr><td><?= e( $types[ $j['type'] ] ?? $j['type'] ) ?></td>
			<td class="code"><?= e( $j['reference'] ) ?></td>
			<td class="muted"><?= e( $j['date_piece'] ) ?></td>
			<td class="muted"><?= e( $j['note'] ) ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
	<form method="post" action="<?= e( url( 'depreciation/justifier' ) ) ?>" style="padding:10px;display:flex;gap:6px;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
		<select name="type"><?php foreach ( $types as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select>
		<input type="text" name="reference" placeholder="Référence de la pièce">
		<input type="date" name="date_piece" value="<?= date( 'Y-m-d' ) ?>">
		<input type="text" name="note" placeholder="Note" style="min-width:200px">
		<button class="btn btn-ghost btn-sm" type="submit">Attacher</button>
	</form>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Qualification fiscale</h2></div>
	<form method="post" action="<?= e( url( 'depreciation/qualifier' ) ) ?>" style="padding:10px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
		<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
		<select name="qualification">
			<?php foreach ( $quals as $k => $v ) : if ( 'a_qualifier' === $k ) { continue; } ?>
				<option value="<?= e( $k ) ?>" <?= $d['qualification'] === $k ? 'selected' : '' ?>><?= e( $v ) ?></option>
			<?php endforeach; ?>
		</select>
		<input type="number" name="part_deductible" min="0" max="100" step="1" style="width:80px"
			value="<?= (int) $d['part_deductible'] ?>" title="Part déductible, si partielle"> %
		<input type="text" name="justification" placeholder="Motif de la part non déductible (figurera au relevé)" style="min-width:300px" value="<?= e( $d['justification_fiscale'] ) ?>">
		<button class="btn btn-ghost btn-sm" type="submit">Qualifier</button>
	</form>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Traitement</h2></div>
	<div style="padding:10px;display:flex;gap:16px;flex-wrap:wrap">
		<?php if ( in_array( $d['statut'], array( 'analyse', 'a_valider' ), true ) ) : ?>
			<form method="post" action="<?= e( url( 'depreciation/valider' ) ) ?>">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<button class="btn btn-primary btn-sm" type="submit">Valider</button>
			</form>
			<form method="post" action="<?= e( url( 'depreciation/abandonner' ) ) ?>" style="display:flex;gap:6px">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<input type="text" name="motif" placeholder="Motif de l'abandon" style="min-width:220px">
				<button class="btn btn-ghost btn-sm" type="submit">Abandonner l'analyse</button>
			</form>
		<?php elseif ( 'validee' === $d['statut'] ) : ?>
			<form method="post" action="<?= e( url( 'depreciation/comptabiliser' ) ) ?>"
				onsubmit="return confirm('Deux écritures seront passées au journal OD :\n\n· reclassement en créance douteuse (411 → 416), sur le TTC\n· dotation 6594 / 4912, sur la base HT\n\nContinuer ?');">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<input type="date" name="date" value="<?= date( 'Y-m-d' ) ?>">
				<button class="btn btn-primary btn-sm" type="submit">Comptabiliser</button>
			</form>
		<?php elseif ( 'en_attente' === $d['statut'] ) : ?>
			<?php
			/*
			 * L'écriture attend au journal temporaire (1.542.0). On ne propose
			 * PAS la reprise ici : reprendre une provision que le bilan ne
			 * porte pas encore n'aurait aucun sens, et enchaînerait deux
			 * écritures dont la seconde annulerait une première jamais
			 * comptabilisée. On renvoie là où le geste attendu se trouve.
			 */
			?>
			<p class="help" style="margin:0">
				L'écriture attend au <a href="<?= e( url( 'comptabilite/brouillard' ) ) ?>">journal temporaire</a> :
				vérifiez-la et comptabilisez-la. La reprise ne sera proposée qu'ensuite.
			</p>
		<?php elseif ( 'comptabilisee' === $d['statut'] ) : ?>
			<form method="post" action="<?= e( url( 'depreciation/reprendre' ) ) ?>" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<input type="number" name="montant" placeholder="Montant (vide = solde)" style="width:180px">
				<input type="date" name="date" value="<?= date( 'Y-m-d' ) ?>">
				<input type="text" name="motif" placeholder="Motif de la reprise (obligatoire)" style="min-width:280px">
				<button class="btn btn-ghost btn-sm" type="submit">Reprendre</button>
			</form>
			<?php if ( ! empty( $encaisse_attente ) && $encaisse_attente >= 1 ) : ?>
				<form method="post" action="<?= e( url( 'depreciation/encaissement' ) ) ?>" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
					<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
					<span style="color:var(--orange)">Le client a payé <?= fkc_money( $encaisse_attente ) ?> F sur cette facture sans que la créance douteuse en tienne compte.</span>
					<input type="date" name="date" value="<?= date( 'Y-m-d' ) ?>">
					<button class="btn btn-primary btn-sm" type="submit">Constater l'encaissement et reprendre la provision</button>
				</form>
			<?php endif; ?>
			<form method="post" action="<?= e( url( 'depreciation/perte' ) ) ?>" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;width:100%"
				onsubmit="return confirm('La créance restante sera passée en perte (651), la provision reprise. Continuer ?');">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<input type="date" name="date" value="<?= date( 'Y-m-d' ) ?>">
				<input type="text" name="motif" placeholder="Pourquoi la créance est définitivement perdue (obligatoire)" style="min-width:320px">
				<label style="font-size:12.5px"><input type="checkbox" name="recuperer_tva" value="1" checked> Récupérer la TVA</label>
				<button class="btn btn-ghost btn-sm" type="submit">Passer en perte</button>
				<span class="help" style="margin:0;width:100%">Déductible et TVA récupérable seulement si l'irrécouvrabilité est prouvée par une pièce :
					<?= e( implode( ', ', array_map( function ( $k ) use ( $types ) { return $types[ $k ] ?? $k; }, (array) $preuves_perte ) ) ) ?>.</span>
			</form>
		<?php endif; ?>
	</div>
</div>

<?php if ( ! empty( $mouvements ) ) : ?>
<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Mouvements</h2></div>
	<table class="table"><thead><tr><th>Date</th><th>Mouvement</th><th class="right">Montant</th><th>Écriture</th></tr></thead><tbody>
	<?php $lbM = array( 'dotation' => 'Reclassement et dotation', 'reprise' => 'Reprise', 'encaissement' => 'Encaissement sur créance douteuse', 'perte' => 'Passage en perte' ); ?>
	<?php foreach ( $mouvements as $m ) : ?>
		<tr><td><?= e( date( 'd/m/Y', strtotime( $m['date_mouvement'] ) ) ) ?></td><td><?= e( $lbM[ $m['type'] ] ?? $m['type'] ) ?></td>
		<td class="right"><?= fkc_money( $m['montant'] ) ?></td><td class="muted"><?= $m['ecriture_id'] ? 'n° ' . (int) $m['ecriture_id'] : ( $m['brouillon_id'] ? 'journal temporaire' : '' ) ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
</div>
<?php endif; ?>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Historique</h2></div>
	<table class="table"><tbody>
	<?php foreach ( $historique as $h ) : ?>
		<tr><td class="muted" style="width:150px"><?= e( $h['created_at'] ) ?></td>
			<td class="code" style="width:130px"><?= e( $h['action'] ) ?></td>
			<td><?= e( $h['detail'] ) ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
</div>
