<?php /** @var array|null $d */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'inventaire' ) ); ?>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucune donnée d'inventaire.</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card"><div class="card-body an-kpi"><span class="l">Valeur du stock</span><span class="v"><?= e( fkc_money( $d['valeur'] ) ) ?></span></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l">Articles</span><span class="v"><?= (int) $d['articles'] ?></span></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l">Sous le seuil</span><span class="v" style="color:<?= $d['sous_seuil']>0?'var(--orange)':'var(--ok)' ?>"><?= (int) $d['sous_seuil'] ?></span></div></div>
</div>
<?php if ( $d['top'] ) : ?>
<div class="card"><div class="card-head"><h2>Articles à plus forte valeur immobilisée</h2></div><div class="card-body"><?php $t=array(); foreach($d['top'] as $r){$t[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $t, array('color'=>'var(--blue)') ); ?></div></div>
<?php endif; ?>
