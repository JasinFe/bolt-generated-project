<?php
/**
 * UN RAPPORT (1.834.0) : écran, impression A4, export CSV — le même tableau.
 *
 * @var array $r           FKC_AnaRapports::produire()
 * @var array $periode
 * @var array $opts
 * @var array $axes
 * @var bool  $avecPeriode
 * @var bool  $entreprise
 * @var array $periodes    périodes relatives
 * @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$params = array_filter( array( 'code' => $r['code'], 'du' => $periode['du'], 'au' => $periode['au'], 'axe' => $opts['axe'] ?? null ) );
$csv = url( 'analyse/rapports/export?' . http_build_query( $params ) );
/* Période relative proposée à l'enregistrement : celle qui correspond aux dates affichées, sinon « dates fixes ». */
$perDefaut = 'fixe';
foreach ( array_keys( $periodes ) as $k ) {
	if ( 'fixe' === $k ) { continue; }
	if ( FKC_AnaRapports::resoudrePeriode( $k ) === array( $periode['du'], $periode['au'] ) ) { $perDefaut = $k; break; }
}
?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'rapports' ) ); ?>
<style>
.rp-bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
.rp-bar .sp{flex:1}
.rp-table td,.rp-table th{white-space:nowrap}
.rp-table td.t,.rp-table th.t{white-space:normal;min-width:120px}
.rp-table .n{text-align:right!important;font-variant-numeric:tabular-nums}
.rp-table tr.rp-sous td{font-weight:700;background:var(--panel2)}
.rp-table tr.rp-total td{font-weight:800;border-top:2px solid var(--line);background:rgba(201,162,39,.10)}
.rp-table tr.rp-muted td{color:var(--muted)}
.rp-table tr.rp-alerte td:first-child{color:var(--danger);font-weight:600}
.rp-table td.neg{color:var(--danger)}
.rp-notes{font-size:12px;color:var(--muted);margin:10px 0 0;padding-left:18px}
.rp-save{border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:12px;background:var(--panel)}
.rp-save form{display:flex!important;gap:10px;flex-wrap:wrap;align-items:flex-end;margin:0}
.rp-save label{display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted);flex:1 1 180px}
.rp-save input,.rp-save select{width:100%}
.rp-axe{display:flex!important;gap:8px;align-items:center;margin:0}
.rp-axe select{width:auto}
@media print{
	/* Seul le rapport s'imprime : tout ce qui n'est ni lui, ni l'un de ses parents, disparaît ;
	   ses parents perdent marges, grilles et décors (barre latérale, bandeaux, filtres). */
	body *:not(:has(.rp-print)):not(.rp-print):not(.rp-print *){display:none!important}
	body *:has(.rp-print){display:block!important;margin:0!important;padding:0!important;border:0!important;box-shadow:none!important;background:#fff!important;position:static!important;width:auto!important;max-width:none!important;min-height:0!important;transform:none!important}
	body{background:#fff!important}
	.rp-print{color:#000!important;background:#fff!important;border:0!important;box-shadow:none!important;margin:0!important}
	.rp-print>.card-body{padding:0!important}
	.rp-print .etat-entete{background:#fff!important;border:1px solid #999!important;color:#000!important}
	.rp-print .etat-entete *{color:#000!important}
	.rp-print .table-wrap{overflow:visible!important}
	.rp-print table{width:100%;border-collapse:collapse;font-size:10.5pt}
	.rp-print th,.rp-print td{border-bottom:1px solid #ccc!important;color:#000!important;background:#fff!important;padding:4px 6px!important}
	.rp-print tr.rp-sous td,.rp-print tr.rp-total td{font-weight:700;background:#eee!important}
	.rp-print a{color:#000!important;text-decoration:none!important}
	.rp-print .rp-notes{color:#333!important}
	@page{size:A4;margin:12mm}
}
</style>
<?php if ( $flash ) : ?><div class="alert alert-warn"><?= e( $flash ) ?></div><?php endif; ?>
<?php if ( $avecPeriode ) { FKC_View::partial( 'analyse::_periode', array( 'periode' => $periode + array( 'sans_cmp' => true, 'caches' => array( 'code' => $r['code'], 'axe' => $opts['axe'] ?? null ) ) ) ); } ?>

<div class="rp-bar fkc-noprint">
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analyse/rapports?' . http_build_query( array( 'du' => $periode['du'], 'au' => $periode['au'] ) ) ) ) ?>">← Rapports</a>
	<?php if ( count( $axes ) > 1 ) : ?>
	<form method="get" class="rp-axe" action="<?= e( url( 'analyse/rapports/voir' ) ) ?>">
		<input type="hidden" name="code" value="<?= e( $r['code'] ) ?>"><input type="hidden" name="du" value="<?= e( $periode['du'] ) ?>"><input type="hidden" name="au" value="<?= e( $periode['au'] ) ?>">
		<label for="rpAxe" class="muted" style="font-size:12.5px">Axe</label>
		<select id="rpAxe" name="axe" onchange="this.form.submit()">
			<?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $a['id'] === (int) ( $r['axe_id'] ?? 0 ) ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?>
		</select>
		<noscript><button class="btn btn-ghost btn-sm">OK</button></noscript>
	</form>
	<?php endif; ?>
	<span class="sp"></span>
	<button type="button" class="btn btn-ghost btn-sm" onclick="window.print()">🖨 Imprimer</button>
	<a class="btn btn-ghost btn-sm" href="<?= e( $csv ) ?>">⬇ CSV</a>
	<?php if ( $entreprise ) : ?><button type="button" class="btn btn-primary btn-sm" id="rpSaveBtn" aria-expanded="false" aria-controls="rpSave">⭐ Enregistrer ce rapport</button><?php endif; ?>
</div>

<?php if ( $entreprise ) : ?>
<div class="rp-save fkc-noprint" id="rpSave" hidden>
	<form method="post" action="<?= e( url( 'analyse/rapports/enregistrer' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<input type="hidden" name="code" value="<?= e( $r['code'] ) ?>">
		<?php if ( ! empty( $r['axe_id'] ) ) : ?><input type="hidden" name="axe" value="<?= (int) $r['axe_id'] ?>"><?php endif; ?>
		<input type="hidden" name="du" value="<?= e( $periode['du'] ) ?>"><input type="hidden" name="au" value="<?= e( $periode['au'] ) ?>">
		<label>Nom<input name="nom" required maxlength="120" value="<?= e( $r['titre'] ) ?>"></label>
		<?php if ( $avecPeriode ) : ?>
		<label>Période à la réouverture
			<select name="periode">
				<?php foreach ( $periodes as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $k === $perDefaut ? 'selected' : '' ?>><?= e( $lib ) ?><?= 'fixe' === $k ? ' (' . date( 'd/m/Y', strtotime( $periode['du'] ) ) . ' → ' . date( 'd/m/Y', strtotime( $periode['au'] ) ) . ')' : '' ?></option><?php endforeach; ?>
			</select>
		</label>
		<?php else : ?><input type="hidden" name="periode" value="exercice"><?php endif; ?>
		<button class="btn btn-primary">Enregistrer</button>
	</form>
</div>
<?php endif; ?>

<div class="card rp-print"><div class="card-body">
	<?php FKC_View::partial( 'comptabilite::_etat_entete', array( 'etat' => $r['titre'], 'periode' => $r['periode'] ) ); ?>
	<?php if ( ! $r['lignes'] ) : ?>
		<p class="muted">Aucune donnée pour cette période.</p>
	<?php else : ?>
	<div class="table-wrap"><table class="table rp-table">
		<thead><tr><?php foreach ( $r['colonnes'] as $c ) : ?><th class="<?= 'txt' === $c[1] ? 't' : 'n' ?>"><?= e( $c[0] ) ?></th><?php endforeach; ?></tr></thead>
		<tbody>
		<?php foreach ( $r['lignes'] as $l ) : ?>
			<tr<?= $l['s'] ? ' class="rp-' . e( $l['s'] ) . '"' : '' ?>>
			<?php foreach ( $l['c'] as $i => $v ) : $t = $r['colonnes'][ $i ][1] ?? 'txt'; $txt = FKC_AnaRapports::formater( $v, $t ); ?>
				<td class="<?= 'txt' === $t ? 't' : 'n' ?><?= 'mt' === $t && is_numeric( $v ) && $v < -0.5 ? ' neg' : '' ?>"><?php if ( 0 === $i && ! empty( $l['lien'] ) ) : ?><a href="<?= e( url( $l['lien'] ) ) ?>"><?= e( $txt ) ?></a><?php else : ?><?= e( $txt ) ?><?php endif; ?></td>
			<?php endforeach; ?>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<?php endif; ?>
	<?php if ( $r['notes'] ) : ?><ul class="rp-notes"><?php foreach ( $r['notes'] as $n ) : ?><li><?= e( $n ) ?></li><?php endforeach; ?></ul><?php endif; ?>
</div></div>
<script>
(function(){
	var b=document.getElementById('rpSaveBtn'), f=document.getElementById('rpSave'); if(!b||!f)return;
	b.addEventListener('click',function(){ f.hidden=!f.hidden; b.setAttribute('aria-expanded',f.hidden?'false':'true'); if(!f.hidden){ var i=f.querySelector('input[name=nom]'); if(i){i.focus();i.select();} } });
})();
</script>
