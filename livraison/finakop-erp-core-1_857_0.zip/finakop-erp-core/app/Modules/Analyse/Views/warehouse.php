<?php /** @var array $domaines @var string|null $updated @var array $dwStats @var array $dwCatalogue @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'warehouse' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-body">
	<h2 style="margin:0 0 6px">Data Warehouse</h2>
	<p class="help">L'entrepôt conserve un <strong>historique daté de tous vos indicateurs</strong>, tous modules confondus, et sert d'<strong>instantanés pré-calculés</strong> pour que les analyses restent rapides. Chaque rafraîchissement recalcule les domaines et historise les métriques du jour. Un instantané ne sert que le jour où il est pris : le lendemain, les écrans repassent d'eux-mêmes en calcul direct — jamais de chiffres figés.</p>
	<p style="margin:10px 0"><?= $updated ? 'Dernier rafraîchissement : <strong>' . e( $updated ) . '</strong>' : '<span class="muted">Aucun instantané — les analyses sont calculées en direct.</span>' ?></p>
	<form method="post" action="<?= e( url( 'analyse/warehouse/refresh' ) ) ?>"><?= FKC_Csrf::field() ?><button class="btn btn-primary">↻ Rafraîchir & historiser</button></form>
</div></div>

<?php if ( ! empty( $dwStats ) && $dwStats['faits'] > 0 ) : ?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:16px 0">
	<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Indicateurs suivis</div><div style="font-size:24px;font-weight:800"><?= (int) $dwStats['metriques'] ?></div></div></div>
	<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Jours d'historique</div><div style="font-size:24px;font-weight:800"><?= (int) $dwStats['jours'] ?></div></div></div>
	<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Points de données</div><div style="font-size:24px;font-weight:800"><?= fkc_money( $dwStats['faits'] ) ?></div></div></div>
	<div class="card"><div class="card-body"><div class="muted" style="font-size:12px">Période couverte</div><div style="font-size:13px;font-weight:600;margin-top:4px"><?= $dwStats['premier'] ? e( $dwStats['premier'] ) . ' → ' . e( $dwStats['dernier'] ) : '—' ?></div></div></div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Indicateurs consolidés (tous modules)</h2></div>
	<table class="table"><thead><tr><th>Indicateur</th><th>Source</th><th>Dernière valeur</th><th>Variation</th><th>Tendance (14 j)</th></tr></thead><tbody>
	<?php foreach ( $dwCatalogue as $c ) : ?>
		<tr>
			<td><strong><?= e( $c['libelle'] ) ?></strong><div class="muted" style="font-size:11px"><?= e( $c['metrique'] ) ?></div></td>
			<td><span class="tag" style="font-size:11px"><?= e( $c['pack'] ?: 'cœur' ) ?></span></td>
			<td style="font-variant-numeric:tabular-nums"><?= null !== $c['valeur'] ? fkc_money( $c['valeur'] ) : '—' ?></td>
			<td>
				<?php if ( null !== $c['variation'] ) : ?>
					<span style="font-size:12px;color:<?= $c['variation'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= $c['variation'] >= 0 ? '▲ +' : '▼ ' ?><?= e( $c['variation'] ) ?>%</span>
				<?php else : ?><span class="muted" style="font-size:12px">—</span><?php endif; ?>
			</td>
			<td><?php if ( count( $c['serie'] ) >= 2 && class_exists( 'FKC_Chart' ) ) : ?><?= FKC_Chart::sparkline( $c['serie'], array( 'width' => 120, 'height' => 28, 'color' => 'var(--blue)' ) ) ?><?php else : ?><span class="muted" style="font-size:11px"><?= (int) $c['points'] ?> pt</span><?php endif; ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody></table>
</div>
<?php else : ?>
<div class="card" style="margin-top:16px"><div class="card-body" style="text-align:center;padding:30px">
	<div style="font-size:32px">🗄️</div>
	<h2 style="margin:8px 0 4px">L'entrepôt se remplit dès le premier rafraîchissement</h2>
	<p class="muted" style="font-size:13px">Chaque jour rafraîchi ajoute un point à l'historique de chaque indicateur. En quelques jours, vous visualisez les tendances de tous vos modules ici.</p>
</div></div>
<?php endif; ?>

<div class="card card-flush" style="margin-top:16px"><div class="card-head"><h2>Domaines pré-calculés</h2></div><table class="table"><thead><tr><th>Domaine</th><th>État</th></tr></thead><tbody>
	<?php foreach ( $domaines as $dom ) : $has = FKC_Warehouse::fromWarehouse( $dom ); ?><tr>
		<td><strong><?= e( ucfirst( $dom ) ) ?></strong></td>
		<td><span class="modbadge <?= $has?'b-on':'b-off' ?>"><?= $has ? 'Instantané du jour' : 'Calcul en direct' ?></span></td>
	</tr><?php endforeach; ?>
</tbody></table></div>
