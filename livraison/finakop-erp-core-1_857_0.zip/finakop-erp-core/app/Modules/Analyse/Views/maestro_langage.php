<?php
/**
 * Langage de Maestro (1.846.0).
 *
 * Ce que vos utilisateurs demandent et que Maestro ne comprend pas encore,
 * et ce qu'on lui a déjà appris. Maestro PROPOSE (la reformulation qui a
 * suivi l'échec) ; l'administrateur DÉCIDE. Aucun mot n'est appris seul.
 *
 * @var array|null $flash
 * @var array      $incomprises, $appris, $cibles
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'maestro' ) );

$h = function ( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); };
/** Liste déroulante des cibles, présélectionnée sur la suggestion. */
$selectCible = function ( $choisi = '' ) use ( $cibles, $h ) {
	$o = '<select name="cible" class="input" required style="max-width:320px"><option value="">— Associer à… —</option>';
	$o .= '<optgroup label="Domaines">';
	foreach ( $cibles['domaine'] as $k => $l ) {
		$v = 'domaine|' . $k;
		$o .= '<option value="' . $h( $v ) . '"' . ( $v === $choisi ? ' selected' : '' ) . '>' . $h( $l ) . '</option>';
	}
	$o .= '</optgroup><optgroup label="Indicateurs">';
	foreach ( $cibles['predicat'] as $k => $l ) {
		$v = 'predicat|' . $k;
		$o .= '<option value="' . $h( $v ) . '"' . ( $v === $choisi ? ' selected' : '' ) . '>' . $h( $l ) . '</option>';
	}
	return $o . '</optgroup></select>';
};
?>
<div class="card-head" style="margin-bottom:12px">
	<h2>🎼 Langage de Maestro</h2>
	<span class="muted">Apprenez à Maestro les mots de votre maison. Il propose, vous décidez : aucun mot n'est appris sans vous.</span>
</div>

<?php if ( $flash ) : ?>
	<div class="alert <?= 'ok' === $flash['type'] ? 'alert-ok' : 'alert-err' ?>" style="margin-bottom:12px"><?= $h( $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card" style="margin-bottom:16px">
	<div class="card-body">
		<h3 style="margin-top:0">Questions restées sans réponse <span class="muted" style="font-size:13px">— 30 derniers jours</span></h3>
		<?php if ( ! $incomprises ) : ?>
			<p class="muted">Aucune question incomprise ces trente derniers jours. Celles qu'une expression apprise a résolues disparaissent d'elles-mêmes.</p>
		<?php else : ?>
			<p class="muted" style="font-size:13px">Pour chaque question, Maestro regarde ce que la personne a demandé juste après : c'est souvent la même question, reformulée. Gardez le cœur de l'expression — deux à cinq mots, sans période ni montant.</p>
			<div style="overflow-x:auto">
			<table class="table">
				<thead><tr><th>Question</th><th style="text-align:right">Fois</th><th>Reformulée en</th><th>Apprendre</th></tr></thead>
				<tbody>
				<?php foreach ( $incomprises as $q ) :
					$s = $q['suggestion'];
					$choisi = $s ? $s['type'] . '|' . $s['cible'] : '';
				?>
					<tr>
						<td>« <?= $h( $q['question'] ) ?> »<div class="muted" style="font-size:11px">dernière fois <?= $h( $q['derniere'] ) ?> · <?= (int) $q['personnes'] ?> personne(s)</div></td>
						<td style="text-align:right"><?= (int) $q['fois'] ?></td>
						<td style="font-size:13px"><?= $s ? '« ' . $h( $s['reformulation'] ) . ' »<div class="muted" style="font-size:11px">→ ' . $h( $s['libelle'] ) . '</div>' : '<span class="muted">—</span>' ?></td>
						<td>
							<form method="post" action="<?= $h( url( 'maestro/langage/apprendre' ) ) ?>" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="exemple" value="<?= $h( $q['question'] ) ?>">
								<input type="text" name="expression" class="input" value="<?= $h( $q['expression'] ) ?>" required maxlength="60" style="width:170px" title="L'expression que Maestro apprendra">
								<?= $selectCible( $choisi ) ?>
								<button class="btn btn-primary btn-sm">Apprendre</button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php endif; ?>
	</div>
</div>

<div class="card" style="margin-bottom:16px">
	<div class="card-body">
		<h3 style="margin-top:0">Ajouter une expression</h3>
		<form method="post" action="<?= $h( url( 'maestro/langage/apprendre' ) ) ?>" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
			<?= FKC_Csrf::field() ?>
			<input type="text" name="expression" class="input" placeholder="ex. : les sous, la caisse du jour, mes débiteurs" required maxlength="60" style="min-width:240px">
			<?= $selectCible() ?>
			<button class="btn btn-primary">Apprendre</button>
		</form>
		<p class="muted" style="font-size:12px;margin-bottom:0">Les mots que Maestro connaît déjà ne peuvent pas être redéfinis : « trésorerie » désignera toujours la trésorerie. Une expression apprise ne donne aucun droit : l'indicateur reste réservé à qui peut le voir.</p>
	</div>
</div>

<div class="card">
	<div class="card-body">
		<h3 style="margin-top:0">Expressions apprises</h3>
		<?php if ( ! $appris ) : ?>
			<p class="muted">Aucune pour l'instant.</p>
		<?php else : ?>
			<div style="overflow-x:auto">
			<table class="table">
				<thead><tr><th>Expression</th><th>Désigne</th><th>Question d'origine</th><th>Depuis</th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $appris as $a ) : $actif = 'actif' === $a['statut']; ?>
					<tr style="<?= $actif ? '' : 'opacity:.55' ?>">
						<td><strong><?= $h( $a['expression'] ) ?></strong></td>
						<td><?= $h( $a['cible_libelle'] ) ?></td>
						<td class="muted" style="font-size:12px"><?= $a['exemple'] ? '« ' . $h( $a['exemple'] ) . ' »' : '—' ?></td>
						<td class="muted" style="font-size:12px"><?= $h( substr( (string) $a['cree_at'], 0, 10 ) ) ?></td>
						<td>
							<?php if ( $actif ) : ?>
								<form method="post" action="<?= $h( url( 'maestro/langage/retirer' ) ) ?>" onsubmit="return confirm('Retirer cette expression ? Maestro ne la comprendra plus.')">
									<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
									<button class="btn btn-ghost btn-sm">Retirer</button>
								</form>
							<?php else : ?><span class="muted" style="font-size:12px">retirée</span><?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php endif; ?>
	</div>
</div>
