<?php /** @var array $alertes @var array $declenchees @var array $registre @var array $operateurs @var array $niveaux @var mixed $flash @var string $modeEmail @var array $modesEmail @var array $destinataires @var bool $courrielDispo @var array $journalCourriels @var bool $estAdmin */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'alertes' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<?php if ( $declenchees ) : ?>
	<div class="card-head" style="border:0"><h2>🔔 Alertes actives (<?= count( $declenchees ) ?>)</h2></div>
	<?php foreach ( $declenchees as $a ) : ?>
		<div class="an-alert n-<?= e( $a['niveau'] ) ?>"><span class="ico"><?= $a['niveau']==='danger'?'🔴':($a['niveau']==='warn'?'🟠':'🔵') ?></span>
			<span><strong><?= e( $a['libelle'] ) ?></strong> — <?= e( FKC_Metrics::metricLabel( $a['metric'] ) ) ?> = <strong><?= e( fkc_money( $a['valeur'] ) ) ?></strong> <?= e( $operateurs[ $a['operateur'] ] ?? $a['operateur'] ) ?> <?= e( fkc_money( $a['seuil'] ) ) ?></span></div>
	<?php endforeach; ?>
<?php else : ?><div class="alert alert-ok">Aucune alerte déclenchée actuellement.</div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouvelle règle</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'analyse/alertes' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Libellé *</span><input name="libelle" required placeholder="Ex. Créances en retard élevées"></label>
			<label class="fld"><span>Métrique</span><select name="metric"><?php foreach ( $registre as $k => $r ) : ?><option value="<?= e( $k ) ?>"><?= e( $r[0] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Condition</span><select name="operateur"><?php foreach ( $operateurs as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Seuil</span><input type="number" step="any" name="seuil" value="0"></label>
			<label class="fld"><span>Niveau</span><select name="niveau"><?php foreach ( $niveaux as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<div class="actions"><button class="btn btn-primary">Créer la règle</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Règles (<?= count( $alertes ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Libellé</th><th>Condition</th><th>Niveau</th><th>État</th><th></th></tr></thead><tbody>
		<?php if ( ! $alertes ) : ?><tr><td colspan="5" class="empty">Aucune règle.</td></tr>
		<?php else : foreach ( $alertes as $a ) : $on = FKC_Alerte::declenche( $a['operateur'], FKC_Metrics::metric( $a['metric'] ), (float) $a['seuil'] ); ?><tr>
			<td><strong><?= e( $a['libelle'] ) ?></strong></td>
			<td class="muted"><?= e( FKC_Metrics::metricLabel( $a['metric'] ) ) ?> <?= e( $operateurs[ $a['operateur'] ] ?? $a['operateur'] ) ?> <?= e( fkc_money( $a['seuil'] ) ) ?></td>
			<td><span class="couche <?= $a['niveau']==='danger'?'couche-pred':'couche-perf' ?>"><?= e( $niveaux[ $a['niveau'] ] ?? $a['niveau'] ) ?></span></td>
			<td><span class="an-status <?= $on?'an-danger':'an-ok' ?>"></span> <?= $on?'Déclenchée':'OK' ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'analyse/alertes/' . (int) $a['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>

<?php
/* ── ENVOI PAR COURRIEL (1.838.0) ─────────────────────────────────────── */
$sansAdresse = array_values( array_filter( (array) ( $destinataires ?? array() ), function ( $u ) { return '' === $u['email']; } ) );
$statuts = array( 'envoye' => array( '✅', 'Envoyé' ), 'echec' => array( '⚠️', 'Échec' ), 'indisponible' => array( '⛔', 'Non envoyé' ) );
?>
<style>
.al-mail form{display:flex!important;gap:10px;flex-wrap:wrap;align-items:flex-end;margin:0}
.al-mail label{display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)}
.al-mail select{width:auto;min-width:min(100%,260px)}
.al-dest{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 0;padding:0;list-style:none}
.al-dest li{border:1px solid var(--line);border-radius:999px;padding:3px 10px;font-size:12px}
.al-dest li.sans{border-color:var(--orange);color:var(--orange)}
</style>
<div class="card al-mail" id="alMail" style="margin-top:14px"><div class="card-head"><h2>✉️ Envoi par courriel</h2></div><div class="card-body">
	<?php if ( empty( $courrielDispo ) ) : ?>
		<div class="alert alert-warn">L'envoi de courriels n'est pas disponible sur ce serveur : les alertes restent dans la cloche. Vérifiez la messagerie de WordPress (extension SMTP de l'hébergement).</div>
	<?php endif; ?>
	<?php if ( ! empty( $estAdmin ) ) : ?>
	<form method="post" action="<?= e( url( 'analyse/alertes/reglages' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<label>Envoyer aussi par courriel
			<select name="mode_email"><?php foreach ( (array) $modesEmail as $k => $l ) : ?><option value="<?= e( $k ) ?>" <?= $k === $modeEmail ? 'selected' : '' ?>><?= e( $l ) ?></option><?php endforeach; ?></select>
		</label>
		<button class="btn btn-primary btn-sm">Enregistrer</button>
	</form>
	<form method="post" action="<?= e( url( 'analyse/alertes/test' ) ) ?>" style="margin-top:10px">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-ghost btn-sm">Envoyer un courriel d'essai à mon adresse</button>
	</form>
	<?php else : ?>
		<p style="margin:0">Envoi par courriel : <strong><?= e( mb_strtolower( $modesEmail[ $modeEmail ] ?? '' ) ) ?></strong> <span class="muted">(réglé par l'administrateur)</span></p>
	<?php endif; ?>
	<p class="help" style="margin:12px 0 0">Le courriel part en même temps que la notification : au franchissement du seuil, puis en rappel au bout de <?= (int) FKC_Alerte::RAPPEL_JOURS ?> jours s'il est toujours franchi. Destinataires : administrateurs et utilisateurs du module Analyse.</p>
	<ul class="al-dest">
		<?php foreach ( (array) $destinataires as $u ) : ?><li class="<?= '' === $u['email'] ? 'sans' : '' ?>"><?= e( $u['nom'] ) ?> · <?= '' === $u['email'] ? 'aucune adresse' : e( $u['email'] ) ?></li><?php endforeach; ?>
	</ul>
	<?php if ( $sansAdresse ) : ?><p class="help" style="color:var(--orange);margin:8px 0 0"><?= count( $sansAdresse ) ?> compte(s) sans adresse ne recevront que la notification : renseignez l'adresse dans Utilisateurs.</p><?php endif; ?>
	<?php if ( ! empty( $journalCourriels ) ) : ?>
	<div class="table-wrap" style="margin-top:12px"><table class="table">
		<thead><tr><th>Date</th><th>Destinataire</th><th>Sujet</th><th>Statut</th></tr></thead>
		<tbody><?php foreach ( $journalCourriels as $c ) : $st = $statuts[ $c['statut'] ] ?? array( '·', $c['statut'] ); ?>
			<tr><td class="muted" style="white-space:nowrap"><?= e( date( 'd/m H:i', strtotime( $c['cree_le'] ) ) ) ?></td><td><?= e( $c['destinataire'] ) ?></td><td><?= e( $c['sujet'] ) ?></td>
			<td title="<?= e( (string) $c['erreur'] ) ?>"><?= $st[0] ?> <?= e( $st[1] ) ?><?php if ( $c['erreur'] ) : ?><br><span class="muted" style="font-size:11px"><?= e( $c['erreur'] ) ?></span><?php endif; ?></td></tr>
		<?php endforeach; ?></tbody>
	</table></div>
	<?php endif; ?>
</div></div>
