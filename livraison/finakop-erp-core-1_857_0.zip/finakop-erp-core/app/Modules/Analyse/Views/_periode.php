<?php /** En-tête de filtre période (du/au + raccourcis + comparaison + Analyser). @var array $periode */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
list( $fkcD0, $fkcA0 ) = FKC_Metrics::bornes();
$du = $periode['du'] ?? $fkcD0;
$au = $periode['au'] ?? $fkcA0;
$racc = $periode['raccourcis'] ?? FKC_Metrics::raccourcis( $du );
$cmp = $periode['cmp'] ?? '';
$mois = $periode['mois'] ?? 12;
?>
<form method="get" class="an-filter" id="anFilter">
	<?php /* Paramètres à conserver quand la période change (rapport, axe…) — 1.834.0. */ foreach ( (array) ( $periode['caches'] ?? array() ) as $fkcK => $fkcV ) : if ( null === $fkcV || '' === $fkcV ) { continue; } ?><input type="hidden" name="<?= e( $fkcK ) ?>" value="<?= e( $fkcV ) ?>"><?php endforeach; ?>
	<div class="an-filter-row">
		<div class="anf-group">
			<label>Période</label>
			<div class="anf-dates"><input type="date" name="du" id="anDu" value="<?= e( $du ) ?>"><span class="sep">→</span><input type="date" name="au" id="anAu" value="<?= e( $au ) ?>"></div>
		</div>
		<div class="anf-group">
			<label>Raccourcis</label>
			<div class="anf-quick">
				<?php foreach ( $racc as $r ) : $on = $r[1] === $du && $r[2] === $au; ?><button type="button" class="anf-chip<?= $on ? ' anf-chip-y is-on' : '' ?>" data-du="<?= e( $r[1] ) ?>" data-au="<?= e( $r[2] ) ?>" title="<?= e( $r[3] . ' : ' . date( 'd/m/Y', strtotime( $r[1] ) ) . ' → ' . date( 'd/m/Y', strtotime( $r[2] ) ) ) ?>"<?= $on ? ' aria-pressed="true"' : '' ?>><?= e( $r[0] ) ?></button><?php endforeach; ?>
			</div>
		</div>
		<?php if ( empty( $periode['sans_cmp'] ) ) : ?>
		<div class="anf-group">
			<label>Comparer à</label>
			<select name="cmp" class="anf-cmp">
				<option value="">Aucune comparaison</option>
				<option value="n1" <?= 'n1' === $cmp ? 'selected' : '' ?>>Année précédente</option>
			</select>
		</div>
		<?php endif; ?>
		<button type="submit" class="btn anf-go">🔍 Analyser</button>
	</div>
	<div class="anf-summary">📅 <?= e( date( 'd/m/Y', strtotime( $du ) ) ) ?> — <?= e( date( 'd/m/Y', strtotime( $au ) ) ) ?> <span class="muted">(<?= (int) $mois ?> mois<?= $du === $fkcD0 && $au === $fkcA0 ? ' · exercice en cours' : '' ?>)</span></div>
</form>
<style>@media(max-width:560px){.anf-dates{flex-wrap:wrap}.anf-dates input[type=date]{min-width:0;flex:1 1 130px;width:auto}}</style>
<script>
(function(){
	var f=document.getElementById('anFilter'); if(!f)return;
	var du=document.getElementById('anDu'), au=document.getElementById('anAu');
	/* Raccourcis calés sur l'EXERCICE (1.832.0) : T1 = ses trois premiers mois, décalé compris. */
	f.querySelectorAll('[data-du]').forEach(function(b){ b.addEventListener('click',function(){ du.value=b.getAttribute('data-du'); au.value=b.getAttribute('data-au'); f.submit(); }); });
})();
</script>
