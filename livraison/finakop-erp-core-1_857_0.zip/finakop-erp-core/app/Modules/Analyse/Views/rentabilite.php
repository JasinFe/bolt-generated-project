<?php
/**
 * MARGE (1.833.0) — soldes intermédiaires de gestion, marge par section
 * analytique, marge par article.
 *
 * @var array|null $d        FKC_Metrics::rentabilite (répartition des charges)
 * @var array      $sig      FKC_Marge::sig
 * @var array      $mensuel  FKC_Marge::mensuel
 * @var array      $axes
 * @var array|null $parAxe
 * @var array|null $articles
 * @var bool       $tousArticles
 * @var bool       $lienArticle
 * @var array      $periode
 * @var array|null $rappro
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcM = function ( $v ) { return fkc_money( round( (float) $v ) ); };
$fkcP = function ( $v, $dec = 1 ) { return null === $v ? '—' : str_replace( '.', ',', number_format( (float) $v, $dec, '.', ' ' ) ) . ' %'; };
$fkcVar = function ( $v, $inverse = false ) {
	if ( null === $v ) { return '<span class="muted">—</span>'; }
	$bon = $inverse ? $v <= 0 : $v >= 0;
	$c = abs( $v ) < 0.05 ? 'var(--muted)' : ( $bon ? 'var(--ok)' : 'var(--danger)' );
	return '<span style="color:' . $c . ';font-weight:600">' . ( $v > 0 ? '▲ +' : ( $v < 0 ? '▼ ' : '' ) ) . e( str_replace( '.', ',', number_format( $v, 1, '.', ' ' ) ) ) . ' %</span>';
};
$n = $sig['n']; $n1 = $sig['n1'];
$per1 = date( 'd/m/Y', strtotime( $sig['du1'] ) ) . ' → ' . date( 'd/m/Y', strtotime( $sig['au1'] ) );
$garder = array_filter( array( 'du' => $periode['du'], 'au' => $periode['au'], 'cmp' => $periode['cmp'] ?: null ) );
?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'rentabilite' ) ); ?>
<?php FKC_View::partial( 'analyse::_periode', array( 'periode' => $periode ) ); ?>
<style>
.mg-sig td,.mg-sig th{white-space:nowrap}
.mg-sig td:first-child{white-space:normal;min-width:180px}
.mg-sig .mg-s td{font-weight:700;background:var(--panel2)}
.mg-sig .mg-g td{font-weight:800;background:rgba(201,162,39,.12);border-top:2px solid var(--line)}
.mg-sig .mg-sg{display:inline-block;width:16px;color:var(--muted);font-weight:600}
.mg-sig .mg-d td:first-child{padding-left:22px}
.mg-sig.mg-court .mg-d{display:none}
.mg-num{text-align:right!important;font-variant-numeric:tabular-nums}
.mg-bar{height:6px;border-radius:3px;background:var(--panel2);overflow:hidden;min-width:60px}
.mg-bar i{display:block;height:100%;border-radius:3px}
.mg-note{font-size:12px;color:var(--muted);margin:8px 0 0}
.mg-axe{display:flex!important;gap:8px;align-items:center;flex-wrap:wrap;margin:0}
.mg-axe select{width:auto;min-width:160px}
@media(max-width:640px){.mg-hide-s{display:none}.mg-sig td:first-child{min-width:140px}}
</style>

<?php if ( $sig['vide'] ) : ?>
	<div class="alert alert-warn">Aucune écriture de gestion (classes 6, 7 et 8) sur cette période. Choisissez une autre période ou saisissez vos ventes et achats.</div>
	<?php return; ?>
<?php endif; ?>
<?php FKC_View::partial( 'analyse::_rappro', array( 'rappro' => $rappro ?? null ) ); ?>

<div class="an-grid">
	<?php
	$tuiles = array(
		array( 'XB', '💰', 'Chiffre d\'affaires', 'an-tile-blue', null ),
		array( 'XA', '🛒', 'Marge commerciale', 'an-tile-ok', $sig['taux_marge_com'] !== null ? 'taux ' . $fkcP( $sig['taux_marge_com'] ) . ' des ventes de marchandises' : null ),
		array( 'XC', '🏭', 'Valeur ajoutée', 'an-tile-violet', $sig['ca'] > 0 ? $fkcP( $n['XC'] / $sig['ca'] * 100 ) . ' du CA' : null ),
		array( 'XD', '⚙️', 'EBE', 'an-tile-orange', $sig['ca'] > 0 ? $fkcP( $n['XD'] / $sig['ca'] * 100 ) . ' du CA' : null ),
		array( 'XI', '📈', 'Résultat net', 'an-tile-ok', $sig['ca'] > 0 ? 'marge nette ' . $fkcP( $n['XI'] / $sig['ca'] * 100 ) : null ),
	);
	foreach ( $tuiles as $t ) :
		if ( 'XA' === $t[0] && abs( (float) $n['TA'] ) < 0.5 && abs( (float) $n1['TA'] ) < 0.5 ) { continue; }
		$v = (float) $n[ $t[0] ];
		$cls = in_array( $t[0], array( 'XA', 'XD', 'XI' ), true ) && $v < 0 ? 'an-tile-danger' : $t[3];
	?>
	<div class="card an-tile <?= e( $cls ) ?>" data-sig="<?= e( $t[0] ) ?>"><div class="card-body an-kpi">
		<span class="an-kpi-top"><span class="ico"><?= $t[1] ?></span><span class="l"><?= e( $t[2] ) ?></span></span>
		<span class="v"><?= e( $fkcM( $v ) ) ?></span>
		<?php if ( $t[4] ) : ?><span class="help" style="font-size:11.5px"><?= e( $t[4] ) ?></span><?php endif; ?>
		<span class="help" style="font-size:11.5px">N-1 : <?= e( $fkcM( $n1[ $t[0] ] ) ) ?> · <?= $fkcVar( FKC_Marge::variation( $v, $n1[ $t[0] ] ) ) ?></span>
	</div></div>
	<?php endforeach; ?>
</div>

<?php if ( count( $mensuel['labels'] ) > 1 ) :
	$ds = array( array( 'label' => 'Chiffre d\'affaires', 'values' => $mensuel['ca'], 'color' => 'var(--blue)' ) );
	if ( array_filter( $mensuel['marge'] ) ) { $ds[] = array( 'label' => 'Marge commerciale', 'values' => $mensuel['marge'], 'type' => 'line', 'color' => 'var(--ok)' ); }
	$ds[] = array( 'label' => 'EBE', 'values' => $mensuel['ebe'], 'type' => 'line', 'color' => 'var(--orange)' );
?>
<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">📊</span>Chiffre d'affaires et marges, mois par mois</span> <span class="couche couche-perf">Performance</span></h2></div>
	<div class="card-body"><?= FKC_Chart::combo( $mensuel['labels'], $ds, array( 'width' => 900, 'height' => 280 ) ) ?></div></div>
<?php endif; ?>

<div class="card"><div class="card-head" style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center">
	<h2>Soldes intermédiaires de gestion <span class="couche couche-perf">Performance</span></h2>
	<button type="button" class="btn btn-ghost btn-sm" id="mgDetail" aria-pressed="true">Masquer le détail</button>
</div><div class="card-body">
	<div class="table-wrap"><table class="table mg-sig" id="mgSig">
		<thead><tr><th>Poste</th><th class="mg-num">Période</th><th class="mg-num mg-hide-s">% CA</th><th class="mg-num">N-1</th><th class="mg-num mg-hide-s">% CA N-1</th><th class="mg-num">Variation</th></tr></thead>
		<tbody>
		<?php foreach ( $sig['lignes'] as $l ) :
			$cls = 'd' === $l['type'] ? 'mg-d' : ( 'g' === $l['type'] ? 'mg-g' : 'mg-s' );
			if ( 'd' === $l['type'] && abs( $l['n'] ) < 0.5 && abs( $l['n1'] ) < 0.5 ) { continue; }
			// Les charges arrivent en positif : le « − » de la colonne suffit à dire qu'elles se retranchent.
			$aff = 1;
			$lien = FKC_Marge::lienGrandLivre( $l['prefixes'], $sig['du'], $sig['au'] );
			// Une charge qui monte est une mauvaise nouvelle : sa variation se lit à l'envers.
			$inv = '−' === $l['signe'];
		?>
			<tr class="<?= $cls ?>" data-cle="<?= e( $l['cle'] ) ?>">
				<td><span class="mg-sg"><?= e( $l['signe'] ) ?></span><?php if ( $lien ) : ?><a href="<?= e( url( $lien ) ) ?>" title="Voir les écritures (grand livre)"><?= e( $l['libelle'] ) ?></a><?php else : ?><?= e( $l['libelle'] ) ?><?php endif; ?></td>
				<td class="mg-num"><?= e( $fkcM( $aff * $l['n'] ) ) ?></td>
				<td class="mg-num mg-hide-s muted"><?= e( $fkcP( $l['pct_ca'] ) ) ?></td>
				<td class="mg-num"><?= e( $fkcM( $aff * $l['n1'] ) ) ?></td>
				<td class="mg-num mg-hide-s muted"><?= e( $fkcP( $l['pct_ca1'] ) ) ?></td>
				<td class="mg-num"><?= $fkcVar( $l['var'], $inv ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<p class="mg-note">Même calcul que le compte de résultat SYSCOHADA, hors écriture de détermination du résultat. N-1 : <?= e( $per1 ) ?>. Cliquez un poste pour voir ses écritures.</p>
</div></div>

<?php if ( $parAxe ) : $pa = $parAxe; $max = 1.0; foreach ( $pa['lignes'] as $l ) { $max = max( $max, abs( $l['marge'] ) ); } ?>
<div class="card" id="mgAxe"><div class="card-head" style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center">
	<h2>Marge par <?= e( mb_strtolower( $pa['axe']['libelle'] ?? 'section' ) ) ?> <span class="couche couche-perf">Performance</span></h2>
	<?php if ( count( $axes ) > 1 ) : ?>
	<form method="get" class="mg-axe" action="<?= e( url( 'analyse/rentabilite' ) ) ?>#mgAxe">
		<?php foreach ( $garder as $k => $v ) : ?><input type="hidden" name="<?= e( $k ) ?>" value="<?= e( $v ) ?>"><?php endforeach; ?>
		<label class="muted" for="mgAxeSel" style="font-size:12.5px">Axe</label>
		<select name="axe" id="mgAxeSel" onchange="this.form.submit()">
			<?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $a['id'] === (int) $pa['axe']['id'] ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?>
		</select>
		<noscript><button class="btn btn-ghost btn-sm">OK</button></noscript>
	</form>
	<?php endif; ?>
</div><div class="card-body">
	<?php if ( ! $pa['lignes'] ) : ?>
		<p class="muted" style="margin:0">Aucune écriture affectée à cet axe sur l'exercice <?= e( FKC_Exercice::libelle( $pa['annee'] ) ) ?>. <a href="<?= e( url( 'analytique' ) ) ?>">Ouvrir l'analytique</a></p>
	<?php else : ?>
	<div class="table-wrap"><table class="table">
		<thead><tr><th>Section</th><th class="mg-num mg-hide-s">Produits</th><th class="mg-num mg-hide-s">Charges</th><th class="mg-num">Marge</th><th class="mg-num">Taux</th><th class="mg-hide-s"></th></tr></thead>
		<tbody>
		<?php foreach ( array_merge( $pa['lignes'], $pa['non_affecte'] ? array( $pa['non_affecte'] ) : array() ) as $l ) :
			$lien = 'analytique/detail?' . http_build_query( array( 'axe' => (int) $pa['axe']['id'], 'valeur' => (int) $l['valeur_id'], 'annee' => $pa['annee'] ) );
			$pct = min( 100, abs( $l['marge'] ) / $max * 100 );
		?>
			<tr<?= 0 === (int) $l['valeur_id'] ? ' class="muted"' : '' ?>>
				<td><a href="<?= e( url( $lien ) ) ?>"><?= e( $l['libelle'] ) ?></a><?php if ( '' !== (string) $l['code'] && '—' !== $l['code'] ) : ?> <span class="muted" style="font-size:11.5px"><?= e( $l['code'] ) ?></span><?php endif; ?></td>
				<td class="mg-num mg-hide-s"><?= e( $fkcM( $l['produits'] ) ) ?></td>
				<td class="mg-num mg-hide-s"><?= e( $fkcM( $l['charges'] ) ) ?></td>
				<td class="mg-num" style="font-weight:600;color:<?= $l['marge'] < 0 ? 'var(--danger)' : 'inherit' ?>"><?= e( $fkcM( $l['marge'] ) ) ?></td>
				<td class="mg-num"><?= e( $fkcP( $l['taux'] ) ) ?></td>
				<td class="mg-hide-s" style="width:22%"><?php if ( 0 !== (int) $l['valeur_id'] ) : ?><div class="mg-bar"><i style="width:<?= round( $pct, 1 ) ?>%;background:<?= $l['marge'] < 0 ? 'var(--danger)' : 'var(--ok)' ?>"></i></div><?php endif; ?></td>
			</tr>
		<?php endforeach; ?>
		<tr style="font-weight:700;border-top:2px solid var(--line)"><td>Total</td><td class="mg-num mg-hide-s"><?= e( $fkcM( $pa['totaux']['produits'] ) ) ?></td><td class="mg-num mg-hide-s"><?= e( $fkcM( $pa['totaux']['charges'] ) ) ?></td><td class="mg-num"><?= e( $fkcM( $pa['totaux']['marge'] ) ) ?></td><td class="mg-num"><?= e( $fkcP( $pa['totaux']['taux'] ) ) ?></td><td class="mg-hide-s"></td></tr>
		</tbody>
	</table></div>
	<?php endif; ?>
	<p class="mg-note">Exercice <?= e( FKC_Exercice::libelle( $pa['annee'] ) ) ?> entier — l'analytique se lit par exercice. Marge = produits − charges de gestion affectés (hors HAO).<?php if ( null !== $pa['couverture'] ) : ?> Couverture de l'axe : <strong style="color:<?= $pa['couverture'] < 80 ? 'var(--orange)' : 'inherit' ?>"><?= (int) $pa['couverture'] ?> %</strong> du mouvement<?= $pa['couverture'] < 80 ? ' — un classement sur un axe peu affecté peut tromper' : '' ?>.<?php endif; ?></p>
</div></div>
<?php endif; ?>

<?php if ( $articles ) : $ar = $articles; ?>
<div class="card" id="mgArticles"><div class="card-head" style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center">
	<h2>Marge par article <span class="couche couche-perf">Performance</span></h2>
	<?php if ( $ar['nb'] > 15 ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'analyse/rentabilite?' . http_build_query( $garder + ( $tousArticles ? array() : array( 'articles' => 'tous' ) ) ) ) ) ?>#mgArticles"><?= $tousArticles ? 'Voir les 15 premiers' : 'Voir les ' . (int) $ar['nb'] . ' articles' ?></a><?php endif; ?>
</div><div class="card-body">
	<div class="an-grid" style="margin-bottom:10px">
		<div><span class="muted" style="font-size:12px">Ventes HT</span><br><strong><?= e( $fkcM( $ar['totaux']['ca'] ) ) ?></strong></div>
		<div><span class="muted" style="font-size:12px">Coût des articles vendus</span><br><strong><?= e( $fkcM( $ar['totaux']['cout'] ) ) ?></strong></div>
		<div><span class="muted" style="font-size:12px">Marge brute</span><br><strong style="color:<?= $ar['totaux']['marge'] < 0 ? 'var(--danger)' : 'var(--ok)' ?>"><?= e( $fkcM( $ar['totaux']['marge'] ) ) ?></strong> <span class="muted">(<?= e( $fkcP( $ar['totaux']['taux'] ) ) ?>)</span></div>
	</div>
	<div class="table-wrap"><table class="table">
		<thead><tr><th>Article</th><th class="mg-num mg-hide-s">Qté</th><th class="mg-num">Ventes HT</th><th class="mg-num mg-hide-s">Coût</th><th class="mg-num">Marge</th><th class="mg-num">Taux</th></tr></thead>
		<tbody>
		<?php foreach ( $ar['lignes'] as $l ) : ?>
			<tr>
				<td><?php if ( $lienArticle && $l['article_id'] ) : ?><a href="<?= e( url( 'inventaire/articles/' . (int) $l['article_id'] . '/modifier' ) ) ?>"><?= e( $l['designation'] ) ?></a><?php else : ?><?= e( $l['designation'] ) ?><?php endif; ?>
					<?php if ( $l['code'] ) : ?> <span class="muted" style="font-size:11.5px"><?= e( $l['code'] ) ?></span><?php endif; ?>
					<?php if ( $l['sans_cout'] ) : ?> <span class="badge" style="background:var(--danger-bg);color:var(--danger)" title="Aucun coût connu à la vente : la marge est surestimée">coût inconnu</span><?php endif; ?></td>
				<td class="mg-num mg-hide-s"><?= e( rtrim( rtrim( number_format( $l['qte'], 2, ',', ' ' ), '0' ), ',' ) ) ?></td>
				<td class="mg-num"><?= e( $fkcM( $l['ca'] ) ) ?></td>
				<td class="mg-num mg-hide-s"><?= e( $fkcM( $l['cout'] ) ) ?></td>
				<td class="mg-num" style="font-weight:600;color:<?= $l['marge'] < 0 ? 'var(--danger)' : 'inherit' ?>"><?= e( $fkcM( $l['marge'] ) ) ?></td>
				<td class="mg-num"><?= e( $fkcP( $l['taux'] ) ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<?php if ( ! $tousArticles && $ar['faibles'] && $ar['nb'] > 15 ) : ?>
		<p class="mg-note"><strong>Taux les plus faibles :</strong>
		<?php foreach ( $ar['faibles'] as $i => $l ) : ?><?= $i ? ' · ' : '' ?><?= e( $l['designation'] ) ?> <span style="color:<?= $l['taux'] < 0 ? 'var(--danger)' : 'inherit' ?>">(<?= e( $fkcP( $l['taux'] ) ) ?>)</span><?php endforeach; ?></p>
	<?php endif; ?>
	<p class="mg-note">Ventes encaissées en caisse sur la période, hors taxes et après remises, retours déduits. Coût = coût moyen pondéré (CUMP) de l'article au moment de la vente.<?= $ar['sans_cout'] ? ' <strong>' . (int) $ar['sans_cout'] . ' article(s) sans coût</strong> : renseignez leur prix d\'achat pour une marge juste.' : '' ?> Les ventes par facture ne sont pas rattachées aux articles et n'apparaissent pas ici.</p>
</div></div>
<?php endif; ?>

<?php if ( $d && ! empty( $d['top_charges'] ) ) : ?>
<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">🧾</span>Répartition des charges par nature</span> <span class="couche couche-perf">Performance</span></h2></div><div class="card-body"><?php $cd = array(); foreach ( $d['top_charges'] as $r ) { $cd[ $r['libelle'] ] = (float) $r['v']; } echo FKC_Chart::barsH( $cd, array( 'width' => 900, 'label_w' => 260 ) ); ?></div></div>
<?php endif; ?>
<script>
(function(){
	var b=document.getElementById('mgDetail'), t=document.getElementById('mgSig'); if(!b||!t)return;
	b.addEventListener('click',function(){ var court=t.classList.toggle('mg-court'); b.textContent=court?'Afficher le détail':'Masquer le détail'; b.setAttribute('aria-pressed',court?'false':'true'); });
})();
</script>
