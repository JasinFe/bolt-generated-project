<?php /** @var array|null $d @var array $secteur @var bool $musical */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$T = function ( $k, $df ) { return class_exists( 'FKC_Term' ) ? FKC_Term::t( $k, $df ) : $df; }; ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'sectorielle' ) ); ?>
<div class="bar"><span class="muted"><?= e( $secteur[0] . ' ' . $secteur[1] ) ?> — analyse réservée à l'édition Creative.</span></div>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucune donnée sectorielle (importez des relevés dans le module <?= e( $T('module','Label musical') ) ?>).</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card"><div class="card-body an-kpi"><span class="l"><?= e( $T('audience','Streams') ) ?></span><span class="v"><?= e( fkc_money( $d['streams_total'], 0 ) ) ?></span></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l"><?= e( $T('revenus','Royalties') ) ?> (total)</span><span class="v"><?= e( fkc_money( $d['royalties_total'] ) ) ?></span></div></div>
</div>
<div class="an-grid-2">
	<?php if ( $d['par_plateforme'] ) : ?>
	<div class="card"><div class="card-head"><h2>Par plateforme</h2></div><div class="card-body"><?php $p=array(); foreach($d['par_plateforme'] as $r){$p[$r['nom']]=(float)$r['v'];} echo FKC_Chart::donut( $p ); ?></div></div>
	<?php endif; ?>
	<?php if ( $d['par_artiste'] ) : ?>
	<div class="card"><div class="card-head"><h2>Par <?= e( fkc_lc( $T('talent','artiste') ) ) ?></h2></div><div class="card-body"><?php $a=array(); foreach($d['par_artiste'] as $r){$a[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $a, array('color'=>'var(--orange)') ); ?></div></div>
	<?php endif; ?>
</div>
<div class="an-grid-2">
	<?php if ( array_sum($d['streams_mois'])>0 ) : ?>
	<div class="card"><div class="card-head"><h2><?= e( $T('audience','Streaming') ) ?> (12 mois) <span class="couche couche-op">Opérationnel</span></h2></div><div class="card-body"><?= FKC_Chart::line( $d['streams_mois'], array('color'=>'var(--blue)') ) ?></div></div>
	<?php endif; ?>
	<?php if ( array_sum($d['royalties_mois'])>0 ) : ?>
	<div class="card"><div class="card-head"><h2><?= e( $T('revenus','Royalties') ) ?> (12 mois)</h2></div><div class="card-body"><?= FKC_Chart::bars( $d['royalties_mois'], array('color'=>'var(--ok)') ) ?></div></div>
	<?php endif; ?>
</div>
<div class="an-grid-2">
	<?php if ( $d['concerts'] ) : ?>
	<div class="card"><div class="card-head"><h2><?= e( $T('evenements','Concerts') ) ?> — résultat</h2></div><div class="card-body"><?php $c=array(); foreach($d['concerts'] as $r){$c[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $c, array('color'=>'var(--blue)') ); ?></div></div>
	<?php endif; ?>
	<?php if ( $d['campagnes'] ) : ?>
	<div class="card"><div class="card-head"><h2>Campagnes — conversions</h2></div><div class="card-body"><?php $c=array(); foreach($d['campagnes'] as $r){$c[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $c, array('color'=>'var(--orange)') ); ?></div></div>
	<?php endif; ?>
</div>
