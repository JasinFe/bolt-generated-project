<?php
/**
 * Cockpit FinaKop Maestro.
 *
 * L'écran suit l'ordre dans lequel un dirigeant lit : ce qu'il faut faire
 * d'abord, pourquoi, sur quoi c'est fondé. Les sources et l'indice de
 * confiance ne sont pas relégués dans une note de bas de page — ils sont
 * DANS la carte, parce que c'est ce qui distingue un conseil d'une opinion.
 *
 * @var array $ctx, $attentes, $priorites, $synthese, $bilan, $dna, $timeline, $signaux, $inventaire, $llm, $previsions, $anomalies, $opportunites, $bilan_opp, $propositions, $appris, $est_admin, $leviers_sim, $plans_action, $actions_attente, $bilan_action
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'maestro' ) );

$grav = array(
	'critique' => array( '🔴', '#c33' ), 'risque' => array( '🟠', '#e67e22' ),
	'attention' => array( '🟡', '#c80' ), 'info' => array( '🔵', '#39c' ),
);
$etatLabel = array( 'action' => 'Action possible', 'alerte' => 'Alerte', 'signal' => 'Signal', 'silence' => 'Observé' );
/* Une seule santé, la même que le copilote et le moteur FIE ; « — » tant que rien n'est mesuré (1.837.0). */
$fkcSante = isset( $sante_globale ) ? $sante_globale : FKC_Maestro::sante();
$sante = $fkcSante['valeur'];
$couleurSante = null === $sante ? 'var(--muted)' : ( $sante >= 80 ? 'var(--ok)' : ( $sante >= 55 ? '#c80' : '#c33' ) );
?>
<div class="card-head" style="margin-bottom:12px">
	<h2>🎼 FinaKop Maestro</h2>
	<span class="muted">Votre copilote intelligent de gestion — il coordonne vos métiers pour comprendre la situation globale.</span>
</div>

<?php
/*
 * TOUTES LES CARTES DANS UNE SEULE GRILLE (1.719.0).
 *
 * L'écran restait une colonne : on avait rangé les trois cartes du bas côte
 * à côte, et laissé les huit autres empilées sur toute la hauteur. Sur un
 * écran de 1 900 px, cela faisait défiler quatre écrans de contenu large
 * d'un seul bloc.
 *
 * Tout passe donc par .cards-grid. Ce qui a besoin de la largeur entière le
 * demande par .card-pleine — un simulateur, une liste de priorités avec ses
 * boutons, un inventaire de vingt Experts. Le reste se range deux ou trois
 * par rangée, et se replie seul sur un portable.
 */
?>
<div class="cards-grid">
<div class="card card-pleine">
	<div class="card-body" style="display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between">
		<div>
			<strong><?= e( FKC_Maestro_Language::salutation( $ctx['prenom'] ?? '' ) ) ?></strong>
			<div class="muted" style="font-size:12px">
				<?= e( FKC_Maestro_Language::dateFr() ) ?>
				· <?= e( $attentes['libelle'] ?? '' ) ?>
				<?php if ( ! empty( $ctx['pack_libelle'] ) ) : ?> · <?= e( $ctx['pack_libelle'] ) ?><?php endif; ?>
				· période <?= e( FKC_Maestro_Context::periodeLabel() ) ?>
			</div>
		</div>
		<div style="text-align:center">
			<span class="muted" style="font-size:11px">Santé globale</span>
			<div style="font-size:1.8em;font-weight:800;color:<?= $couleurSante ?>" data-sante="<?= null === $sante ? '' : (int) $sante ?>"><?= null === $sante ? '—' : (int) $sante ?><?php if ( null !== $sante ) : ?><span style="font-size:.45em;color:var(--muted)">/100</span><?php endif; ?></div>
			<?php if ( null === $sante ) : ?><span class="muted" style="font-size:11px">pas encore de donnée mesurée</span><?php endif; ?>
			<?php if ( ! empty( $masquees ) ) : ?><div class="muted" style="font-size:11px;max-width:220px" data-masquees="<?= (int) $masquees ?>">🔒 <?= (int) $masquees ?> signal(aux) hors de vos domaines non affiché(s)</div><?php endif; ?>
		</div>
		<div style="text-align:right;font-size:11px" class="muted">
			Intelligence métier : FinaKop<br>
			Langage : <?= ! empty( $llm['disponible'] ) ? e( $llm['libelle'] ) : 'interne (aucune IA externe)' ?>
		</div>
	</div>
</div>

<!-- ══ LE BILAN DIRIGEANT ═══════════════════════════════════════════════
     Il OUVRE l'écran, avant tout le reste, parce que c'est la seule question
     qu'un dirigeant pose vraiment : « comment va mon entreprise ? ». Tout ce
     qui suit — priorités, prévisions, anomalies — n'est que le détail sur
     lequel cette réponse s'appuie. L'inverse, un cockpit qui commence par des
     tableaux et finit par une conclusion, oblige à tout lire pour savoir s'il
     fallait lire. -->
<?php if ( ! empty( $bilan['verdict'] ) ) : ?>
<div class="card card-pleine" style="border-left:4px solid <?= $couleurSante ?>">
	<div class="card-body">
		<div style="font-size:1.12em;font-weight:700;line-height:1.45"><?= e( $bilan['verdict'] ) ?></div>

		<?php if ( ! empty( $bilan['contradiction'] ) ) : ?>
			<?php /* La chaîne causale dit POURQUOI deux domaines vont en sens
			         opposés. Sans elle on constate sans expliquer — et on le
			         laisse voir, plutôt que de combler avec une supposition. */ ?>
			<div style="margin-top:10px;padding:10px;border-left:3px solid var(--accent,#39c);background:var(--bg2,rgba(0,0,0,.03));font-size:13px">
				<?php foreach ( (array) $bilan['contradiction']['chaine'] as $ligne ) : ?>
					<div><?= e( $ligne ) ?></div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $bilan['points'] ) ) : ?>
			<div style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
				<?php foreach ( $bilan['points'] as $i => $bp ) :
					$g = $grav[ $bp['gravite'] ] ?? $grav['info']; ?>
					<div style="display:flex;gap:9px;align-items:flex-start">
						<span style="font-size:13px;line-height:1.5"><?= $g[0] ?></span>
						<div style="flex:1">
							<?php if ( ! empty( $bp['expert_libelle'] ) ) : ?>
								<span class="muted" style="font-size:11px"><?= e( $bp['expert_libelle'] ) ?></span><br>
							<?php endif; ?>
							<span style="font-size:13px"><?= e( $bp['message'] ) ?></span>
							<?php /* Une seule recommandation affichée, celle du premier
							         point : une liste de dix priorités n'en est pas une. */ ?>
							<?php if ( 0 === $i && ! empty( $bp['recommandation'] ) ) : ?>
								<div style="margin-top:5px;font-size:12.5px">
									<strong>À traiter d'abord —</strong> <?= e( $bp['recommandation'] ) ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $bilan['angles_morts'] ) ) : ?>
			<?php /* Un silence n'est pas un feu vert : ce que Maestro n'a pas pu
			         examiner est dit, sans quoi l'absence d'alerte se lirait
			         comme une garantie. */ ?>
			<div class="muted" style="margin-top:12px;font-size:11.5px;border-top:1px solid var(--line);padding-top:8px">
				Non examiné faute de données :
				<?= e( implode( ', ', array_map( fn( $a ) => $a['libelle'], array_slice( (array) $bilan['angles_morts'], 0, 4 ) ) ) ) ?><?php
					if ( count( (array) $bilan['angles_morts'] ) > 4 ) { echo ' et ' . ( count( (array) $bilan['angles_morts'] ) - 4 ) . ' autre(s)'; } ?>.
			</div>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

<!-- Demander à Maestro — un vrai fil de discussion (1.845.0) -->
<div class="card">
	<div class="card-body">
		<div id="mfil" aria-live="polite" style="display:none;max-height:460px;overflow-y:auto;margin-bottom:12px;flex-direction:column;gap:10px"></div>
		<div style="display:flex;gap:8px;flex-wrap:wrap">
			<input type="text" id="mq" class="input" style="flex:1;min-width:220px" autocomplete="off"
				placeholder="Demandez : « que dois-je faire aujourd'hui ? » puis « pourquoi ? »">
			<button class="btn btn-primary" id="mq-btn" onclick="mAsk()">Demander</button>
			<button class="btn btn-ghost" onclick="mNouveauSujet()" title="Maestro oublie le sujet en cours">Nouveau sujet</button>
			<?php if ( ! empty( $est_admin ) ) : ?>
				<a class="btn btn-ghost" href="<?= htmlspecialchars( url( 'maestro/langage' ), ENT_QUOTES, 'UTF-8' ) ?>" title="Questions restées sans réponse, expressions apprises">Langage de Maestro</a>
			<?php endif; ?>
		</div>
		<div id="mrep-suites" style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap"></div>
	</div>
</div>

<?php if ( ! empty( $plans_action ) || ! empty( $actions_attente ) ) : ?>
<!-- Action assistée -->
<div class="card card-pleine">
	<div class="card-head"><h2>🎬 Action assistée</h2>
		<?php if ( ! empty( $bilan_action['ecartes'] ) ) : ?>
			<span class="muted" style="font-size:11px">
				<?= (int) $bilan_action['ecartes'] ?> élément(s) écarté(s) à la dernière minute depuis le début — la situation avait changé
			</span>
		<?php endif; ?>
	</div>
	<div class="card-body">
		<p class="muted" style="font-size:11px;margin-top:0">
			Maestro prépare, <strong>vous validez</strong>. Au moment d'exécuter, chaque élément est revérifié :
			ce qui ne remplit plus les conditions est écarté, et vous saurez pourquoi.
		</p>

		<?php if ( ! empty( $actions_attente ) ) : foreach ( $actions_attente as $ac ) : ?>
			<div class="card" style="margin-bottom:10px;border-left:4px solid #e67e22">
				<div class="card-body" data-dossier="<?= (int) $ac['id'] ?>">
					<strong><?= e( $ac['libelle'] ) ?></strong>
					<span class="muted" style="font-size:11px"> · <?= (int) $ac['nb_cibles'] ?> élément(s)
						<?php if ( (float) $ac['montant_total'] > 0 ) : ?>
							· <?= e( FKC_Maestro_Language::montant( $ac['montant_total'], 'F' ) ) ?>
						<?php endif; ?>
					</span>
					<p style="margin:5px 0 0;font-size:13px"><?= e( $ac['apercu'] ) ?></p>
					<span class="muted" style="font-size:10px">Préparé — valable jusqu'à <?= e( substr( (string) $ac['expire_at'], 11, 5 ) ) ?></span>
					<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
						<button class="btn btn-primary btn-sm" onclick="mExec(<?= (int) $ac['id'] ?>, <?= empty( $ac['reversible'] ) ? 1 : 0 ?>, this)">Valider et exécuter</button>
						<button class="btn btn-ghost btn-sm" onclick="mAbandon(<?= (int) $ac['id'] ?>, this)">Abandonner</button>
					</div>
					<div class="mexec-rep" style="display:none;margin-top:8px;font-size:12px"></div>
				</div>
			</div>
		<?php endforeach; endif; ?>

		<?php if ( ! empty( $plans_action ) ) : ?>
			<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">
				<?php foreach ( $plans_action as $pl ) : ?>
					<button class="btn btn-ghost btn-sm" onclick="mPreparer(<?= json_encode( $pl['cle'] ) ?>, this)">
						Préparer : <?= e( $pl['libelle'] ) ?>
					</button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

<?php if ( ! empty( $leviers_sim ) ) : ?>
<!-- Simulateur « et si… ? » -->
<div class="card card-pleine">
	<div class="card-head"><h2>🔮 Et si… ?</h2>
		<span class="muted">l'effet se propage le long des relations connues</span>
	</div>
	<div class="card-body">
		<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
			<span style="font-size:13px">Si</span>
			<select id="sim-levier" class="input" style="flex:1;min-width:150px">
				<?php foreach ( $leviers_sim as $lv ) : ?>
					<option value="<?= e( $lv['predicat'] ) ?>"><?= e( $lv['libelle'] ) ?></option>
				<?php endforeach; ?>
			</select>
			<span style="font-size:13px">varie de</span>
			<input type="number" id="sim-pct" class="input" value="20" step="5" style="width:90px"> %
			<button class="btn btn-primary" onclick="mSim()">Simuler</button>
		</div>
		<div id="sim-rep" style="display:none;margin-top:12px;padding:12px;border-left:3px solid var(--accent,#39c);background:var(--bg2,rgba(0,0,0,.03))">
			<div id="sim-texte" style="white-space:pre-line;font-size:13px"></div>
			<div id="sim-meta" class="muted" style="font-size:11px;margin-top:8px"></div>
		</div>
	</div>
</div>
<?php endif; ?>

<?php
/*
 * LES CARTES S'ÉTALENT, ELLES NE S'EMPILENT PAS (1.716.0).
 *
 * Cet écran plaçait « ADN de l'entreprise », « Signaux suivis » et « Ce que
 * Maestro sait » dans une colonne de 340 px. Trois cartes de diagnostic
 * étranglées sur un tiers d'écran, à lire l'une sous l'autre, pendant que
 * les deux autres tiers servaient à afficher deux priorités.
 *
 * C'est le même défaut qu'au Studio en 1.701.0, et la même correction : le
 * contenu principal prend toute la largeur, les cartes de contexte se
 * rangent DESSOUS, côte à côte.
 */
?>
	<div class="card card-flush card-pleine">
			<div class="card-head"><h2>🎯 Vos priorités</h2>
				<span class="muted"><?= count( $priorites ) ?> point(s) retenu(s)</span>
			</div>
			<div class="card-body">
				<?php if ( empty( $priorites ) ) : ?>
					<p class="muted" style="text-align:center;padding:26px">
						Rien ne demande votre attention pour l'instant.<br>
						<span style="font-size:12px">Maestro observe en silence : il ne vous parlera que lorsqu'un signal se confirmera.</span>
					</p>
				<?php else : foreach ( $priorites as $p ) :
					$g = $grav[ $p['gravite'] ] ?? array( '⚪', '#888' );
					$conf = (array) ( $p['confiance'] ?? array() );
					$etat = (string) ( $p['signal']['etat'] ?? 'signal' );
				?>
					<div class="card" style="margin-bottom:12px;border-left:4px solid <?= $g[1] ?>">
						<div class="card-body">
							<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
								<div style="flex:1;min-width:200px">
									<strong><?= $g[0] ?> <?= e( $p['titre'] ) ?></strong>
									<span class="muted" style="font-size:11px;text-transform:uppercase"> · <?= e( $p['domaine'] ) ?></span>
									<span style="font-size:11px;margin-left:6px"><?= e( $p['pastille'] ) ?> <?= e( $p['mode_libelle'] ) ?></span>
									<span class="muted" style="font-size:11px"> · <?= e( $etatLabel[ $etat ] ?? $etat ) ?></span>
									<p style="margin:6px 0 0;font-size:14px"><?= e( $p['message'] ) ?></p>
									<?php if ( ! empty( $p['recommandation'] ) ) : ?>
										<p style="margin:4px 0 0;font-size:13px;color:var(--ok)">→ <?= e( $p['recommandation'] ) ?></p>
									<?php endif; ?>
								</div>
								<div style="text-align:right;min-width:90px">
									<span class="muted" style="font-size:10px">Confiance</span>
									<div style="font-weight:700"><?= (int) ( $conf['pct'] ?? 0 ) ?> %</div>
									<span class="muted" style="font-size:10px"><?= e( $conf['label'] ?? '' ) ?></span>
								</div>
							</div>

							<?php if ( ! empty( $p['sources'] ) ) : ?>
							<details style="margin-top:8px">
								<summary style="cursor:pointer;font-size:12px;color:var(--muted)">Sur quoi je me base</summary>
								<ul style="margin:8px 0 0;padding-left:18px;font-size:12px;color:var(--muted)">
									<?php foreach ( $p['sources'] as $s ) : ?>
										<li><?= 'externe' === ( $s['nature'] ?? '' ) ? '⚠' : '✓' ?> <?= e( $s['libelle'] ) ?><?php
											if ( 'estimee' === ( $s['nature'] ?? '' ) ) { echo ' <em>(estimation)</em>'; }
											if ( 'externe' === ( $s['nature'] ?? '' ) ) { echo ' <em>(hors FinaKop)</em>'; }
										?></li>
									<?php endforeach; ?>
									<li class="muted">Période : <?= e( $p['periode'] ) ?></li>
								</ul>
							</details>
							<?php endif; ?>

							<?php if ( ! empty( $p['details'] ) ) : ?>
							<details style="margin-top:6px">
								<summary style="cursor:pointer;font-size:12px;color:var(--accent,#39c)">Pourquoi je vous dis cela</summary>
								<ol style="margin:8px 0 0;padding-left:18px;font-size:12px;color:var(--muted)">
									<?php foreach ( $p['details'] as $c ) : ?><li><?= e( $c ) ?></li><?php endforeach; ?>
								</ol>
							</details>
							<?php endif; ?>

							<?php foreach ( (array) $p['actions'] as $a ) : ?>
								<div style="margin-top:8px;padding:8px;border:1px dashed var(--line);font-size:12px">
									<strong><?= e( $a['label'] ) ?></strong>
									<?php if ( ! empty( $a['validation_requise'] ) ) : ?>
										<span class="muted"> — Maestro prépare, <strong>vous validez</strong>.</span>
									<?php endif; ?>
									<?php if ( empty( $a['autorise'] ) ) : ?>
										<span class="muted"> — <?= e( $a['motif'] ) ?></span>
									<?php endif; ?>
									<?php if ( ! empty( $a['etapes'] ) ) : ?>
										<ol style="margin:6px 0 0;padding-left:18px"><?php foreach ( $a['etapes'] as $et ) : ?><li><?= e( $et ) ?></li><?php endforeach; ?></ol>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>

							<?php if ( ! empty( $p['reco_id'] ) ) : ?>
							<div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap" data-reco="<?= (int) $p['reco_id'] ?>">
								<?php foreach ( array( 'pertinent' => '👍 Pertinent', 'pas_pertinent' => '👎 Pas pertinent', 'faite' => '✅ Fait', 'refusee' => '❌ Refusé', 'plus_tard' => '⏰ Plus tard' ) as $v => $lab ) : ?>
									<button class="btn btn-ghost btn-sm" onclick="mFeedback(<?= (int) $p['reco_id'] ?>,'<?= e( $v ) ?>',this)"><?= e( $lab ) ?></button>
								<?php endforeach; ?>
							</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; endif; ?>
			</div>
		</div>

		<?php if ( ! empty( $opportunites ) ) : ?>
	<div class="card card-flush">
			<div class="card-head"><h2>💡 Opportunités</h2>
				<?php if ( ! empty( $bilan_opp['saisies'] ) && null !== $bilan_opp['fidelite'] ) : ?>
					<span class="muted" style="font-size:11px">estimations tenues à <?= (int) round( (float) $bilan_opp['fidelite'] * 100 ) ?> %</span>
				<?php endif; ?>
			</div>
			<div class="card-body">
				<p class="muted" style="font-size:11px;margin-top:0">
					Écarts entre votre situation actuelle et un niveau que vous avez déjà tenu.
					Elles passent après les alertes : un risque engagé prime sur un gain à venir.
				</p>
				<?php foreach ( $opportunites as $op ) : $o = $op['donnees']['opportunite'] ?? array(); ?>
					<div class="card" style="margin-bottom:10px;border-left:4px solid var(--ok)">
						<div class="card-body">
							<strong><?= e( $op['titre'] ) ?></strong>
							<span class="muted" style="font-size:11px"> · effort <?= e( array( 'faible' => 'faible', 'moyen' => 'moyen', 'eleve' => 'élevé' )[ $o['effort'] ?? 'moyen' ] ) ?></span>
							<p style="margin:5px 0 0;font-size:14px"><?= e( $op['message'] ) ?></p>
							<?php if ( ! empty( $o['methode'] ) ) : ?>
								<p class="muted" style="margin:4px 0 0;font-size:11px"><?= e( $o['methode'] ) ?></p>
							<?php endif; ?>
							<?php if ( ! empty( $op['details'] ) ) : ?>
								<details style="margin-top:6px">
									<summary style="cursor:pointer;font-size:12px;color:var(--accent,#39c)">Comment s'y prendre</summary>
									<ol style="margin:6px 0 0;padding-left:18px;font-size:12px">
										<?php foreach ( $op['details'] as $et ) : ?><li style="margin-bottom:3px"><?= e( $et ) ?></li><?php endforeach; ?>
									</ol>
								</details>
							<?php endif; ?>
							<?php if ( ! empty( $o['condition'] ) ) : ?>
								<p class="muted" style="margin:5px 0 0;font-size:11px">⚠ <?= e( $o['condition'] ) ?></p>
							<?php endif; ?>
							<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">
								<button class="btn btn-ghost btn-sm" onclick="mOpp(<?= json_encode( $o['cle'] ?? '' ) ?>,'saisie',this)">✅ Je m'en occupe</button>
								<button class="btn btn-ghost btn-sm" onclick="mOpp(<?= json_encode( $o['cle'] ?? '' ) ?>,'ignoree',this)">Pas pour l'instant</button>
								<button class="btn btn-ghost btn-sm" onclick="mOpp(<?= json_encode( $o['cle'] ?? '' ) ?>,'impossible',this)">Pas réalisable</button>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if ( ! empty( $anomalies ) ) : ?>
		<div class="card card-flush">
			<div class="card-head"><h2>🔎 Anomalies récentes</h2><span class="muted">7 derniers jours</span></div>
			<div class="card-body">
				<p class="muted" style="font-size:11px;margin-top:0">
					Détectées sur l'écart absolu médian, insensible aux valeurs extrêmes.
					Ce qui s'explique par une cause connue n'apparaît pas ici : ce n'est pas une surprise.
				</p>
				<?php
				$typeLib = array(
					'aberrante' => 'Valeur inhabituelle', 'rupture' => 'Changement de niveau',
					'silence' => 'Données interrompues', 'impossible' => 'Donnée impossible',
				);
				foreach ( $anomalies as $a ) :
					$coul = 'risque' === $a['gravite'] ? '#e67e22' : '#c80';
				?>
					<div style="padding:8px 0;border-bottom:1px solid var(--line);border-left:3px solid <?= $coul ?>;padding-left:8px;margin-bottom:4px">
						<strong style="font-size:13px"><?= e( $typeLib[ $a['type'] ] ?? $a['type'] ) ?></strong>
						<span class="muted" style="font-size:10px"> · <?= e( $a['detectee_le'] ) ?></span>
						<p style="margin:4px 0 0;font-size:12px"><?= e( $a['message'] ) ?></p>
						<a href="<?= e( url( 'maestro/pourquoi' ) ) ?>?predicat=<?= urlencode( $a['predicat'] ) ?>"
						   style="font-size:11px" onclick="return mPourquoi(this, <?= json_encode( $a['predicat'] ) ?>)">Pourquoi ?</a>
						<div class="muted" style="font-size:11px;margin-top:4px;display:none"></div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if ( ! empty( $timeline ) ) : ?>
		<div class="card card-flush">
			<div class="card-head"><h2>🕰️ Chronologie de l'entreprise</h2><span class="muted">ce que Maestro a retenu</span></div>
			<div class="card-body">
				<?php foreach ( $timeline as $t ) : ?>
					<div style="display:flex;gap:10px;padding:6px 0;border-bottom:1px solid var(--line);font-size:12px">
						<span class="muted" style="min-width:82px"><?= e( date( 'd/m/Y', strtotime( $t['survenu_le'] ) ) ) ?></span>
						<span><?= e( $t['libelle'] ) ?> <span class="muted">· <?= e( $t['domaine'] ) ?></span></span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>
		<div class="card card-flush">
			<div class="card-head"><h2>🧬 ADN de l'entreprise</h2></div>
			<div class="card-body">
				<?php if ( empty( $dna ) ) : ?>
					<p class="muted" style="font-size:12px">
						Aucun trait mesuré pour l'instant. Maestro ne suppose rien : il attend d'avoir des données.
					</p>
					<form method="post" action="<?= e( url( 'maestro/observer' ) ) ?>" onsubmit="return mObserver(this)">
						<?= FKC_Csrf::field() ?>
						<button class="btn btn-primary btn-sm" type="submit">Lancer une observation</button>
					</form>
				<?php else : foreach ( $dna as $t ) : ?>
					<div style="padding:6px 0;border-bottom:1px solid var(--line);font-size:12px">
						<div style="display:flex;justify-content:space-between">
							<span><?= e( $t['libelle'] ) ?></span>
							<strong><?= e( null !== $t['valeur_num'] ? rtrim( rtrim( number_format( (float) $t['valeur_num'], 2, ',', ' ' ), '0' ), ',' ) : (string) $t['valeur_txt'] ) ?> <?= e( $t['unite'] ) ?></strong>
						</div>
						<span class="muted" style="font-size:10px">
							mesuré le <?= e( substr( (string) $t['mesure_at'], 0, 10 ) ) ?>
							<?php if ( (int) $t['echantillon'] > 1 ) : ?> · <?= (int) $t['echantillon'] ?> relevés<?php endif; ?>
						</span>
					</div>
				<?php endforeach; endif; ?>
			</div>
		</div>

		<div class="card card-flush">
			<div class="card-head"><h2>📡 Signaux suivis</h2><span class="muted"><?= count( $signaux ) ?></span></div>
			<div class="card-body">
				<p class="muted" style="font-size:11px;margin-top:0">
					Silence → Signal → Alerte → Action. Un sujet ne remonte que s'il se confirme ou s'aggrave.
				</p>
				<?php foreach ( $signaux as $s ) : ?>
					<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--line);font-size:12px">
						<span><?= e( $s['cle'] ) ?></span>
						<span class="muted"><?= e( $etatLabel[ $s['etat'] ] ?? $s['etat'] ) ?> · <?= (int) $s['occurrences'] ?>×</span>
					</div>
				<?php endforeach; ?>
				<?php if ( empty( $signaux ) ) : ?><span class="muted" style="font-size:12px">Aucun signal actif.</span><?php endif; ?>
			</div>
		</div>

		<?php if ( ! empty( $previsions ) ) : ?>
		<div class="card card-flush">
			<div class="card-head"><h2>📈 Prévisions</h2><span class="muted">méthode choisie par mesure</span></div>
			<div class="card-body" style="font-size:12px">
				<p class="muted" style="font-size:11px;margin-top:0">
					Neuf méthodes sont rejouées sur l'historique. Celle qui s'est le moins trompée est retenue —
					et seulement si elle bat le simple report de la dernière valeur.
				</p>
				<?php foreach ( $previsions as $pv ) : ?>
					<div style="padding:7px 0;border-bottom:1px solid var(--line)">
						<div style="display:flex;justify-content:space-between;gap:8px">
							<strong><?= e( $pv['libelle'] ) ?></strong>
							<span><?php
								$t = $pv['tendance_pct'];
								echo null === $t || abs( (float) $t ) < 1 ? '→ stable' : ( $t > 0 ? '↑ +' . round( (float) $t ) . ' %' : '↓ ' . round( (float) $t ) . ' %' );
							?></span>
						</div>
						<span class="muted" style="font-size:10px">
							<?= e( $pv['methode'] ) ?> · confiance <?= (int) $pv['confiance'] ?> %
							<?php if ( ! empty( $pv['bat_la_naive'] ) && null !== $pv['mase'] ) : ?>
								· se trompe <?= (int) round( ( 1 - (float) $pv['mase'] ) * 100 ) ?> % moins que le report simple
							<?php elseif ( (int) $pv['plis'] > 0 ) : ?>
								· aucun modèle ne bat le report simple ici
							<?php endif; ?>
							<?php if ( ! empty( $pv['fiabilite']['mesures'] ) ) : ?>
								<br>constaté sur <?= (int) $pv['fiabilite']['mesures'] ?> mesure(s) :
								couverture <?= (int) $pv['fiabilite']['couverture_pct'] ?> %
							<?php endif; ?>
						</span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if ( ! empty( $propositions ) || ! empty( $appris ) ) : ?>
		<div class="card card-flush">
			<div class="card-head"><h2>🧠 Apprentissage</h2></div>
			<div class="card-body" style="font-size:12px">
				<?php if ( ! empty( $propositions ) ) : ?>
					<p class="muted" style="font-size:11px;margin-top:0">
						Maestro propose ; vous décidez. Rien n'est appliqué sans votre accord.
					</p>
					<?php foreach ( $propositions as $pr ) : ?>
						<div style="padding:7px 0;border-bottom:1px solid var(--line)">
							<strong><?= e( $pr['cle'] ) ?></strong>
							<span class="muted" style="font-size:10px"> · niveau <?= (int) $pr['niveau'] ?><?php
								if ( 3 === (int) $pr['niveau'] ) { echo ' · connaissance critique'; }
							?></span>
							<p style="margin:3px 0 0;font-size:11px" class="muted"><?= e( $pr['justification'] ) ?></p>
							<?php if ( ! empty( $pr['valeur_avant'] ) ) : ?>
								<span style="font-size:11px"><?= e( $pr['valeur_avant'] ) ?> → <strong><?= e( FKC_Maestro_Schema::couper( (string) $pr['valeur_proposee'], 60 ) ) ?></strong></span>
							<?php endif; ?>
							<?php if ( ! empty( $est_admin ) ) : ?>
								<div style="margin-top:5px">
									<button class="btn btn-primary btn-sm" onclick="mAppr(<?= (int) $pr['id'] ?>,1,this)">Valider</button>
									<button class="btn btn-ghost btn-sm" onclick="mAppr(<?= (int) $pr['id'] ?>,0,this)">Refuser</button>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				<?php else : ?>
					<p class="muted" style="font-size:11px;margin-top:0">Aucune proposition en attente.</p>
				<?php endif; ?>

				<?php if ( ! empty( $appris ) ) : ?>
					<hr style="border:0;border-top:1px solid var(--line);margin:8px 0">
					<strong style="font-size:11px">En vigueur</strong>
					<?php foreach ( array_slice( $appris, 0, 6 ) as $ap ) : ?>
						<div style="display:flex;justify-content:space-between;gap:6px;padding:4px 0;font-size:11px">
							<span class="muted"><?= e( $ap['categorie'] ) ?> · <?= e( $ap['cle'] ) ?></span>
							<?php if ( ! empty( $est_admin ) ) : ?>
								<a href="#" style="font-size:11px" onclick="return mRevoquer(<?= json_encode( $ap['categorie'] ) ?>, <?= json_encode( $ap['cle'] ) ?>, this)">Révoquer</a>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>

				<?php if ( ! empty( $est_admin ) ) : ?>
					<button class="btn btn-ghost btn-sm" style="margin-top:8px" onclick="mApprendre(this)">Chercher ce qu'il y a à apprendre</button>
				<?php endif; ?>
			</div>
		</div>
		<?php endif; ?>

		<?php
		/*
		 * CETTE CARTE PORTE UNE LONGUE LISTE : elle prend la ligne entière.
		 *
		 * La ranger à côté des deux autres ne suffisait pas — vingt experts
		 * dans une carte de 400 px restent une colonne de vingt lignes. On
		 * avait rangé les cartes, pas leur contenu. .card-pleine lui rend la
		 * largeur, .stat-list y range les lignes en colonnes : quatre rangées
		 * sur un grand écran au lieu de vingt, et une seule colonne sur un
		 * téléphone, sans qu'aucun point de rupture ait à être écrit.
		 */
		?>
		<div class="card card-flush card-pleine">
			<div class="card-head"><h2>🎓 Ce que Maestro sait</h2></div>
			<div class="card-body" style="font-size:12px">
				<div class="stat-list">
					<div class="stat-row"><span>Producteurs de faits</span><strong><?= (int) $inventaire['nb_producteurs'] ?></strong></div>
					<div class="stat-row"><span>Règles métier</span><strong><?= (int) $inventaire['nb_regles'] ?></strong></div>
					<div class="stat-row"><span>Situations reconnues</span><strong><?= (int) $inventaire['nb_patterns'] ?></strong></div>
					<div class="stat-row"><span>Plans d'action</span><strong><?= (int) $inventaire['nb_playbooks'] ?></strong></div>
				</div>
				<?php if ( ! empty( $inventaire['etats'] ) ) : ?>
					<div class="stat-list">
						<div class="stat-titre">
							Experts en service —
							<?= (int) ( $inventaire['compte_etats']['actif'] ?? 0 ) ?> actifs ·
							<?= (int) ( $inventaire['compte_etats']['degrade'] ?? 0 ) ?> dégradés ·
							<?= (int) ( $inventaire['compte_etats']['muet'] ?? 0 ) ?> muets
						</div>
						<?php
						/* Un Expert muet n'est pas un Expert sans rien à dire : c'est
						   un Expert qui ne peut pas conclure. Nommer ce qui lui manque
						   est ce qui transforme un silence en diagnostic. */
						$fkcPuces = array( 'actif' => '🟢', 'degrade' => '🟠', 'muet' => '⚪' );
						foreach ( $inventaire['etats'] as $fkcCode => $fkcEx ) : ?>
							<div class="stat-row" title="<?= e( $fkcEx['libelle'] ) ?>">
								<span><?= $fkcPuces[ $fkcEx['etat'] ] ?? '⚪' ?> <?= e( $fkcEx['libelle'] ) ?></span>
								<span class="muted" style="font-size:11px">
									<?php if ( 'actif' === $fkcEx['etat'] ) : ?>
										<?= e( $fkcEx['type'] ) ?>
									<?php elseif ( $fkcEx['manquants'] ) : ?>
										manque <?= e( implode( ', ', array_slice( (array) $fkcEx['manquants'], 0, 2 ) ) ) ?>
									<?php else : ?>
										aucune connaissance déclarée
									<?php endif; ?>
								</span>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="muted" style="margin-top:6px;font-size:11px">
						Apprentissage des habitudes : <?= 'utilisateur' === ( $inventaire['portee'] ?? '' ) ? 'par utilisateur' : 'au niveau société' ?>
					</div>
				<?php elseif ( ! empty( $inventaire['experts'] ) ) : ?>
					<hr style="border:0;border-top:1px solid var(--line);margin:8px 0">
					<?php foreach ( $inventaire['experts'] as $ex ) : ?>
						<div class="muted">🧩 <?= e( $ex['libelle'] ) ?></div>
					<?php endforeach; ?>
				<?php endif; ?>
				<?php if ( ! empty( $est_admin ) && ! empty( $inventaire['incidents'] ) ) : ?>
					<hr style="border:0;border-top:1px solid var(--line);margin:8px 0">
					<div class="muted" style="font-size:11px">
						<strong>Déclarations refusées</strong>
						<?php foreach ( array_slice( (array) $inventaire['incidents'], -3 ) as $fkcInc ) : ?>
							<div><?= e( $fkcInc ) ?></div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
</div>

<script>
var M_CSRF = <?= json_encode( FKC_Csrf::token() ) ?>;

/*
 * RENDU SÛR (1.837.0). Les réponses de Maestro portent des NOMS saisis par
 * les utilisateurs — clients, articles, libellés d'écriture. Les injecter en
 * innerHTML exécutait tout balisage qu'un nom contenait (« <img onerror=…> »
 * saisi comme raison sociale d'un client s'exécutait dans la session du
 * dirigeant qui validait une relance). Tout texte venu du serveur passe
 * désormais par textContent.
 */
function mTexte(zone, texte, taille){
	zone.textContent = '';
	var s = document.createElement('span');
	s.className = 'muted'; s.style.fontSize = (taille || 12) + 'px';
	s.textContent = texte || '';
	zone.appendChild(s);
}
function mLignes(zone, lignes){
	zone.textContent = '';
	(lignes || []).forEach(function(l, i){
		if (i) { zone.appendChild(document.createElement('br')); }
		zone.appendChild(document.createTextNode(l));
	});
}

/*
 * LE FIL (1.845.0). Chaque réponse remplaçait la précédente : on perdait ce
 * qui venait d'être dit au moment même où l'on demandait « pourquoi ? ». Les
 * échanges s'empilent désormais, et une réponse arrivée en retard (question
 * suivante déjà posée) ne peut plus écraser la plus récente.
 */
var M_SEQ = 0;
function mBulle(role){
	var fil = document.getElementById('mfil');
	fil.style.display = 'flex';
	var b = document.createElement('div');
	b.style.cssText = 'padding:10px 12px;border-radius:8px;max-width:92%;font-size:14px;white-space:pre-line;'
		+ ('moi' === role ? 'align-self:flex-end;background:var(--accent,#39c);color:#fff'
			: 'align-self:flex-start;border-left:3px solid var(--accent,#39c);background:var(--bg2,rgba(0,0,0,.03))');
	fil.appendChild(b);
	fil.scrollTop = fil.scrollHeight;
	return b;
}
function mAsk(texte){
	var champ = document.getElementById('mq');
	var q = (texte || champ.value).trim();
	if(!q) return;
	champ.value = '';
	mBulle('moi').textContent = q;
	var rep = mBulle('maestro');
	rep.textContent = '…';
	document.getElementById('mrep-suites').textContent = '';
	var seq = ++M_SEQ;
	var f = new FormData(); f.append('_csrf', M_CSRF); f.append('q', q); f.append('canal', 'cockpit');
	fetch(<?= json_encode( url( 'maestro/ask' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();})
	.then(function(d){
		rep.textContent = '';
		var t = document.createElement('div'); t.textContent = d.texte || d.message || ''; rep.appendChild(t);
		var meta = '';
		if (false === d.comprise) {
			meta = 'Je n\'ai pas deviné : voici ce que je sais faire.';
			if (seq === M_SEQ) { mSuites(d.propositions || []); }
		} else if ('social' !== d.intention) {
			var src = (d.sources||[]).map(function(s){return s.libelle;}).join(' · ');
			// Ce que Maestro a compris, dit quand ce n'était pas évident (1.846.0).
			meta = (d.compris_comme ? 'J\'ai compris : ' + d.compris_comme + '. ' : '') + 'Confiance ' + ((d.confiance&&d.confiance.pct)||0) + ' % (' + ((d.confiance&&d.confiance.label)||'') + ')'
				+ (d.periode_comprise ? ' · ' + d.periode_comprise : (d.periode ? ' · ' + d.periode : ''))
				+ (d.periode_heritee ? ' (période reprise de votre question précédente)' : '')
				+ (src ? ' · Sources : ' + src : '');
			if (seq === M_SEQ) { mSuites(d.suites || []); }
		} else if (seq === M_SEQ) { mSuites(d.suites || []); }
		if (meta) {
			var m = document.createElement('div'); m.className = 'muted'; m.style.cssText = 'font-size:11px;margin-top:6px';
			m.textContent = meta; rep.appendChild(m);
		}
		// Un dossier d'action préparé se valide ici même, sans changer d'écran.
		if (d.dossier_id) {
			var c = document.createElement('div'); c.setAttribute('data-dossier', d.dossier_id); c.style.marginTop = '8px';
			var bt = document.createElement('button'); bt.className = 'btn btn-primary btn-sm'; bt.textContent = 'Valider et exécuter';
			bt.onclick = function(){ mExec(d.dossier_id, !!d.double_confirmation, bt); };
			var z = document.createElement('div'); z.className = 'mexec-rep'; z.style.display = 'none';
			c.appendChild(bt); c.appendChild(z); rep.appendChild(c);
		}
		document.getElementById('mfil').scrollTop = document.getElementById('mfil').scrollHeight;
	})
	.catch(function(){ rep.textContent = 'Maestro est momentanément indisponible.'; });
}

function mNouveauSujet(){
	var f = new FormData(); f.append('_csrf', M_CSRF); f.append('canal', 'cockpit');
	fetch(<?= json_encode( url( 'maestro/nouveau-fil' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();})
	.then(function(){
		var sep = mBulle('maestro'); sep.className = 'muted'; sep.style.fontSize = '12px';
		sep.textContent = '— Nouveau sujet : je repars de zéro. —';
		document.getElementById('mrep-suites').textContent = '';
	});
}

function mSuites(liste){
	var z = document.getElementById('mrep-suites');
	z.textContent = '';
	(liste || []).forEach(function(s){
		var b = document.createElement('button');
		b.className = 'btn btn-ghost btn-sm';
		b.textContent = s;
		b.onclick = function(){ mAsk(s); };
		z.appendChild(b);
	});
}
document.getElementById('mq').addEventListener('keydown', function(e){ if(13===e.keyCode){ e.preventDefault(); mAsk(); } });

function mFeedback(id, verdict, btn){
	var zone = btn.parentNode;
	Array.prototype.forEach.call(zone.querySelectorAll('button'), function(b){ b.disabled = true; });
	var f = new FormData();
	f.append('_csrf', M_CSRF); f.append('reco_id', id); f.append('verdict', verdict);
	fetch(<?= json_encode( url( 'maestro/feedback' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();})
	.then(function(d){
		mTexte(zone, d.message || 'Retour enregistré.');
	})
	.catch(function(){ Array.prototype.forEach.call(zone.querySelectorAll('button'), function(b){ b.disabled = false; }); });
}

function mPreparer(plan, btn){
	btn.disabled = true;
	var f = new FormData(); f.append('_csrf', M_CSRF); f.append('plan', plan);
	fetch(<?= json_encode( url( 'maestro/action/preparer' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){ alert(d.message || ''); location.reload(); })
	.catch(function(){ btn.disabled = false; });
}

function mExec(id, doubleConf, btn){
	var carte = btn.closest('[data-dossier]');
	var zone = carte.querySelector('.mexec-rep');
	var f = new FormData(); f.append('_csrf', M_CSRF); f.append('dossier_id', id);
	if (doubleConf) {
		if (!confirm("Cette action engage votre responsabilité ou n'est pas réversible. Confirmez-vous ?")) { return; }
		f.append('confirme', '1');
	}
	btn.disabled = true; btn.textContent = '…';
	fetch(<?= json_encode( url( 'maestro/action/executer' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		if (d.confirmation_requise) {
			btn.disabled = false; btn.textContent = 'Valider et exécuter';
			if (confirm(d.message)) {
				f.append('confirme', '1');
				return fetch(<?= json_encode( url( 'maestro/action/executer' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
					.then(function(r2){return r2.json();}).then(function(d2){ mExecRendu(zone, d2, btn); });
			}
			return;
		}
		mExecRendu(zone, d, btn);
	})
	.catch(function(){ btn.disabled = false; btn.textContent = 'Valider et exécuter'; });
}

function mExecRendu(zone, d, btn){
	zone.style.display = 'block';
	zone.textContent = '';
	var t = document.createElement('strong'); t.textContent = d.message || ''; zone.appendChild(t);
	(d.resultats || []).forEach(function(x){
		var ic = 'fait' === x.statut ? '✅' : ('perime' === x.statut ? '⏭' : ('echec' === x.statut ? '⚠' : '·'));
		zone.appendChild(document.createElement('br'));
		zone.appendChild(document.createTextNode(ic + ' ' + (x.libelle || '') + ' — ' + (x.message || '')));
	});
	if (btn) { btn.remove(); }
}

function mAbandon(id, btn){
	var carte = btn.closest('[data-dossier]');
	var f = new FormData(); f.append('_csrf', M_CSRF); f.append('dossier_id', id);
	fetch(<?= json_encode( url( 'maestro/action/abandonner' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		mTexte(carte, d.message || '');
	}).catch(function(){});
}

function mSim(){
	var p = document.getElementById('sim-levier').value;
	var v = parseFloat(document.getElementById('sim-pct').value || '0');
	if (!p || !v) { return; }
	var box = document.getElementById('sim-rep');
	box.style.display = 'block';
	document.getElementById('sim-texte').textContent = '…';
	document.getElementById('sim-meta').textContent = '';
	var f = new FormData();
	f.append('_csrf', M_CSRF);
	f.append('leviers[' + p + ']', v);
	fetch(<?= json_encode( url( 'maestro/simuler' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		document.getElementById('sim-texte').textContent = (d.details || []).join('\n') || d.message || '';
		document.getElementById('sim-meta').textContent =
			(d.message || '') + ' · confiance du maillon le plus faible : '
			+ ((d.confiance && d.confiance.pct) || 0) + ' %';
	})
	.catch(function(){ document.getElementById('sim-texte').textContent = 'Simulation indisponible.'; });
}

function mOpp(cle, statut, btn){
	var zone = btn.parentNode;
	Array.prototype.forEach.call(zone.querySelectorAll('button'), function(b){ b.disabled = true; });
	var f = new FormData();
	f.append('_csrf', M_CSRF); f.append('cle', cle); f.append('statut', statut);
	if ('saisie' === statut) {
		var g = prompt("Gain réellement obtenu, si vous le connaissez (laisser vide sinon) :", '');
		if (null !== g && '' !== g.trim()) { f.append('gain_reel', g.trim()); }
	}
	fetch(<?= json_encode( url( 'maestro/opportunites/conclure' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		mTexte(zone, d.message || '');
	}).catch(function(){ Array.prototype.forEach.call(zone.querySelectorAll('button'), function(b){ b.disabled = false; }); });
}

function mPourquoi(lien, predicat){
	var zone = lien.nextElementSibling;
	zone.style.display = 'block';
	zone.textContent = '…';
	fetch(<?= json_encode( url( 'maestro/pourquoi' ) ) ?> + '?predicat=' + encodeURIComponent(predicat),
		{headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		if (d.explique && d.chaine && d.chaine.length) {
			mLignes(zone, d.chaine.map(function(c){ return '· ' + c; }));
		} else if (d.inexplique) {
			zone.textContent = "Aucune des causes que je connais n'explique cette variation. C'est en soi une raison de regarder.";
		} else {
			zone.textContent = "Je n'ai pas de relation causale déclarée pour cet indicateur.";
		}
	})
	.catch(function(){ zone.textContent = 'Analyse indisponible.'; });
	return false;
}

function mAppr(id, accepte, btn){
	var zone = btn.parentNode;
	Array.prototype.forEach.call(zone.querySelectorAll('button'), function(b){ b.disabled = true; });
	var f = new FormData();
	f.append('_csrf', M_CSRF); f.append('id', id); f.append('accepte', accepte ? '1' : '0');
	fetch(<?= json_encode( url( 'maestro/apprentissages/valider' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		mTexte(zone, d.message || '', 11);
	}).catch(function(){ Array.prototype.forEach.call(zone.querySelectorAll('button'), function(b){ b.disabled = false; }); });
}

function mRevoquer(cat, cle, lien){
	var f = new FormData();
	f.append('_csrf', M_CSRF); f.append('categorie', cat); f.append('cle', cle);
	fetch(<?= json_encode( url( 'maestro/revoquer' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		var sp = document.createElement('span'); sp.className = 'muted'; sp.style.fontSize = '11px'; sp.textContent = d.message || '';
		lien.replaceWith(sp);
	}).catch(function(){});
	return false;
}

function mApprendre(btn){
	btn.disabled = true; var old = btn.textContent; btn.textContent = '…';
	var f = new FormData(); f.append('_csrf', M_CSRF);
	fetch(<?= json_encode( url( 'maestro/apprendre' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){ alert(d.message || ''); location.reload(); })
	.catch(function(){ btn.disabled = false; btn.textContent = old; });
}

function mObserver(form){
	var f = new FormData(form);
	fetch(form.action, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){ alert(d.message||''); location.reload(); })
	.catch(function(){ alert('Observation impossible pour le moment.'); });
	return false;
}
</script>
