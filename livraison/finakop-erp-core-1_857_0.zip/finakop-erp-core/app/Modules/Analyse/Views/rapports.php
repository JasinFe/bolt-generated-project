<?php
/**
 * CENTRE « RAPPORTS » (1.834.0).
 *
 * @var array $groupes     FKC_AnaRapports::parGroupe()
 * @var array $enregistres rapports enregistrés (Enterprise)
 * @var bool  $entreprise  analyse.rapports ouvert
 * @var array $autres      autres éditions de l'ERP
 * @var array $periode
 * @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$per = FKC_AnaRapports::periodesRelatives();
$cat = FKC_AnaRapports::catalogue();
$qs = function ( $code ) use ( $periode ) { return http_build_query( array( 'code' => $code, 'du' => $periode['du'], 'au' => $periode['au'] ) ); };
?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'rapports' ) ); ?>
<style>
.rp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,280px),1fr));gap:12px}
.rp-card{border:1px solid var(--line);border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:8px;background:var(--panel)}
.rp-card h3{margin:0;font-size:15px}
.rp-card p{margin:0;color:var(--muted);font-size:12.5px;flex:1}
.rp-card .rp-act{display:flex;gap:6px;flex-wrap:wrap}
.rp-card.is-lock{opacity:.6}
.rp-lock{font-size:12px;color:var(--orange);font-weight:600}
.rp-autres{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,240px),1fr));gap:8px}
.rp-autres a{display:block;padding:10px 12px;border:1px solid var(--line);border-radius:10px;text-decoration:none;color:inherit}
.rp-autres a:hover{border-color:var(--orange)}
.rp-autres small{display:block;color:var(--muted);font-size:12px;margin-top:2px}
.rp-saved td{vertical-align:middle}
.rp-saved .rp-act{display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap}
@media(max-width:640px){.rp-hide-s{display:none}}
</style>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<?php FKC_View::partial( 'analyse::_periode', array( 'periode' => $periode + array( 'sans_cmp' => true ) ) ); ?>

<div class="card" id="rpEnregistres"><div class="card-head"><h2>⭐ Mes rapports enregistrés <span class="couche couche-perf">Enterprise</span></h2></div><div class="card-body">
<?php if ( ! $entreprise ) : ?>
	<p class="muted" style="margin:0">🔒 Enregistrez vos rapports favoris — avec leurs options et une période qui se recalcule seule (« exercice en cours », « mois dernier »…) — pour les rouvrir en un clic. Fonction de l'édition <?= e( FKC_Modules::featureMinLabel( 'analyse.rapports' ) ) ?>.</p>
<?php elseif ( ! $enregistres ) : ?>
	<p class="muted" style="margin:0">Aucun rapport enregistré. Ouvrez un rapport ci-dessous, réglez-le, puis choisissez « ⭐ Enregistrer ce rapport ».</p>
<?php else : ?>
	<div class="table-wrap"><table class="table rp-saved">
		<thead><tr><th>Nom</th><th class="rp-hide-s">Rapport</th><th class="rp-hide-s">Période</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $enregistres as $s ) : $ouvert = FKC_AnaRapports::accessible( $s['code'] ); ?>
			<tr>
				<td><strong><?= e( $s['nom'] ) ?></strong><?php if ( $s['auteur'] ) : ?><br><span class="muted" style="font-size:11.5px">par <?= e( $s['auteur'] ) ?></span><?php endif; ?></td>
				<td class="rp-hide-s"><?= e( $cat[ $s['code'] ][0] ?? $s['code'] ) ?></td>
				<td class="rp-hide-s"><?= e( $per[ $s['periode'] ] ?? $s['periode'] ) ?><?= 'fixe' === $s['periode'] ? ' (' . e( date( 'd/m/Y', strtotime( $s['du'] ) ) . ' → ' . date( 'd/m/Y', strtotime( $s['au'] ) ) ) . ')' : '' ?></td>
				<td><div class="rp-act">
					<?php if ( $ouvert ) : ?>
					<a class="btn btn-primary btn-sm" href="<?= e( url( 'analyse/rapports/' . (int) $s['id'] . '/ouvrir' ) ) ?>">Ouvrir</a>
					<a class="btn btn-ghost btn-sm" href="<?= e( url( str_replace( 'analyse/rapports/voir?', 'analyse/rapports/export?', FKC_AnaRapports::lien( $s ) ) ) ) ?>">CSV</a>
					<?php else : ?><span class="rp-lock">🔒 non inclus</span><?php endif; ?>
					<form method="post" action="<?= e( url( 'analyse/rapports/' . (int) $s['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ce rapport enregistré ?')" style="display:inline;margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" title="Supprimer" aria-label="Supprimer">✕</button></form>
				</div></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
<?php endif; ?>
</div></div>

<?php foreach ( $groupes as $g => $liste ) : ?>
<div class="card"><div class="card-head"><h2><?= e( $g ) ?></h2></div><div class="card-body">
	<div class="rp-grid">
	<?php foreach ( $liste as $code => $x ) : list( $titre, $desc, $ouvert, $feat ) = $x; ?>
		<div class="rp-card<?= $ouvert ? '' : ' is-lock' ?>" data-rapport="<?= e( $code ) ?>">
			<h3><?= e( $titre ) ?></h3>
			<p><?= e( $desc ) ?></p>
			<?php if ( $ouvert ) : ?>
			<div class="rp-act">
				<a class="btn btn-primary btn-sm" href="<?= e( url( 'analyse/rapports/voir?' . $qs( $code ) ) ) ?>">Afficher</a>
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analyse/rapports/export?' . $qs( $code ) ) ) ?>">⬇ CSV</a>
			</div>
			<?php else : ?>
			<span class="rp-lock">🔒 Édition <?= e( FKC_Modules::featureMinLabel( $feat ) ) ?></span>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
	</div>
</div></div>
<?php endforeach; ?>

<?php if ( $autres ) : ?>
<div class="card"><div class="card-head"><h2>Autres éditions</h2></div><div class="card-body">
	<div class="rp-autres">
	<?php foreach ( $autres as $a ) : ?>
		<a href="<?= e( url( $a[2] ) ) ?>"><strong><?= e( $a[0] ) ?></strong><small><?= e( $a[1] ) ?></small></a>
	<?php endforeach; ?>
	</div>
</div></div>
<?php endif; ?>
