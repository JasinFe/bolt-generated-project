<?php /** @var array|null $d @var array $periode */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'commerciale' ) ); ?>
<?php FKC_View::partial( 'analyse::_periode', array( 'periode' => $periode ) ); ?>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucune facture disponible pour l'analyse commerciale.</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card an-tile an-tile-blue"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">🧾</span><span class="l">Chiffre d'affaires</span></span><span class="v"><?= e( fkc_money( $d['ca'] ) ) ?></span><span class="help" style="font-size:11px"><?= 'factures' === ( $d['source'] ?? '' ) ? 'd\'après les factures' : 'comptes 70 · dont facturé ' . e( fkc_money( $d['ca_facture'] ?? 0 ) ) ?></span><?= FKC_Chart::sparkline( $d['ca_mois'], array('color'=>'var(--blue)') ) ?></div></div>
	<div class="card an-tile an-tile-orange"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">📄</span><span class="l">Factures</span></span><span class="v"><?= (int) $d['nb_factures'] ?></span><span class="help" style="font-size:11px">hors brouillons, annulées et avoirs</span></div></div>
	<div class="card an-tile an-tile-violet"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">🛒</span><span class="l">Panier moyen</span></span><span class="v"><?= e( fkc_money( $d['panier'] ) ) ?></span></div></div>
</div>
<div class="an-grid-2">
	<div class="card"><div class="card-head"><h2>Évolution du CA <span class="couche couche-op">Opérationnel</span></h2></div><div class="card-body"><?= FKC_Chart::line( $d['ca_mois'], array('color'=>'var(--blue)') ) ?></div></div>
	<?php if ( $d['top_clients'] ) : ?>
	<div class="card"><div class="card-head"><h2>Top clients</h2></div><div class="card-body"><?php $tc=array(); foreach($d['top_clients'] as $r){$tc[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $tc, array('color'=>'var(--orange)') ); ?></div></div>
	<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">🥧</span>Répartition du CA par client</span></h2></div><div class="card-body"><?php $td=array(); foreach($d['top_clients'] as $r){$td[$r['nom']]=(float)$r['v'];} echo FKC_Chart::donut( $td, array('width'=>460,'height'=>240) ); ?></div></div>
	<?php endif; ?>
</div>
