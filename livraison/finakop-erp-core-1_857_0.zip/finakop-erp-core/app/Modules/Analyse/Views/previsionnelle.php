<?php /** @var array $d */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$hist = $d['historique'] ?? array(); $proj = $d['projection'] ?? array();
$combo = $hist; foreach ( $proj as $m => $v ) { $combo[ $m ] = $v; } ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'previsionnelle' ) ); ?>
<div class="bar"><span class="muted">Couche <span class="couche couche-pred">Prédictif</span> — projection par régression linéaire sur les <?= (int) ( $d['mois_base'] ?? 0 ) ?> derniers mois complets de chiffre d'affaires (comptable) — le mois en cours, incomplet, n'entre pas dans le calcul.</span></div>
<?php if ( count( $combo ) < 3 ) : ?><div class="alert alert-warn">Historique insuffisant pour une projection fiable.</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card"><div class="card-body an-kpi"><span class="l">Tendance mensuelle</span><span class="v" style="color:<?= ($d['tendance']??0)>=0?'var(--ok)':'var(--danger)' ?>"><?= ($d['tendance']??0)>=0?'▲':'▼' ?> <?= e( fkc_money( abs( $d['tendance'] ?? 0 ) ) ) ?></span><span class="help">par mois</span></div></div>
	<?php $sp=array_sum($proj); ?>
	<div class="card"><div class="card-body an-kpi"><span class="l">Projection (<?= count($proj) ?> mois)</span><span class="v"><?= e( fkc_money( $sp ) ) ?></span></div></div>
</div>
<div class="card"><div class="card-head"><h2>Historique & projection</h2></div><div class="card-body">
	<?= FKC_Chart::line( $combo, array('color'=>'#8B5CF6') ) ?>
	<p class="help">Les <?= count($proj) ?> derniers points (<?= e( implode( ', ', array_keys( $proj ) ) ) ?>) sont une estimation.</p>
</div></div>
