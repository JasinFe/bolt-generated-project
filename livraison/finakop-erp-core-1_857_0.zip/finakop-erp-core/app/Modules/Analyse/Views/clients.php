<?php /** @var array|null $d */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'clients' ) ); ?>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucun client disponible.</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card"><div class="card-body an-kpi"><span class="l">Clients</span><span class="v"><?= (int) $d['nb'] ?></span></div></div>
</div>
<div class="an-grid-2">
	<?php if ( $d['top'] ) : ?>
	<div class="card"><div class="card-head"><h2>Top clients (CA cumulé)</h2></div><div class="card-body"><?php $tc=array(); foreach($d['top'] as $r){$tc[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $tc, array('color'=>'var(--blue)') ); ?></div></div>
	<?php endif; ?>
	<?php if ( $d['types'] ) : ?>
	<div class="card"><div class="card-head"><h2>Répartition par type</h2></div><div class="card-body"><?php $tt=array(); foreach($d['types'] as $r){$tt[$r['nom']]=(float)$r['v'];} echo FKC_Chart::donut( $tt ); ?></div></div>
	<?php endif; ?>
</div>
