<?php
/**
 * ANALYSE BUDGÉTAIRE (revue 1.832.0).
 *
 * Deux comparaisons, chacune sur son périmètre :
 *  - le budget MENSUEL de l'entreprise (Analytique › Budget mensuel), cumulé à fin du mois en cours ;
 *  - les budgets PAR DIVISION, face au réalisé de ces seules divisions — le reste est affiché à part.
 *
 * @var array|null $d
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcBloc = function ( $titre, $sous, $b, $lien ) {
	$tp = $b['bp'] > 0 ? round( $b['rp'] / $b['bp'] * 100 ) : null;
	$tc = $b['bc'] > 0 ? round( $b['rc'] / $b['bc'] * 100 ) : null;
	ob_start(); ?>
	<div class="card"><div class="card-head" style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center"><h2><?= e( $titre ) ?> <span class="couche couche-perf">Performance</span></h2><a class="btn btn-ghost btn-sm" href="<?= e( url( $lien ) ) ?>">Détail →</a></div><div class="card-body">
		<p class="help" style="margin-top:0"><?= $sous ?></p>
		<div class="an-grid-2">
			<div style="text-align:center">
				<strong>Produits</strong>
				<?php if ( $b['bp'] <= 0 && abs( $b['rp'] ) < 1 ) : ?><p class="muted" style="margin:40px 0">Aucun produit budgété ni réalisé.</p><?php else : ?>
				<?= FKC_Chart::gauge( $b['rp'], $b['bp'] ?: 1 ) ?>
				<p class="help"><?= e( fkc_money( $b['rp'] ) ) ?> réalisés / <?= e( fkc_money( $b['bp'] ) ) ?> budgétés<?= null !== $tp ? ' · ' . (int) $tp . ' %' : '' ?></p>
				<?php endif; ?>
			</div>
			<div style="text-align:center">
				<strong>Charges</strong>
				<?php if ( $b['bc'] <= 0 && abs( $b['rc'] ) < 1 ) : ?><p class="muted" style="margin:40px 0">Aucune charge budgétée ni réalisée.</p><?php else : ?>
				<?= FKC_Chart::gauge( $b['rc'], $b['bc'] ?: 1 ) ?>
				<p class="help" style="<?= null !== $tc && $tc > 100 ? 'color:var(--danger)' : '' ?>"><?= e( fkc_money( $b['rc'] ) ) ?> réalisées / <?= e( fkc_money( $b['bc'] ) ) ?> budgétées<?= null !== $tc ? ' · ' . (int) $tc . ' %' : '' ?></p>
				<?php endif; ?>
			</div>
		</div>
	</div></div>
	<?php return ob_get_clean();
};
?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'budgetaire' ) ); ?>
<?php if ( ! $d || ( empty( $d['mensuel'] ) && empty( $d['divisions'] ) ) ) : ?>
	<div class="alert alert-warn">Aucun budget sur l'exercice en cours. Saisissez-en un dans <a href="<?= e( url( 'analytique/budget-mensuel' ) ) ?>">Analytique › Budget mensuel</a> (par nature et par mois) ou <a href="<?= e( url( 'analytique/budgets' ) ) ?>">Budgets par division</a>.</div>
	<?php return; ?>
<?php endif; ?>
<div class="bar"><span class="muted">Exercice <?= e( class_exists( 'FKC_Exercice' ) ? FKC_Exercice::libelle( $d['annee'] ) : $d['annee'] ) ?></span></div>

<?php if ( ! empty( $d['mensuel'] ) ) : $m = $d['mensuel']; ?>
	<?= $fkcBloc( 'Budget mensuel de l\'entreprise — cumul à fin ' . $m['jusqua'],
		'Budget saisi par nature et par mois, comparé au réalisé cumulé depuis le début de l\'exercice' . ( $m['alertes'] ? ' · <strong style="color:var(--danger)">' . (int) $m['alertes'] . ' nature(s) en alerte</strong>' : '' ) . '.',
		$m, 'analytique/budget-mensuel/suivi?section=0' ) ?>
<?php endif; ?>

<?php if ( ! empty( $d['divisions'] ) ) : $v = $d['divisions']; ?>
	<?= $fkcBloc( 'Budgets par division — exercice entier',
		(int) $v['nb'] . ' division(s) budgétée(s), comparée(s) à leur propre réalisé.'
		. ( abs( $v['hors_p'] ) + abs( $v['hors_c'] ) >= 1 ? ' Hors de ce périmètre (divisions sans budget et non imputé) : produits ' . e( fkc_money( $v['hors_p'] ) ) . ' F, charges ' . e( fkc_money( $v['hors_c'] ) ) . ' F.' : '' ),
		$v, 'analytique/controle-budgetaire' ) ?>
<?php endif; ?>
