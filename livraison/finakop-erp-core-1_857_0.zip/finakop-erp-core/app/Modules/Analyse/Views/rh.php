<?php /** @var array|null $d */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'rh' ) ); ?>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucune donnée RH/Paie.</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card"><div class="card-body an-kpi"><span class="l">Effectif actif</span><span class="v"><?= (int) $d['effectif'] ?></span><?php if ( ! empty( $d['sortis'] ) ) : ?><span class="help" style="font-size:11px"><?= (int) $d['sortis'] ?> salarié(s) sorti(s) non compté(s)</span><?php endif; ?></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l">Masse salariale</span><span class="v"><?= e( fkc_money( $d['masse'] ) ) ?></span><span class="help" style="font-size:11px"><?= ! empty( $d['masse_periode'] ) ? 'brut de la paie ' . e( $d['masse_periode'] ) : 'salaires de base des actifs (aucune paie calculée)' ?></span></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l">Coût moyen / pers.</span><span class="v"><?= e( fkc_money( $d['cout_moyen'] ) ) ?></span></div></div>
</div>
<?php if ( array_sum( $d['masse_mois'] ) > 0 ) : ?>
<div class="card"><div class="card-head"><h2>Masse salariale (12 mois)</h2></div><div class="card-body"><?= FKC_Chart::line( $d['masse_mois'], array('color'=>'var(--orange)') ) ?></div></div>
<?php endif; ?>
