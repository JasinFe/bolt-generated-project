<?php
/**
 * Rapprochement avec le compte de résultat (1.832.0) : le résultat affiché
 * doit être celui des états DGI sur la même période. On l'affiche au lieu de
 * le supposer.
 * @var array|null $rappro ['cr','analyse','ecart']
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
if ( empty( $rappro ) ) { return; }
$fkcOk = abs( (float) $rappro['ecart'] ) < 1;
?>
<p class="help an-rappro" style="margin:0 0 12px;<?= $fkcOk ? '' : 'color:var(--danger)' ?>">
	<?= $fkcOk ? '✓' : '⚠' ?> Rapproché du compte de résultat : résultat net <?= e( fkc_money( $rappro['cr'] ) ) ?> F CFA sur la période<?= $fkcOk ? ' — identique.' : ' — écart de ' . e( fkc_money( $rappro['ecart'] ) ) . ' F CFA avec cette analyse.' ?>
</p>
