<?php /** FinaKop Intelligence Engine. @var array $analyse */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'fie' ) );
$s = $analyse['synthese'] ?? array();
/* La santé de Maestro, la même partout (1.837.0) ; « — » tant que rien n'est mesuré. */
$sante = class_exists( 'FKC_Maestro' ) ? FKC_Maestro::sante()['valeur'] : ( isset( $s['sante'] ) ? (int) $s['sante'] : null );
$couleurSante = null === $sante ? 'var(--muted)' : ( $sante >= 80 ? 'var(--ok)' : ( $sante >= 55 ? '#c80' : '#c33' ) );
$grav = array( 'critique' => array( '🔴', '#c33' ), 'risque' => array( '🟠', '#e67e22' ), 'attention' => array( '🟡', '#c80' ), 'info' => array( '🔵', '#39c' ) );
?>
<div class="card-head" style="margin-bottom:12px"><h2>🧠 FinaKop Intelligence Engine</h2>
	<span class="muted">Raisonnement local sur faits déclarés — sans IA générative, sans donnée qui sort.</span>
</div>

<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body" style="text-align:center">
		<span class="muted">Score de santé</span>
		<div style="font-size:2.4em;font-weight:800;color:<?= $couleurSante ?>"><?= null === $sante ? '—' : (int) $sante ?><?php if ( null !== $sante ) : ?><span style="font-size:.4em;color:var(--muted)">/100</span><?php endif; ?></div>
		<?php if ( ! empty( $analyse['masquees'] ) ) : ?><span class="muted" style="font-size:11px">🔒 <?= (int) $analyse['masquees'] ?> décision(s) hors de vos domaines</span><?php endif; ?>
	</div></div>
	<div class="card"><div class="card-body"><span class="muted">Faits analysés</span><div style="font-size:1.6em;font-weight:800"><?= (int) ( $s['nb_faits'] ?? 0 ) ?></div><span class="muted" style="font-size:11px"><?= (int) ( $s['nb_derives'] ?? 0 ) ?> dérivé(s)</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Décisions</span><div style="font-size:1.6em;font-weight:800"><?= (int) ( $s['nb_decisions'] ?? 0 ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Répartition</span>
		<div style="font-size:12px;padding-top:6px">
			<?php foreach ( ( $s['par_gravite'] ?? array() ) as $g => $n ) : if ( $n <= 0 ) { continue; } ?>
				<span style="margin-right:8px"><?= $grav[ $g ][0] ?? '' ?> <?= (int) $n ?></span>
			<?php endforeach; ?>
		</div>
	</div></div>
</div>

<div class="form-grid" style="grid-template-columns:1fr minmax(280px,340px);gap:16px">
	<div class="card card-flush">
		<div class="card-head"><h2>🎯 Décisions & recommandations</h2></div>
		<div class="card-body">
			<?php if ( empty( $analyse['decisions'] ) ) : ?>
				<p class="muted" style="text-align:center;padding:28px">Aucune situation à signaler — l'entreprise est dans le vert sur les indicateurs suivis.</p>
			<?php else : foreach ( $analyse['decisions'] as $d ) : $g = $grav[ $d['gravite'] ] ?? array( '⚪', '#888' ); $e = $d['explication'] ?? array(); ?>
				<div class="card" style="margin-bottom:10px;border-left:4px solid <?= $g[1] ?>">
					<div class="card-body">
						<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
							<div>
								<strong><?= $g[0] ?> <?= e( $d['libelle'] ) ?></strong>
								<span class="muted" style="font-size:11px;text-transform:uppercase"> · <?= e( $d['domaine'] ) ?></span>
								<p style="margin:6px 0 0;font-size:14px"><?= e( $d['message'] ) ?></p>
								<?php if ( ! empty( $d['recommandation'] ) ) : ?><p style="margin:4px 0 0;font-size:13px;color:var(--ok)">→ <?= e( $d['recommandation'] ) ?></p><?php endif; ?>
							</div>
							<?php if ( ! empty( $d['playbook'] ) ) : ?>
								<button class="btn btn-primary btn-sm" onclick="playbook('<?= e( $d['cle'] ) ?>', this)">▶ Playbook</button>
							<?php endif; ?>
						</div>

						<?php if ( ! empty( $e['chaine'] ) ) : ?>
						<details style="margin-top:8px">
							<summary style="cursor:pointer;font-size:12px;color:var(--muted)">Pourquoi ? (raisonnement traçable)</summary>
							<ol style="margin:8px 0 0;padding-left:18px;font-size:12px;color:var(--muted)">
								<?php foreach ( $e['chaine'] as $c ) : ?><li><?= e( $c ) ?></li><?php endforeach; ?>
							</ol>
						</details>
						<?php endif; ?>

						<?php if ( ! empty( $d['etapes'] ) ) : ?>
						<details style="margin-top:6px">
							<summary style="cursor:pointer;font-size:12px;color:var(--accent,#39c)"><?= e( $d['playbook_libelle'] ?? 'Plan d\'action' ) ?> (<?= count( $d['etapes'] ) ?> étapes)</summary>
							<ol style="margin:8px 0 0;padding-left:18px;font-size:13px">
								<?php foreach ( $d['etapes'] as $et ) : ?><li style="margin-bottom:3px"><?= e( $et ) ?></li><?php endforeach; ?>
							</ol>
						</details>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; endif; ?>
		</div>
	</div>

	<div>
		<div class="card card-flush" style="margin-bottom:14px">
			<div class="card-head"><h2>📥 Faits déclarés</h2><span class="muted"><?= count( $analyse['faits'] ?? array() ) ?></span></div>
			<div class="card-body" style="max-height:280px;overflow-y:auto">
				<?php foreach ( ( $analyse['faits'] ?? array() ) as $f ) : ?>
					<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--line);font-size:12px">
						<span><span class="muted"><?= e( $f['source'] ) ?></span> · <?= e( $f['label'] ?: $f['predicat'] ) ?></span>
						<strong><?= e( $f['valeur_num'] !== null ? rtrim( rtrim( number_format( (float) $f['valeur_num'], 2, '.', ' ' ), '0' ), '.' ) : ( $f['valeur_txt'] ?? '' ) ) ?> <?= e( $f['unite'] ) ?></strong>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php if ( ! empty( $analyse['derives'] ) ) : ?>
		<div class="card card-flush">
			<div class="card-head"><h2>🧩 Faits dérivés</h2><span class="muted">calculés</span></div>
			<div class="card-body">
				<p class="muted" style="font-size:11px;margin-top:0">Produits par le moteur d'inférence et réutilisables par les autres modules.</p>
				<?php foreach ( $analyse['derives'] as $f ) : ?>
					<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--line);font-size:12px">
						<span><?= e( $f['label'] ?: $f['predicat'] ) ?></span>
						<strong><?= e( $f['valeur_num'] !== null ? rtrim( rtrim( number_format( (float) $f['valeur_num'], 2, '.', ' ' ), '0' ), '.' ) : ( $f['valeur_txt'] ?? '' ) ) ?> <?= e( $f['unite'] ) ?></strong>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>

<script>
/*
 * CORRECTIF 1.574.0 — le jeton anti-CSRF manquait.
 *
 * FKC_Router::dispatch() refuse toute route POST non publique sans jeton
 * valide : ce fetch recevait donc invariablement un 419, et le bouton
 * « Playbook » n'a jamais rien déclenché depuis l'écran FIE.
 */
function playbook(cle, btn){
	btn.disabled = true; var old = btn.textContent; btn.textContent = '…';
	var f = new FormData();
	f.append('_csrf', <?= json_encode( FKC_Csrf::token() ) ?>);
	f.append('decision', cle);
	fetch(<?= json_encode( url( 'analyse/fie/playbook' ) ) ?>, {method:'POST', body:f, headers:{'Accept':'application/json'}})
	.then(function(r){return r.json();}).then(function(d){
		btn.textContent = d.ok ? '✓ Enclenché' : '✗';
		alert(d.message || '');
		btn.disabled = false; if(!d.ok) btn.textContent = old;
	}).catch(function(){ btn.disabled=false; btn.textContent=old; });
}
</script>
