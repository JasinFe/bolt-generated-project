<?php /** @var array|null $d @var array $periode @var mixed $fromDW @var array|null $rappro */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'financiere' ) ); ?>
<?php FKC_View::partial( 'analyse::_periode', array( 'periode' => $periode ) ); ?>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucune écriture comptable disponible pour l'analyse financière.</div><?php return; endif; ?>

<?php FKC_View::partial( 'analyse::_rappro', array( 'rappro' => $rappro ?? null ) ); ?>
<div class="an-grid">
	<div class="card an-tile an-tile-ok"><div class="card-body an-kpi">
		<span class="an-kpi-top"><span class="ico">💰</span><span class="l">Produits</span></span>
		<span class="v"><?= e( fkc_money( $d['produits'] ) ) ?></span>
		<?= FKC_Chart::sparkline( $d['produits_mois'], array( 'color' => 'var(--ok)' ) ) ?>
	</div></div>
	<div class="card an-tile an-tile-danger"><div class="card-body an-kpi">
		<span class="an-kpi-top"><span class="ico">💸</span><span class="l">Charges</span></span>
		<span class="v"><?= e( fkc_money( $d['charges'] ) ) ?></span>
		<?= FKC_Chart::sparkline( $d['charges_mois'], array( 'color' => 'var(--danger)' ) ) ?>
	</div></div>
	<div class="card an-tile <?= $d['resultat'] >= 0 ? 'an-tile-ok' : 'an-tile-danger' ?>"><div class="card-body an-kpi">
		<span class="an-kpi-top"><span class="ico">📈</span><span class="l">Résultat net</span></span>
		<span class="v"><?= e( fkc_money( $d['resultat'] ) ) ?></span>
		<?= FKC_Chart::sparkline( $d['resultat_mois'], array( 'color' => $d['resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ) ) ?>
	</div></div>
	<?php if ( abs( (float) ( $d['hao'] ?? 0 ) ) >= 0.5 ) : ?>
	<div class="card an-tile"><div class="card-body an-kpi">
		<span class="an-kpi-top"><span class="ico">🧾</span><span class="l">Hors activités ordinaires (cl. 8)</span></span>
		<span class="v"><?= e( fkc_money( $d['hao'] ) ) ?></span>
		<span class="help">Activités ordinaires : <?= e( fkc_money( $d['resultat_ao'] ) ) ?></span>
	</div></div>
	<?php endif; ?>
	<div class="card an-tile an-tile-violet"><div class="card-body an-kpi">
		<span class="an-kpi-top"><span class="ico">📊</span><span class="l">Marge nette</span></span>
		<span class="v"><?= e( fkc_money( $d['marge'], 1 ) ) ?>%</span>
		<span class="help">Résultat net / Produits</span>
	</div></div>
</div>

<div class="an-grid-2">
	<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">📅</span>Évolution mensuelle — CA, Charges &amp; Résultat</span> <span class="couche couche-op">Opérationnel</span></h2></div><div class="card-body">
		<?= FKC_Chart::combo( array_keys( $d['produits_mois'] ), array(
			array( 'label' => 'CA',       'type' => 'bar',  'color' => 'var(--orange)', 'values' => array_values( $d['produits_mois'] ) ),
			array( 'label' => 'Charges',  'type' => 'bar',  'color' => 'var(--danger)', 'values' => array_values( $d['charges_mois'] ) ),
			array( 'label' => 'Résultat', 'type' => 'line', 'color' => 'var(--ok)',     'values' => array_values( $d['resultat_mois'] ) ),
		), array( 'height' => 250 ) ) ?>
	</div></div>
	<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">📈</span>Résultat net cumulé</span> <span class="couche couche-perf">Performance</span></h2></div><div class="card-body">
		<?php $cumul = array(); $acc = 0.0; foreach ( $d['resultat_mois'] as $k => $v ) { $acc += (float) $v; $cumul[ $k ] = $acc; } ?>
		<?= FKC_Chart::line( $cumul, array( 'color' => 'var(--ok)', 'height' => 250 ) ) ?>
	</div></div>
</div>

<?php if ( $d['top_charges'] ) : ?>
<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">🧾</span>Répartition des charges par nature</span> <span class="couche couche-perf">Performance</span></h2></div><div class="card-body">
	<?php $tc = array(); foreach ( $d['top_charges'] as $r ) { $tc[ $r['libelle'] ] = (float) $r['v']; } echo FKC_Chart::barsH( $tc, array( 'width' => 900, 'label_w' => 260 ) ); ?>
</div></div>
<?php endif; ?>
