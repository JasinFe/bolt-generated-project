<?php /** @var string $label @var string $min */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => '' ) ); ?>
<div class="card"><div class="card-body" style="text-align:center;padding:48px 20px">
	<div style="font-size:40px">🔒</div>
	<h2 style="margin:10px 0 4px"><?= e( $label ) ?></h2>
	<p class="muted">Cette analyse est disponible à partir de l'édition <strong><?= e( $min ) ?></strong>.</p>
	<div class="actions" style="justify-content:center"><a class="btn btn-primary" href="<?= e( url( 'licence' ) ) ?>">Voir les éditions</a></div>
</div></div>
