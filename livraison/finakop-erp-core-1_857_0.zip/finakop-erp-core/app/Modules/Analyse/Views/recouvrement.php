<?php /** @var array|null $d */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'recouvrement' ) ); ?>
<?php if ( ! $d ) : ?><div class="alert alert-warn">Aucune donnée de créances.</div><?php return; endif; ?>
<div class="an-grid">
	<div class="card"><div class="card-body an-kpi"><span class="l">Total créances</span><span class="v"><?= e( fkc_money( $d['creances'] ) ) ?></span></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l">En retard</span><span class="v" style="color:<?= $d['en_retard']>0?'var(--danger)':'var(--ok)' ?>"><?= e( fkc_money( $d['en_retard'] ) ) ?></span></div></div>
	<div class="card"><div class="card-body an-kpi"><span class="l">Dossiers ouverts</span><span class="v"><?= (int) $d['dossiers'] ?></span></div></div>
	<?php if ( isset( $d['dso'] ) ) : ?><div class="card"><div class="card-body an-kpi"><span class="l">DSO</span><span class="v"><?= (int) $d['dso'] ?> j</span></div></div><?php endif; ?>
</div>
<?php if ( 'approximation' === ( $d['source'] ?? '' ) ) : ?>
	<div class="alert alert-warn">Module Recouvrement indisponible : ces montants sont ceux <strong>facturés</strong>, les encaissements n'en sont pas déduits.</div>
<?php endif; ?>
<div class="an-grid-2">
	<div class="card"><div class="card-head"><h2>Balance âgée <span class="couche couche-op">Opérationnel</span></h2></div><div class="card-body"><?= FKC_Chart::bars( $d['aging'], array('color'=>'var(--orange)') ) ?></div></div>
	<div class="card"><div class="card-head"><h2>Répartition de l'encours</h2></div><div class="card-body"><?= FKC_Chart::donut( $d['aging'] ) ?></div></div>
</div>
