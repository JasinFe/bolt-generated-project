<?php /** @var array $kpis @var array $registre @var array $couches @var array $sens @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$cc = array( 'operationnel'=>'couche-op','performance'=>'couche-perf','predictif'=>'couche-pred' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'kpi' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Chaque entreprise définit ses propres indicateurs et leurs cibles.</span></div>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouveau KPI</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'analyse/kpi' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Libellé *</span><input name="libelle" required></label>
			<label class="fld"><span>Métrique</span><select name="metric"><?php foreach ( $registre as $k => $r ) : ?><option value="<?= e( $k ) ?>"><?= e( $r[0] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Cible</span><input type="number" step="any" name="cible" value="0"></label>
			<label class="fld"><span>Unité</span><input name="unite" placeholder="FCFA, %, j…"></label>
			<label class="fld"><span>Sens</span><select name="sens"><?php foreach ( $sens as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Couche d'analyse</span><select name="couche"><?php foreach ( $couches as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<div class="actions"><button class="btn btn-primary">Ajouter</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Mes KPI (<?= count( $kpis ) ?>)</h2></div>
		<table class="table"><thead><tr><th>KPI</th><th>Couche</th><th class="num">Actuel</th><th class="num">Cible</th><th class="num">%</th><th>Statut</th><th></th></tr></thead><tbody>
		<?php if ( ! $kpis ) : ?><tr><td colspan="7" class="empty">Aucun KPI défini.</td></tr>
		<?php else : foreach ( $kpis as $k ) : $ev = FKC_Kpi::evalue( $k ); ?><tr>
			<td><strong><?= e( $k['libelle'] ) ?></strong><br><span class="muted" style="font-size:.85em"><?= e( FKC_Metrics::metricLabel( $k['metric'] ) ) ?> · <?= e( $sens[ $k['sens'] ] ?? '' ) ?></span></td>
			<td><span class="couche <?= $cc[$k['couche']]??'' ?>"><?= e( $couches[ $k['couche'] ] ?? $k['couche'] ) ?></span></td>
			<td class="num"><?= e( fkc_money( $ev['actuel'], 1 ) ) ?> <?= e( $k['unite'] ) ?></td>
			<td class="num"><?= e( fkc_money( $ev['cible'], 1 ) ) ?> <?= e( $k['unite'] ) ?></td>
			<td class="num"><?= $ev['cible']?e( fkc_money( $ev['pct'], 0 ) ).'%':'—' ?></td>
			<td><span class="an-status an-<?= e( $ev['statut'] ) ?>"></span></td>
			<td class="right"><form method="post" action="<?= e( url( 'analyse/kpi/' . (int) $k['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
