<?php /** @var array|null $fin @var array|null $com @var array|null $rec @var array|null $inv @var array|null $rh @var array $kpis @var array $alertes @var array $periode @var array|null $cmp @var float $treso @var mixed $fromDW @var array|null $rappro */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analyse::_subnav', array( 'tab' => 'dashboard' ) ); ?>
<?php FKC_View::partial( 'analyse::_periode', array( 'periode' => $periode ) ); ?>
<?php
$delta = function ( $cur, $prev ) {
	if ( null === $prev || 0.0 === (float) $prev ) { return ''; }
	$d = round( ( $cur - $prev ) / abs( $prev ) * 100, 1 );
	return '<span class="anf-delta ' . ( $d >= 0 ? 'up' : 'down' ) . '">' . ( $d >= 0 ? '▲ +' : '▼ ' ) . $d . '%</span>';
};
$cFin = $cmp['fin'] ?? null; $cCom = $cmp['com'] ?? null;
?>
<div class="bar">
	<span class="muted">Transformer les données en décisions — couches <span class="couche couche-op">Opérationnel</span> <span class="couche couche-perf">Performance</span> <span class="couche couche-pred">Prédictif</span></span>
	<?php if ( $fromDW ) : ?><span class="help">Instantané du <?= e( $fromDW ) ?></span><?php endif; ?>
</div>

<?php FKC_View::partial( 'analyse::_rappro', array( 'rappro' => $rappro ?? null ) ); ?>
<?php if ( $alertes ) : ?>
	<?php foreach ( $alertes as $a ) : ?>
		<div class="an-alert n-<?= e( $a['niveau'] ) ?>"><span class="ico"><?= $a['niveau']==='danger'?'🔴':($a['niveau']==='warn'?'🟠':'🔵') ?></span>
			<span><strong><?= e( $a['libelle'] ) ?></strong> — <?= e( FKC_Metrics::metricLabel( $a['metric'] ) ) ?> = <?= e( fkc_money( $a['valeur'] ) ) ?> (seuil <?= e( FKC_Alerte::operateurs()[ $a['operateur'] ] ?? $a['operateur'] ) ?> <?= e( fkc_money( $a['seuil'] ) ) ?>)</span></div>
	<?php endforeach; ?>
<?php endif; ?>

<div class="an-grid">
	<div class="card an-tile an-tile-orange"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">💰</span><span class="l">Chiffre d'affaires</span></span><span class="v"><?= e( fkc_money( $com['ca'] ?? 0 ) ) ?> <small>F CFA</small></span><?php if ( 'factures' === ( $com['source'] ?? '' ) ) : ?><span class="help" style="font-size:11px">d'après les factures (aucune vente en comptabilité)</span><?php endif; ?><?php if ( $cCom ) { echo $delta( $com['ca'] ?? 0, $cCom['ca'] ?? 0 ); } elseif ( ! empty( $com['ca_mois'] ) ) { echo FKC_Chart::sparkline( $com['ca_mois'], array( 'color' => 'var(--orange)' ) ); } ?></div></div>
	<div class="card an-tile an-tile-danger"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">💸</span><span class="l">Charges totales</span></span><span class="v"><?= e( fkc_money( $fin['charges'] ?? 0 ) ) ?> <small>F CFA</small></span><?php if ( $cFin ) { echo $delta( $fin['charges'] ?? 0, $cFin['charges'] ?? 0 ); } elseif ( ! empty( $fin['charges_mois'] ) ) { echo FKC_Chart::sparkline( $fin['charges_mois'], array( 'color' => 'var(--danger)' ) ); } ?></div></div>
	<div class="card an-tile <?= ( $fin['resultat'] ?? 0 ) >= 0 ? 'an-tile-ok' : 'an-tile-danger' ?>"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">📈</span><span class="l">Résultat net</span></span><span class="v"><?= e( fkc_money( $fin['resultat'] ?? 0 ) ) ?> <small>F CFA</small></span><?php if ( abs( (float) ( $fin['hao'] ?? 0 ) ) >= 0.5 ) : ?><span class="help" style="font-size:11px">dont hors activités ordinaires <?= e( fkc_money( $fin['hao'] ) ) ?></span><?php endif; ?><?php if ( $cFin ) { echo $delta( $fin['resultat'] ?? 0, $cFin['resultat'] ?? 0 ); } elseif ( ! empty( $fin['resultat_mois'] ) ) { echo FKC_Chart::sparkline( $fin['resultat_mois'], array( 'color' => ( $fin['resultat'] ?? 0 ) >= 0 ? 'var(--ok)' : 'var(--danger)' ) ); } ?></div></div>
	<div class="card an-tile an-tile-blue"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">🏦</span><span class="l">Trésorerie</span></span><span class="v"><?= e( fkc_money( $treso ?? 0 ) ) ?> <small>F CFA</small></span></div></div>
	<div class="card an-tile an-tile-violet"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">📊</span><span class="l">Marge nette</span></span><span class="v"><?= e( fkc_money( $fin['marge'] ?? 0, 1 ) ) ?>%</span></div></div>
	<div class="card an-tile an-tile-blue"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">📄</span><span class="l">Factures client</span></span><span class="v"><?= (int) ( $com['nb_factures'] ?? 0 ) ?></span><span class="help" style="font-size:11px">hors brouillons et annulées</span></div></div>
	<div class="card an-tile <?= ( $rec['en_retard'] ?? 0 ) > 0 ? 'an-tile-danger' : 'an-tile-ok' ?>"><div class="card-body an-kpi"><span class="an-kpi-top"><span class="ico">⏳</span><span class="l">Impayés</span></span><span class="v"><?= e( fkc_money( $rec['en_retard'] ?? 0 ) ) ?> <small>F CFA</small></span></div></div>
</div>

<div class="an-grid-2">
	<?php if ( $fin ) : ?>
	<div class="card"><div class="card-head"><h2>Produits vs charges (période) <span class="couche couche-op">Opérationnel</span></h2></div><div class="card-body"><?= FKC_Chart::line( $fin['produits_mois'], array('color'=>'var(--ok)','series2'=>$fin['charges_mois']) ) ?><p class="help">Aire : produits · pointillés : charges.</p></div></div>
	<div class="card"><div class="card-head"><h2>Résultat mensuel <span class="couche couche-perf">Performance</span></h2></div><div class="card-body"><?= FKC_Chart::bars( $fin['resultat_mois'], array('color'=>'var(--blue)') ) ?></div></div>
	<?php endif; ?>
	<?php if ( $com && $com['top_clients'] ) : ?>
	<div class="card"><div class="card-head"><h2>Top clients (CA)</h2></div><div class="card-body"><?php $tc=array(); foreach($com['top_clients'] as $r){$tc[$r['nom']]=(float)$r['v'];} echo FKC_Chart::bars( $tc, array('color'=>'var(--orange)') ); ?></div></div>
	<?php endif; ?>
	<?php if ( $rec && array_sum($rec['aging'])>0 ) : ?>
	<div class="card"><div class="card-head"><h2>Balance âgée des créances</h2></div><div class="card-body"><?= FKC_Chart::donut( $rec['aging'] ) ?></div></div>
	<?php endif; ?>
	<?php if ( $com && ! empty( $com['top_clients'] ) ) : ?>
	<div class="card"><div class="card-head"><h2><span class="an-chart-head"><span class="ico">🥧</span>Répartition du CA par client</span></h2></div><div class="card-body"><?php $cd = array(); foreach ( $com['top_clients'] as $r ) { $cd[ $r['nom'] ] = (float) $r['v']; } echo FKC_Chart::donut( $cd, array( 'width' => 460, 'height' => 240 ) ); ?></div></div>
	<?php endif; ?>
</div>

<?php if ( $kpis ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Centre KPI</h2></div><table class="table">
	<thead><tr><th>KPI</th><th>Couche</th><th class="num">Actuel</th><th class="num">Cible</th><th class="num">%</th><th>Statut</th></tr></thead><tbody>
	<?php foreach ( $kpis as $k ) : $ev = FKC_Kpi::evalue( $k ); $cc=array('operationnel'=>'couche-op','performance'=>'couche-perf','predictif'=>'couche-pred'); ?>
		<tr><td><strong><?= e( $k['libelle'] ) ?></strong> <span class="muted"><?= e( FKC_Metrics::metricLabel( $k['metric'] ) ) ?></span></td>
		<td><span class="couche <?= $cc[$k['couche']]??'' ?>"><?= e( FKC_Kpi::couches()[ $k['couche'] ] ?? $k['couche'] ) ?></span></td>
		<td class="num"><?= e( fkc_money( $ev['actuel'], 1 ) ) ?> <?= e( $k['unite'] ) ?></td>
		<td class="num"><?= e( fkc_money( $ev['cible'], 1 ) ) ?> <?= e( $k['unite'] ) ?></td>
		<td class="num"><?= $ev['cible']?e( fkc_money( $ev['pct'], 0 ) ).'%':'—' ?></td>
		<td><span class="an-status an-<?= e( $ev['statut'] ) ?>"></span></td></tr>
	<?php endforeach; ?>
	</tbody>
</table></div>
<?php endif; ?>
