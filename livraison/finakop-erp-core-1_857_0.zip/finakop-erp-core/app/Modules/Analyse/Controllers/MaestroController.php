<?php
/**
 * FinaKop Maestro — contrôleur du cockpit et de l'API interne.
 *
 * Trois familles de points d'entrée, et la frontière entre elles est celle
 * des effets de bord :
 *
 *   • LECTURE (GET)  — cockpit, ask, priorités, explication. Aucun n'écrit
 *     dans les livres ; ils écrivent seulement dans la mémoire de Maestro
 *     (recommandations émises, audit), ce qui est le prix de la traçabilité.
 *   • RETOUR (POST)  — le feedback utilisateur. CSRF exigé.
 *   • VALIDATION (POST) — l'acceptation d'un apprentissage. CSRF + rôle.
 *
 * AUCUNE ACTION MÉTIER N'EST EXÉCUTÉE ICI. Le déclenchement d'un playbook
 * passe par 'cockpit/action' (FKC_Actions), qui porte déjà CSRF, contrôle de
 * rôle et journalisation. Dupliquer ce chemin, c'est dupliquer ses gardes —
 * donc créer l'occasion d'en oublier une.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_MaestroController {

	protected function json( $data, $code = 200 ) {
		if ( ! headers_sent() ) {
			http_response_code( (int) $code );
			header( 'Content-Type: application/json; charset=utf-8' );
		}
		echo json_encode( $data, JSON_UNESCAPED_UNICODE );
		exit;
	}

	/** Le prédicat (ou la clé de prévision) relève-t-il d'un domaine ouvert à l'utilisateur ? */
	protected function ouvert( $predicat ) {
		return ! class_exists( 'FKC_Maestro_Acces' ) || FKC_Maestro_Acces::predicat( (string) $predicat );
	}

	protected function refus() {
		return $this->json( array( 'ok' => false, 'interdit' => true,
			'message' => 'Cette information relève d\'un domaine auquel votre rôle ne donne pas accès.' ), 403 );
	}

	/* ═══════════════ Cockpit ═══════════════ */

	/** Écran principal : le cockpit Maestro. */
	public function index() {
		$ctx  = FKC_Maestro_Context::actuel();
		FKC_Maestro_Profile::enregistrer();

		$prio = FKC_Maestro::priorites( 6 );
		$analyse = FKC_Maestro::analyser();

		FKC_View::render( 'analyse::maestro', array(
			'title'     => 'FinaKop Maestro',
			'tab'       => 'maestro',
			'ctx'       => $ctx,
			'attentes'  => FKC_Maestro_Profile::attentes( $ctx['profil'] ),
			'priorites' => $prio,
			'synthese'  => (array) ( $analyse['synthese'] ?? array() ),
			/* Le bilan dirigeant ouvre l'écran : c'est la réponse à « comment
			   va mon entreprise ? », et tout ce qui suit n'est que le détail
			   sur lequel elle s'appuie. Il réutilise l'analyse déjà en cache,
			   donc il ne coûte rien de plus. */
			'bilan'     => FKC_Maestro::bilan(),
			'dna'       => FKC_Maestro_Dna::traits(),
			'timeline'  => FKC_Maestro_Memory::timeline( array( 'limite' => 8 ) ),
			'signaux'   => FKC_Maestro_Signals::visibles( 10 ),
			/* L'inventaire reçoit l'index des faits réellement collectés :
			   sans lui, l'état d'un Expert ne dirait que ce qu'il a déclaré,
			   pas ce qu'il peut effectivement conclure sur CE dossier. */
			'inventaire'=> FKC_Maestro_Experts::inventaire( (array) ( $analyse['index'] ?? array() ) ),
			'previsions'=> $this->previsionsResumees(),
			'anomalies' => $this->anomaliesRecentes(),
			'opportunites' => FKC_Maestro::opportunites( 3 ),
			'bilan_opp' => FKC_Maestro_Opportunity::bilan(),
			'propositions' => class_exists( 'FKC_Maestro_Feedback' ) ? FKC_Maestro_Feedback::enAttente( 6 ) : array(),
			'appris'    => class_exists( 'FKC_Maestro_Learning' ) ? FKC_Maestro_Learning::enVigueur() : array(),
			'est_admin' => FKC_Auth::isAdmin(),
			'sante_globale' => FKC_Maestro::sante(),
			'masquees' => (int) ( $analyse['masquees'] ?? 0 ),
			'leviers_sim' => class_exists( 'FKC_Maestro_Simulation' ) ? FKC_Maestro_Simulation::leviersDisponibles() : array(),
			'plans_action' => class_exists( 'FKC_Maestro_Action' ) ? FKC_Maestro_Action::plans() : array(),
			'actions_attente' => class_exists( 'FKC_Maestro_Action' ) ? FKC_Maestro_Action::enAttente( 5 ) : array(),
			'bilan_action' => class_exists( 'FKC_Maestro_Action' ) ? FKC_Maestro_Action::bilan() : array(),
			'llm'       => array( 'disponible' => FKC_Maestro_Llm::disponible(), 'libelle' => FKC_Maestro_Llm::libelle() ),
		) );
	}

	/**
	 * Résumé des prévisions du dossier, méthode retenue comprise.
	 *
	 * Borné à six : le cockpit doit rester lisible, et un dirigeant qui doit
	 * faire défiler une liste de prévisions n'en lit aucune.
	 */
	protected function previsionsResumees() {
		if ( ! class_exists( 'FKC_Maestro_Forecast' ) || ! class_exists( 'FKC_Forecast' ) ) { return array(); }
		$out = array();
		foreach ( array_keys( FKC_Forecast::previsions() ) as $cle ) {
			$p = FKC_Maestro_Forecast::evaluer( $cle );
			if ( ! $p || empty( $p['ok'] ) ) { continue; }
			$bt = (array) ( $p['backtest'] ?? array() );
			$out[] = array(
				'cle' => $cle, 'libelle' => $p['libelle'], 'unite' => $p['unite'],
				'methode' => $p['methode_libelle'], 'confiance' => (int) $p['confiance'],
				'tendance_pct' => $p['tendance_pct'], 'horizon' => $p['libelle_horizon'],
				'mase' => $bt['mase'] ?? null, 'plis' => (int) ( $bt['plis'] ?? 0 ),
				'bat_la_naive' => ! empty( $bt['bat_la_naive'] ),
				'fiabilite' => $p['fiabilite'],
				'borne' => $p['bornes'][0] ?? null,
			);
			if ( count( $out ) >= 6 ) { break; }
		}
		return $out;
	}

	/**
	 * Anomalies des sept derniers jours, hors conséquences attendues.
	 *
	 * Une conséquence attendue n'est pas cachée — elle est simplement à sa
	 * place, dans le flux d'information, pas dans la liste des surprises.
	 */
	protected function anomaliesRecentes( $limite = 8 ) {
		if ( ! class_exists( 'FKC_Maestro_Schema' ) ) { return array(); }
		FKC_Maestro_Schema::ensure();
		try {
			return FKC_DB::q(
				"SELECT * FROM fie_anomalies
				 WHERE detectee_le >= date('now','localtime','-7 day') AND (cause_connue IS NULL OR cause_connue='')
				 ORDER BY CASE gravite WHEN 'risque' THEN 0 WHEN 'attention' THEN 1 ELSE 2 END, id DESC
				 LIMIT " . max( 1, (int) $limite )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/* ═══════════════ API interne (JSON) ═══════════════ */

	/**
	 * Point d'entrée conversationnel : ?q=...
	 *
	 * C'est CE point que le dashboard, le mobile, le scan et les packs
	 * appellent. Une seule implémentation, donc une seule réponse possible à
	 * une même question — quel que soit l'écran d'où elle vient.
	 */
	public function ask() {
		/* POST de préférence (1.845.0) : une question ÉCRIT — le fil, le
		   journal, les recommandations, parfois un dossier d'action. Le GET
		   reste accepté pour les appels existants (barre, mobile). */
		$src = 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ? $_POST : $_GET;
		$q = trim( (string) ( $src['q'] ?? '' ) );
		$rep = FKC_Maestro::ask( $q, array(
			'sujet' => (string) ( $src['sujet'] ?? '' ),
			'max'   => max( 1, min( 10, (int) ( $src['max'] ?? 3 ) ) ),
			'canal' => self::canal( (string) ( $src['canal'] ?? '' ) ),
		) );
		return $this->json( $rep );
	}

	/* ═══════════════ Langage de Maestro (1.846.0) ═══════════════ */

	/**
	 * Écran « Langage de Maestro » : les questions restées sans réponse,
	 * la reformulation qui a suivi, et les expressions apprises. Réservé à
	 * l'administrateur — enseigner un mot change ce que Maestro répond à
	 * TOUTE la société.
	 */
	public function langage() {
		if ( ! FKC_Auth::isAdmin() ) {
			$_SESSION['__flash_mlex'] = array( 'type' => 'erreur', 'msg' => 'Le langage de Maestro se règle par l\'administrateur.' );
			redirect( 'analyse/maestro' );
		}
		$flash = $_SESSION['__flash_mlex'] ?? null;
		unset( $_SESSION['__flash_mlex'] );
		FKC_View::render( 'analyse::maestro_langage', array(
			'title'       => 'Langage de Maestro',
			'tab'         => 'maestro',
			'flash'       => $flash,
			'incomprises' => FKC_Maestro_Lexique::incomprises( 30, 40 ),
			'appris'      => FKC_Maestro_Lexique::appris(),
			'cibles'      => FKC_Maestro_Lexique::cibles(),
		) );
	}

	public function langageApprendre() {
		$cible = (string) ( $_POST['cible'] ?? '' );
		$type = 'predicat';
		if ( false !== strpos( $cible, '|' ) ) { list( $type, $cible ) = explode( '|', $cible, 2 ); }
		$r = FKC_Maestro_Lexique::apprendre( (string) ( $_POST['expression'] ?? '' ), $type, $cible, (string) ( $_POST['exemple'] ?? '' ) );
		$_SESSION['__flash_mlex'] = array( 'type' => $r['ok'] ? 'ok' : 'erreur', 'msg' => $r['message'] );
		redirect( 'maestro/langage' );
	}

	public function langageRetirer() {
		$r = FKC_Maestro_Lexique::retirer( (int) ( $_POST['id'] ?? 0 ) );
		$_SESSION['__flash_mlex'] = array( 'type' => $r['ok'] ? 'ok' : 'erreur', 'msg' => $r['message'] );
		redirect( 'maestro/langage' );
	}

	/** Canaux admis depuis le navigateur : pas de « connect:… » forgé à la main. */
	protected static function canal( $c ) {
		return in_array( $c, array( 'cockpit', 'mobile', 'barre', 'scan' ), true ) ? $c : 'cockpit';
	}

	/** Ferme le fil de conversation : le sujet suivant repart de zéro. */
	public function nouveauFil() {
		$canal = self::canal( (string) ( $_POST['canal'] ?? '' ) );
		$ok = class_exists( 'FKC_Maestro_Conversation' )
			? FKC_Maestro_Conversation::sur( $canal, fn() => FKC_Maestro_Conversation::clore() ) : false;
		return $this->json( array( 'ok' => $ok, 'message' => 'Nouveau sujet.' ) );
	}

	/** Les priorités du moment, pour la barre transversale et le mobile. */
	public function priorites() {
		$max = max( 1, min( 20, (int) ( $_GET['max'] ?? 5 ) ) );
		return $this->json( array( 'ok' => true, 'priorites' => FKC_Maestro::priorites( $max ) ) );
	}

	/** Conseil sur un domaine : appelé depuis un écran métier. */
	public function conseiller() {
		return $this->json( FKC_Maestro::conseiller( (string) ( $_GET['domaine'] ?? '' ) ) );
	}

	/**
	 * Les opportunités du moment.
	 *
	 * Point d'entrée distinct de conseiller() : « que dois-je corriger ? » et
	 * « où puis-je gagner ? » sont deux questions différentes, et les mélanger
	 * noierait les secondes dans les premières — toujours plus nombreuses et
	 * toujours plus pressantes.
	 */
	public function opportunites() {
		$max = max( 1, min( 5, (int) ( $_GET['max'] ?? 3 ) ) );
		return $this->json( array(
			'ok' => true,
			'opportunites' => FKC_Maestro::opportunites( $max ),
			'bilan' => class_exists( 'FKC_Maestro_Opportunity' ) ? FKC_Maestro_Opportunity::bilan() : null,
		) );
	}

	/** Conclut une opportunité : saisie, ignorée, ou impossible. */
	public function conclureOpportunite() {
		$cle = (string) ( $_POST['cle'] ?? '' );
		$statut = (string) ( $_POST['statut'] ?? 'ignoree' );
		$gain = isset( $_POST['gain_reel'] ) && '' !== $_POST['gain_reel'] ? (float) $_POST['gain_reel'] : null;
		if ( '' === $cle || ! class_exists( 'FKC_Maestro_Opportunity' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Opportunité non précisée.' ), 400 );
		}
		$ok = FKC_Maestro_Opportunity::conclure( $cle, $statut, $gain );
		return $this->json( array(
			'ok' => $ok,
			'message' => $ok
				? ( null !== $gain ? 'Résultat enregistré : il servira à juger la fiabilité de mes estimations.' : 'Noté.' )
				: 'Opportunité introuvable.',
		) );
	}

	/** Prévisions. */
	public function prevoir() {
		return $this->json( FKC_Maestro::prevoir( (string) ( $_GET['cle'] ?? '' ) ) );
	}

	/**
	 * Détail du backtest d'une prévision : le classement complet des méthodes.
	 *
	 * CET ÉCRAN EST LA CONTREPARTIE DU CHOIX AUTOMATIQUE. Un moteur qui
	 * sélectionne sa méthode tout seul doit pouvoir montrer POURQUOI, sinon il
	 * a simplement remplacé un arbitraire visible par un arbitraire caché. On
	 * affiche donc les neuf méthodes, leur erreur, et leur rapport à la naïve.
	 */
	public function backtest() {
		$cle = (string) ( $_GET['cle'] ?? '' );
		if ( '' === $cle || ! class_exists( 'FKC_Maestro_Forecast' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Prévision inconnue.' ), 404 );
		}
		if ( ! $this->ouvert( $cle ) ) { return $this->refus(); }
		$p = FKC_Maestro_Forecast::evaluer( $cle );
		if ( ! $p || empty( $p['ok'] ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Pas assez d\'historique pour juger les méthodes sur cette prévision.' ), 200 );
		}
		return $this->json( array(
			'ok' => true, 'cle' => $cle, 'libelle' => $p['libelle'],
			'methode' => $p['methode'], 'methode_libelle' => $p['methode_libelle'],
			'confiance' => $p['confiance'], 'confiance_source' => $p['confiance_source'],
			'backtest' => $p['backtest'], 'fiabilite' => $p['fiabilite'],
		) );
	}

	/** « Sur quoi te bases-tu ? » */
	public function expliquer() {
		return $this->json( FKC_Maestro::expliquer( (string) ( $_GET['sujet'] ?? '' ) ) );
	}

	/**
	 * « Pourquoi ce chiffre bouge-t-il ? » — la chaîne causale d'un prédicat.
	 *
	 * Distinct de expliquer(), qui répond à « d'où vient ce chiffre ». Les
	 * deux questions se ressemblent et n'ont pas la même réponse : la
	 * première demande une traçabilité, la seconde un mécanisme.
	 */
	public function pourquoi() {
		$p = (string) ( $_GET['predicat'] ?? '' );
		if ( '' === $p || ! class_exists( 'FKC_Maestro_Causality' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Indiquez l\'indicateur à analyser.' ), 400 );
		}
		if ( ! $this->ouvert( $p ) ) { return $this->refus(); }
		$x = FKC_Maestro_Causality::expliquerVariation( $p );
		$x['remontee'] = FKC_Maestro_Causality::remonter( $p );
		$x['ok'] = true;
		$x['libelle'] = FKC_Maestro_Causality::nommer( $p );
		return $this->json( $x );
	}

	/**
	 * Le graphe causal, avec le verdict des données sur chaque arête.
	 *
	 * Écran de transparence : le graphe est déclaré dans le code, donc
	 * opposable. Montrer lesquelles de ses relations se retrouvent dans CE
	 * dossier — et lesquelles non — est ce qui distingue un modèle assumé
	 * d'une boîte noire.
	 */
	public function causalite() {
		if ( ! class_exists( 'FKC_Maestro_Causality' ) ) { return $this->json( array( 'ok' => false ), 404 ); }
		$out = array();
		foreach ( FKC_Maestro_Causality::aretes() as $a ) {
			$v = FKC_Maestro_Causality::verdict( $a['cle'] );
			$out[] = $a + array(
				'cause_libelle' => FKC_Maestro_Causality::nommer( $a['cause'] ),
				'effet_libelle' => FKC_Maestro_Causality::nommer( $a['effet'] ),
				'statut' => $v['statut'] ?? 'non_mesuree',
				'correlation' => isset( $v['correlation'] ) ? (float) $v['correlation'] : null,
				'echantillon' => (int) ( $v['echantillon'] ?? 0 ),
			);
		}
		return $this->json( array( 'ok' => true, 'aretes' => $out, 'nb' => count( $out ) ) );
	}

	/**
	 * Simulation.
	 *
	 * Deux formes sur le même point d'entrée, selon qu'une clé de scénario est
	 * fournie ou non — l'appelant n'a pas à choisir entre deux URL pour poser
	 * la même question.
	 */
	public function simuler() {
		$cle = (string) ( $_GET['cle'] ?? $_POST['cle'] ?? '' );
		$aj  = (array) ( $_POST['leviers'] ?? $_GET['leviers'] ?? array() );
		if ( '' === $cle ) {
			// What-if : les leviers sont des pourcentages sur des prédicats.
			$leviers = array();
			foreach ( $aj as $p => $v ) {
				if ( ! is_numeric( $v ) ) { continue; }
				if ( ! $this->ouvert( (string) $p ) ) { return $this->refus(); }
				$leviers[ (string) $p ] = (float) $v;
			}
			return $this->json( FKC_Maestro::simuler( $leviers ) );
		}
		return $this->json( FKC_Maestro::simuler( $cle, $aj ) );
	}

	/**
	 * Sur quoi peut-on simuler, et que sait-on de chaque relation ?
	 *
	 * Cet écran est la contrepartie du refus de chiffrer : un moteur qui
	 * répond parfois « je ne sais pas de combien » doit pouvoir montrer où
	 * sont ses trous, sinon le refus passe pour une panne.
	 */
	public function leviers() {
		if ( ! class_exists( 'FKC_Maestro_Simulation' ) ) { return $this->json( array( 'ok' => false ), 404 ); }
		$aretes = array();
		foreach ( FKC_Maestro_Causality::aretes() as $a ) {
			$el = FKC_Maestro_Simulation::elasticite( $a['cle'] );
			$aretes[] = array(
				'cle' => $a['cle'],
				'de' => FKC_Maestro_Causality::nommer( $a['cause'] ),
				'vers' => FKC_Maestro_Causality::nommer( $a['effet'] ),
				'libelle' => $a['libelle'], 'nature' => $a['nature'],
				'chiffrable' => (bool) $el['chiffrable'],
				'elasticite' => $el['elasticite'], 'source' => $el['source'],
				'commentaire' => $el['commentaire'],
			);
		}
		return $this->json( array(
			'ok' => true,
			'leviers' => FKC_Maestro_Simulation::leviersDisponibles(),
			'relations' => $aretes,
		) );
	}

	/* ═══════════════ Action assistée ═══════════════ */

	/** Prépare un dossier d'action. N'exécute rien. */
	public function preparerAction() {
		$plan = (string) ( $_GET['plan'] ?? $_POST['plan'] ?? '' );
		if ( '' === $plan ) { return $this->json( array( 'ok' => false, 'message' => 'Plan d\'action non précisé.' ), 400 ); }
		return $this->json( FKC_Maestro::preparerAction( $plan ) );
	}

	/**
	 * Exécute un dossier validé.
	 *
	 * En POST, jeton vérifié par le routeur. La revérification de chaque
	 * cible se fait dans FKC_Maestro_Action : ce n'est pas un contrôle
	 * d'accès mais un contrôle de FRAÎCHEUR, et il doit vivre au plus près
	 * de l'exécution.
	 */
	public function executerAction() {
		$id = (int) ( $_POST['dossier_id'] ?? 0 );
		$ids = array_values( array_filter( (array) ( $_POST['cibles'] ?? array() ), fn( $x ) => '' !== (string) $x ) );
		$confirme = '1' === (string) ( $_POST['confirme'] ?? '0' );
		$r = FKC_Maestro_Action::executer( $id, $ids, $confirme );
		$code = ! empty( $r['ok'] ) ? 200 : ( ! empty( $r['confirmation_requise'] ) ? 409 : ( ! empty( $r['interdit'] ) ? 403 : 400 ) );
		return $this->json( $r, $code );
	}

	/** Abandonne un dossier préparé. */
	public function abandonnerAction() {
		$id = (int) ( $_POST['dossier_id'] ?? 0 );
		$ok = FKC_Maestro_Action::abandonner( $id, (string) ( $_POST['motif'] ?? '' ) );
		return $this->json( array( 'ok' => $ok, 'message' => $ok ? 'Dossier abandonné : rien n\'a été fait.' : 'Dossier introuvable ou déjà traité.' ) );
	}

	/** Détail d'un dossier. */
	public function dossierAction() {
		$d = FKC_Maestro_Action::dossier( (int) ( $_GET['id'] ?? 0 ) );
		return $this->json( $d ? array( 'ok' => true, 'dossier' => $d ) : array( 'ok' => false, 'message' => 'Dossier introuvable.' ), $d ? 200 : 404 );
	}

	/* ═══════════════ Retour utilisateur ═══════════════ */

	/**
	 * Enregistre un retour (👍 👎 ✅ ❌ ⏰).
	 *
	 * EN POST, ET C'EST NÉCESSAIRE : un retour pose un SILENCE de plusieurs
	 * jours sur un sujet de vigilance. En GET, un lien cliqué par erreur — ou
	 * simplement préchargé par le navigateur — ferait taire une alerte de
	 * trésorerie sans que personne ne l'ait voulu. Le jeton anti-CSRF est
	 * vérifié par FKC_Router::dispatch() sur toute route POST : le redemander
	 * ici doublerait un contrôle unique, donc en créerait deux à maintenir.
	 */
	public function feedback() {
		$id = (int) ( $_POST['reco_id'] ?? 0 );
		$verdict = (string) ( $_POST['verdict'] ?? '' );
		$res = FKC_Maestro_Feedback::noter( $id, $verdict, (string) ( $_POST['commentaire'] ?? '' ) );
		return $this->json( $res, $res['ok'] ? 200 : 400 );
	}

	/* ═══════════════ Apprentissages ═══════════════ */

	/** Ce que Maestro propose d'apprendre, en attente de validation. */
	public function apprentissages() {
		return $this->json( array( 'ok' => true, 'en_attente' => FKC_Maestro_Feedback::enAttente() ) );
	}

	/**
	 * Validation humaine d'un apprentissage.
	 *
	 * Réservée à l'administration : un apprentissage de niveau 3 touche à la
	 * connaissance comptable ou fiscale du dossier. Le contrôle de rôle est
	 * porté par la route ('admin' => true) ET revérifié ici — une route peut
	 * être recopiée sans son option, la classe ne se recopie pas.
	 * Le jeton anti-CSRF, lui, est vérifié par le routeur sur tout POST.
	 */
	public function validerApprentissage() {
		if ( ! FKC_Auth::isAdmin() ) {
			return $this->json( array( 'ok' => false, 'message' => 'Validation réservée à l\'administrateur du dossier.' ), 403 );
		}
		$id = (int) ( $_POST['id'] ?? 0 );
		$accepte = '0' !== (string) ( $_POST['accepte'] ?? '1' );
		$ok = FKC_Maestro_Feedback::valider( $id, $accepte );
		return $this->json( array(
			'ok' => $ok,
			'message' => $ok ? ( $accepte ? 'Apprentissage validé et appliqué.' : 'Apprentissage refusé.' ) : 'Apprentissage introuvable.',
		), $ok ? 200 : 404 );
	}

	/**
	 * Lance une passe d'apprentissage et rend les propositions.
	 *
	 * Coûteuse et volontairement manuelle. Un apprentissage qui se déclenche à
	 * chaque page ferait varier les seuils plus vite que l'utilisateur ne peut
	 * s'en apercevoir, et personne ne saurait plus pourquoi le moteur dit ce
	 * qu'il dit.
	 */
	public function apprendre() {
		if ( ! FKC_Auth::isAdmin() ) {
			return $this->json( array( 'ok' => false, 'message' => 'Réservé à l\'administrateur du dossier.' ), 403 );
		}
		$r = FKC_Maestro::apprendre();
		$n = count( $r['seuils'] ) + count( $r['fiabilites'] ) + count( $r['previsions'] ) + count( $r['interets'] );
		return $this->json( array(
			'ok' => true,
			'message' => $n
				? sprintf( '%d proposition(s) déposée(s), en attente de votre validation.', $n )
				: 'Rien de nouveau à apprendre pour l\'instant.',
			'propositions' => $n, 'detail' => $r,
		) );
	}

	/** Ce que Maestro a appris et qui est en vigueur. */
	public function apprisEnVigueur() {
		if ( ! class_exists( 'FKC_Maestro_Learning' ) ) { return $this->json( array( 'ok' => false ), 404 ); }
		return $this->json( array( 'ok' => true, 'en_vigueur' => FKC_Maestro_Learning::enVigueur() ) );
	}

	/**
	 * Révoque un apprentissage appliqué.
	 *
	 * Aussi accessible qu'accepter, et c'est délibéré : un système qui apprend
	 * sans pouvoir désapprendre accumule des réglages dont plus personne ne
	 * connaît l'origine, jusqu'au jour où il devient incompréhensible.
	 */
	public function revoquer() {
		if ( ! FKC_Auth::isAdmin() ) {
			return $this->json( array( 'ok' => false, 'message' => 'Réservé à l\'administrateur du dossier.' ), 403 );
		}
		$cat = (string) ( $_POST['categorie'] ?? '' );
		$cle = (string) ( $_POST['cle'] ?? '' );
		if ( '' === $cat || '' === $cle || ! class_exists( 'FKC_Maestro_Learning' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Apprentissage à révoquer non précisé.' ), 400 );
		}
		$ok = FKC_Maestro_Learning::revoquer( $cat, $cle );
		return $this->json( array( 'ok' => $ok, 'message' => $ok ? 'Apprentissage révoqué : le réglage d\'origine reprend la main.' : 'Révocation impossible.' ) );
	}

	/* ═══════════════ Entretien ═══════════════ */

	/**
	 * Passe d'observation, déclenchée à la main depuis le cockpit.
	 *
	 * Coûteuse (elle réveille tous les producteurs de faits) : elle n'est
	 * jamais lancée au rendu d'une page. Un dossier laissé de côté deux
	 * semaines rattrape son ADN en un clic. En POST parce qu'elle écrit —
	 * le routeur en vérifie le jeton.
	 */
	public function observer() {
		/*
		 * RÉSERVÉE ET ESPACÉE (1.837.0). La passe réveille tous les
		 * producteurs de faits : ouverte à tout compte et sans délai, un
		 * simple script — ou un bouton martelé — suffisait à occuper le
		 * serveur. Administrateur ou titulaire du module Analyse, et une
		 * passe au plus toutes les cinq minutes par société.
		 */
		if ( ! FKC_Auth::isAdmin() && ! FKC_Auth::can( 'analyse' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Réservé aux utilisateurs du module Analyse.' ), 403 );
		}
		$derniere = 0;
		try { $derniere = (int) FKC_DB::q( "SELECT valeur FROM parametres WHERE cle='maestro_observe_at'" )->fetchColumn(); } catch ( \Throwable $e ) {}
		if ( $derniere && time() - $derniere < 300 ) {
			return $this->json( array( 'ok' => false, 'trop_tot' => true,
				'message' => 'Une observation vient d\'être faite : la suivante sera possible dans ' . max( 1, (int) ceil( ( 300 - ( time() - $derniere ) ) / 60 ) ) . ' minute(s).' ), 429 );
		}
		try {
			$maj = FKC_DB::q( "UPDATE parametres SET valeur=? WHERE cle='maestro_observe_at'", array( (string) time() ) )->rowCount();
			if ( ! $maj ) { FKC_DB::q( "INSERT INTO parametres(cle, valeur) VALUES('maestro_observe_at', ?)", array( (string) time() ) ); }
		} catch ( \Throwable $e ) {}
		$r = FKC_Maestro::observer();
		return $this->json( array(
			'ok' => true,
			'message' => sprintf(
				'Observation faite : %d trait(s) d\'entreprise mesuré(s), %d événement(s) inscrit(s).',
				(int) $r['dna'], (int) $r['evenements']
			),
			'detail' => $r,
		) );
	}
}
