<?php
/** Module Analyse (Insights) : tableaux de bord, KPI, alertes, data warehouse, analyses sectorielles. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnalyseController {

	protected function ok( $feature ) { return FKC_Modules::featureEnabled( $feature ); }
	protected function verrou( $feature ) {
		FKC_View::render( 'analyse::verrou', array(
			'title' => 'Analyse', 'tab' => '', 'feature' => $feature,
			'label' => FKC_Modules::featureLabel( $feature ), 'min' => FKC_Modules::featureMinLabel( $feature ),
		) );
	}
	protected function show( $view, $vars ) {
		$vars['fromDW'] = FKC_Warehouse::utiliseDepuis(); // mention affichée seulement si l'instantané sert encore
		if ( ! isset( $vars['periode'] ) ) { $vars['periode'] = $this->periode(); }
		FKC_View::render( 'analyse::' . $view, $vars );
	}

	/** Période analysée depuis l'URL (?du&au&cmp). Défaut : l'exercice en cours (1.832.0). */
	protected function periode() {
		list( $du, $au ) = FKC_Metrics::bornes( $_GET['du'] ?? null, $_GET['au'] ?? null );
		$cmp = ( 'n1' === ( $_GET['cmp'] ?? '' ) ) ? 'n1' : '';
		$mois = count( FKC_Metrics::moisRange( $du, $au ) );
		return array( 'du' => $du, 'au' => $au, 'cmp' => $cmp, 'mois' => $mois, 'raccourcis' => FKC_Metrics::raccourcis( $du ) );
	}

	/* ── Vue d'ensemble ── */
	public function index() {
		if ( ! $this->ok( 'analyse.dashboards' ) ) { return $this->verrou( 'analyse.dashboards' ); }
		if ( $this->ok( 'analyse.alertes' ) ) { FKC_Alerte::notifierSiDu(); } // une alerte franchie part dans la cloche (1.837.0)
		$p = $this->periode();
		$fin = FKC_Metrics::finance( $p['du'], $p['au'] );
		$com = FKC_Metrics::commercial( $p['du'], $p['au'] );
		$cmp = null;
		if ( 'n1' === $p['cmp'] ) {
			$pdu = date( 'Y-m-d', strtotime( '-1 year', strtotime( $p['du'] ) ) );
			$pau = date( 'Y-m-d', strtotime( '-1 year', strtotime( $p['au'] ) ) );
			$cmp = array( 'fin' => FKC_Metrics::finance( $pdu, $pau ), 'com' => FKC_Metrics::commercial( $pdu, $pau ) );
		}
		$this->show( 'dashboard', array(
			'title' => 'Analyse · Vue d\'ensemble', 'tab' => 'dashboard', 'periode' => $p, 'cmp' => $cmp,
			'fin' => $fin, 'com' => $com, 'rappro' => FKC_Metrics::rapprochement( $fin ),
			'rec' => FKC_Warehouse::data( 'recouvrement' ), 'inv' => FKC_Warehouse::data( 'inventaire' ),
			'rh' => FKC_Warehouse::data( 'rh' ), 'treso' => FKC_Metrics::tresorerie( $p['au'] ),
			'kpis' => FKC_Kpi::all(), 'alertes' => FKC_Alerte::evaluate(),
		) );
	}

	/* ═══════════════ FinaKop Intelligence Engine (FIE) ═══════════════ */

	public function fie() {
		if ( ! $this->ok( 'analyse.dashboards' ) ) { return $this->verrou( 'analyse.dashboards' ); }
		// Passe par Maestro quand il est là : même analyse, mémorisée pour la
		// requête, et enrichie de la confiance et des sources de chaque décision.
		$analyse = class_exists( 'FKC_Maestro' )
			? FKC_Maestro::analyser()
			: ( class_exists( 'FKC_Fie' ) ? FKC_Fie::analyser() : array( 'decisions' => array(), 'faits' => array(), 'derives' => array(), 'synthese' => array() ) );
		$this->show( 'fie', array(
			'title' => 'FinaKop Intelligence Engine', 'tab' => 'fie',
			'analyse' => $analyse,
		) );
	}

	/**
	 * Déclenche le playbook d'une décision.
	 *
	 * CORRECTIF 1.574.0 — l'analyse était calculée DEUX FOIS par appel
	 * (`FKC_Fie::analyser()` dans l'expression de boucle est réévaluée à
	 * chaque itération en PHP, et c'est l'appel le plus cher de
	 * l'application : il réveille tous les producteurs de faits, donc une
	 * bonne part des modules). On passe par FKC_Maestro::analyser(), qui
	 * mémorise le résultat pour la durée de la requête — le cockpit, qui
	 * l'appelle lui aussi, en profite du même coup.
	 */
	public function fiePlaybook() {
		if ( ! $this->ok( 'analyse.dashboards' ) ) { if ( ! headers_sent() ) { header( 'Content-Type: application/json; charset=utf-8' ); } echo json_encode( array( 'ok' => false, 'message' => 'Fonction non incluse dans votre licence.' ) ); exit; }
		$cle = (string) ( $_POST['decision'] ?? '' );
		$msg = 'Décision introuvable.'; $ok = false;
		$decisions = class_exists( 'FKC_Maestro' )
			? (array) FKC_Maestro::analyser()['decisions']
			: ( class_exists( 'FKC_Fie' ) ? (array) FKC_Fie::analyser()['decisions'] : array() );
		foreach ( $decisions as $d ) {
			if ( ( $d['cle'] ?? '' ) === $cle ) { list( $ok, $msg ) = FKC_Fie_Workflow::declencher( $d ); break; }
		}
		if ( ! headers_sent() ) { header( 'Content-Type: application/json; charset=utf-8' ); }
		echo json_encode( array( 'ok' => $ok, 'message' => $msg ), JSON_UNESCAPED_UNICODE );
		exit;
	}

	public function financiere() {
		if ( ! $this->ok( 'analyse.financiere' ) ) { return $this->verrou( 'analyse.financiere' ); }
		$p = $this->periode();
		$d = FKC_Metrics::finance( $p['du'], $p['au'] );
		$this->show( 'financiere', array( 'title' => 'Analyse financière', 'tab' => 'financiere', 'periode' => $p, 'd' => $d, 'rappro' => FKC_Metrics::rapprochement( $d ) ) );
	}
	public function commerciale() {
		if ( ! $this->ok( 'analyse.commerciale' ) ) { return $this->verrou( 'analyse.commerciale' ); }
		$p = $this->periode();
		$this->show( 'commerciale', array( 'title' => 'Analyse commerciale', 'tab' => 'commerciale', 'periode' => $p, 'd' => FKC_Metrics::commercial( $p['du'], $p['au'] ) ) );
	}
	public function clients() {
		if ( ! $this->ok( 'analyse.clients' ) ) { return $this->verrou( 'analyse.clients' ); }
		$this->show( 'clients', array( 'title' => 'Analyse clients', 'tab' => 'clients', 'd' => FKC_Warehouse::data( 'clients' ) ) );
	}
	public function recouvrement() {
		if ( ! $this->ok( 'analyse.recouvrement' ) ) { return $this->verrou( 'analyse.recouvrement' ); }
		$this->show( 'recouvrement', array( 'title' => 'Analyse recouvrement', 'tab' => 'recouvrement', 'd' => FKC_Warehouse::data( 'recouvrement' ) ) );
	}
	public function rh() {
		if ( ! $this->ok( 'analyse.rh' ) ) { return $this->verrou( 'analyse.rh' ); }
		$this->show( 'rh', array( 'title' => 'Analyse RH', 'tab' => 'rh', 'd' => FKC_Warehouse::data( 'rh' ) ) );
	}
	public function inventaire() {
		if ( ! $this->ok( 'analyse.inventaire' ) ) { return $this->verrou( 'analyse.inventaire' ); }
		$this->show( 'inventaire', array( 'title' => 'Analyse inventaire', 'tab' => 'inventaire', 'd' => FKC_Warehouse::data( 'inventaire' ) ) );
	}
	public function budgetaire() {
		if ( ! $this->ok( 'analyse.budgetaire' ) ) { return $this->verrou( 'analyse.budgetaire' ); }
		$this->show( 'budgetaire', array( 'title' => 'Analyse budgétaire', 'tab' => 'budgetaire', 'd' => FKC_Warehouse::data( 'budgetaire' ) ) );
	}
	public function rentabilite() {
		if ( ! $this->ok( 'analyse.rentabilite' ) ) { return $this->verrou( 'analyse.rentabilite' ); }
		$p = $this->periode();
		/*
		 * ÉCRAN « MARGE » (1.833.0) : soldes intermédiaires de gestion
		 * comparés à N-1, marge par section analytique, marge par article.
		 */
		$annee = FKC_Metrics::exerciceDe( $p['du'] );
		$tous = 'tous' === ( $_GET['articles'] ?? '' );
		$this->show( 'rentabilite', array( 'title' => 'Marge', 'tab' => 'rentabilite', 'periode' => $p,
			'd' => FKC_Metrics::rentabilite( $p['du'], $p['au'] ),
			'sig' => FKC_Marge::sig( $p['du'], $p['au'] ),
			'mensuel' => FKC_Marge::mensuel( $p['du'], $p['au'] ),
			'axes' => FKC_Marge::axes(),
			'parAxe' => FKC_Marge::parAxe( (int) ( $_GET['axe'] ?? 0 ), $annee ),
			'articles' => FKC_Marge::articles( $p['du'], $p['au'], $tous ? 500 : 15 ), 'tousArticles' => $tous,
			'lienArticle' => FKC_License::moduleEnabled( 'inventaire' ) && ( ! FKC_Auth::check() || FKC_Auth::can( 'inventaire' ) ),
			'rappro' => FKC_Metrics::rapprochement( FKC_Metrics::finance( $p['du'], $p['au'] ) ) ) );
	}
	public function previsionnelle() {
		if ( ! $this->ok( 'analyse.previsionnelle' ) ) { return $this->verrou( 'analyse.previsionnelle' ); }
		$this->show( 'previsionnelle', array( 'title' => 'Analyse prévisionnelle', 'tab' => 'previsionnelle', 'd' => FKC_Metrics::prevision() ) );
	}
	public function sectorielle() {
		if ( ! $this->ok( 'analyse.sectorielle' ) ) { return $this->verrou( 'analyse.sectorielle' ); }
		$this->show( 'sectorielle', array(
			'title' => 'Analyse sectorielle', 'tab' => 'sectorielle', 'd' => FKC_Warehouse::data( 'sectorielle' ),
			'secteur' => class_exists( 'FKC_Secteur' ) ? FKC_Secteur::meta( FKC_Secteur::active() ) : array( '🎬', 'Creative' ),
			'musical' => class_exists( 'FKC_Secteur' ) ? FKC_Secteur::estMusical() : true,
		) );
	}

	/* ── Centre KPI ── */
	public function kpi() {
		if ( ! $this->ok( 'analyse.kpi' ) ) { return $this->verrou( 'analyse.kpi' ); }
		$this->show( 'kpi', array(
			'title' => 'Centre KPI', 'tab' => 'kpi', 'kpis' => FKC_Kpi::all(),
			'registre' => FKC_Metrics::registre(), 'couches' => FKC_Kpi::couches(), 'sens' => FKC_Kpi::sens(),
			'flash' => $this->flash(),
		) );
	}
	public function kpiStore() {
		if ( $this->ok( 'analyse.kpi' ) && '' !== trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { FKC_Kpi::create( $_POST ); $this->setFlash( 'KPI ajouté.' ); }
		redirect( 'analyse/kpi' );
	}
	public function kpiDelete( $id ) { if ( ! $this->ok( 'analyse.kpi' ) ) { redirect( 'analyse' ); } FKC_Kpi::delete( $id ); $this->setFlash( 'KPI supprimé.' ); redirect( 'analyse/kpi' ); }

	/* ── Alertes intelligentes ── */
	public function alertes() {
		if ( ! $this->ok( 'analyse.alertes' ) ) { return $this->verrou( 'analyse.alertes' ); }
		FKC_Alerte::notifier();
		$this->show( 'alertes', array(
			'title' => 'Alertes intelligentes', 'tab' => 'alertes', 'alertes' => FKC_Alerte::all(),
			'declenchees' => FKC_Alerte::evaluate(), 'registre' => FKC_Metrics::registre(),
			'operateurs' => FKC_Alerte::operateurs(), 'niveaux' => FKC_Alerte::niveaux(), 'flash' => $this->flash(),
			'modeEmail' => FKC_Alerte::modeEmail(), 'modesEmail' => FKC_Alerte::modesEmail(),
			'destinataires' => FKC_Alerte::destinatairesDetail(), 'courrielDispo' => FKC_Courriel::disponible(),
			'journalCourriels' => FKC_Courriel::journal( 8, 'alerte' ), 'estAdmin' => FKC_Auth::isAdmin(),
		) );
	}

	/** Réglage d'envoi par courriel — administrateur (1.838.0). */
	public function alertesReglages() {
		if ( ! $this->ok( 'analyse.alertes' ) ) { return $this->verrou( 'analyse.alertes' ); }
		if ( ! FKC_Auth::isAdmin() ) { $this->setFlash( 'Réglage réservé à l\'administrateur.' ); redirect( 'analyse/alertes' ); }
		$m = FKC_Alerte::setModeEmail( (string) ( $_POST['mode_email'] ?? '' ) );
		$this->setFlash( 'Envoi par courriel : ' . mb_strtolower( FKC_Alerte::modesEmail()[ $m ] ) . '.' );
		redirect( 'analyse/alertes' );
	}

	/** Courriel d'essai à l'administrateur connecté : vérifie la messagerie du serveur avant qu'une vraie alerte en dépende. */
	public function alertesTest() {
		if ( ! $this->ok( 'analyse.alertes' ) ) { return $this->verrou( 'analyse.alertes' ); }
		if ( ! FKC_Auth::isAdmin() ) { $this->setFlash( 'Essai réservé à l\'administrateur.' ); redirect( 'analyse/alertes' ); }
		$u = FKC_Auth::user();
		$to = trim( (string) ( $u['email'] ?? '' ) );
		if ( '' === $to ) {
			$this->setFlash( 'Votre compte n\'a pas d\'adresse e-mail : renseignez-la dans Utilisateurs.' );
			redirect( 'analyse/alertes' );
		}
		$essai = array( 'id' => 0, 'libelle' => 'Courriel d\'essai', 'metric' => 'essai', 'operateur' => '<', 'seuil' => 100, 'niveau' => 'danger' );
		list( $sujet, $texte, $html ) = FKC_Alerte::courriel( $essai, 50 );
		list( $ok, $msg ) = FKC_Courriel::envoyer( $to, '[Essai] ' . $sujet, $texte, $html, 'alerte:essai' );
		$this->setFlash( $ok ? 'Courriel d\'essai envoyé à ' . $to . ' : vérifiez votre boîte (et les indésirables).' : 'Échec de l\'essai : ' . $msg );
		redirect( 'analyse/alertes' );
	}
	public function alerteStore() {
		if ( $this->ok( 'analyse.alertes' ) && '' !== trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { FKC_Alerte::create( $_POST ); $this->setFlash( 'Alerte créée.' ); }
		redirect( 'analyse/alertes' );
	}
	public function alerteDelete( $id ) { if ( ! $this->ok( 'analyse.alertes' ) ) { redirect( 'analyse' ); } FKC_Alerte::delete( $id ); $this->setFlash( 'Alerte supprimée.' ); redirect( 'analyse/alertes' ); }

	/* ── Data Warehouse ── */
	public function warehouse() {
		if ( ! $this->ok( 'analyse.datawarehouse' ) ) { return $this->verrou( 'analyse.datawarehouse' ); }
		$this->show( 'warehouse', array(
			'title' => 'Data Warehouse', 'tab' => 'warehouse', 'domaines' => FKC_Warehouse::domaines(),
			'updated' => FKC_Warehouse::updatedAt(),
			'dwStats' => FKC_Warehouse::stats(),
			'dwCatalogue' => FKC_Warehouse::catalogue(),
			'flash' => $this->flash(),
		) );
	}
	public function warehouseRefresh() {
		if ( $this->ok( 'analyse.datawarehouse' ) ) {
			$n = FKC_Warehouse::refresh();
			$c = FKC_Warehouse::capturer(); // historise les métriques du jour
			$this->setFlash( $n . ' domaine(s) recalculé(s), ' . $c . ' métrique(s) historisée(s) dans l\'entrepôt.' );
		}
		redirect( 'analyse/warehouse' );
	}

	/* ── helpers ── */
	/* ═══════════════ Rapports (1.834.0) ═══════════════ */

	/** Centre « Rapports » : catalogue, rapports enregistrés, autres éditions. */
	public function rapports() {
		$ent = $this->ok( 'analyse.rapports' );
		$this->show( 'rapports', array(
			'title' => 'Rapports', 'tab' => 'rapports', 'periode' => $this->periode(),
			'groupes' => FKC_AnaRapports::parGroupe(),
			'enregistres' => $ent ? FKC_AnaRapports::enregistres() : array(), 'entreprise' => $ent,
			'autres' => FKC_AnaRapports::autresEditions(), 'flash' => $this->flash(),
		) );
	}

	/** Rapport demandé (?code, du, au, axe) — ou null après avoir affiché le verrou. */
	protected function rapportDemande() {
		$code = (string) ( $_GET['code'] ?? '' );
		$cat = FKC_AnaRapports::catalogue();
		if ( ! isset( $cat[ $code ] ) ) { $this->setFlash( 'Rapport introuvable.' ); redirect( 'analyse/rapports' ); }
		if ( ! FKC_AnaRapports::accessible( $code ) ) { $this->verrou( $cat[ $code ][3] ); return null; }
		$p = $this->periode();
		$opts = array();
		if ( ! empty( $_GET['axe'] ) ) { $opts['axe'] = (int) $_GET['axe']; }
		return array( FKC_AnaRapports::produire( $code, $p['du'], $p['au'], $opts ), $p, $opts );
	}

	/** Rapport à l'écran, prêt à imprimer. */
	public function rapportVoir() {
		$x = $this->rapportDemande();
		if ( ! $x ) { return; }
		list( $r, $p, $opts ) = $x;
		$this->show( 'rapport', array(
			'title' => $r['titre'], 'tab' => 'rapports', 'r' => $r, 'periode' => $p, 'opts' => $opts,
			'axes' => 'marge_axe' === $r['code'] ? FKC_Marge::axes() : array(),
			'avecPeriode' => FKC_AnaRapports::catalogue()[ $r['code'] ][5],
			'entreprise' => $this->ok( 'analyse.rapports' ), 'periodes' => FKC_AnaRapports::periodesRelatives(),
			'flash' => $this->flash(),
		) );
	}

	/** Export CSV : les mêmes lignes que l'écran, montants bruts. */
	public function rapportExport() {
		$x = $this->rapportDemande();
		if ( ! $x ) { return; }
		fkc_csv( FKC_AnaRapports::nomFichier( $x[0] ), FKC_AnaRapports::csv( $x[0] ) );
	}

	/** Enregistre un rapport, ses options et sa période relative (Enterprise). */
	public function rapportEnregistrer() {
		if ( ! $this->ok( 'analyse.rapports' ) ) { return $this->verrou( 'analyse.rapports' ); }
		$code = (string) ( $_POST['code'] ?? '' );
		if ( ! FKC_AnaRapports::accessible( $code ) ) { $this->setFlash( 'Ce rapport n\'est pas ouvert à votre licence.' ); redirect( 'analyse/rapports' ); }
		list( $ok, $msg ) = FKC_AnaRapports::enregistrer( $_POST );
		$this->setFlash( $msg );
		if ( ! $ok ) {
			redirect( 'analyse/rapports/voir?' . http_build_query( array_filter( array( 'code' => $code, 'du' => $_POST['du'] ?? null, 'au' => $_POST['au'] ?? null, 'axe' => $_POST['axe'] ?? null ) ) ) );
		}
		redirect( 'analyse/rapports' );
	}

	/** Ouvre un rapport enregistré sur sa période, résolue aujourd'hui. */
	public function rapportOuvrir( $id ) {
		if ( ! $this->ok( 'analyse.rapports' ) ) { return $this->verrou( 'analyse.rapports' ); }
		$s = FKC_AnaRapports::trouver( $id );
		if ( ! $s ) { $this->setFlash( 'Rapport enregistré introuvable.' ); redirect( 'analyse/rapports' ); }
		redirect( FKC_AnaRapports::lien( $s ) );
	}

	public function rapportSupprimer( $id ) {
		if ( ! $this->ok( 'analyse.rapports' ) ) { return $this->verrou( 'analyse.rapports' ); }
		$s = FKC_AnaRapports::trouver( $id );
		if ( $s ) { FKC_AnaRapports::supprimer( $id ); $this->setFlash( 'Rapport « ' . $s['nom'] . ' » supprimé.' ); }
		redirect( 'analyse/rapports' );
	}

	protected function setFlash( $m ) { $_SESSION['__flash_an'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_an'] ?? null; unset( $_SESSION['__flash_an'] ); return $m; }
}
