<?php
/**
 * RAPPORTS (1.834.0) — le centre « Rapports » de la barre latérale.
 *
 * Un rapport est un TABLEAU : des colonnes typées, des lignes, des notes.
 * Le même tableau s'affiche à l'écran, s'imprime (A4) et s'exporte en CSV —
 * trois sorties, un seul calcul, donc jamais deux chiffres différents.
 *
 * Les rapports réutilisent les calculs des écrans d'analyse (FKC_Marge,
 * FKC_Metrics, FKC_Recouvrement) : un rapport n'a pas le droit de dire autre
 * chose que l'écran dont il est l'édition.
 *
 * Édition Enterprise (analyse.rapports) : RAPPORTS ENREGISTRÉS. Un rapport,
 * ses options et une période RELATIVE (« exercice en cours », « mois
 * dernier »…) : rouvert dans six mois, il se recalcule sur la bonne période
 * au lieu de montrer toujours les mêmes dates.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaRapports {

	/* ═══════════════ Catalogue ═══════════════ */

	/**
	 * code => [titre, description, groupe, fonctionnalité, module requis|null, période (bool), options]
	 */
	public static function catalogue() {
		return array(
			'sig' => array( 'Soldes intermédiaires de gestion', 'Marge commerciale, valeur ajoutée, EBE, résultats — comparés à N-1', 'Marge & résultat', 'analyse.rentabilite', null, true, array() ),
			'resultat_mensuel' => array( 'Résultat mois par mois', 'Produits, charges, hors activités ordinaires et résultat de chaque mois', 'Marge & résultat', 'analyse.financiere', null, true, array() ),
			'charges_nature' => array( 'Charges par nature', 'Chaque compte de charges, sa part et son évolution sur N-1', 'Marge & résultat', 'analyse.financiere', null, true, array() ),
			'marge_axe' => array( 'Marge par section analytique', 'Produits, charges et marge par division, projet ou client (par exercice)', 'Marge & résultat', 'analyse.rentabilite', 'analytique', true, array( 'axe' ) ),
			'marge_article' => array( 'Marge par article', 'Ventes de caisse hors taxes, coût, marge et taux par article', 'Ventes & clients', 'analyse.rentabilite', null, true, array() ),
			'ca_clients' => array( 'Chiffre d\'affaires par client', 'Factures validées hors taxes, nombre de factures et part du total', 'Ventes & clients', 'analyse.commerciale', null, true, array() ),
			'balance_agee' => array( 'Balance âgée clients', 'Encours par client et par ancienneté, à la date du jour', 'Ventes & clients', 'analyse.recouvrement', null, false, array() ),
		);
	}

	/** Périodes relatives d'un rapport enregistré. */
	public static function periodesRelatives() {
		return array(
			'exercice' => 'Exercice en cours',
			'exercice_prec' => 'Exercice précédent',
			'mois_prec' => 'Mois dernier',
			'mois' => 'Mois en cours',
			'trimestre_prec' => 'Trimestre civil précédent',
			'12m' => '12 derniers mois complets',
			'fixe' => 'Dates fixes',
		);
	}

	/** Bornes d'une période relative à une date de référence. */
	public static function resoudrePeriode( $cle, $du = null, $au = null, $ref = null ) {
		$ref = $ref ?: date( 'Y-m-d' );
		$t = strtotime( $ref );
		switch ( $cle ) {
			case 'exercice':
				return FKC_Metrics::exercice( FKC_Metrics::exerciceDe( $ref ) );
			case 'exercice_prec':
				return FKC_Metrics::exercice( (string) ( (int) FKC_Metrics::exerciceDe( $ref ) - 1 ) );
			case 'mois_prec':
				$m = strtotime( date( 'Y-m-01', $t ) . ' -1 month' );
				return array( date( 'Y-m-01', $m ), date( 'Y-m-t', $m ) );
			case 'mois':
				return array( date( 'Y-m-01', $t ), date( 'Y-m-t', $t ) );
			case 'trimestre_prec':
				$q = (int) ceil( (int) date( 'n', $t ) / 3 ) - 1; $y = (int) date( 'Y', $t );
				if ( $q < 1 ) { $q = 4; $y--; }
				$d = sprintf( '%04d-%02d-01', $y, ( $q - 1 ) * 3 + 1 );
				return array( $d, date( 'Y-m-t', strtotime( $d . ' +2 month' ) ) );
			case '12m':
				$fin = strtotime( date( 'Y-m-01', $t ) . ' -1 day' );
				return array( date( 'Y-m-01', strtotime( date( 'Y-m-01', $fin ) . ' -11 month' ) ), date( 'Y-m-d', $fin ) );
			default:
				return FKC_Metrics::bornes( $du, $au );
		}
	}

	/** Le rapport est-il ouvert à l'utilisateur courant (licence, module, droits) ? */
	public static function accessible( $code ) {
		$c = self::catalogue();
		if ( ! isset( $c[ $code ] ) ) { return false; }
		if ( ! FKC_Modules::featureEnabled( $c[ $code ][3] ) ) { return false; }
		$mod = $c[ $code ][4];
		if ( $mod && ( ! FKC_License::moduleEnabled( $mod ) || ( FKC_Auth::check() && ! FKC_Auth::can( $mod ) ) ) ) { return false; }
		if ( 'marge_axe' === $code && ! FKC_Marge::axes() ) { return false; }
		return true;
	}

	/**
	 * Catalogue groupé pour le centre : [groupe => [code => [titre, desc, ouvert, fonctionnalité]]].
	 */
	public static function parGroupe() {
		$out = array();
		foreach ( self::catalogue() as $code => $c ) {
			$mod = $c[4];
			if ( $mod && ! FKC_License::moduleEnabled( $mod ) ) { continue; } // module absent : rien à proposer
			$out[ $c[2] ][ $code ] = array( $c[0], $c[1], self::accessible( $code ), $c[3] );
		}
		return $out;
	}

	/**
	 * Autres éditions de l'ERP, là où elles vivent : chacune n'apparaît que
	 * si son module est ouvert à l'utilisateur.
	 * @return array [ [titre, description, route, module] ]
	 */
	public static function autresEditions() {
		$l = array(
			array( 'Balance générale', 'Soldes de tous les comptes', 'comptabilite/balance', 'comptabilite' ),
			array( 'Grand livre général', 'Mouvements détaillés par compte', 'comptabilite/grand-livre', 'comptabilite' ),
			array( 'États financiers', 'Bilan, compte de résultat, liasse SYSCOHADA', 'comptabilite/etats-financiers', 'comptabilite' ),
			array( 'Résultats analytiques', 'Par axe, avec détail et export', 'analytique/resultats-analytiques', 'analytique' ),
			array( 'Tableau croisé analytique', 'Deux axes face à face', 'analytique/croise', 'analytique' ),
			array( 'Suivi du budget mensuel', 'Budget contre réalisé, par nature et par mois', 'analytique/budget-mensuel/suivi', 'analytique' ),
			array( 'Recouvrement', 'Relances, échéancier, dossiers', 'recouvrement', 'recouvrement' ),
			array( 'Reporting inventaire', 'Mouvements et valorisation du stock', 'inventaire/reporting', 'inventaire' ),
		);
		return array_values( array_filter( $l, function ( $x ) {
			return FKC_License::moduleEnabled( $x[3] ) && ( ! FKC_Auth::check() || FKC_Auth::can( $x[3] ) );
		} ) );
	}

	/* ═══════════════ Production ═══════════════ */

	/**
	 * Calcule un rapport.
	 *
	 * @return array{code:string,titre:string,periode:string,du:?string,au:?string,colonnes:array,lignes:array,notes:array}|null
	 *   colonnes : [ [libellé, type] ] — type txt | mt (montant) | pct | var (variation signée) | qte
	 *   lignes   : [ [ 'c' => cellules, 's' => ''|'sous'|'total'|'muted' ] ]
	 */
	public static function produire( $code, $du, $au, array $opts = array() ) {
		$cat = self::catalogue();
		if ( ! isset( $cat[ $code ] ) ) { return null; }
		$m = 'r_' . $code;
		$r = self::$m( $du, $au, $opts );
		$r['code'] = $code;
		$r['titre'] = $r['titre'] ?? $cat[ $code ][0];
		$r['du'] = $cat[ $code ][5] ? $du : null;
		$r['au'] = $cat[ $code ][5] ? $au : null;
		if ( ! isset( $r['periode'] ) ) {
			$r['periode'] = $cat[ $code ][5]
				? 'Du ' . date( 'd/m/Y', strtotime( $du ) ) . ' au ' . date( 'd/m/Y', strtotime( $au ) )
				: 'Au ' . date( 'd/m/Y' );
		}
		$r['notes'] = $r['notes'] ?? array();
		return $r;
	}

	protected static function r_sig( $du, $au, $o ) {
		$s = FKC_Marge::sig( $du, $au );
		$lignes = array();
		foreach ( $s['lignes'] as $l ) {
			if ( 'd' === $l['type'] && abs( $l['n'] ) < 0.5 && abs( $l['n1'] ) < 0.5 ) { continue; }
			$lignes[] = array( 's' => 'd' === $l['type'] ? '' : ( 'g' === $l['type'] ? 'total' : 'sous' ),
				'c' => array( $l['signe'] . ' ' . $l['libelle'], $l['n'], $l['pct_ca'], $l['n1'], $l['pct_ca1'], $l['var'] ) );
		}
		return array(
			'colonnes' => array( array( 'Poste', 'txt' ), array( 'Période', 'mt' ), array( '% CA', 'pct' ), array( 'N-1', 'mt' ), array( '% CA N-1', 'pct' ), array( 'Variation', 'var' ) ),
			'lignes' => $lignes,
			'notes' => array( 'Calcul du compte de résultat SYSCOHADA, hors écriture de détermination du résultat. N-1 : du '
				. date( 'd/m/Y', strtotime( $s['du1'] ) ) . ' au ' . date( 'd/m/Y', strtotime( $s['au1'] ) ) . '.' ),
		);
	}

	protected static function r_resultat_mensuel( $du, $au, $o ) {
		$f = FKC_Metrics::finance( $du, $au );
		$lignes = array(); $t = array( 0.0, 0.0, 0.0, 0.0 );
		foreach ( (array) ( $f['produits_mois'] ?? array() ) as $ym => $p ) {
			$c = (float) ( $f['charges_mois'][ $ym ] ?? 0 ); $h = (float) ( $f['hao_mois'][ $ym ] ?? 0 ); $r = (float) ( $f['resultat_mois'][ $ym ] ?? 0 );
			$lignes[] = array( 's' => '', 'c' => array( self::moisLong( $ym ), (float) $p, $c, $h, $r, (float) $p > 0 ? $r / (float) $p * 100 : null ) );
			$t[0] += (float) $p; $t[1] += $c; $t[2] += $h; $t[3] += $r;
		}
		$lignes[] = array( 's' => 'total', 'c' => array( 'Total', $t[0], $t[1], $t[2], $t[3], $t[0] > 0 ? $t[3] / $t[0] * 100 : null ) );
		return array(
			'colonnes' => array( array( 'Mois', 'txt' ), array( 'Produits', 'mt' ), array( 'Charges', 'mt' ), array( 'Hors activités ordinaires', 'mt' ), array( 'Résultat', 'mt' ), array( 'Marge nette', 'pct' ) ),
			'lignes' => $lignes,
			'notes' => array( 'Classes 6, 7 et 8, hors écriture de détermination du résultat.' ),
		);
	}

	protected static function r_charges_nature( $du, $au, $o ) {
		$du1 = FKC_Marge::moinsUnAn( $du ); $au1 = FKC_Marge::moinsUnAn( $au );
		$hc = FKC_Metrics::horsCloture( 'e' );
		$q = function ( $d1, $d2 ) use ( $hc ) {
			$o = array();
			foreach ( FKC_DB::q( "SELECT c.numero, c.libelle, SUM(l.debit-l.credit) v FROM ecriture_lignes l
				JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
				WHERE e.date_ecriture BETWEEN ? AND ? {$hc} AND c.numero LIKE '6%' GROUP BY c.numero", array( $d1, $d2 ) )->fetchAll() as $r ) {
				$o[ (string) $r['numero'] ] = array( $r['libelle'], (float) $r['v'] );
			}
			return $o;
		};
		$n = $q( $du, $au ); $p = $q( $du1, $au1 );
		$tot = 0.0; foreach ( $n as $x ) { $tot += $x[1]; }
		$tot1 = 0.0; foreach ( $p as $x ) { $tot1 += $x[1]; }
		$nums = array_unique( array_merge( array_keys( $n ), array_keys( $p ) ) );
		usort( $nums, function ( $a, $b ) use ( $n ) { return ( $n[ $b ][1] ?? 0 ) <=> ( $n[ $a ][1] ?? 0 ) ?: strcmp( $a, $b ); } );
		$lignes = array();
		foreach ( $nums as $num ) {
			$v = $n[ $num ][1] ?? 0.0; $v1 = $p[ $num ][1] ?? 0.0;
			if ( abs( $v ) < 0.5 && abs( $v1 ) < 0.5 ) { continue; }
			$lib = $n[ $num ][0] ?? $p[ $num ][0];
			$lignes[] = array( 's' => '', 'c' => array( $num, $lib, $v, $tot > 0 ? $v / $tot * 100 : null, $v1, FKC_Marge::variation( $v, $v1 ) ), 'lien' => FKC_Marge::lienGrandLivre( array( $num ), $du, $au ) );
		}
		$lignes[] = array( 's' => 'total', 'c' => array( '', 'Total des charges', $tot, $tot > 0 ? 100.0 : null, $tot1, FKC_Marge::variation( $tot, $tot1 ) ) );
		return array(
			'colonnes' => array( array( 'Compte', 'txt' ), array( 'Intitulé', 'txt' ), array( 'Période', 'mt' ), array( 'Part', 'pct' ), array( 'N-1', 'mt' ), array( 'Variation', 'var' ) ),
			'lignes' => $lignes,
			'notes' => array( 'Comptes de classe 6, hors écriture de détermination du résultat. N-1 : du ' . date( 'd/m/Y', strtotime( $du1 ) ) . ' au ' . date( 'd/m/Y', strtotime( $au1 ) ) . '.' ),
		);
	}

	protected static function r_marge_axe( $du, $au, $o ) {
		$an = FKC_Metrics::exerciceDe( $du );
		$pa = FKC_Marge::parAxe( (int) ( $o['axe'] ?? 0 ), $an );
		if ( ! $pa ) { return array( 'colonnes' => array( array( 'Section', 'txt' ) ), 'lignes' => array(), 'notes' => array( 'Analytique indisponible.' ) ); }
		$lignes = array();
		foreach ( array_merge( $pa['lignes'], $pa['non_affecte'] ? array( $pa['non_affecte'] ) : array() ) as $l ) {
			$lignes[] = array( 's' => 0 === (int) $l['valeur_id'] ? 'muted' : '', 'c' => array( $l['libelle'], '—' === $l['code'] ? '' : (string) $l['code'], $l['produits'], $l['charges'], $l['marge'], $l['taux'] ) );
		}
		$t = $pa['totaux'];
		$lignes[] = array( 's' => 'total', 'c' => array( 'Total', '', $t['produits'], $t['charges'], $t['marge'], $t['taux'] ) );
		$notes = array( 'Exercice ' . FKC_Exercice::libelle( $an ) . ' entier : l\'analytique se lit par exercice. Marge = produits − charges de gestion affectés (hors HAO).' );
		if ( null !== $pa['couverture'] ) { $notes[] = 'Couverture de l\'axe : ' . (int) $pa['couverture'] . ' % du mouvement.'; }
		return array(
			'titre' => 'Marge par ' . mb_strtolower( $pa['axe']['libelle'] ),
			'periode' => 'Exercice ' . FKC_Exercice::libelle( $an ),
			'colonnes' => array( array( 'Section', 'txt' ), array( 'Code', 'txt' ), array( 'Produits', 'mt' ), array( 'Charges', 'mt' ), array( 'Marge', 'mt' ), array( 'Taux', 'pct' ) ),
			'lignes' => $lignes, 'notes' => $notes, 'axe_id' => (int) $pa['axe']['id'],
		);
	}

	protected static function r_marge_article( $du, $au, $o ) {
		$a = FKC_Marge::articles( $du, $au, 100000 );
		$lignes = array();
		if ( $a ) {
			foreach ( $a['toutes'] as $l ) {
				$lignes[] = array( 's' => '', 'c' => array( $l['designation'] . ( $l['sans_cout'] ? ' (coût inconnu)' : '' ), (string) $l['code'], $l['qte'], $l['ca'], $l['cout'], $l['marge'], $l['taux'] ) );
			}
			$t = $a['totaux'];
			$lignes[] = array( 's' => 'total', 'c' => array( 'Total', '', null, $t['ca'], $t['cout'], $t['marge'], $t['taux'] ) );
		}
		return array(
			'colonnes' => array( array( 'Article', 'txt' ), array( 'Code', 'txt' ), array( 'Qté', 'qte' ), array( 'Ventes HT', 'mt' ), array( 'Coût', 'mt' ), array( 'Marge', 'mt' ), array( 'Taux', 'pct' ) ),
			'lignes' => $lignes,
			'notes' => array( 'Ventes encaissées en caisse, hors taxes, après remises, retours déduits ; coût = CUMP au moment de la vente. Les ventes par facture ne sont pas rattachées aux articles.' ),
		);
	}

	protected static function r_ca_clients( $du, $au, $o ) {
		$rows = FKC_Metrics::topClients( $du, $au, 100000 );
		/* Nombre de factures par client — même filtre et même regroupement que topClients(), avoirs exclus du compte. */
		$nb = array();
		try {
			if ( FKC_Metrics::tableExists( 'factures' ) ) {
				$joinCli = FKC_Metrics::tableExists( 'clients' ) ? 'LEFT JOIN clients cl ON cl.id = f.client_id' : '';
				$nom = $joinCli ? "COALESCE(NULLIF(cl.nom,''), NULLIF(f.client_nom,''), '(sans client)')" : "COALESCE(NULLIF(f.client_nom,''),'(sans client)')";
				foreach ( FKC_DB::q( "SELECT {$nom} nom, SUM(CASE WHEN f.montant_ht > 0 THEN 1 ELSE 0 END) n FROM factures f {$joinCli}
					WHERE " . FKC_Metrics::sqlFacturesValides( 'f' ) . " AND f.date_facture BETWEEN ? AND ?
					GROUP BY COALESCE(CAST(f.client_id AS TEXT), 'n:' || COALESCE(f.client_nom,''))", array( $du, $au ) )->fetchAll() as $r ) {
					$nb[ $r['nom'] ] = ( $nb[ $r['nom'] ] ?? 0 ) + (int) $r['n'];
				}
			}
		} catch ( \Throwable $e ) { $nb = array(); }
		$tot = 0.0; foreach ( $rows as $r ) { $tot += (float) $r['v']; }
		$lignes = array(); $cumul = 0.0;
		foreach ( $rows as $r ) {
			$cumul += (float) $r['v'];
			$lignes[] = array( 's' => '', 'c' => array( $r['nom'], $nb[ $r['nom'] ] ?? null, (float) $r['v'], $tot > 0 ? (float) $r['v'] / $tot * 100 : null, $tot > 0 ? $cumul / $tot * 100 : null ) );
		}
		$lignes[] = array( 's' => 'total', 'c' => array( 'Total (' . count( $rows ) . ' client' . ( count( $rows ) > 1 ? 's' : '' ) . ')', array_sum( $nb ), $tot, $tot > 0 ? 100.0 : null, null ) );
		return array(
			'colonnes' => array( array( 'Client', 'txt' ), array( 'Factures', 'qte' ), array( 'CA facturé HT', 'mt' ), array( 'Part', 'pct' ), array( 'Part cumulée', 'pct' ) ),
			'lignes' => $lignes,
			'notes' => array( 'Factures validées de la période (hors brouillons et annulées), avoirs déduits ; clients regroupés par fiche. La part cumulée montre la concentration du portefeuille.' ),
		);
	}

	protected static function r_balance_agee( $du, $au, $o ) {
		$cols = array( array( 'Client', 'txt' ), array( 'Non échu', 'mt' ), array( '0-30 j', 'mt' ), array( '31-60 j', 'mt' ), array( '61-90 j', 'mt' ), array( '+90 j', 'mt' ), array( 'Encours', 'mt' ) );
		if ( ! class_exists( 'FKC_Recouvrement' ) || ! FKC_Metrics::tableExists( 'factures' ) ) {
			return array( 'colonnes' => $cols, 'lignes' => array(), 'notes' => array( 'Le module Recouvrement n\'est pas disponible : la balance âgée ne peut pas déduire les règlements.' ) );
		}
		try { $rc = FKC_Recouvrement::compute( true ); } catch ( \Throwable $e ) { $rc = array( 'clients' => array() ); }
		$k = array( 'courant', 'b0_30', 'b31_60', 'b61_90', 'b90p' );
		$lignes = array(); $t = array_fill( 0, 6, 0.0 );
		$cl = array_values( array_filter( (array) $rc['clients'], function ( $c ) { return abs( (float) $c['encours'] ) >= 0.5; } ) );
		usort( $cl, function ( $a, $b ) { return (float) $b['encours'] <=> (float) $a['encours']; } );
		foreach ( $cl as $c ) {
			$cells = array( $c['nom'] );
			foreach ( $k as $i => $kk ) { $v = (float) ( $c['buckets'][ $kk ] ?? 0 ); $cells[] = $v; $t[ $i ] += $v; }
			$cells[] = (float) $c['encours']; $t[5] += (float) $c['encours'];
			$lignes[] = array( 's' => (float) ( $c['buckets']['b90p'] ?? 0 ) > 0.5 ? 'alerte' : '', 'c' => $cells );
		}
		$lignes[] = array( 's' => 'total', 'c' => array_merge( array( 'Total' ), $t ) );
		return array(
			'colonnes' => $cols, 'lignes' => $lignes,
			'notes' => array( 'Factures émises, règlements déduits, ancienneté comptée depuis l\'échéance. En rouge : clients ayant des créances de plus de 90 jours.' ),
		);
	}

	public static function moisLong( $ym ) {
		$m = array( 1 => 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre' );
		return $m[ (int) substr( $ym, 5, 2 ) ] . ' ' . substr( $ym, 0, 4 );
	}

	/* ═══════════════ Sorties ═══════════════ */

	/** Cellule mise en forme pour l'écran et l'impression. */
	public static function formater( $v, $type ) {
		if ( null === $v || '' === $v ) { return 'txt' === $type ? '' : '—'; }
		switch ( $type ) {
			case 'mt':  return fkc_money( round( (float) $v ) );
			case 'pct': return str_replace( '.', ',', number_format( (float) $v, 1, '.', ' ' ) ) . ' %';
			case 'var': return ( $v > 0.049 ? '+' : '' ) . str_replace( '.', ',', number_format( (float) $v, 1, '.', ' ' ) ) . ' %';
			case 'qte': return rtrim( rtrim( number_format( (float) $v, 2, ',', ' ' ), '0' ), ',' );
			default:    return (string) $v;
		}
	}

	/**
	 * Lignes CSV : en-tête d'identification, colonnes, données BRUTES (un
	 * montant reste un nombre qu'un tableur sait additionner), notes.
	 * Toute cellule texte passe par la neutralisation des formules.
	 */
	public static function csv( array $r ) {
		$soc = class_exists( 'FKC_Tenant' ) ? ( FKC_Tenant::current()['raison_sociale'] ?? '' ) : '';
		$rows = array( array( self::cellule( $r['titre'] ) ), array( self::cellule( $r['periode'] ) ) );
		if ( $soc ) { $rows[] = array( self::cellule( $soc ) ); }
		$rows[] = array();
		$rows[] = array_map( function ( $c ) { return self::cellule( $c[0] ); }, $r['colonnes'] );
		foreach ( $r['lignes'] as $l ) {
			$ligne = array();
			foreach ( $l['c'] as $i => $v ) {
				$type = $r['colonnes'][ $i ][1] ?? 'txt';
				if ( null === $v ) { $ligne[] = ''; continue; }
				if ( 'txt' === $type ) { $ligne[] = self::cellule( (string) $v ); continue; }
				$ligne[] = str_replace( '.', ',', (string) round( (float) $v, in_array( $type, array( 'pct', 'var' ), true ) ? 1 : 2 ) );
			}
			$rows[] = $ligne;
		}
		if ( $r['notes'] ) { $rows[] = array(); foreach ( $r['notes'] as $n ) { $rows[] = array( self::cellule( $n ) ); } }
		return $rows;
	}

	/** Neutralise une cellule qu'un tableur prendrait pour une formule. */
	public static function cellule( $s ) {
		$s = (string) $s;
		return ( '' !== $s && false !== strpos( "=+-@\t\r", $s[0] ) ) ? "'" . $s : $s;
	}

	public static function nomFichier( array $r ) {
		$slug = function ( $s ) {
			$s = strtolower( strtr( (string) $s, array( 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'à' => 'a', 'â' => 'a', 'ô' => 'o', 'î' => 'i', 'ï' => 'i', 'û' => 'u', 'ù' => 'u', 'ç' => 'c', 'É' => 'e', 'œ' => 'oe' ) ) );
			return trim( preg_replace( '/[^a-z0-9]+/', '-', $s ), '-' );
		};
		return 'rapport-' . $slug( $r['titre'] ) . ( $r['du'] ? '-' . $r['du'] . '-au-' . $r['au'] : '-' . date( 'Y-m-d' ) ) . '.csv';
	}

	/* ═══════════════ Rapports enregistrés (Enterprise) ═══════════════ */

	protected static function table() {
		FKC_DB::conn()->exec( "CREATE TABLE IF NOT EXISTS analyse_rapports(
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			nom TEXT NOT NULL,
			code TEXT NOT NULL,
			periode TEXT NOT NULL DEFAULT 'exercice',
			du TEXT, au TEXT,
			options TEXT,
			created_by INTEGER, auteur TEXT,
			created_at TEXT DEFAULT(datetime('now','localtime'))
		)" );
	}

	public static function enregistres() {
		self::table();
		return FKC_DB::q( 'SELECT * FROM analyse_rapports ORDER BY nom COLLATE NOCASE, id' )->fetchAll();
	}

	public static function trouver( $id ) {
		self::table();
		return FKC_DB::q( 'SELECT * FROM analyse_rapports WHERE id=?', array( (int) $id ) )->fetch() ?: null;
	}

	/** @return array{0:bool,1:string,2:int} */
	public static function enregistrer( array $d ) {
		self::table();
		$nom = trim( (string) ( $d['nom'] ?? '' ) );
		$code = (string) ( $d['code'] ?? '' );
		$per = (string) ( $d['periode'] ?? 'exercice' );
		if ( '' === $nom ) { return array( false, 'Donnez un nom au rapport.', 0 ); }
		if ( mb_strlen( $nom ) > 120 ) { $nom = mb_substr( $nom, 0, 120 ); }
		if ( ! isset( self::catalogue()[ $code ] ) ) { return array( false, 'Rapport inconnu.', 0 ); }
		if ( ! isset( self::periodesRelatives()[ $per ] ) ) { $per = 'exercice'; }
		$du = $au = null;
		if ( 'fixe' === $per ) {
			$du = self::date( $d['du'] ?? '' ); $au = self::date( $d['au'] ?? '' );
			if ( ! $du || ! $au || $du > $au ) { return array( false, 'Dates fixes invalides.', 0 ); }
		}
		$opts = array();
		if ( ! empty( $d['axe'] ) ) { $opts['axe'] = (int) $d['axe']; }
		$u = FKC_Auth::check() ? FKC_Auth::user() : null;
		FKC_DB::q( 'INSERT INTO analyse_rapports(nom,code,periode,du,au,options,created_by,auteur) VALUES(?,?,?,?,?,?,?,?)',
			array( $nom, $code, $per, $du, $au, $opts ? json_encode( $opts ) : null, FKC_Auth::id(), $u['nom_complet'] ?? null ) );
		return array( true, 'Rapport « ' . $nom . ' » enregistré.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function supprimer( $id ) {
		self::table();
		FKC_DB::q( 'DELETE FROM analyse_rapports WHERE id=?', array( (int) $id ) );
	}

	/** Adresse d'affichage d'un rapport enregistré, période résolue au jour de l'ouverture. */
	public static function lien( array $s, $ref = null ) {
		list( $du, $au ) = self::resoudrePeriode( $s['periode'], $s['du'], $s['au'], $ref );
		$q = array( 'code' => $s['code'], 'du' => $du, 'au' => $au );
		$o = json_decode( (string) $s['options'], true );
		if ( ! empty( $o['axe'] ) ) { $q['axe'] = (int) $o['axe']; }
		return 'analyse/rapports/voir?' . http_build_query( $q );
	}

	protected static function date( $s ) {
		$s = trim( (string) $s );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s ) && strtotime( $s ) ? $s : null;
	}
}
