<?php
/** Moteur de métriques transversal (lecture défensive multi-modules) — module Analyse. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Metrics {

	/** Métriques additionnelles enregistrées par les packs métier. */
	protected static $externes = array();

	/**
	 * Enregistre une métrique métier (appelé depuis le hooks.php d'un pack).
	 * @param string   $cle     identifiant unique (ex. 'retail_ca_jour')
	 * @param string   $libelle libellé lisible
	 * @param callable $fn      fonction retournant la valeur numérique
	 * @param array    $meta    optionnel : unite, categorie, sens ('hausse'|'baisse'), format
	 */
	public static function register( $cle, $libelle, $fn, array $meta = array() ) {
		self::$externes[ $cle ] = array( $libelle, $fn, $meta );
	}

	/** Métriques enregistrées par les packs (avec métadonnées). */
	public static function externes() { return self::$externes; }

	/* ── Utilitaires sûrs ── */
	public static function tableExists( $t ) {
		try { return (bool) FKC_DB::q( "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", array( $t ) )->fetch(); }
		catch ( \Throwable $e ) { return false; }
	}
	protected static function val( $sql, $p = array(), $def = 0 ) {
		try { $v = FKC_DB::q( $sql, $p )->fetchColumn(); return ( false === $v || null === $v ) ? $def : $v; }
		catch ( \Throwable $e ) { return $def; }
	}
	protected static function rows( $sql, $p = array() ) {
		try { return FKC_DB::q( $sql, $p )->fetchAll(); } catch ( \Throwable $e ) { return array(); }
	}
	/** Liste des N derniers mois (YYYY-MM). */
	public static function mois( $n = 12 ) {
		$out = array(); for ( $i = $n - 1; $i >= 0; $i-- ) { $out[] = date( 'Y-m', strtotime( "first day of -$i month" ) ); } return $out;
	}
	/** Liste des mois (YYYY-MM) entre deux dates incluses (borné à 48). */
	public static function moisRange( $du, $au ) {
		$out = array();
		$d = strtotime( substr( (string) $du, 0, 7 ) . '-01' );
		$end = strtotime( substr( (string) $au, 0, 7 ) . '-01' );
		$g = 0;
		while ( $d && $end && $d <= $end && $g < 48 ) { $out[] = date( 'Y-m', $d ); $d = strtotime( '+1 month', $d ); $g++; }
		return $out ?: array( date( 'Y-m' ) );
	}
	protected static function serieMoisRange( $rows, $du, $au ) {
		$base = array_fill_keys( self::moisRange( $du, $au ), 0 );
		foreach ( $rows as $r ) { if ( isset( $base[ $r['mois'] ] ) ) { $base[ $r['mois'] ] = (float) $r['v']; } }
		return $base;
	}
	/**
	 * Normalise une période. Défaut : l'EXERCICE EN COURS (1.832.0).
	 *
	 * C'était l'année civile : sur un exercice décalé (juillet → juin), les
	 * écrans d'analyse coupaient l'exercice en deux et additionnaient deux
	 * moitiés d'exercices différents.
	 */
	public static function bornes( $du = null, $au = null ) {
		list( $d0, $a0 ) = self::exercice();
		// Une question posée à Maestro (« le mois dernier ») fixe la période des calculs qu'elle déclenche.
		if ( ( null === $du || null === $au ) && class_exists( 'FKC_Maestro_Context' ) && method_exists( 'FKC_Maestro_Context', 'periodeDemandee' ) ) {
			$q = FKC_Maestro_Context::periodeDemandee();
			if ( $q ) { list( $d0, $a0 ) = $q; }
		}
		$du = ( $du && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $du ) ) ? $du : $d0;
		$au = ( $au && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $au ) ) ? $au : $a0;
		if ( $au < $du ) { $t = $du; $du = $au; $au = $t; }
		return array( $du, $au );
	}

	/** Bornes d'un exercice (défaut : l'exercice en cours), décalé compris. */
	public static function exercice( $annee = null ) {
		$annee = null === $annee
			? ( class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::courant() : date( 'Y' ) )
			: (string) $annee;
		if ( class_exists( 'FKC_Division' ) && method_exists( 'FKC_Division', 'bornes' ) ) {
			$b = FKC_Division::bornes( $annee );
			if ( $b ) { return array( $b[0], $b[1] ); }
		}
		return array( $annee . '-01-01', $annee . '-12-31' );
	}

	/** Millésime de l'exercice auquel appartient une date. */
	public static function exerciceDe( $date ) {
		return class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::annee( $date ) : substr( (string) $date, 0, 4 );
	}

	/**
	 * Raccourcis de période, calés sur l'exercice qui contient $date :
	 * trimestres et semestres DE L'EXERCICE (T1 = ses trois premiers mois,
	 * juillet-septembre sur un exercice ouvert au 1er juillet), l'exercice
	 * entier, le précédent, et les douze derniers mois.
	 * @return array [ [libelle, du, au, titre] … ]
	 */
	public static function raccourcis( $date = null ) {
		$an = self::exerciceDe( $date ?: date( 'Y-m-d' ) );
		list( $d0, $a0 ) = self::exercice( $an );
		$mois = array( 1 => 'janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.' );
		$fin = function ( $debut, $n ) { return date( 'Y-m-t', strtotime( $debut . ' +' . ( $n - 1 ) . ' month' ) ); };
		$lib = function ( $d, $a ) use ( $mois ) { return $mois[ (int) substr( $d, 5, 2 ) ] . '–' . $mois[ (int) substr( $a, 5, 2 ) ]; };
		$out = array();
		for ( $t = 0; $t < 4; $t++ ) {
			$d = date( 'Y-m-01', strtotime( $d0 . ' +' . ( 3 * $t ) . ' month' ) );
			$a = $fin( $d, 3 );
			$out[] = array( 'T' . ( $t + 1 ), $d, $a, $lib( $d, $a ) );
		}
		foreach ( array( 1 => 0, 2 => 6 ) as $sx => $dec ) {
			$d = date( 'Y-m-01', strtotime( $d0 . ' +' . $dec . ' month' ) );
			$a = $fin( $d, 6 );
			$out[] = array( 'S' . $sx, $d, $a, $lib( $d, $a ) );
		}
		$out[] = array( 'Exercice ' . $an, $d0, $a0, class_exists( 'FKC_Exercice' ) ? FKC_Exercice::libelle( $an ) : $an );
		list( $p0, $p1 ) = self::exercice( (string) ( (int) $an - 1 ) );
		$out[] = array( 'Exercice ' . ( (int) $an - 1 ), $p0, $p1, 'Exercice précédent' );
		$out[] = array( '12 derniers mois', date( 'Y-m-01', strtotime( 'first day of -11 month' ) ), date( 'Y-m-t' ), 'Glissant' );
		return $out;
	}

	/**
	 * Filtre SQL « hors écriture de clôture » (1.832.0) sur l'alias d'écriture.
	 * La détermination du résultat solde les classes 6, 7 et 8 : la compter
	 * annulait l'exercice (produits 0, charges 0, marge 0 %) et faisait
	 * plonger le dernier mois.
	 */
	public static function horsCloture( $alias = 'e' ) {
		if ( class_exists( 'FKC_Division' ) && method_exists( 'FKC_Division', 'horsCloture' ) ) { return FKC_Division::horsCloture( $alias ); }
		return '';
	}

	/** Mémo des calculs de la requête : un KPI ou une alerte ne relance plus toute l'analyse. */
	protected static $memo = array();
	protected static function memo( $cle, $fn ) {
		/*
		 * Valable tant que rien n'a été écrit sur la connexion : total_changes()
		 * compte les lignes modifiées depuis son ouverture. Une écriture passée
		 * entre deux lectures (même requête, tests, traitements en lot) relance
		 * donc le calcul — jamais de chiffre périmé.
		 */
		try { $v = spl_object_id( FKC_DB::conn() ) . ':' . (string) FKC_DB::q( 'SELECT total_changes()' )->fetchColumn(); } // + la connexion : changer de société change de base
		catch ( \Throwable $e ) { return $fn(); }
		$cle .= '|' . $v;
		if ( ! array_key_exists( $cle, self::$memo ) ) {
			if ( count( self::$memo ) > 50 ) { self::$memo = array(); }
			self::$memo[ $cle ] = $fn();
		}
		return self::$memo[ $cle ];
	}
	/** Vide le mémo (après une écriture dans la même requête, tests). */
	public static function oublier() { self::$memo = array(); }

	protected static function serieMois( $rows, $n = 12 ) {
		$base = array_fill_keys( self::mois( $n ), 0 );
		foreach ( $rows as $r ) { if ( isset( $base[ $r['mois'] ] ) ) { $base[ $r['mois'] ] = (float) $r['v']; } }
		return $base;
	}

	/* ── 1. Finance (écritures × comptes) ── */
	/**
	 * Produits (classe 7), charges (classe 6), HAO (classe 8), résultat NET.
	 *
	 * 1.832.0 : écriture de clôture exclue ; classe lue sur le numéro de
	 * compte (comme les états DGI) ; classe 8 comptée — « Résultat net »
	 * ignorait l'impôt sur le résultat et les cessions. `resultat_ao` garde le
	 * résultat des activités ordinaires (7 − 6).
	 */
	public static function finance( $du = null, $au = null ) {
		if ( ! self::tableExists( 'ecriture_lignes' ) || ! self::tableExists( 'comptes' ) ) { return null; }
		list( $du, $au ) = self::bornes( $du, $au );
		return self::memo( 'finance|' . $du . '|' . $au, function () use ( $du, $au ) {
			$hc = self::horsCloture( 'e' );
			$base = "FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id WHERE e.date_ecriture BETWEEN ? AND ? {$hc}";
			$sens = "CASE WHEN c.numero LIKE '6%' THEN l.debit-l.credit ELSE l.credit-l.debit END";
			$tot = array( '6' => 0.0, '7' => 0.0, '8' => 0.0 );
			$mois = array( '6' => array(), '7' => array(), '8' => array() );
			foreach ( self::rows( "SELECT substr(c.numero,1,1) cl, substr(e.date_ecriture,1,7) mois, SUM({$sens}) v {$base}
				AND ( c.numero LIKE '6%' OR c.numero LIKE '7%' OR c.numero LIKE '8%' ) GROUP BY cl, mois", array( $du, $au ) ) as $r ) {
				$tot[ $r['cl'] ] += (float) $r['v'];
				$mois[ $r['cl'] ][] = array( 'mois' => $r['mois'], 'v' => $r['v'] );
			}
			$pm = self::serieMoisRange( $mois['7'], $du, $au );
			$cm = self::serieMoisRange( $mois['6'], $du, $au );
			$hm = self::serieMoisRange( $mois['8'], $du, $au );
			$rm = array(); foreach ( $pm as $m => $v ) { $rm[ $m ] = $v - ( $cm[ $m ] ?? 0 ) + ( $hm[ $m ] ?? 0 ); }
			$charges = self::rows( "SELECT c.numero, c.libelle, SUM(l.debit-l.credit) v {$base} AND c.numero LIKE '6%' GROUP BY c.id HAVING v>0 ORDER BY v DESC LIMIT 6", array( $du, $au ) );
			$prod = $tot['7']; $chg = $tot['6']; $hao = $tot['8'];
			return array(
				'produits' => $prod, 'charges' => $chg, 'hao' => $hao,
				'resultat_ao' => $prod - $chg, 'resultat' => $prod - $chg + $hao,
				'marge' => $prod > 0 ? ( $prod - $chg + $hao ) / $prod * 100 : 0,
				'produits_mois' => $pm, 'charges_mois' => $cm, 'hao_mois' => $hm, 'resultat_mois' => $rm,
				'top_charges' => $charges, 'du' => $du, 'au' => $au,
			);
		} );
	}

	/**
	 * Résultat net du compte de résultat (même source que les états DGI) sur
	 * la période, pour afficher le rapprochement plutôt que de le supposer.
	 * @return array{cr:float,analyse:float,ecart:float}|null
	 */
	public static function rapprochement( $fin ) {
		if ( ! is_array( $fin ) || ! class_exists( 'FKC_EtatsDgi' ) || ! method_exists( 'FKC_EtatsDgi', 'sigBruts' ) ) { return null; }
		try { $cr = (float) ( FKC_EtatsDgi::sigBruts( $fin['du'], $fin['au'] )['XI'] ?? 0 ); } catch ( \Throwable $e ) { return null; }
		return array( 'cr' => $cr, 'analyse' => (float) $fin['resultat'], 'ecart' => round( (float) $fin['resultat'] - $cr, 2 ) );
	}

	/**
	 * Trésorerie nette à une date (défaut : aujourd'hui) : classe 5, sans les
	 * dépréciations (59), qui ne sont pas de l'argent.
	 */
	public static function tresorerie( $au = null ) {
		if ( ! self::tableExists( 'ecriture_lignes' ) || ! self::tableExists( 'comptes' ) ) { return 0.0; }
		$au = ( $au && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $au ) ) ? $au : date( 'Y-m-d' );
		return (float) self::val( "SELECT COALESCE(SUM(l.debit-l.credit),0) FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id WHERE c.numero LIKE '5%' AND c.numero NOT LIKE '59%' AND e.date_ecriture<=?", array( $au ) );
	}

	/* ── 2. Commercial ── */
	/** Factures qui comptent : ni brouillon, ni annulée (les avoirs, négatifs, se déduisent). */
	public static function sqlFacturesValides( $alias = '' ) {
		$a = '' === $alias ? '' : $alias . '.';
		return " LOWER(COALESCE({$a}statut,'')) NOT IN ('brouillon','annulee','annulée') AND LOWER(COALESCE({$a}statut,'')) NOT LIKE 'annul%' ";
	}

	/**
	 * Chiffre d'affaires et activité commerciale.
	 *
	 * 1.832.0 — le CA est lu en COMPTABILITÉ (comptes 70, hors clôture) : il
	 * comprend les ventes en caisse, que les factures ignorent, et il se
	 * compare enfin au résultat et à la marge, lus au même endroit. Les
	 * factures (hors brouillons — elles comptaient) donnent le nombre, le
	 * panier et le classement des clients. Sans comptabilité, repli sur les
	 * factures, annoncé.
	 */
	public static function commercial( $du = null, $au = null ) {
		list( $du, $au ) = self::bornes( $du, $au );
		return self::memo( 'commercial|' . $du . '|' . $au, function () use ( $du, $au ) {
			$aFact = self::tableExists( 'factures' );
			$aCompta = self::tableExists( 'ecriture_lignes' ) && self::tableExists( 'comptes' );
			if ( ! $aFact && ! $aCompta ) { return null; }
			$hc = self::horsCloture( 'e' );
			$ca = 0.0; $caM = array();
			if ( $aCompta ) {
				$rows = self::rows( "SELECT substr(e.date_ecriture,1,7) mois, SUM(l.credit-l.debit) v FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
					WHERE c.numero LIKE '70%' AND e.date_ecriture BETWEEN ? AND ? {$hc} GROUP BY mois", array( $du, $au ) );
				foreach ( $rows as $r ) { $ca += (float) $r['v']; }
				$caM = self::serieMoisRange( $rows, $du, $au );
			}
			$v = self::sqlFacturesValides();
			$caF = 0.0; $nb = 0; $top = array(); $caFM = array();
			if ( $aFact ) {
				$caF = (float) self::val( "SELECT COALESCE(SUM(montant_ht),0) FROM factures WHERE {$v} AND date_facture BETWEEN ? AND ?", array( $du, $au ) );
				$nb = (int) self::val( "SELECT COUNT(*) FROM factures WHERE {$v} AND COALESCE(type,'facture')<>'avoir' AND date_facture BETWEEN ? AND ?", array( $du, $au ) );
				$caFM = self::serieMoisRange( self::rows( "SELECT substr(date_facture,1,7) mois, SUM(montant_ht) v FROM factures WHERE {$v} AND date_facture BETWEEN ? AND ? GROUP BY mois", array( $du, $au ) ), $du, $au );
				$top = self::topClients( $du, $au, 6 );
			}
			$source = 'compta';
			if ( abs( $ca ) < 0.5 && abs( $caF ) >= 0.5 ) { $ca = $caF; $caM = $caFM; $source = 'factures'; }
			return array(
				'ca' => $ca, 'ca_facture' => $caF, 'nb_factures' => $nb, 'panier' => $nb ? $caF / $nb : 0,
				'ca_mois' => $caM ?: array_fill_keys( self::moisRange( $du, $au ), 0 ), 'top_clients' => $top,
				'source' => $source, 'du' => $du, 'au' => $au,
			);
		} );
	}

	/** Meilleurs clients (factures valides), regroupés par FICHE client — plus par nom saisi. */
	public static function topClients( $du = null, $au = null, $n = 6 ) {
		if ( ! self::tableExists( 'factures' ) ) { return array(); }
		$v = self::sqlFacturesValides( 'f' );
		$periode = ''; $p = array();
		if ( null !== $du ) { list( $du, $au ) = self::bornes( $du, $au ); $periode = ' AND f.date_facture BETWEEN ? AND ? '; $p = array( $du, $au ); }
		$joinCli = self::tableExists( 'clients' ) ? 'LEFT JOIN clients cl ON cl.id = f.client_id' : '';
		$nom = $joinCli ? "COALESCE(NULLIF(cl.nom,''), NULLIF(f.client_nom,''), '(sans client)')" : "COALESCE(NULLIF(f.client_nom,''),'(sans client)')";
		return self::rows( "SELECT {$nom} nom, SUM(f.montant_ht) v FROM factures f {$joinCli}
			WHERE {$v} {$periode} GROUP BY COALESCE(CAST(f.client_id AS TEXT), 'n:' || COALESCE(f.client_nom,'')) HAVING v <> 0 ORDER BY v DESC LIMIT " . (int) $n, $p );
	}

	/* ── 3. Clients ── */
	public static function clients() {
		if ( ! self::tableExists( 'clients' ) ) { return null; }
		$nb = (int) self::val( 'SELECT COUNT(*) FROM clients' );
		$types = self::rows( "SELECT COALESCE(NULLIF(type,''),'Autre') nom, COUNT(*) v FROM clients GROUP BY type ORDER BY v DESC" );
		$top = self::topClients( null, null, 8 );
		return array( 'nb' => $nb, 'types' => $types, 'top' => $top );
	}

	/* ── 4. Recouvrement (créances impayées + balance âgée) ── */
	/**
	 * DEUX MODULES DISAIENT DEUX CHIFFRES DIFFÉRENTS POUR LA MÊME CHOSE.
	 *
	 * Cet écran refiltrait les factures pour son compte, sur des statuts —
	 * « %PAY% », « %REGL% » — qui n'existent nulle part dans le produit :
	 * `factures.statut` ne vaut jamais que brouillon, validee, certifiee, emise
	 * ou annulee. Aucune facture n'était donc jamais écartée, ET SURTOUT aucun
	 * règlement n'était déduit : l'« Analyse recouvrement » annonçait le TOTAL
	 * FACTURÉ sous le nom de « créances ».
	 *
	 * Un dirigeant qui ouvrait les deux écrans lisait deux montants, sans moyen
	 * de savoir lequel croire — et c'est le plus gros des deux qui inquiète.
	 *
	 * Le module Recouvrement fait autorité : il lettre les encaissements en
	 * FIFO, écarte les avoirs et les brouillons, et connaît le délai de paiement
	 * de chaque client. On le lit quand il est là. Le calcul historique reste en
	 * repli pour les éditions où il n'est pas activé — mais il est désormais
	 * annoncé pour ce qu'il est : une approximation.
	 */
	public static function recouvrement() {
		if ( ! self::tableExists( 'factures' ) ) { return null; }
		if ( class_exists( 'FKC_Recouvrement' ) ) {
			try {
				$k = FKC_Recouvrement::compute()['kpis'];
				$dossiers = self::tableExists( 'recouvrement_dossiers' )
					? (int) self::val( "SELECT COUNT(*) FROM recouvrement_dossiers WHERE statut<>'clos'" ) : 0;
				$aging = array();
				foreach ( array( 'courant' => 'Non échu', 'b0_30' => '0-30 j', 'b31_60' => '31-60 j',
					'b61_90' => '61-90 j', 'b90p' => '+90 j' ) as $kk => $lib ) {
					$aging[ $lib ] = (float) ( $k['aging'][ $kk ] ?? 0 );
				}
				return array(
					'creances' => (float) $k['encours'], 'aging' => $aging,
					'en_retard' => (float) $k['retard'], 'dossiers' => $dossiers,
					'dso' => (int) ( $k['dso'] ?? 0 ), 'taux' => (float) ( $k['taux'] ?? 0 ),
					'a_relancer' => (float) ( $k['a_relancer'] ?? 0 ),
					'sous_accord' => (float) ( $k['sous_accord'] ?? 0 ),
					'source' => 'recouvrement',
				);
			} catch ( \Throwable $e ) { /* repli ci-dessous */ }
		}
		$imp = "statut NOT LIKE 'ANNUL%' AND statut NOT LIKE 'annul%' AND LOWER(statut) NOT IN ('brouillon','devis','proforma')";
		$rows = self::rows( "SELECT montant_ttc m, echeance FROM factures WHERE $imp" );
		$buckets = array( 'Non échu' => 0, '0-30 j' => 0, '31-60 j' => 0, '61-90 j' => 0, '+90 j' => 0 );
		$total = 0;
		foreach ( $rows as $r ) {
			$m = (float) $r['m']; $total += $m;
			$j = $r['echeance'] ? floor( ( time() - strtotime( $r['echeance'] ) ) / 86400 ) : 0;
			if ( $j <= 0 ) { $buckets['Non échu'] += $m; }
			elseif ( $j <= 30 ) { $buckets['0-30 j'] += $m; }
			elseif ( $j <= 60 ) { $buckets['31-60 j'] += $m; }
			elseif ( $j <= 90 ) { $buckets['61-90 j'] += $m; }
			else { $buckets['+90 j'] += $m; }
		}
		$dossiers = self::tableExists( 'recouvrement_dossiers' ) ? (int) self::val( 'SELECT COUNT(*) FROM recouvrement_dossiers' ) : 0;
		$retard = $buckets['0-30 j'] + $buckets['31-60 j'] + $buckets['61-90 j'] + $buckets['+90 j'];
		// Repli : montants FACTURÉS, encaissements non déduits — le module de
		// recouvrement n'est pas disponible pour faire le lettrage.
		return array( 'creances' => $total, 'aging' => $buckets, 'en_retard' => $retard,
			'dossiers' => $dossiers, 'source' => 'approximation' );
	}

	/* ── 5. RH / Paie ── */
	/**
	 * 1.832.0 — l'effectif comptait les salariés partis, et la masse salariale
	 * additionnait leurs salaires de base. On compte les ACTIFS ; la masse est
	 * le brut du dernier mois de paie calculé (à défaut, les salaires de base
	 * des actifs).
	 */
	public static function rh() {
		$has = self::tableExists( 'paie_employes' ); if ( ! $has ) { return null; }
		$actif = self::colonne( 'paie_employes', 'actif' ) ? ' WHERE COALESCE(actif,1)=1' : '';
		$eff = (int) self::val( 'SELECT COUNT(*) FROM paie_employes' . $actif );
		$sortis = (int) self::val( 'SELECT COUNT(*) FROM paie_employes' ) - $eff;
		$masse = (float) self::val( 'SELECT COALESCE(SUM(salaire_base),0) FROM paie_employes' . $actif );
		$bm = array(); $periode = null;
		if ( self::tableExists( 'paie_bulletins' ) ) {
			$bm = self::serieMois( self::rows( "SELECT substr(periode,1,7) mois, SUM(brut_total) v FROM paie_bulletins GROUP BY mois" ) );
			$periode = (string) self::val( 'SELECT MAX(periode) FROM paie_bulletins', array(), '' );
			if ( '' !== $periode ) {
				$mb = (float) self::val( 'SELECT COALESCE(SUM(brut_total),0) FROM paie_bulletins WHERE periode=?', array( $periode ) );
				if ( $mb > 0 ) { $masse = $mb; } else { $periode = null; }
			}
		}
		return array( 'effectif' => $eff, 'sortis' => $sortis, 'masse' => $masse, 'masse_periode' => $periode ?: null,
			'masse_mois' => $bm, 'cout_moyen' => $eff ? $masse / $eff : 0 );
	}

	/** La colonne existe-t-elle ? */
	protected static function colonne( $table, $col ) {
		try { return in_array( $col, array_column( FKC_DB::q( "PRAGMA table_info({$table})" )->fetchAll(), 'name' ), true ); }
		catch ( \Throwable $e ) { return false; }
	}

	/* ── 6. Inventaire ── */
	public static function inventaire() {
		if ( ! self::tableExists( 'inv_stock' ) || ! self::tableExists( 'inv_articles' ) ) { return null; }
		$val = (float) self::val( 'SELECT COALESCE(SUM(s.quantite*COALESCE(a.cmp,a.prix_achat,0)),0) FROM inv_stock s JOIN inv_articles a ON a.id=s.article_id' );
		$nb = (int) self::val( 'SELECT COUNT(*) FROM inv_articles' );
		$top = self::rows( 'SELECT a.code nom, s.quantite*COALESCE(a.cmp,a.prix_achat,0) v FROM inv_stock s JOIN inv_articles a ON a.id=s.article_id ORDER BY v DESC LIMIT 6' );
		$alertes = (int) self::val( 'SELECT COUNT(*) FROM inv_stock s JOIN inv_articles a ON a.id=s.article_id WHERE a.gere_stock=1 AND s.quantite<=a.stock_min' );
		return array( 'valeur' => $val, 'articles' => $nb, 'top' => $top, 'sous_seuil' => $alertes );
	}

	/* ── 7. Budgétaire ── */
	/**
	 * 1.832.0 — on comparait les budgets DES DIVISIONS au réalisé de TOUTE
	 * l'entreprise (non imputé compris), sur l'année civile. Désormais :
	 *  - budgets par division : face au réalisé DE CES DIVISIONS, sur l'exercice
	 *    en cours ; ce qui n'est pas budgété est affiché à part ;
	 *  - budget mensuel de l'entreprise (1.831.0), s'il existe : cumul à fin
	 *    du mois en cours face au réalisé cumulé.
	 */
	public static function budgetaire() {
		$an = class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::courant() : date( 'Y' );
		$out = array( 'annee' => $an, 'divisions' => null, 'mensuel' => null );
		if ( self::tableExists( 'budgets' ) && class_exists( 'FKC_Division' ) ) {
			$bud = array();
			foreach ( self::rows( 'SELECT division_id, budget_produits bp, budget_charges bc FROM budgets WHERE annee=?', array( $an ) ) as $b ) { $bud[ (int) $b['division_id'] ] = $b; }
			if ( $bud ) {
				$res = FKC_Division::resultats( $an );
				$d = array( 'bp' => 0.0, 'bc' => 0.0, 'rp' => 0.0, 'rc' => 0.0, 'nb' => count( $bud ), 'hors_p' => 0.0, 'hors_c' => 0.0 );
				foreach ( $res['lignes'] as $l ) {
					if ( isset( $bud[ (int) $l['id'] ] ) ) {
						$d['bp'] += (float) $bud[ (int) $l['id'] ]['bp']; $d['bc'] += (float) $bud[ (int) $l['id'] ]['bc'];
						$d['rp'] += (float) $l['produits']; $d['rc'] += (float) $l['charges'];
					} else { $d['hors_p'] += (float) $l['produits']; $d['hors_c'] += (float) $l['charges']; }
				}
				$d['hors_p'] += (float) $res['non_impute']['produits']; $d['hors_c'] += (float) $res['non_impute']['charges'];
				$out['divisions'] = $d;
			}
		}
		if ( class_exists( 'FKC_BudgetMensuel' ) && in_array( 0, FKC_BudgetMensuel::sectionsBudgetees( $an ), true ) ) {
			$s = FKC_BudgetMensuel::suivi( $an, 0, FKC_BudgetMensuel::moisCourant( $an ) );
			$out['mensuel'] = array(
				'jusqua' => FKC_BudgetMensuel::libMois( $s['mois'][ $s['jusqua'] ] ),
				'bp' => $s['totaux']['produit']['bc'], 'rp' => $s['totaux']['produit']['rc'],
				'bc' => $s['totaux']['charge']['bc'], 'rc' => $s['totaux']['charge']['rc'],
				'alertes' => $s['alertes'],
			);
		}
		if ( ! $out['divisions'] && ! $out['mensuel'] ) { return null; }
		// Clés historiques (KPI, entrepôt) : le bloc le plus fin disponible.
		$ref = $out['mensuel'] ?: $out['divisions'];
		$out['budget_produits'] = $ref['bp']; $out['budget_charges'] = $ref['bc'];
		$out['realise_produits'] = $ref['rp']; $out['realise_charges'] = $ref['rc'];
		$out['taux_produits'] = $ref['bp'] > 0 ? $ref['rp'] / $ref['bp'] * 100 : 0;
		$out['taux_charges'] = $ref['bc'] > 0 ? $ref['rc'] / $ref['bc'] * 100 : 0;
		return $out;
	}

	/* ── 8. Rentabilité ── */
	public static function rentabilite( $du = null, $au = null ) {
		$fin = self::finance( $du, $au ); if ( ! $fin ) { return null; }
		return array(
			'produits' => $fin['produits'], 'charges' => $fin['charges'], 'hao' => $fin['hao'],
			'resultat_ao' => $fin['resultat_ao'], 'resultat' => $fin['resultat'],
			'marge' => $fin['marge'], 'resultat_mois' => $fin['resultat_mois'], 'top_charges' => $fin['top_charges'],
			'ratio_charges' => $fin['produits'] > 0 ? $fin['charges'] / $fin['produits'] * 100 : 0,
			'du' => $fin['du'], 'au' => $fin['au'],
		);
	}

	/* ── 9. Prévisionnelle (couche prédictive : régression linéaire) ── */
	/**
	 * 1.832.0 — la régression tournait sur janvier→décembre de l'année
	 * civile, MOIS À VENIR COMPRIS (à zéro) : en septembre, trois zéros
	 * tiraient la tendance vers le bas. Et les mois projetés, indexés après
	 * décembre, étaient étiquetés à partir du mois prochain.
	 *
	 * Désormais : les douze derniers mois COMPLETS de chiffre d'affaires
	 * (comptable), sans les mois d'avant le premier mouvement ; la projection
	 * commence au mois qui suit le dernier mois connu.
	 */
	public static function prevision( $serie = null, $horizon = 3 ) {
		if ( null === $serie ) {
			$du = date( 'Y-m-01', strtotime( 'first day of -12 month' ) );
			$au = date( 'Y-m-t', strtotime( 'last day of -1 month' ) );
			$c = self::commercial( $du, $au );
			$serie = $c ? $c['ca_mois'] : array();
			// Pas de zéros « avant l'activité » : ils inventeraient une croissance.
			foreach ( $serie as $m => $v ) { if ( abs( (float) $v ) >= 0.5 ) { break; } unset( $serie[ $m ] ); }
		}
		$vals = array_values( $serie ); $n = count( $vals );
		if ( $n < 3 ) { return array( 'historique' => $serie, 'projection' => array(), 'tendance' => 0, 'mois_base' => $n ); }
		$sx = $sy = $sxy = $sxx = 0;
		foreach ( $vals as $i => $y ) { $sx += $i; $sy += $y; $sxy += $i * $y; $sxx += $i * $i; }
		$den = ( $n * $sxx - $sx * $sx ); $a = $den ? ( $n * $sxy - $sx * $sy ) / $den : 0; $b = ( $sy - $a * $sx ) / $n;
		$dernier = array_key_last( $serie );
		$proj = array();
		for ( $k = 1; $k <= $horizon; $k++ ) {
			$mlabel = date( 'Y-m', strtotime( $dernier . '-01 +' . $k . ' month' ) );
			$proj[ $mlabel ] = max( 0, $a * ( $n - 1 + $k ) + $b );
		}
		return array( 'historique' => $serie, 'projection' => $proj, 'tendance' => $a, 'mois_base' => $n );
	}

	/* ── 10. Sectorielle (édition Creative) ── */
	public static function sectorielle() {
		if ( ! self::tableExists( 'lbl_royalty_lignes' ) ) { return null; }
		/*
		 * Les relevés distributeurs sont libellés en devise étrangère, et
		 * chacun a son cours. Un SUM() sur plusieurs relevés additionne des
		 * devises : le montant est faux, et le CLASSEMENT aussi — une
		 * plateforme payée en euros passait derrière une plateforme payée en
		 * francs pour un revenu réel bien supérieur.
		 */
		$loc = function ( $sql ) {
			$rows = self::rows( $sql );
			if ( ! class_exists( 'FKC_Royalty' ) ) { return $rows; }
			$r = FKC_Royalty::localiser( $rows );
			$out = array();
			foreach ( $r['par_cle'] as $nom => $v ) { $out[] = array( 'nom' => $nom, 'v' => $v ); }
			return array_slice( $out, 0, 8 );
		};
		$parPlateforme = $loc( "SELECT COALESCE(NULLIF(plateforme,''),'Autre') cle, import_id, SUM(montant_brut) montant FROM lbl_royalty_lignes GROUP BY plateforme, import_id" );
		$parArtiste = $loc( "SELECT COALESCE(a.nom_scene,a.nom,'(non affecté)') cle, l.import_id, SUM(l.montant_brut) montant FROM lbl_royalty_lignes l LEFT JOIN lbl_artistes a ON a.id=l.artiste_id GROUP BY l.artiste_id, l.import_id" );
		$streamsMois = self::serieMois( self::rows( "SELECT substr(i.date,1,7) mois, SUM(l.streams) v FROM lbl_royalty_lignes l JOIN lbl_royalty_imports i ON i.id=l.import_id GROUP BY mois" ) );
		$rm = self::rows( "SELECT substr(date,1,7) cle, id import_id, COALESCE(total_brut,0) montant FROM lbl_royalty_imports" );
		if ( class_exists( 'FKC_Royalty' ) ) {
			$r = FKC_Royalty::localiser( $rm );
			$rm = array();
			foreach ( $r['par_cle'] as $mois => $v ) { $rm[] = array( 'mois' => $mois, 'v' => $v ); }
			usort( $rm, fn( $a, $b ) => strcmp( $a['mois'], $b['mois'] ) );
		}
		$royaltiesMois = self::serieMois( $rm );
		$concerts = array();
		if ( self::tableExists( 'lbl_concerts' ) ) {
			$concerts = self::rows( "SELECT titre nom, (billets_vendus*billet_prix - cachet) v FROM lbl_concerts ORDER BY v DESC LIMIT 6" );
		}
		$campagnes = array();
		if ( self::tableExists( 'lbl_marketing' ) ) {
			$campagnes = self::rows( "SELECT campagne nom, conversions v FROM lbl_marketing ORDER BY v DESC LIMIT 6" );
		}
		$streamsTotal = (int) self::val( 'SELECT COALESCE(SUM(streams),0) FROM lbl_royalty_lignes' );
		$royaltiesTotal = class_exists( 'FKC_Royalty' )
			? (float) FKC_Royalty::localiser( self::rows( 'SELECT id import_id, COALESCE(total_brut,0) montant FROM lbl_royalty_imports' ) )['total']
			: (float) self::val( 'SELECT COALESCE(SUM(total_brut),0) FROM lbl_royalty_imports' );
		return array(
			'par_plateforme' => $parPlateforme, 'par_artiste' => $parArtiste,
			'streams_mois' => $streamsMois, 'royalties_mois' => $royaltiesMois,
			'concerts' => $concerts, 'campagnes' => $campagnes,
			'streams_total' => $streamsTotal, 'royalties_total' => $royaltiesTotal,
		);
	}

	/** Registre de métriques scalaires (pour KPI & alertes). */
	public static function registre() {
		$registre = array(
			'produits'      => array( 'Produits (exercice)', function () { $f = self::finance(); return $f['produits'] ?? 0; } ),
			'charges'       => array( 'Charges (exercice)', function () { $f = self::finance(); return $f['charges'] ?? 0; } ),
			'resultat'      => array( 'Résultat net (exercice)', function () { $f = self::finance(); return $f['resultat'] ?? 0; } ),
			'marge'         => array( 'Marge (%)', function () { $f = self::finance(); return round( $f['marge'] ?? 0, 1 ); } ),
			'ca'            => array( "Chiffre d'affaires (exercice)", function () { $c = self::commercial(); return $c['ca'] ?? 0; } ),
			'creances'      => array( 'Créances clients', function () { $r = self::recouvrement(); return $r['creances'] ?? 0; } ),
			'creances_retard' => array( 'Créances en retard', function () { $r = self::recouvrement(); return $r['en_retard'] ?? 0; } ),
			'effectif'      => array( 'Effectif', function () { $r = self::rh(); return $r['effectif'] ?? 0; } ),
			'masse_salariale' => array( 'Masse salariale', function () { $r = self::rh(); return $r['masse'] ?? 0; } ),
			'stock_valeur'  => array( 'Valeur du stock', function () { $i = self::inventaire(); return $i['valeur'] ?? 0; } ),
			'stock_alertes' => array( 'Articles sous seuil', function () { $i = self::inventaire(); return $i['sous_seuil'] ?? 0; } ),
			'royalties'     => array( 'Royalties (total)', function () { $s = self::sectorielle(); return $s['royalties_total'] ?? 0; } ),
			'streams'       => array( 'Streams (total)', function () { $s = self::sectorielle(); return $s['streams_total'] ?? 0; } ),
		);
		// Métriques métier enregistrées par le pack actif (register()).
		foreach ( self::$externes as $cle => $def ) {
			$registre[ $cle ] = array( $def[0], $def[1] );
		}
		return $registre;
	}
	public static function metric( $cle ) {
		$r = self::registre(); if ( ! isset( $r[ $cle ] ) ) { return null; }
		try { return (float) call_user_func( $r[ $cle ][1] ); } catch ( \Throwable $e ) { return 0; }
	}
	public static function metricLabel( $cle ) { $r = self::registre(); return $r[ $cle ][0] ?? $cle; }
}
