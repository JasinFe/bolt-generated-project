<?php
/** Alertes intelligentes : règles paramétrables évaluées sur les métriques. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Alerte {
	public static function operateurs() { return array( '>' => '>', '>=' => '≥', '<' => '<', '<=' => '≤' ); }
	public static function niveaux() { return array( 'info' => 'Information', 'warn' => 'Avertissement', 'danger' => 'Critique' ); }

	public static function all() { return FKC_DB::q( 'SELECT * FROM analyse_alertes ORDER BY id DESC' )->fetchAll(); }
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO analyse_alertes(libelle,metric,operateur,seuil,niveau,actif) VALUES(?,?,?,?,?,1)',
			array( trim( (string) $d['libelle'] ), (string) $d['metric'],
				isset( self::operateurs()[ $d['operateur'] ?? '' ] ) ? $d['operateur'] : '>',
				(float) ( $d['seuil'] ?? 0 ), isset( self::niveaux()[ $d['niveau'] ?? '' ] ) ? $d['niveau'] : 'warn' ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM analyse_alertes WHERE id=?', array( (int) $id ) ); }

	public static function declenche( $op, $val, $seuil ) {
		switch ( $op ) {
			case '>': return $val > $seuil; case '>=': return $val >= $seuil;
			case '<': return $val < $seuil; case '<=': return $val <= $seuil;
		}
		return false;
	}
	/* ═══════════════ Notification des alertes (1.837.0) ═══════════════ */

	/** Délai au bout duquel une alerte toujours franchie est rappelée, en jours. */
	const RAPPEL_JOURS = 7;

	protected static function colonnesEtat() {
		static $fait = array();
		$f = (string) FKC_DB::file();
		if ( isset( $fait[ $f ] ) ) { return; }
		$cols = array_column( FKC_DB::q( 'PRAGMA table_info(analyse_alertes)' )->fetchAll(), 'name' );
		if ( ! in_array( 'etat', $cols, true ) ) { FKC_DB::conn()->exec( 'ALTER TABLE analyse_alertes ADD COLUMN etat INTEGER NOT NULL DEFAULT 0' ); }
		if ( ! in_array( 'notifie_le', $cols, true ) ) { FKC_DB::conn()->exec( 'ALTER TABLE analyse_alertes ADD COLUMN notifie_le TEXT' ); }
		$fait[ $f ] = true;
	}

	/** Comptes à prévenir : actifs, et administrateurs ou titulaires du module Analyse. */
	public static function destinataires() {
		return array_map( function ( $u ) { return (int) $u['id']; }, self::destinatairesDetail() );
	}

	/** Mêmes comptes, avec nom et adresse (écran des réglages, envoi de courriels). */
	public static function destinatairesDetail() {
		if ( ! class_exists( 'FKC_User' ) ) { return array(); }
		$out = array();
		foreach ( FKC_User::all() as $u ) {
			if ( empty( $u['actif'] ) ) { continue; }
			$mods = ! empty( $u['modules'] ) ? json_decode( (string) $u['modules'], true ) : array();
			if ( 'admin' === ( $u['role'] ?? '' ) || ( is_array( $mods ) && in_array( 'analyse', $mods, true ) ) ) {
				$out[] = array( 'id' => (int) $u['id'], 'nom' => (string) ( $u['nom_complet'] ?? $u['login'] ?? '' ), 'email' => trim( (string) ( $u['email'] ?? '' ) ) );
			}
		}
		return $out;
	}

	/* ═══════════════ Courriels (1.838.0) ═══════════════ */

	/** Ce qui part aussi par courriel. */
	public static function modesEmail() {
		return array(
			'critiques' => 'Alertes critiques seulement',
			'toutes' => 'Toutes les alertes',
			'aucune' => 'Aucun courriel (cloche seulement)',
		);
	}

	/** Réglage de la société ; « critiques » par défaut : c'est ce qui ne peut pas attendre. */
	public static function modeEmail() {
		try { $v = (string) FKC_DB::q( "SELECT valeur FROM parametres WHERE cle='alertes_email'" )->fetchColumn(); }
		catch ( \Throwable $e ) { $v = ''; }
		return isset( self::modesEmail()[ $v ] ) ? $v : 'critiques';
	}

	public static function setModeEmail( $mode ) {
		$mode = isset( self::modesEmail()[ $mode ] ) ? $mode : 'critiques';
		$maj = FKC_DB::q( "UPDATE parametres SET valeur=? WHERE cle='alertes_email'", array( $mode ) )->rowCount();
		if ( ! $maj ) { FKC_DB::q( "INSERT INTO parametres(cle, valeur) VALUES('alertes_email', ?)", array( $mode ) ); }
		return $mode;
	}

	/** Cette alerte doit-elle partir par courriel, vu le réglage ? */
	public static function parCourriel( $niveau ) {
		$m = self::modeEmail();
		return 'toutes' === $m || ( 'critiques' === $m && 'danger' === $niveau );
	}

	/**
	 * Rédige le courriel d'une alerte : [sujet, texte, html].
	 * Tout ce qui vient de la base est échappé dans la version HTML.
	 */
	public static function courriel( array $a, $valeur, $rappel = false ) {
		$soc = class_exists( 'FKC_Tenant' ) ? (string) ( FKC_Tenant::current()['raison_sociale'] ?? '' ) : '';
		$lib = class_exists( 'FKC_Metrics' ) ? FKC_Metrics::metricLabel( $a['metric'] ) : $a['metric'];
		$op = self::operateurs()[ $a['operateur'] ] ?? $a['operateur'];
		$niv = self::niveaux()[ $a['niveau'] ] ?? $a['niveau'];
		$lien = function_exists( 'url' ) ? url( 'analyse/alertes' ) : '';
		$sujet = '[FinaKop] ' . ( 'danger' === $a['niveau'] ? 'Alerte critique' : 'Alerte' ) . ' — ' . $a['libelle'] . ( $soc ? ' — ' . $soc : '' ) . ( $rappel ? ' (rappel)' : '' );
		$constat = sprintf( '%s = %s (seuil : %s %s).', $lib, self::nombre( $valeur ), $op, self::nombre( $a['seuil'] ) );
		$texte = implode( "\n", array_filter( array(
			$soc ? 'Société : ' . $soc : null,
			'Alerte : ' . $a['libelle'] . ' (' . $niv . ')',
			$constat,
			$rappel ? 'Cette alerte est toujours franchie depuis plus de ' . self::RAPPEL_JOURS . ' jours.' : 'Le seuil vient d\'être franchi.',
			'Constaté le ' . date( 'd/m/Y à H:i' ) . '.',
			$lien ? 'Voir les alertes : ' . $lien : null,
			'',
			'Vous recevez ce courriel parce que vous avez accès au module Analyse de FinaKop. Le réglage d\'envoi se trouve sur l\'écran des alertes.',
		), function ( $l ) { return null !== $l; } ) );
		$e = function ( $x ) { return htmlspecialchars( (string) $x, ENT_QUOTES, 'UTF-8' ); };
		$coul = 'danger' === $a['niveau'] ? '#c33' : ( 'warn' === $a['niveau'] ? '#e67e22' : '#39c' );
		$html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#222;max-width:560px">'
			. '<div style="border-left:4px solid ' . $coul . ';padding:10px 14px;background:#f7f7f7">'
			. '<div style="font-size:12px;color:#666">' . $e( $soc ) . '</div>'
			. '<div style="font-size:17px;font-weight:bold;margin:4px 0">' . $e( $a['libelle'] ) . ' <span style="font-size:12px;color:' . $coul . '">(' . $e( $niv ) . ')</span></div>'
			. '<div>' . $e( $constat ) . '</div>'
			. '<div style="margin-top:6px;color:#555">' . $e( $rappel ? 'Toujours franchie depuis plus de ' . self::RAPPEL_JOURS . ' jours.' : 'Le seuil vient d\'être franchi.' ) . ' ' . $e( 'Constaté le ' . date( 'd/m/Y à H:i' ) . '.' ) . '</div>'
			. '</div>'
			. ( $lien ? '<p><a href="' . $e( $lien ) . '" style="color:#1a56db">Voir les alertes dans FinaKop</a></p>' : '' )
			. '<p style="font-size:11px;color:#888">Vous recevez ce courriel parce que vous avez accès au module Analyse de FinaKop. Le réglage d\'envoi se trouve sur l\'écran des alertes.</p>'
			. '</div>';
		return array( $sujet, $texte, $html );
	}

	/** Envoie l'alerte à chaque destinataire qui a une adresse. @return int courriels partis */
	protected static function envoyerCourriels( array $a, $valeur, $rappel ) {
		if ( ! class_exists( 'FKC_Courriel' ) || ! self::parCourriel( (string) $a['niveau'] ) ) { return 0; }
		list( $sujet, $texte, $html ) = self::courriel( $a, $valeur, $rappel );
		$n = 0;
		foreach ( self::destinatairesDetail() as $u ) {
			if ( '' === $u['email'] ) { continue; }
			list( $ok ) = FKC_Courriel::envoyer( $u['email'], $sujet, $texte, $html, 'alerte:' . (int) $a['id'] );
			if ( $ok ) { $n++; }
		}
		return $n;
	}

	/**
	 * UNE ALERTE QUE PERSONNE NE VOIT N'ALERTE PERSONNE.
	 *
	 * Les règles des « Alertes intelligentes » n'étaient évaluées qu'à
	 * l'ouverture de leur propre écran : une trésorerie passée sous le seuil
	 * restait muette tant que personne ne pensait à aller vérifier — c'est-à-
	 * dire exactement quand l'alerte aurait servi.
	 *
	 * Chaque règle garde désormais son ÉTAT. Au FRANCHISSEMENT (état 0 → 1),
	 * une notification part dans la cloche des comptes concernés ; tant que
	 * la règle reste franchie, rien de plus, sauf un rappel hebdomadaire ; au
	 * retour sous le seuil, l'état revient à 0 et le prochain franchissement
	 * sera à nouveau signalé. Pas d'avalanche, pas de silence.
	 *
	 * @return int nombre de règles notifiées
	 */
	public static function notifier() {
		try { self::colonnesEtat(); } catch ( \Throwable $e ) { return 0; }
		$n = 0; $dest = null;
		foreach ( self::all() as $a ) {
			if ( empty( $a['actif'] ) ) { continue; }
			try { $val = FKC_Metrics::metric( $a['metric'] ); } catch ( \Throwable $e ) { continue; }
			$franchie = self::declenche( $a['operateur'], $val, (float) $a['seuil'] );
			if ( ! $franchie ) {
				if ( (int) ( $a['etat'] ?? 0 ) ) { FKC_DB::q( 'UPDATE analyse_alertes SET etat=0 WHERE id=?', array( (int) $a['id'] ) ); }
				continue;
			}
			$rappel = ! empty( $a['notifie_le'] ) && strtotime( (string) $a['notifie_le'] ) < strtotime( '-' . self::RAPPEL_JOURS . ' days' );
			if ( (int) ( $a['etat'] ?? 0 ) && ! $rappel ) { continue; }
			if ( null === $dest ) { $dest = self::destinataires(); }
			$lib = class_exists( 'FKC_Metrics' ) ? FKC_Metrics::metricLabel( $a['metric'] ) : $a['metric'];
			$titre = ( 'danger' === $a['niveau'] ? '🔴 ' : ( 'warn' === $a['niveau'] ? '🟠 ' : '🔵 ' ) ) . 'Alerte : ' . $a['libelle'];
			$msg = sprintf( '%s = %s (seuil %s %s)%s.', $lib, self::nombre( $val ), self::operateurs()[ $a['operateur'] ] ?? $a['operateur'], self::nombre( $a['seuil'] ),
				$rappel ? ' — toujours franchie' : '' );
			if ( class_exists( 'FKC_Notification' ) ) {
				foreach ( $dest as $uid ) {
					try { FKC_Notification::create( $uid, $titre, $msg, 'alerte', 'analyse/alertes', 'erp', 'alerte:' . (int) $a['id'] ); } catch ( \Throwable $e ) {}
				}
			}
			FKC_DB::q( "UPDATE analyse_alertes SET etat=1, notifie_le=datetime('now','localtime') WHERE id=?", array( (int) $a['id'] ) );
			// Le courriel suit exactement la cloche : au franchissement et au rappel, jamais entre les deux.
			self::envoyerCourriels( $a, $val, $rappel );
			$n++;
		}
		return $n;
	}

	protected static function nombre( $v ) {
		$v = (float) $v;
		return abs( $v - round( $v ) ) < 0.005 ? number_format( $v, 0, ',', ' ' ) : number_format( $v, 2, ',', ' ' );
	}

	/**
	 * Évaluation « au passage », au plus une fois toutes les quinze minutes par
	 * société : appelée par la vue d'ensemble, le panneau d'alertes de la
	 * barre et la passe planifiée, elle ne coûte presque rien le reste du temps.
	 */
	public static function notifierSiDu( $intervalle = 900 ) {
		try {
			if ( ! (int) FKC_DB::q( 'SELECT COUNT(*) FROM analyse_alertes WHERE actif=1' )->fetchColumn() ) { return 0; }
			$der = (int) FKC_DB::q( "SELECT valeur FROM parametres WHERE cle='alertes_evaluees_at'" )->fetchColumn();
			if ( $der && time() - $der < (int) $intervalle ) { return 0; }
			$maj = FKC_DB::q( "UPDATE parametres SET valeur=? WHERE cle='alertes_evaluees_at'", array( (string) time() ) )->rowCount();
			if ( ! $maj ) { FKC_DB::q( "INSERT INTO parametres(cle, valeur) VALUES('alertes_evaluees_at', ?)", array( (string) time() ) ); }
		} catch ( \Throwable $e ) { return 0; }
		return self::notifier();
	}

	/** Liste des alertes déclenchées (avec valeur courante). */
	public static function evaluate() {
		$out = array();
		foreach ( self::all() as $a ) {
			if ( empty( $a['actif'] ) ) { continue; }
			$val = FKC_Metrics::metric( $a['metric'] );
			if ( self::declenche( $a['operateur'], $val, (float) $a['seuil'] ) ) {
				$a['valeur'] = $val; $out[] = $a;
			}
		}
		return $out;
	}
}
