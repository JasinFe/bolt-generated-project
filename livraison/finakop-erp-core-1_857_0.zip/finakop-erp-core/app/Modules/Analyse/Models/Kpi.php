<?php
/** Centre KPI : chaque entreprise définit ses indicateurs et leurs cibles. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Kpi {
	public static function couches() {
		return array( 'operationnel' => 'Opérationnel (aujourd\'hui)', 'performance' => 'Performance (pourquoi)', 'predictif' => 'Prédictif (demain)' );
	}
	public static function sens() { return array( 'hausse' => 'À maximiser', 'baisse' => 'À minimiser' ); }

	public static function all() { return FKC_DB::q( 'SELECT * FROM analyse_kpis ORDER BY couche, id' )->fetchAll(); }
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO analyse_kpis(libelle,metric,cible,unite,sens,couche,actif) VALUES(?,?,?,?,?,?,1)',
			array( trim( (string) $d['libelle'] ), (string) $d['metric'], (float) ( $d['cible'] ?? 0 ),
				trim( (string) ( $d['unite'] ?? '' ) ), isset( self::sens()[ $d['sens'] ?? '' ] ) ? $d['sens'] : 'hausse',
				isset( self::couches()[ $d['couche'] ?? '' ] ) ? $d['couche'] : 'operationnel' ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM analyse_kpis WHERE id=?', array( (int) $id ) ); }

	/** Évalue un KPI : valeur actuelle, % de la cible, statut. */
	public static function evalue( $k ) {
		$actuel = FKC_Metrics::metric( $k['metric'] );
		$cible = (float) $k['cible'];
		$pct = $cible != 0 ? $actuel / $cible * 100 : 0;
		if ( 'baisse' === $k['sens'] ) {
			$statut = ( $cible <= 0 ) ? 'na' : ( $actuel <= $cible ? 'ok' : ( $actuel <= $cible * 1.1 ? 'warn' : 'danger' ) );
		} else {
			$statut = ( $cible <= 0 ) ? 'na' : ( $actuel >= $cible ? 'ok' : ( $actuel >= $cible * 0.9 ? 'warn' : 'danger' ) );
		}
		return array( 'actuel' => $actuel, 'cible' => $cible, 'pct' => $pct, 'statut' => $statut );
	}
}
