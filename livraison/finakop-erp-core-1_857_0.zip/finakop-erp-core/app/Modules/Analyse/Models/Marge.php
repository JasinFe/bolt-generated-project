<?php
/**
 * MARGE (1.833.0) — l'écran « Marge » de la barre latérale.
 *
 * Trois lectures, chacune sur la source qui fait foi :
 *
 *  1. Les SOLDES INTERMÉDIAIRES DE GESTION, tirés de la même cascade que le
 *     compte de résultat officiel (FKC_EtatsDgi::sigBruts) — marge
 *     commerciale, valeur ajoutée, EBE, résultat d'exploitation, résultat
 *     net —, comparés à la même période un an plus tôt. Une marge qui ne
 *     retombe pas sur la liasse n'est pas une marge : elle est donc calculée
 *     par le même code.
 *  2. La marge PAR SECTION ANALYTIQUE (division, projet, client… selon
 *     l'axe choisi), lue par exercice comme toute l'analytique.
 *  3. La marge PAR ARTICLE, là où la vente connaît son article et son coût :
 *     les tickets de caisse, dont chaque ligne garde le CUMP de l'instant de
 *     la vente. Les factures ne portent pas d'article : elles n'y figurent
 *     pas, et l'écran le dit.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Marge {

	/**
	 * Lignes de la cascade : [clé, libellé, type, préfixes de comptes].
	 * type : d = poste élémentaire, s = solde intermédiaire, g = résultat net.
	 * La clé d'un poste composé est une expression sur les postes de
	 * sigBruts() (« RA+RB », « RL-TJ ») ; celle d'un solde est son code.
	 */
	public static function definition() {
		return array(
			array( 'TA',          'Ventes de marchandises', 'd', array( '701' ) ),
			array( 'RA+RB',       'Coût d\'achat des marchandises vendues', 'd', array( '601', '6031' ) ),
			array( 'XA',          'Marge commerciale', 's', array() ),
			array( 'TB+TC+TD',    'Ventes de produits, travaux et services', 'd', array( '702', '703', '704', '705', '706', '707' ) ),
			array( 'XB',          'Chiffre d\'affaires', 's', array() ),
			array( 'TE+TF+TG+TH+TI', 'Production stockée et immobilisée, subventions, autres produits', 'd', array( '71', '72', '73', '75', '781', '782' ) ),
			array( 'RC+RD+RE+RF', 'Matières, fournitures et autres achats consommés', 'd', array( '602', '6032', '6033', '604', '605', '608' ) ),
			array( 'RG+RH',       'Transports et services extérieurs', 'd', array( '61', '62', '63' ) ),
			array( 'RI',          'Impôts et taxes', 'd', array( '64' ) ),
			array( 'RJ',          'Autres charges', 'd', array( '65' ) ),
			array( 'XC',          'Valeur ajoutée', 's', array() ),
			array( 'RK',          'Charges de personnel', 'd', array( '66' ) ),
			array( 'XD',          'Excédent brut d\'exploitation (EBE)', 's', array() ),
			array( 'RL-TJ',       'Dotations aux amortissements et provisions, nettes des reprises', 'd', array( '681', '691', '791', '798', '799' ) ),
			array( 'XE',          'Résultat d\'exploitation', 's', array() ),
			array( 'XF',          'Résultat financier', 'd', array( '67', '687', '697', '77', '787', '797' ) ),
			array( 'XH',          'Résultat hors activités ordinaires (HAO)', 'd', array( '81', '82', '83', '84', '85', '86', '88' ) ),
			array( 'RQ+RS',       'Participation des travailleurs et impôts sur le résultat', 'd', array( '87', '89' ) ),
			array( 'XI',          'Résultat net', 'g', array() ),
		);
	}

	/** Valeur d'une clé sur un jeu de sigBruts() : « RA+RB », « RL-TJ », « XA »… */
	public static function valeur( array $v, $cle ) {
		$total = 0.0; $signe = 1;
		foreach ( preg_split( '/([+-])/', $cle, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY ) as $t ) {
			if ( '+' === $t ) { $signe = 1; continue; }
			if ( '-' === $t ) { $signe = -1; continue; }
			$total += $signe * (float) ( $v[ $t ] ?? 0 );
		}
		return $total;
	}

	/**
	 * Même période, un an plus tôt. Un 29 février ou une fin de mois reste
	 * une fin de mois : « au 29/02/2024 » se compare au 28/02/2023, pas au
	 * 1er mars — sinon la comparaison déborde d'un jour sur le mois suivant.
	 */
	public static function moinsUnAn( $date ) {
		$t = strtotime( (string) $date );
		if ( ! $t ) { return $date; }
		$y = (int) date( 'Y', $t ) - 1; $m = (int) date( 'n', $t ); $d = (int) date( 'j', $t );
		$fin = (int) date( 't', $t ) === $d;
		$max = (int) date( 't', mktime( 0, 0, 0, $m, 1, $y ) );
		return sprintf( '%04d-%02d-%02d', $y, $m, $fin ? $max : min( $d, $max ) );
	}

	/**
	 * Soldes intermédiaires de gestion sur [du, au], comparés à N-1.
	 *
	 * @return array{du:string,au:string,du1:string,au1:string,lignes:array,n:array,n1:array,ca:float,ca1:float,vide:bool}
	 */
	public static function sig( $du, $au ) {
		$du1 = self::moinsUnAn( $du ); $au1 = self::moinsUnAn( $au );
		$N = FKC_EtatsDgi::sigBruts( $du, $au );
		$P = FKC_EtatsDgi::sigBruts( $du1, $au1 );
		$ca = (float) $N['XB']; $ca1 = (float) $P['XB'];
		$lignes = array(); $masse = 0.0;
		foreach ( self::definition() as $d ) {
			list( $cle, $lib, $type, $prefs ) = $d;
			$n = self::valeur( $N, $cle ); $n1 = self::valeur( $P, $cle );
			// Un poste de charge s'affiche en positif, précédé de « − ».
			$sg = ( 'd' === $type && 'R' === $cle[0] ) ? -1 : 1;
			$lignes[] = array(
				'cle' => $cle, 'libelle' => $lib, 'type' => $type, 'prefixes' => $prefs,
				'signe' => 'd' === $type ? ( $sg < 0 ? '−' : ( 'X' === $cle[0] ? '±' : '+' ) ) : '=',
				'n' => $n, 'n1' => $n1,
				// Part du CA : une charge s'y lit en positif, comme son montant.
				'pct_ca' => $ca > 0 ? $n / $ca * 100 : null,
				'pct_ca1' => $ca1 > 0 ? $n1 / $ca1 * 100 : null,
				'var' => self::variation( $n, $n1 ),
			);
			if ( 'd' === $type ) { $masse += abs( $n ); }
		}
		return array(
			'du' => $du, 'au' => $au, 'du1' => $du1, 'au1' => $au1,
			'lignes' => $lignes, 'n' => $N, 'n1' => $P, 'ca' => $ca, 'ca1' => $ca1,
			'vide' => $masse < 0.5 && abs( $ca ) < 0.5,
			'taux_marge_com' => (float) $N['TA'] > 0 ? (float) $N['XA'] / (float) $N['TA'] * 100 : null,
			'taux_marge_com1' => (float) $P['TA'] > 0 ? (float) $P['XA'] / (float) $P['TA'] * 100 : null,
		);
	}

	/** Variation en % de n1 à n ; null quand n1 est nul (aucune base). */
	public static function variation( $n, $n1 ) {
		if ( abs( (float) $n1 ) < 0.5 ) { return null; }
		return ( (float) $n - (float) $n1 ) / abs( (float) $n1 ) * 100;
	}

	/**
	 * Chiffre d'affaires, marge commerciale et EBE, mois par mois, bornés à
	 * la période (un premier et un dernier mois partiels restent partiels).
	 * @return array{labels:string[],ca:float[],marge:float[],ebe:float[]}
	 */
	public static function mensuel( $du, $au ) {
		$out = array( 'labels' => array(), 'ca' => array(), 'marge' => array(), 'ebe' => array() );
		$mois = FKC_Metrics::moisRange( $du, $au );
		foreach ( array_slice( $mois, 0, 24 ) as $ym ) {
			$d1 = max( $du, $ym . '-01' );
			$d2 = min( $au, date( 'Y-m-t', strtotime( $ym . '-01' ) ) );
			$v = FKC_EtatsDgi::sigBruts( $d1, $d2 );
			$out['labels'][] = FKC_Marge::moisCourt( $ym );
			$out['ca'][] = round( (float) $v['XB'] );
			$out['marge'][] = round( (float) $v['XA'] );
			$out['ebe'][] = round( (float) $v['XD'] );
		}
		return $out;
	}

	public static function moisCourt( $ym ) {
		$m = array( 1 => 'janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.' );
		return $m[ (int) substr( $ym, 5, 2 ) ] . ' ' . substr( $ym, 2, 2 );
	}

	/**
	 * Lien de détail : le grand livre général, filtré sur les préfixes du
	 * poste et hors écriture de détermination du résultat (sans quoi un
	 * exercice clôturé montrerait des comptes 6 et 7 soldés à zéro).
	 */
	public static function lienGrandLivre( array $prefixes, $du, $au ) {
		if ( ! $prefixes ) { return null; }
		return 'comptabilite/grand-livre?' . http_build_query( array(
			'du' => $du, 'au' => $au, 'prefixes' => implode( ',', $prefixes ), 'gestion' => 1,
		) );
	}

	/* ═══════════════ Marge par section analytique ═══════════════ */

	/** L'analytique est-elle accessible à l'utilisateur courant ? */
	public static function analytiqueDisponible() {
		return class_exists( 'FKC_Affectation' ) && class_exists( 'FKC_Axe' )
			&& FKC_License::moduleEnabled( 'analytique' )
			&& ( ! FKC_Auth::check() || FKC_Auth::can( 'analytique' ) );
	}

	/** Axes proposés : l'axe Divisions toujours, les autres si le multi-axes est ouvert. */
	public static function axes() {
		if ( ! self::analytiqueDisponible() ) { return array(); }
		$multi = FKC_Modules::featureEnabled( 'analytique.multi_axes' );
		$out = array();
		foreach ( FKC_Axe::all( true ) as $a ) {
			if ( 'DIV' !== $a['code'] && ! $multi ) { continue; }
			$out[] = $a;
		}
		return $out;
	}

	/**
	 * Marge par valeur d'un axe sur un exercice : produits, charges, marge
	 * (produits − charges de gestion) et taux, triée de la meilleure à la
	 * moins bonne, avec le non-affecté et la couverture de l'axe.
	 */
	public static function parAxe( $axeId, $annee ) {
		$axes = self::axes();
		if ( ! $axes ) { return null; }
		$axe = null;
		foreach ( $axes as $a ) { if ( (int) $a['id'] === (int) $axeId ) { $axe = $a; } }
		if ( ! $axe ) {
			$div = class_exists( 'FKC_Ventilation' ) ? (int) FKC_Ventilation::axeDivision() : 0;
			foreach ( $axes as $a ) { if ( (int) $a['id'] === $div ) { $axe = $a; } }
			if ( ! $axe ) { $axe = $axes[0]; }
		}
		$r = FKC_Affectation::resultatsParAxe( (int) $axe['id'], (string) $annee );
		$lignes = array();
		foreach ( $r['lignes'] as $l ) {
			if ( abs( (float) $l['produits'] ) < 0.5 && abs( (float) $l['charges'] ) < 0.5 ) { continue; }
			$lignes[] = self::ligneAxe( $l, (int) $l['valeur_id'], $l['libelle'], $l['code'] ?? '' );
		}
		usort( $lignes, function ( $a, $b ) { return $b['marge'] <=> $a['marge']; } );
		$na = $r['non_affecte'];
		return array(
			'axe' => $axe, 'annee' => (string) $annee, 'lignes' => $lignes,
			'non_affecte' => $na && ( abs( (float) $na['produits'] ) >= 0.5 || abs( (float) $na['charges'] ) >= 0.5 ) ? self::ligneAxe( $na, 0, 'Non affecté', '—' ) : null,
			'totaux' => self::ligneAxe( $r['totaux'], -1, 'Total', '' ),
			'couverture' => $r['couverture'] ?? null,
		);
	}

	protected static function ligneAxe( array $l, $id, $libelle, $code ) {
		$p = (float) $l['produits']; $c = (float) $l['charges'];
		return array(
			'valeur_id' => $id, 'code' => $code, 'libelle' => $libelle,
			'produits' => $p, 'charges' => $c, 'marge' => $p - $c,
			'taux' => $p > 0 ? ( $p - $c ) / $p * 100 : null,
		);
	}

	/* ═══════════════ Marge par article (ventes de caisse) ═══════════════ */

	protected static function tableExiste( $t ) {
		try { return (bool) FKC_DB::q( "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", array( $t ) )->fetchColumn(); }
		catch ( \Throwable $e ) { return false; }
	}

	protected static function colonne( $table, $col ) {
		try { return in_array( $col, array_column( FKC_DB::q( "PRAGMA table_info({$table})" )->fetchAll(), 'name' ), true ); }
		catch ( \Throwable $e ) { return false; }
	}

	/**
	 * Marge par article sur les tickets de caisse encaissés entre du et au.
	 *
	 * Chiffre d'affaires HORS TAXES de chaque ligne, après sa part des
	 * remises du ticket (remise globale, promotions, fidélité), au prorata du
	 * TTC — la même règle que celle qui calcule la TVA du ticket. Service et
	 * pourboire, qui ne sont pas des ventes d'article, en sont exclus.
	 * Coût : le CUMP figé sur la ligne à la vente. Un ticket de RETOUR se
	 * retranche, à son propre coefficient.
	 *
	 * @return array|null null quand aucune vente de caisse n'existe sur la période.
	 */
	public static function articles( $du, $au, $limite = 15 ) {
		if ( ! self::tableExiste( 'caisse_lignes' ) || ! self::tableExiste( 'caisse_tickets' ) ) { return null; }
		$promo = self::colonne( 'caisse_tickets', 'promo_montant' ) ? 'COALESCE(t.promo_montant,0)' : '0';
		$fid   = self::colonne( 'caisse_tickets', 'remise_fidelite' ) ? 'COALESCE(t.remise_fidelite,0)' : '0';
		$coef = "CASE WHEN s.st > 0 THEN (CASE WHEN t.type='retour' THEN t.total_ttc
		                                       ELSE s.st - COALESCE(t.remise_montant,0) - {$promo} - {$fid} END) / s.st
		              ELSE 1 END";
		$sgn = "CASE WHEN t.type='retour' THEN -1 ELSE 1 END";
		try {
			$rows = FKC_DB::q(
				"SELECT l.article_id aid, MAX(l.libelle) lib,
				        SUM({$sgn} * l.quantite) qte,
				        SUM({$sgn} * l.total_ttc * ({$coef}) / (1 + l.tva/100.0)) ca,
				        SUM({$sgn} * l.cout_unitaire * l.quantite) cout
				 FROM caisse_lignes l
				 JOIN caisse_tickets t ON t.id = l.ticket_id
				 JOIN (SELECT ticket_id, SUM(total_ttc) st FROM caisse_lignes GROUP BY ticket_id) s ON s.ticket_id = t.id
				 WHERE ( (t.type='retour' AND t.statut='paye') OR (COALESCE(t.type,'vente')<>'retour' AND t.statut IN ('paye','rembourse')) )
				   AND date(t.paye_at) BETWEEN ? AND ?
				 GROUP BY l.article_id",
				array( $du, $au )
			)->fetchAll();
		} catch ( \Throwable $e ) { return null; }
		if ( ! $rows ) { return null; }

		$arts = array();
		if ( self::tableExiste( 'inv_articles' ) ) {
			$ids = array_filter( array_map( 'intval', array_column( $rows, 'aid' ) ) );
			if ( $ids ) {
				foreach ( FKC_DB::q( 'SELECT id, code, designation FROM inv_articles WHERE id IN (' . implode( ',', $ids ) . ')' )->fetchAll() as $a ) {
					$arts[ (int) $a['id'] ] = $a;
				}
			}
		}
		$lignes = array(); $tot = array( 'ca' => 0.0, 'cout' => 0.0, 'marge' => 0.0 ); $sansCout = 0;
		foreach ( $rows as $r ) {
			$ca = round( (float) $r['ca'], 2 ); $cout = round( (float) $r['cout'], 2 );
			if ( abs( $ca ) < 0.5 && abs( $cout ) < 0.5 ) { continue; }
			$aid = (int) $r['aid'];
			$a = $arts[ $aid ] ?? null;
			$l = array(
				'article_id' => $aid && $a ? $aid : 0,
				'code' => $a['code'] ?? '',
				'designation' => $a ? $a['designation'] : ( $aid ? (string) $r['lib'] : 'Ventes libres (hors catalogue)' ),
				'qte' => (float) $r['qte'], 'ca' => $ca, 'cout' => $cout, 'marge' => $ca - $cout,
				'taux' => $ca > 0 ? ( $ca - $cout ) / $ca * 100 : null,
				'sans_cout' => $aid > 0 && $ca > 0 && $cout < 0.005, // une vente libre n'a pas de fiche où renseigner un coût
			);
			if ( $l['sans_cout'] ) { $sansCout++; }
			$lignes[] = $l;
			$tot['ca'] += $ca; $tot['cout'] += $cout; $tot['marge'] += $ca - $cout;
		}
		if ( ! $lignes ) { return null; }
		usort( $lignes, function ( $a, $b ) { return $b['marge'] <=> $a['marge']; } );
		$tot['taux'] = $tot['ca'] > 0 ? $tot['marge'] / $tot['ca'] * 100 : null;

		// Les moins rentables : taux le plus bas d'abord, pertes comprises.
		$faibles = array_values( array_filter( $lignes, function ( $l ) { return null !== $l['taux'] && ! $l['sans_cout']; } ) );
		usort( $faibles, function ( $a, $b ) { return $a['taux'] <=> $b['taux']; } );

		return array(
			'lignes' => array_slice( $lignes, 0, (int) $limite ),
			'faibles' => array_slice( $faibles, 0, 5 ),
			'nb' => count( $lignes ), 'totaux' => $tot, 'sans_cout' => $sansCout,
			'toutes' => $lignes,
		);
	}
}
