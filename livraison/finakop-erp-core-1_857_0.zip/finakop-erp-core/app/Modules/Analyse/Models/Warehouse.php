<?php
/** Data Warehouse : instantanés pré-calculés pour que l'analyse ne ralentisse pas l'exploitation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Warehouse {
	/** Domaines calculés et stockés. */
	public static function domaines() {
		return array( 'finance', 'commercial', 'clients', 'recouvrement', 'rh', 'inventaire', 'budgetaire', 'rentabilite', 'prevision', 'sectorielle' );
	}
	/** Recalcule et stocke tous les instantanés. */
	public static function refresh() {
		$n = 0;
		foreach ( self::domaines() as $d ) {
			$data = FKC_Metrics::$d();
			self::set( $d, $data );
			$n++;
		}
		self::set( '_meta', array( 'refreshed_at' => date( 'Y-m-d H:i' ) ) );
		return $n;
	}
	public static function set( $cle, $data ) {
		FKC_DB::q( "INSERT INTO analyse_snapshots(cle,valeur,updated_at) VALUES(?,?,datetime('now','localtime'))
			ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur, updated_at=excluded.updated_at",
			array( $cle, json_encode( $data ) ) );
	}
	public static function get( $cle ) {
		$r = FKC_DB::q( 'SELECT valeur FROM analyse_snapshots WHERE cle=?', array( $cle ) )->fetch();
		return $r ? json_decode( $r['valeur'], true ) : null;
	}
	public static function updatedAt() {
		$m = self::get( '_meta' ); return $m['refreshed_at'] ?? null;
	}
	/** Date du dernier rafraîchissement SI les écrans s'en servent encore (aujourd'hui), sinon null. */
	public static function utiliseDepuis() {
		return self::frais( '_meta' ) ? self::updatedAt() : null;
	}
	/**
	 * Donnée d'un domaine : l'instantané DU JOUR s'il existe, sinon le calcul
	 * en direct.
	 *
	 * 1.832.0 — un instantané ne périmait jamais : après un seul
	 * rafraîchissement, les écrans Clients, Recouvrement, RH, Inventaire…
	 * et la tuile « Impayés » restaient figés à cette date, des semaines
	 * durant, avec pour seul indice une petite mention. Un instantané sert à
	 * aller vite dans la journée, pas à remplacer la réalité.
	 */
	public static function data( $domaine ) {
		if ( self::frais( $domaine ) ) { return self::get( $domaine ); }
		return method_exists( 'FKC_Metrics', $domaine ) ? FKC_Metrics::$domaine() : null;
	}
	/** L'instantané existe-t-il ET date-t-il d'aujourd'hui ? */
	public static function frais( $domaine ) {
		try {
			$r = FKC_DB::q( 'SELECT updated_at FROM analyse_snapshots WHERE cle=?', array( $domaine ) )->fetch();
			return $r && substr( (string) $r['updated_at'], 0, 10 ) === date( 'Y-m-d' );
		} catch ( \Throwable $e ) { return false; }
	}
	public static function fromWarehouse( $domaine ) { return self::frais( $domaine ); }

	/* ══════════════════════════════════════════════════════════════════════
	 * Entrepôt historisé (Data Warehouse) — Priorité 10.
	 *
	 * Au-delà des instantanés à plat ci-dessus, l'entrepôt conserve une SÉRIE
	 * TEMPORELLE de chaque métrique (cœur + packs). Une capture par jour et par
	 * métrique permet d'analyser l'évolution de n'importe quel indicateur sur la
	 * durée, tous modules confondus, sans recalcul lourd.
	 * ════════════════════════════════════════════════════════════════════ */

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS dw_faits(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					jour TEXT NOT NULL,
					metrique TEXT NOT NULL,
					libelle TEXT,
					valeur REAL,
					pack TEXT,
					capture_at TEXT DEFAULT(datetime('now','localtime')),
					UNIQUE(jour, metrique)
				);
				CREATE INDEX IF NOT EXISTS idx_dw_metrique ON dw_faits(metrique);
				CREATE INDEX IF NOT EXISTS idx_dw_jour ON dw_faits(jour);
			" );
		} catch ( \Throwable $e ) { /* silencieux */ }
		self::$ready = true;
	}

	/**
	 * Capture toutes les métriques du jour dans l'entrepôt (cœur + packs).
	 * Idempotent : une seule ligne par (jour, métrique), mise à jour si rappelé.
	 * @param string|null $jour  date de capture (défaut aujourd'hui)
	 * @return int nombre de métriques capturées
	 */
	public static function capturer( $jour = null ) {
		self::ensure();
		$jour = $jour ?: date( 'Y-m-d' );
		$pack = class_exists( 'FKC_License' ) ? FKC_License::packCode() : '';
		$n = 0;
		if ( ! class_exists( 'FKC_Metrics' ) ) { return 0; }
		$registre = FKC_Metrics::registre();
		foreach ( $registre as $cle => $def ) {
			$libelle = $def[0] ?? $cle;
			$val = FKC_Metrics::metric( $cle );
			if ( null === $val ) { continue; }
			try {
				FKC_DB::q(
					"INSERT INTO dw_faits(jour,metrique,libelle,valeur,pack,capture_at)
					 VALUES(?,?,?,?,?,datetime('now','localtime'))
					 ON CONFLICT(jour,metrique) DO UPDATE SET valeur=excluded.valeur, libelle=excluded.libelle, capture_at=excluded.capture_at",
					array( $jour, $cle, $libelle, (float) $val, $pack )
				);
				$n++;
			} catch ( \Throwable $e ) { /* métrique ignorée */ }
		}
		return $n;
	}

	/** Série temporelle d'une métrique sur les N derniers jours. */
	public static function serie( $metrique, $jours = 30 ) {
		self::ensure();
		try {
			$rows = FKC_DB::q(
				"SELECT jour, valeur FROM dw_faits WHERE metrique=? AND jour>=? ORDER BY jour ASC",
				array( $metrique, date( 'Y-m-d', strtotime( "-{$jours} day" ) ) )
			)->fetchAll();
			$out = array();
			foreach ( $rows as $r ) { $out[ $r['jour'] ] = (float) $r['valeur']; }
			return $out;
		} catch ( \Throwable $e ) { return array(); }
	}

	/** Dernière valeur capturée d'une métrique + sa date. */
	public static function derniere( $metrique ) {
		self::ensure();
		try {
			$r = FKC_DB::q(
				"SELECT jour, valeur FROM dw_faits WHERE metrique=? ORDER BY jour DESC LIMIT 1",
				array( $metrique )
			)->fetch();
			return $r ? array( 'jour' => $r['jour'], 'valeur' => (float) $r['valeur'] ) : null;
		} catch ( \Throwable $e ) { return null; }
	}

	/**
	 * Catalogue des métriques présentes dans l'entrepôt, avec dernière valeur,
	 * variation vs la capture précédente et série courte pour sparkline.
	 */
	public static function catalogue( $joursSparkline = 14 ) {
		self::ensure();
		$out = array();
		try {
			$metriques = FKC_DB::q( "SELECT DISTINCT metrique, libelle, pack FROM dw_faits ORDER BY pack, metrique" )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		foreach ( $metriques as $m ) {
			$serie = self::serie( $m['metrique'], $joursSparkline );
			$vals = array_values( $serie );
			$derniere = end( $vals );
			$precedente = count( $vals ) >= 2 ? $vals[ count( $vals ) - 2 ] : null;
			$variation = ( null !== $precedente && $precedente != 0 ) ? round( ( $derniere - $precedente ) / abs( $precedente ) * 100, 1 ) : null;
			$out[] = array(
				'metrique' => $m['metrique'], 'libelle' => $m['libelle'], 'pack' => $m['pack'],
				'valeur' => false !== $derniere ? $derniere : null,
				'variation' => $variation, 'serie' => $vals, 'points' => count( $vals ),
			);
		}
		return $out;
	}

	/** Statistiques globales de l'entrepôt. */
	public static function stats() {
		self::ensure();
		try {
			$nbMetriques = (int) FKC_DB::q( "SELECT COUNT(DISTINCT metrique) FROM dw_faits" )->fetchColumn();
			$nbJours = (int) FKC_DB::q( "SELECT COUNT(DISTINCT jour) FROM dw_faits" )->fetchColumn();
			$nbFaits = (int) FKC_DB::q( "SELECT COUNT(*) FROM dw_faits" )->fetchColumn();
			$premier = FKC_DB::q( "SELECT MIN(jour) FROM dw_faits" )->fetchColumn();
			$dernier = FKC_DB::q( "SELECT MAX(jour) FROM dw_faits" )->fetchColumn();
			return array( 'metriques' => $nbMetriques, 'jours' => $nbJours, 'faits' => $nbFaits, 'premier' => $premier, 'dernier' => $dernier );
		} catch ( \Throwable $e ) { return array( 'metriques' => 0, 'jours' => 0, 'faits' => 0, 'premier' => null, 'dernier' => null ); }
	}

	/** Purge les faits plus vieux que N jours (rétention). */
	public static function purger( $joursRetention = 365 ) {
		self::ensure();
		try {
			FKC_DB::q( "DELETE FROM dw_faits WHERE jour < ?", array( date( 'Y-m-d', strtotime( "-{$joursRetention} day" ) ) ) );
			return true;
		} catch ( \Throwable $e ) { return false; }
	}
}
