<?php
/**
 * Contrôleur Santé — écrans partagés des packs Clinique & Hôpital :
 * planning des consultations, praticiens & rétrocessions, hospitalisation.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteController {

	protected function module() { return FKC_Packs::activeCode(); }
	protected function setFlash( $ok, $msg ) { $_SESSION['__sante_flash'] = array( 'ok' => (bool) $ok, 'msg' => (string) $msg ); }
	protected function flash() { $f = $_SESSION['__sante_flash'] ?? null; unset( $_SESSION['__sante_flash'] ); return $f; }

	/* ── Planning des consultations ──────────────────────────────────────── */
	public function planning() {
		$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_GET['date'] ?? '' ) ) ? $_GET['date'] : date( 'Y-m-d' );
		FKC_View::render( 'sante::planning', array(
			'title' => 'Planning des consultations', 'module' => $this->module(),
			'date' => $date,
			'rdvs' => FKC_SantePlanning::jour( $date ),
			'praticiens' => FKC_SantePraticien::tous(),
			'compteurs' => FKC_SantePlanning::compteursJour( $date ),
			'flash' => $this->flash(),
		) );
	}

	public function rdvCreer() {
		list( $ok, $msg ) = FKC_SantePlanning::create( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning?date=' . urlencode( (string) ( $_POST['date'] ?? date( 'Y-m-d' ) ) ) );
	}

	public function rdvFacturer( $id ) {
		list( $ok, $msg ) = FKC_SantePlanning::facturer( (int) $id );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning' );
	}

	public function rdvAnnuler( $id ) {
		list( $ok, $msg ) = FKC_SantePlanning::annuler( (int) $id );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning' );
	}

	/* ── Praticiens & rétrocessions ──────────────────────────────────────── */
	public function praticiens() {
		$ym = preg_match( '/^\d{4}-\d{2}$/', (string) ( $_GET['mois'] ?? '' ) ) ? $_GET['mois'] : date( 'Y-m' );
		FKC_View::render( 'sante::praticiens', array(
			'title' => 'Praticiens & rétrocessions', 'module' => $this->module(),
			'praticiens' => FKC_SantePraticien::tous( false ),
			'mois' => $ym,
			'bordereau' => FKC_SantePraticien::bordereauRetrocessions( $ym ),
			'flash' => $this->flash(),
		) );
	}

	public function praticienCreer() {
		list( $ok, $msg ) = FKC_SantePraticien::create( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/praticiens' );
	}

	/* ── Hospitalisation ─────────────────────────────────────────────────── */
	public function hospitalisation() {
		FKC_View::render( 'sante::hospitalisation', array(
			'title' => 'Hospitalisation', 'module' => $this->module(),
			'lits' => FKC_SanteHospit::lits(),
			'occupation' => FKC_SanteHospit::occupation(),
			'sejours' => FKC_SanteHospit::sejoursEnCours(),
			'flash' => $this->flash(),
		) );
	}

	public function litCreer() {
		list( $ok, $msg ) = FKC_SanteHospit::creerLit( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function admettre() {
		list( $ok, $msg ) = FKC_SanteHospit::admettre( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function sortir( $sejourId ) {
		list( $ok, $msg ) = FKC_SanteHospit::sortir( (int) $sejourId, (string) ( $_POST['sortie'] ?? '' ) ?: null );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	/* ── Dossier médical électronique (DME) ──────────────────────────────── */

	public function dossiers() {
		FKC_View::render( 'sante::dossiers', array(
			'title' => 'Dossiers patients', 'module' => $this->module(),
			'patients' => FKC_SanteDossier::patients( (string) ( $_GET['q'] ?? '' ) ),
			'q' => (string) ( $_GET['q'] ?? '' ),
			'flash' => $this->flash(),
		) );
	}

	public function patientCreer() {
		list( $ok, $msg, $id ) = FKC_SanteDossier::creerPatient( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/dossiers' . ( $ok && $id ? '/' . $id : '' ) );
	}

	public function dossier( $id ) {
		$p = FKC_SanteDossier::patient( (int) $id );
		if ( ! $p ) { $this->setFlash( false, 'Patient introuvable.' ); return redirect( $this->module() . '/dossiers' ); }
		$consults = FKC_SanteDossier::consultations( (int) $id );
		$prescr = array();
		foreach ( $consults as $c ) { $prescr[ (int) $c['id'] ] = FKC_SanteDossier::prescriptions( (int) $c['id'] ); }
		FKC_View::render( 'sante::dossier', array(
			'title' => 'Dossier · ' . $p['nom'], 'module' => $this->module(),
			'p' => $p, 'age' => FKC_SanteDossier::age( $p ),
			'allergies' => FKC_SanteDossier::allergies( (int) $id ),
			'antecedents' => FKC_SanteDossier::antecedents( (int) $id ),
			'consultations' => $consults, 'prescriptions' => $prescr,
			'praticiens' => FKC_SantePraticien::tous(),
			'flash' => $this->flash(),
		) );
	}

	public function dossierAction( $id ) {
		$id = (int) $id;
		switch ( (string) ( $_POST['action'] ?? '' ) ) {
			case 'antecedent':
				list( $ok, $msg ) = FKC_SanteDossier::ajouterAntecedent( $id, $_POST['type'] ?? 'autre', $_POST['libelle'] ?? '', $_POST['depuis'] ?? '' );
				$this->setFlash( $ok, $msg );
				break;
			case 'allergie':
				list( $ok, $msg ) = FKC_SanteDossier::ajouterAllergie( $id, $_POST['substance'] ?? '', $_POST['severite'] ?? 'moderee', $_POST['note'] ?? '' );
				$this->setFlash( $ok, $msg );
				break;
			case 'consultation':
				list( $ok, $msg, $cid ) = FKC_SanteDossier::creerConsultation( array_merge( $_POST, array( 'patient_id' => $id ) ) );
				$this->setFlash( $ok, $msg );
				break;
			case 'prescription':
				$r = FKC_SanteDossier::prescrire( $_POST['consultation_id'] ?? 0, $_POST['medicament'] ?? '', $_POST['posologie'] ?? '', $_POST['duree'] ?? '' );
				$this->setFlash( $r['ok'], $r['ok'] ? ( $r['alerte'] ?: 'Prescription ajoutée.' ) : 'Échec de la prescription.' );
				break;
			default:
				$this->setFlash( false, 'Action inconnue.' );
		}
		redirect( $this->module() . '/dossiers/' . $id );
	}
}
