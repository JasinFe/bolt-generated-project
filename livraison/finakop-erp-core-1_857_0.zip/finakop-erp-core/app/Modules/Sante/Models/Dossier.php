<?php
/**
 * Santé Premium — DOSSIER MÉDICAL ÉLECTRONIQUE (DME).
 *
 * Le socle clinique (praticiens, RDV, lits) gère l'agenda et le séjour ; le
 * DME gère le SOIN lui-même :
 *
 *   PATIENT       — identité, données vitales de base, groupe sanguin.
 *   ANTÉCÉDENTS   — l'histoire médicale : chroniques, chirurgicaux, familiaux.
 *   ALLERGIES     — critiques : elles doivent SAUTER AUX YEUX avant toute
 *                   prescription (une allergie pénicilline non vue tue).
 *   CONSULTATIONS — chaque passage horodaté : motif, examen, diagnostic,
 *                   constantes (tension, poids, température).
 *   PRESCRIPTIONS — les médicaments prescrits lors d'une consultation ; le
 *                   moteur CROISE la prescription avec les allergies connues
 *                   du patient et alerte AVANT validation.
 *
 * Confidentialité : le DME est rattaché au pack actif (clinique|hôpital) et
 * cloisonné comme le reste des données de santé.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteDossier {

	protected static $ready = false;

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : 'clinique'; }

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		// Le dossier référence les praticiens (consultations) : s'assurer que
		// leur table existe, même si le pack ne les a pas encore touchés.
		if ( class_exists( 'FKC_SantePraticien' ) ) { FKC_SantePraticien::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_patients(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				code TEXT NOT NULL,
				nom TEXT NOT NULL,
				sexe TEXT DEFAULT '',
				date_naissance TEXT,
				telephone TEXT DEFAULT '',
				groupe_sanguin TEXT DEFAULT '',
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, code)
			);
			CREATE TABLE IF NOT EXISTS sante_antecedents(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				patient_id INTEGER NOT NULL,
				type TEXT NOT NULL DEFAULT 'chronique', -- chronique | chirurgical | familial | autre
				libelle TEXT NOT NULL,
				depuis TEXT DEFAULT '',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_allergies(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				patient_id INTEGER NOT NULL,
				substance TEXT NOT NULL,
				severite TEXT NOT NULL DEFAULT 'moderee', -- legere | moderee | severe
				note TEXT DEFAULT '',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_consultations(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				patient_id INTEGER NOT NULL,
				praticien_id INTEGER,
				date_consult TEXT NOT NULL,
				motif TEXT DEFAULT '',
				examen TEXT DEFAULT '',
				diagnostic TEXT DEFAULT '',
				tension TEXT DEFAULT '',
				poids REAL,
				temperature REAL,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_prescriptions(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				consultation_id INTEGER NOT NULL,
				medicament TEXT NOT NULL,
				posologie TEXT DEFAULT '',
				duree TEXT DEFAULT '',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_pat_pack ON sante_patients(pack, actif);
			CREATE INDEX IF NOT EXISTS idx_sante_antec ON sante_antecedents(patient_id);
			CREATE INDEX IF NOT EXISTS idx_sante_allerg ON sante_allergies(patient_id);
			CREATE INDEX IF NOT EXISTS idx_sante_consult ON sante_consultations(patient_id, date_consult);
			CREATE INDEX IF NOT EXISTS idx_sante_presc ON sante_prescriptions(consultation_id);
		" );
	}

	/* ── Patients ────────────────────────────────────────────────────────── */

	public static function nextCode() {
		self::ensure();
		$n = (int) FKC_DB::q( 'SELECT COUNT(*) c FROM sante_patients WHERE pack=?', array( self::pack() ) )->fetch()['c'];
		return 'PAT-' . str_pad( (string) ( $n + 1 ), 5, '0', STR_PAD_LEFT );
	}

	public static function creerPatient( array $d ) {
		self::ensure();
		$nom = trim( (string) ( $d['nom'] ?? '' ) );
		if ( '' === $nom ) { return array( false, 'Le nom du patient est obligatoire.', null ); }
		$code = trim( (string) ( $d['code'] ?? '' ) ) ?: self::nextCode();
		try {
			FKC_DB::q(
				'INSERT INTO sante_patients(pack, code, nom, sexe, date_naissance, telephone, groupe_sanguin) VALUES(?,?,?,?,?,?,?)',
				array( self::pack(), $code, $nom, (string) ( $d['sexe'] ?? '' ), $d['date_naissance'] ?? null,
					(string) ( $d['telephone'] ?? '' ), (string) ( $d['groupe_sanguin'] ?? '' ) )
			);
			return array( true, 'Patient créé.', (int) FKC_DB::conn()->lastInsertId() );
		} catch ( \Throwable $e ) { return array( false, 'Code patient déjà utilisé.', null ); }
	}

	public static function patients( $recherche = '' ) {
		self::ensure();
		$sql = 'SELECT * FROM sante_patients WHERE pack=? AND actif=1'; $a = array( self::pack() );
		if ( '' !== trim( (string) $recherche ) ) {
			$sql .= ' AND (nom LIKE ? OR code LIKE ?)';
			$like = '%' . trim( $recherche ) . '%'; $a[] = $like; $a[] = $like;
		}
		return FKC_DB::q( $sql . ' ORDER BY nom LIMIT 100', $a )->fetchAll();
	}

	public static function patient( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_patients WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	public static function age( $patient ) {
		if ( empty( $patient['date_naissance'] ) ) { return null; }
		$n = strtotime( $patient['date_naissance'] );
		return $n ? (int) floor( ( time() - $n ) / ( 365.25 * 86400 ) ) : null;
	}

	/* ── Antécédents & allergies ─────────────────────────────────────────── */

	public static function ajouterAntecedent( $patientId, $type, $libelle, $depuis = '' ) {
		self::ensure();
		if ( '' === trim( (string) $libelle ) ) { return array( false, 'Libellé obligatoire.' ); }
		$type = in_array( $type, array( 'chronique', 'chirurgical', 'familial', 'autre' ), true ) ? $type : 'autre';
		FKC_DB::q( 'INSERT INTO sante_antecedents(patient_id, type, libelle, depuis) VALUES(?,?,?,?)',
			array( (int) $patientId, $type, trim( $libelle ), trim( (string) $depuis ) ) );
		return array( true, 'Antécédent ajouté.' );
	}

	public static function antecedents( $patientId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_antecedents WHERE patient_id=? ORDER BY type, id', array( (int) $patientId ) )->fetchAll();
	}

	public static function ajouterAllergie( $patientId, $substance, $severite = 'moderee', $note = '' ) {
		self::ensure();
		if ( '' === trim( (string) $substance ) ) { return array( false, 'Substance obligatoire.' ); }
		$severite = in_array( $severite, array( 'legere', 'moderee', 'severe' ), true ) ? $severite : 'moderee';
		FKC_DB::q( 'INSERT INTO sante_allergies(patient_id, substance, severite, note) VALUES(?,?,?,?)',
			array( (int) $patientId, trim( $substance ), $severite, trim( (string) $note ) ) );
		return array( true, 'Allergie enregistrée.' );
	}

	public static function allergies( $patientId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_allergies WHERE patient_id=? ORDER BY (severite=\'severe\') DESC, substance', array( (int) $patientId ) )->fetchAll();
	}

	/* ── Consultations & prescriptions ───────────────────────────────────── */

	public static function creerConsultation( array $d ) {
		self::ensure();
		$patientId = (int) ( $d['patient_id'] ?? 0 );
		if ( ! self::patient( $patientId ) ) { return array( false, 'Patient introuvable.', null ); }
		FKC_DB::q(
			'INSERT INTO sante_consultations(patient_id, praticien_id, date_consult, motif, examen, diagnostic, tension, poids, temperature) VALUES(?,?,?,?,?,?,?,?,?)',
			array( $patientId, ! empty( $d['praticien_id'] ) ? (int) $d['praticien_id'] : null,
				$d['date_consult'] ?? date( 'Y-m-d H:i' ), (string) ( $d['motif'] ?? '' ),
				(string) ( $d['examen'] ?? '' ), (string) ( $d['diagnostic'] ?? '' ),
				(string) ( $d['tension'] ?? '' ),
				'' !== ( $d['poids'] ?? '' ) ? (float) $d['poids'] : null,
				'' !== ( $d['temperature'] ?? '' ) ? (float) $d['temperature'] : null )
		);
		return array( true, 'Consultation enregistrée.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function consultations( $patientId, $limit = 50 ) {
		self::ensure();
		return FKC_DB::q(
			'SELECT c.*, p.nom AS praticien FROM sante_consultations c LEFT JOIN sante_praticiens p ON p.id=c.praticien_id
			 WHERE c.patient_id=? ORDER BY c.date_consult DESC LIMIT ' . max( 1, (int) $limit ),
			array( (int) $patientId )
		)->fetchAll();
	}

	public static function prescriptions( $consultationId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_prescriptions WHERE consultation_id=? ORDER BY id', array( (int) $consultationId ) )->fetchAll();
	}

	/**
	 * Ajoute une prescription APRÈS avoir croisé le médicament avec les
	 * allergies connues du patient. Retourne l'alerte s'il y a correspondance
	 * (la prescription est tout de même enregistrée : c'est le praticien qui
	 * tranche, mais il est prévenu).
	 * @return array{ok: bool, alerte: string|null}
	 */
	public static function prescrire( $consultationId, $medicament, $posologie = '', $duree = '' ) {
		self::ensure();
		$c = FKC_DB::q( 'SELECT * FROM sante_consultations WHERE id=?', array( (int) $consultationId ) )->fetch();
		if ( ! $c ) { return array( 'ok' => false, 'alerte' => null ); }
		if ( '' === trim( (string) $medicament ) ) { return array( 'ok' => false, 'alerte' => null ); }
		$alerte = self::verifierAllergie( (int) $c['patient_id'], $medicament );
		FKC_DB::q( 'INSERT INTO sante_prescriptions(consultation_id, medicament, posologie, duree) VALUES(?,?,?,?)',
			array( (int) $consultationId, trim( $medicament ), trim( (string) $posologie ), trim( (string) $duree ) ) );
		return array( 'ok' => true, 'alerte' => $alerte );
	}

	/**
	 * Détecte si un médicament recoupe une allergie du patient (correspondance
	 * de sous-chaîne insensible à la casse, dans les deux sens : « pénicilline »
	 * dans « Amoxicilline pénicilline », ou substance incluse dans le nom).
	 * @return string|null message d'alerte, null si rien.
	 */
	public static function verifierAllergie( $patientId, $medicament ) {
		$med = mb_strtolower( trim( (string) $medicament ) );
		if ( '' === $med ) { return null; }
		foreach ( self::allergies( $patientId ) as $a ) {
			$sub = mb_strtolower( trim( $a['substance'] ) );
			if ( '' === $sub ) { continue; }
			if ( false !== mb_strpos( $med, $sub ) || false !== mb_strpos( $sub, $med ) ) {
				return sprintf( '⚠️ ALLERGIE %s : « %s » recoupe l\'allergie connue « %s » du patient.',
					mb_strtoupper( $a['severite'] ), $medicament, $a['substance'] );
			}
		}
		return null;
	}

	/** Résumé cliniquement utile pour l'en-tête du dossier (allergies d'abord). */
	public static function resume( $patientId ) {
		return array(
			'allergies' => self::allergies( $patientId ),
			'antecedents' => self::antecedents( $patientId ),
			'derniere_consult' => self::consultations( $patientId, 1 )[0] ?? null,
		);
	}
}
