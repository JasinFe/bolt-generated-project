<?php
/**
 * Planning des consultations — module Santé (packs Clinique & Hôpital).
 *
 * Rendez-vous par praticien et par jour. Un rendez-vous honoré peut être
 * facturé en un clic : la facture part dans le circuit standard des pièces
 * (workflow de validation → écriture comptable SYSCOHADA), rattachée au
 * dossier patient. Le montant facturé alimente le bordereau de rétrocession
 * du praticien.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SantePlanning {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_rdv(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				praticien_id INTEGER NOT NULL,
				dossier_id INTEGER,
				patient TEXT NOT NULL,
				date TEXT NOT NULL,
				heure TEXT NOT NULL DEFAULT '08:00',
				motif TEXT,
				montant REAL NOT NULL DEFAULT 0,
				statut TEXT NOT NULL DEFAULT 'prevu',
				piece_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_rdv_jour ON sante_rdv(pack, date, praticien_id);
		" );
		/*
		 * LA TABLE DES PRATICIENS AUSSI (1.690.0).
		 *
		 * `jour()` joint `sante_praticiens`, dont la création appartient à
		 * FKC_SantePraticien. Sans cet appel, l'écran Planning mourait sur
		 * « no such table » dans TOUT dossier où personne n'avait ouvert
		 * l'écran des praticiens avant — c'est-à-dire tout dossier neuf.
		 *
		 * L'écran était donc mort sur les DEUX packs qui le portent, cabinet
		 * médical et optique, et il l'était depuis toujours. Aucun harnais ne
		 * le voyait : la couverture de routes ne s'exécutait que sur
		 * « generique » et « bazar », qui n'ont pas le module Santé.
		 *
		 * FKC_SanteDossier::ensure() faisait déjà exactement cet appel : la
		 * convention existait, ce modèle-ci l'avait oubliée.
		 */
		if ( class_exists( 'FKC_SantePraticien' ) ) { FKC_SantePraticien::ensure(); }
		self::$ready = true;
	}

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	/** Type de pièce utilisé pour facturer une consultation selon le pack. */
	public static function typeConsultation() {
		$types = array_keys( (array) ( FKC_Packs::verticalConfig()['pieces'] ?? array() ) );
		if ( in_array( 'soins', $types, true ) ) { return 'soins'; }
		if ( in_array( 'actes', $types, true ) ) { return 'actes'; }
		return $types[0] ?? '';
	}

	/** @return array{bool, string, int|null} ( ok, message, id|null ) */
	public static function create( array $d ) {
		self::ensure();
		$prat = class_exists( 'FKC_SantePraticien' ) ? FKC_SantePraticien::find( (int) ( $d['praticien_id'] ?? 0 ) ) : null;
		if ( ! $prat ) { return array( false, 'Praticien introuvable.', null ); }
		$patient = trim( (string) ( $d['patient'] ?? '' ) );
		if ( '' === $patient ) { return array( false, 'Le nom du patient est requis.', null ); }
		$date = (string) ( $d['date'] ?? date( 'Y-m-d' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) { return array( false, 'Date invalide.', null ); }
		$montant = (float) ( $d['montant'] ?? 0 );
		if ( $montant <= 0 ) { $montant = (float) $prat['tarif_consultation']; }
		FKC_DB::q(
			'INSERT INTO sante_rdv(pack, praticien_id, dossier_id, patient, date, heure, motif, montant) VALUES(?,?,?,?,?,?,?,?)',
			array(
				self::pack(), (int) $prat['id'],
				! empty( $d['dossier_id'] ) ? (int) $d['dossier_id'] : null,
				$patient, $date, (string) ( $d['heure'] ?? '08:00' ),
				trim( (string) ( $d['motif'] ?? '' ) ), max( 0, $montant ),
			)
		);
		return array( true, 'Rendez-vous planifié.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function find( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_rdv WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	/** Planning d'un jour, groupé par praticien. */
	public static function jour( $date = null ) {
		self::ensure();
		$d = $date ?: date( 'Y-m-d' );
		return FKC_DB::q(
			"SELECT r.*, p.nom praticien, p.specialite
			 FROM sante_rdv r JOIN sante_praticiens p ON p.id=r.praticien_id
			 WHERE r.pack=? AND r.date=? ORDER BY p.nom, r.heure",
			array( self::pack(), $d )
		)->fetchAll();
	}

	public static function annuler( $id ) {
		self::ensure();
		$r = self::find( $id );
		if ( ! $r ) { return array( false, 'Rendez-vous introuvable.' ); }
		if ( 'honore' === $r['statut'] ) { return array( false, 'Ce rendez-vous est déjà facturé.' ); }
		FKC_DB::q( "UPDATE sante_rdv SET statut='annule' WHERE id=?", array( (int) $id ) );
		return array( true, 'Rendez-vous annulé.' );
	}

	/**
	 * Facture une consultation : crée (au besoin) le dossier patient, émet la
	 * pièce dans le circuit standard (soumise + validée → comptabilisée) et
	 * marque le rendez-vous honoré. Idempotent (un RDV ne se facture qu'une fois).
	 * @return array{bool, string, mixed} ( ok, message, pieceId|null )
	 */
	public static function facturer( $id ) {
		self::ensure();
		$r = self::find( $id );
		if ( ! $r ) { return array( false, 'Rendez-vous introuvable.', null ); }
		if ( 'honore' === $r['statut'] ) { return array( false, 'Consultation déjà facturée.', null ); }
		if ( 'annule' === $r['statut'] ) { return array( false, 'Rendez-vous annulé : replanifier avant de facturer.', null ); }
		if ( (float) $r['montant'] <= 0 ) { return array( false, 'Montant de la consultation non défini.', null ); }
		$cfg = FKC_Packs::verticalConfig();
		$type = self::typeConsultation();
		if ( '' === $type ) { return array( false, 'Aucun type de pièce disponible.', null ); }
		// Dossier patient : réutilise le dossier lié, sinon le crée.
		$did = (int) ( $r['dossier_id'] ?? 0 );
		if ( $did <= 0 ) {
			list( $ok, $msg, $did ) = FKC_VpDossier::create( array( 'libelle' => $r['patient'], 'tiers_nom' => $r['patient'] ), $cfg );
			if ( ! $ok ) { return array( false, 'Dossier patient : ' . $msg, null ); }
		}
		$prat = FKC_SantePraticien::find( (int) $r['praticien_id'] );
		$libelle = 'Consultation ' . ( $prat ? $prat['nom'] : '' ) . ' du ' . $r['date'];
		list( $ok, $msg, $pid ) = FKC_VpPiece::create( $did, array( 'type' => $type, 'montant_ht' => (float) $r['montant'], 'libelle' => $libelle ), $cfg );
		if ( ! $ok ) { return array( false, $msg, null ); }
		$piece = FKC_VpPiece::find( $pid );
		FKC_WorkflowEngine::transition( (int) $piece['wf_instance_id'], 'soumettre' );
		FKC_WorkflowEngine::transition( (int) $piece['wf_instance_id'], 'valider' );
		FKC_DB::q( "UPDATE sante_rdv SET statut='honore', piece_id=?, dossier_id=? WHERE id=?", array( (int) $pid, $did, (int) $id ) );
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_rdv_facturer', 'RDV #' . $id . ' facturé (pièce #' . $pid . ')' ); }
		return array( true, 'Consultation facturée et comptabilisée.', (int) $pid );
	}

	/** Compteurs du jour (pour KPI/assistant). */
	public static function compteursJour( $date = null ) {
		self::ensure();
		$d = $date ?: date( 'Y-m-d' );
		$rows = FKC_DB::q( 'SELECT statut, COUNT(*) n FROM sante_rdv WHERE pack=? AND date=? GROUP BY statut', array( self::pack(), $d ) )->fetchAll();
		$c = array( 'prevu' => 0, 'honore' => 0, 'annule' => 0, 'total' => 0 );
		foreach ( $rows as $r ) { $c[ $r['statut'] ] = (int) $r['n']; $c['total'] += (int) $r['n']; }
		return $c;
	}
}
