<?php
/**
 * Hospitalisation — module Santé (packs Clinique & Hôpital).
 *
 * Lits par service, admissions et sorties. À la sortie, le séjour est
 * facturé automatiquement (nuitées × tarif du lit) dans le circuit standard
 * des pièces. Le taux d'occupation des lits — l'indicateur roi de
 * l'hospitalisation — devient un chiffre RÉEL (lits occupés / lits ouverts).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteHospit {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_lits(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				numero TEXT NOT NULL,
				service TEXT,
				tarif_nuit REAL NOT NULL DEFAULT 0,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_sejours(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				lit_id INTEGER NOT NULL,
				dossier_id INTEGER,
				patient TEXT NOT NULL,
				entree TEXT NOT NULL,
				sortie TEXT,
				tarif_nuit REAL NOT NULL DEFAULT 0,
				nuitees INTEGER,
				piece_id INTEGER,
				statut TEXT NOT NULL DEFAULT 'en_cours',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_sej ON sante_sejours(pack, statut, lit_id);
		" );
		self::$ready = true;
	}

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	/** Type de pièce pour la facture de séjour selon le pack. */
	public static function typeSejour() {
		$types = array_keys( (array) ( FKC_Packs::verticalConfig()['pieces'] ?? array() ) );
		if ( in_array( 'sejour', $types, true ) ) { return 'sejour'; }
		if ( in_array( 'soins', $types, true ) ) { return 'soins'; }
		return $types[0] ?? '';
	}

	/* ── Lits ────────────────────────────────────────────────────────────── */
	public static function creerLit( array $d ) {
		self::ensure();
		$numero = trim( (string) ( $d['numero'] ?? '' ) );
		if ( '' === $numero ) { return array( false, 'Le numéro du lit est requis.', null ); }
		FKC_DB::q(
			'INSERT INTO sante_lits(pack, numero, service, tarif_nuit) VALUES(?,?,?,?)',
			array( self::pack(), $numero, trim( (string) ( $d['service'] ?? '' ) ), max( 0, (float) ( $d['tarif_nuit'] ?? 0 ) ) )
		);
		return array( true, 'Lit enregistré.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function lits() {
		self::ensure();
		return FKC_DB::q(
			"SELECT l.*, s.id sejour_id, s.patient patient_actuel, s.entree
			 FROM sante_lits l
			 LEFT JOIN sante_sejours s ON s.lit_id=l.id AND s.statut='en_cours'
			 WHERE l.pack=? AND l.actif=1 ORDER BY l.service, l.numero",
			array( self::pack() )
		)->fetchAll();
	}

	/** Taux d'occupation réel : lits occupés / lits ouverts. */
	public static function occupation() {
		self::ensure();
		$r = FKC_DB::q(
			"SELECT COUNT(l.id) lits, COUNT(s.id) occupes
			 FROM sante_lits l LEFT JOIN sante_sejours s ON s.lit_id=l.id AND s.statut='en_cours'
			 WHERE l.pack=? AND l.actif=1",
			array( self::pack() )
		)->fetch();
		$lits = (int) ( $r['lits'] ?? 0 ); $occ = (int) ( $r['occupes'] ?? 0 );
		return array( 'lits' => $lits, 'occupes' => $occ, 'taux' => $lits > 0 ? round( $occ / $lits * 100, 1 ) : 0.0 );
	}

	/* ── Séjours ─────────────────────────────────────────────────────────── */
	/** Admet un patient dans un lit libre. @return array( ok, message, sejourId|null ) */
	public static function admettre( array $d ) {
		self::ensure();
		$lit = FKC_DB::q( 'SELECT * FROM sante_lits WHERE id=? AND pack=? AND actif=1', array( (int) ( $d['lit_id'] ?? 0 ), self::pack() ) )->fetch();
		if ( ! $lit ) { return array( false, 'Lit introuvable.', null ); }
		$dejaOccupe = FKC_DB::q( "SELECT id FROM sante_sejours WHERE lit_id=? AND statut='en_cours'", array( (int) $lit['id'] ) )->fetch();
		if ( $dejaOccupe ) { return array( false, 'Ce lit est déjà occupé.', null ); }
		$patient = trim( (string) ( $d['patient'] ?? '' ) );
		if ( '' === $patient ) { return array( false, 'Le nom du patient est requis.', null ); }
		$entree = (string) ( $d['entree'] ?? date( 'Y-m-d' ) );
		$tarif = isset( $d['tarif_nuit'] ) && (float) $d['tarif_nuit'] > 0 ? (float) $d['tarif_nuit'] : (float) $lit['tarif_nuit'];
		FKC_DB::q(
			'INSERT INTO sante_sejours(pack, lit_id, dossier_id, patient, entree, tarif_nuit) VALUES(?,?,?,?,?,?)',
			array( self::pack(), (int) $lit['id'], ! empty( $d['dossier_id'] ) ? (int) $d['dossier_id'] : null, $patient, $entree, $tarif )
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_admission', 'Admission #' . $id . ' — ' . $patient . ' (lit ' . $lit['numero'] . ')' ); }
		return array( true, 'Patient admis (lit ' . $lit['numero'] . ').', $id );
	}

	public static function findSejour( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_sejours WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	public static function sejoursEnCours() {
		self::ensure();
		return FKC_DB::q(
			"SELECT s.*, l.numero lit, l.service FROM sante_sejours s JOIN sante_lits l ON l.id=s.lit_id
			 WHERE s.pack=? AND s.statut='en_cours' ORDER BY s.entree",
			array( self::pack() )
		)->fetchAll();
	}

	/**
	 * Sortie du patient : calcule les nuitées (minimum 1), facture le séjour
	 * dans le circuit standard, libère le lit. Idempotent.
	 * @return array{bool, string, mixed} ( ok, message, pieceId|null )
	 */
	public static function sortir( $sejourId, $dateSortie = null ) {
		self::ensure();
		$s = self::findSejour( $sejourId );
		if ( ! $s ) { return array( false, 'Séjour introuvable.', null ); }
		if ( 'en_cours' !== $s['statut'] ) { return array( false, 'Séjour déjà clôturé.', null ); }
		$sortie = $dateSortie ?: date( 'Y-m-d' );
		if ( $sortie < $s['entree'] ) { return array( false, 'La sortie ne peut précéder l\'entrée.', null ); }
		$nuitees = max( 1, (int) round( ( strtotime( $sortie ) - strtotime( $s['entree'] ) ) / 86400 ) );
		$montant = $nuitees * (float) $s['tarif_nuit'];
		if ( $montant <= 0 ) { return array( false, 'Tarif de nuitée non défini pour ce séjour.', null ); }
		$cfg = FKC_Packs::verticalConfig();
		$type = self::typeSejour();
		if ( '' === $type ) { return array( false, 'Aucun type de pièce disponible.', null ); }
		$did = (int) ( $s['dossier_id'] ?? 0 );
		if ( $did <= 0 ) {
			list( $ok, $msg, $did ) = FKC_VpDossier::create( array( 'libelle' => $s['patient'], 'tiers_nom' => $s['patient'] ), $cfg );
			if ( ! $ok ) { return array( false, 'Dossier patient : ' . $msg, null ); }
		}
		$libelle = 'Séjour du ' . $s['entree'] . ' au ' . $sortie . ' (' . $nuitees . ' nuitée' . ( $nuitees > 1 ? 's' : '' ) . ')';
		list( $ok, $msg, $pid ) = FKC_VpPiece::create( $did, array( 'type' => $type, 'montant_ht' => $montant, 'libelle' => $libelle ), $cfg );
		if ( ! $ok ) { return array( false, $msg, null ); }
		$piece = FKC_VpPiece::find( $pid );
		FKC_WorkflowEngine::transition( (int) $piece['wf_instance_id'], 'soumettre' );
		FKC_WorkflowEngine::transition( (int) $piece['wf_instance_id'], 'valider' );
		FKC_DB::q(
			"UPDATE sante_sejours SET statut='clos', sortie=?, nuitees=?, piece_id=?, dossier_id=? WHERE id=?",
			array( $sortie, $nuitees, (int) $pid, $did, (int) $sejourId )
		);
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_sortie', 'Sortie séjour #' . $sejourId . ' — ' . $nuitees . ' nuitées facturées (pièce #' . $pid . ')' ); }
		return array( true, 'Sortie enregistrée : ' . $nuitees . ' nuitée(s) facturée(s).', (int) $pid );
	}
}
