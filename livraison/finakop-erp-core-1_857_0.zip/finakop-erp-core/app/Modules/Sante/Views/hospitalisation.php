<?php /** @var string $module @var array $lits @var array $occupation @var array $sejours @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'hospitalisation' ) );
$litsLibres = array_values( array_filter( $lits, fn( $l ) => empty( $l['sejour_id'] ) ) );
$occCol = $occupation['taux'] >= 85 ? 'var(--danger)' : ( $occupation['taux'] >= 60 ? 'var(--ok)' : 'var(--warn)' );
?>
<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
		<h2>🛏️ Hospitalisation</h2>
		<span class="tag" style="color:<?= $occCol ?>;font-weight:700">Occupation : <?= e( $occupation['taux'] ) ?> % (<?= (int) $occupation['occupes'] ?>/<?= (int) $occupation['lits'] ?> lits)</span>
	</div>
	<div class="card-body">
		<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
		<?php if ( ! $lits ) : ?>
			<div class="alert alert-warn">Aucun lit enregistré — commencez par déclarer vos lits ci-dessous.</div>
		<?php else : ?>
		<table class="table">
			<thead><tr><th>Lit</th><th>Service</th><th style="text-align:right">Tarif / nuit</th><th>État</th><th>Patient</th><th>Entrée</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $lits as $l ) : $occupe = ! empty( $l['sejour_id'] ); ?>
				<tr>
					<td style="font-weight:700"><?= e( $l['numero'] ) ?></td>
					<td class="muted"><?= e( $l['service'] ) ?></td>
					<td style="text-align:right"><?= fkc_money( $l['tarif_nuit'] ) ?> F</td>
					<td><span class="tag" style="color:<?= $occupe ? 'var(--warn)' : 'var(--ok)' ?>"><?= $occupe ? 'Occupé' : 'Libre' ?></span></td>
					<td><?= $occupe ? e( $l['patient_actuel'] ) : '—' ?></td>
					<td class="muted"><?= $occupe ? e( $l['entree'] ) : '' ?></td>
					<td style="text-align:right">
						<?php if ( $occupe ) : ?>
						<form method="post" action="<?= e( url( $module . '/hospitalisation/sejour/' . (int) $l['sejour_id'] . '/sortir' ) ) ?>" style="display:inline-flex;gap:6px;align-items:center">
							<?= FKC_Csrf::field() ?>
							<input type="date" name="sortie" value="<?= e( date( 'Y-m-d' ) ) ?>" class="fld" style="margin:0">
							<button class="btn btn-primary btn-sm" type="submit" onclick="return confirm('Clôturer le séjour et facturer les nuitées ?');">Sortie + facture</button>
						</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="muted" style="font-size:12px;margin-top:8px">À la sortie, le séjour est facturé automatiquement (nuitées × tarif du lit) et part en comptabilité par le circuit habituel.</p>
		<?php endif; ?>
	</div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px">
	<div class="card card-flush">
		<div class="card-head"><h2>➕ Admettre un patient</h2></div>
		<div class="card-body">
			<?php if ( ! $litsLibres ) : ?>
				<div class="alert">Aucun lit libre.</div>
			<?php else : ?>
			<form method="post" action="<?= e( url( $module . '/hospitalisation/admettre' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Lit</span><select name="lit_id"><?php foreach ( $litsLibres as $l ) : ?><option value="<?= (int) $l['id'] ?>"><?= e( $l['numero'] ) ?><?= $l['service'] ? ' — ' . e( $l['service'] ) : '' ?> (<?= fkc_money( $l['tarif_nuit'] ) ?> F/nuit)</option><?php endforeach; ?></select></label>
				<label class="fld"><span>Patient</span><input name="patient" required></label>
				<label class="fld"><span>Date d'entrée</span><input type="date" name="entree" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<button class="btn btn-primary" type="submit">Admettre</button>
			</form>
			<?php endif; ?>
		</div>
	</div>
	<div class="card card-flush">
		<div class="card-head"><h2>🛏️ Déclarer un lit</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url( $module . '/hospitalisation/lit' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Numéro</span><input name="numero" required placeholder="A-101"></label>
				<label class="fld"><span>Service</span><input name="service" placeholder="Médecine, Maternité, Chirurgie…"></label>
				<label class="fld"><span>Tarif par nuit (F)</span><input type="number" name="tarif_nuit" min="0" step="1000" value="25000"></label>
				<button class="btn btn-primary" type="submit">Enregistrer le lit</button>
			</form>
		</div>
	</div>
</div>
