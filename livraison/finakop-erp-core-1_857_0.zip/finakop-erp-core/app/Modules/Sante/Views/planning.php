<?php /** @var string $module @var string $date @var array $rdvs @var array $praticiens @var array $compteurs @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'planning' ) );
$statuts = array( 'prevu' => array( 'Prévu', 'var(--blue)' ), 'honore' => array( 'Facturé', 'var(--ok)' ), 'annule' => array( 'Annulé', 'var(--muted)' ) );
?>
<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
		<h2>🗓️ Planning des consultations</h2>
		<form method="get" action="<?= e( url( $module . '/planning' ) ) ?>" style="display:flex;gap:8px;align-items:center">
			<input type="date" name="date" value="<?= e( $date ) ?>" class="fld" style="margin:0">
			<button class="btn btn-ghost btn-sm" type="submit">Afficher</button>
		</form>
	</div>
	<div class="card-body">
		<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
		<p class="muted" style="font-size:12.5px;margin-bottom:14px">
			<?= (int) $compteurs['total'] ?> rendez-vous — <?= (int) $compteurs['prevu'] ?> prévu(s), <?= (int) $compteurs['honore'] ?> facturé(s), <?= (int) $compteurs['annule'] ?> annulé(s).
			Facturer une consultation crée la pièce dans le circuit habituel (validation → comptabilité) et alimente la rétrocession du praticien.
		</p>
		<?php if ( ! $rdvs ) : ?>
			<div class="alert">Aucun rendez-vous ce jour.</div>
		<?php else : ?>
		<table class="table">
			<thead><tr><th>Heure</th><th>Praticien</th><th>Patient</th><th>Motif</th><th style="text-align:right">Montant</th><th>Statut</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $rdvs as $r ) : $st = $statuts[ $r['statut'] ] ?? array( $r['statut'], 'var(--muted)' ); ?>
				<tr>
					<td><?= e( $r['heure'] ) ?></td>
					<td><?= e( $r['praticien'] ) ?> <span class="muted" style="font-size:11px"><?= e( $r['specialite'] ) ?></span></td>
					<td><?= e( $r['patient'] ) ?></td>
					<td class="muted"><?= e( $r['motif'] ) ?></td>
					<td style="text-align:right"><?= fkc_money( $r['montant'] ) ?> F</td>
					<td><span class="tag" style="color:<?= $st[1] ?>"><?= e( $st[0] ) ?></span></td>
					<td style="text-align:right;white-space:nowrap">
						<?php if ( 'prevu' === $r['statut'] ) : ?>
						<form method="post" action="<?= e( url( $module . '/planning/rdv/' . (int) $r['id'] . '/facturer' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" type="submit">Facturer</button></form>
						<form method="post" action="<?= e( url( $module . '/planning/rdv/' . (int) $r['id'] . '/annuler' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Annuler</button></form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
	</div>
</div>

<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>➕ Nouveau rendez-vous</h2></div>
	<div class="card-body">
		<?php if ( ! $praticiens ) : ?>
			<div class="alert alert-warn">Aucun praticien enregistré — <a href="<?= e( url( $module . '/praticiens' ) ) ?>">créer un praticien</a> d'abord.</div>
		<?php else : ?>
		<form method="post" action="<?= e( url( $module . '/planning/rdv' ) ) ?>" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;align-items:end">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Praticien</span><select name="praticien_id"><?php foreach ( $praticiens as $p ) : ?><option value="<?= (int) $p['id'] ?>"><?= e( $p['nom'] ) ?><?= $p['specialite'] ? ' — ' . e( $p['specialite'] ) : '' ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Patient</span><input name="patient" required></label>
			<label class="fld"><span>Date</span><input type="date" name="date" value="<?= e( $date ) ?>"></label>
			<label class="fld"><span>Heure</span><input type="time" name="heure" value="08:00"></label>
			<label class="fld"><span>Motif</span><input name="motif"></label>
			<label class="fld"><span>Montant (F) — vide = tarif praticien</span><input type="number" name="montant" min="0" step="500"></label>
			<button class="btn btn-primary" type="submit">Planifier</button>
		</form>
		<?php endif; ?>
	</div>
</div>
