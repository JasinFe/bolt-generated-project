<?php /** @var string $module @var array $patients @var string $q @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'dossiers' ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= $flash['ok'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="form-rows" style="gap:16px">
	<div class="card card-flush">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
			<h2>🩺 Dossiers patients</h2>
			<form method="get" action="<?= e( url( $module . '/dossiers' ) ) ?>"><input name="q" value="<?= e( $q ) ?>" placeholder="Nom ou code…"><button class="btn btn-sm">Chercher</button></form>
		</div>
		<table class="table"><thead><tr><th>Code</th><th>Patient</th><th>Sexe</th><th>Groupe</th><th></th></tr></thead><tbody>
		<?php if ( ! $patients ) : ?><tr><td colspan="5" class="empty">Aucun patient<?= $q ? ' pour « ' . e( $q ) . ' »' : '' ?>.</td></tr>
		<?php else : foreach ( $patients as $p ) : ?>
			<tr><td><code style="font-size:12px"><?= e( $p['code'] ) ?></code></td>
			<td><a href="<?= e( url( $module . '/dossiers/' . (int) $p['id'] ) ) ?>"><strong><?= e( $p['nom'] ) ?></strong></a></td>
			<td class="muted"><?= e( $p['sexe'] ?: '—' ) ?></td>
			<td class="muted"><?= e( $p['groupe_sanguin'] ?: '—' ) ?></td>
			<td><a class="btn btn-sm" href="<?= e( url( $module . '/dossiers/' . (int) $p['id'] ) ) ?>">Ouvrir</a></td></tr>
		<?php endforeach; endif; ?>
		</tbody></table>
	</div>
	<div class="card">
		<div class="card-head"><h2>＋ Nouveau patient</h2></div>
		<div class="card-body"><form method="post" action="<?= e( url( $module . '/dossiers/creer' ) ) ?>"><?= FKC_Csrf::field() ?>
			<label class="fld"><span>Nom complet</span><input name="nom" required></label>
			<div style="display:flex;gap:8px"><label class="fld" style="flex:1"><span>Sexe</span><select name="sexe"><option value="">—</option><option>M</option><option>F</option></select></label>
			<label class="fld" style="flex:1"><span>Groupe</span><input name="groupe_sanguin" placeholder="O+"></label></div>
			<label class="fld"><span>Naissance</span><input type="date" name="date_naissance"></label>
			<label class="fld"><span>Téléphone</span><input name="telephone"></label>
			<button class="btn btn-primary" type="submit">Créer le dossier</button>
		</form></div>
	</div>
</div>
