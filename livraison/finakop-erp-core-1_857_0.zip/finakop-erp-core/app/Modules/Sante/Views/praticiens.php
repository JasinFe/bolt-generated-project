<?php /** @var string $module @var array $praticiens @var string $mois @var array $bordereau @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'praticiens' ) );
$totRetro = 0; $totHono = 0;
foreach ( $bordereau as $l ) { $totRetro += $l['retrocession']; $totHono += $l['honoraires']; }
?>
<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
		<h2>🩺 Bordereau de rétrocessions</h2>
		<form method="get" action="<?= e( url( $module . '/praticiens' ) ) ?>" style="display:flex;gap:8px;align-items:center">
			<input type="month" name="mois" value="<?= e( $mois ) ?>" class="fld" style="margin:0">
			<button class="btn btn-ghost btn-sm" type="submit">Afficher</button>
		</form>
	</div>
	<div class="card-body">
		<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
		<p class="muted" style="font-size:12.5px;margin-bottom:14px">Part des honoraires de consultation à reverser à chaque praticien pour le mois — calculée sur les consultations facturées du planning.</p>
		<table class="table">
			<thead><tr><th>Praticien</th><th>Spécialité</th><th style="text-align:right">Consult.</th><th style="text-align:right">Honoraires</th><th style="text-align:right">Taux</th><th style="text-align:right">À reverser</th><th style="text-align:right">Net établissement</th></tr></thead>
			<tbody>
			<?php foreach ( $bordereau as $l ) : ?>
				<tr>
					<td><?= e( $l['praticien'] ) ?></td>
					<td class="muted"><?= e( $l['specialite'] ) ?></td>
					<td style="text-align:right"><?= (int) $l['nb'] ?></td>
					<td style="text-align:right"><?= fkc_money( $l['honoraires'] ) ?> F</td>
					<td style="text-align:right"><?= e( $l['taux'] ) ?> %</td>
					<td style="text-align:right;font-weight:700;color:var(--orange)"><?= fkc_money( $l['retrocession'] ) ?> F</td>
					<td style="text-align:right;color:var(--ok)"><?= fkc_money( $l['net_etablissement'] ) ?> F</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot><tr style="font-weight:700"><td colspan="3">Total</td><td style="text-align:right"><?= fkc_money( $totHono ) ?> F</td><td></td><td style="text-align:right;color:var(--orange)"><?= fkc_money( $totRetro ) ?> F</td><td style="text-align:right;color:var(--ok)"><?= fkc_money( $totHono - $totRetro ) ?> F</td></tr></tfoot>
		</table>
	</div>
</div>

<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>➕ Nouveau praticien</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( $module . '/praticiens/creer' ) ) ?>" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;align-items:end">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Nom</span><input name="nom" required placeholder="Dr Kouassi"></label>
			<label class="fld"><span>Spécialité</span><input name="specialite" placeholder="Généraliste"></label>
			<label class="fld"><span>Tarif consultation (F)</span><input type="number" name="tarif_consultation" min="0" step="500" value="10000"></label>
			<label class="fld"><span>Taux de rétrocession (%)</span><input type="number" name="taux_retrocession" min="0" max="100" step="5" value="50"></label>
			<button class="btn btn-primary" type="submit">Enregistrer</button>
		</form>
		<p class="muted" style="font-size:12px;margin-top:10px">💡 Le taux de rétrocession est la part des honoraires reversée au praticien (usuellement 40 à 60&nbsp;%). Le reste constitue la marge de l'établissement.</p>
	</div>
</div>
