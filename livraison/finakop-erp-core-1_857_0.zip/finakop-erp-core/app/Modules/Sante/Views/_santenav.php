<?php /** Sous-navigation santé. @var string $module @var string $actif */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$actif = $actif ?? '';
$liens = array( 'dossiers' => '🩺 Dossiers', 'planning' => '🗓️ Planning', 'praticiens' => '👨‍⚕️ Praticiens', 'hospitalisation' => '🏥 Hospitalisation' );
?>
<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">
	<?php foreach ( $liens as $k => $lbl ) : ?>
		<a href="<?= e( url( $module . '/' . $k ) ) ?>" class="btn btn-sm<?= $actif === $k ? ' btn-primary' : ' btn-ghost' ?>"><?= e( $lbl ) ?></a>
	<?php endforeach; ?>
</div>
