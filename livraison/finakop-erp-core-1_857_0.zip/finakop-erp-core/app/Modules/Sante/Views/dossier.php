<?php /** @var string $module @var array $p @var int|null $age @var array $allergies @var array $antecedents @var array $consultations @var array $prescriptions @var array $praticiens @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module . '/dossiers', 'backLabel' => 'Dossiers' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'dossier' ) );
$sevBadge = array( 'severe' => 'var(--danger)', 'moderee' => 'var(--warn)', 'legere' => 'var(--muted)' );
$typeAnt = array( 'chronique' => 'Chronique', 'chirurgical' => 'Chirurgical', 'familial' => 'Familial', 'autre' => 'Autre' );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= $flash['ok'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:8px">
	<h1 style="font-size:20px"><?= e( $p['nom'] ) ?> <span class="muted" style="font-size:14px"><?= e( $p['code'] ) ?><?= null !== $age ? ' · ' . (int) $age . ' ans' : '' ?><?= $p['sexe'] ? ' · ' . e( $p['sexe'] ) : '' ?><?= $p['groupe_sanguin'] ? ' · ' . e( $p['groupe_sanguin'] ) : '' ?></span></h1>
</div>

<?php if ( $allergies ) : ?>
	<div class="alert alert-err" style="margin-bottom:12px">
		<strong>⚠️ ALLERGIES :</strong>
		<?= e( implode( ' · ', array_map( fn( $a ) => $a['substance'] . ' (' . $a['severite'] . ')', $allergies ) ) ) ?>
		— vérifiez avant toute prescription.
	</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 320px;gap:16px;align-items:start">
	<div class="card card-flush">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
			<h2>Consultations</h2>
			<details><summary class="btn btn-primary btn-sm">＋ Nouvelle consultation</summary></details>
		</div>
		<form method="post" action="<?= e( url( $module . '/dossiers/' . (int) $p['id'] ) ) ?>" style="padding:12px 16px;border-bottom:1px solid var(--border)"><?= FKC_Csrf::field() ?>
			<input type="hidden" name="action" value="consultation">
			<div style="display:flex;gap:8px;flex-wrap:wrap">
				<label class="fld" style="flex:2;min-width:180px"><span>Motif</span><input name="motif" required></label>
				<label class="fld" style="flex:1"><span>Praticien</span><select name="praticien_id"><option value="">—</option><?php foreach ( $praticiens as $pr ) : ?><option value="<?= (int) $pr['id'] ?>"><?= e( $pr['nom'] ) ?></option><?php endforeach; ?></select></label>
			</div>
			<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
				<label class="fld" style="flex:1"><span>Tension</span><input name="tension" placeholder="12/8" style="width:80px"></label>
				<label class="fld" style="flex:1"><span>Poids (kg)</span><input class="num" name="poids" style="width:80px"></label>
				<label class="fld" style="flex:1"><span>Temp. (°C)</span><input class="num" name="temperature" style="width:80px"></label>
			</div>
			<label class="fld" style="margin-top:6px"><span>Diagnostic</span><input name="diagnostic"></label>
			<button class="btn btn-sm" style="margin-top:6px">Enregistrer la consultation</button>
		</form>
		<?php if ( ! $consultations ) : ?><div class="empty" style="padding:16px">Aucune consultation enregistrée.</div>
		<?php else : foreach ( $consultations as $c ) : ?>
			<div style="border-bottom:1px solid var(--border);padding:12px 16px">
				<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
					<strong><?= e( substr( (string) $c['date_consult'], 0, 16 ) ) ?> — <?= e( $c['motif'] ?: 'consultation' ) ?></strong>
					<span class="muted" style="font-size:12px"><?= e( $c['praticien'] ?: '' ) ?></span>
				</div>
				<?php if ( $c['diagnostic'] ) : ?><div style="font-size:13px;margin-top:2px">Diagnostic : <?= e( $c['diagnostic'] ) ?></div><?php endif; ?>
				<?php if ( $c['tension'] || $c['poids'] || $c['temperature'] ) : ?>
					<div class="muted" style="font-size:12px"><?= e( trim( ( $c['tension'] ? 'TA ' . $c['tension'] : '' ) . ( $c['poids'] ? ' · ' . $c['poids'] . ' kg' : '' ) . ( $c['temperature'] ? ' · ' . $c['temperature'] . ' °C' : '' ), ' ·' ) ) ?></div>
				<?php endif; ?>
				<?php $pr = $prescriptions[ (int) $c['id'] ] ?? array(); ?>
				<?php if ( $pr ) : ?>
					<div style="margin-top:6px;font-size:13px"><strong>Ordonnance :</strong>
						<ul style="margin:4px 0 0;padding-left:18px"><?php foreach ( $pr as $x ) : ?><li><?= e( $x['medicament'] ) ?><?= $x['posologie'] ? ' — ' . e( $x['posologie'] ) : '' ?><?= $x['duree'] ? ' (' . e( $x['duree'] ) . ')' : '' ?></li><?php endforeach; ?></ul>
					</div>
				<?php endif; ?>
				<details style="margin-top:6px"><summary class="btn btn-ghost btn-sm" style="display:inline-block">＋ Prescrire</summary>
					<form method="post" action="<?= e( url( $module . '/dossiers/' . (int) $p['id'] ) ) ?>" style="display:flex;gap:6px;align-items:end;margin-top:6px;flex-wrap:wrap"><?= FKC_Csrf::field() ?>
						<input type="hidden" name="action" value="prescription"><input type="hidden" name="consultation_id" value="<?= (int) $c['id'] ?>">
						<input name="medicament" placeholder="Médicament" required style="flex:2">
						<input name="posologie" placeholder="Posologie" style="flex:1">
						<input name="duree" placeholder="Durée" style="flex:1">
						<button class="btn btn-sm">Ajouter</button>
					</form>
					<div class="muted" style="font-size:11px;margin-top:2px">Le médicament est croisé avec les allergies du patient.</div>
				</details>
			</div>
		<?php endforeach; endif; ?>
	</div>

	<div>
		<div class="card" style="margin-bottom:16px">
			<div class="card-head"><h2>🚨 Allergies</h2></div>
			<div class="card-body">
				<?php if ( ! $allergies ) : ?><p class="muted" style="font-size:13px">Aucune allergie connue.</p>
				<?php else : foreach ( $allergies as $a ) : ?>
					<div style="font-size:13px;margin-bottom:4px"><span style="color:<?= $sevBadge[ $a['severite'] ] ?? 'var(--fg)' ?>">●</span> <strong><?= e( $a['substance'] ) ?></strong> <span class="muted">(<?= e( $a['severite'] ) ?>)</span></div>
				<?php endforeach; endif; ?>
				<form method="post" action="<?= e( url( $module . '/dossiers/' . (int) $p['id'] ) ) ?>" style="margin-top:8px"><?= FKC_Csrf::field() ?>
					<input type="hidden" name="action" value="allergie">
					<div style="display:flex;gap:6px"><input name="substance" placeholder="Substance" required style="flex:2"><select name="severite" style="flex:1"><option value="legere">Légère</option><option value="moderee" selected>Modérée</option><option value="severe">Sévère</option></select></div>
					<button class="btn btn-sm" style="margin-top:6px">Ajouter</button>
				</form>
			</div>
		</div>
		<div class="card">
			<div class="card-head"><h2>📋 Antécédents</h2></div>
			<div class="card-body">
				<?php if ( ! $antecedents ) : ?><p class="muted" style="font-size:13px">Aucun antécédent.</p>
				<?php else : foreach ( $antecedents as $a ) : ?>
					<div style="font-size:13px;margin-bottom:4px"><span class="tag"><?= e( $typeAnt[ $a['type'] ] ?? $a['type'] ) ?></span> <?= e( $a['libelle'] ) ?><?= $a['depuis'] ? ' <span class="muted">(' . e( $a['depuis'] ) . ')</span>' : '' ?></div>
				<?php endforeach; endif; ?>
				<form method="post" action="<?= e( url( $module . '/dossiers/' . (int) $p['id'] ) ) ?>" style="margin-top:8px"><?= FKC_Csrf::field() ?>
					<input type="hidden" name="action" value="antecedent">
					<div style="display:flex;gap:6px"><select name="type" style="flex:1"><option value="chronique">Chronique</option><option value="chirurgical">Chirurgical</option><option value="familial">Familial</option><option value="autre">Autre</option></select><input name="libelle" placeholder="Libellé" required style="flex:2"></div>
					<button class="btn btn-sm" style="margin-top:6px">Ajouter</button>
				</form>
			</div>
		</div>
	</div>
</div>
