<?php /** @var array $societes @var array $toutes @var array $stats @var int|null $active_id @var bool $is_admin @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'societes', 'backLabel' => 'Accueil' ) );
$formes  = FKC_Societe::formes();
$regimes = FKC_Societe::regimes();
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<div>
		<span class="stat-label">Entités gérées</span>
		<strong style="font-size:18px"><?= count( $societes ) ?></strong>
		<?php if ( $active_id ) : ?><span class="muted" style="margin-left:8px">· une entité est active</span><?php endif; ?>
	</div>
	<?php if ( $is_admin ) : ?>
		<a class="btn btn-primary btn-sm" href="<?= e( url('societes/nouvelle') ) ?>">+ Nouvelle entité</a>
	<?php endif; ?>
</div>

<?php if ( ! $societes ) : ?>
	<div class="card"><div class="card-body" style="text-align:center;padding:40px">
		<div style="font-size:40px;margin-bottom:10px">🏢</div>
		<h2 style="font-family:Syne,sans-serif;margin:0 0 8px">Aucune entité accessible</h2>
		<p class="muted"><?= $is_admin ? "Créez votre première entité pour démarrer." : "Aucune entité ne vous a encore été attribuée. Contactez votre administrateur." ?></p>
		<?php if ( $is_admin ) : ?><a class="btn btn-primary" href="<?= e( url('societes/nouvelle') ) ?>" style="margin-top:12px">+ Créer une entité</a><?php endif; ?>
	</div></div>
<?php else : ?>
	<div class="soc-grid">
		<?php foreach ( $societes as $s ) : $st = $stats[ $s['id'] ] ?? array(); $isActive = (int) $s['id'] === (int) $active_id; ?>
			<div class="soc-card <?= $isActive ? 'active' : '' ?>">
				<div class="soc-top">
					<?php if ( FKC_Societe::hasLogo( $s ) ) : ?>
						<span class="soc-avatar soc-avatar-img"><img src="<?= e( FKC_Societe::logoUrl( $s ) ) ?>" alt=""></span>
					<?php else : ?>
						<span class="soc-avatar"><?= e( strtoupper( substr( $s['sigle'] ?: $s['raison_sociale'], 0, 2 ) ) ) ?></span>
					<?php endif; ?>
					<div class="soc-id">
						<div class="soc-name"><?= e( $s['raison_sociale'] ) ?></div>
						<div class="soc-meta">
							<?php if ( $s['forme_juridique'] && isset( $formes[ $s['forme_juridique'] ] ) ) : ?><span><?= e( $formes[ $s['forme_juridique'] ] ) ?></span><?php endif; ?>
							<?php if ( $s['ncc'] ) : ?><span>· NCC <?= e( $s['ncc'] ) ?></span><?php endif; ?>
							<?php
							/* Secteur d'activité du dossier. Un cabinet suit des entités de
							   métiers différents, et chacune a son propre pack : c'est lui qui
							   commande ses écrans, sa terminologie et ses schémas comptables.
							   Ne rien afficher revenait à masquer cette différence. */
							?>
							<span>· <?= e( FKC_Societe::packLabel( $st['pack'] ?? '' ) ) ?></span>
						</div>
					</div>
					<?php if ( $isActive ) : ?><span class="soc-badge">Active</span><?php endif; ?>
				</div>
				<div class="soc-stats">
					<div><span class="ss-n"><?= (int) ( $st['ecritures'] ?? 0 ) ?></span><span class="ss-l">écritures</span></div>
					<div><span class="ss-n"><?= (int) ( $st['factures'] ?? 0 ) ?></span><span class="ss-l">factures</span></div>
					<div><span class="ss-n"><?= e( $s['regime_fiscal'] ?: '—' ) ?></span><span class="ss-l">régime</span></div>
				</div>
				<div class="soc-actions">
					<?php if ( $isActive ) : ?>
						<a class="btn btn-ghost btn-sm btn-block" href="<?= e( url('') ) ?>">Ouvrir le tableau de bord →</a>
					<?php else : ?>
						<form method="post" action="<?= e( url('societes/'.$s['id'].'/activer') ) ?>" style="margin:0;flex:1">
							<?= FKC_Csrf::field() ?>
							<button class="btn btn-blue btn-sm btn-block" type="submit">Sélectionner</button>
						</form>
					<?php endif; ?>
					<?php if ( $is_admin ) : ?>
						<a class="btn btn-ghost btn-sm" href="<?= e( url('societes/'.$s['id'].'/modifier') ) ?>">Gérer</a>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<?php if ( $is_admin && $toutes && count( $toutes ) !== count( $societes ) ) : ?>
	<div class="card" style="margin-top:18px"><div class="card-head"><h2>Entités désactivées</h2></div>
	<table class="table"><thead><tr><th>Entité</th><th>NCC</th><th>Statut</th><th></th></tr></thead><tbody>
		<?php foreach ( $toutes as $s ) : if ( $s['actif'] ) continue; ?>
			<tr>
				<td><strong><?= e( $s['raison_sociale'] ) ?></strong></td>
				<td class="muted"><?= e( $s['ncc'] ?: '—' ) ?></td>
				<td><span class="modbadge b-off">Inactive</span></td>
				<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url('societes/'.$s['id'].'/modifier') ) ?>">Gérer</a></td>
			</tr>
		<?php endforeach; ?>
	</tbody></table></div>
<?php endif; ?>

<p class="help" style="margin-top:14px">Chaque entité dispose de ses <strong>propres livres comptables isolés</strong> (plan comptable, journaux, écritures, factures, paie, configuration FNE). Sélectionnez une entité pour travailler dessus ; la licence et l'édition du cabinet s'appliquent à toutes.</p>

<style>
.soc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:15px}
.soc-card{background:var(--panel);border:1px solid var(--line);border-radius:13px;padding:16px;display:flex;flex-direction:column;gap:13px}
.soc-card.active{border-color:var(--orange);box-shadow:0 0 0 1px var(--orange) inset}
.soc-top{display:flex;align-items:flex-start;gap:11px}
.soc-avatar{width:42px;height:42px;flex-shrink:0;border-radius:11px;background:linear-gradient(135deg,var(--blue),var(--blue-d));display:flex;align-items:center;justify-content:center;font-family:Syne,sans-serif;font-weight:800;font-size:15px;color:#fff}
.soc-avatar-img{background:#fff;padding:3px;overflow:hidden}
.soc-avatar-img img{max-width:100%;max-height:100%;object-fit:contain}
.soc-id{flex:1;min-width:0}
.soc-name{font-family:Syne,sans-serif;font-weight:800;font-size:15.5px;line-height:1.2}
.soc-meta{font-size:11.5px;color:var(--muted);margin-top:3px;display:flex;gap:4px;flex-wrap:wrap}
.soc-badge{font-size:10.5px;font-weight:700;padding:3px 9px;border-radius:20px;background:var(--orange);color:#241500}
.soc-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;background:var(--bg2);border:1px solid var(--line);border-radius:10px;padding:11px}
.soc-stats>div{text-align:center}
.ss-n{display:block;font-family:Syne,sans-serif;font-weight:800;font-size:16px}
.ss-l{display:block;font-size:10px;text-transform:uppercase;letter-spacing:.4px;color:var(--muted2);margin-top:2px}
.soc-actions{display:flex;gap:8px;align-items:center}
</style>
