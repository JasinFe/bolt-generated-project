<?php /** @var array|null $s @var array $errors @var array $formes @var array $regimes */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); $ed = (bool) $s; ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:820px"><div class="card-head"><h2><?= $ed ? 'Modifier la entité' : 'Nouvelle entité' ?></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url('societes') ) ?>">← Retour</a></div><div class="card-body">

<?php if ( ! $ed ) : ?><p class="help">À la création, des livres comptables vierges et isolés sont générés pour cette entité : plan comptable SYSCOHADA, journaux, comptes de trésorerie et paramètres FNE par défaut. Vous y serez basculé automatiquement.</p><?php endif; ?>

<form method="post" action="<?= e( $ed ? url('societes/'.$s['id']) : url('societes') ) ?>" enctype="multipart/form-data">
	<?= FKC_Csrf::field() ?>
	<div class="form-grid" style="grid-template-columns:2fr 1fr">
		<label class="fld"><span>Raison sociale *</span><input name="raison_sociale" value="<?= e($ed?$s['raison_sociale']:'') ?>" required autofocus></label>
		<label class="fld"><span>Sigle / abréviation</span><input name="sigle" value="<?= e($ed?($s['sigle']??''):'') ?>" maxlength="12" placeholder="ex. ACME"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
		<label class="fld"><span>NCC (n° contribuable)</span><input name="ncc" value="<?= e($ed?($s['ncc']??''):'') ?>" placeholder="ex. CI-1234567 A"></label>
		<label class="fld"><span>RCCM</span><input name="rccm" value="<?= e($ed?($s['rccm']??''):'') ?>" placeholder="ex. CI-ABJ-2025-B-12345"></label>
		<label class="fld"><span>Forme juridique</span><select name="forme_juridique">
			<option value="">—</option>
			<?php foreach ( $formes as $k=>$lbl ) : ?><option value="<?= e($k) ?>" <?= ($ed && ($s['forme_juridique']??'')===$k)?'selected':'' ?>><?= e($lbl) ?></option><?php endforeach; ?>
		</select></label>
		<label class="fld"><span>Régime fiscal <span style="color:var(--danger)">*</span></span><select name="regime_fiscal" required>
			<option value="">— à choisir —</option>
			<?php foreach ( $regimes as $k=>$lbl ) : ?><option value="<?= e($k) ?>" <?= ($ed && ($s['regime_fiscal']??'')===$k)?'selected':'' ?>><?= e($lbl) ?></option><?php endforeach; ?>
		</select></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Devise</span><select name="devise">
			<?php foreach ( array('XOF'=>'Franc CFA (XOF)','EUR'=>'Euro (EUR)','USD'=>'Dollar (USD)') as $k=>$lbl ) : ?>
				<option value="<?= e($k) ?>" <?= ($ed?($s['devise']??'XOF'):'XOF')===$k?'selected':'' ?>><?= e($lbl) ?></option>
			<?php endforeach; ?>
		</select></label>
		<?php
		/*
		 * CE CHAMP COMMANDE TOUTE LA COMPTABILITÉ DEPUIS LA 1.544.0.
		 *
		 * Il existait en base et à l'écran depuis longtemps sans être lu nulle
		 * part : la clôture, les dotations, les états financiers et l'IS
		 * supposaient tous le 01/01–31/12. Il faut donc dire ce qu'il fait,
		 * et que seuls le jour et le mois comptent — l'année saisie n'a aucun
		 * sens pour un exercice qui se répète.
		 */
		?>
		<label class="fld">
			<span>Début d'exercice</span>
			<input type="date" name="exercice_debut" value="<?= e($ed?($s['exercice_debut']??''):'') ?>">
			<small class="help">Jour et mois d'ouverture (l'année saisie est ignorée). Vide = année civile,
				du 1<sup>er</sup> janvier au 31 décembre. Commande la clôture annuelle, les trimestres,
				les dotations d'amortissement et les états financiers.</small>
		</label>
	</div>
	<div class="form-grid" style="grid-template-columns:2fr 1fr">
		<label class="fld"><span>Adresse</span><input name="adresse" value="<?= e($ed?($s['adresse']??''):'') ?>" placeholder="ex. Yopougon, route de fin goudron — en face du Collège Carnot"></label>
		<label class="fld"><span>Ville</span><input name="ville" value="<?= e($ed?($s['ville']??''):'') ?>" placeholder="ex. Abidjan"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Téléphone</span><input name="telephone" value="<?= e($ed?($s['telephone']??''):'') ?>" placeholder="ex. +225 27 31 93 45 75"></label>
		<label class="fld"><span>E-mail</span><input name="email" type="email" value="<?= e($ed?($s['email']??''):'') ?>" placeholder="ex. contact@societe.ci"></label>
	</div>
	<p class="help" style="margin-top:-4px">Ces informations (raison sociale, NCC, RCCM, adresse, contacts, logo) composent l'<strong>en-tête officiel des factures</strong> de la entité.</p>

	<div class="logo-field">
		<div class="stat-label" style="margin-bottom:8px">Logo de la entité</div>
		<div class="logo-row">
			<div class="logo-preview" id="logoPreview">
				<?php if ( $ed && FKC_Societe::hasLogo( $s ) ) : ?>
					<img src="<?= e( FKC_Societe::logoUrl( $s ) ) ?>?t=<?= time() ?>" alt="Logo">
				<?php else : ?>
					<span class="logo-ph">🏢</span>
				<?php endif; ?>
			</div>
			<div class="logo-controls">
				<input type="file" name="logo" id="logoInput" accept="image/png,image/jpeg,image/gif,image/webp">
				<p class="help" style="margin:8px 0 0">PNG, JPG, GIF ou WEBP — 2 Mo maximum. Apparaît sur les factures et dans l'application.</p>
				<?php if ( $ed && FKC_Societe::hasLogo( $s ) ) : ?>
					<label class="chk" style="margin-top:8px"><input type="checkbox" name="remove_logo" value="1"> Supprimer le logo actuel</label>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<?php if ( $ed ) : ?>
		<input type="hidden" name="actif" value="0">
		<label class="chk" style="margin-top:6px"><input type="checkbox" name="actif" value="1" <?= $s['actif'] ? 'checked' : '' ?>> Entité active (décocher pour l'archiver)</label>
	<?php else : ?>
		<input type="hidden" name="actif" value="1">
	<?php endif; ?>

	<div class="actions"><button class="btn btn-primary" type="submit"><?= $ed?'Enregistrer':'Créer la entité' ?></button><a class="btn btn-ghost" href="<?= e( url('societes') ) ?>">Annuler</a></div>
</form>
</div></div>

<?php if ( $ed ) : ?>
<div class="card" style="max-width:820px;border-color:var(--danger)"><div class="card-head"><h2 style="color:var(--danger)">Zone dangereuse</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">La suppression efface définitivement les livres comptables de cette entité (écritures, factures, paie…). Cette action est irréversible. Préférez l'archivage (décocher « Entité active ») pour conserver les données.</p>
	<form method="post" action="<?= e( url('societes/'.$s['id'].'/supprimer') ) ?>" onsubmit="return confirm('Supprimer définitivement « <?= e($s['raison_sociale']) ?> » et tous ses livres comptables ? Cette action est irréversible.')">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-ghost" type="submit" style="border-color:var(--danger);color:var(--danger)">Supprimer définitivement cette entité</button>
	</form>
</div></div>
<?php endif; ?>
<style>.chk{display:flex;align-items:center;gap:8px;font-size:14px}.chk input{width:auto}
.logo-field{background:var(--bg2);border:1px solid var(--line);border-radius:12px;padding:14px;margin-top:6px}
.logo-row{display:flex;gap:16px;align-items:flex-start}
.logo-preview{width:96px;height:96px;flex-shrink:0;border-radius:12px;background:var(--panel);border:1px solid var(--line2);display:flex;align-items:center;justify-content:center;overflow:hidden}
.logo-preview img{max-width:100%;max-height:100%;object-fit:contain}
.logo-ph{font-size:34px;opacity:.5}
.logo-controls{flex:1;min-width:0}
.logo-controls input[type=file]{font-size:13px}
</style>
<script>
(function(){
	var inp=document.getElementById('logoInput'), prev=document.getElementById('logoPreview'), rm=document.querySelector('input[name=remove_logo]');
	if(inp){ inp.addEventListener('change', function(){
		var f=inp.files&&inp.files[0]; if(!f) return;
		if(rm){ rm.checked=false; }
		var r=new FileReader(); r.onload=function(e){ prev.innerHTML='<img src="'+e.target.result+'" alt="Logo">'; }; r.readAsDataURL(f);
	}); }
	if(rm){ rm.addEventListener('change', function(){ if(rm.checked){ inp.value=''; prev.innerHTML='<span class="logo-ph">🏢</span>'; } }); }
})();
</script>
