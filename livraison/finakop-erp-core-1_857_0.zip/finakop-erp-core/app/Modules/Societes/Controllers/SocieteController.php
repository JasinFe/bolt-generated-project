<?php
/** Module Multi-entités : sélection, création et gestion des entités. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SocieteController {

	/** Sélecteur / liste des entités accessibles. */
	public function index() {
		$accessibles = FKC_Tenant::accessibles();
		$stats = array();
		foreach ( $accessibles as $s ) { $stats[ $s['id'] ] = FKC_Societe::stats( $s ); }
		FKC_View::render( 'societes::index', array(
			'title'       => 'Entités',
			'societes'    => $accessibles,
			'toutes'      => FKC_Auth::isAdmin() ? FKC_Societe::all() : array(),
			'stats'       => $stats,
			'active_id'   => FKC_Tenant::id(),
			'is_admin'    => FKC_Auth::isAdmin(),
			'flash'       => $this->flash(),
		) );
	}

	public function create() { $this->requireAdmin(); $this->form( null, array() ); }

	public function edit( $id ) {
		$this->requireAdmin();
		$s = FKC_Societe::find( $id );
		if ( ! $s ) { redirect( 'societes' ); }
		$this->form( $s, array() );
	}

	protected function form( $s, $errors ) {
		FKC_View::render( 'societes::form', array(
			'title'   => $s ? 'Modifier la entité' : 'Nouvelle entité',
			's'       => $s, 'errors' => $errors,
			'formes'  => FKC_Societe::formes(),
			'regimes' => FKC_Societe::regimes(),
		) );
	}

	public function store() {
		$this->requireAdmin();
		$errors = $this->validate( $_POST );
		if ( $errors ) { return $this->form( null, $errors ); }
		// Quota d'entités (entités) du palier de licence.
		if ( ! FKC_License::within( 'societes', FKC_Societe::count() ) ) {
			$max = FKC_License::limit( 'societes' );
			$errors[] = 'Limite atteinte : votre licence ' . FKC_License::editionLabel() . ' « ' . FKC_License::resolve()['profile_label'] . ' » autorise ' . $max . ' entité(s). Passez à un palier supérieur pour en créer davantage.';
			return $this->form( null, $errors );
		}
		$id = FKC_Tenant::provision( $_POST );
		if ( ! empty( $_FILES['logo']['name'] ) ) {
			FKC_Societe::setLogo( $id, $_FILES['logo'] );
		}
		FKC_Tenant::set( $id ); // bascule sur la nouvelle entité
		$this->setFlash( 'Entité « ' . trim( (string) $_POST['raison_sociale'] ) . ' » créée. Ses livres sont prêts (plan comptable SYSCOHADA, journaux).' );
		/*
		 * Le moment de configurer est CELUI-CI, pas plus tard : l'entité vient
		 * d'être créée, l'administrateur est déjà devant son écran, et rien
		 * n'a encore été saisi qu'un changement de pack pourrait bousculer.
		 * Le parcours reste sautable — le bouton « Plus tard » ramène au
		 * tableau de bord — et rejouable depuis Paramètres › Démarrage.
		 */
		redirect( class_exists( 'FKC_Onboarding' ) ? 'demarrage' : '' );
	}

	public function update( $id ) {
		$this->requireAdmin();
		$s = FKC_Societe::find( $id );
		if ( ! $s ) { redirect( 'societes' ); }
		$errors = $this->validate( $_POST );
		if ( $errors ) { return $this->form( $s, $errors ); }
		FKC_Societe::update( $id, $_POST );
		// Logo : suppression ou remplacement.
		if ( ! empty( $_POST['remove_logo'] ) ) {
			FKC_Societe::removeLogo( $id );
		}
		if ( ! empty( $_FILES['logo']['name'] ) ) {
			list( $okLogo, $msgLogo ) = FKC_Societe::setLogo( $id, $_FILES['logo'] );
			if ( ! $okLogo ) {
				$this->setFlash( 'Entité mise à jour, mais logo refusé : ' . $msgLogo, 'err' );
				redirect( 'societes' );
			}
		}
		// Si l'on désactive la entité active, on la quitte.
		if ( empty( $_POST['actif'] ) && (int) $id === (int) FKC_Tenant::id() ) {
			FKC_Tenant::clear();
		}
		$this->setFlash( 'Entité mise à jour.' );
		redirect( 'societes' );
	}

	/** Diffuse le logo d'une entité (lecture côté serveur ; dossier protégé). */
	public function logo( $id ) {
		$s = FKC_Societe::find( $id );
		if ( ! $s || ! FKC_Tenant::userCanAccess( $id ) ) {
			http_response_code( 404 );
			exit;
		}
		$path = FKC_Societe::logoAbsPath( $s );
		if ( ! $path ) {
			http_response_code( 404 );
			exit;
		}
		$mime = $s['logo_mime'] ?: 'image/png';
		$etag = '"' . md5( $path . filemtime( $path ) ) . '"';
		if ( isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) && trim( $_SERVER['HTTP_IF_NONE_MATCH'] ) === $etag ) {
			http_response_code( 304 );
			exit;
		}
		if ( ! headers_sent() ) {
			header( 'Content-Type: ' . $mime );
			header( 'Content-Length: ' . filesize( $path ) );
			header( 'Cache-Control: private, max-age=86400' );
			header( 'ETag: ' . $etag );
		}
		readfile( $path );
		exit;
	}

	/** Bascule sur une entité (tout utilisateur autorisé). */
	public function activer( $id ) {
		if ( ! FKC_Tenant::set( $id ) ) {
			$this->setFlash( "Accès refusé à cette entité ou entité introuvable.", 'err' );
			redirect( 'societes' );
		}
		redirect( '' );
	}

	public function destroy( $id ) {
		$this->requireAdmin();
		$s = FKC_Societe::find( $id );
		if ( ! $s ) { redirect( 'societes' ); }
		if ( (int) $id === (int) FKC_Tenant::id() ) { FKC_Tenant::clear(); }
		FKC_Societe::delete( $id );
		$this->setFlash( 'Entité « ' . $s['raison_sociale'] . ' » supprimée (livres effacés).' );
		redirect( 'societes' );
	}

	/* ── helpers ── */

	protected function validate( $d ) {
		$e = array();
		if ( '' === trim( (string) ( $d['raison_sociale'] ?? '' ) ) ) { $e[] = 'La raison sociale est requise.'; }
		// 1.844.0 — le régime fiscal n'est plus facultatif : il décide de la
		// TVA des factures et des tickets, et l'ERP ne le suppose plus.
		if ( ! array_key_exists( strtoupper( trim( (string) ( $d['regime_fiscal'] ?? '' ) ) ), FKC_Societe::regimes() ) ) {
			$e[] = 'Le régime fiscal est requis (Réel normal, Réel simplifié, Entreprenant ou Microentreprise) : il décide si l\'entité collecte la TVA.';
		}
		return $e;
	}

	protected function requireAdmin() {
		if ( ! FKC_Auth::isAdmin() ) {
			http_response_code( 403 );
			FKC_View::render( 'errors.denied', array( 'reason' => 'admin' ) );
			exit;
		}
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_soc'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_soc'] ?? null; unset( $_SESSION['__flash_soc'] ); return $m; }
}
