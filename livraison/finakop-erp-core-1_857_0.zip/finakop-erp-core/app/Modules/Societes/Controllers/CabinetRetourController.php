<?php
/**
 * Retour au cabinet depuis la comptabilité d'un client (1.803.0).
 *
 * Toujours chargé : quand on travaille dans la société d'un client, le pack
 * actif est celui du CLIENT, et les classes du pack Cabinet ne sont pas
 * chargées. Le retour ne peut donc dépendre ni de FKC_CabinetDossiers ni
 * d'une route du pack — d'où ce contrôleur minimal, qui ne lit que la
 * session posée à l'ouverture et repasse par FKC_Tenant::set(), donc par le
 * contrôle d'accès ordinaire.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_CabinetRetourController {

	const SESSION = 'fkc_cabinet_retour';

	/** Contexte d'un dossier client ouvert depuis le cabinet, s'il vaut pour la société active. */
	public static function contexte() {
		$r = $_SESSION[ self::SESSION ] ?? null;
		if ( ! is_array( $r ) || empty( $r['societe_id'] ) ) { return null; }
		if ( (int) FKC_Tenant::id() !== (int) $r['societe_id'] ) { return null; }
		return $r;
	}

	public function retour() {
		$r = $_SESSION[ self::SESSION ] ?? null;
		unset( $_SESSION[ self::SESSION ] );
		if ( ! is_array( $r ) || empty( $r['cabinet_id'] ) ) { return redirect( 'societes' ); }
		if ( ! FKC_Tenant::set( (int) $r['cabinet_id'] ) ) {
			if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'cabinet_retour_refuse', 'societe=' . (int) $r['cabinet_id'] ); }
			return redirect( 'societes' );
		}
		return redirect( 'cabinet/clients/' . (int) ( $r['client_id'] ?? 0 ) );
	}
}
