<?php
/**
 * TERMINAL CLIENT — l'écran que le client a sous les doigts.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * REFONTE 1.806.0 — « FINAKOP TERMINAL PREMIUM » · PHASE 2 1.807.0 (charte
 * FinaKop, QR et frise de suivi, photos, badges, recherche, hors ligne)
 *
 * Ce fichier regroupait tout : styles, balisage, panier, formulaire,
 * confirmation, plein écran et rafraîchissement du catalogue, en 285 lignes.
 * Il n'est plus qu'une COMPOSITION :
 *
 *   components/_head        métabalises + Design System + accent validé
 *   components/header       marque de l'établissement, réseau, heure
 *   components/categories   chips de catégories
 *   components/card         carte de prestation
 *   components/action-bar   barre d'action basse
 *   components/panier       bottom sheet / drawer / panneau ancré, 2 étapes
 *   components/success      écran de succès + ticket de référence
 *   components/attract      écran d'attente
 *   components/idle         dialogue d'inactivité
 *
 * et le comportement vit dans assets/terminal/js : terminal-core (socle
 * commun à tous les écrans), terminal-cart (modèle du panier),
 * terminal-client (parcours de cet écran).
 *
 * CE QUI NE CHANGE PAS, ET NE DOIT PAS CHANGER
 *
 *  · TOUT EST DIMENSIONNÉ POUR UN DOIGT : cibles de 56 à 72 px, aucun survol
 *    requis, aucun menu déroulant.
 *  · LE PRIX EST AFFICHÉ MAIS N'ENGAGE RIEN : « total estimé », jamais « à
 *    payer ». Le serveur relit ses prix ; la demande part en brouillon et
 *    c'est l'accueil qui la chiffre.
 *  · LE CONTACT EST FACULTATIF : un champ obligatoire fait abandonner une
 *    demande sur une borne. `inputmode="tel"` fait sortir le clavier numérique.
 *  · LA CONFIRMATION DIT CE QUE LE SERVEUR SAIT (1.736.0) : l'état affiché
 *    sur le ticket est relu par la route de suivi (`urls.suivi`).
 *  · MODE ASSISTÉ (1.736.0) : en libre-service l'écran se remet seul à zéro
 *    après la confirmation ; en assisté, il attend l'opérateur.
 * ─────────────────────────────────────────────────────────────────────────
 *
 * @var array $terminal @var array $ui @var array $identite @var array $voc
 * @var array $catalogue @var bool $peutCommander @var bool $autoReset
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$voc = array_merge( array(
	'titre' => 'Nos prestations', 'intro' => '', 'panier' => 'Ma sélection',
	'bouton' => 'Envoyer', 'confirmation' => 'Demande transmise.', 'identite' => 'Votre nom',
	'contact' => 'Votre téléphone', 'ajouter' => 'Ajouter', 'voir' => 'Voir ma demande',
	'continuer' => 'Continuer', 'etape_coord' => 'Vos coordonnées',
	'aide_coord' => 'Pour vous appeler quand c\'est votre tour. Rien d\'obligatoire.',
	'tout' => 'Tout', 'attract' => 'Touchez l\'écran pour commencer', 'nouvelle' => 'Nouvelle demande',
	'estime' => 'Total estimé', 'mention_prix' => 'Montant indicatif : le tarif définitif est confirmé à l\'accueil.',
	'devis' => 'Sur devis', 'choisir' => 'Choisir',
), (array) $voc );

$ui = (array) ( $ui ?? FKC_TerminalTheme::resoudre( $terminal, null, 'clair' ) );
$reglages = (array) ( $ui['reglages'] ?? FKC_Terminal::reglages( $terminal ) );
$catalogue = array_values( (array) $catalogue );
$identite = (array) ( $identite ?? array() );

/* Rubriques dans l'ordre d'apparition du catalogue (qui suit l'ordre choisi au bureau). */
/* Phase 3 (1.814.0) : contenus promotionnels, relus pour CE catalogue (article lié encore présent). */
$promos = array_values( (array) ( $promos ?? ( class_exists( 'FKC_TerminalPromo' ) ? FKC_TerminalPromo::publiques( (string) ( $terminal['pack'] ?? '' ), $catalogue ) : array() ) ) );
/* 1.820.0 — horaires : hors ouverture, la borne affiche « Fermé » (et le serveur refuse les commandes). */
$ouverture = (array) ( $ouverture ?? FKC_Terminal::ouverture( $terminal ) );
$fkcFerme = empty( $ouverture['ouvert'] );
/* Aperçu depuis l'administration (1.820.0) : aucune route de borne n'est appelée (pas de jeton). */
$fkcApercu = ! empty( $apercu );
$fkcAOptions = false;
foreach ( $catalogue as $a ) { if ( ! empty( $a['options'] ) ) { $fkcAOptions = true; break; } }
$categories = array();
foreach ( $catalogue as $a ) {
	$c = trim( (string) ( $a['categorie'] ?? '' ) );
	if ( '' !== $c ) { $categories[ $c ] = ( $categories[ $c ] ?? 0 ) + 1; }
}

/*
 * LA CONFIGURATION DE LA PAGE, EN UN SEUL BLOC JSON.
 *
 * Le catalogue n'y porte que ce que la carte affiche déjà ; le prix n'y sert
 * qu'à l'estimation. Encodé avec JSON_HEX_TAG : un libellé contenant
 * « </script> » ne peut pas refermer la balise et injecter du code.
 */
$fkcConfig = array(
	'ecran'       => 'client',
	'mode'        => (string) ( $terminal['mode'] ?? 'libre' ),
	'autoReset'   => ! empty( $autoReset ),
	'peutCommander' => (bool) $peutCommander,
	'delai'       => (int) $reglages['delai_inactivite'],
	'attract'     => (bool) $reglages['attract'],
	'successSecondes' => 10,
	'indicatif'   => (string) ( $identite['indicatif'] ?? '' ),
	/* 1.808.0 — étape « lieu » (table) et champ téléphone, selon le métier. */
	'lieu'        => ( ! empty( $identite['lieu'] ) && is_array( $identite['lieu'] ) ) ? $identite['lieu'] : null,
	'telephone'   => ! isset( $identite['telephone'] ) || (bool) $identite['telephone'],
	'devise'      => 'F',
	'maxLignes'   => FKC_TerminalAdapter::MAX_LIGNES,
	'maxQte'      => FKC_TerminalAdapter::MAX_QTE,
	'catalogue'   => array_map( function ( $a ) {
		return array(
			'id' => (int) $a['id'], 'libelle' => (string) $a['libelle'], 'prix' => (float) $a['prix'],
			'devis' => ! empty( $a['devis'] ), 'icone' => (string) ( $a['icone'] ?? '' ),
			'prix_affiche' => (string) $a['prix_affiche'], 'categorie' => (string) ( $a['categorie'] ?? '' ),
			'image' => (string) ( $a['image'] ?? '' ),
			/* 1.812.0 — options (cuisson, suppléments) : libellé et supplément seulement. */
			'options' => array_values( (array) ( $a['options'] ?? array() ) ),
		);
	}, $catalogue ),
	'voc'         => $voc,
	'promos'      => $promos,
	'ferme'       => $fkcFerme,
	/* Secondes avant le prochain changement d'état, selon l'horloge du SERVEUR. */
	'basculeDans' => (int) ( $ouverture['bascule_dans'] ?? 0 ),
	'apercu'      => ! empty( $apercu ),
	'urls'        => array(
		'catalogue' => $fkcApercu ? '' : url( 'terminal/catalogue' ),
		'commander' => url( 'terminal/commander' ),
		/* suiviUrl : la route de suivi a enfin un appelant depuis 1.736.0. */
		'suivi'     => rtrim( url( 'terminal/suivi' ), '/' ) . '/',
		'ping'      => $fkcApercu ? '' : url( 'terminal/ping' ),
		'lieux'     => $fkcApercu ? '' : url( 'terminal/lieux' ),
	),
);
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => $voc['titre'] ) ); ?>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app" id="fkt-app" data-ecran="client" data-panel="sheet">

	<?php FKC_View::partial( 'terminal::components.header', array( 'ui' => $ui ) ); ?>

	<main class="fkt-main" id="fkt-main">
		<section class="fkt-hero">
			<h1 class="fkt-hero__title"><?= e( $voc['titre'] ) ?></h1>
			<?php if ( '' !== (string) $voc['intro'] ) : ?><p class="fkt-hero__intro"><?= e( $voc['intro'] ) ?></p><?php endif; ?>
		</section>

		<?php if ( ! $catalogue ) : ?>
			<div class="fkt-empty">
				<div class="fkt-empty__ico"><svg class="fkt-ico fkt-ico--lg"><use href="#i-inbox"/></svg></div>
				<p class="fkt-empty__title">Le catalogue est vide pour le moment.</p>
				<p>Adressez-vous à l'accueil.</p>
			</div>
		<?php else : ?>
			<?php FKC_View::partial( 'terminal::components.promo-banner', array(
				'promos' => FKC_TerminalPromo::pour( $promos, 'carte' ), 'voc' => $voc, 'peutCommander' => $peutCommander,
			) ); ?>
			<?php FKC_View::partial( 'terminal::components.categories', array( 'categories' => $categories, 'voc' => $voc ) ); ?>
			<?php
			/*
			 * RECHERCHE (1.807.0) — seulement si le catalogue est long. Sur huit
			 * cartes, un champ de recherche est un obstacle ; sur quarante, c'est
			 * le seul chemin.
			 */
			if ( count( $catalogue ) > 8 ) : ?>
				<div class="fkt-search" role="search">
					<div class="fkt-input-wrap">
						<span class="fkt-input-wrap__prefix" aria-hidden="true"><svg class="fkt-ico"><use href="#i-search"/></svg></span>
						<input class="fkt-input" id="fkt-search" type="search" inputmode="search" enterkeyhint="search"
							autocomplete="off" autocorrect="off" spellcheck="false" name="q_<?= e( bin2hex( random_bytes( 3 ) ) ) ?>"
							placeholder="Rechercher une prestation" aria-label="Rechercher une prestation">
						<button type="button" class="fkt-search__clear" id="fkt-search-clear" aria-label="Effacer la recherche" hidden>
							<svg class="fkt-ico"><use href="#i-close"/></svg></button>
					</div>
				</div>
			<?php endif; ?>
			<div class="fkt-grid" id="fkt-grid">
				<?php foreach ( $catalogue as $i => $a ) : ?>
					<?php FKC_View::partial( 'terminal::components.card', array(
						'a' => $a, 'i' => $i, 'peutCommander' => $peutCommander, 'voc' => $voc,
					) ); ?>
				<?php endforeach; ?>
			</div>
			<div class="fkt-empty fkt-empty--sm" id="fkt-filtre-vide" hidden>
				<p class="fkt-empty__title">Rien dans cette catégorie pour le moment.</p>
			</div>
		<?php endif; ?>
		<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui ) ); ?>
	</main>

	<?php if ( $peutCommander && $catalogue ) : ?>
		<?php FKC_View::partial( 'terminal::components.action-bar', array( 'voc' => $voc ) ); ?>
		<?php FKC_View::partial( 'terminal::components.panier', array(
			'voc' => $voc, 'indicatif' => (string) ( $identite['indicatif'] ?? '' ),
			'lieu' => $fkcConfig['lieu'], 'telephone' => $fkcConfig['telephone'],
		) ); ?>
		<?php if ( $fkcAOptions ) { FKC_View::partial( 'terminal::components.options', array( 'voc' => $voc ) ); } ?>
		<?php FKC_View::partial( 'terminal::components.success', array( 'ui' => $ui, 'voc' => $voc, 'autoReset' => $autoReset ) ); ?>
	<?php endif; ?>

	<?php FKC_View::partial( 'terminal::components.attract', array(
		'ui' => $ui, 'voc' => $voc, 'message' => (string) $reglages['message_accueil'],
		'promos' => FKC_TerminalPromo::pour( $promos, 'attente' ),
	) ); ?>
	<?php FKC_View::partial( 'terminal::components.idle' ); ?>
	<?php if ( $fkcFerme ) { FKC_View::partial( 'terminal::components.ferme', array( 'ui' => $ui, 'ouverture' => $ouverture ) ); } ?>
	<?php if ( ! empty( $apercu ) ) : ?>
		<?php /* Aperçu depuis l'administration (1.820.0) : rien ne part, et on le dit. */ ?>
		<div class="fkt-apercu-bandeau" role="note">Aperçu depuis l'administration — les commandes ne sont pas envoyées.</div>
	<?php endif; ?>
	<?php /* Hors ligne (1.807.0) : le dire, et rassurer — rien n'est perdu. */ ?>
	<div class="fkt-offline-bar" role="status" aria-live="polite">
		<svg class="fkt-ico" aria-hidden="true"><use href="#i-refresh"/></svg>
		<span>Connexion interrompue — vos choix sont conservés, l'envoi reprendra dès son retour.</span>
	</div>
</div>

<script type="application/json" id="fkt-config"><?= json_encode( $fkcConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) ?></script>
<?php /* Générateur de QR déjà livré avec l'application (licence MIT) — aucun service externe. */ ?>
<script src="<?= e( fkc_asset( 'js/qrcode.js' ) ) ?>?v=<?= e( defined( 'FKC_VERSION' ) ? FKC_VERSION : '0' ) ?>"></script>
<?= FKC_TerminalTheme::script( 'terminal-core' ) ?>
<?= FKC_TerminalTheme::script( 'terminal-cart' ) ?>
<?= FKC_TerminalTheme::script( 'terminal-client' ) ?>
<?php if ( $promos ) : ?><?= FKC_TerminalTheme::script( 'terminal-promo' ) ?><?php endif; ?>
</body>
</html>
