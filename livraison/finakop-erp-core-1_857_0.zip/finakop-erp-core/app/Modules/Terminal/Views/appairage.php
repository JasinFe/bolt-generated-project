<?php
/**
 * ÉCRAN D'APPAIRAGE — la première chose que voit une tablette neuve.
 *
 * Page ENTIÈRE et autonome : ni barre latérale, ni menu, ni nom
 * d'utilisateur. Le gabarit de l'application n'a rien à faire ici, et pas
 * seulement pour l'allure — il afficherait des éléments de gestion sous les
 * yeux du premier passant.
 *
 * 1.806.0 — Design System commun, thème sombre, clavier en MAJUSCULES et
 * code découpé à la frappe (12-ABCD-EFGH-JKLM).
 *
 * @var string $erreur @var array $ui
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ?? 'sombre' ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => 'FinaKop · Associer cet appareil' ) ); ?>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app">
	<main class="fkt-pair">
		<div class="fkt-pair__box">
			<div class="fkt-attract__mark" style="width:96px;font-size:44px;animation:none" aria-hidden="true">
				<svg class="fkt-ico" style="width:48px;height:48px"><use href="#i-lock"/></svg>
			</div>
			<h1 class="fkt-pair__title">Associer cet appareil</h1>
			<p class="fkt-pair__sub">Saisissez le code affiché sur l'écran de gestion,<br>rubrique <em>Paramètres → Terminaux</em>.</p>
			<div class="fkt-input-wrap" id="wrap">
				<input class="fkt-input" id="code" inputmode="latin" autocapitalize="characters" autocomplete="off"
					autocorrect="off" spellcheck="false" enterkeyhint="go" maxlength="24" aria-describedby="msg"
					placeholder="12-ABCD-EFGH-JKLM" value="<?= e( (string) ( $_GET['c'] ?? '' ) ) ?>">
			</div>
			<button id="go" type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl fkt-btn--block">Associer</button>
			<div class="fkt-pair__msg" id="msg" role="alert"><?= e( $erreur ?? '' ) ?></div>
			<p class="fkt-pair__help">Cet appareil n'aura accès qu'au catalogue public et aux demandes qu'il aura lui-même ouvertes.
			Aucune donnée de gestion ne lui est transmise. L'association se retire à tout moment depuis l'écran de gestion.</p>
		</div>
	</main>
	<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui, 'classe' => 'fkt-footer--fixe' ) ); ?>
</div>
<script>
(function () {
	var c = document.getElementById('code'), b = document.getElementById('go'), m = document.getElementById('msg');
	var wrap = document.getElementById('wrap');
	/* Le code se découpe à la frappe : « 12ABCDEFGHJKLM » → « 12-ABCD-EFGH-JKLM ». */
	c.addEventListener('input', function () {
		var v = c.value.toUpperCase().replace(/[^0-9A-Z]/g, '');
		var mm = v.match(/^(\d+)([A-Z2-9].*)?$/);
		if (mm && mm[2]) {
			var reste = mm[2].slice(0, 12).match(/.{1,4}/g) || [];
			c.value = mm[1] + '-' + reste.join('-');
		} else { c.value = c.value.toUpperCase(); }
		wrap.classList.remove('is-invalid');
	});
	function envoyer() {
		var v = (c.value || '').trim();
		if (!v) { m.textContent = 'Saisissez le code.'; wrap.classList.add('is-invalid'); return; }
		b.disabled = true; b.classList.add('is-loading'); m.className = 'fkt-pair__msg is-info'; m.textContent = 'Association en cours…';
		var d = new FormData();
		d.append('code', v);
		d.append('appareil', navigator.platform || 'Terminal');
		fetch(<?= json_encode( url( 'terminal/appairer' ), JSON_UNESCAPED_SLASHES ) ?>, { method: 'POST', body: d, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (j) {
				if (j.ok) { m.textContent = j.message || 'Associé.'; location.href = <?= json_encode( url( 'terminal' ), JSON_UNESCAPED_SLASHES ) ?>; }
				else {
					m.className = 'fkt-pair__msg'; m.textContent = j.message || 'Association refusée.';
					b.disabled = false; b.classList.remove('is-loading');
					wrap.classList.add('is-invalid'); wrap.classList.remove('fkt-shake'); void wrap.offsetWidth; wrap.classList.add('fkt-shake');
				}
			})
			.catch(function () { m.className = 'fkt-pair__msg'; m.textContent = 'Connexion impossible.'; b.disabled = false; b.classList.remove('is-loading'); });
	}
	b.addEventListener('click', envoyer);
	c.addEventListener('keydown', function (e) { if (13 === e.keyCode) { envoyer(); } });
	if (c.value) { envoyer(); }   /* code passé en QR : rien à taper */
}());
</script>
</body>
</html>
