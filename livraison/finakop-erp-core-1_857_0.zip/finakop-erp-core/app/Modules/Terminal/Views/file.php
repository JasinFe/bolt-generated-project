<?php
/**
 * ÉCRAN D'ATELIER (cuisine, préparation) — la file de ce qui reste à faire.
 *
 * Il se rafraîchit seul : personne ne touche un écran de cuisine avec les
 * mains pleines. Aucun montant n'y figure — ce n'est pas l'information dont on
 * a besoin devant un plan de travail, et un écran d'atelier est souvent
 * visible depuis la salle.
 *
 * DEUX AJOUTS EN 1.736.0
 *
 *  · PLEIN ÉCRAN. Il n'existait que sur l'écran client. C'est pourtant ici
 *    qu'il compte le plus : un écran d'atelier reste allumé toute la journée,
 *    et la barre du navigateur mange une ligne de tickets pour rien.
 *
 *  · AVANCER. La capacité était déclarée pour ce type d'appareil depuis
 *    1.724.0 et annoncée dans sa fiche — sans route, sans méthode, sans
 *    bouton. L'atelier peut désormais dire « je m'en occupe » puis « c'est
 *    prêt », sur un axe SÉPARÉ de l'état commercial : accepter, acompter,
 *    payer et facturer restent le geste du professionnel sur son écran.
 *
 * 1.806.0 — Design System commun (thème sombre, marque, réseau, heure) ; les
 * tickets sont colorés par état : à faire, en cours, prêt.
 *
 * @var array $terminal @var array $ui @var array $file @var bool $peutAvancer
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ?? 'sombre' ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => 'Atelier · ' . $terminal['nom'] ) ); ?>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app" data-ecran="atelier">
	<?php FKC_View::partial( 'terminal::components.header', array( 'ui' => $ui, 'service' => $terminal['nom'] ) ); ?>
	<main class="fkt-main" style="padding-bottom:var(--t-s10)">
		<div id="zone"></div>
		<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui ) ); ?>
	</main>
</div>
<script type="application/json" id="fkt-config"><?= json_encode( array(
	'ecran' => 'atelier',
	'urls'  => array( 'ping' => url( 'terminal/ping' ), 'file' => url( 'terminal/file' ), 'avancer' => url( 'terminal/avancer' ) ),
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) ?></script>
<?= FKC_TerminalTheme::script( 'terminal-core' ) ?>
<script>
/*
 * ON INTERROGE LA FILE, ON NE RECHARGE PAS LA PAGE. Un écran de cuisine qui
 * clignote toutes les vingt secondes fatigue, et un rechargement tombe
 * fatalement au moment où quelqu'un lit une ligne. On redessine seulement
 * quand le contenu a changé.
 */
(function () {
	var zone = document.getElementById('zone');
	var peutAvancer = <?= $peutAvancer ? 'true' : 'false' ?>;
	var suivant = { attente: 'en_cours', en_cours: 'pret' };
	var libelleBouton = { attente: 'Je m\u2019en occupe', en_cours: 'C\u2019est prêt' };
	var urlAvancer = <?= json_encode( url( 'terminal/avancer' ), JSON_UNESCAPED_SLASHES ) ?>;

	var vu = null;
	function dessiner(file) {
		var sig = JSON.stringify(file);
		if (sig === vu) { return; }
		vu = sig;
		zone.innerHTML = '';
		if (!file.length) {
			var p = document.createElement('div');
			p.className = 'fkt-empty';
			p.innerHTML = '<div class="fkt-empty__ico"><svg class="fkt-ico fkt-ico--lg"><use href="#i-check"/></svg></div>';
			var t = document.createElement('p'); t.className = 'fkt-empty__title'; t.textContent = 'Rien en attente.';
			p.appendChild(t);
			zone.appendChild(p);
			return;
		}
		var g = document.createElement('div');
		g.className = 'fkt-board';
		file.forEach(function (t) {
			var etat = t.prod || 'attente';
			var d = document.createElement('div');
			d.className = 'fkt-tk ' + etat;
			var r = document.createElement('div'); r.className = 'fkt-tk__ref'; r.textContent = t.reference;
			var c = document.createElement('div'); c.className = 'fkt-tk__client'; c.style.fontSize = 'var(--t-fs-xl)'; c.textContent = t.client || '—';
			var u = document.createElement('ul'); u.className = 'fkt-tk__lines';
			(t.lignes || []).forEach(function (l) {
				var li = document.createElement('li'); li.textContent = l; u.appendChild(li);
			});
			var e = document.createElement('div'); e.className = 'fkt-tk__state'; e.textContent = t.prod_label || '';
			d.appendChild(r); d.appendChild(c); d.appendChild(u); d.appendChild(e);

			if (peutAvancer && suivant[etat]) {
				/* Cibles de 64 px et plus : on appuie avec un gant, un coude, un doigt fariné. */
				var b = document.createElement('button');
				b.type = 'button';
				b.className = 'fkt-btn fkt-btn--primary fkt-btn--xl fkt-btn--block';
				b.textContent = libelleBouton[etat];
				b.addEventListener('click', function () {
					b.disabled = true; b.classList.add('is-loading');
					FKT.api.post(urlAvancer, { reference: t.reference, vers: suivant[etat] })
						.then(function (x) {
							/* On force le redessin : l'état a changé, l'écran
							   doit le montrer sans attendre le prochain tour. */
							if (x.ok && x.data.ok) { vu = null; rafraichir(); }
							else { b.disabled = false; b.classList.remove('is-loading'); e.textContent = x.data.message || 'Refusé.'; }
						})
						.catch(function () { b.disabled = false; b.classList.remove('is-loading'); FKT.toast('Connexion interrompue : réessayez.', 'error'); });
				});
				d.appendChild(b);
			}
			g.appendChild(d);
		});
		zone.appendChild(g);
	}

	function rafraichir() {
		FKT.api.get(<?= json_encode( url( 'terminal/file' ), JSON_UNESCAPED_SLASHES ) ?>, 10000)
			.then(function (r) { if (r.ok && r.data.ok) { dessiner(r.data.file || []); } })
			.catch(function () { /* réseau coupé : l'écran garde le dernier état connu */ });
	}

	dessiner(<?= json_encode( array_values( (array) $file ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) ?>);
	setInterval(rafraichir, 20000);
}());
</script>
</body>
</html>
