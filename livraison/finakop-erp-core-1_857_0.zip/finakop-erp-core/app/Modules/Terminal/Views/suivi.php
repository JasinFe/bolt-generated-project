<?php
/**
 * PAGE PUBLIQUE DE SUIVI (1.807.0) — ce que le client voit en scannant le QR
 * de son ticket, sur SON téléphone.
 *
 * Elle ne montre que l'établissement, la référence et l'avancement : ni nom,
 * ni téléphone, ni montant, ni détail. Un lien se transfère, une photo de QR
 * circule ; la page doit rester inoffensive entre toutes les mains.
 *
 * Elle se tient à jour seule (toutes les 30 s, et au retour sur l'onglet) :
 * le client la laisse ouverte dans sa poche pendant qu'il attend.
 *
 * @var array|null $suivi @var string $code @var array $ui @var string $message
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcM = (array) ( $ui['marque'] ?? array() );
$fkcDate = '';
if ( $suivi && ! empty( $suivi['date'] ) && strtotime( (string) $suivi['date'] ) ) {
	$fkcDate = date( 'd/m/Y', strtotime( (string) $suivi['date'] ) );
}
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ?? 'clair' ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => 'Suivi de votre demande · ' . ( $fkcM['nom'] ?? 'FinaKop' ) ) ); ?>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app" data-ecran="suivi">
	<?php FKC_View::partial( 'terminal::components.header', array( 'ui' => $ui, 'service' => 'Suivi de demande', 'horloge' => false, 'pleinEcran' => false ) ); ?>
	<main class="fkt-main fkt-suivi" style="padding-bottom:var(--t-s10)">
		<?php if ( ! $suivi ) : ?>
			<div class="fkt-empty">
				<div class="fkt-empty__ico"><svg class="fkt-ico fkt-ico--lg"><use href="#i-search"/></svg></div>
				<p class="fkt-empty__title"><?= e( $message ?? 'Demande introuvable.' ) ?></p>
			</div>
		<?php else : ?>
			<section class="fkt-suivi__card">
				<p class="fkt-suivi__kicker">Votre demande</p>
				<h1 class="fkt-suivi__ref fkt-mono" id="ref"><?= e( $suivi['reference'] ) ?></h1>
				<p class="fkt-suivi__etat<?= 'annulee' === $suivi['etape'] ? ' is-annule' : '' ?>" id="etat">
					<span class="fkt-status__dot" aria-hidden="true"></span><span id="etatTxt"><?= e( $suivi['libelle'] ) ?></span>
				</p>
				<div id="frise"><?php FKC_View::partial( 'terminal::components.timeline', array( 'etapes' => $suivi['etapes'] ) ); ?></div>
				<div class="fkt-suivi__meta">
					<?php if ( $fkcDate ) : ?><span>Demande du <?= e( $fkcDate ) ?></span><?php endif; ?>
					<span>Mis à jour à <b id="maj" class="fkt-num"><?= e( date( 'H:i' ) ) ?></b></span>
				</div>
			</section>
			<p class="fkt-suivi__aide">Gardez cette page ouverte : elle se met à jour toute seule.<br>Pour toute question, présentez votre référence à l'accueil.</p>
		<?php endif; ?>
		<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui ) ); ?>
	</main>
</div>
<?php if ( $suivi ) : ?>
<script>
(function () {
	var url = <?= json_encode( url( 'suivre/' . $code ) . '?format=json', JSON_UNESCAPED_SLASHES ) ?>;
	var ico = { fait: '<svg class="fkt-ico"><use href="#i-check"/></svg>', annule: '<svg class="fkt-ico"><use href="#i-close"/></svg>' };
	function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
	function frise(etapes) {
		return '<ol class="fkt-timeline" aria-label="Avancement de la demande">' + etapes.map(function (e) {
			return '<li class="fkt-timeline__step is-' + esc(e.etat) + '"' + ('actuel' === e.etat ? ' aria-current="step"' : '') + '>'
				+ '<span class="fkt-timeline__dot" aria-hidden="true">' + (ico[e.etat] || '') + '</span>'
				+ '<span class="fkt-timeline__label">' + esc(e.libelle) + '</span></li>';
		}).join('') + '</ol>';
	}
	var vu = null;
	function maj() {
		fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
			.then(function (r) { return r.json(); })
			.then(function (j) {
				if (!j.ok || !j.suivi) { return; }
				var h = new Date();
				document.getElementById('maj').textContent = ('0' + h.getHours()).slice(-2) + ':' + ('0' + h.getMinutes()).slice(-2);
				var sig = JSON.stringify(j.suivi);
				if (sig === vu) { return; }
				vu = sig;
				document.getElementById('etatTxt').textContent = j.suivi.libelle || '';
				document.getElementById('etat').classList.toggle('is-annule', 'annulee' === j.suivi.etape);
				document.getElementById('frise').innerHTML = frise(j.suivi.etapes || []);
			})
			.catch(function () { /* hors réseau : on garde le dernier état connu */ });
	}
	setInterval(maj, 30000);
	document.addEventListener('visibilitychange', function () { if (!document.hidden) { maj(); } });
}());
</script>
<?php endif; ?>
</body>
</html>
