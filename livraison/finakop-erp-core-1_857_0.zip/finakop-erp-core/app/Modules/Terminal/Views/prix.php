<?php
/**
 * VÉRIFICATEUR DE PRIX (1.840.0) — borne en rayon, appairée par code.
 *
 * Le client scanne un article, la borne affiche son libellé et son prix, puis
 * revient à l'accueil. Le lecteur de codes-barres se comporte comme un
 * clavier : un champ toujours actif suffit, sans rien à régler. La borne ne
 * montre ni stock, ni coût, ni tarif réservé à un client.
 *
 * @var array $terminal @var array $ui
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ?? 'clair' ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => 'Prix · ' . $terminal['nom'] ) ); ?>
<style>
	.fkc-prix { min-height:100vh; display:flex; flex-direction:column; }
	.fkc-prix__zone { flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; gap:18px; padding:24px; }
	.fkc-prix__lib { font-size: clamp(24px, 1rem + 2vw, 52px); font-weight:700; }
	.fkc-prix__val { font-size: clamp(44px, 2rem + 5vw, 120px); font-weight:800; }
	.fkc-prix__aide { font-size: clamp(18px, .8rem + 1vw, 30px); opacity:.75; }
	#code { position:absolute; left:-9999px; }
</style>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app fkc-prix" data-ecran="verificateur_prix">
	<?php FKC_View::partial( 'terminal::components.header', array( 'ui' => $ui, 'service' => 'Vérificateur de prix' ) ); ?>
	<div class="fkc-prix__zone">
		<div id="lib" class="fkc-prix__lib"></div>
		<div id="val" class="fkc-prix__val"></div>
		<div id="aide" class="fkc-prix__aide">Scannez un article pour connaître son prix</div>
	</div>
	<input id="code" autocomplete="off" inputmode="none" aria-label="Code de l'article">
</div>
<script type="application/json" id="fkt-config"><?= json_encode( array(
	'ecran' => 'verificateur_prix',
	'urls'  => array( 'ping' => url( 'terminal/ping' ), 'prix' => url( 'terminal/prix' ) ),
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) ?></script>
<?= FKC_TerminalTheme::script( 'terminal-core' ) ?>
<script>
(function () {
	var $ = function (id) { return document.getElementById(id); };
	var champ = $('code'), minuterie = null;
	var fmt = function (n) { return Math.round(Number(n) || 0).toLocaleString('fr-FR').replace(/\u202f/g, ' ') + ' F'; };
	function accueil() { $('lib').textContent = ''; $('val').textContent = ''; $('aide').textContent = 'Scannez un article pour connaître son prix'; }
	function garderFocus() { if (document.activeElement !== champ) { champ.focus(); } }
	setInterval(garderFocus, 1000); garderFocus();
	champ.addEventListener('keydown', function (e) {
		if (e.key !== 'Enter') { return; }
		var c = champ.value.trim(); champ.value = '';
		if (!c) { return; }
		clearTimeout(minuterie);
		FKT.api.get(FKT.config.urls.prix + '?code=' + encodeURIComponent(c), 5000).then(function (r) {
			var d = r && r.data;
			if (d && d.ok) {
				$('lib').textContent = d.article.libelle;
				$('val').textContent = fmt(d.article.prix) + (d.article.unite && d.article.unite !== 'U' ? ' / ' + d.article.unite : '');
				$('aide').textContent = '';
			} else {
				$('lib').textContent = ''; $('val').textContent = '';
				$('aide').textContent = (d && d.message) || 'Article inconnu.';
			}
			minuterie = setTimeout(accueil, 8000);
		}).catch(function () { $('aide').textContent = 'Réseau indisponible.'; minuterie = setTimeout(accueil, 5000); });
	});
}());
</script>
</body>
</html>
