<?php
/**
 * ÉCRAN CLIENT DE CAISSE APPAIRÉ (1.840.0).
 *
 * L'écran client existait (Caisse → Écran client), mais il fallait ouvrir la
 * session du caissier sur l'appareil tourné vers le client : le compte, son
 * menu et ses droits à portée de main de la clientèle. Celui-ci s'appaire
 * par code, comme toute borne, et ne sait lire qu'une chose : l'addition en
 * cours du poste de caisse auquel il est rattaché — articles, total, monnaie
 * rendue. Aucun nom de client, aucune donnée de gestion.
 *
 * Interrogation courte toutes les deux secondes, sans flux permanent :
 * l'hébergement mutualisé ne garde pas de processus ouvert pour un écran.
 *
 * @var array $terminal @var array $ui
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$msgAccueil = (string) FKC_PosConfig::get( 'afficheur_message', 'Merci de votre visite' );
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ?? 'sombre' ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => 'Caisse · ' . $terminal['nom'] ) ); ?>
<style>
	.fkc-aff { display:flex; flex-direction:column; min-height:100vh; }
	.fkc-aff__lignes { flex:1; overflow:auto; padding: var(--t-s6, 24px); }
	.fkc-aff__ligne { display:flex; justify-content:space-between; gap:16px; font-size: clamp(18px, .8rem + 1vw, 28px); padding:10px 0; border-bottom:1px solid rgba(127,127,127,.2); }
	.fkc-aff__ligne span:first-child { overflow:hidden; text-overflow:ellipsis; }
	.fkc-aff__total { padding: var(--t-s6, 24px); display:flex; justify-content:space-between; align-items:baseline; font-size: clamp(30px, 1.2rem + 3vw, 72px); font-weight:800; border-top:2px solid rgba(127,127,127,.35); }
	.fkc-aff__accueil { flex:1; display:flex; align-items:center; justify-content:center; text-align:center; font-size: clamp(26px, 1rem + 2.5vw, 60px); padding: var(--t-s6, 24px); }
	.fkc-aff__rendu { font-size: clamp(22px, .9rem + 1.5vw, 40px); padding: 0 var(--t-s6, 24px) var(--t-s6, 24px); }
</style>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app fkc-aff" data-ecran="afficheur_caisse">
	<?php FKC_View::partial( 'terminal::components.header', array( 'ui' => $ui, 'service' => 'Votre addition' ) ); ?>
	<div id="accueil" class="fkc-aff__accueil"><?= e( $msgAccueil ) ?></div>
	<div id="lignes" class="fkc-aff__lignes" hidden></div>
	<div id="rendu" class="fkc-aff__rendu" hidden></div>
	<div id="total" class="fkc-aff__total" hidden><span>Total</span><span id="totalV"></span></div>
</div>
<script type="application/json" id="fkt-config"><?= json_encode( array(
	'ecran' => 'afficheur_caisse',
	'urls'  => array( 'ping' => url( 'terminal/ping' ), 'etat' => url( 'terminal/afficheur' ) ),
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) ?></script>
<?= FKC_TerminalTheme::script( 'terminal-core' ) ?>
<script>
(function () {
	var $ = function (id) { return document.getElementById(id); };
	var fmt = function (n) { return Math.round(Number(n) || 0).toLocaleString('fr-FR').replace(/\u202f/g, ' ') + ' F'; };
	var vu = null;
	function dessiner(d) {
		var sig = JSON.stringify([d.rev, d.statut]);
		if (sig === vu) { return; }
		vu = sig;
		var actif = d.statut === 'actif' || d.statut === 'paye';
		$('accueil').hidden = actif; $('lignes').hidden = !actif; $('total').hidden = !actif;
		$('rendu').hidden = !(d.statut === 'paye' && d.rendu > 0);
		var z = $('lignes'); z.innerHTML = '';
		(d.lignes || []).forEach(function (l) {
			var r = document.createElement('div'); r.className = 'fkc-aff__ligne';
			var a = document.createElement('span'); a.textContent = (l.quantite != 1 ? l.quantite + ' × ' : '') + l.libelle;
			var b = document.createElement('span'); b.textContent = fmt(l.total);
			r.appendChild(a); r.appendChild(b); z.appendChild(r);
		});
		$('totalV').textContent = fmt(d.total);
		$('rendu').textContent = d.statut === 'paye' ? ('Merci ! Monnaie rendue : ' + fmt(d.rendu)) : '';
	}
	function tirer() {
		FKT.api.get(FKT.config.urls.etat, 5000)
			.then(function (r) { if (r.ok && r.data.ok) { dessiner(r.data); } })
			.catch(function () { /* réseau coupé : on garde le dernier état */ });
	}
	tirer(); setInterval(tirer, 2000);
}());
</script>
</body>
</html>
