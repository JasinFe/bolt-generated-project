<?php
/**
 * ÉCRAN D'AFFICHAGE — le tableau de la salle d'attente (1.736.0).
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CE TYPE D'APPAREIL N'AVAIT AUCUN ÉCRAN
 *
 * `index()` n'avait que deux branches, atelier ou client. Un terminal déclaré
 * « affichage » tombait donc sur la page du client, où sa capacité ne lui
 * donne aucun catalogue : il affichait « Le catalogue est vide pour le
 * moment. Adressez-vous à l'accueil » indéfiniment, sur un mur, devant la
 * salle d'attente. Sa fiche promettait pourtant « montre l'avancement ».
 *
 * CE QU'IL MONTRE, ET CE QU'IL NE MONTRE PAS
 *
 * Référence, nom donné par le client, avancement. Rien d'autre. Un écran
 * mural est lu par toute la salle et souvent depuis la rue : aucun montant,
 * aucun détail de prestation, aucune note interne n'y a sa place. Le nom y
 * figure parce que c'est exactement ce que le client a saisi et pourquoi —
 * « Votre nom (pour qu'on vous appelle) ».
 *
 * IL SE LIT DE LOIN, DEBOUT, PARFOIS À SIX MÈTRES : gros caractères, fort
 * contraste, ce qui est PRÊT en tête et en couleur. Une salle d'attente
 * regarde cet écran pour une seule ligne — la sienne.
 *
 * 1.806.0 — même Design System que l'écran client (thème sombre par défaut,
 * marque de l'établissement, indicateur réseau), et les demandes PRÊTES
 * forment leur propre bandeau en tête : c'est la seule ligne qu'on vient lire.
 *
 * @var array $terminal @var array $ui @var array $voc @var array $tableau
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?><!DOCTYPE html>
<html lang="fr" data-theme="<?= e( $ui['theme'] ?? 'sombre' ) ?>">
<head>
<?php FKC_View::partial( 'terminal::components._head', array( 'ui' => $ui, 'titre' => 'Affichage · ' . $terminal['nom'] ) ); ?>
<style>
	/* L'écran d'affichage se lit de LOIN, debout, parfois à six mètres. */
	.fkt-display .fkt-tk__client { font-size: clamp(26px, 1.2rem + 2vw, 56px); }
	.fkt-display .fkt-tk__ref { font-size: clamp(18px, .9rem + 1vw, 30px); }
	.fkt-display .fkt-tk.pret .fkt-tk__state { font-size: clamp(20px, 1rem + 1vw, 32px); }
	.fkt-display .fkt-board-section--pret .fkt-board { grid-template-columns: repeat(auto-fill, minmax(min(100%, 380px), 1fr)); }
</style>
</head>
<body>
<?php FKC_View::partial( 'terminal::components.icons' ); ?>
<div class="fkt-app fkt-display" data-ecran="affichage">
	<?php FKC_View::partial( 'terminal::components.header', array( 'ui' => $ui, 'service' => 'Suivi des demandes' ) ); ?>
	<main class="fkt-main" style="padding-bottom:var(--t-s10)">
		<div id="zone"></div>
		<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui ) ); ?>
	</main>
</div>
<script type="application/json" id="fkt-config"><?= json_encode( array(
	'ecran' => 'affichage',
	'urls'  => array( 'ping' => url( 'terminal/ping' ), 'tableau' => url( 'terminal/tableau' ) ),
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) ?></script>
<?= FKC_TerminalTheme::script( 'terminal-core' ) ?>
<script>
(function () {
	var zone = document.getElementById('zone');

	/*
	 * ON REDESSINE SEULEMENT QUAND LE CONTENU A CHANGÉ. Un écran mural qui
	 * clignote toutes les vingt secondes fatigue la salle, et un rechargement
	 * tombe fatalement pendant que quelqu'un cherche sa ligne.
	 */
	var vu = null;
	function carte(r) {
		var d = document.createElement('div');
		d.className = 'fkt-tk' + (r.prod ? ' ' + r.prod : '');
		var ref = document.createElement('div'); ref.className = 'fkt-tk__ref'; ref.textContent = r.reference || '';
		var cli = document.createElement('div'); cli.className = 'fkt-tk__client';
		/* Une demande anonyme s'affiche par sa seule référence : on
		   n'invente pas un nom que le client n'a pas donné. */
		cli.textContent = (r.client || '').trim() || '—';
		var et = document.createElement('div'); et.className = 'fkt-tk__state'; et.textContent = r.libelle || '';
		d.appendChild(ref); d.appendChild(cli); d.appendChild(et);
		return d;
	}
	function section(titre, rows, cls) {
		var s = document.createElement('section');
		s.className = 'fkt-board-section ' + (cls || '');
		var h = document.createElement('h2'); h.className = 'fkt-board-section__title';
		h.textContent = titre + ' ';
		var n = document.createElement('span'); n.className = 'fkt-board-section__count'; n.textContent = rows.length;
		h.appendChild(n); s.appendChild(h);
		var g = document.createElement('div'); g.className = 'fkt-board';
		rows.forEach(function (r) { g.appendChild(carte(r)); });
		s.appendChild(g);
		return s;
	}
	function dessiner(rows) {
		var sig = JSON.stringify(rows);
		if (sig === vu) { return; }
		vu = sig;
		zone.innerHTML = '';
		if (!rows.length) {
			var p = document.createElement('div');
			p.className = 'fkt-empty';
			p.innerHTML = '<div class="fkt-empty__ico"><svg class="fkt-ico fkt-ico--lg"><use href="#i-inbox"/></svg></div>';
			var t = document.createElement('p'); t.className = 'fkt-empty__title'; t.textContent = 'Aucune demande en cours.';
			p.appendChild(t);
			zone.appendChild(p);
			return;
		}
		var prets = rows.filter(function (r) { return 'pret' === r.prod; });
		var autres = rows.filter(function (r) { return 'pret' !== r.prod; });
		/* Ce qui est PRÊT se voit d'un bout à l'autre de la salle. */
		if (prets.length) { zone.appendChild(section('Prêt', prets, 'fkt-board-section--pret')); }
		if (autres.length) { zone.appendChild(section('En préparation', autres)); }
	}

	dessiner(<?= json_encode( array_values( (array) $tableau ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) ?>);

	setInterval(function () {
		FKT.api.get(FKT.config.urls.tableau, 10000)
			.then(function (r) { if (r.ok && r.data.ok) { dessiner(r.data.tableau || []); } })
			.catch(function () { /* réseau coupé : l'écran garde le dernier état connu */ });
	}, 20000);
}());
</script>
</body>
</html>
