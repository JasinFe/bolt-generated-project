<?php
/**
 * CARTE DE PRESTATION (1.806.0) — icône, titre, description, prix, action.
 *
 * Rendue par le serveur (premier affichage immédiat, même si le script tarde)
 * puis animée par terminal-client.js, qui bascule la zone d'action entre
 * « + Ajouter » et le stepper « − quantité + ».
 *
 * LE PRIX AFFICHÉ N'ENGAGE RIEN : c'est une estimation. Le serveur relit le
 * sien dans le catalogue à l'envoi — l'attribut data-* ne sert qu'au total
 * estimé de l'écran.
 *
 * @var array $a article public @var int $i rang @var bool $peutCommander @var array $voc
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcStyle = '--i:' . min( 12, (int) $i );
if ( ! empty( $a['couleur'] ) ) { $fkcStyle .= ';--card-accent:' . FKC_TerminalTheme::couleur( $a['couleur'] ); }
$fkcDevis = ! empty( $a['devis'] );
$fkcPhoto = (string) ( $a['image'] ?? '' );
$fkcBadges = class_exists( 'FKC_ServiceCatalog' ) ? FKC_ServiceCatalog::badges() : array();
$fkcBadge = (string) ( $a['badge'] ?? '' );
/* Texte de recherche : libellé + description + rubrique, sans accents (1.807.0). */
$fkcCherche = strtolower( fkc_sans_accents( $a['libelle'] . ' ' . ( $a['description'] ?? '' ) . ' ' . ( $a['categorie'] ?? '' ) ) );
?>
<article class="fkt-card<?= '' !== $fkcPhoto ? ' has-photo' : '' ?>" data-id="<?= (int) $a['id'] ?>" data-cat="<?= e( (string) ( $a['categorie'] ?? '' ) ) ?>"
	data-search="<?= e( $fkcCherche ) ?>" style="<?= e( $fkcStyle ) ?>" aria-label="<?= e( $a['libelle'] ) ?>">
	<?php if ( isset( $fkcBadges[ $fkcBadge ] ) ) : ?>
		<span class="fkt-badge-tag fkt-badge-tag--<?= e( $fkcBadge ) ?>"><?= e( $fkcBadges[ $fkcBadge ] ) ?></span>
	<?php endif; ?>
	<div class="fkt-card__media" aria-hidden="true">
		<?php if ( '' !== $fkcPhoto ) : ?>
			<?php /* En cas d'échec de chargement, on retombe sur le pictogramme plutôt que sur un cadre vide. */ ?>
			<img src="<?= e( $fkcPhoto ) ?>" alt="" loading="lazy" decoding="async"
				onerror="var m=this.parentNode;m.closest('.fkt-card').classList.remove('has-photo');m.textContent=<?= e( json_encode( (string) ( $a['icone'] ?? '' ) ?: '✦' ) ) ?>">
		<?php else : ?>
			<?= e( (string) ( $a['icone'] ?? '' ) ?: '✦' ) ?>
		<?php endif; ?>
	</div>
	<div class="fkt-card__body">
		<?php if ( ! empty( $a['categorie'] ) ) : ?><span class="fkt-card__cat"><?= e( $a['categorie'] ) ?></span><?php endif; ?>
		<h3 class="fkt-card__title"><?= e( $a['libelle'] ) ?></h3>
		<?php if ( ! empty( $a['description'] ) ) : ?>
			<p class="fkt-card__desc"><?= e( $a['description'] ) ?></p>
		<?php endif; ?>
		<?php if ( ! empty( $a['duree'] ) || ! empty( $a['options'] ) ) : ?>
			<div class="fkt-card__meta">
				<?php if ( ! empty( $a['duree'] ) ) : ?><span class="fkt-tag"><svg class="fkt-ico" aria-hidden="true"><use href="#i-clock"/></svg><?= e( $a['duree'] ) ?></span><?php endif; ?>
				<?php if ( ! empty( $a['options'] ) ) : ?><span class="fkt-tag fkt-tag--opt"><?= e( implode( ' · ', array_column( (array) $a['options'], 'groupe' ) ) ) ?></span><?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
	<div class="fkt-card__foot">
		<div class="fkt-price<?= $fkcDevis ? ' is-devis' : '' ?>">
			<span class="fkt-price__value"><?= e( $a['prix_affiche'] ) ?></span>
			<?php if ( $fkcDevis ) : ?><span class="fkt-price__note">chiffré à l'accueil</span><?php endif; ?>
		</div>
		<?php if ( $peutCommander ) : ?>
			<?php
			/* 1.812.0 — un article à options s'ouvre sur ses choix : « Choisir », pas « Ajouter ». */
			$fkcLib = ! empty( $a['options'] ) ? ( $voc['choisir'] ?? 'Choisir' ) : ( $voc['ajouter'] ?? 'Ajouter' );
			?>
			<div class="fkt-card__action" data-slot="action">
				<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--add" data-act="add"
					<?= ! empty( $a['options'] ) ? 'aria-haspopup="dialog"' : '' ?>
					aria-label="<?= e( $fkcLib . ' : ' . $a['libelle'] ) ?>">
					<svg class="fkt-ico" aria-hidden="true"><use href="#<?= ! empty( $a['options'] ) ? 'i-arrow-right' : 'i-plus' ?>"/></svg><?= e( $fkcLib ) ?>
				</button>
			</div>
		<?php endif; ?>
	</div>
</article>
