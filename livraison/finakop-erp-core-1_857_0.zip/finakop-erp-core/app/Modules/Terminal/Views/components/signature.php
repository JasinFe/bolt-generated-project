<?php
/**
 * SIGNATURE FINAKOP — PIED DE PAGE (1.811.0).
 *
 * Demande de l'utilisateur : le nom et le logo de FinaKop n'apparaissent QUE
 * dans le pied de page ; l'en-tête appartient à la société. Ce composant est
 * le seul endroit où la marque du produit est dessinée sur un écran de
 * Terminal.
 *
 * @var array $ui @var string $classe (facultatif)
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcLogo = (string) ( $ui['marque']['logo_finakop'] ?? ( function_exists( 'fkc_asset' ) ? fkc_asset( 'img/logo-256.png' ) : '' ) );
?>
<footer class="fkt-footer<?= ! empty( $classe ) ? ' ' . e( $classe ) : '' ?>">
	<span class="fkt-signature">
		<?php if ( '' !== $fkcLogo ) : ?><img src="<?= e( $fkcLogo ) ?>" alt="" onerror="this.remove()"><?php endif; ?>
		<span>Propulsé par <b>FinaKop</b></span>
	</span>
</footer>
