<?php
/**
 * SUCCESS SCREEN PLEIN ÉCRAN + TICKET DE RÉFÉRENCE (1.806.0).
 *
 * LA CONFIRMATION DIT CE QUE LE SERVEUR SAIT, PAS CE QUE LA PAGE ESPÈRE
 * (1.736.0) : la ligne d'état du ticket est relue par `terminal/suivi/{ref}`
 * — c'est la preuve que la demande existe du côté de l'établissement.
 *
 * Le pied change avec le mode : en libre-service, l'écran se remet seul à
 * zéro (compte à rebours visible, bouton pour ne pas attendre) ; en assisté,
 * il attend l'opérateur, qui note ou montre la référence.
 *
 * @var array $ui @var array $voc @var bool $autoReset
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="fkt-overlay" id="fkt-success" role="alertdialog" aria-modal="true" aria-labelledby="fkt-success-title" aria-hidden="true">
	<div class="fkt-success" id="fkt-success-box">
		<div class="fkt-check" aria-hidden="true">
			<svg viewBox="0 0 100 100"><circle class="fkt-check__circle" cx="50" cy="50" r="46"/><path class="fkt-check__tick" d="M30 52l13 13 27-29"/></svg>
		</div>
		<h2 class="fkt-success__title" id="fkt-success-title">Demande transmise</h2>
		<p class="fkt-success__msg" id="fkt-success-msg"><?= e( $voc['confirmation'] ?? '' ) ?></p>
		<div class="fkt-ticket" id="fkt-ticket">
			<div class="fkt-ticket__brand">
				<span><?= e( (string) ( $ui['marque']['nom'] ?? '' ) ) ?></span>
				<span id="fkt-ticket-heure" class="fkt-num"></span>
			</div>
			<div class="fkt-ticket__label">Votre référence</div>
			<div class="fkt-ticket__ref" id="fkt-ref"></div>
			<div class="fkt-ticket__cut" aria-hidden="true"></div>
			<div class="fkt-ticket__meta">
				<span id="fkt-ticket-nb"></span>
				<span class="fkt-status is-pending" id="fkt-statut"><span class="fkt-status__dot" aria-hidden="true"></span><span class="fkt-status__txt">Vérification…</span></span>
			</div>
			<?php /* Frise et QR de suivi (1.807.0), remplis par terminal-client.js. */ ?>
			<div id="fkt-ticket-frise"></div>
			<div class="fkt-ticket__suivi" id="fkt-ticket-suivi" hidden>
				<div class="fkt-qr" id="fkt-qr" aria-hidden="true"></div>
				<p class="fkt-ticket__suivi-txt"><b>Suivez votre demande</b>Scannez ce code avec l'appareil photo de votre téléphone : l'avancement s'affiche en direct, sans compte ni application.</p>
			</div>
		</div>
		<div class="fkt-success__actions">
			<?php if ( ! empty( $autoReset ) ) : ?>
				<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl fkt-btn--block" data-act="nouvelle">
					<?= e( $voc['nouvelle'] ?? 'Nouvelle demande' ) ?>
				</button>
				<div class="fkt-countdown" id="fkt-countdown">
					<svg class="fkt-ring" viewBox="0 0 26 26" aria-hidden="true"><circle class="fkt-ring__bg" cx="13" cy="13" r="11"/><circle class="fkt-ring__fg" cx="13" cy="13" r="11"/></svg>
					<span>Cet écran se remet à zéro dans <b id="fkt-countdown-n">10</b> s</span>
				</div>
			<?php else : ?>
				<?php /* Mode assisté : c'est l'opérateur qui referme. */ ?>
				<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl fkt-btn--block" id="dialFermer" data-act="nouvelle">Terminer</button>
			<?php endif; ?>
		</div>
	</div>
</div>
