<?php
/**
 * À LA UNE — carrousel des contenus promotionnels en haut de la carte
 * (Phase 3, 1.814.0).
 *
 * Contenu de l'établissement (titre, texte, photo), présentation du Core :
 * aucune mise en forme libre. Un contenu lié à un article porte un bouton
 * qui mène à cet article (ajout direct, ou fenêtre d'options).
 * Défilement : glisser du doigt (scroll-snap), points, et avance seule —
 * sauf si l'appareil demande moins d'animations.
 *
 * @var array $promos contenus de l'emplacement « carte » @var array $voc @var bool $peutCommander
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$promos = array_values( (array) $promos );
if ( ! $promos ) { return; }
$fkcN = count( $promos );
?>
<section class="fkt-promo" id="fkt-promo" aria-roledescription="carrousel" aria-label="À la une" data-carrousel-root>
	<div class="fkt-promo__track" data-carrousel>
		<?php foreach ( $promos as $i => $p ) : ?>
			<article class="fkt-promo__slide<?= '' !== (string) $p['image'] ? ' has-photo' : '' ?>" aria-roledescription="diapositive"
				aria-label="<?= (int) $i + 1 ?> sur <?= (int) $fkcN ?> : <?= e( $p['titre'] ) ?>">
				<?php if ( '' !== (string) $p['image'] ) : ?>
					<img class="fkt-promo__img" src="<?= e( $p['image'] ) ?>" alt="" <?= $i > 0 ? 'loading="lazy"' : '' ?> decoding="async"
						onerror="this.closest('.fkt-promo__slide').classList.remove('has-photo');this.remove()">
				<?php endif; ?>
				<div class="fkt-promo__body">
					<span class="fkt-promo__kicker"><?= e( $voc['une'] ?? 'À la une' ) ?></span>
					<h2 class="fkt-promo__title"><?= e( $p['titre'] ) ?></h2>
					<?php if ( '' !== (string) $p['texte'] ) : ?><p class="fkt-promo__text"><?= e( $p['texte'] ) ?></p><?php endif; ?>
					<?php if ( ! empty( $p['article'] ) ) : ?>
						<button type="button" class="fkt-btn fkt-btn--primary fkt-promo__cta" data-act="promo" data-article="<?= (int) $p['article'] ?>">
							<?= e( $peutCommander ? ( $voc['promo_cta'] ?? 'Commander' ) : ( $voc['promo_voir'] ?? 'Voir' ) ) ?><svg class="fkt-ico" aria-hidden="true"><use href="#i-arrow-right"/></svg>
						</button>
					<?php endif; ?>
				</div>
			</article>
		<?php endforeach; ?>
	</div>
	<?php if ( $fkcN > 1 ) : ?>
		<div class="fkt-promo__dots" data-carrousel-dots>
			<?php foreach ( $promos as $i => $p ) : ?>
				<button type="button" class="fkt-promo__dot" data-i="<?= (int) $i ?>" aria-label="<?= e( 'Contenu ' . ( $i + 1 ) . ' : ' . $p['titre'] ) ?>"<?= 0 === $i ? ' aria-current="true"' : '' ?>></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>
