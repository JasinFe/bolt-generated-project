<?php
/**
 * DIALOGUE D'INACTIVITÉ (1.806.0) — « Vous êtes toujours là ? »
 *
 * Deux temps, comme un distributeur de billets : on prévient, puis on remet à
 * zéro. Il ne s'affiche que s'il y a quelque chose à perdre (sélection ou
 * saisie en cours) ; un écran vierge repart directement à l'écran d'attente.
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="fkt-dialog" id="fkt-idle" role="alertdialog" aria-modal="true" aria-labelledby="fkt-idle-title" aria-hidden="true">
	<div class="fkt-dialog__box">
		<div class="fkt-dialog__count fkt-num" id="fkt-idle-n">15</div>
		<h2 class="fkt-dialog__title" id="fkt-idle-title">Vous êtes toujours là ?</h2>
		<p class="fkt-dialog__txt">Sans action de votre part, votre sélection sera effacée pour le client suivant.</p>
		<div class="fkt-dialog__actions">
			<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl fkt-btn--block" data-act="rester">Je continue</button>
			<button type="button" class="fkt-btn fkt-btn--quiet fkt-btn--block" data-act="reset">Tout effacer maintenant</button>
		</div>
	</div>
</div>
