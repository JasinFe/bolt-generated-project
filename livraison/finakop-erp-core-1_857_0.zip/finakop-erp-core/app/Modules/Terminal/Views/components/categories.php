<?php
/**
 * CHIPS DE CATÉGORIES (1.806.0) — une rangée horizontale qui défile au doigt.
 *
 * Masquée s'il n'y a qu'une rubrique : un filtre qui ne filtre rien est du
 * bruit. Le premier chip (« Tout ») est actif par défaut et revient à chaque
 * remise à zéro de l'écran.
 *
 * @var array $categories [ libellé => nombre ] @var array $voc
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
if ( count( $categories ) < 2 ) { return; }
$fkcTotal = array_sum( $categories );
?>
<nav class="fkt-chips" id="fkt-chips" aria-label="Catégories">
	<button type="button" class="fkt-chip" data-cat="" aria-pressed="true">
		<?= e( $voc['tout'] ?? 'Tout' ) ?> <span class="fkt-chip__count"><?= (int) $fkcTotal ?></span>
	</button>
	<?php foreach ( $categories as $fkcCat => $fkcN ) : ?>
		<button type="button" class="fkt-chip" data-cat="<?= e( $fkcCat ) ?>" aria-pressed="false">
			<?= e( $fkcCat ) ?> <span class="fkt-chip__count"><?= (int) $fkcN ?></span>
		</button>
	<?php endforeach; ?>
</nav>
