<?php
/**
 * FRISE DE SUIVI (1.807.0) — Reçue → Prise en charge → En cours → Terminée.
 *
 * Rendue par le serveur sur la page publique de suivi ; terminal-client.js
 * dessine la même, avec les mêmes classes, sur le ticket de la borne.
 *
 * @var array $etapes FKC_TerminalSuivi::timeline()
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<ol class="fkt-timeline" aria-label="Avancement de la demande">
	<?php foreach ( (array) $etapes as $fkcE ) : ?>
		<li class="fkt-timeline__step is-<?= e( $fkcE['etat'] ) ?>"<?= 'actuel' === $fkcE['etat'] ? ' aria-current="step"' : '' ?>>
			<span class="fkt-timeline__dot" aria-hidden="true">
				<?php if ( 'fait' === $fkcE['etat'] ) : ?><svg class="fkt-ico"><use href="#i-check"/></svg>
				<?php elseif ( 'annule' === $fkcE['etat'] ) : ?><svg class="fkt-ico"><use href="#i-close"/></svg><?php endif; ?>
			</span>
			<span class="fkt-timeline__label"><?= e( $fkcE['libelle'] ) ?></span>
		</li>
	<?php endforeach; ?>
</ol>
