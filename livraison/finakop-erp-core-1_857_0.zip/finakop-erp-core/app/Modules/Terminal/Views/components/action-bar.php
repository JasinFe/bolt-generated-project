<?php
/**
 * BOTTOM ACTION BAR (1.806.0) — remplace le pied de page fixe.
 *
 * Elle n'apparaît qu'avec un premier article (un bandeau « rien pour
 * l'instant » mangeait une rangée de cartes pour rien), résume la demande et
 * ouvre le panneau. En mode ancré (desktop, borne paysage), le panier est déjà
 * visible : la barre s'efface.
 *
 * @var array $voc
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="fkt-actionbar" id="fkt-bar" aria-hidden="true">
	<div class="fkt-actionbar__count" aria-hidden="true">
		<svg class="fkt-ico fkt-ico--lg"><use href="#i-bag"/></svg>
		<span class="fkt-badge" id="fkt-bar-nb">0</span>
	</div>
	<div class="fkt-actionbar__sum">
		<span class="fkt-actionbar__label"><?= e( $voc['estime'] ?? 'Total estimé' ) ?></span>
		<span class="fkt-actionbar__total" id="fkt-bar-total">0 F</span>
	</div>
	<button type="button" class="fkt-btn fkt-btn--primary fkt-actionbar__cta" data-act="open">
		<span class="fkt-actionbar__cta-long"><?= e( $voc['voir'] ?? 'Voir ma demande' ) ?></span>
		<span class="fkt-actionbar__cta-short"><?= e( $voc['panier'] ?? 'Ma demande' ) ?></span>
		<svg class="fkt-ico" aria-hidden="true"><use href="#i-arrow-right"/></svg>
	</button>
</div>
