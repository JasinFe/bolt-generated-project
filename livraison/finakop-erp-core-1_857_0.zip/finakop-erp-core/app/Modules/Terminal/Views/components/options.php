<?php
/**
 * FENÊTRE D'OPTIONS (1.812.0) — cuisson, sauce, suppléments d'un article.
 *
 * Une coquille : terminal-client.js la remplit à l'ouverture avec les
 * groupes de l'article choisi (catalogue déjà chargé, aucun appel réseau).
 * Un groupe « unique » se choisit comme un bouton radio et doit être
 * renseigné ; les autres se cochent librement. Le prix affiché sur le bouton
 * inclut les suppléments et la quantité — il reste une estimation.
 *
 * @var array $voc
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="fkt-dialog fkt-dialog--options" id="fkt-opt" role="dialog" aria-modal="true" aria-labelledby="fkt-opt-title" aria-hidden="true">
	<div class="fkt-dialog__box">
		<div class="fkt-opt-head">
			<h2 class="fkt-dialog__title" id="fkt-opt-title"></h2>
			<button type="button" class="fkt-btn fkt-btn--icon fkt-btn--quiet" data-act="opt-close" aria-label="Fermer">
				<svg class="fkt-ico"><use href="#i-close"/></svg>
			</button>
		</div>
		<div class="fkt-opt-body" id="fkt-opt-body"></div>
		<div class="fkt-opt-foot">
			<div class="fkt-stepper" role="group" aria-label="Quantité">
				<button type="button" class="fkt-stepper__btn" data-act="opt-dec" aria-label="Un de moins"><svg class="fkt-ico"><use href="#i-minus"/></svg></button>
				<span class="fkt-stepper__val" id="fkt-opt-qte" aria-live="polite">1</span>
				<button type="button" class="fkt-stepper__btn fkt-stepper__btn--plus" data-act="opt-inc" aria-label="Un de plus"><svg class="fkt-ico"><use href="#i-plus"/></svg></button>
			</div>
			<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl" id="fkt-opt-add" data-act="opt-add">
				<svg class="fkt-ico" aria-hidden="true"><use href="#i-plus"/></svg><span><?= e( $voc['ajouter'] ?? 'Ajouter' ) ?></span>
			</button>
		</div>
		<p class="fkt-opt-manque" id="fkt-opt-manque" aria-live="polite"></p>
	</div>
</div>
