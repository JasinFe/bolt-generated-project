<?php
/**
 * BORNE FERMÉE (Phase 3, lot 3 — 1.820.0).
 *
 * Hors des horaires déclarés par l'établissement : la marque, « Fermé », et
 * quand on rouvre. Rien à toucher — et le serveur refuse de toute façon les
 * commandes. La page se recharge seule à l'heure d'ouverture (empreinte de
 * configuration du battement, et minuterie calée sur l'heure du SERVEUR).
 *
 * @var array $ui @var array $ouverture
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcM = (array) ( $ui['marque'] ?? array() );
?>
<div class="fkt-overlay fkt-ferme is-visible" id="fkt-ferme" role="status" aria-live="polite">
	<div class="fkt-attract__orb fkt-attract__orb--a" aria-hidden="true"></div>
	<div class="fkt-ferme__inner">
		<div class="fkt-attract__mark<?= ! empty( $ui['logo_url'] ) ? ' has-logo' : '' ?>" aria-hidden="true">
			<?php if ( ! empty( $ui['logo_url'] ) ) : ?><img src="<?= e( $ui['logo_url'] ) ?>" alt=""><?php else : ?><?= e( (string) ( $fkcM['initiales'] ?? '' ) ?: '✦' ) ?><?php endif; ?>
		</div>
		<h1 class="fkt-attract__name"><?= e( (string) ( $fkcM['nom'] ?? '' ) ) ?></h1>
		<p class="fkt-ferme__etat"><svg class="fkt-ico" aria-hidden="true"><use href="#i-clock"/></svg>Fermé</p>
		<?php if ( '' !== (string) ( $ouverture['libelle'] ?? '' ) && 'Fermé' !== (string) $ouverture['libelle'] ) : ?>
			<p class="fkt-ferme__quand"><?= e( $ouverture['libelle'] ) ?></p>
		<?php endif; ?>
	</div>
	<div class="fkt-attract__clock" aria-hidden="true">
		<span data-fkt-clock></span>
		<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui ) ); ?>
	</div>
</div>
