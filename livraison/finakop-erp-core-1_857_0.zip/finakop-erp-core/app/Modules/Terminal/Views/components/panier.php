<?php
/**
 * PANNEAU DE DEMANDE (1.806.0) — bottom sheet sur téléphone, drawer latéral
 * sur tablette, panneau ANCRÉ sur desktop et borne en paysage. Un seul
 * composant : responsive.css choisit la forme, terminal-client.js le parcours.
 *
 * DEUX ÉTAPES, ET PLUS UN FORMULAIRE COLLÉ AU PIED DE PAGE :
 *   1. Sélection  — relire, ajuster les quantités, retirer ;
 *   2. Coordonnées — nom et téléphone, facultatifs, avec clavier adapté.
 *
 * CONFIDENTIALITÉ DES CHAMPS. Les noms d'attribut sont TIRÉS AU SORT à chaque
 * affichage et le formulaire n'est jamais soumis nativement (envoi par
 * fetch) : le navigateur de la borne n'a donc ni clé stable ni soumission
 * pour mémoriser — et proposer au client suivant — le nom et le numéro du
 * précédent. `autocomplete="off"` seul ne suffit pas : Chrome l'ignore.
 *
 * 1.808.0 — étape « lieu » facultative (le Restaurant : « Votre table »),
 * déclarée par le pack via identite()['lieu'] ; téléphone masquable
 * (identite()['telephone'] = false).
 *
 * @var array $voc @var string $indicatif @var array|null $lieu @var bool $telephone
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcSel = bin2hex( random_bytes( 4 ) );
$lieu = ( isset( $lieu ) && is_array( $lieu ) ) ? $lieu : null;
$telephone = ! isset( $telephone ) || $telephone;
$fkcN = 1;
?>
<div class="fkt-scrim" id="fkt-scrim" data-act="close"></div>
<aside class="fkt-panel" id="fkt-panel" role="dialog" aria-modal="true" aria-labelledby="fkt-panel-title" aria-hidden="true">
	<div class="fkt-panel__grip" data-grip aria-hidden="true"></div>
	<div class="fkt-panel__head" data-grip>
		<h2 class="fkt-panel__title" id="fkt-panel-title"><?= e( $voc['panier'] ?? 'Ma demande' ) ?></h2>
		<button type="button" class="fkt-btn fkt-btn--icon fkt-btn--quiet fkt-panel__close" data-act="close" aria-label="Fermer">
			<svg class="fkt-ico"><use href="#i-close"/></svg>
		</button>
	</div>
	<ol class="fkt-steps" aria-label="Étapes">
		<li class="fkt-steps__item is-active" data-step="panier"><span class="fkt-steps__num"><?= $fkcN++ ?></span>Sélection</li>
		<?php if ( $lieu ) : ?>
			<li class="fkt-steps__sep" aria-hidden="true"></li>
			<li class="fkt-steps__item" data-step="lieu"><span class="fkt-steps__num"><?= $fkcN++ ?></span><?= e( $lieu['etape'] ?? $lieu['titre'] ?? 'Lieu' ) ?></li>
		<?php endif; ?>
		<li class="fkt-steps__sep" aria-hidden="true"></li>
		<li class="fkt-steps__item" data-step="coord"><span class="fkt-steps__num"><?= $fkcN++ ?></span><?= e( $voc['etape_coord'] ?? 'Vos coordonnées' ) ?></li>
	</ol>

	<div class="fkt-panel__body" id="fkt-panel-body">
		<section class="fkt-view is-active" data-view="panier" aria-label="Sélection">
			<ul class="fkt-lines" id="fkt-lines"></ul>
			<div class="fkt-empty fkt-empty--sm" id="fkt-panier-vide">
				<div class="fkt-empty__ico"><svg class="fkt-ico fkt-ico--lg"><use href="#i-touch"/></svg></div>
				<p class="fkt-empty__title">Votre demande est vide</p>
				<p>Touchez une prestation pour l'ajouter.</p>
			</div>
		</section>

		<?php if ( $lieu ) : ?>
		<section class="fkt-view" data-view="lieu" aria-label="<?= e( $lieu['titre'] ?? 'Lieu' ) ?>">
			<?php
			/* 1.813.0 — sur place (une table) ou à emporter (un numéro d'appel), si le métier le propose. */
			$fkcEmp = ( ! empty( $lieu['emporter'] ) && is_array( $lieu['emporter'] ) ) ? $lieu['emporter'] : null;
			if ( $fkcEmp ) : ?>
				<div class="fkt-modes" role="radiogroup" aria-label="<?= e( $lieu['titre'] ?? '' ) ?>">
					<button type="button" class="fkt-mode" role="radio" aria-checked="true" data-act="mode-choisir" data-mode="sur_place">
						<svg class="fkt-ico fkt-ico--lg" aria-hidden="true"><use href="#i-dine"/></svg><span><?= e( $fkcEmp['sur_place'] ?? 'Sur place' ) ?></span></button>
					<button type="button" class="fkt-mode" role="radio" aria-checked="false" data-act="mode-choisir" data-mode="emporter">
						<svg class="fkt-ico fkt-ico--lg" aria-hidden="true"><use href="#i-bag"/></svg><span><?= e( $fkcEmp['libelle'] ?? 'À emporter' ) ?></span></button>
				</div>
				<div class="fkt-emporter-info" id="fkt-emporter-info" hidden>
					<svg class="fkt-ico fkt-ico--lg" aria-hidden="true"><use href="#i-bag"/></svg>
					<p><?= e( $fkcEmp['aide'] ?? '' ) ?></p>
				</div>
			<?php endif; ?>
			<p class="fkt-form__intro" id="fkt-lieu-aide"><?= e( $lieu['aide'] ?? '' ) ?></p>
			<div class="fkt-lieux" id="fkt-lieux" role="radiogroup" aria-label="<?= e( $lieu['titre'] ?? 'Lieu' ) ?>" aria-busy="true"></div>
			<div class="fkt-empty fkt-empty--sm" id="fkt-lieux-vide" hidden>
				<div class="fkt-empty__ico"><svg class="fkt-ico fkt-ico--lg"><use href="#i-inbox"/></svg></div>
				<p class="fkt-empty__title"><?= e( $lieu['vide'] ?? 'Aucun lieu disponible.' ) ?></p>
				<button type="button" class="fkt-btn fkt-btn--ghost" data-act="lieux"><svg class="fkt-ico" aria-hidden="true"><use href="#i-refresh"/></svg>Actualiser</button>
			</div>
		</section>
		<?php endif; ?>

		<section class="fkt-view" data-view="coord" aria-label="<?= e( $voc['etape_coord'] ?? 'Vos coordonnées' ) ?>">
			<form class="fkt-form" id="fkt-form" novalidate autocomplete="off" onsubmit="return false">
				<?php if ( $lieu ) : ?>
					<div class="fkt-lieu-choisi" id="fkt-lieu-choisi" hidden>
						<span class="fkt-lieu-choisi__txt"><svg class="fkt-ico" aria-hidden="true"><use href="#i-check"/></svg><span id="fkt-lieu-choisi-lib"></span></span>
						<button type="button" class="fkt-btn fkt-btn--quiet" data-act="lieu-changer">Changer</button>
					</div>
				<?php endif; ?>
				<p class="fkt-form__intro" id="fkt-coord-aide" data-defaut="<?= e( $voc['aide_coord'] ?? '' ) ?>"><?= e( $voc['aide_coord'] ?? '' ) ?></p>
				<div class="fkt-field">
					<label class="fkt-field__label" for="fkt-nom"><?= e( $voc['identite'] ?? 'Votre nom' ) ?></label>
					<div class="fkt-input-wrap">
						<span class="fkt-input-wrap__prefix" aria-hidden="true"><svg class="fkt-ico"><use href="#i-user"/></svg></span>
						<input class="fkt-input" id="fkt-nom" name="n_<?= e( $fkcSel ) ?>" type="text" maxlength="80"
							autocomplete="off" autocorrect="off" autocapitalize="words" spellcheck="false" enterkeyhint="next"
							aria-describedby="fkt-nom-err" placeholder="Ex. Aya Koffi">
					</div>
					<div class="fkt-field__error" id="fkt-nom-err" role="alert"></div>
				</div>
				<?php if ( $telephone ) : ?>
				<div class="fkt-field">
					<label class="fkt-field__label" for="fkt-tel"><?= e( $voc['contact'] ?? 'Votre téléphone' ) ?></label>
					<div class="fkt-input-wrap">
						<span class="fkt-input-wrap__prefix" id="fkt-tel-prefix"><?php if ( '' !== (string) $indicatif ) : ?><?= e( $indicatif ) ?><?php else : ?><svg class="fkt-ico" aria-hidden="true"><use href="#i-phone"/></svg><?php endif; ?></span>
						<?php /* `type=tel` + `inputmode=tel` : le clavier NUMÉRIQUE sort, avec + pour l'international. */ ?>
						<input class="fkt-input fkt-num" id="fkt-tel" name="t_<?= e( $fkcSel ) ?>" type="tel" inputmode="tel" maxlength="22"
							autocomplete="off" enterkeyhint="send" aria-describedby="fkt-tel-hint fkt-tel-err" placeholder="07 00 00 00 00">
					</div>
					<div class="fkt-field__hint" id="fkt-tel-hint">Numéro local, ou international commençant par +.</div>
					<div class="fkt-field__error" id="fkt-tel-err" role="alert"></div>
				</div>
				<?php endif; ?>
				<p class="fkt-privacy"><svg class="fkt-ico" aria-hidden="true"><use href="#i-lock"/></svg>
					<span>Vos coordonnées servent uniquement à traiter cette demande. Elles sont effacées de cet écran dès l'envoi.</span></p>
			</form>
		</section>
	</div>

	<div class="fkt-panel__foot">
		<div class="fkt-totals">
			<div>
				<div class="fkt-totals__label"><?= e( $voc['estime'] ?? 'Total estimé' ) ?></div>
				<div class="fkt-totals__note" id="fkt-note"><?= e( $voc['mention_prix'] ?? '' ) ?></div>
			</div>
			<div class="fkt-totals__value" id="fkt-total" aria-live="polite">0 F</div>
		</div>
		<div class="fkt-panel__row">
			<button type="button" class="fkt-btn fkt-btn--ghost" id="fkt-secondaire" data-act="clear">
				<svg class="fkt-ico" aria-hidden="true"><use href="#i-trash"/></svg><span>Effacer</span>
			</button>
			<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl" id="fkt-primaire" data-act="next" disabled>
				<span><?= e( $voc['continuer'] ?? 'Continuer' ) ?></span><svg class="fkt-ico" aria-hidden="true"><use href="#i-arrow-right"/></svg>
			</button>
		</div>
	</div>
</aside>
