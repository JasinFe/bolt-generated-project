<?php
/**
 * COMPOSANT <head> COMMUN AUX ÉCRANS DU TERMINAL (1.806.0).
 *
 * Métabalises de borne, feuilles du Design System dans l'ordre de la cascade,
 * puis les SEULES variables que le serveur pose : l'accent validé par
 * FKC_TerminalTheme (Core → pack → établissement).
 *
 * @var array $ui @var string $titre
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<?php /* Une borne publique n'a rien à faire dans un index de moteur de recherche. */ ?>
<meta name="robots" content="noindex,nofollow">
<?php
/*
 * PLEIN ÉCRAN (1.727.0) — `apple-mobile-web-app-capable` retire la barre du
 * navigateur quand la page est ajoutée à l'écran d'accueil (le seul vrai
 * plein écran sur iPad) ; l'API Fullscreen, déclenchée par le bouton #fs de
 * l'en-tête, couvre Android et les bornes sous Chrome.
 */
?>
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="<?= ! empty( $ui['sombre'] ) ? 'black-translucent' : 'default' ?>">
<meta name="theme-color" content="<?= e( (string) ( $ui['fond'] ?? '#f5f4f0' ) ) ?>">
<meta name="format-detection" content="telephone=no">
<title><?= e( (string) ( $titre ?? 'FinaKop Terminal' ) ) ?></title>
<?= FKC_TerminalTheme::feuilles() ?>
<style><?= FKC_TerminalTheme::variablesCss( $ui ) /* valeurs validées : #rrggbb uniquement */ ?></style>
