<?php
/**
 * ATTRACT SCREEN (1.806.0) — l'écran d'attente d'une borne inoccupée.
 *
 * Il n'apparaît qu'APRÈS une remise à zéro pour inactivité, jamais au premier
 * chargement : un client déjà devant l'écran n'a pas à toucher deux fois.
 * Un appui n'importe où le fait disparaître.
 *
 * @var array $ui @var array $voc @var string $message @var array $promos (1.814.0)
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcM = (array) ( $ui['marque'] ?? array() );
?>
<?php $fkcPromos = array_values( (array) ( $promos ?? array() ) ); ?>
<?php
/* Ambiance de l'écran d'attente, choisie par l'établissement (1.815.0) : halos | photo | sobre. */
$fkcAmb = in_array( (string) ( $ui['ambiance'] ?? 'halos' ), array( 'halos', 'photo', 'sobre' ), true ) ? (string) $ui['ambiance'] : 'halos';
if ( 'photo' === $fkcAmb && empty( $ui['fond_attente'] ) ) { $fkcAmb = 'halos'; }
?>
<div class="fkt-overlay fkt-attract fkt-attract--<?= e( $fkcAmb ) ?><?= $fkcPromos ? ' has-promo' : '' ?>" id="fkt-attract" role="button" tabindex="-1" aria-hidden="true"
	aria-label="<?= e( $voc['attract'] ?? 'Touchez l\'écran pour commencer' ) ?>">
	<?php if ( 'photo' === $fkcAmb ) : ?>
		<img class="fkt-attract__fond" src="<?= e( $ui['fond_attente'] ) ?>" alt="" aria-hidden="true" decoding="async"
			onerror="this.closest('.fkt-attract').classList.replace('fkt-attract--photo','fkt-attract--halos');this.remove()">
	<?php endif; ?>
	<?php if ( 'sobre' !== $fkcAmb ) : ?>
		<div class="fkt-attract__orb fkt-attract__orb--a" aria-hidden="true"></div>
		<div class="fkt-attract__orb fkt-attract__orb--b" aria-hidden="true"></div>
	<?php endif; ?>
	<div class="fkt-attract__inner">
		<?php /* La SOCIÉTÉ : son logo, sinon ses initiales (1.811.0). FinaKop signe seulement le pied. */ ?>
		<div class="fkt-attract__mark<?= ! empty( $ui['logo_url'] ) ? ' has-logo' : '' ?>" aria-hidden="true">
			<?php if ( ! empty( $ui['logo_url'] ) ) : ?>
				<img src="<?= e( $ui['logo_url'] ) ?>" alt="" onerror="this.parentNode.classList.remove('has-logo');this.replaceWith(<?= e( json_encode( (string) ( $fkcM['initiales'] ?? '' ) ) ) ?>)">
			<?php else : ?>
				<?= e( (string) ( $fkcM['initiales'] ?? '' ) ?: '✦' ) ?>
			<?php endif; ?>
		</div>
		<h2 class="fkt-attract__name"><?= e( (string) ( $fkcM['nom'] ?? '' ) ) ?></h2>
		<?php if ( ! empty( $fkcM['service'] ) ) : ?><p class="fkt-attract__service"><?= e( $fkcM['service'] ) ?></p><?php endif; ?>
		<p class="fkt-attract__msg"><?= e( '' !== (string) $message ? $message : ( $voc['intro'] ?? '' ) ) ?></p>
		<?php
		/* Phase 3 (1.814.0) — les contenus de l'établissement défilent sur l'écran d'attente. */
		if ( $fkcPromos ) : ?>
			<div class="fkt-attract__promo" data-carrousel-root aria-hidden="true">
				<div class="fkt-promo__track" data-carrousel>
					<?php foreach ( $fkcPromos as $p ) : ?>
						<div class="fkt-promo__slide<?= '' !== (string) $p['image'] ? ' has-photo' : '' ?>">
							<?php if ( '' !== (string) $p['image'] ) : ?><img class="fkt-promo__img" src="<?= e( $p['image'] ) ?>" alt="" decoding="async" onerror="this.closest('.fkt-promo__slide').classList.remove('has-photo');this.remove()"><?php endif; ?>
							<div class="fkt-promo__body">
								<span class="fkt-promo__title"><?= e( $p['titre'] ) ?></span>
								<?php if ( '' !== (string) $p['texte'] ) : ?><span class="fkt-promo__text"><?= e( $p['texte'] ) ?></span><?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<?php if ( count( $fkcPromos ) > 1 ) : ?>
					<div class="fkt-promo__dots" data-carrousel-dots><?php foreach ( $fkcPromos as $i => $p ) : ?><span class="fkt-promo__dot" data-i="<?= (int) $i ?>"<?= 0 === $i ? ' aria-current="true"' : '' ?>></span><?php endforeach; ?></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<span class="fkt-attract__touch"><svg class="fkt-ico fkt-ico--lg" aria-hidden="true"><use href="#i-touch"/></svg><?= e( $voc['attract'] ?? 'Touchez l\'écran pour commencer' ) ?></span>
	</div>
	<div class="fkt-attract__clock" aria-hidden="true">
		<span data-fkt-clock></span>
		<?php FKC_View::partial( 'terminal::components.signature', array( 'ui' => $ui ) ); ?>
	</div>
</div>
