<?php
/**
 * EN-TÊTE PREMIUM DU TERMINAL (1.806.0) : marque de l'établissement (logo ou
 * pictogramme), nom du service, état réseau, heure, plein écran.
 *
 * Rien ici n'est cliquable par le client en dehors du plein écran : un
 * en-tête de borne n'est pas une navigation.
 *
 * @var array $ui @var string $service (facultatif) @var bool $horloge (défaut true)
 * @var bool $pleinEcran (défaut true — faux sur la page de suivi, ouverte sur le téléphone du client)
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcM = (array) ( $ui['marque'] ?? array() );
$fkcNom = (string) ( $fkcM['nom'] ?? 'FinaKop' );
$fkcService = (string) ( $service ?? ( $fkcM['service'] ?? '' ) );
$fkcInitiale = mb_substr( $fkcNom, 0, 1 );
$fkcInitiale = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $fkcInitiale ) : strtoupper( $fkcInitiale );
?>
<header class="fkt-header">
	<div class="fkt-brand">
		<?php
		/*
		 * LA SOCIÉTÉ EN EN-TÊTE (1.811.0) : son logo, sinon ses initiales —
		 * comme l'en-tête de l'application. Plus jamais le logo FinaKop ici :
		 * la marque du produit ne signe que le pied de page.
		 */
		?>
		<div class="fkt-brand__mark<?= ! empty( $ui['logo_url'] ) ? ' has-logo' : '' ?>" aria-hidden="true">
			<?php if ( ! empty( $ui['logo_url'] ) ) : ?>
				<img src="<?= e( $ui['logo_url'] ) ?>" alt="" onerror="this.parentNode.classList.remove('has-logo');this.replaceWith(<?= e( json_encode( (string) ( $fkcM['initiales'] ?? $fkcInitiale ) ) ) ?>)">
			<?php else : ?>
				<?= e( (string) ( $fkcM['initiales'] ?? $fkcInitiale ) ) ?>
			<?php endif; ?>
		</div>
		<div class="fkt-brand__txt">
			<span class="fkt-brand__name"><?= e( $fkcNom ) ?></span>
			<?php if ( '' !== $fkcService ) : ?><span class="fkt-brand__service"><?= e( $fkcService ) ?></span><?php endif; ?>
		</div>
	</div>
	<div class="fkt-header__end">
		<?php if ( ! isset( $pleinEcran ) || $pleinEcran ) : /* indicateur réseau : seulement sur un appareil du Terminal */ ?>
		<span class="fkt-net" role="status" aria-live="polite" aria-label="Connecté">
			<span class="fkt-net__dot" aria-hidden="true"></span><span class="fkt-net__label">Connecté</span>
		</span>
		<?php endif; ?>
		<?php if ( ! isset( $horloge ) || $horloge ) : ?><span class="fkt-clock" data-fkt-clock aria-hidden="true"></span><?php endif; ?>
		<?php /* Plein écran : un bouton, parce qu'aucun navigateur n'y entre sans geste (1.727.0). */ ?>
		<?php if ( ! isset( $pleinEcran ) || $pleinEcran ) : ?>
		<button id="fs" type="button" class="fkt-btn fkt-btn--icon fkt-btn--quiet" aria-label="Plein écran" title="Plein écran">
			<svg class="fkt-ico"><use href="#i-expand"/></svg>
		</button>
		<?php endif; ?>
	</div>
</header>
