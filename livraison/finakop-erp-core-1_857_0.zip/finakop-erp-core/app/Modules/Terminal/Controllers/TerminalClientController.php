<?php
/**
 * TERMINAL CLIENT — routes PUBLIQUES, authentifiées par le jeton d'appairage.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * AUCUNE DE CES ROUTES N'A DE SESSION. Il n'y a donc ni utilisateur, ni rôle,
 * ni société résolue d'avance : tout part du jeton posé dans le cookie de
 * l'appareil, qui porte le numéro de l'établissement en préfixe.
 *
 * CHAQUE POINT D'ENTRÉE REPASSE PAR LA GARDE. L'interface d'un écran
 * d'affichage ne montre pas de bouton « commander » — cela ne suffit pas, et
 * ne suffira jamais : une requête se fabrique à la main. La capacité est donc
 * vérifiée au serveur, à chaque appel, sans exception.
 *
 * @package FinaKop_ERP_Core
 */

defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_TerminalClientController {

	protected function json( $data, $code = 200 ) {
		http_response_code( $code );
		header( 'Content-Type: application/json; charset=utf-8' );
		$this->sansCache();
		echo json_encode( $data, JSON_UNESCAPED_UNICODE );
	}

	/**
	 * RIEN DE CE QUE SERT LE TERMINAL NE SE MET EN CACHE (1.806.0).
	 *
	 * Une borne est partagée par des inconnus qui se succèdent. Une page ou
	 * une réponse gardée par le navigateur — bouton « Précédent », cache
	 * disque, proxy de l'hôtel — pourrait rendre au client suivant l'état
	 * laissé par le précédent. `no-store` interdit de l'écrire nulle part.
	 */
	protected function sansCache() {
		if ( headers_sent() ) { return; }
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		header( 'Pragma: no-cache' );
	}

	/**
	 * Identité visuelle et réglages d'un écran : Core → pack → établissement.
	 * Réunis ici pour que les quatre écrans (appairage, client, atelier,
	 * affichage) se dessinent avec le MÊME Design System.
	 */
	protected function ui( $t, $adapt, $defaut ) {
		$ui = FKC_TerminalTheme::resoudre( $t, $adapt, $defaut );
		$ui['reglages'] = FKC_Terminal::reglages( $t );
		$ui['logo_url'] = ! empty( $ui['marque']['logo'] ) ? url( 'terminal/logo' ) : '';
		return $ui;
	}

	/**
	 * Le terminal de l'appareil courant, ou null s'il n'est pas (ou plus) appairé.
	 *
	 * LE JETON N'EST PLUS ACCEPTÉ DANS L'URL (1.735.0).
	 *
	 * Il l'était, en dernier recours, par `$_GET['jeton']`. Aucun écran ne
	 * s'en servait — mais une adresse se retrouve dans les journaux du
	 * serveur, dans ceux du proxy, dans l'historique du navigateur et dans
	 * l'en-tête Referer de la première ressource externe venue. Le cookie est
	 * posé `HttpOnly` précisément pour que ce jeton ne circule pas ainsi :
	 * laisser une porte qui le remet en clair dans une URL vidait la
	 * précaution de son sens.
	 *
	 * Le corps d'un POST, lui, n'est pas journalisé : la branche est
	 * conservée comme issue de secours pour un navigateur de borne qui
	 * refuserait les cookies.
	 */
	protected function terminal() {
		$j = (string) ( $_COOKIE[ FKC_Terminal::COOKIE ] ?? '' );
		if ( '' === $j ) { $j = (string) ( $_POST['jeton'] ?? '' ); }
		return FKC_Terminal::parJeton( $j );
	}

	/**
	 * Page unique de l'appareil : écran d'appairage tant qu'il n'est pas
	 * associé, expérience du pack ensuite.
	 *
	 * Rendue SANS le gabarit de l'application — pas de barre latérale, pas de
	 * menu, pas de nom d'utilisateur. Ce n'est pas une question d'esthétique :
	 * le gabarit affiche des éléments qui n'ont rien à faire sous les yeux
	 * d'un client.
	 */
	public function index() {
		$this->sansCache();
		$t = $this->terminal();
		if ( ! $t ) {
			FKC_View::render( 'terminal::appairage', array(
				'erreur' => '',
				'ui'     => FKC_TerminalTheme::resoudre( array(), null, 'sombre' ),
			), null );
			return;
		}
		/* 1.840.0 — écrans de caisse : écran client et vérificateur de prix. */
		if ( 'afficheur_caisse' === (string) $t['type'] ) {
			FKC_View::render( 'terminal::afficheur_caisse', array( 'terminal' => $t, 'ui' => $this->ui( $t, null, 'sombre' ) ), null );
			return;
		}
		if ( 'verificateur_prix' === (string) $t['type'] ) {
			FKC_View::render( 'terminal::prix', array( 'terminal' => $t, 'ui' => $this->ui( $t, null, 'clair' ) ), null );
			return;
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		$voc = $adapt && method_exists( $adapt, 'vocabulaire' ) ? $adapt::vocabulaire() : array();
		if ( in_array( (string) $t['type'], array( 'cuisine', 'preparation' ), true ) ) {
			FKC_View::render( 'terminal::file', array(
				'terminal' => $t,
				'ui'       => $this->ui( $t, $adapt, 'sombre' ),
				'file' => ( $adapt && method_exists( $adapt, 'file' ) ) ? $adapt::file( $t['pack'] ) : array(),
				'peutAvancer' => FKC_Terminal::peut( $t, 'avancer' ),
			), null );
			return;
		}
		/*
		 * L'ÉCRAN D'AFFICHAGE A ENFIN LE SIEN (1.736.0).
		 *
		 * Il n'y avait que deux branches : atelier, ou client. Un terminal
		 * déclaré « affichage » tombait donc sur la page du client avec un
		 * catalogue vide — sa capacité ne lui en donne aucun — et affichait
		 * « Le catalogue est vide pour le moment. Adressez-vous à l'accueil »
		 * indéfiniment, sur un mur, devant la salle d'attente.
		 */
		if ( 'affichage' === (string) $t['type'] ) {
			FKC_View::render( 'terminal::affichage', array(
				'terminal' => $t,
				'ui'       => $this->ui( $t, $adapt, 'sombre' ),
				'voc'      => $voc,
				'tableau'  => ( $adapt && method_exists( $adapt, 'tableau' ) && FKC_Terminal::peut( $t, 'tableau' ) )
					? $adapt::tableau( $t['pack'] ) : array(),
			), null );
			return;
		}
		/* 1.820.0 — la carte de CETTE borne (rubriques choisies) et son état d'ouverture. */
		$fkcCat = ( $adapt && FKC_Terminal::peut( $t, 'catalogue' ) ) ? FKC_Terminal::filtrerCatalogue( $t, $adapt::catalogue( $t['pack'] ) ) : array();
		FKC_View::render( 'terminal::client', array(
			'terminal' => $t,
			'ouverture' => FKC_Terminal::ouverture( $t ),
			/* Phase 3 (1.814.0) : contenus promotionnels de l'établissement. */
			'promos'   => FKC_Terminal::peut( $t, 'catalogue' ) ? FKC_TerminalPromo::publiques( $t['pack'], $fkcCat ) : array(),
			'ui'       => $this->ui( $t, $adapt, 'clair' ),
			'identite' => ( $adapt && method_exists( $adapt, 'identite' ) ) ? (array) $adapt::identite() : array(),
			'voc'      => $voc,
			'catalogue' => $fkcCat,
			'peutCommander' => FKC_Terminal::peut( $t, 'commander' ),
			/*
			 * LE MODE « ASSISTÉ » FAIT ENFIN QUELQUE CHOSE (1.736.0). Il
			 * figurait dans la liste des modes et n'était lu nulle part :
			 * seul « lecture » avait un effet, si bien qu'« assisté » était
			 * en tout point identique à « libre-service ». Le module s'appliquait
			 * à lui-même ce qu'il énonce depuis 1.727.0 : un réglage qui ne
			 * fait rien est un réglage qui trompe.
			 *
			 * Effet retenu, minimal et vérifiable : en libre-service, l'écran
			 * se remet seul à zéro après la confirmation, parce que le client
			 * suivant arrive ; en assisté, il attend que l'opérateur ferme —
			 * celui-ci note la référence, la dicte, ou la montre au client.
			 */
			'autoReset' => 'assiste' !== (string) ( $t['mode'] ?? 'libre' ),
		), null );
	}

	/** Appairage : le code dicté par l'exploitant est échangé contre un jeton. */
	public function appairer() {
		if ( FKC_Terminal::appairageBloque() ) {
			return $this->json( array( 'ok' => false,
				'message' => 'Trop de tentatives depuis cet appareil. Réessayez dans quelques minutes.' ), 429 );
		}
		list( $ok, $msg, $jeton, $t ) = FKC_Terminal::appairer( (string) ( $_POST['code'] ?? '' ), array(
			'appareil'   => (string) ( $_POST['appareil'] ?? 'Terminal' ),
			'plateforme' => (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ),
		) );
		if ( ! $ok ) {
			FKC_Terminal::appairageEchec();
			return $this->json( array( 'ok' => false, 'message' => $msg ) );
		}
		FKC_Terminal::appairageOk();
		/*
		 * COOKIE LONG, ET VOLONTAIREMENT : une tablette de salle ne se
		 * réappaire pas tous les matins. Il est HttpOnly — le jeton ne doit
		 * pas être lisible par un script de la page — et SameSite=Lax.
		 *
		 * `secure` PASSE PAR FKC_Security::isHttps() (1.735.0). On testait
		 * `$_SERVER['HTTPS']` à la main : cette variable est absente dès que
		 * TLS se termine sur un reverse proxy — nginx, Apache en frontal,
		 * Cloudflare — c'est-à-dire dans l'installation la plus courante. Le
		 * cookie partait alors SANS l'attribut, et le jeton d'appairage
		 * pouvait voyager en clair sur le premier saut non chiffré. Le noyau
		 * sait déjà lire `X-Forwarded-Proto` et le port 443 ; il n'y avait
		 * aucune raison d'en écrire une seconde version, moins complète.
		 */
		setcookie( FKC_Terminal::COOKIE, FKC_Terminal::jetonComplet( $t ), array(
			'expires'  => time() + 365 * 86400,
			'path'     => '/',
			'httponly' => true,
			'samesite' => 'Lax',
			'secure'   => class_exists( 'FKC_Security' )
				? FKC_Security::isHttps()
				: ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== strtolower( (string) $_SERVER['HTTPS'] ) ),
		) );
		return $this->json( array( 'ok' => true, 'message' => $msg ) );
	}

	/**
	 * BATTEMENT DE L'APPAREIL (1.806.0).
	 *
	 * Deux usages, un seul appel léger :
	 *   · l'indicateur réseau de l'écran — « connecté » tant que ce point
	 *     répond, « connexion interrompue » sinon ;
	 *   · LA RÉVOCATION SE VOIT ENFIN. Un terminal révoqué continuait
	 *     d'afficher son catalogue jusqu'au prochain rechargement — parfois
	 *     des jours, sur une borne jamais touchée — et le client découvrait
	 *     le refus au moment d'envoyer. Un 403 ici fait revenir l'appareil à
	 *     l'écran d'appairage.
	 *
	 * La signature de configuration permet aussi de recharger l'écran quand
	 * l'exploitant change son thème ou son délai d'inactivité.
	 */
	public function ping() {
		$t = $this->terminal();
		if ( ! $t ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$r = FKC_Terminal::reglages( $t );
		return $this->json( array(
			'ok'     => true,
			'heure'  => date( 'H:i' ),
			/*
			 * L'EMPREINTE DE CONFIGURATION couvre aussi (1.820.0) les horaires,
			 * l'état ouvert/fermé, les rubriques et l'apparence de l'établissement :
			 * quand l'un change — ou quand l'heure d'ouverture arrive — la borne se
			 * recharge d'elle-même dès que personne ne compose.
			 */
			'config' => substr( md5( json_encode( array( $r, (string) $t['mode'], (string) $t['nom'],
				(string) ( $t['horaires'] ?? '' ), (string) ( $t['rubriques'] ?? '' ), FKC_Terminal::ouverture( $t )['ouvert'],
				class_exists( 'FKC_TerminalMarque' ) ? FKC_TerminalMarque::reglages() : array() ) ) ), 0, 12 ),
			'ouvert' => FKC_Terminal::ouverture( $t )['ouvert'],
		) );
	}

	/**
	 * Logo de l'établissement, pour l'en-tête et l'écran d'attente (1.806.0).
	 *
	 * La route de gestion `societes/{id}/logo` exige une session : la borne
	 * n'en a pas. Celle-ci est ouverte au seul jeton, ne sert QUE le logo de
	 * la société de ce jeton, et ne prend aucun paramètre — il n'y a rien à
	 * deviner ni à énumérer.
	 */
	public function logo() {
		$t = $this->terminal();
		$soc = $t ? (int) ( $t['societe_id'] ?? 0 ) : 0;
		$row = null;
		if ( $soc && class_exists( 'FKC_Master' ) ) {
			try { $row = FKC_Master::q( 'SELECT * FROM societes WHERE id=?', array( $soc ) )->fetch(); } catch ( \Throwable $e ) {}
		}
		$fichier = $row ? FKC_TerminalTheme::logoFichier( $row ) : null;
		if ( ! $fichier ) { http_response_code( 404 ); return; }
		$mime = (string) ( $row['logo_mime'] ?? '' );
		if ( ! in_array( $mime, array( 'image/png', 'image/jpeg', 'image/gif', 'image/webp' ), true ) ) { $mime = 'image/png'; }
		header( 'Content-Type: ' . $mime );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Cache-Control: private, max-age=3600' );
		header( 'Content-Length: ' . (string) filesize( $fichier ) );
		readfile( $fichier );
	}

	/**
	 * PHOTO D'UNE PRESTATION, servie à la borne (1.807.0).
	 *
	 * Seulement si le jeton ouvre le catalogue ET que la prestation figure au
	 * catalogue PUBLIC de ce terminal (bon pack, active, affichée à
	 * l'accueil) : la route ne sert pas à parcourir les photos d'un autre
	 * métier ou d'une prestation retirée.
	 */
	public function image( $id ) {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'catalogue' ) ) { http_response_code( 403 ); return; }
		/*
		 * 1.812.0 — la photo est demandée au MÉTIER du terminal (prestation du
		 * Studio, plat du Restaurant…) : c'est lui qui sait ce qui est visible.
		 * Un terminal ne voit que les photos de son propre pack.
		 */
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		$p = ( $adapt && method_exists( $adapt, 'image' ) ) ? $adapt::image( $t['pack'], (int) $id ) : null;
		if ( ! $p ) { http_response_code( 404 ); return; }
		FKC_TerminalMedia::servir( $p );
	}

	/** Photo de fond de l'écran d'attente, choisie par l'établissement (1.815.0). Tout terminal actif de la société la voit. */
	public function fond() {
		$t = $this->terminal();
		if ( ! $t ) { http_response_code( 403 ); return; }
		$p = FKC_TerminalMarque::fondChemin();
		if ( ! $p ) { http_response_code( 404 ); return; }
		FKC_TerminalMedia::servir( $p );
	}

	/** Photo d'un contenu promotionnel (1.814.0) — seulement s'il est à l'écran pour le pack de CE terminal. */
	public function promoImage( $id ) {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'catalogue' ) ) { http_response_code( 403 ); return; }
		$p = FKC_TerminalPromo::imagePourBorne( (int) $id, (string) $t['pack'] );
		if ( ! $p ) { http_response_code( 404 ); return; }
		FKC_TerminalMedia::servir( $p );
	}

	/**
	 * LES LIEUX DISPONIBLES — étape « Votre table » (1.808.0).
	 *
	 * Relus à chaque ouverture de l'étape : une table se libère ou se prend
	 * pendant que le client compose. Réservé aux terminaux qui COMMANDENT —
	 * un écran d'affichage n'a pas à lister l'occupation de la salle.
	 */
	public function lieux() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'commander' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		if ( ! $adapt || ! method_exists( $adapt, 'lieux' ) ) {
			return $this->json( array( 'ok' => true, 'lieux' => array() ) );
		}
		return $this->json( array( 'ok' => true, 'lieux' => array_values( (array) $adapt::lieux( $t['pack'] ) ) ) );
	}

	/** Catalogue public, en JSON. */
	public function catalogue() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'catalogue' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		$arts = $adapt ? FKC_Terminal::filtrerCatalogue( $t, $adapt::catalogue( $t['pack'] ) ) : array();
		/* Les contenus promotionnels voyagent avec le catalogue (1.814.0) : la borne se recharge quand ils changent. */
		return $this->json( array( 'ok' => true, 'articles' => $arts, 'promos' => FKC_TerminalPromo::publiques( $t['pack'], $arts ),
			'ouvert' => FKC_Terminal::ouverture( $t )['ouvert'] ) );
	}

	/** Le client envoie sa demande. Elle naît en brouillon, elle ne comptabilise rien. */
	public function commander() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'commander' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Ce terminal n\'est pas autorisé à commander.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		if ( ! $adapt ) { return $this->json( array( 'ok' => false, 'message' => 'Service indisponible.' ), 503 );	}

		/*
		 * LIMITE DE DÉBIT PAR TERMINAL (1.736.0).
		 *
		 * L'appairage était limité, l'envoi de demandes ne l'était pas. Sur
		 * une borne de hall, n'importe qui peut appuyer sur « Envoyer » en
		 * boucle : c'est exactement le bruit que 1.724.0 combattait en
		 * effaçant les coquilles vides, et la liste que le professionnel doit
		 * traiter chaque matin est le pire endroit où le laisser entrer.
		 *
		 * On s'appuie sur le compteur d'actions déjà en place — il compte des
		 * essais et bloque au-delà d'un seuil, ce qui est précisément ce qu'on
		 * veut ici, même si l'essai n'a rien d'un échec. Huit demandes puis
		 * deux minutes de pause : large pour un comptoir, court pour un
		 * client qui se ravise, insupportable pour un automate.
		 */
		$cle = 'terminal:' . (int) $t['id'];
		if ( class_exists( 'FKC_Security' ) && FKC_Security::actionBloquee( 'terminal_commande', $cle ) ) {
			return $this->json( array( 'ok' => false,
				'message' => 'Trop de demandes envoyées coup sur coup. Patientez un instant ou adressez-vous à l\'accueil.' ), 429 );
		}

		$panier = json_decode( (string) ( $_POST['panier'] ?? '[]' ), true );
		if ( ! is_array( $panier ) ) { $panier = array(); }
		/*
		 * PLAFOND DE LIGNES. Une route publique sans session accepte tout ce
		 * qu'on lui envoie : sans borne, un panier de dix mille lignes ouvre
		 * dix mille lignes de commande dans les livres d'un tiers. Vingt est
		 * large pour un comptoir et ridicule pour un automate.
		 */
		if ( count( $panier ) > 20 ) {
			return $this->json( array( 'ok' => false, 'message' => 'Demande trop longue : adressez-vous à l\'accueil.' ) );
		}
		/*
		 * HORAIRES ET RUBRIQUES (1.820.0) — contrôlés ICI, pas seulement à
		 * l'écran : une borne restée ouverte sur la carte après la fermeture,
		 * ou une requête fabriquée, ne passe pas.
		 */
		$ouv = FKC_Terminal::ouverture( $t );
		if ( ! $ouv['ouvert'] ) {
			return $this->json( array( 'ok' => false, 'ferme' => true, 'message' => 'La borne est fermée. ' . $ouv['libelle'] ) );
		}
		if ( FKC_Terminal::rubriques( $t ) ) {
			$visibles = array_flip( array_map( 'intval', array_column( FKC_Terminal::filtrerCatalogue( $t, $adapt::catalogue( $t['pack'] ) ), 'id' ) ) );
			foreach ( $panier as $l ) {
				if ( is_array( $l ) && ! isset( $visibles[ (int) ( $l['id'] ?? 0 ) ] ) ) {
					return $this->json( array( 'ok' => false, 'message' => 'Un article de votre demande n\'est pas disponible sur cette borne.' ) );
				}
			}
		}
		/*
		 * `mb_substr` et non `substr` (1.806.0) : couper « Adjoua Kouassi-Bé »
		 * à l'octet près pouvait trancher un caractère accentué en deux et
		 * ranger en base une chaîne UTF-8 invalide, que la page de gestion
		 * affichait ensuite en losanges.
		 */
		list( $ok, $msg, $ref ) = $adapt::commander( $t['pack'], $panier, array(
			'nom' => mb_substr( trim( (string) ( $_POST['nom'] ?? '' ) ), 0, 80 ),
			'tel' => mb_substr( trim( (string) ( $_POST['tel'] ?? '' ) ), 0, 30 ),
			/* 1.808.0 — le LIEU choisi (table du restaurant) ; le pack le revérifie. */
			'lieu_id' => (int) ( $_POST['lieu_id'] ?? 0 ),
			'mode'    => 'emporter' === (string) ( $_POST['mode'] ?? '' ) ? 'emporter' : 'sur_place', // 1.813.0
		), $t );
		if ( $ok && class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'terminal_commande', 'terminal_id=' . (int) $t['id'] . ' ref=' . (string) $ref );
			// Le compteur ne retient que les demandes ACCEPTÉES : un panier
			// vide ou une prestation retirée ne doit pas condamner la borne.
			FKC_Security::actionEchec( 'terminal_commande', $cle, 8, 2 );
		}
		/*
		 * LE LIEN DE SUIVI (1.807.0) — signé, pour le QR du ticket. Le client
		 * le scanne et suit sa demande sur son téléphone, sans compte.
		 */
		$suivi = ( $ok && $ref && class_exists( 'FKC_TerminalSuivi' ) )
			? FKC_TerminalSuivi::url( (int) ( $t['societe_id'] ?? 0 ), (string) $t['pack'], (string) $ref ) : '';
		return $this->json( array( 'ok' => $ok, 'message' => $msg, 'reference' => $ref, 'suivi_url' => $suivi ) );
	}

	/**
	 * L'ATELIER FAIT AVANCER LA PRODUCTION (1.736.0).
	 *
	 * La capacité est vérifiée ici comme toutes les autres : le bouton absent
	 * de l'écran d'un type qui n'y a pas droit ne protège rien, une requête
	 * se fabrique à la main.
	 */
	public function avancer() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'avancer' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		if ( ! $adapt || ! method_exists( $adapt, 'avancer' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Service indisponible.' ), 503 );
		}
		$vers = (string) ( $_POST['vers'] ?? '' );
		list( $ok, $msg, $etat ) = $adapt::avancer( $t['pack'], (string) ( $_POST['reference'] ?? '' ), '' !== $vers ? $vers : null );
		return $this->json( array( 'ok' => $ok, 'message' => $msg, 'etat' => $etat ) );
	}

	/** Le tableau de salle d'attente d'un écran d'affichage. */
	public function tableau() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'tableau' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		return $this->json( array( 'ok' => true,
			'tableau' => ( $adapt && method_exists( $adapt, 'tableau' ) ) ? $adapt::tableau( $t['pack'] ) : array() ) );
	}

	/**
	 * État de l'addition en cours du poste de CE terminal (1.840.0). Le poste
	 * vient de la déclaration du terminal, jamais de la requête : un écran ne
	 * peut pas lire l'addition d'une autre caisse en changeant l'adresse.
	 */
	public function afficheur() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'afficheur' ) || empty( $t['caisse_id'] ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		FKC_PosConfig::poste( (int) $t['caisse_id'] );
		return $this->json( array( 'ok' => true ) + FKC_Pos::afficheurEtat( (int) $t['caisse_id'] ) );
	}

	/**
	 * Prix d'un article scanné (vérificateur de prix, 1.840.0) : libellé, prix
	 * public, promotion éventuelle. Ni stock, ni coût, ni tarif client.
	 */
	public function prix() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'prix' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$code = trim( (string) ( $_GET['code'] ?? '' ) );
		if ( '' === $code || strlen( $code ) > 64 ) { return $this->json( array( 'ok' => false, 'message' => 'Scannez un article.' ) ); }
		$art = null;
		if ( class_exists( 'FKC_Scan' ) ) {
			$res = FKC_Scan::resoudre( $code, 'consultation', array( 'module' => 'caisse', 'canal' => 'borne' ) );
			if ( ! empty( $res['ok'] ) && 'article' === ( $res['entite_type'] ?? '' ) && ! empty( $res['entite_id'] ) ) {
				$art = FKC_InvArticle::find( (int) $res['entite_id'] );
			}
		}
		if ( ! $art ) {
			try { $art = FKC_DB::q( 'SELECT * FROM inv_articles WHERE code=? AND actif=1 LIMIT 1', array( $code ) )->fetch() ?: null; }
			catch ( \Throwable $e ) { $art = null; }
		}
		if ( ! $art ) { return $this->json( array( 'ok' => false, 'message' => 'Article inconnu : adressez-vous à la caisse.' ) ); }
		return $this->json( array( 'ok' => true, 'article' => array(
			'libelle' => (string) $art['designation'], 'prix' => (float) $art['prix_vente'], 'unite' => (string) ( $art['unite'] ?? '' ),
		) ) );
	}

	/** Suivi d'une demande, par sa référence. */
	public function statut( $ref ) {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'statut' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		$s = $adapt ? $adapt::statut( $t['pack'], (string) $ref ) : null;
		if ( ! $s ) { return $this->json( array( 'ok' => false, 'message' => 'Demande introuvable.' ), 404 ); }
		$s['etapes'] = FKC_TerminalSuivi::timeline( (string) ( $s['etape'] ?? 'recue' ) );
		return $this->json( array( 'ok' => true, 'suivi' => $s ) );
	}

	/**
	 * PAGE PUBLIQUE DE SUIVI (1.807.0) — ouverte par le QR du ticket, sur le
	 * téléphone du client. Ni session, ni jeton d'appareil : le lien SIGNÉ
	 * est la seule clé (FKC_TerminalSuivi). `?format=json` sert la même
	 * information à la page elle-même, qui se tient à jour seule.
	 *
	 * Une signature fausse compte comme un essai raté, par adresse IP : on
	 * n'énumère pas les demandes d'un établissement en essayant des liens.
	 */
	public function suivre( $code ) {
		$this->sansCache();
		$json = 'json' === (string) ( $_GET['format'] ?? '' );
		$ip = class_exists( 'FKC_Security' ) ? FKC_Security::clientIp() : '';
		if ( class_exists( 'FKC_Security' ) && FKC_Security::actionBloquee( 'terminal_suivi', $ip ) ) {
			return $this->refusSuivi( $json, 429, 'Trop de liens invalides depuis cet appareil. Réessayez dans quelques minutes.' );
		}
		$d = FKC_TerminalSuivi::decoder( (string) $code );
		if ( ! $d ) {
			if ( class_exists( 'FKC_Security' ) ) { FKC_Security::actionEchec( 'terminal_suivi', $ip, 20, 15 ); }
			return $this->refusSuivi( $json, 404, 'Ce lien de suivi n\'est pas valide.' );
		}
		list( $soc, $pack, $ref ) = $d;
		$lie = class_exists( 'FKC_Tenant' ) ? ( ( FKC_Tenant::current() && (int) FKC_Tenant::id() === $soc ) || FKC_Tenant::bindById( $soc ) ) : true;
		$adapt = $lie ? FKC_TerminalAdapter::pour( $pack ) : null;
		$s = $adapt ? $adapt::statut( $pack, $ref ) : null;
		if ( ! $s ) { return $this->refusSuivi( $json, 404, 'Cette demande est introuvable. Adressez-vous à l\'accueil.' ); }

		/* Rien d'autre que ce qu'un inconnu peut lire sans dommage. */
		$pub = array(
			'reference' => (string) $s['reference'],
			'libelle'   => (string) $s['libelle'],
			'etape'     => (string) ( $s['etape'] ?? 'recue' ),
			'etapes'    => FKC_TerminalSuivi::timeline( (string) ( $s['etape'] ?? 'recue' ) ),
			'date'      => (string) ( $s['date'] ?? '' ),
		);
		if ( $json ) { return $this->json( array( 'ok' => true, 'suivi' => $pub ) ); }
		$t = array( 'societe_id' => $soc, 'theme' => 'clair' );
		$ui = FKC_TerminalTheme::resoudre( $t, $adapt, 'clair' );
		/* Le logo de la SOCIÉTÉ, servi par une route du même lien signé : le
		   téléphone du client n'a pas de jeton d'appareil (1.811.0). */
		$ui['logo_url'] = ! empty( $ui['marque']['logo'] ) ? url( 'suivre/' . $code . '/logo' ) : '';
		FKC_View::render( 'terminal::suivi', array(
			'suivi' => $pub,
			'code'  => (string) $code,
			'ui'    => $ui,
		), null );
	}

	/**
	 * Logo de la société sur la page publique de suivi (1.811.0). Même clé que
	 * la page : le lien signé. Rien d'autre n'est servi par cette route.
	 */
	public function suivreLogo( $code ) {
		$d = FKC_TerminalSuivi::decoder( (string) $code );
		$row = null;
		if ( $d && class_exists( 'FKC_Master' ) ) {
			try { $row = FKC_Master::q( 'SELECT * FROM societes WHERE id=?', array( (int) $d[0] ) )->fetch(); } catch ( \Throwable $e ) {}
		}
		$f = $row ? FKC_TerminalTheme::logoFichier( $row ) : null;
		if ( ! $f ) { http_response_code( 404 ); return; }
		$mime = (string) ( $row['logo_mime'] ?? '' );
		if ( ! in_array( $mime, array( 'image/png', 'image/jpeg', 'image/gif', 'image/webp' ), true ) ) { $mime = 'image/png'; }
		header( 'Content-Type: ' . $mime );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Cache-Control: private, max-age=3600' );
		readfile( $f );
	}

	protected function refusSuivi( $json, $code, $msg ) {
		if ( $json ) { return $this->json( array( 'ok' => false, 'message' => $msg ), $code ); }
		http_response_code( $code );
		FKC_View::render( 'terminal::suivi', array(
			'suivi' => null, 'code' => '', 'message' => $msg,
			'ui'    => FKC_TerminalTheme::resoudre( array( 'theme' => 'clair' ), null, 'clair' ),
		), null );
	}

	/** File d'un écran d'atelier, rafraîchie par la page elle-même. */
	public function file() {
		$t = $this->terminal();
		if ( ! $t || ! FKC_Terminal::peut( $t, 'file' ) ) {
			return $this->json( array( 'ok' => false, 'message' => 'Terminal non autorisé.' ), 403 );
		}
		$adapt = FKC_TerminalAdapter::pour( $t['pack'] );
		return $this->json( array( 'ok' => true,
			'file' => ( $adapt && method_exists( $adapt, 'file' ) ) ? $adapt::file( $t['pack'] ) : array() ) );
	}
}
