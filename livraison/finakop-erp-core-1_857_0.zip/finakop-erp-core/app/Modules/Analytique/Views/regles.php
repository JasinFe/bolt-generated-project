<?php
/**
 * ANALYTIQUE → RÈGLES D'IMPUTATION AUTOMATIQUE (1.824.0).
 *
 * @var array $regles @var array $axes @var array $valeurs [axe => [id => libellé]] @var array $cles [axe => [id => libellé]]
 * @var array $tiers ['fournisseur'|'client' => ['type:id' => nom]] @var array $journaux @var string $annee @var array $annees
 * @var array $apercu @var int $reste @var array $form @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcF = function ( $k, $def = '' ) use ( $form ) { return isset( $form[ $k ] ) ? (string) $form[ $k ] : $def; };
$fkcAxe = (int) $fkcF( 'axe_id', (string) ( $axes[0]['id'] ?? 0 ) );
$fkcMode = 'cle' === $fkcF( 'mode' ) ? 'cle' : 'valeur';
$fkcAvecCles = ! empty( $cles );
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'regles' ) ); ?>
<?php if ( $flash ) : ?><div class="alert <?= 0 === strpos( (string) $flash, 'Refusé' ) ? 'alert-err' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>

<p class="help" style="margin-top:0">Une règle impute toute seule les lignes de charges et de produits qui lui correspondent, dès leur comptabilisation — y compris à la validation du journal temporaire. Elle ne remplit que les axes <strong>encore vides</strong> : une affectation saisie à la main n'est jamais écrasée. Par axe, la première règle qui correspond l'emporte (priorité la plus basse d'abord).</p>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
		<h2>Règles</h2>
		<form method="get" style="display:flex;gap:6px;align-items:center;margin:0"><span class="muted">Aperçu sur l'exercice</span>
			<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= (string) $y === (string) $annee ? 'selected' : '' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
	</div>
	<div style="overflow-x:auto"><table class="table">
		<thead><tr><th class="num" style="width:60px">Prio.</th><th>Règle</th><th class="num">Déjà imputées</th><th class="num">À rattraper <?= e( $annee ) ?></th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $regles ) : ?><tr><td colspan="5" class="empty">Aucune règle. Créez la première ci-dessous — par exemple « compte 622 du fournisseur X → Division : Abidjan ».</td></tr>
		<?php else : foreach ( $regles as $r ) : $on = ! empty( $r['actif'] ); ?>
			<tr<?= $on ? '' : ' class="muted"' ?>>
				<td class="num"><?= (int) $r['priorite'] ?></td>
				<td><strong><?= e( $r['libelle'] ) ?></strong><?= $on ? '' : ' <span class="tag">suspendue</span>' ?><br><span class="muted" style="font-size:12px"><?= e( $r['texte'] ) ?></span></td>
				<td class="num"><?= (int) $r['appliquees'] ?></td>
				<td class="num"><?= $on ? (int) ( $apercu['par_regle'][ (int) $r['id'] ] ?? 0 ) : '—' ?></td>
				<td class="right" style="white-space:nowrap">
					<form method="post" action="<?= e( url( 'analytique/regles/' . (int) $r['id'] . '/basculer' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit"><?= $on ? 'Suspendre' : 'Réactiver' ?></button></form>
					<form method="post" action="<?= e( url( 'analytique/regles/' . (int) $r['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer cette règle ? Les imputations qu\'elle a déjà posées restent en place.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)">✕</button></form>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
	<?php if ( $regles ) : ?>
	<div class="card-body" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;border-top:1px solid var(--line)">
		<?php if ( $apercu['clos'] ) : ?>
			<span class="muted">🔒 L'exercice <?= e( $annee ) ?> est clôturé : ses imputations sont figées.</span>
		<?php elseif ( $apercu['lignes'] ) : ?>
			<span>Sur l'exercice <?= e( $annee ) ?>, les règles actives imputeraient <strong><?= (int) $apercu['lignes'] ?></strong> ligne(s) déjà passée(s)<?= $reste ? ' (' . (int) $reste . ' ligne(s) sans aucune imputation au total)' : '' ?>.</span>
			<form method="post" action="<?= e( url( 'analytique/regles/appliquer' ) ) ?>" style="margin:0" onsubmit="return confirm('Appliquer les règles à <?= (int) $apercu['lignes'] ?> ligne(s) de l\'exercice <?= e( $annee ) ?> ? Seuls les axes vides sont remplis.')"><?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>"><button class="btn btn-primary btn-sm" type="submit">Appliquer aux lignes déjà passées</button></form>
		<?php else : ?>
			<span class="muted">Rien à rattraper sur l'exercice <?= e( $annee ) ?> : aucune ligne vide ne correspond aux règles actives.</span>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</div>

<div class="card">
	<div class="card-head"><h2>Nouvelle règle</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'analytique/regles' ) ) ?>" id="fkc-rg-form" style="display:grid;gap:14px">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:minmax(0,3fr) minmax(0,1fr)">
				<label class="fld" style="margin:0"><span>Nom de la règle</span><input name="libelle" required maxlength="120" value="<?= e( $fkcF( 'libelle' ) ) ?>" placeholder="Loyer du siège"></label>
				<label class="fld" style="margin:0"><span>Priorité</span><input type="number" name="priorite" min="0" max="999" value="<?= e( $fkcF( 'priorite', '10' ) ) ?>"></label>
			</div>
			<fieldset style="border:1px dashed var(--line);border-radius:10px;padding:10px 12px;margin:0">
				<legend class="muted" style="padding:0 6px">Quand… (au moins un critère — tous doivent correspondre)</legend>
				<div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
					<label class="fld" style="margin:0"><span>Compte commence par</span><input name="compte_prefixe" inputmode="numeric" pattern="[678][0-9]*" maxlength="10" value="<?= e( $fkcF( 'compte_prefixe' ) ) ?>" placeholder="622"></label>
					<label class="fld" style="margin:0"><span>Journal</span><select name="journal_id"><option value="">— tous —</option><?php foreach ( $journaux as $jr ) : ?><option value="<?= (int) $jr['id'] ?>" <?= $fkcF( 'journal_id' ) === (string) $jr['id'] ? 'selected' : '' ?>><?= e( $jr['code'] . ' · ' . $jr['libelle'] ) ?></option><?php endforeach; ?></select></label>
					<label class="fld" style="margin:0"><span>Tiers de l'écriture</span><select name="tiers"><option value="">— tous —</option>
						<?php foreach ( array( 'fournisseur' => 'Fournisseurs', 'client' => 'Clients' ) as $t => $lib ) : if ( empty( $tiers[ $t ] ) ) { continue; } ?>
							<optgroup label="<?= e( $lib ) ?>"><?php foreach ( $tiers[ $t ] as $k => $nom ) : ?><option value="<?= e( $k ) ?>" <?= $fkcF( 'tiers' ) === $k ? 'selected' : '' ?>><?= e( $nom ) ?></option><?php endforeach; ?></optgroup>
						<?php endforeach; ?></select></label>
					<label class="fld" style="margin:0"><span>Libellé contient</span><input name="libelle_contient" maxlength="80" value="<?= e( $fkcF( 'libelle_contient' ) ) ?>" placeholder="CIE, SODECI, loyer…"></label>
				</div>
			</fieldset>
			<fieldset style="border:1px dashed var(--line);border-radius:10px;padding:10px 12px;margin:0">
				<legend class="muted" style="padding:0 6px">…alors imputer</legend>
				<div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
					<label class="fld" style="margin:0"><span>Axe</span><select name="axe_id" id="fkc-rg-axe"><?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $a['id'] === $fkcAxe ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?></select></label>
					<?php if ( $fkcAvecCles ) : ?>
					<div class="fld" style="margin:0"><span>Mode</span>
						<div style="display:flex;gap:14px;align-items:center;min-height:38px">
							<label style="display:flex;gap:6px;align-items:center;margin:0"><input type="radio" name="mode" value="valeur" style="width:auto;margin:0" <?= 'valeur' === $fkcMode ? 'checked' : '' ?>> une valeur</label>
							<label style="display:flex;gap:6px;align-items:center;margin:0"><input type="radio" name="mode" value="cle" style="width:auto;margin:0" <?= 'cle' === $fkcMode ? 'checked' : '' ?>> une clé de répartition</label>
						</div>
					</div>
					<?php else : ?><input type="hidden" name="mode" value="valeur"><?php endif; ?>
					<?php foreach ( $axes as $a ) : $aid = (int) $a['id']; ?>
						<label class="fld fkc-rg-val" data-axe="<?= $aid ?>" style="margin:0"><span>Valeur</span><select name="valeur[<?= $aid ?>]"><option value="">—</option><?php foreach ( ( $valeurs[ $aid ] ?? array() ) as $vid => $lib ) : ?><option value="<?= (int) $vid ?>"><?= e( $lib ) ?></option><?php endforeach; ?></select></label>
						<?php if ( $fkcAvecCles ) : ?>
						<label class="fld fkc-rg-cle" data-axe="<?= $aid ?>" style="margin:0"><span>Clé de répartition</span><select name="cle[<?= $aid ?>]"><option value="">—</option><?php foreach ( ( $cles[ $aid ] ?? array() ) as $cid => $lib ) : ?><option value="<?= (int) $cid ?>"><?= e( $lib ) ?></option><?php endforeach; ?></select>
							<?php if ( empty( $cles[ $aid ] ) ) : ?><small class="muted">Aucune clé ne ventile cet axe.</small><?php endif; ?></label>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			</fieldset>
			<div class="actions" style="margin:0"><button class="btn btn-primary" type="submit">Créer la règle</button></div>
		</form>
	</div>
</div>
<p class="help">Les écritures de clôture et les contre-passations ne sont jamais touchées (une contre-passation reprend l'imputation de la ligne qu'elle annule). Supprimer une règle ne défait pas ce qu'elle a imputé. Chaque création, suspension, suppression et chaque rattrapage est tracé au journal d'audit.</p>
<script>
(function () {
	var axe = document.getElementById('fkc-rg-axe'); if (!axe) { return; }
	function maj() {
		var a = axe.value, m = document.querySelector('input[name="mode"]:checked'), mode = m ? m.value : 'valeur';
		document.querySelectorAll('.fkc-rg-val').forEach(function (el) { el.style.display = el.dataset.axe === a && mode === 'valeur' ? '' : 'none'; });
		document.querySelectorAll('.fkc-rg-cle').forEach(function (el) { el.style.display = el.dataset.axe === a && mode === 'cle' ? '' : 'none'; });
	}
	axe.addEventListener('change', maj);
	document.querySelectorAll('input[name="mode"]').forEach(function (r) { r.addEventListener('change', maj); });
	maj();
}());
</script>
