<?php /** @var string $annee @var array $annees @var array $axes @var int $axeId @var array $res @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$t = $res['totaux']; $ni = $res['non_affecte'];
$fkcDet = function ( $valeur ) use ( $axeId, $annee ) { return url( 'analytique/detail?axe=' . (int) $axeId . '&valeur=' . (int) $valeur . '&annee=' . $annee ); };
$fkcHao = abs( (float) ( $t['hao'] ?? 0 ) ) >= 0.5; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'resultats_ana' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<?php
/*
 * BARRE DE SÉLECTION (refondue en 1.773.0).
 *
 * Les axes étaient rendus en boutons, tous, sur une seule rangée qui
 * débordait : avec vingt-cinq axes — ce que produit l'édition Creative —
 * la liste occupait trois lignes et repoussait le sélecteur d'exercice hors
 * de l'écran. Le choix de l'année devenait littéralement introuvable.
 *
 * L'axe et l'exercice passent en tête, dans deux listes déroulantes toujours
 * visibles. Les boutons restent, en accès rapide, mais dans un bloc que l'on
 * déplie — et qui ne pousse plus personne dehors.
 */
$axeCourant = null;
foreach ( $axes as $a ) { if ( (int) $axeId === (int) $a['id'] ) { $axeCourant = $a; } }
$nbAxes = count( $axes );
?>
<div class="ana-bar">
	<form method="get" class="ana-form">
		<label class="fld"><span>Axe analytique</span>
			<select name="axe" onchange="this.form.submit()">
				<?php foreach ( $axes as $a ) : ?>
					<option value="<?= (int) $a['id'] ?>" <?= (int) $axeId === (int) $a['id'] ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option>
				<?php endforeach; ?>
			</select></label>
		<label class="fld"><span>Exercice</span>
			<select name="annee" onchange="this.form.submit()">
				<?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y === $annee ? 'selected' : '' ?>><?= e( $y ) ?></option><?php endforeach; ?>
			</select></label>
		<noscript><button class="btn btn-ghost btn-sm" type="submit">Afficher</button></noscript>
	</form>
	<div class="ana-resume">
		<span class="muted">Résultat <?= e( $annee ) ?></span>
		<strong style="color:<?= $t['resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= e( fkc_money( $t['resultat'] ) ) ?></strong>
		<span class="muted"><?= (int) count( $res['lignes'] ) ?> valeur(s) sur <?= e( $axeCourant['libelle'] ?? '—' ) ?></span>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/export?axe=' . (int) $axeId . '&annee=' . $annee ) ) ?>">⬇ Exporter (CSV)</a>
	</div>
</div>
<details class="ana-axes"<?= $nbAxes <= 8 ? ' open' : '' ?>>
	<summary>Accès rapide aux <?= (int) $nbAxes ?> axes</summary>
	<div class="ana-axes-liste">
		<?php foreach ( $axes as $a ) : ?>
			<a class="btn btn-sm <?= (int) $axeId === (int) $a['id'] ? 'btn-primary' : 'btn-ghost' ?>"
				href="<?= e( url( 'analytique/resultats-analytiques?axe=' . (int) $a['id'] . '&annee=' . $annee ) ) ?>"><?= e( $a['libelle'] ) ?></a>
		<?php endforeach; ?>
	</div>
</details>
<style>
.ana-bar{display:flex;flex-wrap:wrap;gap:16px;align-items:flex-end;justify-content:space-between;margin-bottom:12px}
/*
 * ═══════════════════════════════════════════════════════════════════════
 *  AXE ET EXERCICE SUR LA MÊME LIGNE
 * ═══════════════════════════════════════════════════════════════════════
 *  La barre était déjà en `flex`, et pourtant les deux listes s'empilaient.
 *  La cause n'est pas dans le `flex` mais dans les éléments : un `.fld` est
 *  un bloc sans base de flexibilité, dont la largeur naturelle vaut celle
 *  de l'option la plus longue du `select`. Avec vingt-cinq axes, il suffit
 *  d'un intitulé comme « Centre de coût / Département » pour que le premier
 *  champ réclame plusieurs centaines de pixels — et comme rien ne
 *  l'autorisait à rétrécir (`min-width` par défaut = `auto` sur un élément
 *  flex), le second passait à la ligne.
 *
 *  D'où la grille : deux colonnes déclarées, et surtout `min-width:0`, qui
 *  autorise enfin un champ à devenir plus étroit que son contenu. L'axe
 *  prend la place disponible, l'exercice se contente de la sienne — une
 *  année tient en cinq caractères.
 * ═══════════════════════════════════════════════════════════════════════
 */
.ana-form{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,150px);
  gap:12px;align-items:end;margin:0;flex:1 1 420px;max-width:620px}
.ana-form .fld{margin:0;min-width:0}
.ana-form select{width:100%;max-width:100%}
/* Le bouton de repli sans JavaScript ne doit pas casser la grille. */
.ana-form noscript{grid-column:1/-1}
.ana-resume{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap;font-size:14px}
.ana-axes{margin-bottom:16px}
.ana-axes>summary{cursor:pointer;color:var(--muted);font-size:13px;padding:4px 0;list-style:none}
.ana-axes>summary::-webkit-details-marker{display:none}
.ana-axes>summary::before{content:'▸ ';}
.ana-axes[open]>summary::before{content:'▾ ';}
.ana-axes-liste{display:flex;flex-wrap:wrap;gap:6px;padding:8px 0 0}
/*
 * Sous 520 px, deux colonnes ne laissent plus assez de place au libellé de
 * l'axe : on empile, mais c'est alors un choix, pas un débordement subi.
 */
@media(max-width:520px){.ana-form{grid-template-columns:1fr}}
</style>
<?php
/*
 * RÉPARTITION SECONDAIRE.
 *
 * Quand des sections auxiliaires sont déclarées, deux colonnes s'ajoutent :
 * les charges PROPRES (celles que porte la balance générale) et le
 * déversement. Sans elles, on lirait un chiffre de charges introuvable au
 * grand livre, sans aucun moyen de le rapprocher — et la première question
 * posée serait « d'où sort ce montant ? ».
 */
$rep = $res['repartition'] ?? array( 'active' => false );
$ctl = ! empty( $rep['active'] ) && class_exists( 'FKC_AnaAuxiliaire' ) ? FKC_AnaAuxiliaire::controle( $res ) : null;
?>
<?php if ( ! empty( $rep['active'] ) ) : ?>
	<div class="alert alert-ok" style="margin-bottom:12px">
		↔️ <strong>Répartition secondaire appliquée.</strong>
		<?php foreach ( $rep['sections'] as $sx ) : ?>
			<?= e( $sx['libelle'] ) ?> déverse <?= e( fkc_money( $sx['deverse'] ) ) ?> F
			<?= $sx['reste'] > 0.5 ? '(reste ' . e( fkc_money( $sx['reste'] ) ) . ' F chez elle)' : '' ?><br>
		<?php endforeach; ?>
		<?php /* Le contrôle est affiché : une répartition qu'on ne peut pas vérifier ne mérite pas qu'on s'y fie. */ ?>
		<span class="muted" style="font-size:12px">Total des charges inchangé : <?= e( fkc_money( $ctl['avant'] ) ) ?> F avant, <?= e( fkc_money( $ctl['apres'] ) ) ?> F après<?= $ctl['ok'] ? ' ✓' : ' — ⚠️ écart de ' . e( fkc_money( $ctl['ecart'] ) ) . ' F' ?>. La comptabilité générale n'est pas modifiée.</span>
		<?php if ( ! empty( $rep['incompletes'] ) ) : ?>
			<br><span style="color:var(--warn)">⚠️ Clé incomplète pour : <?= e( implode( ', ', $rep['incompletes'] ) ) ?> — la part non répartie reste sur la section.</span>
		<?php endif; ?>
	</div>
<?php endif; ?>
<div class="card card-flush" style="overflow-x:auto"><table class="table">
	<thead><tr><th>Code</th><th>Valeur</th><th class="num">Produits</th>
		<?php if ( ! empty( $rep['active'] ) ) : ?><th class="num">Charges propres</th><th class="num">Déversement</th><?php endif; ?>
		<th class="num">Charges<?= ! empty( $rep['active'] ) ? ' après' : '' ?></th><th class="num">Résultat</th><th class="num">Marge</th><?php if ( $fkcHao ) : ?><th class="num">HAO</th><th class="num">Résultat net</th><?php endif; ?></tr></thead>
	<tbody>
	<?php $nc = ( ! empty( $rep['active'] ) ? 8 : 6 ) + ( $fkcHao ? 2 : 0 ); ?>
	<?php if ( ! $res['lignes'] ) : ?><tr><td colspan="<?= (int) $nc ?>" class="empty">Aucune donnée affectée sur cet axe. Renseignez les <a href="<?= e( url( 'analytique/affectations?annee=' . $annee ) ) ?>">affectations</a>.</td></tr>
	<?php else : foreach ( $res['lignes'] as $l ) : $m = $l['produits'] > 0 ? round( $l['resultat'] / $l['produits'] * 100, 1 ) : null; ?>
		<tr><td class="code"><?= e( $l['code'] ) ?><?= ! empty( $l['auxiliaire'] ) ? ' <span class="muted" title="Section auxiliaire">↔</span>' : '' ?></td><td><a href="<?= e( $fkcDet( $l['valeur_id'] ?? 0 ) ) ?>" title="Voir les écritures">🔎 <?= e( $l['libelle'] ) ?></a></td>
			<td class="num"><?= e( fkc_money( $l['produits'] ) ) ?></td>
			<?php if ( ! empty( $rep['active'] ) ) : ?>
				<td class="num muted"><?= e( fkc_money( $l['charges_propres'] ?? $l['charges'] ) ) ?></td>
				<td class="num" style="font-size:12px">
					<?php $dv = (float) ( $l['charges_deversees'] ?? 0 ); $rc = (float) ( $l['charges_recues'] ?? 0 ); ?>
					<?php if ( $dv > 0.5 ) : ?><span style="color:var(--ok)">− <?= e( fkc_money( $dv ) ) ?></span>
					<?php elseif ( $rc > 0.5 ) : ?><span style="color:var(--warn)">+ <?= e( fkc_money( $rc ) ) ?></span>
					<?php else : ?><span class="muted">—</span><?php endif; ?>
				</td>
			<?php endif; ?>
			<td class="num"><?= e( fkc_money( $l['charges'] ) ) ?></td>
			<td class="num" style="color:<?= $l['resultat']>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $l['resultat'] ) ) ?></td>
			<td class="num"><?= null===$m?'—':e( $m ).' %' ?></td>
			<?php if ( $fkcHao ) : ?><td class="num"><?= e( fkc_money( $l['hao'] ?? 0 ) ) ?></td><td class="num"><?= e( fkc_money( $l['resultat_net'] ?? $l['resultat'] ) ) ?></td><?php endif; ?></tr>
	<?php endforeach; endif; ?>
	<?php if ( $ni && ( abs( $ni['produits'] ) > 0 || abs( $ni['charges'] ) > 0 || abs( (float) ( $ni['hao'] ?? 0 ) ) > 0 ) ) : ?>
		<tr><td class="code">—</td><td class="muted"><a href="<?= e( $fkcDet( 0 ) ) ?>" title="Voir les écritures">🔎 Non affecté</a></td><td class="num muted"><?= e( fkc_money( $ni['produits'] ) ) ?></td><?php if ( ! empty( $rep['active'] ) ) : ?><td class="num muted"><?= e( fkc_money( $ni['charges'] ) ) ?></td><td class="num muted">—</td><?php endif; ?><td class="num muted"><?= e( fkc_money( $ni['charges'] ) ) ?></td><td class="num muted"><?= e( fkc_money( $ni['resultat'] ) ) ?></td><td></td><?php if ( $fkcHao ) : ?><td class="num muted"><?= e( fkc_money( $ni['hao'] ?? 0 ) ) ?></td><td class="num muted"><?= e( fkc_money( $ni['resultat_net'] ?? $ni['resultat'] ) ) ?></td><?php endif; ?></tr>
	<?php endif; ?>
	</tbody>
	<tfoot><tr class="total"><td></td><td class="right">Total</td><td class="num"><?= e( fkc_money( $t['produits'] ) ) ?></td><?php if ( ! empty( $rep['active'] ) ) : ?><td class="num"><?= e( fkc_money( $t['charges'] ) ) ?></td><td class="num muted">0</td><?php endif; ?><td class="num"><?= e( fkc_money( $t['charges'] ) ) ?></td><td class="num"><?= e( fkc_money( $t['resultat'] ) ) ?></td><td></td><?php if ( $fkcHao ) : ?><td class="num"><?= e( fkc_money( $t['hao'] ) ) ?></td><td class="num"><?= e( fkc_money( $t['resultat_net'] ) ) ?></td><?php endif; ?></tr></tfoot>
</table></div>
