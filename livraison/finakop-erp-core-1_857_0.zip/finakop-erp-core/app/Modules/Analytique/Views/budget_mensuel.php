<?php
/**
 * ANALYTIQUE → BUDGET MENSUEL PAR NATURE — SAISIE (1.831.0).
 *
 * @var string $annee @var array $annees @var array $sections [id => libellé] @var int $div
 * @var array $natures @var array $mois [1..12 => AAAA-MM] @var array $budget [nature => [mois => montant]]
 * @var array $reelN1 @var array $saison @var bool $fige @var array|null $annuel @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$prec = (string) ( (int) $annee - 1 );
$groupes = array( 'charge' => 'Charges (classe 6)', 'produit' => 'Produits (classe 7)' );
$tot = FKC_BudgetMensuel::totaux( $budget );
$fkcN = function ( $v ) { return $v ? (string) round( $v ) : ''; };
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'budgets' ) ); ?>
<?php if ( $flash ) : ?><div class="alert <?= 0 === strpos( (string) $flash, 'Refusé' ) ? 'alert-err' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>

<form method="get" action="<?= e( url( 'analytique/budget-mensuel' ) ) ?>" class="bm-barre">
	<label class="fld"><span>Section</span><select name="section" onchange="this.form.submit()"><?php foreach ( $sections as $id => $lib ) : ?><option value="<?= (int) $id ?>" <?= (int) $id === $div ? 'selected' : '' ?>><?= e( $lib ) ?></option><?php endforeach; ?></select></label>
	<label class="fld"><span>Exercice</span><select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= (string) $y === (string) $annee ? 'selected' : '' ?>><?= e( FKC_Exercice::libelle( $y ) ) ?></option><?php endforeach; ?></select></label>
	<noscript><button class="btn btn-ghost btn-sm" type="submit">Afficher</button></noscript>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/budget-mensuel/suivi?annee=' . $annee . '&section=' . $div ) ) ?>">📊 Suivi budget / réalisé →</a>
</form>

<div class="stats kpi">
	<div class="stat kpi-neg"><span class="stat-label">Charges budgétées</span><span class="stat-value" id="bm-k-ch"><?= e( fkc_money( $tot['charges'] ) ) ?><small> F CFA</small></span></div>
	<div class="stat kpi-ca"><span class="stat-label">Produits budgétés</span><span class="stat-value" id="bm-k-pr"><?= e( fkc_money( $tot['produits'] ) ) ?><small> F CFA</small></span></div>
	<div class="stat <?= $tot['produits'] - $tot['charges'] >= 0 ? 'kpi-pos' : 'kpi-neg' ?>"><span class="stat-label">Résultat d'exploitation budgété</span><span class="stat-value" id="bm-k-re"><?= e( fkc_money( $tot['produits'] - $tot['charges'] ) ) ?><small> F CFA</small></span></div>
</div>

<?php if ( $annuel ) : $ecartA = abs( (float) $annuel['budget_charges'] - $tot['charges'] ) + abs( (float) $annuel['budget_produits'] - $tot['produits'] ); ?>
	<p class="help" style="<?= $ecartA >= 1 ? 'color:var(--orange)' : '' ?>">Budget annuel saisi pour cette division : charges <?= e( fkc_money( $annuel['budget_charges'] ) ) ?> F, produits <?= e( fkc_money( $annuel['budget_produits'] ) ) ?> F<?= $ecartA >= 1 ? ' — différent du détail mensuel ci-dessous. Le bouton « Reporter dans le budget annuel » aligne les deux.' : ' — identique au détail mensuel ✓' ?></p>
<?php endif; ?>

<?php if ( $fige ) : ?>
	<div class="alert alert-err">🔒 L'exercice <?= e( $annee ) ?> est clôturé : son budget est figé (lecture seule).</div>
<?php else : ?>
<div class="bm-outils">
	<form method="post" action="<?= e( url( 'analytique/budget-mensuel' ) ) ?>" onsubmit="return confirm('Remplacer tout le budget de cette section par le réalisé <?= e( $prec ) ?> ?')">
		<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>"><input type="hidden" name="section" value="<?= (int) $div ?>"><input type="hidden" name="action" value="copier_n1">
		<span class="muted">Partir du réalisé <?= e( $prec ) ?></span>
		<input type="number" name="pct" value="0" step="0.5" style="width:80px;text-align:right" aria-label="Ajustement en pourcentage"> <span class="muted">%</span>
		<button class="btn btn-ghost btn-sm" type="submit"<?= $reelN1 ? '' : ' disabled title="Aucun réalisé sur ' . e( $prec ) . '"' ?>>Reprendre</button>
	</form>
	<?php if ( $div && $budget ) : ?>
	<form method="post" action="<?= e( url( 'analytique/budget-mensuel' ) ) ?>">
		<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>"><input type="hidden" name="section" value="<?= (int) $div ?>"><input type="hidden" name="action" value="reporter">
		<button class="btn btn-ghost btn-sm" type="submit" title="Met à jour le budget annuel de la division (contrôle budgétaire, budgets comparatifs)">Reporter dans le budget annuel</button>
	</form>
	<?php endif; ?>
</div>
<?php endif; ?>

<form method="post" action="<?= e( url( 'analytique/budget-mensuel' ) ) ?>" id="bm-form">
	<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>"><input type="hidden" name="section" value="<?= (int) $div ?>"><input type="hidden" name="action" value="enregistrer">
	<div class="card card-flush bm-wrap"><table class="table bm">
		<thead><tr>
			<th class="bm-nat">Nature</th>
			<?php foreach ( $mois as $i => $m ) : ?><th class="num"><?= e( FKC_BudgetMensuel::libMois( $m ) ) ?></th><?php endforeach; ?>
			<th class="num">Total</th>
			<?php if ( ! $fige ) : ?><th>Répartir un total annuel</th><?php endif; ?>
		</tr></thead>
		<?php foreach ( $groupes as $sens => $titre ) : ?>
		<tbody data-sens="<?= e( $sens ) ?>">
			<tr class="bm-groupe"><th colspan="<?= $fige ? 14 : 15 ?>"><span><?= e( $titre ) ?></span></th></tr>
			<?php foreach ( $natures as $k => $n ) : if ( $n['sens'] !== $sens ) { continue; } $b = $budget[ $k ] ?? array(); $n1 = array_sum( $reelN1[ $k ] ?? array() ); ?>
			<tr data-nat="<?= e( $k ) ?>">
				<th class="bm-nat"><span class="code"><?= e( $k ) ?></span> <?= e( $n['libelle'] ) ?><?php if ( abs( $n1 ) >= 1 ) : ?><br><small class="muted"><?= e( $prec ) ?> : <?= e( fkc_money( $n1 ) ) ?></small><?php endif; ?></th>
				<?php for ( $i = 1; $i <= 12; $i++ ) : ?>
					<td class="num"><input type="number" name="b[<?= e( $k ) ?>][<?= $i ?>]" value="<?= e( $fkcN( $b[ $i ] ?? 0 ) ) ?>" min="0" step="1" inputmode="numeric" aria-label="<?= e( $n['libelle'] . ' — ' . FKC_BudgetMensuel::libMois( $mois[ $i ] ) ) ?>"<?= $fige ? ' disabled' : '' ?>></td>
				<?php endfor; ?>
				<td class="num bm-tot"><strong><?= e( fkc_money( array_sum( $b ) ) ) ?></strong></td>
				<?php if ( ! $fige ) : ?>
				<td class="bm-rep" style="white-space:nowrap">
					<input type="number" class="bm-annuel" min="0" step="1" placeholder="Total" aria-label="Total annuel à répartir">
					<button type="button" class="btn btn-ghost btn-sm bm-egal" title="Douze parts égales">÷12</button>
					<?php if ( ! empty( $saison[ $k ] ) ) : ?><button type="button" class="btn btn-ghost btn-sm bm-saison" data-poids="<?= e( json_encode( array_values( $saison[ $k ] ) ) ) ?>" title="Selon la saisonnalité du réalisé <?= e( $prec ) ?>">comme <?= e( $prec ) ?></button><?php endif; ?>
				</td>
				<?php endif; ?>
			</tr>
			<?php endforeach; ?>
			<tr class="bm-sous"><th class="bm-nat">Total <?= 'charge' === $sens ? 'charges' : 'produits' ?></th><?php for ( $i = 1; $i <= 12; $i++ ) : ?><td class="num" data-col="<?= $i ?>">—</td><?php endfor; ?><td class="num" data-col="t">—</td><?php if ( ! $fige ) : ?><td></td><?php endif; ?></tr>
		</tbody>
		<?php endforeach; ?>
		<tfoot><tr class="total" id="bm-res"><th class="bm-nat">Résultat d'exploitation</th><?php for ( $i = 1; $i <= 12; $i++ ) : ?><td class="num" data-col="<?= $i ?>">—</td><?php endfor; ?><td class="num" data-col="t">—</td><?php if ( ! $fige ) : ?><td></td><?php endif; ?></tr></tfoot>
	</table></div>
	<?php if ( ! $fige ) : ?><div class="actions"><button class="btn btn-primary" type="submit">Enregistrer le budget</button> <span class="muted" id="bm-modif" aria-live="polite"></span></div><?php endif; ?>
	<input type="hidden" name="_fin" value="1">
</form>
<p class="help">Montants en F CFA, en positif : le sens vient de la nature (une charge se budgète comme une charge). Les natures sont les comptes à deux chiffres du plan SYSCOHADA ; les mois suivent l'exercice<?= FKC_Exercice::estCalendaire() ? '' : ' (décalé)' ?>. Les opérations hors activités ordinaires (classe 8) ne se budgètent pas au mois.</p>

<script>
(function () {
	var form = document.getElementById('bm-form'); if (!form) { return; }
	var fmt = function (n) { return Math.round(n).toLocaleString('fr-FR').replace(/ /g, ' '); };
	var num = function (el) { return parseFloat(String(el.value || '0').replace(',', '.')) || 0; };
	var modif = false;
	function calc() {
		var col = { charge: [], produit: [] };
		['charge', 'produit'].forEach(function (s) { for (var i = 0; i <= 12; i++) { col[s][i] = 0; } });
		form.querySelectorAll('tbody[data-sens]').forEach(function (tb) {
			var s = tb.dataset.sens;
			tb.querySelectorAll('tr[data-nat]').forEach(function (tr) {
				var t = 0;
				tr.querySelectorAll('input[name^="b["]').forEach(function (inp, i) { var v = num(inp); t += v; col[s][i + 1] += v; });
				col[s][0] += t;
				tr.querySelector('.bm-tot strong').textContent = fmt(t);
			});
			var sous = tb.querySelector('.bm-sous');
			for (var i = 1; i <= 12; i++) { sous.querySelector('[data-col="' + i + '"]').textContent = fmt(col[s][i]); }
			sous.querySelector('[data-col="t"]').textContent = fmt(col[s][0]);
		});
		var res = document.getElementById('bm-res');
		for (var i = 1; i <= 12; i++) { var r = col.produit[i] - col.charge[i], c = res.querySelector('[data-col="' + i + '"]'); c.textContent = fmt(r); c.style.color = r < 0 ? 'var(--danger)' : ''; }
		var rt = col.produit[0] - col.charge[0], ct = res.querySelector('[data-col="t"]'); ct.textContent = fmt(rt); ct.style.color = rt < 0 ? 'var(--danger)' : '';
		var k = function (id, v) { var el = document.getElementById(id); if (el) { el.firstChild.nodeValue = fmt(v); } };
		k('bm-k-ch', col.charge[0]); k('bm-k-pr', col.produit[0]); k('bm-k-re', rt);
	}
	/* Répartit un total en montants entiers : le reliquat d'arrondi va au dernier mois non nul. */
	function repartir(tr, poids) {
		var total = Math.round(num(tr.querySelector('.bm-annuel'))); if (!total) { return; }
		var inputs = tr.querySelectorAll('input[name^="b["]'), cumul = 0, dernier = -1;
		poids.forEach(function (p, i) { if (p > 0) { dernier = i; } });
		inputs.forEach(function (inp, i) {
			var v = i === dernier ? total - cumul : Math.round(total * (poids[i] || 0));
			if (i > dernier) { v = 0; }
			inp.value = v || ''; cumul += v;
		});
		modif = true; calc(); maj();
	}
	form.addEventListener('click', function (e) {
		var b = e.target.closest('.bm-egal, .bm-saison'); if (!b) { return; }
		var poids = b.classList.contains('bm-egal') ? Array(12).fill(1 / 12) : JSON.parse(b.dataset.poids || '[]');
		repartir(b.closest('tr'), poids);
	});
	form.addEventListener('input', function (e) { if (e.target.name && e.target.name.indexOf('b[') === 0) { modif = true; calc(); maj(); } });
	function maj() { var m = document.getElementById('bm-modif'); if (m) { m.textContent = modif ? 'Modifications non enregistrées' : ''; } }
	var envoi = false; form.addEventListener('submit', function () { envoi = true; });
	window.addEventListener('beforeunload', function (e) { if (modif && !envoi) { e.preventDefault(); e.returnValue = ''; } });
	calc();
}());
</script>
<style>
.bm-barre{display:flex!important;flex-wrap:wrap;gap:10px;align-items:end;margin:0 0 14px}
.bm-barre .fld{margin:0;min-width:0;flex:0 1 260px}
.bm-barre select{width:100%}
.bm-outils{display:flex;flex-wrap:wrap;gap:14px;align-items:center;margin:0 0 12px}
.bm-outils form{display:flex!important;gap:6px;align-items:center;flex-wrap:wrap;margin:0}
.bm-wrap{overflow:auto;max-height:78vh}
.bm{border-collapse:separate;border-spacing:0}
.bm th,.bm td{white-space:nowrap;padding:6px 6px}
.bm thead th{position:sticky;top:0;z-index:2;background:var(--panel)}
.bm .bm-nat{position:sticky;left:0;z-index:1;background:var(--panel);text-align:left;min-width:190px;max-width:240px;white-space:normal;font-weight:600}
.bm thead .bm-nat{z-index:3}
.bm tbody .bm-nat{text-transform:none;letter-spacing:0;font-size:13px;color:var(--text)}
.bm td input{width:92px;text-align:right;padding:6px 6px}
.bm .bm-annuel{width:110px}
.bm .bm-groupe th{text-align:left;background:var(--panel2);color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.4px}
.bm .bm-groupe th span{position:sticky;left:8px} /* la cellule couvre toute la largeur : c'est le libellé qui reste visible */
.bm .bm-sous td,.bm .bm-sous th{font-weight:700;border-top:1px solid var(--line2)}
@media(max-width:520px){.bm .bm-nat{min-width:130px}}
</style>
