<?php /** @var string $annee @var array $annees @var array $lignes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$tot = 0.0; foreach ( $lignes as $l ) { $tot += $l['charges']; }
$max = 1; foreach ( $lignes as $l ) { $max = max( $max, $l['charges'] ); } ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'centres_couts' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Charges réelles par centre de coût — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th>Centre de coût</th><th class="num">Charges</th><th>Poids</th></tr></thead>
	<tbody>
	<?php if ( ! $lignes ) : ?><tr><td colspan="4" class="empty">Aucun centre de coût. Classez vos divisions en « Centre de coût » dans l'onglet Divisions.</td></tr>
	<?php else : foreach ( $lignes as $l ) : ?>
		<tr>
			<td class="code"><?= e( $l['code'] ) ?></td>
			<td><a href="<?= e( url( 'analytique?annee=' . $annee ) ) ?>"><?= e( $l['libelle'] ) ?></a></td>
			<td class="num"><?= e( fkc_money( $l['charges'] ) ) ?></td>
			<td><div style="background:rgba(255,255,255,.05);border-radius:6px;height:14px;width:160px"><div style="height:100%;width:<?= round( $l['charges'] / $max * 100 ) ?>%;background:var(--orange);border-radius:6px"></div></div></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $lignes ) : ?><tfoot><tr class="total"><td></td><td class="right">Total charges</td><td class="num"><?= e( fkc_money( $tot ) ) ?></td><td></td></tr></tfoot><?php endif; ?>
</table></div>
