<?php
/**
 * ANALYTIQUE → DÉTAIL D'UN MONTANT (1.825.0).
 *
 * @var array $axe @var int $valeur @var string $annee @var array $annees @var array $opts
 * @var array $d (voir FKC_AnaDetail::lignes) @var bool $aux @var mixed $flash
 * @var array|null $axe2 @var int $valeur2 case d'un tableau croisé (1.826.0)
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcDiv = 'DIV' === $axe['code'];
$axe2 = $axe2 ?? null; $valeur2 = (int) ( $valeur2 ?? 0 );
$fkcQ = function ( array $extra = array() ) use ( $axe, $valeur, $annee, $opts, $axe2, $valeur2 ) {
	$q = array_merge( array( 'axe' => $axe['id'], 'valeur' => $valeur, 'annee' => $annee ), $axe2 ? array( 'axe2' => $axe2['id'], 'valeur2' => $valeur2 ) : array(), $opts, $extra );
	return http_build_query( array_filter( $q, function ( $v ) { return '' !== (string) $v; } ) );
};
$fkcRetour = $axe2 ? 'analytique/croise?x=' . (int) $axe['id'] . '&y=' . (int) $axe2['id'] . '&annee=' . $annee
	: ( $fkcDiv ? 'analytique?annee=' . $annee : 'analytique/resultats-analytiques?axe=' . (int) $axe['id'] . '&annee=' . $annee );
$t = $d['totaux'];
$fkcHao = abs( $t['hao'] ) >= 0.5;
$fkcPct = function ( $p ) { return rtrim( rtrim( number_format( (float) $p, 2, ',', '' ), '0' ), ',' ); };
// Mois de l'exercice, pour le filtre.
$fkcMois = array();
$b = FKC_Division::bornes( $annee );
if ( $b ) { for ( $c = substr( $b[0], 0, 7 ), $i = 0; $i < 12; $i++, $c = date( 'Y-m', strtotime( $c . '-01 +1 month' ) ) ) { $fkcMois[] = $c; } }
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'resultats' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<p style="margin:0 0 10px"><a href="<?= e( url( $fkcRetour ) ) ?>">← <?= $axe2 ? 'Tableau croisé' : ( $fkcDiv ? 'Résultat par division' : 'Résultats par axe' ) ?></a></p>

<div class="bar" style="flex-wrap:wrap;gap:10px">
	<div>
		<span class="stat-label"><?= e( $axe['libelle'] ) ?><?= $axe2 ? ' × ' . e( $axe2['libelle'] ) : '' ?> · exercice <?= e( $annee ) ?></span>
		<strong style="font-size:17px">🔎 <?= e( $d['valeur'] ) ?></strong>
	</div>
	<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
		<form method="get" action="<?= e( url( 'analytique/detail' ) ) ?>" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:0">
			<input type="hidden" name="axe" value="<?= (int) $axe['id'] ?>"><input type="hidden" name="valeur" value="<?= (int) $valeur ?>">
			<?php if ( ! empty( $opts['compte'] ) ) : ?><input type="hidden" name="compte" value="<?= e( $opts['compte'] ) ?>"><?php endif; ?>
			<?php if ( $axe2 ) : ?><input type="hidden" name="axe2" value="<?= (int) $axe2['id'] ?>"><input type="hidden" name="valeur2" value="<?= (int) $valeur2 ?>"><?php endif; ?>
			<select name="annee" onchange="this.form.submit()" aria-label="Exercice" style="width:auto;min-width:0"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= (string) $y === (string) $annee ? 'selected' : '' ?>><?= e( $y ) ?></option><?php endforeach; ?></select>
			<select name="nature" onchange="this.form.submit()" aria-label="Nature" style="width:auto;min-width:0"><option value="">Toutes natures</option><?php foreach ( FKC_AnaDetail::NATURES as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= ( $opts['nature'] ?? '' ) === $k ? 'selected' : '' ?>><?= e( $lib ) ?>s</option><?php endforeach; ?></select>
			<select name="mois" onchange="this.form.submit()" aria-label="Mois" style="width:auto;min-width:0"><option value="">Tout l'exercice</option><?php foreach ( $fkcMois as $m ) : ?><option value="<?= e( $m ) ?>" <?= ( $opts['mois'] ?? '' ) === $m ? 'selected' : '' ?>><?= e( substr( $m, 5, 2 ) . '/' . substr( $m, 0, 4 ) ) ?></option><?php endforeach; ?></select>
			<noscript><button class="btn btn-ghost btn-sm" type="submit">Filtrer</button></noscript>
		</form>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/detail/export?' . $fkcQ() ) ) ?>">⬇ Exporter (CSV)</a>
	</div>
</div>

<?php if ( ! empty( $opts['compte'] ) ) : ?>
	<p class="help" style="margin:0 0 10px">Filtré sur les comptes <strong><?= e( $opts['compte'] ) ?>…</strong> — <a href="<?= e( url( 'analytique/detail?' . $fkcQ( array( 'compte' => '' ) ) ) ) ?>">retirer ce filtre</a></p>
<?php endif; ?>
<div class="stats kpi">
	<div class="stat kpi-ca"><span class="stat-label">Produits</span><span class="stat-value"><?= e( fkc_money( $t['produits'] ) ) ?><small> F CFA</small></span></div>
	<div class="stat kpi-neg"><span class="stat-label">Charges</span><span class="stat-value"><?= e( fkc_money( $t['charges'] ) ) ?><small> F CFA</small></span></div>
	<?php if ( $fkcHao ) : ?><div class="stat"><span class="stat-label">HAO (cl. 8)</span><span class="stat-value"><?= e( fkc_money( $t['hao'] ) ) ?><small> F CFA</small></span></div><?php endif; ?>
	<div class="stat <?= ( $fkcHao ? $t['resultat_net'] : $t['resultat'] ) >= 0 ? 'kpi-pos' : 'kpi-neg' ?>"><span class="stat-label"><?= $fkcHao ? 'Résultat net' : 'Résultat' ?></span><span class="stat-value"><?= e( fkc_money( $fkcHao ? $t['resultat_net'] : $t['resultat'] ) ) ?><small> F CFA</small></span></div>
</div>
<?php if ( $aux ) : ?>
	<p class="help">↔️ Des sections auxiliaires sont actives sur cet axe : ce détail montre les montants <strong>propres</strong> de la valeur, avant déversement.</p>
<?php endif; ?>

<div class="card card-flush" style="overflow-x:auto"><table class="table">
	<thead><tr><th>Date</th><th>Pièce</th><th>Libellé</th><th>Compte</th><th class="num">Montant</th><th class="num">Part</th><th class="num">Imputé</th></tr></thead>
	<tbody>
	<?php if ( ! $d['lignes'] ) : ?><tr><td colspan="7" class="empty">Aucune ligne<?= $opts ? ' pour ces filtres' : '' ?> sur l'exercice <?= e( $annee ) ?>.</td></tr>
	<?php else : foreach ( $d['lignes'] as $l ) : ?>
		<tr>
			<td class="code"><?= e( date( 'd/m/Y', strtotime( $l['date_ecriture'] ) ) ) ?></td>
			<td class="code"><?= e( $l['piece'] ?: ( $l['ecriture_numero'] ?: '#' . $l['ecriture_id'] ) ) ?></td>
			<td><?= e( mb_strimwidth( (string) $l['libelle'], 0, 60, '…' ) ) ?></td>
			<td><span class="modbadge <?= 'produit' === $l['nature'] ? 'b-on' : '' ?>" style="font-size:.75em" title="<?= e( $l['compte_libelle'] ) ?>"><?= e( $l['numero'] ) ?></span></td>
			<td class="num"><?= e( fkc_money( $l['montant'] ) ) ?></td>
			<td class="num"><?= $l['part'] < 99.9999 ? '<span title="' . ( $l['repartition_id'] ? 'Ventilée par une clé' : ( $valeur ? 'Ventilée' : 'Part restée non imputée' ) ) . '">⚖️ ' . e( $fkcPct( $l['part'] ) ) . ' %</span>' : '100 %' ?></td>
			<td class="num"><strong><?= e( fkc_money( $l['impute'] ) ) ?></strong></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
<p class="help">
	<?= (int) $d['nb'] ?> ligne(s)<?= $d['tronque'] ? ' — les 500 plus récentes sont affichées ; l\'export CSV les contient toutes' : '' ?>.
	Montants signés : une charge compte en positif, un avoir ou une annulation en négatif. La somme de la colonne « Imputé » égale le montant affiché au résultat<?= $valeur ? '' : ' pour « ' . e( $d['valeur'] ) . ' »' ?>.
	<?php if ( ! $valeur ) : ?>Pour imputer ces lignes : <a href="<?= e( url( 'analytique/affectations?annee=' . $annee . '&restant=1' ) ) ?>">Affectations</a> ou <a href="<?= e( url( 'analytique/regles?annee=' . $annee ) ) ?>">Règles d'imputation</a>.<?php endif; ?>
</p>
