<?php /** @var array $repartitions @var array $types @var array $axes @var array|null $sel @var array|null $sim @var mixed $montant @var mixed $flash @var array $usage [rep => [total, figees]] */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'repartitions' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouvelle répartition</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'analytique/repartitions' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 2fr"><label class="fld"><span>Code</span><input name="code" maxlength="20" required style="text-transform:uppercase"></label>
			<label class="fld"><span>Libellé</span><input name="libelle" required></label></div>
			<div class="form-grid" style="grid-template-columns:1fr 1fr"><label class="fld"><span>Axe cible</span><select name="axe_id" required><?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['libelle'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $lbl ) : ?><option value="<?= e( $k ) ?>"><?= e( $lbl ) ?></option><?php endforeach; ?></select></label></div>
			<label class="fld"><span>Axe de base (si dynamique)</span><select name="base_axe_id"><option value="">—</option><?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['libelle'] ) ?></option><?php endforeach; ?></select></label>
			<div class="actions"><button class="btn btn-primary" type="submit">Créer</button></div>
		</form>
	</div></div>
	<div class="card"><div class="card-head"><h2>Répartitions</h2></div><div class="card-body">
		<?php if ( ! $repartitions ) : ?><p class="muted" style="margin:0">Aucune répartition.</p>
		<?php else : foreach ( $repartitions as $r ) : ?>
			<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--line)">
				<a href="<?= e( url( 'analytique/repartitions?rep=' . (int) $r['id'] ) ) ?>"><strong><?= e( $r['code'] ) ?></strong> · <?= e( $r['libelle'] ) ?> <span class="muted">(<?= e( $r['type'] ) ?>, <?= e( $r['axe_libelle'] ) ?>)</span><?php if ( ! empty( $usage[ (int) $r['id'] ]['total'] ) ) : ?> <span class="tag">⚖️ <?= (int) $usage[ (int) $r['id'] ]['total'] ?> ligne(s)</span><?php endif; ?></a>
				<form method="post" action="<?= e( url( 'analytique/repartitions/' . (int) $r['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">✕</button></form>
			</div>
		<?php endforeach; endif; ?>
	</div></div>
</div>

<?php if ( $sel ) : ?>
<div class="card"><div class="card-head"><h2>Clé · <?= e( $sel['libelle'] ) ?> <span class="muted">(<?= e( $sel['type'] ) ?>)</span></h2></div><div class="card-body">
	<?php $fkcU = $usage[ (int) $sel['id'] ] ?? array( 'total' => 0, 'figees' => 0 ); ?>
	<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px;padding:10px 12px;border:1px dashed var(--line);border-radius:10px">
		<?php if ( $fkcU['total'] ) : ?>
			<span>⚖️ Appliquée à <strong><?= (int) $fkcU['total'] ?></strong> ligne(s)<?= $fkcU['figees'] ? ' — dont ' . (int) $fkcU['figees'] . ' en exercice clôturé, figée(s)' : '' ?>.</span>
			<?php if ( $fkcU['total'] > $fkcU['figees'] ) : ?>
			<form method="post" action="<?= e( url( 'analytique/repartitions/' . (int) $sel['id'] . '/reappliquer' ) ) ?>" onsubmit="return confirm('Recalculer la ventilation des <?= (int) ( $fkcU['total'] - $fkcU['figees'] ) ?> ligne(s) avec la clé telle qu\'elle est aujourd\'hui ?')" style="margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">↻ Réappliquer la clé</button></form>
			<?php endif; ?>
			<span class="muted" style="font-size:12px;flex-basis:100%"><?= 'dynamique' === $sel['type'] ? 'Les poids d\'une clé dynamique bougent au fil de l\'exercice : réappliquez-la avant de lire les résultats (en fin de mois, par exemple).' : 'Après une modification des pourcentages, réappliquez la clé pour mettre à jour les lignes déjà ventilées.' ?></span>
		<?php else : ?>
			<span class="muted">Pas encore appliquée à des lignes existantes. Dans <a href="<?= e( url( 'analytique/affectations' ) ) ?>">Affectations</a>, cochez les lignes puis « Appliquer la clé ».</span>
		<?php endif; ?>
	</div>
	<?php if ( 'fixe' === $sel['type'] ) : ?>
		<form method="post" action="<?= e( url( 'analytique/repartitions/cle' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin-bottom:8px">
			<?= FKC_Csrf::field() ?><input type="hidden" name="repartition_id" value="<?= (int) $sel['id'] ?>">
			<label class="fld" style="margin:0;min-width:200px"><span>Valeur</span><select name="valeur_id" required><?php foreach ( FKC_Valeur::byAxe( $sel['axe_id'], true ) as $v ) : ?><option value="<?= (int) $v['id'] ?>"><?= e( $v['libelle'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld" style="margin:0"><span>%</span><input type="number" name="pourcentage" step="0.01" min="0" max="100" value="0" style="width:90px"></label>
			<button class="btn btn-ghost btn-sm" type="submit">Définir</button>
		</form>
		<table class="table"><thead><tr><th>Valeur</th><th class="num">%</th><th></th></tr></thead><tbody>
			<?php if ( ! $sel['cles'] ) : ?><tr><td colspan="3" class="empty">Aucune valeur déclarée dans cette clé.</td></tr><?php endif; ?>
			<?php $somme = 0; foreach ( $sel['cles'] as $cl ) : $somme += $cl['pourcentage']; $nulle = (float) $cl['pourcentage'] <= 0; ?>
			<tr>
				<td><?= e( $cl['libelle'] ) ?><?= $nulle ? ' <span class="muted" style="font-size:.82em">— déclarée, ne reçoit rien</span>' : '' ?></td>
				<td class="num"<?= $nulle ? ' style="color:var(--muted)"' : '' ?>><?= e( $cl['pourcentage'] ) ?> %</td>
				<td class="right">
					<form method="post" action="<?= e( url( 'analytique/repartitions/cle/retirer' ) ) ?>" style="display:inline" onsubmit="return confirm('Retirer « <?= e( $cl['libelle'] ) ?> » de cette clé ?\n\nPour la garder dans la clé sans rien lui attribuer, annulez et fixez sa part à 0 %.')">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="repartition_id" value="<?= (int) $sel['id'] ?>">
						<input type="hidden" name="valeur_id" value="<?= (int) $cl['valeur_id'] ?>">
						<button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)">Retirer</button>
					</form>
				</td>
			</tr>
			<?php endforeach; ?>
			<tr class="total"><td class="right">Total</td><td class="num" style="<?= abs( $somme - 100 ) > 0.01 ? 'color:var(--orange)' : '' ?>"><?= e( round( $somme, 2 ) ) ?> %</td><td></td></tr>
		</tbody></table>
		<p class="help" style="margin-top:6px">Une part à <strong>0 %</strong> est conservée et affichée : elle dit « cette section ne reçoit rien », ce qui est un arbitrage — à distinguer d'une valeur simplement absente de la clé, qui est un oubli. Pour sortir une valeur de la clé, utilisez « Retirer ».</p>
		<?php if ( abs( $somme - 100 ) > 0.01 ) : ?>
			<p class="help" style="color:var(--orange);margin-top:6px">Tant que le total ne fait pas exactement 100 %, cette clé <strong>n'est pas appliquée</strong> aux écritures : la ligne part non ventilée plutôt que de charger la dernière section de tout l'écart.</p>
		<?php endif; ?>
	<?php else : ?>
		<p class="help">Répartition dynamique : les pourcentages sont calculés d'après les poids réels (charges + produits) des valeurs de l'<strong>axe de base</strong> — c'est sur ces valeurs que la ligne est ventilée. Seules les imputations directes pèsent : une ligne déjà ventilée ne compte pas dans le calcul de sa propre clé.</p>
	<?php endif; ?>
	<form method="get" action="<?= e( url( 'analytique/repartitions' ) ) ?>" style="display:flex;gap:8px;align-items:end;margin-top:10px">
		<input type="hidden" name="rep" value="<?= (int) $sel['id'] ?>">
		<label class="fld" style="margin:0"><span>Simuler un montant</span><input type="number" name="montant" value="<?= e( $montant ) ?>" style="width:140px"></label>
		<button class="btn btn-primary btn-sm" type="submit">Simuler la ventilation</button>
	</form>
	<?php if ( is_array( $sim ) ) : ?>
		<?php if ( ! empty( $sim['message'] ) ) : ?>
			<div class="alert" style="margin-top:8px;border-left:3px solid var(--orange)"><?= e( $sim['message'] ) ?></div>
		<?php endif; ?>
		<table class="table" style="margin-top:8px"><thead><tr><th>Valeur</th><th class="num">%</th><th class="num">Montant</th></tr></thead><tbody>
			<?php if ( ! $sim['lignes'] ) : ?><tr><td colspan="3" class="empty">Aucune ventilation possible.</td></tr>
			<?php else : foreach ( $sim['lignes'] as $s ) : ?><tr><td><?= e( $s['libelle'] ) ?></td><td class="num"><?= e( $s['pourcentage'] ) ?> %</td><td class="num"><?= e( fkc_money( $s['montant'] ) ) ?></td></tr><?php endforeach; endif; ?>
			<?php if ( $sim['lignes'] ) : ?><tr class="total"><td class="right">Total ventilé</td><td class="num"><?= e( $sim['total_pct'] ) ?> %</td><td class="num"><?= e( fkc_money( $sim['ventile'] ) ) ?></td></tr><?php endif; ?>
		</tbody></table>
		<p class="help" style="margin-top:6px"><?= $sim['complete'] ? 'Clé applicable : cette ventilation sera appliquée automatiquement aux écritures qui la déclarent.' : 'Clé non applicable en l\'état : les écritures qui la déclarent ne seront pas ventilées.' ?></p>
	<?php endif; ?>
</div></div>
<?php endif; ?>
