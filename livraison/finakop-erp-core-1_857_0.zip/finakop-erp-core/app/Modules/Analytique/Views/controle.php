<?php /** @var string $annee @var array $annees @var array $ctrl @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$t = $ctrl['totaux'];
$pct = function ( $r, $b ) { return $b > 0 ? round( $r / $b * 100 ) : null; }; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'controle' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><a class="btn btn-primary btn-sm" href="#">Division</a><?php foreach ( array_filter( FKC_Axe::all(), function($a){return 'DIV'!==$a['code'];} ) as $a ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/controle-axe?axe=' . (int) $a['id'] . '&annee=' . $annee ) ) ?>"><?= e( $a['libelle'] ) ?></a><?php endforeach; ?></div>
	<span class="muted" style="flex-basis:100%">Budget vs réalisé — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Division</th><th class="num">Budget charges</th><th class="num">Réel charges</th><th class="num">Écart</th><th>Conso.</th><th class="num">Budget résultat</th><th class="num">Réel résultat</th></tr></thead>
	<tbody>
	<?php if ( ! $ctrl['lignes'] ) : ?><tr><td colspan="7" class="empty">Aucune division.</td></tr>
	<?php else : foreach ( $ctrl['lignes'] as $l ) :
		$dep = $l['ecart_charges'] > 0; // dépassement de charges
		$conso = $l['conso_charges']; ?>
		<tr>
			<td><strong><?= e( $l['code'] ) ?></strong> <?= e( $l['libelle'] ) ?><?= $l['a_budget'] ? '' : ' <span class="muted" style="font-size:.82em">(sans budget)</span>' ?><?= isset( $l['actif'] ) && ! $l['actif'] ? ' <span class="muted" style="font-size:.82em">(inactive)</span>' : '' ?></td>
			<td class="num"><?= e( fkc_money( $l['budget_charges'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $l['reel_charges'] ) ) ?></td>
			<td class="num" style="color:<?= $dep ? 'var(--danger)' : 'var(--ok)' ?>"><?= ( $dep ? '+' : '' ) . e( fkc_money( $l['ecart_charges'] ) ) ?></td>
			<td><?php if ( null === $conso ) : ?><span class="muted">—</span><?php else : ?>
				<div style="display:flex;align-items:center;gap:6px"><div style="background:rgba(255,255,255,.05);border-radius:6px;height:12px;width:90px"><div style="height:100%;border-radius:6px;width:<?= min( 100, (int) $conso ) ?>%;background:<?= $conso > 100 ? 'var(--danger)' : ( $conso > 85 ? 'var(--orange)' : 'var(--ok)' ) ?>"></div></div><span style="font-size:.85em;<?= $conso>100?'color:var(--danger)':'' ?>"><?= (int) $conso ?>%</span></div>
			<?php endif; ?></td>
			<td class="num"><?= e( fkc_money( $l['budget_resultat'] ) ) ?></td>
			<td class="num" style="color:<?= $l['reel_resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= e( fkc_money( $l['reel_resultat'] ) ) ?></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $ctrl['lignes'] ) : ?><tfoot><tr class="total">
		<td class="right">Total</td>
		<td class="num"><?= e( fkc_money( $t['bc'] ) ) ?></td><td class="num"><?= e( fkc_money( $t['rc'] ) ) ?></td>
		<td class="num" style="color:<?= $t['ecart_charges']>0?'var(--danger)':'var(--ok)' ?>"><?= ( $t['ecart_charges']>0?'+':'' ) . e( fkc_money( $t['ecart_charges'] ) ) ?></td>
		<td><?php $tc = $pct( $t['rc'], $t['bc'] ); echo null===$tc?'—':( (int)$tc.'%' ); ?></td>
		<td class="num"><?= e( fkc_money( $t['budget_resultat'] ) ) ?></td>
		<td class="num"><?= e( fkc_money( $t['reel_resultat'] ) ) ?></td>
	</tr></tfoot><?php endif; ?>
</table></div>
