<?php /** @var string $annee @var array $annees @var array $kpi @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$pct = function ( $v ) { return null === $v ? '—' : $v . ' %'; }; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'kpi' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Indicateurs analytiques — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>
<div class="form-grid">
	<div class="card"><div class="card-body"><span class="muted">Marge — Marge brute</span><div style="font-size:1.4em;font-weight:700;color:var(--ok)"><?= e( fkc_money( $kpi['marge_brute'] ) ) ?></div><span class="muted" style="font-size:.85em">Taux : <?= $pct( $kpi['taux_marge_brute'] ) ?> du CA</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Rentabilité — Résultat / Produits</span><div style="font-size:1.4em;font-weight:700"><?= $pct( $kpi['rentabilite'] ) ?></div><span class="muted" style="font-size:.85em">Résultat : <?= e( fkc_money( $kpi['resultat'] ) ) ?></span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Performance — Coût salarié</span><div style="font-size:1.4em;font-weight:700;color:var(--orange)"><?= e( fkc_money( $kpi['cout_salarie'] ) ) ?></div><span class="muted" style="font-size:.85em"><?= $pct( $kpi['taux_cout_salarie'] ) ?> de l'activité</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Recouvrement — DSO</span><div style="font-size:1.4em;font-weight:700"><?= null === $kpi['dso'] ? '—' : (int) $kpi['dso'] . ' j' ?></div><span class="muted" style="font-size:.85em">Créances : <?= e( fkc_money( $kpi['creances'] ) ) ?><?= empty( $kpi['dso_ttc'] ) ? '' : ' · base CA TTC' ?></span></div></div>
</div>
<div class="form-grid">
	<div class="card"><div class="card-body"><span class="muted">Chiffre d'affaires (cl.70)</span><div style="font-weight:700"><?= e( fkc_money( $kpi['ca'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Produits (cl.7)</span><div style="font-weight:700"><?= e( fkc_money( $kpi['produits'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Charges (cl.6)</span><div style="font-weight:700"><?= e( fkc_money( $kpi['charges'] ) ) ?></div></div></div>
</div>
