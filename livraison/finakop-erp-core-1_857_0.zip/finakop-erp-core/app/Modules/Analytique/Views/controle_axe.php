<?php /** @var string $annee @var array $annees @var array $axes @var int $axeId @var int $seuil @var float $sim @var array $ctrl @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$t = $ctrl['totaux']; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'controle' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/controle-budgetaire?annee=' . $annee ) ) ?>">Division</a>
		<?php foreach ( $axes as $a ) : ?><a class="btn btn-sm <?= (int)$axeId===(int)$a['id']?'btn-primary':'btn-ghost' ?>" href="<?= e( url( 'analytique/controle-axe?axe=' . (int) $a['id'] . '&annee=' . $annee ) ) ?>"><?= e( $a['libelle'] ) ?></a><?php endforeach; ?>
	</div>
</div>
<div class="card"><div class="card-body">
	<form method="get" action="<?= e( url( 'analytique/controle-axe' ) ) ?>" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">
		<input type="hidden" name="axe" value="<?= (int) $axeId ?>">
		<label class="fld" style="margin:0"><span>Exercice</span><select name="annee"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Seuil d'alerte (% conso.)</span><input type="number" name="seuil" value="<?= (int) $seuil ?>" min="1" max="200" style="width:90px"></label>
		<label class="fld" style="margin:0"><span>Simulation : variation charges (%)</span><input type="number" name="sim" value="<?= (int) $sim ?>" step="1" style="width:120px"></label>
		<button class="btn btn-primary btn-sm" type="submit">Appliquer</button>
	</form>
</div></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Valeur</th><th class="num">Budget charges</th><th class="num">Réel charges</th><?php if ( $sim ) : ?><th class="num">Simulé (+<?= (int) $sim ?>%)</th><?php endif; ?><th class="num">Écart</th><th>Conso.</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $ctrl['lignes'] ) : ?><tr><td colspan="7" class="empty">Aucune valeur budgétée pour cet axe.</td></tr>
	<?php else : foreach ( $ctrl['lignes'] as $l ) : $conso = $l['conso_charges']; $simChg = round( $l['reel_charges'] * ( 1 + $sim / 100 ) ); ?>
		<tr style="<?= $l['alerte'] ? 'background:rgba(244,154,18,.06)' : '' ?>">
			<td><strong><?= e( $l['code'] ) ?></strong> <?= e( $l['libelle'] ) ?></td>
			<td class="num"><?= e( fkc_money( $l['budget_charges'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $l['reel_charges'] ) ) ?></td>
			<?php if ( $sim ) : ?><td class="num muted"><?= e( fkc_money( $simChg ) ) ?></td><?php endif; ?>
			<td class="num" style="color:<?= $l['ecart_charges']>0?'var(--danger)':'var(--ok)' ?>"><?= ( $l['ecart_charges']>0?'+':'' ) . e( fkc_money( $l['ecart_charges'] ) ) ?></td>
			<td><?php if ( null === $conso ) : ?><span class="muted">—</span><?php else : ?>
				<div style="display:flex;align-items:center;gap:6px"><div style="background:rgba(255,255,255,.05);border-radius:6px;height:12px;width:80px"><div style="height:100%;border-radius:6px;width:<?= min( 100, (int) $conso ) ?>%;background:<?= $conso>100?'var(--danger)':( $conso>=$seuil?'var(--orange)':'var(--ok)' ) ?>"></div></div><span style="font-size:.85em;<?= $conso>=$seuil?'color:var(--orange)':'' ?>"><?= (int) $conso ?>%</span></div>
			<?php endif; ?></td>
			<td><?= $l['alerte'] ? '<span class="modbadge b-off">⚠ Alerte</span>' : '' ?></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( ! empty( $ctrl['lignes'] ) ) : ?><tfoot><tr class="total"><td class="right">Total</td><td class="num"><?= e( fkc_money( $t['bc'] ) ) ?></td><td class="num"><?= e( fkc_money( $t['rc'] ) ) ?></td><?php if ( $sim ) : ?><td class="num"><?= e( fkc_money( round( $t['rc'] * ( 1 + $sim / 100 ) ) ) ) ?></td><?php endif; ?><td class="num" style="color:<?= ($t['ecart_charges']??0)>0?'var(--danger)':'var(--ok)' ?>"><?= ( ($t['ecart_charges']??0)>0?'+':'' ) . e( fkc_money( $t['ecart_charges'] ?? 0 ) ) ?></td><td colspan="2"></td></tr></tfoot><?php endif; ?>
</table></div>
