<?php
/**
 * ANALYTIQUE → SUIVI BUDGÉTAIRE MENSUEL (1.831.0).
 *
 * @var string $annee @var array $annees @var array $sections @var int $div @var int $seuil
 * @var array $s (FKC_BudgetMensuel::suivi) @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$j = (int) $s['jusqua'];
$mois = $s['mois'];
$t = $s['totaux'];
$fin = FKC_BudgetMensuel::libMois( $mois[ $j ] );
$fkcPct = function ( $r, $b ) { return $b > 0 ? round( ( $r - $b ) / $b * 100, 1 ) : null; };
$fkcDet = function ( $nature ) use ( $div, $annee ) {
	return $div ? url( 'analytique/detail?axe=DIV&valeur=' . (int) $div . '&annee=' . $annee . '&compte=' . $nature ) : '';
};
$labels = array(); foreach ( $mois as $i => $m ) { $labels[] = FKC_BudgetMensuel::libMois( $m ); }
$serieReel = function ( $cle ) use ( $s, $j ) { $o = array(); for ( $i = 1; $i <= 12; $i++ ) { $o[] = $i <= $j ? round( $s['serie'][ $cle ][ $i ] ) : 0; } return $o; };
$groupes = array( 'charge' => 'Charges', 'produit' => 'Produits' );
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'controle' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<form method="get" action="<?= e( url( 'analytique/budget-mensuel/suivi' ) ) ?>" class="bm-barre">
	<label class="fld"><span>Section</span><select name="section" onchange="this.form.submit()"><?php foreach ( $sections as $id => $lib ) : ?><option value="<?= (int) $id ?>" <?= (int) $id === $div ? 'selected' : '' ?>><?= e( $lib ) ?></option><?php endforeach; ?></select></label>
	<label class="fld"><span>Exercice</span><select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= (string) $y === (string) $annee ? 'selected' : '' ?>><?= e( FKC_Exercice::libelle( $y ) ) ?></option><?php endforeach; ?></select></label>
	<label class="fld" style="flex-basis:150px"><span>À fin de</span><select name="mois" onchange="this.form.submit()"><?php foreach ( $mois as $i => $m ) : ?><option value="<?= (int) $i ?>" <?= $i === $j ? 'selected' : '' ?>><?= e( FKC_BudgetMensuel::libMois( $m ) ) ?></option><?php endforeach; ?></select></label>
	<label class="fld" style="flex-basis:120px"><span>Alerte au-delà de</span><select name="seuil" onchange="this.form.submit()"><?php foreach ( array( 0, 5, 10, 20 ) as $x ) : ?><option value="<?= $x ?>" <?= $x === $seuil ? 'selected' : '' ?>><?= $x ?> %</option><?php endforeach; ?></select></label>
	<noscript><button class="btn btn-ghost btn-sm" type="submit">Afficher</button></noscript>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/budget-mensuel?annee=' . $annee . '&section=' . $div ) ) ?>">✏️ Saisir le budget</a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/budget-mensuel/export?annee=' . $annee . '&section=' . $div ) ) ?>">⬇ Exporter (CSV)</a>
</form>

<?php if ( ! $s['a_budget'] ) : ?>
	<div class="alert" style="border-left:3px solid var(--orange)">Aucun budget mensuel saisi pour <?= e( $sections[ $div ] ?? '' ) ?> sur <?= e( $annee ) ?> : seul le réalisé s'affiche. <a href="<?= e( url( 'analytique/budget-mensuel?annee=' . $annee . '&section=' . $div ) ) ?>">Saisir le budget →</a></div>
<?php endif; ?>

<?php $ec = $fkcPct( $t['charge']['rc'], $t['charge']['bc'] ); $ep = $fkcPct( $t['produit']['rc'], $t['produit']['bc'] ); $r = $s['resultat']; ?>
<div class="stats kpi">
	<div class="stat <?= null !== $ec && $ec > $seuil ? 'kpi-neg' : '' ?>"><span class="stat-label">Charges à fin <?= e( $fin ) ?></span><span class="stat-value"><?= e( fkc_money( $t['charge']['rc'] ) ) ?><small> F</small></span>
		<span class="muted" style="font-size:12px">budget <?= e( fkc_money( $t['charge']['bc'] ) ) ?><?= null !== $ec ? ' · ' . ( $ec > 0 ? '+' : '' ) . e( str_replace( '.', ',', (string) $ec ) ) . ' %' : '' ?></span></div>
	<div class="stat <?= null !== $ep && -$ep > $seuil ? 'kpi-neg' : 'kpi-ca' ?>"><span class="stat-label">Produits à fin <?= e( $fin ) ?></span><span class="stat-value"><?= e( fkc_money( $t['produit']['rc'] ) ) ?><small> F</small></span>
		<span class="muted" style="font-size:12px">budget <?= e( fkc_money( $t['produit']['bc'] ) ) ?><?= null !== $ep ? ' · ' . ( $ep > 0 ? '+' : '' ) . e( str_replace( '.', ',', (string) $ep ) ) . ' %' : '' ?></span></div>
	<div class="stat <?= $r['reel_cumul'] >= 0 ? 'kpi-pos' : 'kpi-neg' ?>"><span class="stat-label">Résultat d'exploitation cumulé</span><span class="stat-value"><?= e( fkc_money( $r['reel_cumul'] ) ) ?><small> F</small></span>
		<span class="muted" style="font-size:12px">budget <?= e( fkc_money( $r['budget_cumul'] ) ) ?> · année <?= e( fkc_money( $r['budget_annuel'] ) ) ?></span></div>
	<div class="stat <?= $s['alertes'] ? 'kpi-neg' : 'kpi-pos' ?>"><span class="stat-label">Natures en alerte</span><span class="stat-value"><?= (int) $s['alertes'] ?></span>
		<span class="muted" style="font-size:12px">écart au-delà de <?= (int) $seuil ?> %</span></div>
</div>

<div class="bm-graphes">
	<?php foreach ( $groupes as $sens => $lib ) : $cle = $sens . 's'; ?>
	<div class="card"><div class="card-head"><h2><?= e( $lib ) ?> par mois</h2></div><div class="card-body">
		<?= FKC_Chart::combo( $labels, array(
			array( 'label' => 'Réalisé', 'type' => 'bar', 'values' => $serieReel( 'reel_' . $cle ), 'color' => 'charge' === $sens ? 'var(--danger)' : 'var(--ok)' ),
			array( 'label' => 'Budget', 'type' => 'line', 'values' => array_map( 'round', array_values( $s['serie'][ 'budget_' . $cle ] ) ), 'color' => 'var(--blue)' ),
		), array( 'height' => 230 ) ) ?>
	</div></div>
	<?php endforeach; ?>
</div>

<div class="card card-flush" style="overflow-x:auto"><table class="table">
	<thead><tr><th>Nature</th><th class="num">Budget <?= e( $fin ) ?></th><th class="num">Réel <?= e( $fin ) ?></th><th class="num">Budget cumulé</th><th class="num">Réel cumulé</th><th class="num">Écart</th><th>Année consommée</th></tr></thead>
	<?php foreach ( $groupes as $sens => $lib ) : $lignes = array_filter( $s['lignes'], function ( $l ) use ( $sens ) { return $l['sens'] === $sens; } ); $tt = $t[ $sens ]; ?>
	<tbody>
		<tr class="bm-groupe"><th colspan="7" style="text-align:left;background:var(--panel2);color:var(--muted);font-size:12px;text-transform:uppercase"><?= e( $lib ) ?></th></tr>
		<?php if ( ! $lignes ) : ?><tr><td colspan="7" class="empty">Ni budget ni réalisé.</td></tr><?php endif; ?>
		<?php foreach ( $lignes as $l ) : $mauvais = 'charge' === $sens ? $l['ecart'] > 0.5 : $l['ecart'] < -0.5; $lien = $fkcDet( $l['nature'] ); ?>
		<tr<?= $l['alerte'] ? ' style="background:rgba(239,68,68,.08)"' : '' ?>>
			<td><?= $l['alerte'] ? '⚠️ ' : '' ?><span class="code"><?= e( $l['nature'] ) ?></span> <?= e( $l['libelle'] ) ?><?= $l['sans_budget'] ? ' <span class="muted" style="font-size:.82em">(sans budget)</span>' : '' ?></td>
			<td class="num muted"><?= e( fkc_money( $l['budget_mois'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $l['reel_mois'] ) ) ?></td>
			<td class="num muted"><?= e( fkc_money( $l['budget_cumul'] ) ) ?></td>
			<td class="num"><?= $lien ? '<a href="' . e( $lien ) . '" title="Voir les écritures">' . e( fkc_money( $l['reel_cumul'] ) ) . '</a>' : e( fkc_money( $l['reel_cumul'] ) ) ?></td>
			<td class="num" style="color:<?= $mauvais ? 'var(--danger)' : 'var(--ok)' ?>"><?= ( $l['ecart'] > 0 ? '+' : '' ) . e( fkc_money( $l['ecart'] ) ) ?><?= null !== $l['ecart_pct'] ? '<br><small>' . ( $l['ecart_pct'] > 0 ? '+' : '' ) . e( str_replace( '.', ',', (string) $l['ecart_pct'] ) ) . ' %</small>' : '' ?></td>
			<td><?php if ( null === $l['conso'] ) : ?><span class="muted">—</span><?php else : $c = (int) $l['conso']; $att = round( $j / 12 * 100 ); ?>
				<div style="display:flex;align-items:center;gap:6px" title="<?= $c ?> % du budget annuel ; <?= $att ?> % de l'année écoulée">
					<div style="position:relative;background:rgba(255,255,255,.06);border-radius:6px;height:10px;width:100px">
						<div style="height:100%;border-radius:6px;width:<?= min( 100, $c ) ?>%;background:<?= 'charge' === $sens ? ( $c > $att + $seuil ? 'var(--danger)' : 'var(--ok)' ) : ( $c + $seuil < $att ? 'var(--orange)' : 'var(--ok)' ) ?>"></div>
						<div style="position:absolute;top:-3px;left:<?= min( 100, $att ) ?>%;width:2px;height:16px;background:var(--muted)"></div>
					</div><span style="font-size:.85em"><?= $c ?> %</span></div>
			<?php endif; ?></td>
		</tr>
		<?php endforeach; ?>
		<tr class="total"><td>Total <?= e( mb_strtolower( $lib ) ) ?></td><td class="num"><?= e( fkc_money( $tt['bm'] ) ) ?></td><td class="num"><?= e( fkc_money( $tt['rm'] ) ) ?></td><td class="num"><?= e( fkc_money( $tt['bc'] ) ) ?></td><td class="num"><?= e( fkc_money( $tt['rc'] ) ) ?></td><td class="num"><?= ( $tt['rc'] - $tt['bc'] > 0 ? '+' : '' ) . e( fkc_money( $tt['rc'] - $tt['bc'] ) ) ?></td><td><?= $tt['ba'] > 0 ? (int) round( $tt['rc'] / $tt['ba'] * 100 ) . ' %' : '—' ?></td></tr>
	</tbody>
	<?php endforeach; ?>
</table></div>
<p class="help">Le trait vertical de la barre marque la part de l'année écoulée (<?= (int) round( $j / 12 * 100 ) ?> % à fin <?= e( $fin ) ?>) : une charge qui le dépasse nettement consomme son budget trop vite. Une charge sans budget est signalée dès le premier franc. Réalisé lu au grand livre (écriture de clôture exclue)<?= $div ? ', parts ventilées comprises ; un clic sur le réel cumulé montre les écritures' : '' ?>.</p>
<style>
.bm-barre{display:flex!important;flex-wrap:wrap;gap:10px;align-items:end;margin:0 0 14px}
.bm-barre .fld{margin:0;min-width:0;flex:0 1 240px}
.bm-barre select{width:100%}
.bm-graphes{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:14px;margin-bottom:14px}
.bm-graphes .card{margin:0}
</style>
