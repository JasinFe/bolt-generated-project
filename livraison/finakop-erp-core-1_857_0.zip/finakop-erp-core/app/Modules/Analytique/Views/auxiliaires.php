<?php /** @var array $axes @var int $axeId @var array $auxiliaires @var array $valeurs @var string $annee @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'auxiliaires' ) );
$pct = fn( $v ) => str_replace( '.', ',', (string) round( (float) $v, 2 ) );
// Sections déjà sources : elles ne peuvent être ni destinataires, ni déclarées deux fois.
$sources = array();
foreach ( $auxiliaires as $a ) { $sources[ (int) $a['source_id'] ] = true; }
?>
<?php if ( $flash ) : ?><div class="alert <?= false !== strpos( (string) $flash, '⚠️' ) ? 'alert-warn' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:4px">
	<h1 style="font-size:20px">Sections auxiliaires</h1>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/resultats-analytiques?axe=' . (int) $axeId . '&annee=' . e( $annee ) ) ) ?>">Voir les résultats →</a>
</div>

<div class="card" style="margin-bottom:16px"><div class="card-body">
	<p style="font-size:13px;margin:0 0 8px">
		Une <strong>section auxiliaire</strong> travaille pour les autres sans vendre elle-même : siège, administration,
		direction. Elle porte des salaires, un loyer, de l'électricité, et n'a en face aucun produit.
	</p>
	<p style="font-size:13px;margin:0 0 8px">
		Lue telle quelle, elle affiche un résultat massivement négatif, et les autres un résultat trop beau — puisqu'elles
		consomment ce support sans en porter le coût. <strong>Aucun des deux chiffres n'est faux comptablement ; les deux
		sont trompeurs en gestion.</strong> La répartition secondaire déverse ses charges sur les sections qui en profitent.
	</p>
	<ul style="margin:0;padding-left:20px;font-size:13px;line-height:1.7">
		<li><strong>La comptabilité générale n'est pas touchée.</strong> Aucune écriture n'est créée ni modifiée : le déversement est calculé à l'affichage. Vous pouvez changer une clé sans rien contrepasser.</li>
		<li><strong>Le total ne bouge jamais.</strong> Ce qui sort d'une section entre dans une autre, au franc près.</li>
		<li><strong>Aucune boucle.</strong> Une section qui reçoit ne peut pas déverser à son tour : le résultat dépendrait de l'ordre de calcul.</li>
		<li><strong>Seules les charges sont réparties.</strong> Si la section encaisse accessoirement quelque chose, ce produit reste chez elle : on déverse ce qu'elle a coûté, pas ce qu'elle a gagné.</li>
	</ul>
</div></div>

<div class="card" style="margin-bottom:16px"><div class="card-body">
	<form method="get" class="form-grid" style="grid-template-columns:minmax(0,1fr) minmax(0,150px);gap:12px;align-items:end">
		<label class="fld" style="margin:0;min-width:0"><span>Axe analytique</span>
			<select name="axe" onchange="this.form.submit()" style="width:100%">
				<?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $axeId === (int) $a['id'] ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?>
			</select></label>
		<input type="hidden" name="annee" value="<?= e( $annee ) ?>">
		<noscript><button class="btn btn-ghost btn-sm">Afficher</button></noscript>
	</form>
</div></div>

<?php foreach ( $auxiliaires as $a ) : ?>
	<div class="card" style="margin-bottom:16px">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
			<h2><?= e( $a['source']['libelle'] ?? ( 'Section #' . (int) $a['source_id'] ) ) ?>
				<span class="muted" style="font-size:12px"><?= e( $a['source']['code'] ?? '' ) ?></span>
				<?php if ( empty( $a['actif'] ) ) : ?><span class="modbadge b-off">désactivée</span><?php endif; ?>
			</h2>
			<div style="display:flex;gap:8px;align-items:center">
				<?php /* Le total décide si la clé s'applique intégralement : il est donc affiché à côté du titre, pas en bas de tableau. */ ?>
				<span class="modbadge <?= $a['complete'] ? 'b-on' : 'b-off' ?>">Réparti : <?= e( $pct( $a['total'] ) ) ?> %</span>
				<form method="post" action="<?= e( url( 'analytique/auxiliaires/' . (int) $a['id'] . '/basculer' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>"><button class="btn btn-ghost btn-sm"><?= empty( $a['actif'] ) ? 'Activer' : 'Désactiver' ?></button></form>
				<form method="post" action="<?= e( url( 'analytique/auxiliaires/' . (int) $a['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer cette section auxiliaire ? Ses charges resteront chez elle.')" style="display:inline"><?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>"><button class="btn btn-ghost btn-sm">✕</button></form>
			</div>
		</div>
		<?php if ( ! $a['complete'] ) : ?>
			<div class="alert alert-warn" style="margin:12px 16px">
				⚠️ <?= e( $pct( 100 - $a['total'] ) ) ?> % ne sont pas répartis : cette part des charges <strong>restera sur la section auxiliaire</strong>.
				C'est un choix valable — une quote-part de siège qu'on ne veut imputer à personne — mais il vaut mieux qu'il soit voulu.
			</div>
		<?php endif; ?>
		<table class="table"><thead><tr><th>Section destinataire</th><th class="num" style="width:180px">Part</th><th style="width:60px"></th></tr></thead><tbody>
		<?php if ( ! $a['parts'] ) : ?><tr><td colspan="3" class="empty">Aucune destinataire : les charges restent entièrement sur cette section.</td></tr>
		<?php else : foreach ( $a['parts'] as $p ) : ?><tr>
			<td><strong><?= e( $p['cible']['libelle'] ?? ( 'Section #' . (int) $p['cible_id'] ) ) ?></strong> <span class="muted" style="font-size:11px"><?= e( $p['cible']['code'] ?? '' ) ?></span></td>
			<td class="num">
				<form method="post" action="<?= e( url( 'analytique/auxiliaires/' . (int) $a['id'] . '/part' ) ) ?>" style="display:flex;gap:4px;justify-content:flex-end;align-items:center">
					<?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>"><input type="hidden" name="cible_id" value="<?= (int) $p['cible_id'] ?>">
					<input type="number" step="0.01" min="0" max="100" name="part" value="<?= e( (float) $p['part'] ) ?>" style="width:90px" class="num">
					<span class="muted">%</span><button class="btn btn-ghost btn-sm">✓</button>
				</form>
			</td>
			<td class="right"><form method="post" action="<?= e( url( 'analytique/auxiliaires/' . (int) $a['id'] . '/retirer' ) ) ?>"><?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>"><input type="hidden" name="cible_id" value="<?= (int) $p['cible_id'] ?>"><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
		<div class="card-body">
			<form method="post" action="<?= e( url( 'analytique/auxiliaires/' . (int) $a['id'] . '/part' ) ) ?>" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
				<?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>">
				<label class="fld" style="margin:0;min-width:220px;flex:1"><span>Ajouter une destinataire</span>
					<select name="cible_id" required>
						<option value="">— choisir —</option>
						<?php foreach ( $valeurs as $v ) :
							// Ni la source elle-même, ni une autre section auxiliaire : les deux créeraient une boucle.
							if ( (int) $v['id'] === (int) $a['source_id'] || isset( $sources[ (int) $v['id'] ] ) ) { continue; } ?>
							<option value="<?= (int) $v['id'] ?>"><?= e( $v['code'] ) ?> · <?= e( $v['libelle'] ) ?></option>
						<?php endforeach; ?>
					</select></label>
				<label class="fld" style="margin:0;width:120px"><span>Part (%)</span><input type="number" step="0.01" min="0" max="100" name="part" value="0" required></label>
				<button class="btn btn-primary btn-sm">Ajouter</button>
			</form>
		</div>
	</div>
<?php endforeach; ?>

<div class="card"><div class="card-head"><h2>＋ Déclarer une section auxiliaire</h2></div><div class="card-body">
	<?php $dispo = array_filter( $valeurs, fn( $v ) => ! isset( $sources[ (int) $v['id'] ] ) ); ?>
	<?php if ( ! $dispo ) : ?>
		<p class="muted" style="font-size:13px;margin:0">Toutes les sections de cet axe sont déjà déclarées auxiliaires — ce qui ne laisserait personne pour recevoir les charges.</p>
	<?php else : ?>
	<form method="post" action="<?= e( url( 'analytique/auxiliaires/creer' ) ) ?>">
		<?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>">
		<label class="fld"><span>Section qui supporte les charges *</span>
			<select name="source_id" required><option value="">— choisir —</option>
				<?php foreach ( $dispo as $v ) : ?><option value="<?= (int) $v['id'] ?>"><?= e( $v['code'] ) ?> · <?= e( $v['libelle'] ) ?></option><?php endforeach; ?>
			</select></label>
		<label class="fld"><span>Note <span class="muted">(sur quoi repose la clé : effectif, surface, chiffre d'affaires…)</span></span><input name="note" placeholder="Ex. : au prorata de l'effectif au 1er janvier"></label>
		<p class="help" style="margin-top:-4px">Notez la base de votre clé : c'est la première question posée six mois plus tard, et la réponse ne se déduit pas des pourcentages.</p>
		<div class="actions"><button class="btn btn-primary">Déclarer</button></div>
	</form>
	<?php endif; ?>
</div></div>
