<?php /** @var string $annee @var array $annees @var array $data @var array $axes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'multi_axes' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Analyse par axe — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>

<div class="card">
	<div class="card-head"><h2>Axes analytiques</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'analytique/multi-axes/axes' ) ) ?>" style="display:flex;gap:8px;align-items:end;flex-wrap:wrap;margin-bottom:10px">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0"><span>Code</span><input type="text" name="code" maxlength="10" placeholder="PROJ" style="width:100px"></label>
			<label class="fld" style="margin:0;min-width:200px"><span>Libellé</span><input type="text" name="libelle" placeholder="Projet"></label>
			<button class="btn btn-ghost btn-sm" type="submit">+ Ajouter un axe</button>
		</form>
		<?php
		/*
		 * Chaque axe est modifiable sur place (1.768.0) : il n'était que
		 * créable et supprimable, si bien qu'une coquille dans un libellé
		 * coûtait tout le paramétrage rattaché à l'axe.
		 */
		?>
		<table class="table">
			<thead><tr><th style="width:130px">Code</th><th>Libellé</th><th style="width:110px">État</th><th style="width:240px"></th></tr></thead>
			<tbody>
			<?php foreach ( $axes as $a ) : $div = 'DIV' === $a['code']; $actif = ! empty( $a['actif'] ); ?>
				<tr>
					<form method="post" action="<?= e( url( 'analytique/multi-axes/axes/' . (int) $a['id'] ) ) ?>" id="axe-<?= (int) $a['id'] ?>"></form>
					<td><input form="axe-<?= (int) $a['id'] ?>" name="code" value="<?= e( $a['code'] ) ?>" maxlength="10" style="width:100px" <?= $div ? 'readonly title="Le code DIV est figé : le référentiel des divisions s\'y rattache."' : '' ?>></td>
					<td><input form="axe-<?= (int) $a['id'] ?>" name="libelle" value="<?= e( $a['libelle'] ) ?>"></td>
					<td><span class="modbadge <?= $actif ? 'b-on' : 'b-off' ?>"><?= $actif ? 'Actif' : 'Inactif' ?></span></td>
					<td class="right" style="white-space:nowrap">
						<?= FKC_Csrf::field() ?>
						<button class="btn btn-ghost btn-sm" form="axe-<?= (int) $a['id'] ?>" type="submit">Enregistrer</button>
						<?php if ( ! $div ) : ?>
							<form method="post" action="<?= e( url( 'analytique/multi-axes/axes/' . (int) $a['id'] . '/actif' ) ) ?>" style="display:inline;margin:0">
								<?= FKC_Csrf::field() ?>
								<button class="btn btn-ghost btn-sm" type="submit"><?= $actif ? 'Désactiver' : 'Réactiver' ?></button>
							</form>
							<?php
							$imp = ( $impacts ?? array() )[ (int) $a['id'] ] ?? array();
							$porte = array();
							if ( ! empty( $imp['affectations'] ) ) { $porte[] = $imp['affectations'] . ' affectation(s)'; }
							if ( ! empty( $imp['budgets'] ) )      { $porte[] = $imp['budgets'] . ' budget(s)'; }
							if ( ! empty( $imp['repartitions'] ) ) { $porte[] = $imp['repartitions'] . ' clé(s) de répartition'; }
							if ( ! empty( $imp['bases'] ) )        { $porte[] = $imp['bases'] . ' répartition(s) appuyée(s) dessus'; }
							$avert = $porte
								? 'Cet axe porte ' . implode( ', ', $porte ) . '. Tout disparaît avec lui, définitivement. Continuer ?'
								: 'Supprimer cet axe ? Ses valeurs analytiques disparaissent avec lui.';
							?>
							<form method="post" action="<?= e( url( 'analytique/multi-axes/axes/' . (int) $a['id'] . '/supprimer' ) ) ?>"
								onsubmit="return confirm(<?= json_encode( $avert, JSON_UNESCAPED_UNICODE ) ?>)" style="display:inline;margin:0">
								<?= FKC_Csrf::field() ?>
								<?php if ( $porte ) : ?><input type="hidden" name="forcer" value="1"><?php endif; ?>
								<button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)"
									title="<?= $porte ? e( 'Emporte : ' . implode( ', ', $porte ) ) : 'Cet axe ne porte encore aucune donnée' ?>">
									<?= $porte ? 'Supprimer définitivement' : 'Supprimer' ?></button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="help" style="margin:8px 0 0">Un axe qui ne sert plus se <strong>désactive</strong> : il quitte les écrans de saisie et son historique reste lisible.
			La suppression, elle, emporte ses valeurs, ses affectations, ses budgets et ses clés de répartition — elle est refusée tant que l'axe en porte,
			et se confirme alors depuis ce même écran.</p>
		<p class="help" style="margin:8px 0 0">Rattachez chaque division à un axe via l'onglet Divisions. Les sections sont ensuite analysées par axe ci-dessous.</p>
	</div>
</div>

<?php foreach ( ( $data['groupes'] ?? array() ) as $g ) : ?>
<div class="card card-flush">
	<div class="card-head"><h2><?= e( $g['axe'] ) ?></h2>
		<span class="muted">Résultat : <strong style="color:<?= $g['resultat']>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $g['resultat'] ) ) ?></strong></span></div>
	<table class="table">
		<thead><tr><th>Code</th><th>Division</th><th class="num">Produits</th><th class="num">Charges</th><th class="num">Résultat</th></tr></thead>
		<tbody><?php foreach ( $g['lignes'] as $l ) : ?>
			<tr><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td>
				<td class="num"><?= e( fkc_money( $l['produits'] ) ) ?></td><td class="num"><?= e( fkc_money( $l['charges'] ) ) ?></td>
				<td class="num" style="color:<?= $l['resultat']>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $l['resultat'] ) ) ?></td></tr>
		<?php endforeach; ?></tbody>
		<tfoot><tr class="total"><td></td><td class="right">Sous-total <?= e( $g['axe'] ) ?></td>
			<td class="num"><?= e( fkc_money( $g['produits'] ) ) ?></td><td class="num"><?= e( fkc_money( $g['charges'] ) ) ?></td><td class="num"><?= e( fkc_money( $g['resultat'] ) ) ?></td></tr></tfoot>
	</table>
</div>
<?php endforeach; ?>
