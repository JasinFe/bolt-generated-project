<?php /** @var string $annee @var array $annees @var array $axes @var int $axeId @var array $valeurs @var array $budgets @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'budgets' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/budgets?annee=' . $annee ) ) ?>">Division</a>
		<?php foreach ( $axes as $a ) : ?><a class="btn btn-sm <?= (int)$axeId===(int)$a['id']?'btn-primary':'btn-ghost' ?>" href="<?= e( url( 'analytique/budgets-axe?axe=' . (int) $a['id'] . '&annee=' . $annee ) ) ?>"><?= e( $a['libelle'] ) ?></a><?php endforeach; ?>
	</div>
	<form method="get" style="display:flex;gap:6px;align-items:center"><input type="hidden" name="axe" value="<?= (int) $axeId ?>"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>
<form method="post" action="<?= e( url( 'analytique/budgets-axe' ) ) ?>">
	<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>"><input type="hidden" name="axe_id" value="<?= (int) $axeId ?>">
	<div class="card card-flush"><table class="table">
		<thead><tr><th>Valeur</th><th class="num">Budget produits</th><th class="num">Budget charges</th><th class="num">Budget résultat</th><th>Note</th></tr></thead>
		<tbody>
		<?php if ( ! $valeurs ) : ?><tr><td colspan="5" class="empty">Aucune valeur pour cet axe. Ajoutez-en dans l'onglet Valeurs.</td></tr>
		<?php else : foreach ( $valeurs as $v ) : $b = $budgets[ (int) $v['id'] ] ?? null; $bp = $b ? (float) $b['budget_produits'] : 0; $bc = $b ? (float) $b['budget_charges'] : 0; ?>
			<tr><td><strong><?= e( $v['code'] ) ?></strong> <?= e( $v['libelle'] ) ?></td>
				<td class="num"><input type="number" name="produits[<?= (int) $v['id'] ?>]" value="<?= $bp ?: '' ?>" style="width:130px;text-align:right"></td>
				<td class="num"><input type="number" name="charges[<?= (int) $v['id'] ?>]" value="<?= $bc ?: '' ?>" style="width:130px;text-align:right"></td>
				<td class="num"><?= e( fkc_money( $bp - $bc ) ) ?></td>
				<td><input type="text" name="note[<?= (int) $v['id'] ?>]" value="<?= e( $b['note'] ?? '' ) ?>" style="width:100%"></td></tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
	<?php if ( $valeurs ) : ?><div class="actions"><button class="btn btn-primary" type="submit">Enregistrer</button></div><?php endif; ?>
</form>
