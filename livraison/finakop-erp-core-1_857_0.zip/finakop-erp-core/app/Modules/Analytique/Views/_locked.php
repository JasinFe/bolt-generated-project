<?php /** @var string $label @var string $min */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => '' ) ); ?>
<div class="card"><div class="card-body" style="text-align:center;padding:48px 24px">
	<div style="font-size:2em">🔒</div>
	<h2 style="margin:8px 0"><?= e( $label ) ?></h2>
	<p class="muted">Cette fonctionnalité est disponible à partir de l'édition <strong><?= e( $min ) ?></strong>.</p>
	<a class="btn btn-primary" href="<?= e( url( 'licence' ) ) ?>">Voir les éditions</a>
</div></div>
