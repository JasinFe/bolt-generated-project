<?php
/**
 * ANALYTIQUE → TABLEAU CROISÉ SUR DEUX AXES (1.826.0).
 *
 * @var array $axes @var int $x @var int $y @var string $annee @var array $annees @var string $mesure
 * @var array $m (FKC_AnaCroise::calculer) @var array $cols colonnes affichées @var array $autres ids regroupés @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$vide = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
$val = function ( $c ) use ( $mesure ) { return FKC_AnaCroise::mesure( $c ?: array( 'produits' => 0, 'charges' => 0, 'hao' => 0 ), $mesure ); };
$fkcDet = function ( array $q ) use ( $annee ) { return url( 'analytique/detail?' . http_build_query( $q + array( 'annee' => $annee ) ) ); };
// Intensité de couleur : relative à la plus grande case affichée.
$max = 0.0;
if ( $m['ok'] ) {
	foreach ( $m['lignes'] as $xi => $l ) { foreach ( $cols as $yi => $c ) { $max = max( $max, abs( $val( $m['cases'][ $xi ][ $yi ] ?? null ) ) ); } }
}
$fond = function ( $v ) use ( $max, $mesure ) {
	if ( $max <= 0 || abs( $v ) < 0.5 ) { return ''; }
	$a = round( 0.07 + 0.33 * min( 1, abs( $v ) / $max ), 3 );
	$neg = 'charges' === $mesure ? $v > 0 : $v < 0; // pour les charges, « plus » est la mauvaise direction
	return 'background:' . ( $neg ? 'rgba(239,68,68,' . $a . ')' : 'rgba(34,197,94,' . $a . ')' );
};
$fkcHao = $m['ok'] && abs( $m['total']['hao'] ) >= 0.5;
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'croise' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<form method="get" action="<?= e( url( 'analytique/croise' ) ) ?>" class="cx-form">
	<label class="fld"><span>En lignes</span><select name="x" onchange="this.form.submit()"><?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $a['id'] === $x ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?></select></label>
	<a class="btn btn-ghost btn-sm cx-swap" href="<?= e( url( 'analytique/croise?' . http_build_query( array( 'x' => $y, 'y' => $x, 'annee' => $annee, 'mesure' => $mesure ) ) ) ) ?>" title="Inverser lignes et colonnes" aria-label="Inverser lignes et colonnes">⇄</a>
	<label class="fld"><span>En colonnes</span><select name="y" onchange="this.form.submit()"><?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $a['id'] === $y ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?></select></label>
	<label class="fld"><span>Mesure</span><select name="mesure" onchange="this.form.submit()"><?php foreach ( FKC_AnaCroise::MESURES as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $k === $mesure ? 'selected' : '' ?>><?= e( $lib ) ?></option><?php endforeach; ?></select></label>
	<label class="fld"><span>Exercice</span><select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $yy ) : ?><option value="<?= e( $yy ) ?>" <?= (string) $yy === (string) $annee ? 'selected' : '' ?>><?= e( $yy ) ?></option><?php endforeach; ?></select></label>
	<noscript><button class="btn btn-ghost btn-sm" type="submit">Afficher</button></noscript>
	<?php if ( $m['ok'] ) : ?><a class="btn btn-ghost btn-sm" style="align-self:end" href="<?= e( url( 'analytique/croise/export?' . http_build_query( array( 'x' => $x, 'y' => $y, 'annee' => $annee, 'mesure' => $mesure ) ) ) ) ?>">⬇ Exporter (CSV)</a><?php endif; ?>
</form>

<?php if ( ! $m['ok'] ) : ?>
	<div class="alert alert-err"><?= e( $m['message'] ) ?></div>
<?php elseif ( ! $m['lignes'] ) : ?>
	<div class="card"><div class="card-body"><p class="muted" style="margin:0">Aucun mouvement de gestion sur l'exercice <?= e( $annee ) ?>.</p></div></div>
<?php else : ?>
<div class="card card-flush cx-wrap"><table class="table cx">
	<thead><tr>
		<th class="cx-coin"><?= e( $m['axeX']['libelle'] ) ?> <span class="muted">\ <?= e( $m['axeY']['libelle'] ) ?></span></th>
		<?php foreach ( $cols as $yi => $c ) : ?><th class="num" title="<?= e( $c[1] ) ?>"><a href="<?= e( $fkcDet( array( 'axe' => $y, 'valeur' => $yi ) ) ) ?>"><?= e( mb_strimwidth( (string) $c[1], 0, 18, '…' ) ) ?></a></th><?php endforeach; ?>
		<?php if ( $autres ) : ?><th class="num" title="Les <?= count( $autres ) ?> colonnes les plus petites, regroupées (l'export CSV les détaille)">Autres (<?= count( $autres ) ?>)</th><?php endif; ?>
		<th class="num cx-tot">Total</th>
	</tr></thead>
	<tbody>
	<?php foreach ( $m['lignes'] as $xi => $l ) : ?>
		<tr>
			<th class="cx-lib" title="<?= e( $l[1] ) ?>"><a href="<?= e( $fkcDet( array( 'axe' => $x, 'valeur' => $xi ) ) ) ?>"><?= e( mb_strimwidth( (string) $l[1], 0, 28, '…' ) ) ?></a></th>
			<?php foreach ( $cols as $yi => $c ) : $v = $val( $m['cases'][ $xi ][ $yi ] ?? null ); ?>
				<td class="num" style="<?= e( $fond( $v ) ) ?>"><?php if ( isset( $m['cases'][ $xi ][ $yi ] ) ) : ?><a href="<?= e( $fkcDet( array( 'axe' => $x, 'valeur' => $xi, 'axe2' => $y, 'valeur2' => $yi ) ) ) ?>" title="<?= e( $l[1] . ' × ' . $c[1] ) ?> — voir les écritures"><?= e( fkc_money( $v ) ) ?></a><?php else : ?><span class="muted">·</span><?php endif; ?></td>
			<?php endforeach; ?>
			<?php if ( $autres ) : $s = FKC_AnaCroise::somme( array_map( function ( $yi ) use ( $m, $xi ) { return $m['cases'][ $xi ][ $yi ] ?? array(); }, $autres ) ); $v = $val( $s ); ?>
				<td class="num muted"><?= abs( $v ) >= 0.5 ? e( fkc_money( $v ) ) : '·' ?></td>
			<?php endif; ?>
			<td class="num cx-tot"><strong><?= e( fkc_money( $val( $m['totL'][ $xi ] ) ) ) ?></strong></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
	<tfoot><tr class="total">
		<th class="cx-lib">Total</th>
		<?php foreach ( $cols as $yi => $c ) : ?><td class="num"><?= e( fkc_money( $val( $m['totC'][ $yi ] ) ) ) ?></td><?php endforeach; ?>
		<?php if ( $autres ) : ?><td class="num"><?= e( fkc_money( $val( FKC_AnaCroise::somme( array_map( function ( $yi ) use ( $m ) { return $m['totC'][ $yi ]; }, $autres ) ) ) ) ) ?></td><?php endif; ?>
		<td class="num cx-tot"><strong><?= e( fkc_money( $val( $m['total'] ) ) ) ?></strong></td>
	</tr></tfoot>
</table></div>
<p class="help">
	Une case additionne ce qui est imputé À LA FOIS à la ligne et à la colonne ; une ligne ventilée y compte pour le produit de ses deux parts (60 % × 50 % = 30 %). Les totaux de lignes égalent les résultats par axe « <?= e( $m['axeX']['libelle'] ) ?> », ceux des colonnes les résultats « <?= e( $m['axeY']['libelle'] ) ?> ». Cliquez une case pour voir ses écritures.
	<?php if ( $fkcHao && 'resultat' === $mesure ) : ?>Cet exercice porte des opérations hors activités ordinaires (<?= e( fkc_money( $m['total']['hao'] ) ) ?> F) : choisissez « Résultat net » pour les inclure.<?php endif; ?>
</p>
<?php endif; ?>
<style>
/* La feuille générale met en grille tout formulaire à plusieurs .fld (sélecteur :has, plus fort) : on reprend la main. */
.cx-form{display:flex!important;flex-wrap:wrap;gap:10px;align-items:end;margin:0 0 14px}
.cx-form .fld{margin:0;min-width:0;flex:0 1 200px}
.cx-form select{width:100%}
.cx-swap{align-self:end;margin-bottom:2px}
.cx-wrap{overflow:auto;max-height:75vh}
.cx{border-collapse:separate;border-spacing:0}
.cx th,.cx td{white-space:nowrap}
.cx td a,.cx th a{color:inherit;text-decoration:none}
.cx td a:hover,.cx th a:hover{text-decoration:underline}
.cx thead th{position:sticky;top:0;z-index:2;background:var(--panel)}
.cx .cx-lib,.cx .cx-coin{position:sticky;left:0;z-index:1;background:var(--panel);text-align:left;font-weight:600;max-width:220px;overflow:hidden;text-overflow:ellipsis}
.cx thead .cx-coin{z-index:3}
.cx .cx-tot{border-left:1px solid var(--line2)}
@media(max-width:520px){.cx-form .fld{flex:1 1 140px}}
</style>
