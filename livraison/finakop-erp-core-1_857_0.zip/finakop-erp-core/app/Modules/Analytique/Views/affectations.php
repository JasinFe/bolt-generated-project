<?php
/**
 * ANALYTIQUE → AFFECTATIONS (fiabilisé 1.822.0).
 *
 * - Pagination dimensionnée sur max_input_vars : tout ce qui est affiché arrive au serveur.
 * - Listes chargées à la demande : chaque sélecteur ne contient que « — » et la valeur
 *   actuelle ; la liste complète de l'axe (un <template> par axe) est versée au premier
 *   toucher. La page reste légère même avec des centaines de valeurs.
 * - Le champ `_fin` est le dernier du formulaire : sans lui, le serveur refuse le lot.
 * - Lignes d'un exercice clôturé : figées (cadenas), le serveur les refuse aussi.
 *
 * @var string $annee @var array $annees @var array $axes @var array $valeursParAxe @var array $libelles
 * @var array $lignes @var array $affect @var array $verrou @var bool $restant @var int $reste
 * @var int $page @var int $pages @var int $total @var int $parPage @var int $attente @var mixed $flash
 * @var array $ventil [ligne => [axe => [valeur => part]]] @var array $cles clés applicables (1.823.0)
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcQs = function ( $p ) use ( $annee, $restant ) {
	return url( 'analytique/affectations?annee=' . $annee . ( $restant ? '&restant=1' : '' ) . ( $p > 1 ? '&page=' . (int) $p : '' ) );
};
$fkcVerrouillees = count( array_filter( $verrou ) );
$fkcRetour = 'analytique/affectations?annee=' . $annee . ( $restant ? '&restant=1' : '' ) . ( $page > 1 ? '&page=' . (int) $page : '' );
$fkcCles = ! empty( $cles );
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'affectations' ) ); ?>
<?php if ( $flash ) : ?><div class="alert <?= false !== stripos( (string) $flash, 'refus' ) ? 'alert-err' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar" style="flex-wrap:wrap;gap:8px">
	<span class="muted">Exercice <?= e( $annee ) ?> · <?= (int) $total ?> ligne(s)<?= $restant ? ' à affecter' : '' ?><?= $reste ? ' · ' . (int) $reste . ' non affectée(s) sur l\'exercice' : ' · tout est affecté' ?></span>
	<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
		<a class="btn btn-sm <?= $restant ? 'btn-primary' : 'btn-ghost' ?>" href="<?= e( url( 'analytique/affectations?annee=' . $annee . ( $restant ? '' : '&restant=1' ) ) ) ?>"><?= $restant ? 'Voir toutes les lignes' : 'Ne montrer que le reste à affecter' ?></a>
		<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
			<?php if ( $restant ) : ?><input type="hidden" name="restant" value="1"><?php endif; ?>
			<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= (string) $y === (string) $annee ? 'selected' : '' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
	</div>
</div>
<?php if ( ! empty( $attente ) ) : ?>
	<p class="help">⏳ <?= (int) $attente ?> écriture(s) attendent au <a href="<?= e( url( 'comptabilite/brouillard' ) ) ?>">journal temporaire</a>. Elles ne sont pas encore en comptabilité : ni cet écran, ni les résultats analytiques ne les voient. C'est normal, et c'est souvent l'explication d'un montant qu'on croit manquant ici.</p>
<?php endif; ?>
<?php if ( $fkcVerrouillees ) : ?>
	<p class="help">🔒 <?= (int) $fkcVerrouillees ?> ligne(s) de cette page appartiennent à un exercice clôturé : leurs affectations sont figées, comme les écritures.</p>
<?php endif; ?>

<?php foreach ( $axes as $a ) : $aid = (int) $a['id']; ?>
<template id="fkc-aff-axe-<?= $aid ?>"><option value="">—</option><?php foreach ( ( $valeursParAxe[ $aid ] ?? array() ) as $v ) : ?><option value="<?= (int) $v['id'] ?>"><?= e( $v['libelle'] ) ?></option><?php endforeach; ?></template>
<?php endforeach; ?>

<form method="post" action="<?= e( url( 'analytique/affectations' ) ) ?>" id="fkc-aff-form">
	<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>"><input type="hidden" name="page" value="<?= (int) $page ?>"><?php if ( $restant ) : ?><input type="hidden" name="restant" value="1"><?php endif; ?>
	<?php if ( $lignes ) : ?>
	<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 8px">
		<input type="search" id="fkc-aff-filtre" placeholder="Filtrer cette page : libellé, compte, pièce…" style="flex:1;min-width:200px;max-width:420px" aria-label="Filtrer les lignes de la page">
		<span class="muted" id="fkc-aff-modif" aria-live="polite"></span>
	</div>
	<?php if ( $fkcCles && count( $lignes ) > $fkcVerrouillees ) : ?>
	<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 8px;padding:8px 10px;border:1px dashed var(--line);border-radius:10px">
		<span class="muted">⚖️ Lignes cochées :</span>
		<select name="repartition_id" aria-label="Clé de répartition à appliquer" style="width:auto;flex:0 1 380px;min-width:0;max-width:100%"><option value="">— choisir une clé —</option><?php foreach ( $cles as $c ) : ?><option value="<?= (int) $c['id'] ?>"><?= e( $c['libelle'] ) ?></option><?php endforeach; ?></select>
		<button class="btn btn-ghost btn-sm" type="submit" id="fkc-aff-cle" formaction="<?= e( url( 'analytique/affectations/appliquer-cle' ) ) ?>">Appliquer la clé</button>
		<span class="muted" style="font-size:12px">Remplace, sur l'axe de la clé, l'affectation ou la ventilation existante.</span>
	</div>
	<?php endif; ?>
	<?php endif; ?>
	<div class="card card-flush" style="overflow-x:auto"><table class="table">
		<thead><tr><?php if ( $fkcCles ) : ?><th style="width:28px"><input type="checkbox" id="fkc-aff-tout" aria-label="Tout cocher" style="width:auto;margin:0"></th><?php endif; ?><th>Date</th><th>Pièce</th><th>Libellé</th><th class="num">Montant</th><?php foreach ( $axes as $a ) : ?><th title="<?= e( $a['libelle'] ) ?>"><?= e( $a['code'] ) ?></th><?php endforeach; ?></tr></thead>
		<tbody>
		<?php if ( ! $lignes ) : ?><tr><td colspan="<?= 4 + count( $axes ) + ( $fkcCles ? 1 : 0 ) ?>" class="empty"><?= $restant ? 'Aucune ligne à affecter sur cet exercice : tout est déjà rattaché à au moins un axe.' : 'Aucune ligne de gestion (classes 6, 7 ou 8) sur cette période.' ?></td></tr>
		<?php else : foreach ( $lignes as $l ) :
			$lid = (int) $l['id']; $cur = $affect[ $lid ] ?? array(); $mt = $l['debit'] > 0 ? $l['debit'] : $l['credit']; $fige = ! empty( $verrou[ $lid ] );
			$cherche = mb_strtolower( $l['libelle'] . ' ' . $l['numero'] . ' ' . $l['compte_libelle'] . ' ' . $l['piece'] ); ?>
			<tr data-q="<?= e( $cherche ) ?>"<?= $fige ? ' class="muted"' : '' ?>>
				<?php if ( $fkcCles ) : ?><td><?php if ( ! $fige ) : ?><input type="checkbox" name="lignes[]" value="<?= $lid ?>" class="fkc-aff-coche" aria-label="Choisir cette ligne" style="width:auto;margin:0"><?php endif; ?></td><?php endif; ?>
				<td class="code"><?= $fige ? '🔒 ' : '' ?><?= e( date( 'd/m', strtotime( $l['date_ecriture'] ) ) ) ?></td>
				<td class="code"><?= e( $l['piece'] ?: '—' ) ?></td>
				<td><span title="<?= e( $l['compte_libelle'] ) ?>"><?= e( mb_strimwidth( (string) $l['libelle'], 0, 32, '…' ) ) ?></span> <span class="modbadge <?= 'produit' === $l['sens'] ? 'b-on' : '' ?>" style="font-size:.7em"><?= e( $l['numero'] ) ?></span>
					<a class="fkc-aff-nav" href="<?= e( url( 'analytique/affectations/' . $lid . '/ventiler?retour=' . rawurlencode( $fkcRetour ) ) ) ?>" title="Ventiler en pourcentages" style="text-decoration:none;margin-left:2px">⚖️</a></td>
				<td class="num"><?= e( fkc_money( $mt ) ) ?></td>
				<?php foreach ( $axes as $a ) : $aid = (int) $a['id']; $sel = (int) ( $cur[ $aid ] ?? 0 ); $vp = $ventil[ $lid ][ $aid ] ?? array(); ?>
					<?php if ( $vp ) : $fkcTip = array(); foreach ( $vp as $vv => $pp ) { $fkcTip[] = ( $libelles[ $aid ][ $vv ] ?? '#' . $vv ) . ' ' . rtrim( rtrim( number_format( $pp['pourcentage'], 2, ',', '' ), '0' ), ',' ) . ' %'; } ?>
					<td><a class="btn btn-ghost btn-sm fkc-aff-nav" href="<?= e( url( 'analytique/affectations/' . $lid . '/ventiler?axe=' . $aid . '&retour=' . rawurlencode( $fkcRetour ) ) ) ?>" title="<?= e( implode( ' · ', $fkcTip ) ) ?>" style="white-space:nowrap">⚖️ <?= count( $vp ) ?> parts</a></td>
					<?php continue; endif; ?>
					<td><select name="aff[<?= $lid ?>][<?= $aid ?>]" data-axe="<?= $aid ?>" data-init="<?= $sel ?>" style="width:100%;min-width:120px;max-width:170px" aria-label="<?= e( $a['libelle'] ) ?>"<?= $fige ? ' disabled' : '' ?>>
						<option value="">—</option>
						<?php if ( $sel ) : ?><option value="<?= $sel ?>" selected><?= e( $libelles[ $aid ][ $sel ] ?? ( '#' . $sel ) ) ?></option><?php endif; ?>
					</select></td>
				<?php endforeach; ?>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
	<?php if ( $pages > 1 ) : ?>
	<nav style="display:flex;gap:6px;align-items:center;justify-content:center;flex-wrap:wrap;margin-top:10px" aria-label="Pages">
		<?php if ( $page > 1 ) : ?><a class="btn btn-ghost btn-sm fkc-aff-nav" href="<?= e( $fkcQs( $page - 1 ) ) ?>">← Précédente</a><?php endif; ?>
		<span class="muted">Page <?= (int) $page ?> / <?= (int) $pages ?> · <?= (int) $parPage ?> lignes par page</span>
		<?php if ( $page < $pages ) : ?><a class="btn btn-ghost btn-sm fkc-aff-nav" href="<?= e( $fkcQs( $page + 1 ) ) ?>">Suivante →</a><?php endif; ?>
	</nav>
	<?php endif; ?>
	<?php if ( $lignes && count( $lignes ) > $fkcVerrouillees ) : ?><div class="actions"><button class="btn btn-primary" type="submit">Enregistrer les affectations</button></div><?php endif; ?>
	<input type="hidden" name="_fin" value="1">
</form>
<p class="help">⚖️ Une ligne commune à plusieurs sections (loyer, électricité…) se <strong>ventile en pourcentages</strong> : bouton ⚖️ de la ligne, ou une clé de répartition appliquée aux lignes cochées. Seules les valeurs modifiées sont enregistrées, et chaque lot est tracé au journal d'audit. Pour l'axe Division, les valeurs sont les divisions ; les autres axes utilisent leurs valeurs (onglet Valeurs). Ces affectations alimentent les résultats par axe et le Reporting BI.</p>
<script>
(function () {
	var form = document.getElementById('fkc-aff-form'); if (!form) { return; }
	/* Liste complète versée au premier toucher, valeur actuelle conservée. */
	function remplir(s) {
		if (s.dataset.plein) { return; }
		var t = document.getElementById('fkc-aff-axe-' + s.dataset.axe); if (!t) { return; }
		var v = s.value, cur = s.options[s.selectedIndex], garder = null;
		if (v && cur) { garder = cur.cloneNode(true); }
		s.innerHTML = ''; s.appendChild(t.content.cloneNode(true));
		if (v && !s.querySelector('option[value="' + v + '"]') && garder) { s.appendChild(garder); }
		s.value = v; s.dataset.plein = '1';
	}
	function compter() {
		var n = 0;
		form.querySelectorAll('select[data-axe]').forEach(function (s) { if (String(s.value || 0) !== String(s.dataset.init || 0)) { n++; } });
		var m = document.getElementById('fkc-aff-modif'); if (m) { m.textContent = n ? n + ' modification(s) non enregistrée(s)' : ''; }
		return n;
	}
	form.addEventListener('focusin', function (e) { if (e.target.matches('select[data-axe]')) { remplir(e.target); } });
	form.addEventListener('pointerdown', function (e) { if (e.target.matches('select[data-axe]')) { remplir(e.target); } });
	form.addEventListener('change', compter);
	var envoi = false; form.addEventListener('submit', function () { envoi = true; });
	/* Changer de page sans enregistrer : on prévient. */
	document.querySelectorAll('.fkc-aff-nav').forEach(function (a) {
		a.addEventListener('click', function (e) {
			if (!compter()) { return; }
			if (confirm('Des modifications ne sont pas enregistrées sur cette page. Les abandonner ?')) { envoi = true; } else { e.preventDefault(); }
		});
	});
	window.addEventListener('beforeunload', function (e) { if (!envoi && compter()) { e.preventDefault(); e.returnValue = ''; } });
	var tout = document.getElementById('fkc-aff-tout');
	if (tout) { tout.addEventListener('change', function () {
		form.querySelectorAll('.fkc-aff-coche').forEach(function (c) { if (c.closest('tr').style.display !== 'none') { c.checked = tout.checked; } });
	}); }
	var bc = document.getElementById('fkc-aff-cle');
	if (bc) { bc.addEventListener('click', function (e) {
		var n = form.querySelectorAll('.fkc-aff-coche:checked').length, cle = form.querySelector('select[name="repartition_id"]');
		if (!n || !cle.value) { e.preventDefault(); alert('Cochez au moins une ligne et choisissez une clé.'); return; }
		if (!confirm('Appliquer « ' + cle.options[cle.selectedIndex].text + ' » à ' + n + ' ligne(s) ?' + (compter() ? '\n\nLes autres modifications non enregistrées de la page seront perdues.' : ''))) { e.preventDefault(); return; }
		envoi = true;
	}); }
	var f = document.getElementById('fkc-aff-filtre');
	if (f) { f.addEventListener('input', function () {
		var q = f.value.trim().toLowerCase();
		form.querySelectorAll('tbody tr[data-q]').forEach(function (tr) { tr.style.display = !q || tr.dataset.q.indexOf(q) !== -1 ? '' : 'none'; });
	}); }
}());
</script>
