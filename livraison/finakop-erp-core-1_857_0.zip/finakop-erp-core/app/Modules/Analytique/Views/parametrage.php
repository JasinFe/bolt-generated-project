<?php
/**
 * ANALYTIQUE → PARAMÉTRAGE (revu 1.822.0).
 *
 * Ne reste que ce qui agit réellement. L'analytique suit les exercices
 * COMPTABLES ; les anciens « exercices analytiques » sont affichés sans effet.
 *
 * @var array $exercices @var array $params @var array $annees @var array $comptables @var string $courant @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcLib = function ( $a ) { return class_exists( 'FKC_Exercice' ) ? FKC_Exercice::libelle( $a ) : (string) $a; };
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'parametrage' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Exercice affiché par défaut</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'analytique/parametrage/parametres' ) ) ?>" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0;min-width:240px"><span>À l'ouverture des écrans analytiques</span>
				<select name="exercice_defaut">
					<option value="">L'exercice en cours (<?= e( $fkcLib( $courant ) ) ?>)</option>
					<?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= (string) $params['exercice_defaut'] === (string) $y ? 'selected' : '' ?>><?= e( $fkcLib( $y ) ) ?></option><?php endforeach; ?>
				</select></label>
			<button class="btn btn-primary" type="submit">Enregistrer</button>
		</form>
		<p class="help" style="margin-bottom:0">Utile pendant la clôture, pour travailler sur l'exercice précédent sans le rechoisir à chaque écran. Le sélecteur « Exercice » de chaque écran reste disponible.</p>
	</div>
</div>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
		<h2>Exercices de référence</h2>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/exercices' ) ) ?>">Gérer les exercices comptables →</a>
	</div>
	<p class="help" style="padding:0 16px">L'analytique découpe ses périodes sur les exercices <strong>comptables</strong> — y compris un exercice décalé. Un exercice clôturé fige les affectations de ses lignes.</p>
	<div style="overflow-x:auto"><table class="table">
		<thead><tr><th>Exercice</th><th>Début</th><th>Fin</th><th>Statut</th></tr></thead>
		<tbody>
		<?php if ( ! $comptables ) : ?><tr><td colspan="4" class="empty">Aucun exercice comptable ouvert.</td></tr>
		<?php else : foreach ( $comptables as $ex ) : ?>
			<tr><td><strong><?= (int) $ex['annee'] ?></strong></td><td class="code"><?= e( $ex['periode_debut'] ) ?></td><td class="code"><?= e( $ex['periode_fin'] ) ?></td>
				<td><span class="modbadge <?= empty( $ex['cloture_annuelle'] ) ? 'b-on' : 'b-off' ?>"><?= empty( $ex['cloture_annuelle'] ) ? 'Ouvert' : '🔒 Clôturé' ?></span></td></tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
</div>

<?php if ( $exercices ) : ?>
<div class="card card-flush">
	<div class="card-head"><h2>Anciens exercices analytiques <span class="tag">sans effet</span></h2></div>
	<p class="help" style="padding:0 16px">Ces périodes avaient été saisies ici, mais aucun calcul ne les a jamais utilisées. Vous pouvez les supprimer.</p>
	<div style="overflow-x:auto"><table class="table">
		<thead><tr><th>Libellé</th><th>Début</th><th>Fin</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $exercices as $ex ) : ?>
			<tr class="muted"><td><?= e( $ex['libelle'] ) ?></td><td class="code"><?= e( $ex['date_debut'] ) ?></td><td class="code"><?= e( $ex['date_fin'] ) ?></td>
				<td class="right"><form method="post" action="<?= e( url( 'analytique/parametrage/exercices/' . (int) $ex['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer cette période sans effet ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Supprimer</button></form></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
</div>
<?php endif; ?>
