<?php /** @var string $annee @var array $annees @var array $lignes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$t = array( 'p' => 0.0, 'c' => 0.0, 'r' => 0.0 ); foreach ( $lignes as $l ) { $t['p'] += $l['produits']; $t['c'] += $l['charges']; $t['r'] += $l['resultat']; } ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'centres_profit' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Rentabilité par centre de profit — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th>Centre de profit</th><th class="num">Produits</th><th class="num">Charges</th><th class="num">Résultat</th><th class="num">Marge</th></tr></thead>
	<tbody>
	<?php if ( ! $lignes ) : ?><tr><td colspan="6" class="empty">Aucun centre de profit. Classez vos divisions en « Centre de profit » dans l'onglet Divisions.</td></tr>
	<?php else : foreach ( $lignes as $l ) : $marge = $l['produits'] > 0 ? round( $l['resultat'] / $l['produits'] * 100, 1 ) : null; ?>
		<tr>
			<td class="code"><?= e( $l['code'] ) ?></td>
			<td><?= e( $l['libelle'] ) ?></td>
			<td class="num"><?= e( fkc_money( $l['produits'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $l['charges'] ) ) ?></td>
			<td class="num" style="color:<?= $l['resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= e( fkc_money( $l['resultat'] ) ) ?></td>
			<td class="num"><?= null === $marge ? '—' : e( $marge ) . ' %' ?></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $lignes ) : ?><tfoot><tr class="total"><td></td><td class="right">Total</td><td class="num"><?= e( fkc_money( $t['p'] ) ) ?></td><td class="num"><?= e( fkc_money( $t['c'] ) ) ?></td><td class="num"><?= e( fkc_money( $t['r'] ) ) ?></td><td class="num"><?= $t['p']>0?e( round( $t['r']/$t['p']*100,1 ) ).' %':'—' ?></td></tr></tfoot><?php endif; ?>
</table></div>
