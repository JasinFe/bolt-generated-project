<?php /** @var string $tab @var string $annee @var array $annees @var array $res @var array $divisions @var string|null $flash @var array|null $rapprochement */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$lignes = $res['lignes']; $ni = $res['non_impute']; $tot = $res['totaux'];
$typeLabels = FKC_Division::types();
$avecHao = abs( (float) ( $tot['hao'] ?? 0 ) ) >= 0.5;
$fkcDet = function ( $valeur, $nature = '' ) use ( $annee ) { return url( 'analytique/detail?axe=DIV&valeur=' . (int) $valeur . '&annee=' . $annee . ( $nature ? '&nature=' . $nature : '' ) ); };
$pct = function ( $part, $whole ) { $whole = (float) $whole; return $whole != 0 ? max( 0, min( 100, round( abs( $part ) / abs( $whole ) * 100 ) ) ) : 0; };
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="bar">
	<div>
		<span class="stat-label">Contrôle de gestion</span>
		<strong style="font-size:17px">Résultat par division — Exercice <?= e( $annee ) ?></strong>
	</div>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/export?axe=DIV&annee=' . $annee ) ) ?>" style="margin-left:auto">⬇ Exporter (CSV)</a>
	<form method="get" action="<?= e( url( 'analytique' ) ) ?>" class="dash-year">
		<select name="annee" onchange="this.form.submit()">
			<?php foreach ( $annees as $yy ) : ?><option value="<?= e( $yy ) ?>" <?= (string) $yy === (string) $annee ? 'selected' : '' ?>>Exercice <?= e( $yy ) ?></option><?php endforeach; ?>
		</select>
	</form>
</div>

<?php if ( ! $divisions ) : ?>
	<div class="card"><div class="card-body" style="text-align:center;padding:34px">
		<div style="font-size:38px">🏗️</div>
		<h2 style="font-family:Syne,sans-serif;margin:8px 0">Aucune division définie</h2>
		<p class="muted">Créez vos divisions (business units, centres de coûts, projets…) puis imputez-y vos charges et produits.</p>
		<a class="btn btn-primary" href="<?= e( url( 'analytique/divisions/nouvelle' ) ) ?>" style="margin-top:10px">+ Créer une division</a>
	</div></div>
<?php else : ?>

<div class="stats kpi">
	<div class="stat kpi-ca"><span class="stat-label">Produits imputés</span><span class="stat-value"><?= e( fkc_money( $tot['produits'] ) ) ?><small> F CFA</small></span></div>
	<div class="stat kpi-neg"><span class="stat-label">Charges imputées</span><span class="stat-value"><?= e( fkc_money( $tot['charges'] ) ) ?><small> F CFA</small></span></div>
	<div class="stat <?= $tot['resultat'] >= 0 ? 'kpi-pos' : 'kpi-neg' ?>"><span class="stat-label"><?= $avecHao ? 'Résultat des activités ordinaires' : 'Résultat global' ?></span><span class="stat-value"><?= e( fkc_money( $tot['resultat'] ) ) ?><small> F CFA</small></span></div>
	<?php if ( $avecHao ) : /* 1.822.0 : la classe 8 n'est plus ignorée. */ ?>
		<div class="stat"><span class="stat-label">Hors activités ordinaires (cl. 8)</span><span class="stat-value"><?= e( fkc_money( $tot['hao'] ) ) ?><small> F CFA</small></span></div>
		<div class="stat <?= $tot['resultat_net'] >= 0 ? 'kpi-pos' : 'kpi-neg' ?>"><span class="stat-label">Résultat net</span><span class="stat-value"><?= e( fkc_money( $tot['resultat_net'] ) ) ?><small> F CFA</small></span></div>
	<?php endif; ?>
</div>
<?php
/*
 * RAPPROCHEMENT AVEC LE COMPTE DE RÉSULTAT (1.822.0) : le total analytique
 * (imputé + non imputé) doit égaler le résultat net comptable. On l'affiche
 * au lieu de le supposer.
 */
if ( ! empty( $rapprochement ) ) : $fkcOk = abs( (float) $rapprochement['ecart'] ) < 1; ?>
	<p class="help" style="margin:-4px 0 12px;<?= $fkcOk ? '' : 'color:var(--danger)' ?>">
		<?= $fkcOk ? '✓' : '⚠' ?> Rapproché du compte de résultat : résultat net comptable <?= e( fkc_money( $rapprochement['cr'] ) ) ?> F CFA
		<?= $fkcOk ? '— identique au total analytique (divisions + non imputé).' : '— écart de ' . e( fkc_money( $rapprochement['ecart'] ) ) . ' F CFA avec le total analytique.' ?>
	</p>
<?php endif; ?>

<?php foreach ( $lignes as $l ) : $rp = $l['resultat'] >= 0; ?>
	<div class="divcard <?= $rp ? 'ok' : 'ko' ?>">
		<div class="divcard-head">
			<div>
				<a class="divcard-name" href="<?= e( $fkcDet( $l['id'] ) ) ?>" title="Voir les écritures">🔎 <?= e( $l['libelle'] ) ?></a>
				<span class="divcard-type"><?= e( $typeLabels[ $l['type'] ] ?? $l['type'] ) ?> · <?= e( $l['code'] ) ?><?= isset( $l['actif'] ) && ! $l['actif'] ? ' · <strong>inactive</strong>' : '' ?></span>
			</div>
			<span class="divcard-res <?= $rp ? 'pos' : 'neg' ?>"><?= e( fkc_money( $l['resultat'] ) ) ?> F CFA</span>
		</div>
		<a class="divrow" href="<?= e( $fkcDet( $l['id'], 'produit' ) ) ?>"><span>Produits</span><strong class="pos"><?= e( fkc_money( $l['produits'] ) ) ?> F CFA</strong></a>
		<a class="divrow" href="<?= e( $fkcDet( $l['id'], 'charge' ) ) ?>"><span>Charges</span><strong class="neg"><?= e( fkc_money( $l['charges'] ) ) ?> F CFA</strong></a>
		<?php if ( abs( (float) ( $l['hao'] ?? 0 ) ) >= 0.5 ) : ?><div class="divrow"><span>Hors activités ordinaires</span><strong><?= e( fkc_money( $l['hao'] ) ) ?> F CFA</strong></div>
		<div class="divrow"><span><strong>Résultat net</strong> <span class="muted" style="font-size:12px">(en-tête : activités ordinaires)</span></span><strong class="<?= $l['resultat_net'] >= 0 ? 'pos' : 'neg' ?>"><?= e( fkc_money( $l['resultat_net'] ) ) ?> F CFA</strong></div><?php endif; ?>
		<div class="cr-bar"><span class="cr-bar-fill" style="width:<?= e( $pct( $l['charges'], $l['produits'] ) ) ?>%"></span></div>
	</div>
<?php endforeach; ?>

<?php if ( $ni['produits'] != 0 || $ni['charges'] != 0 || abs( (float) ( $ni['hao'] ?? 0 ) ) >= 0.5 ) : ?>
	<div class="divcard ni">
		<div class="divcard-head">
			<div><a class="divcard-name" href="<?= e( $fkcDet( 0 ) ) ?>" title="Voir les écritures">🔎 Non imputé</a><span class="divcard-type">Mouvements sans division</span></div>
			<span class="divcard-res <?= $ni['resultat'] >= 0 ? 'pos' : 'neg' ?>"><?= e( fkc_money( $ni['resultat'] ) ) ?> F CFA</span>
		</div>
		<a class="divrow" href="<?= e( $fkcDet( 0, 'produit' ) ) ?>"><span>Produits</span><strong class="pos"><?= e( fkc_money( $ni['produits'] ) ) ?> F CFA</strong></a>
		<a class="divrow" href="<?= e( $fkcDet( 0, 'charge' ) ) ?>"><span>Charges</span><strong class="neg"><?= e( fkc_money( $ni['charges'] ) ) ?> F CFA</strong></a>
		<?php if ( abs( (float) ( $ni['hao'] ?? 0 ) ) >= 0.5 ) : ?><div class="divrow"><span>Hors activités ordinaires</span><strong><?= e( fkc_money( $ni['hao'] ) ) ?> F CFA</strong></div><?php endif; ?>
		<p class="help" style="margin:8px 0 0">Imputez ces montants à une division — dans <a href="<?= e( url( 'analytique/affectations?annee=' . $annee . '&restant=1' ) ) ?>">Affectations</a>, par une <a href="<?= e( url( 'analytique/regles?annee=' . $annee ) ) ?>">règle</a>, ou dès la saisie — pour un contrôle de gestion complet.</p>
	</div>
<?php endif; ?>

<?php endif; ?>

<style>
.divcard{background:var(--panel);border:1px solid var(--line);border-radius:13px;padding:16px 18px;margin-bottom:13px;border-left:3px solid var(--line2)}
.divcard.ok{border-left-color:var(--ok)} .divcard.ko{border-left-color:var(--danger)} .divcard.ni{border-left-color:var(--muted2);opacity:.92}
.divcard-head{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
.divcard-name{display:block;font-family:Syne,sans-serif;font-weight:800;font-size:16px}
.divcard-type{display:block;font-size:11px;color:var(--muted2);text-transform:uppercase;letter-spacing:.4px;margin-top:3px}
.divcard-res{font-family:Syne,sans-serif;font-weight:800;font-size:18px}
.divcard-res.pos{color:var(--ok)} .divcard-res.neg{color:var(--danger)}
.divrow{display:flex;justify-content:space-between;padding:6px 0;font-size:13.5px;border-bottom:1px solid var(--line);color:inherit;text-decoration:none}
a.divrow:hover span{text-decoration:underline} a.divcard-name{color:inherit;text-decoration:none} a.divcard-name:hover{text-decoration:underline}
.divrow:last-of-type{border-bottom:none}
.divrow strong{font-weight:700} .divrow .pos{color:var(--ok)} .divrow .neg{color:var(--danger)}
</style>
