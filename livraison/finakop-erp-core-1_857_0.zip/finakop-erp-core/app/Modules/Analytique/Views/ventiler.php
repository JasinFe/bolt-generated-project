<?php
/**
 * ANALYTIQUE → VENTILER UNE LIGNE EN POURCENTAGES (1.823.0).
 *
 * Un axe à la fois (onglets). Les parts totalisent 100 % ; le montant de
 * chaque part s'affiche en direct. Une clé de l'axe peut pré-remplir le
 * tableau (calculée pour l'exercice de la ligne).
 *
 * @var array $l @var float $montant @var string $annee @var array $axes @var array|null $axe
 * @var array $valeurs [id => libellé] @var array $vent @var array $parts @var int $unique
 * @var bool $verrou @var array $cles @var string $retour @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcAid = $axe ? (int) $axe['id'] : 0;
$fkcBase = 'analytique/affectations/' . (int) $l['id'] . '/ventiler';
$fkcRet = '' !== $retour ? '&retour=' . rawurlencode( $retour ) : '';
$fkcPct = function ( $p ) { return rtrim( rtrim( number_format( (float) $p, 2, ',', '' ), '0' ), ',' ); };
// Lignes du tableau : la ventilation existante, sinon l'affectation unique à 100 %, sinon deux lignes vides.
$fkcRows = array();
foreach ( $parts as $v => $p ) { $fkcRows[] = array( (int) $v, (float) $p['pourcentage'] ); }
if ( ! $fkcRows && $unique ) { $fkcRows[] = array( $unique, 100.0 ); }
while ( count( $fkcRows ) < 2 ) { $fkcRows[] = array( 0, 0.0 ); }
$fkcRep = '';
foreach ( $parts as $p ) { if ( ! empty( $p['repartition_id'] ) ) { $fkcRep = (int) $p['repartition_id']; } }
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'affectations' ) ); ?>
<?php if ( $flash ) : ?><div class="alert <?= 0 === strpos( (string) $flash, 'Refusé' ) ? 'alert-err' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>

<p style="margin:0 0 10px"><a href="<?= e( url( '' !== $retour ? $retour : 'analytique/affectations?annee=' . $annee ) ) ?>">← Affectations</a></p>

<div class="card">
	<div class="card-body" style="display:flex;gap:18px;flex-wrap:wrap;align-items:baseline">
		<div><span class="muted" style="font-size:12px">Ligne</span><br><strong><?= e( (string) ( $l['libelle'] ?: $l['ecriture_libelle'] ) ) ?></strong></div>
		<div><span class="muted" style="font-size:12px">Date · pièce</span><br><span class="code"><?= e( date( 'd/m/Y', strtotime( $l['date_ecriture'] ) ) ) ?></span> · <?= e( $l['piece'] ?: '—' ) ?></div>
		<div><span class="muted" style="font-size:12px">Compte</span><br><span class="code"><?= e( $l['numero'] ) ?></span> <?= e( $l['compte_libelle'] ) ?></div>
		<div><span class="muted" style="font-size:12px">Montant</span><br><strong><?= e( fkc_money( $montant ) ) ?> F CFA</strong></div>
		<?php if ( $verrou ) : ?><div><span class="tag" style="color:var(--danger)">🔒 exercice clôturé — lecture seule</span></div><?php endif; ?>
	</div>
</div>

<?php if ( ! $axe ) : ?>
	<p class="help">Aucun axe analytique actif.</p>
<?php else : ?>
<nav style="display:flex;gap:6px;flex-wrap:wrap;margin:12px 0" aria-label="Axes">
	<?php foreach ( $axes as $a ) : $n = count( $vent[ (int) $a['id'] ] ?? array() ); ?>
		<a class="btn btn-sm <?= (int) $a['id'] === $fkcAid ? 'btn-primary' : 'btn-ghost' ?>" href="<?= e( url( $fkcBase . '?axe=' . (int) $a['id'] . $fkcRet ) ) ?>"><?= e( $a['libelle'] ) ?><?= $n ? ' · ⚖️ ' . $n : '' ?></a>
	<?php endforeach; ?>
</nav>

<div class="card">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
		<h2>⚖️ Ventilation · <?= e( $axe['libelle'] ) ?></h2>
		<?php if ( $parts ) : ?><span class="tag">ventilée · <?= count( $parts ) ?> parts</span><?php elseif ( $unique ) : ?><span class="tag">affectée à une seule valeur</span><?php else : ?><span class="tag">non imputée sur cet axe</span><?php endif; ?>
	</div>
	<div class="card-body">
		<?php if ( ! $valeurs ) : ?>
			<p class="muted" style="margin:0">Cet axe n'a aucune valeur active. Ajoutez-en dans l'onglet Valeurs.</p>
		<?php else : ?>
		<?php if ( $cles && ! $verrou ) : ?>
			<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
				<span class="muted">Pré-remplir avec une clé :</span>
				<?php foreach ( $cles as $c ) : ?>
					<?php if ( $c['ok'] ) : ?>
						<button type="button" class="btn btn-ghost btn-sm fkc-v-cle" data-rep="<?= (int) $c['id'] ?>" data-parts="<?= e( json_encode( $c['parts'] ) ) ?>" title="<?= e( $c['libelle'] ) ?>"><?= e( $c['code'] ) ?><?= 'dynamique' === $c['type'] ? ' (poids ' . e( $annee ) . ')' : '' ?></button>
					<?php else : ?>
						<span class="btn btn-ghost btn-sm" style="opacity:.55;cursor:not-allowed" title="<?= e( $c['msg'] ) ?>"><?= e( $c['code'] ) ?> — inapplicable</span>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<form method="post" action="<?= e( url( $fkcBase ) ) ?>" id="fkc-v-form">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="axe_id" value="<?= $fkcAid ?>"><input type="hidden" name="retour" value="<?= e( $retour ) ?>">
			<input type="hidden" name="repartition_id" id="fkc-v-rep" value="<?= e( (string) $fkcRep ) ?>">
			<div style="overflow-x:auto"><table class="table" id="fkc-v-table">
				<thead><tr><th>Valeur</th><th class="num" style="width:130px">Part (%)</th><th class="num" style="width:160px">Montant</th><th style="width:40px"></th></tr></thead>
				<tbody>
				<?php foreach ( $fkcRows as $r ) : ?>
					<tr>
						<td><select name="valeur[]" style="width:100%;min-width:160px" aria-label="Valeur"<?= $verrou ? ' disabled' : '' ?>><option value="">—</option>
							<?php foreach ( $valeurs as $vid => $lib ) : ?><option value="<?= (int) $vid ?>" <?= $vid === $r[0] ? 'selected' : '' ?>><?= e( $lib ) ?></option><?php endforeach; ?>
							<?php if ( $r[0] && ! isset( $valeurs[ $r[0] ] ) ) : ?><option value="<?= (int) $r[0] ?>" selected>#<?= (int) $r[0] ?> (désactivée)</option><?php endif; ?>
						</select></td>
						<td class="num"><input type="number" name="pct[]" step="0.01" min="0" max="100" value="<?= $r[1] > 0 ? e( rtrim( rtrim( number_format( $r[1], 4, '.', '' ), '0' ), '.' ) ) : '' ?>" style="width:110px;text-align:right" aria-label="Part en pourcentage"<?= $verrou ? ' disabled' : '' ?>></td>
						<td class="num fkc-v-mt">—</td>
						<td><?php if ( ! $verrou ) : ?><button type="button" class="btn btn-ghost btn-sm fkc-v-suppr" aria-label="Retirer cette part">✕</button><?php endif; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr class="total"><td class="right">Total</td><td class="num" id="fkc-v-total">—</td><td class="num" id="fkc-v-totmt">—</td><td></td></tr></tfoot>
			</table></div>
			<?php if ( ! $verrou ) : ?>
			<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px">
				<button type="button" class="btn btn-ghost btn-sm" id="fkc-v-ajout">+ Ajouter une part</button>
				<button type="button" class="btn btn-ghost btn-sm" id="fkc-v-egal">Parts égales</button>
				<span style="flex:1"></span>
				<?php if ( $parts ) : ?><button class="btn btn-ghost btn-sm" type="submit" name="action" value="retirer" formnovalidate onclick="return confirm('Retirer la ventilation ? La ligne ne sera plus imputée sur cet axe.')" style="color:var(--danger)">Retirer la ventilation</button><?php endif; ?>
				<button class="btn btn-primary" type="submit" name="action" value="enregistrer" id="fkc-v-ok">Enregistrer la ventilation</button>
			</div>
			<p class="help" id="fkc-v-msg" style="margin:8px 0 0" aria-live="polite"></p>
			<?php endif; ?>
		</form>
		<?php endif; ?>
		<p class="help" style="margin-bottom:0">La ligne comptable n'est ni éclatée ni modifiée : la ventilation vit dans l'analytique seulement. Elle remplace, <strong>sur cet axe</strong>, l'affectation existante ; les autres axes ne bougent pas. Une seule valeur à 100 % est enregistrée comme une affectation simple.</p>
	</div>
</div>
<script>
(function () {
	var form = document.getElementById('fkc-v-form'); if (!form) { return; }
	var MT = <?= json_encode( round( $montant, 2 ) ) ?>, tb = document.querySelector('#fkc-v-table tbody');
	var fmt = function (n) { return Math.round(n).toLocaleString('fr-FR').replace(/ /g, ' '); };
	var rep = document.getElementById('fkc-v-rep'), ok = document.getElementById('fkc-v-ok'), msg = document.getElementById('fkc-v-msg');
	function calc() {
		var t = 0;
		tb.querySelectorAll('tr').forEach(function (tr) {
			var p = parseFloat((tr.querySelector('input[name="pct[]"]').value || '0').replace(',', '.')) || 0;
			var v = tr.querySelector('select').value;
			t += v ? p : 0;
			tr.querySelector('.fkc-v-mt').textContent = v && p ? fmt(MT * p / 100) + ' F' : '—';
		});
		t = Math.round(t * 100) / 100;
		var el = document.getElementById('fkc-v-total'); el.textContent = t.toLocaleString('fr-FR') + ' %';
		var bon = Math.abs(t - 100) <= 0.01; el.style.color = bon ? 'var(--ok)' : 'var(--orange)';
		document.getElementById('fkc-v-totmt').textContent = fmt(MT * t / 100) + ' F';
		if (ok) { ok.disabled = !bon; }
		if (msg) { msg.textContent = bon ? '' : (t < 100 ? 'Il manque ' + (Math.round((100 - t) * 100) / 100).toLocaleString('fr-FR') + ' point(s) pour atteindre 100 %.' : 'Excédent de ' + (Math.round((t - 100) * 100) / 100).toLocaleString('fr-FR') + ' point(s).'); }
	}
	function ligne(v, p) {
		var modele = tb.querySelector('tr'), tr = modele.cloneNode(true);
		tr.querySelector('select').value = v || ''; tr.querySelector('input[name="pct[]"]').value = p || '';
		tb.appendChild(tr); return tr;
	}
	form.addEventListener('input', function () { if (rep) { rep.value = ''; } calc(); });
	form.addEventListener('change', calc);
	tb.addEventListener('click', function (e) {
		var b = e.target.closest('.fkc-v-suppr'); if (!b) { return; }
		if (tb.querySelectorAll('tr').length <= 1) { var tr = b.closest('tr'); tr.querySelector('select').value = ''; tr.querySelector('input').value = ''; }
		else { b.closest('tr').remove(); }
		if (rep) { rep.value = ''; } calc();
	});
	var aj = document.getElementById('fkc-v-ajout'); if (aj) { aj.addEventListener('click', function () { ligne('', ''); calc(); }); }
	var eg = document.getElementById('fkc-v-egal');
	if (eg) { eg.addEventListener('click', function () {
		var rows = Array.prototype.filter.call(tb.querySelectorAll('tr'), function (tr) { return tr.querySelector('select').value; });
		if (!rows.length) { return; }
		var base = Math.floor(10000 / rows.length) / 100, reste = Math.round((100 - base * rows.length) * 100) / 100;
		rows.forEach(function (tr, i) { tr.querySelector('input[name="pct[]"]').value = i === 0 ? Math.round((base + reste) * 100) / 100 : base; });
		if (rep) { rep.value = ''; } calc();
	}); }
	document.querySelectorAll('.fkc-v-cle').forEach(function (b) {
		b.addEventListener('click', function () {
			var parts = JSON.parse(b.getAttribute('data-parts') || '{}'), trs = tb.querySelectorAll('tr');
			for (var i = 1; i < trs.length; i++) { trs[i].remove(); }
			var first = true;
			Object.keys(parts).forEach(function (v) {
				if (first) { trs[0].querySelector('select').value = v; trs[0].querySelector('input[name="pct[]"]').value = Math.round(parts[v] * 10000) / 10000; first = false; }
				else { ligne(v, Math.round(parts[v] * 10000) / 10000); }
			});
			if (rep) { rep.value = b.getAttribute('data-rep'); }
			calc();
		});
	});
	calc();
}());
</script>
<?php endif; ?>
