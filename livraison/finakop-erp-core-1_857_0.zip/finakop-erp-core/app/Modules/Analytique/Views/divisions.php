<?php /** @var string $tab @var array $divisions @var array $types @var string|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="bar">
	<div><span class="stat-label">Sections analytiques</span><strong style="font-size:17px"><?= count( $divisions ) ?> division(s)</strong></div>
	<a class="btn btn-primary btn-sm" href="<?= e( url( 'analytique/divisions/nouvelle' ) ) ?>">+ Nouvelle division</a>
</div>

<div class="card card-flush">
	<table class="table">
		<thead><tr><th>Code</th><th>Libellé</th><th>Type</th><th>Statut</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $divisions ) : ?>
			<tr><td colspan="5" class="muted" style="text-align:center;padding:24px">Aucune division. Créez vos business units, centres de coûts ou projets.</td></tr>
		<?php else : foreach ( $divisions as $d ) : ?>
			<tr>
				<td class="mono"><strong><?= e( $d['code'] ) ?></strong></td>
				<td><?= e( $d['libelle'] ) ?></td>
				<td class="muted"><?= e( $types[ $d['type'] ] ?? $d['type'] ) ?></td>
				<td><span class="modbadge <?= $d['actif'] ? 'b-on' : 'b-off' ?>"><?= $d['actif'] ? 'Active' : 'Inactive' ?></span></td>
				<td class="right">
					<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/divisions/' . $d['id'] . '/modifier' ) ) ?>">Modifier</a>
					<form method="post" action="<?= e( url( 'analytique/divisions/' . $d['id'] . '/basculer' ) ) ?>" style="display:inline">
						<?= FKC_Csrf::field() ?>
						<button class="btn btn-ghost btn-sm" type="submit"><?= $d['actif'] ? 'Désactiver' : 'Réactiver' ?></button>
					</form>
					<?php
					$imp = $impacts[ (int) $d['id'] ] ?? array( 'total' => 0, 'lignes' => 0, 'factures' => 0, 'budgets' => 0 );
					if ( $imp['total'] > 0 ) :
						/*
						 * La division porte quelque chose : la suppression ordinaire
						 * la refusera. On n'offre donc PAS un bouton qui échoue —
						 * on annonce le contenu, et l'administrateur seul dispose du
						 * passage en force, conséquences chiffrées à l'appui.
						 */
						$detail = array();
						if ( $imp['lignes'] )   { $detail[] = $imp['lignes'] . ' ligne(s) d\'écriture'; }
						if ( $imp['factures'] ) { $detail[] = $imp['factures'] . ' facture(s)'; }
						if ( $imp['budgets'] )  { $detail[] = $imp['budgets'] . ' budget(s)'; }
						$detail = implode( ', ', $detail );
						?>
						<span class="muted" style="font-size:.82em" title="Contenu porté par cette division"><?= e( $detail ) ?></span>
						<?php if ( ! empty( $estAdmin ) ) : ?>
							<form method="post" action="<?= e( url( 'analytique/divisions/' . $d['id'] . '/supprimer-quand-meme' ) ) ?>" style="display:inline" onsubmit="return confirm('SUPPRESSION FORCÉE — « <?= e( $d['libelle'] ) ?> »\n\nCette division porte <?= e( $detail ) ?>.\n\nEn continuant :\n· <?= (int) $imp['lignes'] ?> ligne(s) d\'écriture repasseront en « non imputé » — leur imputation analytique sera perdue ;\n· <?= (int) $imp['budgets'] ?> budget(s) seront effacés ;\n· la division disparaîtra des états passés, y compris du comparatif N-1.\n\nLes montants comptables ne bougent pas ; c\'est l\'analytique qui est détruite, et c\'est irréversible.\nL\'opération sera tracée à l\'audit.\n\nSi vous voulez seulement retirer cette division de la saisie, annulez et utilisez « Désactiver ».\n\nConfirmer la suppression forcée ?')">
								<?= FKC_Csrf::field() ?>
								<button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)" title="Réservé à l'administrateur — destruction irréversible de l'imputation analytique">Suppr. quand même</button>
							</form>
						<?php endif; ?>
					<?php else : ?>
						<form method="post" action="<?= e( url( 'analytique/divisions/' . $d['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer la division « <?= e( $d['libelle'] ) ?> » ? Elle n\'a jamais servi : rien ne sera perdu.')">
							<?= FKC_Csrf::field() ?>
							<button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)">Suppr.</button>
						</form>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
<p class="help" style="margin-top:12px"><strong>Désactiver plutôt que supprimer.</strong> Une division désactivée disparaît des sélecteurs de saisie et de la saisie budgétaire, mais garde tout son historique dans les résultats, le contrôle budgétaire et le comparatif N-1 — elle y apparaît marquée « inactive ». Une division qui porte des écritures, des factures ou un budget ne se supprime pas d'un clic : la ligne indique ce qu'elle contient.<?= ! empty( $estAdmin ) ? ' En tant qu\'administrateur, vous disposez de « Suppr. quand même » pour les divisions créées par erreur ou pendant la prise en main — l\'imputation analytique des écritures concernées est alors définitivement perdue, et le geste est tracé à l\'audit.' : ' Seul un administrateur peut forcer leur suppression.' ?></p>
<p class="help" style="margin-top:12px">Une fois vos divisions créées, imputez vos charges et produits depuis la <strong>saisie d'écriture</strong> (colonne Division) et les <strong>factures</strong>. Le résultat par division est consolidé dans l'onglet « Résultat par division » et sur le tableau de bord.</p>
