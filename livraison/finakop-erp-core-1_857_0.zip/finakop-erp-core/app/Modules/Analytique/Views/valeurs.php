<?php /** @var array $axes @var array|null $axe @var array $valeurs @var array $divisions @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$isDiv = $axe && 'DIV' === $axe['code']; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'valeurs' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Valeurs analytiques par axe</span>
	<div style="display:flex;gap:6px;flex-wrap:wrap"><?php foreach ( $axes as $a ) : ?>
		<a class="btn btn-sm <?= ( $axe && (int)$axe['id']===(int)$a['id'] )?'btn-primary':'btn-ghost' ?>" href="<?= e( url( 'analytique/valeurs?axe=' . (int) $a['id'] ) ) ?>"><?= e( $a['code'] ) ?></a>
	<?php endforeach; ?></div>
</div>
<?php if ( ! $axe ) : ?><div class="card"><div class="card-body"><p class="muted" style="margin:0">Aucun axe.</p></div></div>
<?php elseif ( $isDiv ) : ?>
	<div class="card"><div class="card-body"><p class="help" style="margin:0">L'axe <strong>Division</strong> utilise le référentiel des <a href="<?= e( url( 'analytique/divisions' ) ) ?>">divisions</a>. <?= count( $divisions ) ?> division(s) définie(s).</p></div></div>
<?php else : ?>
	<div class="card"><div class="card-head"><h2>Ajouter une valeur · <?= e( $axe['libelle'] ) ?></h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'analytique/valeurs' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?><input type="hidden" name="axe_id" value="<?= (int) $axe['id'] ?>">
			<label class="fld" style="margin:0"><span>Code</span><input type="text" name="code" maxlength="20" required style="width:120px;text-transform:uppercase"></label>
			<label class="fld" style="margin:0;min-width:220px"><span>Libellé</span><input type="text" name="libelle" required></label>
			<label class="fld" style="margin:0"><span>Ordre</span><input type="number" name="ordre" value="0" style="width:80px"></label>
			<button class="btn btn-primary" type="submit">Ajouter</button>
		</form>
	</div></div>
	<div class="card card-flush"><table class="table">
		<thead><tr><th>Code</th><th>Libellé</th><th>Origine</th><th>Statut</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $valeurs ) : ?><tr><td colspan="5" class="empty">Aucune valeur pour cet axe.</td></tr>
		<?php else : foreach ( $valeurs as $v ) : ?>
			<tr><td class="code"><?= e( $v['code'] ) ?></td><td><?= e( $v['libelle'] ) ?></td>
				<td class="muted"><?php if ( empty( $v['source_type'] ) ) : ?>Saisie<?php else : ?><?= e( $v['source_type'] ) ?><?= empty( $v['source_orpheline'] ) ? '' : ' <strong style="color:var(--orange)">— fiche supprimée</strong>' ?><?php endif; ?></td>
				<td><span class="modbadge <?= empty( $v['actif'] ) ? 'b-off' : 'b-on' ?>"><?= empty( $v['actif'] ) ? 'Inactive' : 'Active' ?></span></td>
				<td class="right">
					<form method="post" action="<?= e( url( 'analytique/valeurs/' . (int) $v['id'] . '/basculer' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit"><?= empty( $v['actif'] ) ? 'Réactiver' : 'Désactiver' ?></button></form>
					<?php
					$imp = $impacts[ (int) $v['id'] ] ?? array( 'total' => 0, 'affectations' => 0, 'budgets' => 0, 'cles' => 0 );
					// Une valeur liée au référentiel se comporte comme « portée » :
					// sa suppression ordinaire est refusée, puisqu'elle reviendrait.
					$bloquee = $imp['total'] > 0 || ! empty( $v['source_type'] );
					if ( $bloquee ) :
						$detail = array();
						if ( $imp['affectations'] ) { $detail[] = $imp['affectations'] . ' affectation(s)'; }
						if ( $imp['budgets'] )      { $detail[] = $imp['budgets'] . ' budget(s)'; }
						if ( $imp['cles'] )         { $detail[] = $imp['cles'] . ' clé(s)'; }
						$detail = $detail ? implode( ', ', $detail ) : 'liée au référentiel';
						?>
						<span class="muted" style="font-size:.82em"><?= e( $detail ) ?></span>
						<?php if ( ! empty( $estAdmin ) ) : ?>
							<form method="post" action="<?= e( url( 'analytique/valeurs/' . (int) $v['id'] . '/supprimer-quand-meme' ) ) ?>" style="display:inline" onsubmit="return confirm('SUPPRESSION FORCÉE — « <?= e( $v['libelle'] ) ?> »\n\nSeront détruits : <?= e( $detail ) ?>.\n\n· <?= (int) $imp['affectations'] ?> ligne(s) perdront leur imputation sur cet axe ;\n· <?= (int) $imp['budgets'] ?> budget(s) par valeur seront effacés ;\n· <?= (int) $imp['cles'] ?> clé(s) de répartition seront retirées — une clé amputée cesse de faire 100 % et ne sera plus appliquée aux écritures.<?= empty( $v['source_type'] ) ? '' : '\n\nCette valeur reflète une fiche « ' . e( $v['source_type'] ) . ' » : elle SERA RECRÉÉE au prochain affichage d\'un écran analytique. Pour qu\'elle ne revienne pas, supprimez la fiche dans son module.' ?>\n\nIrréversible, et tracé à l\'audit.\n\nPour la retirer seulement des sélecteurs, annulez et utilisez « Désactiver ».\n\nConfirmer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)" title="Réservé à l'administrateur — destruction irréversible">Suppr. quand même</button></form>
						<?php endif; ?>
					<?php else : ?>
						<form method="post" action="<?= e( url( 'analytique/valeurs/' . (int) $v['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer cette valeur ? Elle n\'a jamais servi : rien ne sera perdu.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" style="color:var(--danger)">Supprimer</button></form>
					<?php endif; ?>
				</td></tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
	<p class="help" style="margin-top:10px">Une valeur marquée « Saisie » a été créée ici ; les autres reflètent une fiche d'un autre module (client, fournisseur, artiste, produit…) et sont rafraîchies automatiquement. Une valeur marquée <strong>« fiche supprimée »</strong> a vu son client, fournisseur ou article disparaître de son module : elle a été désactivée automatiquement — on peut lire son historique, plus lui imputer de nouvelles écritures. Elle n'est pas effacée, car cela emporterait toutes ses imputations passées. <strong>Désactiver</strong> retire une valeur des sélecteurs sans toucher à son historique — c'est ce qu'il faut faire pour une valeur qui a déjà servi.<?= ! empty( $estAdmin ) ? ' « Suppr. quand même », réservé à l\'administrateur, force la suppression d\'une valeur portée ou liée : les affectations, budgets et clés associés sont détruits, et le geste est tracé à l\'audit.' : '' ?></p>
<?php endif; ?>
