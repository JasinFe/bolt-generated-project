<?php /** @var string $annee @var array $annees @var array $divisions @var array $budgets @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'budgets' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"><a class="btn btn-primary btn-sm" href="#">Division</a><?php foreach ( array_filter( FKC_Axe::all(), function($a){return 'DIV'!==$a['code'];} ) as $a ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/budgets-axe?axe=' . (int) $a['id'] . '&annee=' . $annee ) ) ?>"><?= e( $a['libelle'] ) ?></a><?php endforeach; ?></div>
	<span class="muted" style="flex-basis:100%">Budget prévisionnel par division — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>
<form method="post" action="<?= e( url( 'analytique/budgets' ) ) ?>">
	<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= e( $annee ) ?>">
	<div class="card card-flush"><table class="table">
		<thead><tr><th>Division</th><th class="num">Budget produits</th><th class="num">Budget charges</th><th class="num">Prév. produits</th><th class="num">Prév. charges</th><th class="num">Budget résultat</th><th>Note</th></tr></thead>
		<tbody>
		<?php if ( ! $divisions ) : ?><tr><td colspan="7" class="empty">Aucune division active. Créez-en dans l'onglet Divisions.</td></tr>
		<?php else : foreach ( $divisions as $d ) : $b = $budgets[ (int) $d['id'] ] ?? null; $bp = $b ? (float) $b['budget_produits'] : 0; $bc = $b ? (float) $b['budget_charges'] : 0; $pp = $b ? (float) ( $b['prev_produits'] ?? 0 ) : 0; $pc = $b ? (float) ( $b['prev_charges'] ?? 0 ) : 0; ?>
			<tr>
				<td><strong><?= e( $d['code'] ) ?></strong> <?= e( $d['libelle'] ) ?></td>
				<td class="num"><input type="number" name="produits[<?= (int) $d['id'] ?>]" value="<?= $bp ?: '' ?>" step="1" style="width:120px;text-align:right"></td>
				<td class="num"><input type="number" name="charges[<?= (int) $d['id'] ?>]" value="<?= $bc ?: '' ?>" step="1" style="width:120px;text-align:right"></td>
				<td class="num"><input type="number" name="prev_produits[<?= (int) $d['id'] ?>]" value="<?= $pp ?: '' ?>" step="1" style="width:120px;text-align:right"></td>
				<td class="num"><input type="number" name="prev_charges[<?= (int) $d['id'] ?>]" value="<?= $pc ?: '' ?>" step="1" style="width:120px;text-align:right"></td>
				<td class="num"><?= e( fkc_money( $bp - $bc ) ) ?></td>
				<td><input type="text" name="note[<?= (int) $d['id'] ?>]" value="<?= e( $b['note'] ?? '' ) ?>" style="width:100%"></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>
	<?php if ( $divisions ) : ?><div class="actions"><button class="btn btn-primary" type="submit">Enregistrer les budgets</button> <a class="btn btn-ghost" href="<?= e( url( 'analytique/budgets-comparatifs?annee=' . $annee ) ) ?>">Vue comparative →</a></div><?php endif; ?>
</form>
<p class="help">📅 Pour budgéter <strong>mois par mois et par nature</strong> (achats, transports, personnel, ventes…) : <a href="<?= e( url( 'analytique/budget-mensuel?annee=' . $annee ) ) ?>">Budget mensuel</a>. Ses totaux peuvent être reportés ici d'un clic.</p>
<p class="help">Les montants saisis servent de référence au <a href="<?= e( url( 'analytique/controle-budgetaire?annee=' . $annee ) ) ?>">contrôle budgétaire</a> (comparaison budget / réalisé).</p>
