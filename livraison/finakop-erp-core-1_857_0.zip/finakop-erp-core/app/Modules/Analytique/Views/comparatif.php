<?php /** @var string $annee @var array $annees @var array $cmp @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$t   = $cmp['totaux'];
$prc = $cmp['annee_prec'];

/** Mini-histogramme SVG à barres groupées (gère les valeurs négatives, axe zéro). */
$histo = function ( $series, $h = 190 ) {
	// $series : array de array('label'=>..,'value'=>..,'color'=>..)
	$W = 560; $padL = 46; $padR = 10; $padT = 14; $padB = 34;
	$cw = $W - $padL - $padR; $ch = $h - $padT - $padB;
	$vals = array_map( function ( $s ) { return (float) $s['value']; }, $series );
	$max = max( 1.0, max( $vals ), 0.0 );
	$min = min( 0.0, min( $vals ) );
	$range = ( $max - $min ) ?: 1.0;
	$zeroY = $padT + ( $max / $range ) * $ch; // ordonnée du zéro
	$n = count( $series ); $gap = 18; $bw = max( 10, ( $cw / max( 1, $n ) ) - $gap );
	$svg  = '<svg viewBox="0 0 ' . $W . ' ' . $h . '" width="100%" height="' . $h . '" preserveAspectRatio="xMidYMid meet" style="font-family:system-ui,sans-serif">';
	// lignes de repère
	for ( $g = 0; $g <= 4; $g++ ) {
		$y = $padT + $ch * $g / 4;
		$val = $max - $range * $g / 4;
		$svg .= '<line x1="' . $padL . '" y1="' . round( $y, 1 ) . '" x2="' . ( $W - $padR ) . '" y2="' . round( $y, 1 ) . '" stroke="var(--line)" stroke-width="1"/>';
		$svg .= '<text x="' . ( $padL - 6 ) . '" y="' . round( $y + 3, 1 ) . '" fill="var(--muted)" font-size="9" text-anchor="end">' . e( fkc_money( $val ) ) . '</text>';
	}
	// barres
	$i = 0;
	foreach ( $series as $s ) {
		$x = $padL + $i * ( $bw + $gap ) + $gap / 2;
		$v = (float) $s['value'];
		$bh = abs( $v ) / $range * $ch;
		$y  = $v >= 0 ? ( $zeroY - $bh ) : $zeroY;
		$svg .= '<rect x="' . round( $x, 1 ) . '" y="' . round( $y, 1 ) . '" width="' . round( $bw, 1 ) . '" height="' . round( max( 0.5, $bh ), 1 ) . '" rx="3" fill="' . $s['color'] . '"><title>' . e( $s['label'] . ' : ' . fkc_money( $v ) ) . '</title></rect>';
		$ty = $v >= 0 ? ( $y - 4 ) : ( $y + $bh + 11 );
		$svg .= '<text x="' . round( $x + $bw / 2, 1 ) . '" y="' . round( $ty, 1 ) . '" fill="var(--text)" font-size="9.5" text-anchor="middle">' . e( fkc_money( $v ) ) . '</text>';
		$svg .= '<text x="' . round( $x + $bw / 2, 1 ) . '" y="' . ( $h - $padB + 15 ) . '" fill="var(--muted)" font-size="10" text-anchor="middle">' . e( $s['label'] ) . '</text>';
		$i++;
	}
	$svg .= '</svg>';
	return $svg;
};

$col = array( 'reel' => 'var(--blue)', 'budget' => 'var(--orange)', 'prevision' => 'var(--ok)', 'n1' => 'var(--muted)' );
$ecCol = function ( $v ) { return $v >= 0 ? 'var(--ok)' : 'var(--danger)'; };
$pct = function ( $e ) { return null === $e['pct'] ? '—' : ( ( $e['pct'] >= 0 ? '+' : '' ) . $e['pct'] . ' %' ); };
?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'comparatif' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted" style="flex-basis:100%">Budgets comparatifs — Réel · Budget · Prévision · N-1 — exercice <?= e( $annee ) ?> (N-1 = <?= e( $prc ) ?>)</span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y === $annee ? 'selected' : '' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/budgets?annee=' . $annee ) ) ?>">Saisir budgets / prévisions →</a>
</div>

<!-- Synthèse en cartes -->
<div class="form-grid" style="grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px">
	<div class="card"><div class="card-body"><div class="muted" style="font-size:.8em;text-transform:uppercase;letter-spacing:.5px">Résultat réel</div><div style="font-size:1.5em;font-weight:800;color:<?= $ecCol( $t['reel_r'] ) ?>"><?= e( fkc_money( $t['reel_r'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><div class="muted" style="font-size:.8em;text-transform:uppercase;letter-spacing:.5px">Résultat budget</div><div style="font-size:1.5em;font-weight:800"><?= e( fkc_money( $t['bud_r'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><div class="muted" style="font-size:.8em;text-transform:uppercase;letter-spacing:.5px">Résultat prévision</div><div style="font-size:1.5em;font-weight:800"><?= e( fkc_money( $t['prev_r'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><div class="muted" style="font-size:.8em;text-transform:uppercase;letter-spacing:.5px">Résultat <?= e( $prc ) ?> (N-1)</div><div style="font-size:1.5em;font-weight:800"><?= e( fkc_money( $t['n1_r'] ) ) ?></div></div></div>
</div>

<!-- Histogramme comparatif (résultat total) -->
<div class="card"><div class="card-head"><h2>Histogramme comparatif du résultat</h2></div><div class="card-body">
	<?= $histo( array(
		array( 'label' => 'Réel',      'value' => $t['reel_r'], 'color' => $col['reel'] ),
		array( 'label' => 'Budget',    'value' => $t['bud_r'],  'color' => $col['budget'] ),
		array( 'label' => 'Prévision', 'value' => $t['prev_r'], 'color' => $col['prevision'] ),
		array( 'label' => 'N-1',       'value' => $t['n1_r'],   'color' => $col['n1'] ),
	) ) ?>
	<div style="display:flex;gap:18px;flex-wrap:wrap;margin-top:8px;font-size:12px;color:var(--muted)">
		<span><b style="color:var(--text)">Écart Réel vs Budget :</b> <span style="color:<?= $ecCol( $t['ecart_budget']['val'] ) ?>"><?= ( $t['ecart_budget']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $t['ecart_budget']['val'] ) ) ?> (<?= $pct( $t['ecart_budget'] ) ?>)</span></span>
		<span><b style="color:var(--text)">Écart Réel vs Prévision :</b> <span style="color:<?= $ecCol( $t['ecart_prevision']['val'] ) ?>"><?= ( $t['ecart_prevision']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $t['ecart_prevision']['val'] ) ) ?> (<?= $pct( $t['ecart_prevision'] ) ?>)</span></span>
		<span><b style="color:var(--text)">Variation vs N-1 :</b> <span style="color:<?= $ecCol( $t['var_n1']['val'] ) ?>"><?= ( $t['var_n1']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $t['var_n1']['val'] ) ) ?> (<?= $pct( $t['var_n1'] ) ?>)</span></span>
	</div>
</div></div>

<!-- Tableau comparatif par division -->
<div class="card card-flush"><div class="card-head"><h2>Comparatif par division (résultat)</h2></div>
	<table class="table">
		<thead><tr>
			<th>Division</th>
			<th class="num">Réel</th><th class="num">Budget</th><th class="num">Prévision</th><th class="num">N-1</th>
			<th class="num">Écart / Budget</th><th class="num">Écart / Prévision</th><th class="num">Var. / N-1</th>
		</tr></thead>
		<tbody>
		<?php if ( ! $cmp['lignes'] ) : ?><tr><td colspan="8" class="empty">Aucune division. Créez des divisions et saisissez leurs budgets.</td></tr>
		<?php else : foreach ( $cmp['lignes'] as $l ) : ?>
			<tr>
				<td><strong><?= e( $l['code'] ) ?></strong> <?= e( $l['libelle'] ) ?><?= $l['a_budget'] ? '' : ' <span class="muted" style="font-size:.82em">(sans budget)</span>' ?></td>
				<td class="num" style="color:<?= $ecCol( $l['reel']['resultat'] ) ?>"><?= e( fkc_money( $l['reel']['resultat'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $l['budget']['resultat'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $l['prevision']['resultat'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $l['n1']['resultat'] ) ) ?></td>
				<td class="num" style="color:<?= $ecCol( $l['ecart_budget']['val'] ) ?>"><?= ( $l['ecart_budget']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $l['ecart_budget']['val'] ) ) ?><br><span class="muted" style="font-size:.82em"><?= $pct( $l['ecart_budget'] ) ?></span></td>
				<td class="num" style="color:<?= $ecCol( $l['ecart_prevision']['val'] ) ?>"><?= ( $l['ecart_prevision']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $l['ecart_prevision']['val'] ) ) ?><br><span class="muted" style="font-size:.82em"><?= $pct( $l['ecart_prevision'] ) ?></span></td>
				<td class="num" style="color:<?= $ecCol( $l['var_n1']['val'] ) ?>"><?= ( $l['var_n1']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $l['var_n1']['val'] ) ) ?><br><span class="muted" style="font-size:.82em"><?= $pct( $l['var_n1'] ) ?></span></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( $cmp['lignes'] ) : ?><tfoot><tr class="total">
			<td class="right">Total</td>
			<td class="num"><?= e( fkc_money( $t['reel_r'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $t['bud_r'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $t['prev_r'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $t['n1_r'] ) ) ?></td>
			<td class="num" style="color:<?= $ecCol( $t['ecart_budget']['val'] ) ?>"><?= ( $t['ecart_budget']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $t['ecart_budget']['val'] ) ) ?></td>
			<td class="num" style="color:<?= $ecCol( $t['ecart_prevision']['val'] ) ?>"><?= ( $t['ecart_prevision']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $t['ecart_prevision']['val'] ) ) ?></td>
			<td class="num" style="color:<?= $ecCol( $t['var_n1']['val'] ) ?>"><?= ( $t['var_n1']['val'] >= 0 ? '+' : '' ) . e( fkc_money( $t['var_n1']['val'] ) ) ?></td>
		</tr></tfoot><?php endif; ?>
	</table>
</div>
<p class="help">« Réel » = réalisé de l'exercice (comptabilité analytique). « Budget » et « Prévision » se saisissent dans <a href="<?= e( url( 'analytique/budgets?annee=' . $annee ) ) ?>">Budgets</a>. « N-1 » = réalisé de l'exercice <?= e( $prc ) ?>.</p>
