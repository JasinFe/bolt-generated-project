<?php /** @var string $annee @var array $annees @var array $res @var array $mensuel @var array $profitAxes @var array $budget @var array $kpi @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$lignes = $res['lignes']; $tot = $res['totaux'];
$profitAxes = $profitAxes ?? array(); $budget = $budget ?? array(); $kpi = $kpi ?? array();
$mNoms = array( 1=>'Jan',2=>'Fév',3=>'Mar',4=>'Avr',5=>'Mai',6=>'Juin',7=>'Juil',8=>'Aoû',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Déc' );
$maxM = 1; foreach ( $mensuel as $m ) { $maxM = max( $maxM, abs( $m['produits'] ), abs( $m['charges'] ) ); }
$top = $lignes; usort( $top, function ( $a, $b ) { return $b['resultat'] <=> $a['resultat']; } );
$maxAbs = 1; foreach ( $top as $l ) { $maxAbs = max( $maxAbs, abs( $l['resultat'] ) ); }
$marge = $tot['produits'] > 0 ? round( $tot['resultat'] / $tot['produits'] * 100, 1 ) : 0; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => 'bi' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Tableau de bord analytique — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>

<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Produits</span><div style="font-size:1.4em;font-weight:700;color:var(--ok)"><?= e( fkc_money( $tot['produits'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Charges</span><div style="font-size:1.4em;font-weight:700;color:var(--orange)"><?= e( fkc_money( $tot['charges'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Résultat</span><div style="font-size:1.4em;font-weight:700;color:<?= $tot['resultat']>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $tot['resultat'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Marge nette</span><div style="font-size:1.4em;font-weight:700"><?= e( $marge ) ?> %</div></div></div>
</div>

<div class="card">
	<div class="card-head"><h2>Évolution mensuelle</h2></div>
	<div class="card-body">
		<div style="display:flex;align-items:flex-end;gap:6px;height:180px;padding-top:10px">
			<?php foreach ( $mensuel as $m => $d ) :
				$hp = round( abs( $d['produits'] ) / $maxM * 150 ); $hc = round( abs( $d['charges'] ) / $maxM * 150 ); ?>
				<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;justify-content:flex-end" title="<?= e( $mNoms[ $m ] ) ?> — Produits <?= e( fkc_money( $d['produits'] ) ) ?> / Charges <?= e( fkc_money( $d['charges'] ) ) ?>">
					<div style="display:flex;gap:2px;align-items:flex-end;height:150px">
						<div style="width:8px;height:<?= $hp ?>px;background:var(--ok);border-radius:2px 2px 0 0"></div>
						<div style="width:8px;height:<?= $hc ?>px;background:var(--orange);border-radius:2px 2px 0 0"></div>
					</div>
					<span class="muted" style="font-size:.72em"><?= e( $mNoms[ $m ] ) ?></span>
				</div>
			<?php endforeach; ?>
		</div>
		<div style="display:flex;gap:16px;margin-top:8px;font-size:.85em"><span><span style="display:inline-block;width:10px;height:10px;background:var(--ok);border-radius:2px"></span> Produits</span><span><span style="display:inline-block;width:10px;height:10px;background:var(--orange);border-radius:2px"></span> Charges</span></div>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Résultat par division</h2></div>
	<div class="card-body">
		<?php if ( ! $top ) : ?><p class="muted" style="margin:0">Aucune donnée analytique.</p>
		<?php else : foreach ( $top as $l ) : $w = round( abs( $l['resultat'] ) / $maxAbs * 100 ); ?>
			<div style="display:flex;align-items:center;gap:10px;margin:5px 0">
				<span style="width:150px;font-size:.88em" title="<?= e( $l['libelle'] ) ?>"><strong><?= e( $l['code'] ) ?></strong> <?= e( mb_strimwidth( $l['libelle'], 0, 22, '…' ) ) ?></span>
				<div style="flex:1;background:rgba(255,255,255,.05);border-radius:6px;height:16px"><div style="height:100%;width:<?= $w ?>%;border-radius:6px;background:<?= $l['resultat']>=0?'var(--ok)':'var(--danger)' ?>"></div></div>
				<span style="width:120px;text-align:right;font-weight:600;color:<?= $l['resultat']>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $l['resultat'] ) ) ?></span>
			</div>
		<?php endforeach; endif; ?>
	</div>
</div>

<?php if ( $kpi ) : ?>
<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Marge brute</span><div style="font-size:1.2em;font-weight:700;color:var(--ok)"><?= e( fkc_money( $kpi['marge_brute'] ) ) ?></div><span class="muted" style="font-size:.8em"><?= null===$kpi['taux_marge_brute']?'—':e( $kpi['taux_marge_brute'] ).' %' ?></span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Rentabilité</span><div style="font-size:1.2em;font-weight:700"><?= null===$kpi['rentabilite']?'—':e( $kpi['rentabilite'] ).' %' ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Coût salarié</span><div style="font-size:1.2em;font-weight:700;color:var(--orange)"><?= e( fkc_money( $kpi['cout_salarie'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">DSO (recouvrement)</span><div style="font-size:1.2em;font-weight:700"><?= (int) $kpi['dso'] ?> j</div></div></div>
</div>
<?php endif; ?>

<?php if ( $budget && ( ( $budget['bp'] ?? 0 ) || ( $budget['bc'] ?? 0 ) ) ) :
	$bp = $budget['bp']; $bc = $budget['bc']; $rp = $budget['rp']; $rc = $budget['rc'];
	$ecartP = $rp - $bp; $ecartC = $rc - $bc; ?>
<div class="card card-flush">
	<div class="card-head"><h2>Budgets · prévu / réalisé / écart</h2></div>
	<table class="table">
		<thead><tr><th></th><th class="num">Prévu</th><th class="num">Réalisé</th><th class="num">Écart</th></tr></thead>
		<tbody>
			<tr><td>Produits</td><td class="num"><?= e( fkc_money( $bp ) ) ?></td><td class="num"><?= e( fkc_money( $rp ) ) ?></td><td class="num" style="color:<?= $ecartP>=0?'var(--ok)':'var(--danger)' ?>"><?= ( $ecartP>=0?'+':'' ) . e( fkc_money( $ecartP ) ) ?></td></tr>
			<tr><td>Charges</td><td class="num"><?= e( fkc_money( $bc ) ) ?></td><td class="num"><?= e( fkc_money( $rc ) ) ?></td><td class="num" style="color:<?= $ecartC>0?'var(--danger)':'var(--ok)' ?>"><?= ( $ecartC>0?'+':'' ) . e( fkc_money( $ecartC ) ) ?></td></tr>
		</tbody>
		<tfoot><tr class="total"><td>Résultat</td><td class="num"><?= e( fkc_money( $bp - $bc ) ) ?></td><td class="num"><?= e( fkc_money( $rp - $rc ) ) ?></td><td class="num"><?= e( fkc_money( ( $rp - $rc ) - ( $bp - $bc ) ) ) ?></td></tr></tfoot>
	</table>
</div>
<?php endif; ?>

<?php foreach ( $profitAxes as $pa ) :
	$axe = $pa['axe']; $rows = $pa['res']['lignes'];
	usort( $rows, function ( $a, $b ) { return $b['resultat'] <=> $a['resultat']; } );
	$mx = 1; foreach ( $rows as $r ) { $mx = max( $mx, abs( $r['resultat'] ) ); } ?>
<div class="card">
	<div class="card-head"><h2>Profitabilité par <?= e( $axe['libelle'] ) ?></h2></div>
	<div class="card-body">
		<?php foreach ( array_slice( $rows, 0, 12 ) as $r ) : $w = round( abs( $r['resultat'] ) / $mx * 100 ); ?>
			<div style="display:flex;align-items:center;gap:10px;margin:5px 0">
				<span style="width:160px;font-size:.88em" title="<?= e( $r['libelle'] ) ?>"><?= e( mb_strimwidth( (string) $r['libelle'], 0, 26, '…' ) ) ?></span>
				<div style="flex:1;background:rgba(255,255,255,.05);border-radius:6px;height:15px"><div style="height:100%;width:<?= $w ?>%;border-radius:6px;background:<?= $r['resultat']>=0?'var(--ok)':'var(--danger)' ?>"></div></div>
				<span style="width:120px;text-align:right;font-weight:600;color:<?= $r['resultat']>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $r['resultat'] ) ) ?></span>
			</div>
		<?php endforeach; ?>
	</div>
</div>
<?php endforeach; ?>
