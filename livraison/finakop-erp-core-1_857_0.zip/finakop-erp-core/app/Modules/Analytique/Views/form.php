<?php /** @var string $tab @var array|null $d @var array $errors @var array $types */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); $ed = (bool) $d; ?>
<?php FKC_View::partial( 'analytique::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>

<div class="card" style="max-width:640px"><div class="card-head"><h2><?= $ed ? 'Modifier la division' : 'Nouvelle division' ?></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'analytique/divisions' ) ) ?>">← Retour</a></div><div class="card-body">
<form method="post" action="<?= e( $ed ? url( 'analytique/divisions/' . $d['id'] ) : url( 'analytique/divisions' ) ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-grid" style="grid-template-columns:1fr 2fr">
		<label class="fld"><span>Code *</span><input name="code" value="<?= e( $ed ? $d['code'] : '' ) ?>" maxlength="20" placeholder="ex. MUSIC" required style="text-transform:uppercase"></label>
		<label class="fld"><span>Libellé *</span><input name="libelle" value="<?= e( $ed ? $d['libelle'] : '' ) ?>" placeholder="ex. Pôle Musique" required autofocus></label>
	</div>
	<div class="form-grid" style="grid-template-columns:2fr 1fr">
		<label class="fld"><span>Type</span><select name="type">
			<?php foreach ( $types as $k => $lbl ) : ?><option value="<?= e( $k ) ?>" <?= ( $ed && $d['type'] === $k ) ? 'selected' : '' ?>><?= e( $lbl ) ?></option><?php endforeach; ?>
		</select></label>
		<label class="fld"><span>Ordre d'affichage</span><input type="number" name="ordre" value="<?= e( $ed ? $d['ordre'] : 0 ) ?>" min="0"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Nature</span><select name="nature">
			<?php foreach ( ( $natures ?? array() ) as $k => $lbl ) : ?><option value="<?= e( $k ) ?>" <?= ( $ed && ( $d['nature'] ?? 'mixte' ) === $k ) ? 'selected' : '' ?>><?= e( $lbl ) ?></option><?php endforeach; ?>
		</select></label>
		<label class="fld"><span>Axe analytique</span><select name="axe_id">
			<option value="">— Aucun —</option>
			<?php foreach ( ( $axes ?? array() ) as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= ( $ed && (int) ( $d['axe_id'] ?? 0 ) === (int) $a['id'] ) ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option><?php endforeach; ?>
		</select></label>
	</div>
	<label class="chk" style="margin-top:6px"><input type="checkbox" name="actif" value="1" <?= ( ! $ed || $d['actif'] ) ? 'checked' : '' ?>> Division active</label>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $ed ? 'Enregistrer' : 'Créer la division' ?></button><a class="btn btn-ghost" href="<?= e( url( 'analytique/divisions' ) ) ?>">Annuler</a></div>
</form>
</div></div>
<style>.chk{display:flex;align-items:center;gap:8px;font-size:14px}.chk input{width:auto}</style>
