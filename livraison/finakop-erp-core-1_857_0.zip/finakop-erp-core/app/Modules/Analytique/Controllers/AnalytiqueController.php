<?php
/** Module Analytique : contrôle de gestion par division. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnalytiqueController {

	/** Tableau « Résultat par division » + liste des divisions. */
	public function index() {
		$annee = $this->anneeParam(); // exercice par défaut du Paramétrage (1.825.0 — l'écran principal l'ignorait)
		FKC_View::render( 'analytique::index', array(
			'title'     => 'Analytique · Contrôle de gestion',
			'tab'       => 'resultats',
			'annee'     => $annee,
			'annees'    => $this->annees(),
			'res'       => ( $fkcRes = FKC_Division::resultats( $annee ) ),
			'rapprochement' => $this->rapprochement( $annee, $fkcRes ),
			'divisions' => FKC_Division::all(),
			'flash'     => $this->flash(),
		) );
	}

	/**
	 * Résultat net du COMPTE DE RÉSULTAT sur l'exercice, face au total
	 * analytique (1.822.0). Même source que les états DGI.
	 */
	protected function rapprochement( $annee, array $res ) {
		if ( ! class_exists( 'FKC_EtatsDgi' ) || ! method_exists( 'FKC_EtatsDgi', 'sigBruts' ) ) { return null; }
		$b = FKC_Division::bornes( $annee );
		if ( ! $b ) { return null; }
		try { $cr = (float) ( FKC_EtatsDgi::sigBruts( $b[0], $b[1] )['XI'] ?? 0 ); } catch ( \Throwable $e ) { return null; }
		$ana = (float) ( $res['totaux']['resultat_net'] ?? $res['totaux']['resultat'] );
		if ( abs( $cr ) < 0.5 && abs( $ana ) < 0.5 ) { return null; }
		return array( 'cr' => $cr, 'analytique' => $ana, 'ecart' => round( $ana - $cr, 2 ) );
	}

	/** Gestion des divisions. */
	public function divisions() {
		$divisions = FKC_Division::all();
		// Ce que chaque division détruirait en partant : l'écran l'annonce
		// AVANT de proposer la suppression forcée. Un garde-fou qu'on peut
		// contourner sans avoir lu ses conséquences ne protège personne.
		$impacts = array();
		foreach ( $divisions as $d ) { $impacts[ (int) $d['id'] ] = FKC_Division::impact( $d['id'] ); }
		FKC_View::render( 'analytique::divisions', array(
			'title'     => 'Analytique · Divisions',
			'tab'       => 'divisions',
			'divisions' => $divisions,
			'impacts'   => $impacts,
			'estAdmin'  => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'types'     => FKC_Division::types(),
			'flash'     => $this->flash(),
		) );
	}

	public function create() { $this->form( null, array() ); }

	public function edit( $id ) {
		$d = FKC_Division::find( $id );
		if ( ! $d ) { redirect( 'analytique/divisions' ); }
		$this->form( $d, array() );
	}

	protected function form( $d, $errors ) {
		FKC_View::render( 'analytique::form', array(
			'title'   => $d ? 'Modifier la division' : 'Nouvelle division',
			'tab'     => 'divisions',
			'd'       => $d, 'errors' => $errors,
			'types'   => FKC_Division::types(),
			'natures' => FKC_Division::natures(),
			'axes'    => FKC_Axe::all(),
		) );
	}

	public function store() {
		$errors = $this->validate( $_POST, 0 );
		if ( $errors ) { return $this->form( null, $errors ); }
		FKC_Division::create( $_POST );
		$this->setFlash( 'Division créée.' );
		redirect( 'analytique/divisions' );
	}

	public function update( $id ) {
		$d = FKC_Division::find( $id );
		if ( ! $d ) { redirect( 'analytique/divisions' ); }
		$errors = $this->validate( $_POST, (int) $id );
		if ( $errors ) { return $this->form( $d, $errors ); }
		FKC_Division::update( $id, $_POST );
		$this->setFlash( 'Division mise à jour.' );
		redirect( 'analytique/divisions' );
	}

	public function destroy( $id ) {
		$d = FKC_Division::find( $id );
		if ( ! $d ) { redirect( 'analytique/divisions' ); }
		list( $ok, $msg ) = FKC_Division::delete( $id );
		$this->setFlash( $msg );
		redirect( 'analytique/divisions' );
	}

	/**
	 * Supprime une division MALGRÉ ses imputations.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * POURQUOI CETTE PORTE EXISTE, ET POURQUOI ELLE EST ÉTROITE
	 *
	 * Le refus posé en 1.547.0 protège un cas réel : effacer une division
	 * porteuse d'écritures détruit l'imputation analytique de chacune d'elles,
	 * sans retour possible. Mais il y a un autre cas réel — les divisions de
	 * test créées pendant la prise en main, qui ont servi à deux ou trois
	 * saisies d'essai et qu'on veut voir disparaître du référentiel. Refuser
	 * les deux au même titre obligerait à garder pour toujours une section
	 * « AAA test » dans les états.
	 *
	 * La porte est donc ouverte, mais gardée par trois barrières :
	 *   • la route exige le rôle ADMINISTRATEUR (contrôle du routeur, pas
	 *     seulement un bouton caché dans la vue) ;
	 *   • l'écran DIT ce qui sera détruit, chiffres à l'appui, avant de
	 *     demander confirmation — un refus qu'on peut contourner sans avoir
	 *     lu ses conséquences ne protège personne ;
	 *   • le geste est TRACÉ à l'audit avec le détail de ce qui a été perdu,
	 *     parce qu'un écart analytique constaté trois mois plus tard doit
	 *     pouvoir s'expliquer.
	 * ─────────────────────────────────────────────────────────────────────
	 */
	public function destroyForce( $id ) {
		$d = FKC_Division::find( $id );
		if ( ! $d ) { redirect( 'analytique/divisions' ); }
		$imp = FKC_Division::impact( $id );
		// L'audit est posé par le modèle (FKC_Division::delete) : il suit l'acte
		// et non l'écran, donc tout autre chemin de destruction est tracé aussi.
		list( $ok, $msg ) = FKC_Division::delete( $id, true );
		$this->setFlash( $ok
			? 'Division « ' . $d['libelle'] . ' » supprimée. ' . $imp['lignes'] . ' ligne(s) d\'écriture sont repassées en « non imputé » et '
				. $imp['budgets'] . ' budget(s) ont été effacés. L\'opération est tracée à l\'audit.'
			: $msg );
		redirect( 'analytique/divisions' );
	}

	/** Désactive / réactive une division sans toucher à son historique. */
	public function toggleDivision( $id ) {
		$d = FKC_Division::find( $id );
		if ( ! $d ) { redirect( 'analytique/divisions' ); }
		$actif = empty( $d['actif'] );
		FKC_Division::setActif( $id, $actif );
		$this->setFlash( $actif
			? 'Division « ' . $d['libelle'] . ' » réactivée.'
			: 'Division « ' . $d['libelle'] . ' » désactivée : elle quitte les sélecteurs de saisie, '
				. 'son historique reste lisible dans les résultats.' );
		redirect( 'analytique/divisions' );
	}

	/* ── Fonctions à déblocage progressif (selon l'édition) ── */

	/** Vérifie l'accès à une fonctionnalité ; rend l'écran de déblocage sinon. */
	protected function feature( $code ) {
		if ( FKC_Modules::featureEnabled( $code ) ) { return true; }
		FKC_View::render( 'analytique::_locked', array(
			'title' => 'Analytique · ' . FKC_Modules::featureLabel( $code ),
			'tab'   => '', 'feature' => $code,
			'label' => FKC_Modules::featureLabel( $code ),
			'min'   => FKC_Modules::featureMinLabel( $code ),
		) );
		return false;
	}

	/**
	 * Rafraîchit les VALEURS analytiques depuis leurs référentiels d'origine.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * SIX ÉCRANS SUR HUIT NE SYNCHRONISAIENT PAS (1.547.0)
	 *
	 * Seuls « Valeurs » et « Multi-axes » appelaient le backfill. Un
	 * fournisseur, un artiste, un article créé dans son module restait donc
	 * INVISIBLE du sélecteur d'affectation, des budgets par axe, du contrôle
	 * par axe et du BI — tant que l'utilisateur n'était pas passé, par
	 * hasard, sur l'un des deux écrans qui le déclenchaient. Le symptôme
	 * était particulièrement trompeur : la valeur apparaissait « toute
	 * seule » plus tard, ce qui donnait l'impression d'un délai de
	 * traitement inexistant.
	 *
	 * La synchronisation est idempotente (elle n'insère que le manquant) et
	 * n'est faite qu'UNE FOIS par requête : huit écrans peuvent l'appeler
	 * sans que le coût soit payé huit fois.
	 * ─────────────────────────────────────────────────────────────────────
	 */
	protected static $synced = false;
	protected function syncSources() {
		if ( self::$synced ) { return; }
		self::$synced = true;
		try {
			if ( class_exists( 'FKC_AnalytiqueLink' ) ) { FKC_AnalytiqueLink::backfill(); }
			// Stock consolidé (packs + entrepôts) reflété sur l'axe Produit.
			if ( class_exists( 'FKC_Stock' ) ) { FKC_Stock::syncAnalytique(); }
		} catch ( \Throwable $e ) {
			// Un référentiel absent ne doit jamais empêcher l'écran de s'afficher.
			if ( function_exists( 'fkc_log' ) ) { fkc_log( 'Analytique::syncSources ' . $e->getMessage(), 'WARN' ); }
		}
	}

	protected function anneeParam() {
		$a = isset( $_GET['annee'] ) ? preg_replace( '/\D/', '', (string) $_GET['annee'] ) : '';
		if ( '' !== $a ) { return $a; }
		// Réglage « exercice par défaut » (Paramétrage) — enfin lu (1.822.0).
		$d = class_exists( 'FKC_AnaExercice' ) ? FKC_AnaExercice::exerciceDefaut() : '';
		if ( '' !== $d ) { return $d; }
		return class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::courant() : date( 'Y' );
	}

	/** Centres de coûts (Business+) : charges réelles par centre de coût. */
	public function centresCouts() {
		if ( ! $this->feature( 'analytique.centre_couts' ) ) { return; }
		$annee = $this->anneeParam();
		$res = FKC_Division::resultats( $annee );
		$lignes = array_filter( $res['lignes'], function ( $l ) { return in_array( $l['nature'], array( 'cout', 'mixte' ), true ); } );
		FKC_View::render( 'analytique::centres_couts', array(
			'title' => 'Analytique · Centres de coûts', 'tab' => 'centres_couts',
			'annee' => $annee, 'annees' => $this->annees(), 'lignes' => array_values( $lignes ), 'flash' => $this->flash(),
		) );
	}

	/** Centres de profit (Business+) : produits, charges, marge, résultat par centre de profit. */
	public function centresProfit() {
		if ( ! $this->feature( 'analytique.centre_profit' ) ) { return; }
		$annee = $this->anneeParam();
		$res = FKC_Division::resultats( $annee );
		$lignes = array_filter( $res['lignes'], function ( $l ) { return in_array( $l['nature'], array( 'profit', 'mixte' ), true ); } );
		FKC_View::render( 'analytique::centres_profit', array(
			'title' => 'Analytique · Centres de profit', 'tab' => 'centres_profit',
			'annee' => $annee, 'annees' => $this->annees(), 'lignes' => array_values( $lignes ), 'flash' => $this->flash(),
		) );
	}

	/** Budgets (Pro+) : saisie du budget produits/charges par division et exercice. */
	public function budgets() {
		if ( ! $this->feature( 'analytique.budgets' ) ) { return; }
		$annee = $this->anneeParam();
		FKC_View::render( 'analytique::budgets', array(
			'title' => 'Analytique · Budgets', 'tab' => 'budgets',
			'annee' => $annee, 'annees' => $this->annees(),
			'divisions' => $this->divisionsBudgetables( $annee ), 'budgets' => $this->budgetMap( $annee ), 'flash' => $this->flash(),
		) );
	}

	/**
	 * Divisions saisissables au budget : les actives, PLUS les inactives qui
	 * portent déjà un budget sur l'exercice. Sans cela, désactiver une
	 * division en cours d'année faisait disparaître son budget de l'écran de
	 * saisie tout en le laissant peser dans le contrôle budgétaire — l'écart
	 * était affiché mais son origine devenue inaccessible.
	 */
	protected function divisionsBudgetables( $annee ) {
		$out = FKC_Division::all( true );
		$vus = array();
		foreach ( $out as $d ) { $vus[ (int) $d['id'] ] = true; }
		foreach ( FKC_Budget::all( $annee ) as $b ) {
			$id = (int) $b['division_id'];
			if ( isset( $vus[ $id ] ) ) { continue; }
			$d = FKC_Division::find( $id );
			if ( $d ) { $out[] = $d; $vus[ $id ] = true; }
		}
		return $out;
	}
	protected function budgetMap( $annee ) {
		$m = array();
		foreach ( FKC_Budget::all( $annee ) as $b ) { $m[ (int) $b['division_id'] ] = $b; }
		return $m;
	}
	public function budgetSave() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.budgets' ) ) { redirect( 'analytique' ); }
		$annee = preg_replace( '/\D/', '', (string) ( $_POST['annee'] ?? date( 'Y' ) ) ) ?: date( 'Y' );
		$prod = $_POST['produits'] ?? array();
		$charg = $_POST['charges'] ?? array();
		$prevP = $_POST['prev_produits'] ?? array();
		$prevC = $_POST['prev_charges'] ?? array();
		$notes = $_POST['note'] ?? array();
		foreach ( $this->divisionsBudgetables( $annee ) as $d ) {
			$id = (int) $d['id'];
			$p = (float) ( $prod[ $id ] ?? 0 );
			$c = (float) ( $charg[ $id ] ?? 0 );
			$pp = (float) ( $prevP[ $id ] ?? 0 );
			$pc = (float) ( $prevC[ $id ] ?? 0 );
			$n = trim( (string) ( $notes[ $id ] ?? '' ) );
			if ( $p > 0 || $c > 0 || $pp > 0 || $pc > 0 || '' !== $n ) { FKC_Budget::upsert( $id, $annee, $p, $c, $n, $pp, $pc ); }
			else { FKC_Budget::delete( $id, $annee ); }
		}
		$this->setFlash( 'Budgets ' . $annee . ' enregistrés.' );
		redirect( 'analytique/budgets?annee=' . $annee );
	}

	/** Contrôle budgétaire (Pro+) : budget vs réalisé, écarts et taux de consommation. */
	public function controle() {
		if ( ! $this->feature( 'analytique.controle_budgetaire' ) ) { return; }
		$annee = $this->anneeParam();
		FKC_View::render( 'analytique::controle', array(
			'title' => 'Analytique · Contrôle budgétaire', 'tab' => 'controle',
			'annee' => $annee, 'annees' => $this->annees(), 'ctrl' => FKC_Budget::controle( $annee ), 'flash' => $this->flash(),
		) );
	}

	/** Budgets comparatifs : Réel / Budget / Prévision / N-1, par division. */
	public function comparatif() {
		if ( ! $this->feature( 'analytique.budgets' ) ) { return; }
		$annee = $this->anneeParam();
		FKC_View::render( 'analytique::comparatif', array(
			'title' => 'Analytique · Budgets comparatifs', 'tab' => 'comparatif',
			'annee' => $annee, 'annees' => $this->annees(),
			'cmp'   => FKC_Budget::comparatif( $annee ), 'flash' => $this->flash(),
		) );
	}

	/* ── Budget mensuel par nature (1.831.0) ── */

	/** Sections proposées : l'entreprise (0), les divisions actives, et celles déjà budgétées. */
	protected function sectionsBudget( $annee ) {
		$out = array( 0 => 'Entreprise (toutes divisions)' );
		foreach ( FKC_Division::all( true ) as $d ) { $out[ (int) $d['id'] ] = $d['libelle']; }
		foreach ( FKC_BudgetMensuel::sectionsBudgetees( $annee ) as $id ) {
			if ( ! isset( $out[ $id ] ) ) { $out[ $id ] = FKC_BudgetMensuel::nomSection( $id ) . ' (inactive)'; }
		}
		return $out;
	}

	public function budgetMensuel() {
		if ( ! $this->feature( 'analytique.budgets' ) ) { return; }
		$annee = $this->anneeParam();
		$sections = $this->sectionsBudget( $annee );
		$div = (int) ( $_GET['section'] ?? 0 );
		if ( ! isset( $sections[ $div ] ) ) { $div = 0; }
		$prec = (string) ( (int) $annee - 1 );
		$reelN1 = FKC_BudgetMensuel::reel( $prec, $div );
		FKC_View::render( 'analytique::budget_mensuel', array(
			'title' => 'Analytique · Budget mensuel', 'tab' => 'budgets',
			'annee' => $annee, 'annees' => $this->annees(), 'sections' => $sections, 'div' => $div,
			'natures' => FKC_BudgetMensuel::natures(), 'mois' => FKC_BudgetMensuel::moisExercice( $annee ),
			'budget' => FKC_BudgetMensuel::budget( $annee, $div ), 'reelN1' => $reelN1,
			'saison' => FKC_BudgetMensuel::saisonnalite( $annee, $div ), 'fige' => FKC_BudgetMensuel::estFige( $annee ),
			'annuel' => $div ? FKC_Budget::find( $div, $annee ) : null,
			'flash' => $this->flash(),
		) );
	}

	public function budgetMensuelSave() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.budgets' ) ) { redirect( 'analytique' ); }
		$annee = preg_replace( '/\D/', '', (string) ( $_POST['annee'] ?? '' ) ) ?: $this->anneeParam();
		$div = (int) ( $_POST['section'] ?? 0 );
		$retour = 'analytique/budget-mensuel?annee=' . $annee . '&section=' . $div;
		$action = (string) ( $_POST['action'] ?? 'enregistrer' );
		if ( 'copier_n1' === $action ) {
			list( $ok, $msg ) = FKC_BudgetMensuel::copierN1( $annee, $div, (float) str_replace( ',', '.', (string) ( $_POST['pct'] ?? 0 ) ) );
		} elseif ( 'reporter' === $action ) {
			list( $ok, $msg ) = FKC_BudgetMensuel::reporterAnnuel( $annee, $div );
		} else {
			if ( empty( $_POST['_fin'] ) ) {
				$this->setFlash( 'Refusé : le formulaire est arrivé incomplet. Rien n\'a été modifié.' );
				redirect( $retour );
			}
			list( $ok, $msg ) = FKC_BudgetMensuel::enregistrer( $annee, $div, (array) ( $_POST['b'] ?? array() ) );
		}
		$this->setFlash( $ok ? $msg : 'Refusé : ' . $msg );
		redirect( $retour );
	}

	public function budgetMensuelSuivi() {
		if ( ! $this->feature( 'analytique.controle_budgetaire' ) ) { return; }
		$annee = $this->anneeParam();
		$sections = $this->sectionsBudget( $annee );
		$div = (int) ( $_GET['section'] ?? 0 );
		if ( ! isset( $sections[ $div ] ) ) { $div = 0; }
		$jusqua = isset( $_GET['mois'] ) ? (int) $_GET['mois'] : FKC_BudgetMensuel::moisCourant( $annee );
		$seuil = max( 0, min( 50, (int) ( $_GET['seuil'] ?? 5 ) ) );
		FKC_View::render( 'analytique::budget_mensuel_suivi', array(
			'title' => 'Analytique · Suivi budgétaire mensuel', 'tab' => 'controle',
			'annee' => $annee, 'annees' => $this->annees(), 'sections' => $sections, 'div' => $div, 'seuil' => $seuil,
			's' => FKC_BudgetMensuel::suivi( $annee, $div, $jusqua, $seuil ), 'flash' => $this->flash(),
		) );
	}

	public function budgetMensuelExport() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.controle_budgetaire' ) ) { redirect( 'analytique' ); }
		$annee = $this->anneeParam();
		$div = (int) ( $_GET['section'] ?? 0 );
		fkc_csv( 'budget-mensuel-' . FKC_AnaDetail::slug( FKC_BudgetMensuel::nomSection( $div ) ) . '-' . $annee . '.csv', FKC_BudgetMensuel::csv( $annee, $div ) );
	}

	/** Multi-axes analytiques (Enterprise) : résultats regroupés par axe. */
	public function multiAxes() {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$this->syncSources();
		$annee = $this->anneeParam();
		FKC_View::render( 'analytique::multi_axes', array(
			'title' => 'Analytique · Multi-axes', 'tab' => 'multi_axes',
			'annee' => $annee, 'annees' => $this->annees(),
			'data' => FKC_Division::resultatsParAxe( $annee ), 'axes' => FKC_Axe::all(),
			// Ce que chaque axe entraînerait dans sa chute, calculé AVANT
			// d'offrir le bouton (1.768.0).
			'impacts' => $this->impactsAxes(), 'flash' => $this->flash(),
		) );
	}
	/** Impact de suppression par axe : id => array(valeurs, affectations, …). */
	protected function impactsAxes() {
		$out = array();
		foreach ( FKC_Axe::all() as $a ) { $out[ (int) $a['id'] ] = FKC_Axe::impact( (int) $a['id'] ); }
		return $out;
	}

	public function axeStore() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		$lib = trim( (string) ( $_POST['libelle'] ?? '' ) );
		if ( '' === $code || '' === $lib ) { $this->setFlash( 'Code et libellé requis.' ); }
		elseif ( ! preg_match( '/^[A-Z0-9_-]{2,10}$/', $code ) ) {
			// Le code sert d'étiquette partout (écrans, exports, clés de
			// répartition) : un espace ou un accent s'y retrouverait pour de bon.
			$this->setFlash( 'Le code d\'axe doit faire 2 à 10 caractères, en lettres, chiffres, tiret ou souligné (ex. PROJ, ARTISTE).' );
		} elseif ( FKC_Axe::codeExists( $code ) ) { $this->setFlash( 'Ce code d\'axe existe déjà.' ); }
		else { FKC_Axe::create( array( 'code' => $code, 'libelle' => $lib, 'actif' => 1 ) ); $this->setFlash( 'Axe « ' . $lib . ' » créé. Ajoutez-lui ses valeurs depuis l\'onglet Valeurs.' ); }
		redirect( 'analytique/multi-axes' );
	}
	/**
	 * RENOMMER UN AXE (1.768.0).
	 *
	 * On pouvait créer un axe et le supprimer, jamais le corriger : une faute
	 * dans le libellé ou un code mal choisi n'avait qu'une issue, la
	 * suppression — qui emporte valeurs, affectations, budgets et clés de
	 * répartition. Une coquille coûtait le paramétrage entier.
	 *
	 * Le code de l'axe DIV reste figé : il porte le référentiel des divisions,
	 * et le reste du module le reconnaît par ce code. Son libellé, lui, se
	 * corrige comme les autres.
	 */
	public function axeUpdate( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$a = FKC_Axe::find( $id );
		if ( ! $a ) { $this->setFlash( 'Axe introuvable.' ); redirect( 'analytique/multi-axes' ); }
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		$lib  = trim( (string) ( $_POST['libelle'] ?? '' ) );
		if ( 'DIV' === $a['code'] ) { $code = 'DIV'; }
		if ( '' === $lib ) { $this->setFlash( 'Le libellé ne peut pas être vide.' ); }
		elseif ( ! preg_match( '/^[A-Z0-9_-]{2,10}$/', $code ) ) {
			$this->setFlash( 'Le code d\'axe doit faire 2 à 10 caractères, en lettres, chiffres, tiret ou souligné.' );
		} elseif ( FKC_Axe::codeExists( $code, (int) $id ) ) { $this->setFlash( 'Ce code d\'axe est déjà pris.' ); }
		else {
			FKC_Axe::update( (int) $id, array( 'code' => $code, 'libelle' => $lib, 'actif' => (int) $a['actif'], 'ordre' => (int) $a['ordre'] ) );
			$this->setFlash( 'Axe mis à jour.' . ( 'DIV' === $a['code'] && 'DIV' !== strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) )
				? ' Son code reste DIV : le référentiel des divisions s\'y rattache.' : '' ) );
		}
		redirect( 'analytique/multi-axes' );
	}

	/**
	 * ACTIVER / DÉSACTIVER UN AXE (1.768.0).
	 *
	 * Le champ `actif` existait en base et filtrait déjà les listes de saisie,
	 * mais rien ne permettait de le basculer. C'est pourtant le geste juste
	 * quand un axe ne sert plus : il disparaît des écrans de saisie, et tout
	 * l'historique qui s'y rattache reste lisible — là où la suppression
	 * l'effacerait.
	 */
	public function axeToggle( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$a = FKC_Axe::find( $id );
		if ( ! $a ) { $this->setFlash( 'Axe introuvable.' ); redirect( 'analytique/multi-axes' ); }
		if ( 'DIV' === $a['code'] ) {
			$this->setFlash( 'L\'axe Division ne se désactive pas : il porte le référentiel des divisions.' );
			redirect( 'analytique/multi-axes' );
		}
		$actif = empty( $a['actif'] ) ? 1 : 0;
		FKC_Axe::update( (int) $id, array( 'code' => $a['code'], 'libelle' => $a['libelle'], 'actif' => $actif, 'ordre' => (int) $a['ordre'] ) );
		$this->setFlash( $actif
			? 'Axe « ' . $a['libelle'] .' » réactivé : il revient dans les écrans de saisie.'
			: 'Axe « ' . $a['libelle'] . ' » désactivé : il ne sera plus proposé à la saisie, et son historique reste consultable.' );
		redirect( 'analytique/multi-axes' );
	}

	public function axeDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$a = FKC_Axe::find( $id );
		/*
		 * UNE SUPPRESSION QUI EMPORTE DES DONNÉES SE DEMANDE DEUX FOIS (1.768.0).
		 *
		 * `delete()` retire l'axe ET ses affectations, budgets et clés de
		 * répartition, puis annonce les dégâts APRÈS coup. Sur un axe qui ne
		 * porte encore rien, c'est sans conséquence ; sur un axe en service,
		 * c'est un paramétrage entier qui disparaît sur un clic. Le poids est
		 * désormais annoncé AVANT, et la désactivation proposée — qui garde
		 * l'historique lisible.
		 */
		if ( $a && empty( $_POST['forcer'] ) ) {
			$imp = FKC_Axe::impact( (int) $id );
			$porte = array();
			if ( $imp['affectations'] ) { $porte[] = $imp['affectations'] . ' affectation(s) d\'écriture'; }
			if ( $imp['budgets'] )      { $porte[] = $imp['budgets'] . ' budget(s)'; }
			if ( $imp['repartitions'] ) { $porte[] = $imp['repartitions'] . ' clé(s) de répartition'; }
			if ( $imp['bases'] )        { $porte[] = $imp['bases'] . ' répartition(s) qui s\'appuient dessus'; }
			if ( $porte ) {
				$this->setFlash( 'Suppression refusée : cet axe porte ' . implode( ', ', $porte )
					. '. Désactivez-le pour qu\'il cesse d\'être proposé à la saisie sans rien perdre, ou confirmez la suppression définitive.' );
				redirect( 'analytique/multi-axes' );
			}
		}
		$imp = FKC_Axe::delete( $id );
		if ( false === $imp ) {
			$this->setFlash( $a && 'DIV' === $a['code']
				? 'L\'axe Division ne peut pas être supprimé : il porte le référentiel des divisions.'
				: 'Suppression impossible.' );
		} else {
			// Ce qui a disparu AVEC l'axe est dit : sans cela, l'utilisateur
			// découvrait plus tard que sa clé de répartition n'existait plus.
			$suite = array();
			if ( $imp['valeurs'] )      { $suite[] = $imp['valeurs'] . ' valeur(s)'; }
			if ( $imp['affectations'] ) { $suite[] = $imp['affectations'] . ' affectation(s)'; }
			if ( $imp['budgets'] )      { $suite[] = $imp['budgets'] . ' budget(s)'; }
			if ( $imp['repartitions'] ) { $suite[] = $imp['repartitions'] . ' répartition(s)'; }
			$msg = 'Axe supprimé.' . ( $suite ? ' Retiré avec lui : ' . implode( ', ', $suite ) . '.' : '' );
			if ( ! empty( $imp['bases'] ) ) {
				$msg .= ' ' . $imp['bases'] . ' répartition(s) dynamique(s) qui s\'appuyaient sur cet axe sont repassées en clé fixe : re-paramétrez-les.';
			}
			$this->setFlash( $msg );
		}
		redirect( 'analytique/multi-axes' );
	}

	/** Reporting BI avancé (Enterprise) : tableaux de bord visuels. */
	public function bi() {
		if ( ! $this->feature( 'analytique.reporting_bi' ) ) { return; }
		$this->syncSources();
		$annee = $this->anneeParam();
		$profitAxes = array();
		foreach ( FKC_Axe::all() as $a ) {
			$r = FKC_Affectation::resultatsParAxe( (int) $a['id'], $annee );
			if ( ! empty( $r['lignes'] ) ) { $profitAxes[] = array( 'axe' => $a, 'res' => $r ); }
		}
		FKC_View::render( 'analytique::bi', array(
			'title' => 'Analytique · Reporting BI', 'tab' => 'bi',
			'annee' => $annee, 'annees' => $this->annees(),
			'res' => FKC_Division::resultats( $annee ), 'mensuel' => FKC_Division::resultatMensuel( $annee ),
			'profitAxes' => $profitAxes, 'budget' => FKC_Budget::controle( $annee )['totaux'],
			'kpi' => FKC_AnaKpi::compute( $annee ), 'flash' => $this->flash(),
		) );
	}

	/* ── Paramétrage général : exercices analytiques + paramètres ── */
	public function parametrage() {
		if ( ! $this->feature( 'analytique.parametrage' ) ) { return; }
		FKC_View::render( 'analytique::parametrage', array(
			'title' => 'Analytique · Paramétrage', 'tab' => 'parametrage',
			'exercices' => FKC_AnaExercice::all(), 'params' => FKC_AnaExercice::params(),
			'annees' => $this->annees(),
			'comptables' => $this->exercicesReference(),
			'courant' => class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::courant() : date( 'Y' ),
			'flash' => $this->flash(),
		) );
	}
	public function parametresSave() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.parametrage' ) ) { redirect( 'analytique' ); }
		FKC_AnaExercice::saveParams( $_POST );
		$this->setFlash( 'Paramètres analytiques enregistrés.' );
		redirect( 'analytique/parametrage' );
	}
	/**
	 * Exercices comptables servant de référence : ceux déclarés ET ceux qui
	 * portent des écritures (un dossier repris n'a pas toujours « ouvert »
	 * ses exercices), avec leurs bornes réelles et leur clôture annuelle.
	 */
	protected function exercicesReference() {
		$out = array();
		foreach ( $this->annees() as $y ) {
			$b = FKC_Division::bornes( $y );
			if ( ! $b ) { continue; }
			$out[] = array( 'annee' => (int) $y, 'periode_debut' => $b[0], 'periode_fin' => $b[1],
				'cloture_annuelle' => class_exists( 'FKC_Cloture' ) && FKC_Cloture::isExerciceClos( $b[1] ) );
		}
		return $out;
	}

	/** Plus de création d'« exercice analytique » : aucun calcul ne les lisait (1.822.0). */
	public function exerciceStore() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.parametrage' ) ) { redirect( 'analytique' ); }
		$this->setFlash( 'Les exercices analytiques ne se créent plus : l\'analytique suit les exercices comptables (Paramètres → Exercices).' );
		redirect( 'analytique/parametrage' );
	}
	public function exerciceDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.parametrage' ) ) { redirect( 'analytique' ); }
		FKC_AnaExercice::delete( $id );
		$this->setFlash( 'Exercice supprimé.' );
		redirect( 'analytique/parametrage' );
	}

	/* ── Valeurs analytiques (tableau central par axe) ── */
	public function valeurs() {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$this->syncSources();
		$axes = FKC_Axe::all();
		$axeId = (int) ( $_GET['axe'] ?? ( $axes[0]['id'] ?? 0 ) );
		$axe = FKC_Axe::find( $axeId ) ?: ( $axes[0] ?? null );
		$valeurs = $axe ? ( 'DIV' === $axe['code'] ? array() : FKC_Valeur::byAxe( $axe['id'] ) ) : array();
		$impacts = array();
		foreach ( $valeurs as $v ) { $impacts[ (int) $v['id'] ] = FKC_Valeur::impact( $v['id'] ); }
		FKC_View::render( 'analytique::valeurs', array(
			'title' => 'Analytique · Valeurs', 'tab' => 'valeurs',
			'axes' => $axes, 'axe' => $axe,
			'impacts' => $impacts,
			'estAdmin' => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'valeurs' => $valeurs,
			'divisions' => $axe && 'DIV' === $axe['code'] ? FKC_Division::all() : array(),
			'flash' => $this->flash(),
		) );
	}
	public function valeurStore() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$axeId = (int) ( $_POST['axe_id'] ?? 0 );
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		$lib = trim( (string) ( $_POST['libelle'] ?? '' ) );
		if ( '' === $code || '' === $lib ) { $this->setFlash( 'Code et libellé requis.' ); }
		elseif ( FKC_Valeur::codeExists( $axeId, $code ) ) { $this->setFlash( 'Ce code existe déjà pour cet axe.' ); }
		else { FKC_Valeur::create( $axeId, $code, $lib, (int) ( $_POST['ordre'] ?? 0 ) ); $this->setFlash( 'Valeur ajoutée.' ); }
		redirect( 'analytique/valeurs?axe=' . $axeId );
	}
	public function valeurDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$v = FKC_Valeur::find( $id );
		list( $ok, $msg ) = FKC_Valeur::delete( $id );
		$this->setFlash( $msg );
		redirect( 'analytique/valeurs?axe=' . ( $v ? (int) $v['axe_id'] : '' ) );
	}

	/**
	 * Supprime une valeur analytique MALGRÉ ce qu'elle porte.
	 * Même cadre que destroyForce() : administrateur, conséquences annoncées
	 * avant confirmation, geste tracé à l'audit.
	 *
	 * Cas particulier des valeurs LIÉES à une fiche du référentiel : la
	 * suppression forcée fonctionne, mais le prochain rafraîchissement des
	 * écrans analytiques recréera la valeur à partir de sa fiche d'origine.
	 * L'écran le dit plutôt que de laisser croire à un bug.
	 */
	public function valeurDeleteForce( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$v = FKC_Valeur::find( $id );
		if ( ! $v ) { redirect( 'analytique/valeurs' ); }
		$imp = FKC_Valeur::impact( $id );
		list( $ok, $msg ) = FKC_Valeur::delete( $id, true ); // audit posé par le modèle
		$suite = '';
		if ( $ok && ! empty( $v['source_type'] ) ) {
			$suite = ' Attention : cette valeur reflète une fiche « ' . $v['source_type'] . ' » — elle sera recréée au prochain affichage d\'un écran analytique. '
				. 'Pour qu\'elle ne revienne pas, supprimez la fiche dans son module, ou désactivez la valeur après sa recréation.';
		}
		$this->setFlash( $ok
			? 'Valeur « ' . $v['libelle'] . ' » supprimée avec ' . $imp['affectations'] . ' affectation(s), '
				. $imp['budgets'] . ' budget(s) et ' . $imp['cles'] . ' clé(s) de répartition. L\'opération est tracée à l\'audit.' . $suite
			: $msg );
		redirect( 'analytique/valeurs?axe=' . (int) $v['axe_id'] );
	}

	/** Désactive / réactive une valeur analytique (conserve ses affectations). */
	public function valeurToggle( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$v = FKC_Valeur::find( $id );
		if ( ! $v ) { redirect( 'analytique/valeurs' ); }
		$actif = empty( $v['actif'] );
		FKC_Valeur::setActif( $id, $actif );
		$this->setFlash( 'Valeur « ' . $v['libelle'] . ' » ' . ( $actif ? 'réactivée.' : 'désactivée : elle quitte les sélecteurs, son historique reste lisible.' ) );
		redirect( 'analytique/valeurs?axe=' . (int) $v['axe_id'] );
	}

	/* ── Affectations analytiques multi-axes ── */
	public function affectations() {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		// Sans cette synchronisation, une fiche créée à l'instant dans son
		// module n'apparaissait pas dans les sélecteurs de cet écran.
		$this->syncSources();
		$annee = $this->anneeParam();
		$restant = ! empty( $_GET['restant'] );
		$axes = FKC_Axe::all( true );
		$valeursParAxe = array(); $libelles = array();
		foreach ( $axes as $a ) {
			$aid = (int) $a['id'];
			$toutes = 'DIV' === $a['code'] ? FKC_Division::all() : FKC_Valeur::byAxe( $aid );
			$valeursParAxe[ $aid ] = array_values( array_filter( $toutes, function ( $v ) { return ! empty( $v['actif'] ); } ) );
			// Libellés de TOUTES les valeurs : une ligne portant une valeur
			// désactivée doit la montrer (et la garder) — l'ancien écran
			// l'affichait « — » et l'effaçait au premier enregistrement.
			foreach ( $toutes as $v ) { $libelles[ $aid ][ (int) $v['id'] ] = $v['libelle'] . ( empty( $v['actif'] ) ? ' (désactivée)' : '' ); }
		}
		$opts = array( 'non_affectees' => $restant );
		$parPage = FKC_Affectation::taillePage( count( $axes ) + 1 ); // + la case à cocher de la ligne
		$total = FKC_Affectation::compterLignes( $annee, $opts );
		$pages = max( 1, (int) ceil( $total / $parPage ) );
		$page = min( $pages, max( 1, (int) ( $_GET['page'] ?? 1 ) ) );
		$lignes = FKC_Affectation::lignesAnalytiques( $annee, $parPage, $opts + array( 'offset' => ( $page - 1 ) * $parPage ) );
		$affect = array(); $verrou = array();
		$ventil = FKC_Ventilation::pourLignes( array_column( $lignes, 'id' ) );
		$cles = array();
		if ( FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) {
			$noms = array(); foreach ( $axes as $a ) { $noms[ (int) $a['id'] ] = $a['code']; }
			foreach ( FKC_Repartition::all() as $r ) {
				if ( empty( $r['actif'] ) ) { continue; }
				$cible = 'dynamique' === $r['type'] && ! empty( $r['base_axe_id'] ) ? (int) $r['base_axe_id'] : (int) $r['axe_id'];
				$cles[] = array( 'id' => (int) $r['id'], 'libelle' => $r['code'] . ' · ' . $r['libelle'] . ' (' . ( $noms[ $cible ] ?? '?' ) . ', ' . $r['type'] . ')' );
			}
		}
		foreach ( $lignes as $l ) {
			$affect[ (int) $l['id'] ] = FKC_Affectation::forLigne( $l['id'] );
			$verrou[ (int) $l['id'] ] = FKC_Affectation::estVerrouillee( $l['date_ecriture'] );
		}
		FKC_View::render( 'analytique::affectations', array(
			'title' => 'Analytique · Affectations', 'tab' => 'affectations',
			'annee' => $annee, 'annees' => $this->annees(), 'axes' => $axes,
			'valeursParAxe' => $valeursParAxe, 'libelles' => $libelles, 'lignes' => $lignes, 'affect' => $affect, 'verrou' => $verrou,
			'ventil' => $ventil, 'cles' => $cles,
			'restant' => $restant, 'reste' => FKC_Affectation::resteAAffecter( $annee ),
			'page' => $page, 'pages' => $pages, 'total' => $total, 'parPage' => $parPage,
			'attente' => $this->enAttente(), 'flash' => $this->flash(),
		) );
	}

	/**
	 * Écritures encore au journal temporaire : elles ne sont PAS dans
	 * l'analytique, parce qu'elles ne sont pas encore en comptabilité. Le
	 * silence sur ce point faisait chercher des montants manquants côté
	 * analytique alors qu'ils attendaient simplement leur validation.
	 */
	protected function enAttente() {
		try {
			if ( ! class_exists( 'FKC_Brouillard' ) ) { return 0; }
			return (int) FKC_DB::q( 'SELECT COUNT(*) FROM ecritures_brouillon' )->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}
	public function affectationsSave() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$retour = 'analytique/affectations?annee=' . preg_replace( '/\D/', '', (string) ( $_POST['annee'] ?? date( 'Y' ) ) )
			. ( empty( $_POST['restant'] ) ? '' : '&restant=1' )
			. ( empty( $_POST['page'] ) ? '' : '&page=' . (int) $_POST['page'] );
		/*
		 * Le champ `_fin` est le DERNIER du formulaire. S'il manque, PHP a
		 * tronqué l'envoi (max_input_vars) : on n'enregistre rien plutôt que
		 * la moitié d'une page, puisque rien ne dirait laquelle.
		 */
		if ( empty( $_POST['_fin'] ) ) {
			$this->setFlash( 'Enregistrement refusé : le formulaire est arrivé incomplet (limite du serveur). Rien n\'a été modifié — rechargez la page et recommencez.' );
			redirect( $retour );
		}
		$r = FKC_Affectation::enregistrerLot( (array) ( $_POST['aff'] ?? array() ) );
		$msg = $r['modifiees']
			? $r['modifiees'] . ' affectation(s) modifiée(s) sur ' . $r['lignes'] . ' ligne(s).'
			: 'Aucun changement à enregistrer.';
		if ( $r['refus'] ) {
			$msg .= ' ' . count( $r['refus'] ) . ' refus : ' . implode( ' ', array_slice( $r['refus'], 0, 3 ) ) . ( count( $r['refus'] ) > 3 ? ' …' : '' );
		}
		$this->setFlash( $msg );
		redirect( $retour );
	}

	/* ── Ventilation d'une ligne en pourcentages (1.823.0) ── */

	/** Valeurs d'un axe proposées à la ventilation (divisions pour DIV). */
	protected function valeursVentilables( array $axe ) {
		$out = array();
		$src = 'DIV' === $axe['code'] ? FKC_Division::all( true ) : FKC_Valeur::byAxe( $axe['id'], true );
		foreach ( $src as $v ) { $out[ (int) $v['id'] ] = $v['libelle']; }
		return $out;
	}

	public function ventiler( $id ) {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$this->syncSources();
		$l = FKC_DB::q(
			'SELECT el.*, e.date_ecriture, e.piece, e.libelle ecriture_libelle, c.numero, c.libelle compte_libelle
			 FROM ecriture_lignes el JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
			 WHERE el.id=? AND ' . FKC_Division::sqlGestion(),
			array( (int) $id )
		)->fetch();
		if ( ! $l ) { $this->setFlash( 'Ligne introuvable ou hors classes 6/7/8.' ); redirect( 'analytique/affectations' ); }
		$axes = FKC_Axe::all( true );
		$axeId = (int) ( $_GET['axe'] ?? 0 );
		$vent = FKC_Ventilation::pourLigne( $id );
		if ( ! $axeId ) { $axeId = $vent ? (int) array_key_first( $vent ) : (int) ( $axes[0]['id'] ?? 0 ); }
		$axe = null;
		foreach ( $axes as $a ) { if ( (int) $a['id'] === $axeId ) { $axe = $a; } }
		if ( ! $axe && $axes ) { $axe = $axes[0]; $axeId = (int) $axe['id']; }
		$annee = class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::annee( $l['date_ecriture'] ) : substr( $l['date_ecriture'], 0, 4 );
		// Clés proposées pour pré-remplir : celles qui ventilent cet axe, calculées pour l'exercice de la ligne.
		$cles = array();
		if ( $axe && FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) {
			foreach ( FKC_Repartition::all() as $r ) {
				if ( empty( $r['actif'] ) ) { continue; }
				list( $ok, $msg, $cAxe, $parts ) = FKC_Ventilation::partsCle( $r['id'], $annee );
				if ( $cAxe !== $axeId ) { continue; }
				$cles[] = array( 'id' => (int) $r['id'], 'code' => $r['code'], 'libelle' => $r['libelle'], 'type' => $r['type'], 'ok' => $ok, 'msg' => $msg, 'parts' => $parts );
			}
		}
		$cur = FKC_Affectation::forLigne( $id );
		FKC_View::render( 'analytique::ventiler', array(
			'title' => 'Analytique · Ventiler une ligne', 'tab' => 'affectations',
			'l' => $l, 'montant' => (float) ( $l['debit'] > 0 ? $l['debit'] : $l['credit'] ), 'annee' => $annee,
			'axes' => $axes, 'axe' => $axe, 'valeurs' => $axe ? $this->valeursVentilables( $axe ) : array(),
			'vent' => $vent, 'parts' => $vent[ $axeId ] ?? array(), 'unique' => (int) ( $cur[ $axeId ] ?? 0 ),
			'verrou' => FKC_Affectation::estVerrouillee( $l['date_ecriture'] ), 'cles' => $cles,
			'retour' => (string) ( $_GET['retour'] ?? '' ), 'flash' => $this->flash(),
		) );
	}

	public function ventilerSave( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$axeId = (int) ( $_POST['axe_id'] ?? 0 );
		$retour = preg_replace( '#[^a-z0-9_/?=&%.-]#i', '', (string) ( $_POST['retour'] ?? '' ) );
		if ( ! preg_match( '#^analytique/affectations(\?|$)#', $retour ) ) { $retour = ''; } // jamais de sortie du module
		$ici = 'analytique/affectations/' . (int) $id . '/ventiler?axe=' . $axeId . ( '' !== $retour ? '&retour=' . rawurlencode( $retour ) : '' );
		if ( 'retirer' === ( $_POST['action'] ?? '' ) ) {
			list( $ok, $msg ) = FKC_Ventilation::retirer( $id, $axeId );
			$this->setFlash( $ok ? $msg : 'Refusé : ' . $msg );
			redirect( $ici );
		}
		$parts = array();
		foreach ( (array) ( $_POST['valeur'] ?? array() ) as $i => $v ) {
			$v = (int) $v; if ( $v <= 0 ) { continue; }
			$p = (float) str_replace( ',', '.', (string) ( $_POST['pct'][ $i ] ?? 0 ) );
			$parts[ $v ] = ( $parts[ $v ] ?? 0 ) + $p;
		}
		$rep = (int) ( $_POST['repartition_id'] ?? 0 );
		list( $ok, $msg ) = FKC_Ventilation::definir( $id, $axeId, $parts, array( 'repartition_id' => $rep ?: null ) );
		$this->setFlash( $ok ? $msg : 'Refusé : ' . $msg );
		redirect( $ok && '' !== $retour ? $retour : $ici );
	}

	/** Applique une clé de répartition aux lignes cochées de l'écran Affectations. */
	public function appliquerCle() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) || ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		$retour = 'analytique/affectations?annee=' . preg_replace( '/\D/', '', (string) ( $_POST['annee'] ?? date( 'Y' ) ) )
			. ( empty( $_POST['restant'] ) ? '' : '&restant=1' )
			. ( empty( $_POST['page'] ) ? '' : '&page=' . (int) $_POST['page'] );
		$rep = (int) ( $_POST['repartition_id'] ?? 0 );
		$ids = array_map( 'intval', (array) ( $_POST['lignes'] ?? array() ) );
		if ( ! $rep || ! $ids ) {
			$this->setFlash( 'Refusé : cochez au moins une ligne et choisissez une clé.' );
			redirect( $retour );
		}
		$r = FKC_Ventilation::appliquerCle( $rep, $ids );
		$msg = $r['appliquees'] ? 'Clé appliquée à ' . $r['appliquees'] . ' ligne(s).' : 'Aucune ligne ventilée.';
		if ( $r['refus'] ) { $msg .= ' ' . count( $r['refus'] ) . ' refus : ' . implode( ' ', array_slice( $r['refus'], 0, 3 ) ) . ( count( $r['refus'] ) > 3 ? ' …' : '' ); }
		$this->setFlash( $msg );
		redirect( $retour );
	}

	/** Réapplique une clé aux lignes qu'elle ventile (exercices ouverts). */
	public function reappliquerCle( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		$r = FKC_Ventilation::reappliquerCle( (int) $id );
		$msg = $r['appliquees'] ? 'Clé réappliquée : ' . $r['appliquees'] . ' ligne(s) recalculée(s).' : 'Aucune ligne à recalculer (exercices clôturés exclus).';
		if ( $r['refus'] ) { $msg .= ' ' . count( $r['refus'] ) . ' refus : ' . implode( ' ', array_slice( $r['refus'], 0, 3 ) ); }
		$this->setFlash( $msg );
		redirect( 'analytique/repartitions?rep=' . (int) $id );
	}

	/* ── Règles d'imputation automatique (1.824.0) ── */

	public function regles() {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$this->syncSources();
		$annee = $this->anneeParam();
		$axes = FKC_Axe::all( true );
		$valeurs = array();
		foreach ( $axes as $a ) { $valeurs[ (int) $a['id'] ] = $this->valeursVentilables( $a ); }
		$cles = array();
		if ( FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) {
			foreach ( FKC_Repartition::all() as $r ) {
				if ( empty( $r['actif'] ) ) { continue; }
				$cible = 'dynamique' === $r['type'] && ! empty( $r['base_axe_id'] ) ? (int) $r['base_axe_id'] : (int) $r['axe_id'];
				$cles[ $cible ][ (int) $r['id'] ] = $r['code'] . ' · ' . $r['libelle'] . ' (' . $r['type'] . ')';
			}
		}
		$tiers = array();
		foreach ( array( 'fournisseur' => 'fournisseurs', 'client' => 'clients' ) as $t => $table ) {
			try { foreach ( FKC_DB::q( "SELECT id, nom FROM {$table} ORDER BY nom COLLATE NOCASE LIMIT 1000" )->fetchAll() as $x ) { $tiers[ $t ][ $t . ':' . (int) $x['id'] ] = $x['nom']; } }
			catch ( \Throwable $e ) { /* table absente */ }
		}
		$regles = FKC_AnaRegle::all();
		foreach ( $regles as &$r ) { $r['texte'] = FKC_AnaRegle::decrire( $r ); }
		unset( $r );
		FKC_View::render( 'analytique::regles', array(
			'title' => 'Analytique · Règles d\'imputation', 'tab' => 'regles',
			'regles' => $regles, 'axes' => $axes, 'valeurs' => $valeurs, 'cles' => $cles, 'tiers' => $tiers,
			'journaux' => FKC_Journal::all(), 'annee' => $annee, 'annees' => $this->annees(),
			'apercu' => FKC_AnaRegle::apercu( $annee ), 'reste' => FKC_Affectation::resteAAffecter( $annee ),
			'form' => $_SESSION['__ana_regle_form'] ?? array(), 'flash' => $this->flash(),
		) );
		unset( $_SESSION['__ana_regle_form'] );
	}

	public function regleStore() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$d = $_POST;
		$axe = (int) ( $d['axe_id'] ?? 0 );
		// L'écran envoie une valeur ET une clé par axe : on ne garde que celles de l'axe choisi, selon le mode.
		$mode = 'cle' === ( $d['mode'] ?? '' ) ? 'cle' : 'valeur';
		$d['valeur_id'] = 'valeur' === $mode ? (int) ( $d['valeur'][ $axe ] ?? 0 ) : 0;
		$d['repartition_id'] = 'cle' === $mode ? (int) ( $d['cle'][ $axe ] ?? 0 ) : 0;
		list( $ok, $msg ) = FKC_AnaRegle::creer( $d );
		if ( ! $ok ) { $_SESSION['__ana_regle_form'] = array_intersect_key( $_POST, array_flip( array( 'libelle', 'priorite', 'compte_prefixe', 'journal_id', 'tiers', 'libelle_contient', 'axe_id', 'mode' ) ) ); }
		$this->setFlash( $ok ? $msg : 'Refusé : ' . $msg );
		redirect( 'analytique/regles' );
	}

	public function regleToggle( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		FKC_AnaRegle::basculer( $id );
		$r = FKC_AnaRegle::find( $id );
		$this->setFlash( $r ? 'Règle « ' . $r['libelle'] . ' » ' . ( empty( $r['actif'] ) ? 'suspendue.' : 'réactivée.' ) : 'Règle introuvable.' );
		redirect( 'analytique/regles' );
	}

	public function regleDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		FKC_AnaRegle::supprimer( $id );
		$this->setFlash( 'Règle supprimée. Les imputations qu\'elle a déjà posées restent en place.' );
		redirect( 'analytique/regles' );
	}

	public function reglesAppliquer() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$annee = preg_replace( '/\D/', '', (string) ( $_POST['annee'] ?? '' ) );
		$r = FKC_AnaRegle::appliquerExercice( $annee );
		if ( $r['clos'] ) { $msg = 'Refusé : l\'exercice ' . $annee . ' est clôturé, ses imputations sont figées.'; }
		else {
			$msg = $r['imputations'] ? $r['imputations'] . ' imputation(s) posée(s) sur ' . $r['lignes'] . ' ligne(s) de l\'exercice ' . $annee . '.' : 'Aucune ligne à imputer : les règles ne trouvent rien de vide qui leur corresponde.';
			if ( $r['refus'] ) { $msg .= ' ' . count( $r['refus'] ) . ' refus : ' . implode( ' ', array_slice( $r['refus'], 0, 3 ) ); }
		}
		$this->setFlash( $msg );
		redirect( 'analytique/regles?annee=' . $annee );
	}

	/* ── Détail d'un montant, exports (1.825.0) ── */

	/** Axe demandé (id ou « DIV »), avec contrôle de la fonction nécessaire. */
	protected function axeDemande() {
		$a = (string) ( $_GET['axe'] ?? '' );
		if ( 'DIV' === strtoupper( $a ) || '' === $a ) {
			$id = FKC_Ventilation::axeDivision();
		} else { $id = (int) $a; }
		$axe = $id ? FKC_Axe::find( $id ) : null;
		return $axe;
	}

	/** Paramètres du détail, repris dans les liens (export, filtres). */
	protected function optsDetail() {
		$o = array();
		$n = (string) ( $_GET['nature'] ?? '' );
		if ( isset( FKC_AnaDetail::NATURES[ $n ] ) ) { $o['nature'] = $n; }
		$m = (string) ( $_GET['mois'] ?? '' );
		if ( preg_match( '/^\d{4}-\d{2}$/', $m ) ) { $o['mois'] = $m; }
		$c = (string) ( $_GET['compte'] ?? '' );
		if ( preg_match( '/^[678]\d{0,5}$/', $c ) ) { $o['compte'] = $c; }
		return $o;
	}

	public function detail() {
		$axe = $this->axeDemande();
		if ( ! $axe ) { $this->setFlash( 'Axe introuvable.' ); redirect( 'analytique' ); }
		if ( 'DIV' !== $axe['code'] && ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$annee = $this->anneeParam();
		$valeur = (int) ( $_GET['valeur'] ?? 0 );
		$opts = $this->optsDetail();
		$axe2 = ! empty( $_GET['axe2'] ) ? FKC_Axe::find( (int) $_GET['axe2'] ) : null;
		$valeur2 = (int) ( $_GET['valeur2'] ?? 0 );
		if ( $axe2 && ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { $axe2 = null; }
		$d = $axe2
			? FKC_AnaCroise::detailCase( $axe['id'], $valeur, $axe2['id'], $valeur2, $annee, $opts + array( 'limite' => 500 ) )
			: FKC_AnaDetail::lignes( $axe['id'], $valeur, $annee, $opts + array( 'limite' => 500 ) );
		$aux = false;
		if ( class_exists( 'FKC_AnaAuxiliaire' ) && 'DIV' !== $axe['code'] ) {
			foreach ( FKC_AnaAuxiliaire::parAxe( $axe['id'], true ) as $x ) { $aux = true; break; }
		}
		FKC_View::render( 'analytique::detail', array(
			'title' => 'Analytique · Détail', 'tab' => 'resultats',
			'axe' => $axe, 'valeur' => $valeur, 'annee' => $annee, 'annees' => $this->annees(), 'opts' => $opts,
			'axe2' => $axe2, 'valeur2' => $valeur2,
			'd' => $d, 'aux' => $aux, 'flash' => $this->flash(),
		) );
	}

	public function detailExport() {
		$axe = $this->axeDemande();
		if ( ! $axe || ( 'DIV' !== $axe['code'] && ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) ) { redirect( 'analytique' ); }
		$annee = $this->anneeParam();
		$valeur = (int) ( $_GET['valeur'] ?? 0 );
		$nom = 'analytique-' . FKC_AnaDetail::slug( $axe['code'] ) . '-' . FKC_AnaDetail::slug( FKC_AnaDetail::libelleValeur( $axe, $valeur ) ) . '-' . $annee . '.csv';
		$axe2 = ! empty( $_GET['axe2'] ) ? FKC_Axe::find( (int) $_GET['axe2'] ) : null;
		if ( $axe2 ) {
			$valeur2 = (int) ( $_GET['valeur2'] ?? 0 );
			$d = FKC_AnaCroise::detailCase( $axe['id'], $valeur, $axe2['id'], $valeur2, $annee, $this->optsDetail() );
			$nom = 'analytique-croise-' . FKC_AnaDetail::slug( $d['valeur'] ) . '-' . $annee . '.csv';
			fkc_csv( $nom, FKC_AnaDetail::csvDepuis( $d, $annee ) );
		}
		fkc_csv( $nom, FKC_AnaDetail::csvDetail( $axe['id'], $valeur, $annee, $this->optsDetail() ) );
	}

	public function resultatsExport() {
		$axe = $this->axeDemande();
		if ( ! $axe || ( 'DIV' !== $axe['code'] && ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) ) { redirect( 'analytique' ); }
		$annee = $this->anneeParam();
		fkc_csv( 'analytique-resultats-' . FKC_AnaDetail::slug( $axe['code'] ) . '-' . $annee . '.csv', FKC_AnaDetail::csvResultats( $axe['id'], $annee ) );
	}

	/* ── Tableau croisé sur deux axes (1.826.0) ── */

	public function croise() {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$this->syncSources();
		$axes = FKC_Axe::all();
		$annee = $this->anneeParam();
		$x = (int) ( $_GET['x'] ?? 0 ); $y = (int) ( $_GET['y'] ?? 0 );
		// Par défaut : Division en lignes, le premier autre axe qui porte quelque chose en colonnes.
		if ( ! $x ) { $x = FKC_Ventilation::axeDivision() ?: (int) ( $axes[0]['id'] ?? 0 ); }
		if ( ! $y ) {
			foreach ( $axes as $a ) {
				if ( (int) $a['id'] === $x ) { continue; }
				$imp = FKC_Axe::impact( $a['id'] );
				if ( ! $y ) { $y = (int) $a['id']; }
				if ( $imp['affectations'] > 0 ) { $y = (int) $a['id']; break; }
			}
		}
		$mesure = (string) ( $_GET['mesure'] ?? 'resultat' );
		if ( ! isset( FKC_AnaCroise::MESURES[ $mesure ] ) ) { $mesure = 'resultat'; }
		$m = FKC_AnaCroise::calculer( $x, $y, $annee );
		list( $cols, $autres ) = $m['ok'] ? FKC_AnaCroise::colonnesAffichees( $m, $mesure ) : array( array(), array() );
		FKC_View::render( 'analytique::croise', array(
			'title' => 'Analytique · Tableau croisé', 'tab' => 'croise',
			'axes' => $axes, 'x' => $x, 'y' => $y, 'annee' => $annee, 'annees' => $this->annees(), 'mesure' => $mesure,
			'm' => $m, 'cols' => $cols, 'autres' => $autres, 'flash' => $this->flash(),
		) );
	}

	public function croiseExport() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.multi_axes' ) ) { redirect( 'analytique' ); }
		$x = (int) ( $_GET['x'] ?? 0 ); $y = (int) ( $_GET['y'] ?? 0 );
		$mesure = (string) ( $_GET['mesure'] ?? 'resultat' );
		if ( ! isset( FKC_AnaCroise::MESURES[ $mesure ] ) ) { $mesure = 'resultat'; }
		$ax = FKC_Axe::find( $x ); $ay = FKC_Axe::find( $y );
		$annee = $this->anneeParam();
		fkc_csv( 'analytique-croise-' . FKC_AnaDetail::slug( ( $ax['code'] ?? 'x' ) . '-' . ( $ay['code'] ?? 'y' ) ) . '-' . $mesure . '-' . $annee . '.csv',
			FKC_AnaCroise::csv( $x, $y, $annee, $mesure ) );
	}

	/* ── Résultats analytiques par axe (Division/Projet/Client/Produit) ── */
	public function resultatsAnalytiques() {
		if ( ! $this->feature( 'analytique.multi_axes' ) ) { return; }
		$this->syncSources();
		$annee = $this->anneeParam();
		$axes = FKC_Axe::all();
		$axeId = (int) ( $_GET['axe'] ?? ( $axes[0]['id'] ?? 0 ) );
		FKC_View::render( 'analytique::resultats_analytiques', array(
			'title' => 'Analytique · Résultats par axe', 'tab' => 'resultats_ana',
			'annee' => $annee, 'annees' => $this->annees(), 'axes' => $axes, 'axeId' => $axeId,
			/*
			 * La répartition secondaire est appliquée APRÈS le calcul, sur le
			 * résultat obtenu : elle ne touche ni les écritures ni la requête,
			 * uniquement la lecture. Désactivée, l'écran retrouve exactement
			 * les chiffres d'avant.
			 */
			'res' => FKC_AnaAuxiliaire::appliquer( FKC_Affectation::resultatsParAxe( $axeId, $annee ), $axeId, $annee ),
			'flash' => $this->flash(),
		) );
	}

	/* ── Sections auxiliaires (répartition secondaire) ── */

	public function auxiliaires() {
		if ( ! $this->feature( 'analytique.repartitions' ) ) { return; }
		$this->syncSources();
		$axes  = FKC_Axe::all();
		$axeId = (int) ( $_GET['axe'] ?? ( $axes[0]['id'] ?? 0 ) );
		FKC_View::render( 'analytique::auxiliaires', array(
			'title' => 'Analytique · Sections auxiliaires', 'tab' => 'auxiliaires',
			'axes' => $axes, 'axeId' => $axeId,
			'auxiliaires' => FKC_AnaAuxiliaire::parAxe( $axeId ),
			'valeurs' => FKC_AnaAuxiliaire::valeursAxe( $axeId ),
			'annee' => $this->anneeParam(), 'flash' => $this->flash(),
		) );
	}

	public function auxiliaireCreer() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		$axeId = (int) ( $_POST['axe_id'] ?? 0 );
		list( $ok, $msg ) = FKC_AnaAuxiliaire::creer( $axeId, $_POST['source_id'] ?? 0, $_POST['libelle'] ?? '', $_POST['note'] ?? '' );
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'analytique/auxiliaires?axe=' . $axeId );
	}

	public function auxiliairePart( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		list( $ok, $msg ) = FKC_AnaAuxiliaire::setPart( $id, $_POST['cible_id'] ?? 0, $_POST['part'] ?? 0 );
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'analytique/auxiliaires?axe=' . (int) ( $_POST['axe_id'] ?? 0 ) );
	}

	public function auxiliaireRetirer( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		list( , $msg ) = FKC_AnaAuxiliaire::retirerPart( $id, $_POST['cible_id'] ?? 0 );
		$this->setFlash( $msg );
		redirect( 'analytique/auxiliaires?axe=' . (int) ( $_POST['axe_id'] ?? 0 ) );
	}

	public function auxiliaireBasculer( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		list( , $msg ) = FKC_AnaAuxiliaire::basculer( $id );
		$this->setFlash( $msg );
		redirect( 'analytique/auxiliaires?axe=' . (int) ( $_POST['axe_id'] ?? 0 ) );
	}

	public function auxiliaireSupprimer( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		list( , $msg ) = FKC_AnaAuxiliaire::supprimer( $id );
		$this->setFlash( $msg );
		redirect( 'analytique/auxiliaires?axe=' . (int) ( $_POST['axe_id'] ?? 0 ) );
	}

	/* ── Répartitions ── */
	public function repartitions() {
		if ( ! $this->feature( 'analytique.repartitions' ) ) { return; }
		$this->syncSources();
		$sel = isset( $_GET['rep'] ) ? FKC_Repartition::find( (int) $_GET['rep'] ) : null;
		$sim = null;
		if ( $sel && isset( $_GET['montant'] ) ) { $sim = FKC_Repartition::simuler( $sel['id'], (float) $_GET['montant'], $this->anneeParam() ); }
		FKC_View::render( 'analytique::repartitions', array(
			'title' => 'Analytique · Répartitions', 'tab' => 'repartitions',
			'repartitions' => FKC_Repartition::all(), 'types' => FKC_Repartition::types(),
			'axes' => FKC_Axe::all(), 'sel' => $sel, 'sim' => $sim, 'usage' => FKC_Ventilation::usageCles(),
			'montant' => $_GET['montant'] ?? '', 'flash' => $this->flash(),
		) );
	}
	public function repartitionStore() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		if ( '' === $code || '' === trim( (string) ( $_POST['libelle'] ?? '' ) ) || empty( $_POST['axe_id'] ) ) { $this->setFlash( 'Code, libellé et axe requis.' ); }
		elseif ( FKC_Repartition::codeExists( $code ) ) { $this->setFlash( 'Ce code de répartition existe déjà.' ); }
		else { $id = FKC_Repartition::create( $_POST ); $this->setFlash( 'Répartition créée.' ); redirect( 'analytique/repartitions?rep=' . $id ); }
		redirect( 'analytique/repartitions' );
	}
	public function repartitionCle() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		$rid = (int) ( $_POST['repartition_id'] ?? 0 );
		list( $ok, $msg ) = FKC_Repartition::setCle( $rid, (int) ( $_POST['valeur_id'] ?? 0 ), (float) ( $_POST['pourcentage'] ?? 0 ) );
		// Le total est rappelé à chaque saisie : c'est lui qui décide si la clé
		// sera appliquée, et l'utilisateur le corrige au fil de l'eau plutôt
		// que de le découvrir à la simulation.
		if ( $ok ) {
			$somme = FKC_Repartition::sommeCles( $rid );
			$msg  .= ' Total de la clé : ' . rtrim( rtrim( number_format( $somme, 2, ',', ' ' ), '0' ), ',' ) . ' %'
				. ( FKC_Repartition::estComplete( $rid ) ? ' — la clé est applicable.' : ' — il faut 100 % pour qu\'elle s\'applique.' );
		}
		$this->setFlash( $msg );
		redirect( 'analytique/repartitions?rep=' . $rid );
	}

	/** Retire une valeur d'une clé fixe — distinct d'une part fixée à 0 %. */
	public function repartitionCleDelete() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		$rid = (int) ( $_POST['repartition_id'] ?? 0 );
		FKC_Repartition::removeCle( $rid, (int) ( $_POST['valeur_id'] ?? 0 ) );
		$somme = FKC_Repartition::sommeCles( $rid );
		$this->setFlash( 'Valeur retirée de la clé. Total : ' . rtrim( rtrim( number_format( $somme, 2, ',', ' ' ), '0' ), ',' ) . ' %'
			. ( FKC_Repartition::estComplete( $rid ) ? ' — la clé est applicable.' : ' — il faut 100 % pour qu\'elle s\'applique.' ) );
		redirect( 'analytique/repartitions?rep=' . $rid );
	}
	public function repartitionDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'analytique.repartitions' ) ) { redirect( 'analytique' ); }
		FKC_Repartition::delete( $id );
		$this->setFlash( 'Répartition supprimée.' );
		redirect( 'analytique/repartitions' );
	}

	/* ── KPI analytiques ── */
	public function kpi() {
		if ( ! $this->feature( 'analytique.kpi' ) ) { return; }
		$annee = $this->anneeParam();
		FKC_View::render( 'analytique::kpi', array(
			'title' => 'Analytique · KPI', 'tab' => 'kpi',
			'annee' => $annee, 'annees' => $this->annees(), 'kpi' => FKC_AnaKpi::compute( $annee ), 'flash' => $this->flash(),
		) );
	}

	/* ── Budgets / contrôle par axe ── */
	public function budgetsAxe() {
		if ( ! $this->feature( 'analytique.budgets' ) ) { return; }
		$this->syncSources();
		$annee = $this->anneeParam();
		$axes = array_values( array_filter( FKC_Axe::all(), function ( $a ) { return 'DIV' !== $a['code']; } ) );
		$axeId = (int) ( $_GET['axe'] ?? ( $axes[0]['id'] ?? 0 ) );
		$valeurs = $axeId ? FKC_Valeur::byAxe( $axeId, true ) : array();
		$map = array();
		foreach ( FKC_Budget::allAxe( $axeId, $annee ) as $b ) { $map[ (int) $b['valeur_id'] ] = $b; }
		FKC_View::render( 'analytique::budgets_axe', array(
			'title' => 'Analytique · Budgets par axe', 'tab' => 'budgets',
			'annee' => $annee, 'annees' => $this->annees(), 'axes' => $axes, 'axeId' => $axeId,
			'valeurs' => $valeurs, 'budgets' => $map, 'flash' => $this->flash(),
		) );
	}
	public function budgetAxeSave() {
		if ( ! FKC_Modules::featureEnabled( 'analytique.budgets' ) ) { redirect( 'analytique' ); }
		$annee = preg_replace( '/\D/', '', (string) ( $_POST['annee'] ?? date( 'Y' ) ) ) ?: date( 'Y' );
		$axeId = (int) ( $_POST['axe_id'] ?? 0 );
		$prod = $_POST['produits'] ?? array(); $charg = $_POST['charges'] ?? array(); $notes = $_POST['note'] ?? array();
		foreach ( FKC_Valeur::byAxe( $axeId, true ) as $v ) {
			$id = (int) $v['id']; $p = (float) ( $prod[ $id ] ?? 0 ); $c = (float) ( $charg[ $id ] ?? 0 ); $n = trim( (string) ( $notes[ $id ] ?? '' ) );
			if ( $p > 0 || $c > 0 || '' !== $n ) { FKC_Budget::upsertAxe( $axeId, $id, $annee, $p, $c, $n ); }
			else { FKC_Budget::deleteAxe( $axeId, $id, $annee ); }
		}
		$this->setFlash( 'Budgets enregistrés.' );
		redirect( 'analytique/budgets-axe?axe=' . $axeId . '&annee=' . $annee );
	}
	public function controleAxe() {
		if ( ! $this->feature( 'analytique.controle_budgetaire' ) ) { return; }
		$this->syncSources();
		$annee = $this->anneeParam();
		$axes = array_values( array_filter( FKC_Axe::all(), function ( $a ) { return 'DIV' !== $a['code']; } ) );
		$axeId = (int) ( $_GET['axe'] ?? ( $axes[0]['id'] ?? 0 ) );
		$seuil = (int) ( $_GET['seuil'] ?? 90 );
		$sim = isset( $_GET['sim'] ) ? max( 0, (float) $_GET['sim'] ) : 0; // % variation charges simulée
		FKC_View::render( 'analytique::controle_axe', array(
			'title' => 'Analytique · Contrôle par axe', 'tab' => 'controle',
			'annee' => $annee, 'annees' => $this->annees(), 'axes' => $axes, 'axeId' => $axeId,
			'seuil' => $seuil, 'sim' => $sim, 'ctrl' => $axeId ? FKC_Budget::controleAxe( $axeId, $annee, $seuil ) : array( 'lignes' => array(), 'totaux' => array(), 'seuil' => $seuil ),
			'flash' => $this->flash(),
		) );
	}

	/* ── helpers ── */

	protected function validate( $d, $exceptId ) {
		$e = array();
		$code = strtoupper( trim( (string) ( $d['code'] ?? '' ) ) );
		if ( '' === $code ) { $e[] = 'Le code est requis.'; }
		elseif ( FKC_Division::codeExists( $code, $exceptId ) ) { $e[] = 'Ce code de division existe déjà.'; }
		if ( '' === trim( (string) ( $d['libelle'] ?? '' ) ) ) { $e[] = 'Le libellé est requis.'; }
		return $e;
	}

	protected function annees() {
		if ( class_exists( 'FKC_Exercice' ) ) { $y = FKC_Exercice::annees(); if ( $y ) { return $y; } }
		$ys = array();
		try {
			foreach ( FKC_DB::q( "SELECT DISTINCT substr(date_ecriture,1,4) y FROM ecritures WHERE date_ecriture IS NOT NULL" )->fetchAll() as $r ) {
				if ( ! empty( $r['y'] ) ) { $ys[] = $r['y']; }
			}
		} catch ( Exception $e ) { /* */ }
		$cur = date( 'Y' );
		if ( ! in_array( $cur, $ys, true ) ) { $ys[] = $cur; }
		$ys = array_values( array_unique( $ys ) );
		rsort( $ys );
		return $ys;
	}

	protected function setFlash( $m ) { $_SESSION['__flash_ana'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_ana'] ?? null; unset( $_SESSION['__flash_ana'] ); return $m; }
}
