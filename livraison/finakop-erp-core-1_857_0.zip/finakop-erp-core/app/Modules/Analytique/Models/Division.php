<?php
/** Divisions analytiques (centres de coûts / business units) + contrôle de gestion. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Division {

	/** Types de section analytique. */
	public static function types() {
		return array(
			'siege'      => 'Siège / Général',
			'division'   => 'Division / Business unit',
			'centre'     => 'Centre de coût',
			'projet'     => 'Projet',
			'agence'     => 'Agence / Site',
			'activite'   => "Branche d'activité",
		);
	}

	/** Nature économique d'une section : centre de coût, de profit, ou mixte. */
	public static function natures() {
		return array( 'cout' => 'Centre de coût', 'profit' => 'Centre de profit', 'mixte' => 'Mixte' );
	}

	/**
	 * Bornes de l'exercice analytique.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * L'ANALYTIQUE COMPTAIT DOUZE MOIS QUI N'ÉTAIENT PAS CEUX DU DOSSIER (1.547.0)
	 *
	 * Depuis 1.544.0, un exercice peut ne pas être l'année civile : les états
	 * DGI, la clôture, les amortissements et la fiscalité lisent tous
	 * `FKC_Exercice::bornes()`. Tout le module Analytique était resté sur
	 * « substr(date_ecriture,1,4)=? ». Chez un dossier clôturant au 30/06, le
	 * résultat par division, les budgets, le comparatif N-1 et les KPI
	 * couvraient donc juillet→juin décalé d'un semestre par rapport au compte
	 * de résultat — et le sélecteur affichait pourtant « Exercice 2026 »,
	 * puisqu'il lit déjà FKC_Exercice::annees(). L'écran annonçait la bonne
	 * période et calculait la mauvaise, sans que rien ne le signale : les
	 * totaux étaient cohérents entre eux, simplement pas ceux de l'exercice.
	 *
	 * Un dossier en année civile — l'immense majorité — retrouve exactement
	 * le comportement d'avant : bornes(2026) = 2026-01-01 → 2026-12-31.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @param string|int $annee Millésime ; vide = toutes périodes.
	 * @return array{0:string,1:string}|null null si aucun filtre de période.
	 */
	public static function bornes( $annee ) {
		$y = (string) $annee;
		if ( '' === $y || ! preg_match( '/^\d{4}$/', $y ) ) { return null; }
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'bornes' ) ) {
			try { return FKC_Exercice::bornes( (int) $y ); } catch ( \Throwable $e ) { /* repli */ }
		}
		return array( $y . '-01-01', $y . '-12-31' );
	}

	/**
	 * Fragment SQL « AND date BETWEEN ? AND ? » et paramètres associés.
	 * Source unique : tout le module y passe, plus aucun substr() en dur.
	 */
	public static function filtrePeriode( $annee, array &$params, $alias = 'e' ) {
		$hors = self::horsCloture( $alias );
		$b = self::bornes( $annee );
		if ( ! $b ) { return $hors; }
		$params[] = $b[0];
		$params[] = $b[1];
		return " AND {$alias}.date_ecriture BETWEEN ? AND ? " . $hors;
	}

	/**
	 * L'ÉCRITURE DE DÉTERMINATION DU RÉSULTAT N'EST PAS DE L'ACTIVITÉ (1.822.0).
	 *
	 * La clôture annuelle solde toutes les classes 6, 7 et 8 au dernier jour
	 * de l'exercice, sans section analytique. Lue comme une opération
	 * ordinaire, elle passait tout en « Non imputé » avec le signe opposé :
	 * le total analytique d'un exercice clôturé tombait à ZÉRO, le chiffre
	 * d'affaires des KPI aussi, décembre plongeait dans le BI, et deux lignes
	 * fictives restaient « à affecter » pour toujours. Les états DGI
	 * l'écartaient déjà ; l'Analytique l'écarte désormais de la même façon
	 * (FKC_EtatsDgi::sqlEcritureResultat), dans CHAQUE requête du module,
	 * puisque toutes passent par filtrePeriode().
	 */
	public static function horsCloture( $alias = 'e' ) {
		static $colonnes = null;
		if ( null === $colonnes ) {
			try {
				$cols = array_column( FKC_DB::q( 'PRAGMA table_info(ecritures)' )->fetchAll(), 'name' );
				$colonnes = in_array( 'origine', $cols, true ) && in_array( 'source', $cols, true );
			} catch ( \Throwable $e ) { $colonnes = false; }
		}
		if ( ! $colonnes ) { return ''; }
		$sql = class_exists( 'FKC_EtatsDgi' ) && method_exists( 'FKC_EtatsDgi', 'sqlEcritureResultat' )
			? FKC_EtatsDgi::sqlEcritureResultat( $alias )
			: "( COALESCE({$alias}.origine,'') = 'resultat' AND COALESCE({$alias}.source,'') = 'cloture' )";
		return " AND NOT {$sql} ";
	}

	/**
	 * Expressions SQL des trois blocs du compte de résultat (1.822.0) :
	 * produits et charges des ACTIVITÉS ORDINAIRES (classes 7 et 6), et solde
	 * HORS ACTIVITÉS ORDINAIRES (classe 8 : cessions, subventions
	 * d'équilibre, participation, impôt sur le résultat). La classe 8 était
	 * ignorée : dès qu'elle portait quelque chose, le total analytique
	 * s'écartait du résultat net sans explication.
	 */
	public static function sqlBlocs( $alias = 'el', $compte = 'c', $coef = '' ) {
		// $coef : multiplicateur SQL optionnel (part d'une ventilation, 1.823.0).
		$k = '' === (string) $coef ? '' : ' * ( ' . $coef . ' )';
		return "COALESCE(SUM(CASE WHEN {$compte}.numero LIKE '7%' THEN ( {$alias}.credit - {$alias}.debit ){$k} ELSE 0 END),0) AS produits,
			   COALESCE(SUM(CASE WHEN {$compte}.numero LIKE '6%' THEN ( {$alias}.debit - {$alias}.credit ){$k} ELSE 0 END),0) AS charges,
			   COALESCE(SUM(CASE WHEN {$compte}.numero LIKE '8%' THEN ( {$alias}.credit - {$alias}.debit ){$k} ELSE 0 END),0) AS hao";
	}

	/** Filtre « compte de gestion » : classes 6, 7 et 8. */
	public static function sqlGestion( $compte = 'c' ) {
		return "( {$compte}.numero LIKE '6%' OR {$compte}.numero LIKE '7%' OR {$compte}.numero LIKE '8%' )";
	}

	public static function all( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE actif=1' : '';
		return FKC_DB::q( "SELECT * FROM divisions{$w} ORDER BY ordre, libelle COLLATE NOCASE" )->fetchAll();
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM divisions WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	public static function count( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE actif=1' : '';
		return (int) FKC_DB::q( "SELECT COUNT(*) FROM divisions{$w}" )->fetchColumn();
	}

	public static function codeExists( $code, $exceptId = 0 ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM divisions WHERE code=? AND id<>?', array( $code, (int) $exceptId ) )->fetch();
	}

	public static function create( $d ) {
		FKC_DB::q(
			'INSERT INTO divisions(code,libelle,type,nature,axe_id,actif,ordre) VALUES(?,?,?,?,?,?,?)',
			array(
				strtoupper( trim( (string) $d['code'] ) ),
				trim( (string) $d['libelle'] ),
				trim( (string) ( $d['type'] ?? 'division' ) ) ?: 'division',
				isset( self::natures()[ $d['nature'] ?? '' ] ) ? $d['nature'] : 'mixte',
				! empty( $d['axe_id'] ) ? (int) $d['axe_id'] : null,
				empty( $d['actif'] ) ? 0 : 1,
				(int) ( $d['ordre'] ?? 0 ),
			)
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	public static function update( $id, $d ) {
		FKC_DB::q(
			'UPDATE divisions SET code=?, libelle=?, type=?, nature=?, axe_id=?, actif=?, ordre=? WHERE id=?',
			array(
				strtoupper( trim( (string) $d['code'] ) ),
				trim( (string) $d['libelle'] ),
				trim( (string) ( $d['type'] ?? 'division' ) ) ?: 'division',
				isset( self::natures()[ $d['nature'] ?? '' ] ) ? $d['nature'] : 'mixte',
				! empty( $d['axe_id'] ) ? (int) $d['axe_id'] : null,
				empty( $d['actif'] ) ? 0 : 1,
				(int) ( $d['ordre'] ?? 0 ),
				(int) $id,
			)
		);
	}

	/** Active ou désactive une section sans toucher à son histoire. */
	public static function setActif( $id, $actif ) {
		FKC_DB::q( 'UPDATE divisions SET actif=? WHERE id=?', array( $actif ? 1 : 0, (int) $id ) );
	}

	/**
	 * Ce qu'une division porte encore : lignes d'écriture, factures, budgets.
	 * Calculé AVANT de proposer une suppression — l'utilisateur doit voir ce
	 * qu'il efface, et le code doit pouvoir dire non sans deviner.
	 */
	public static function impact( $id ) {
		$id = (int) $id;
		$n  = function ( $sql ) use ( $id ) {
			try { return (int) FKC_DB::q( $sql, array( $id ) )->fetchColumn(); } catch ( \Throwable $e ) { return 0; }
		};
		$lignes = $n( 'SELECT COUNT(*) FROM ecriture_lignes WHERE division_id=?' )
			+ ( class_exists( 'FKC_Ventilation' ) ? FKC_Ventilation::compter( 'valeur_id', $id, FKC_Ventilation::axeDivision() ) : 0 );
		$fv     = $n( 'SELECT COUNT(*) FROM factures WHERE division_id=?' );
		$ff     = $n( 'SELECT COUNT(*) FROM factures_fournisseurs WHERE division_id=?' );
		$bud    = $n( 'SELECT COUNT(*) FROM budgets WHERE division_id=?' );
		return array(
			'lignes'   => $lignes,
			'factures' => $fv + $ff,
			'budgets'  => $bud,
			'total'    => $lignes + $fv + $ff + $bud,
		);
	}

	/**
	 * Sections retenues par le résultat analytique d'un exercice.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UNE DIVISION DÉSACTIVÉE PERDAIT TOUT SON HISTORIQUE (1.547.0)
	 *
	 * `resultats()` bouclait sur `all( true )` — les sections actives
	 * seulement. Désactiver une division (une agence fermée, une business
	 * unit arrêtée en cours d'année) la faisait donc disparaître du résultat
	 * par division, du contrôle budgétaire, du comparatif N/N-1 et des
	 * centres de coûts/profit. Ses écritures, elles, restaient en base : les
	 * montants n'étaient pas rebasculés en « Non imputé » (leur division_id
	 * n'est pas NULL), ils étaient simplement absents du tableau. Le total
	 * affiché ne correspondait plus au compte de résultat, et rien ne
	 * l'expliquait.
	 *
	 * Une section désactivée n'est pas une section qui n'a jamais existé :
	 * on cesse de POUVOIR L'IMPUTER (elle disparaît des sélecteurs et de la
	 * saisie de budget), on ne cesse pas de LA LIRE. Elle reste donc au
	 * résultat dès qu'elle porte quelque chose sur la période — écritures ou
	 * budget — et l'écran la marque « inactive ».
	 * ─────────────────────────────────────────────────────────────────────
	 */
	public static function sectionsDuResultat( $annee = '', array $autres = array() ) {
		$toutes = self::all();
		$actives = array();
		$dormantes = array();
		foreach ( $toutes as $d ) {
			if ( ! empty( $d['actif'] ) ) { $actives[] = $d; } else { $dormantes[ (int) $d['id'] ] = $d; }
		}
		if ( ! $dormantes ) { return $actives; }

		// Sections inactives qui portent encore quelque chose sur l'exercice.
		$vivantes = array();
		$params   = array();
		$f        = self::filtrePeriode( $annee, $params );
		try {
			$sql = "SELECT DISTINCT el.division_id d FROM ecriture_lignes el
			        JOIN ecritures e ON e.id = el.ecriture_id
			        WHERE el.division_id IS NOT NULL {$f}";
			foreach ( FKC_DB::q( $sql, $params )->fetchAll() as $r ) { $vivantes[ (int) $r['d'] ] = true; }
		} catch ( \Throwable $e ) { /* base partielle : on garde ce qu'on a */ }
		try {
			$b = self::bornes( $annee );
			if ( $b ) {
				foreach ( FKC_DB::q( 'SELECT DISTINCT division_id d FROM budgets WHERE annee=?', array( (string) $annee ) )->fetchAll() as $r ) {
					$vivantes[ (int) $r['d'] ] = true;
				}
			}
		} catch ( \Throwable $e ) { /* table budgets absente */ }

		foreach ( $autres as $id ) { $vivantes[ (int) $id ] = true; } // divisions reçues par ventilation
		$out = $actives;
		foreach ( $dormantes as $id => $d ) {
			if ( isset( $vivantes[ $id ] ) ) { $out[] = $d; }
		}
		// L'ordre de all() est perdu par la concaténation : on le rétablit.
		usort( $out, function ( $a, $b ) {
			$o = (int) $a['ordre'] <=> (int) $b['ordre'];
			return $o ?: strcasecmp( (string) $a['libelle'], (string) $b['libelle'] );
		} );
		return $out;
	}

	/**
	 * Supprime une division.
	 *
	 * REFUS MOTIVÉ (1.547.0) : tant qu'elle porte des imputations, la
	 * supprimer effaçait sans un mot l'analytique de toutes ses écritures —
	 * elles repassaient en « non imputé » et le travail d'affectation était
	 * perdu, irrécupérablement. Une division qu'on n'utilise plus se
	 * DÉSACTIVE : elle quitte les sélecteurs, garde son histoire.
	 *
	 * @param bool $forcer Réservé à un nettoyage délibéré (saisie de test).
	 * @return array{0:bool,1:string}
	 */
	public static function delete( $id, $forcer = false ) {
		$id = (int) $id;
		$d  = self::find( $id );
		if ( ! $d ) { return array( false, 'Division introuvable.' ); }
		$imp = self::impact( $id );
		if ( $imp['total'] > 0 && ! $forcer ) {
			$quoi = array();
			if ( $imp['lignes'] )   { $quoi[] = $imp['lignes'] . ' ligne(s) d\'écriture'; }
			if ( $imp['factures'] ) { $quoi[] = $imp['factures'] . ' facture(s)'; }
			if ( $imp['budgets'] )  { $quoi[] = $imp['budgets'] . ' budget(s)'; }
			return array( false, 'Suppression refusée : « ' . $d['libelle'] . ' » porte ' . implode( ', ', $quoi )
				. '. Les effacer perdrait définitivement leur imputation analytique. Désactivez la division : '
				. 'elle quitte les sélecteurs de saisie et conserve son historique dans les états.' );
		}
		/*
		 * La trace du forçage est posée ICI, dans le modèle, et non dans le
		 * contrôleur : un écart analytique constaté trois mois plus tard doit
		 * pouvoir s'expliquer quel que soit le chemin emprunté pour détruire
		 * la section — écran, script de reprise, ou appel d'un pack. Une trace
		 * attachée à un écran ne couvre que cet écran.
		 */
		if ( $forcer && $imp['total'] > 0 && class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'analytique_division_suppression_forcee',
				'Division « ' . $d['code'] . ' — ' . $d['libelle'] . ' » supprimée malgré son contenu : '
				. $imp['lignes'] . ' ligne(s) d\'écriture désimputée(s), ' . $imp['factures'] . ' facture(s), '
				. $imp['budgets'] . ' budget(s) supprimé(s).' );
		}
		FKC_DB::q( 'UPDATE ecriture_lignes SET division_id=NULL WHERE division_id=?', array( $id ) );
		if ( class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::supprimerPour( 'valeur_id', $id, FKC_Ventilation::axeDivision() ); }
		FKC_DB::q( 'UPDATE factures SET division_id=NULL WHERE division_id=?', array( $id ) );
		FKC_DB::q( 'UPDATE factures_fournisseurs SET division_id=NULL WHERE division_id=?', array( $id ) );
		FKC_DB::q( 'DELETE FROM budgets WHERE division_id=?', array( $id ) );
		FKC_DB::q( 'DELETE FROM divisions WHERE id=?', array( $id ) );
		return array( true, 'Division « ' . $d['libelle'] . ' » supprimée.' );
	}

	/**
	 * Résultat par division pour un exercice : produits (Cl.7), charges (Cl.6), résultat.
	 * Inclut une ligne « Non imputé » pour les mouvements sans division.
	 *
	 * @param string $annee année (YYYY) ; vide = toutes périodes
	 * @return array{lignes: array, non_impute: array, totaux: array}
	 */
	public static function resultats( $annee = '' ) {
		$params      = array();
		$filtreAnnee = self::filtrePeriode( $annee, $params );

		/*
		 * UNE SEULE REQUÊTE GROUPÉE (1.822.0) — il y en avait une par division,
		 * plus une pour le non imputé.
		 */
		$parDiv = array();
		$nonImp = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		foreach ( FKC_DB::q(
			"SELECT el.division_id AS d, " . self::sqlBlocs() . "
			 FROM ecriture_lignes el
			 JOIN ecritures e ON e.id = el.ecriture_id
			 JOIN comptes c ON c.id = el.compte_id
			 WHERE " . self::sqlGestion() . " {$filtreAnnee}
			 GROUP BY el.division_id",
			$params
		)->fetchAll() as $r ) {
			$v = array( 'produits' => (float) $r['produits'], 'charges' => (float) $r['charges'], 'hao' => (float) $r['hao'] );
			if ( null === $r['d'] ) { $nonImp = $v; } else { $parDiv[ (int) $r['d'] ] = $v; }
		}

		/*
		 * LIGNES VENTILÉES ENTRE PLUSIEURS DIVISIONS (1.823.0). Leur
		 * division_id est NULL : la requête ci-dessus les compte au non
		 * imputé. On les en retire, part par part, pour les porter à leurs
		 * divisions. Le total, lui, ne bouge pas.
		 */
		$ventDiv = array();
		if ( class_exists( 'FKC_Ventilation' ) && ( $axeDiv = FKC_Ventilation::axeDivision() ) ) {
			$ventDiv = FKC_Ventilation::montantsAxe( $axeDiv, $annee );
			foreach ( $ventDiv as $id => $v ) {
				foreach ( $v as $k => $x ) {
					$nonImp[ $k ] -= $x;
					$parDiv[ $id ][ $k ] = ( $parDiv[ $id ][ $k ] ?? 0.0 ) + $x;
				}
			}
		}

		$lignes = array();
		$vides = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		foreach ( self::sectionsDuResultat( $annee, array_keys( $ventDiv ) ) as $d ) {
			$v = $parDiv[ (int) $d['id'] ] ?? $vides;
			unset( $parDiv[ (int) $d['id'] ] );
			$lignes[] = array(
				'id'       => (int) $d['id'],
				'code'     => $d['code'],
				'libelle'  => $d['libelle'],
				'type'     => $d['type'],
				'nature'   => $d['nature'] ?? 'mixte',
				'axe_id'   => isset( $d['axe_id'] ) ? (int) $d['axe_id'] : 0,
				'actif'    => empty( $d['actif'] ) ? 0 : 1,
				'produits' => $v['produits'],
				'charges'  => $v['charges'],
				'resultat' => $v['produits'] - $v['charges'],
				'hao'      => $v['hao'],
				'resultat_net' => $v['produits'] - $v['charges'] + $v['hao'],
			);
		}
		/* Division supprimée d'une base ancienne mais encore référencée : ses montants rejoignent le non imputé. */
		foreach ( $parDiv as $v ) { foreach ( $nonImp as $k => $x ) { $nonImp[ $k ] += $v[ $k ]; } }

		$nonImpute = array(
			'id'       => 0,
			'code'     => '—',
			'libelle'  => 'Non imputé',
			'type'     => 'autre',
			'produits' => $nonImp['produits'],
			'charges'  => $nonImp['charges'],
			'resultat' => $nonImp['produits'] - $nonImp['charges'],
			'hao'      => $nonImp['hao'],
			'resultat_net' => $nonImp['produits'] - $nonImp['charges'] + $nonImp['hao'],
		);

		$totaux = array( 'produits' => 0.0, 'charges' => 0.0, 'resultat' => 0.0, 'hao' => 0.0, 'resultat_net' => 0.0 );
		foreach ( array_merge( $lignes, array( $nonImpute ) ) as $l ) {
			foreach ( $totaux as $k => $x ) { $totaux[ $k ] += $l[ $k ]; }
		}

		return array( 'lignes' => $lignes, 'non_impute' => $nonImpute, 'totaux' => $totaux );
	}

	/** Résultats regroupés par axe analytique (analyse multi-axes). */
	public static function resultatsParAxe( $annee = '' ) {
		$res = self::resultats( $annee );
		$axes = class_exists( 'FKC_Axe' ) ? FKC_Axe::map() : array();
		$groupes = array();
		foreach ( $res['lignes'] as $l ) {
			$aid = (int) ( $l['axe_id'] ?? 0 );
			$key = $aid ?: 0;
			if ( ! isset( $groupes[ $key ] ) ) {
				$groupes[ $key ] = array(
					'axe' => $aid && isset( $axes[ $aid ] ) ? $axes[ $aid ] : 'Sans axe',
					'lignes' => array(), 'produits' => 0.0, 'charges' => 0.0, 'resultat' => 0.0,
				);
			}
			$groupes[ $key ]['lignes'][] = $l;
			$groupes[ $key ]['produits'] += $l['produits'];
			$groupes[ $key ]['charges']  += $l['charges'];
			$groupes[ $key ]['resultat'] += $l['resultat'];
		}
		return array( 'groupes' => $groupes, 'totaux' => $res['totaux'] );
	}

	/**
	 * Évolution mensuelle produits/charges/résultat pour un exercice (BI).
	 *
	 * Les DOUZE MOIS DE L'EXERCICE, dans leur ordre — pas janvier→décembre.
	 * Sur un exercice ouvert au 1er juillet, la courbe commençait en janvier
	 * au milieu de l'exercice, remontait jusqu'en juin, puis retombait à zéro
	 * pour les mois à venir : une saisonnalité entièrement fictive.
	 *
	 * La clé reste le numéro de mois civil (1-12) pour ne rien casser chez
	 * les lecteurs existants ; l'ordre du tableau, lui, est celui de
	 * l'exercice, et chaque entrée porte son libellé.
	 */
	public static function resultatMensuel( $annee ) {
		$b = self::bornes( $annee );
		if ( ! $b ) { $b = array( date( 'Y' ) . '-01-01', date( 'Y' ) . '-12-31' ); }

		$mois = array();
		$curseur = $b[0];
		for ( $i = 0; $i < 12; $i++ ) {
			$m = (int) date( 'n', strtotime( $curseur ) );
			$mois[ $m ] = array(
				'produits' => 0.0, 'charges' => 0.0, 'resultat' => 0.0,
				'libelle'  => date( 'm/Y', strtotime( $curseur ) ),
				'rang'     => $i + 1,
			);
			$curseur = date( 'Y-m-d', strtotime( $curseur . ' +1 month' ) );
		}

		$rows = FKC_DB::q(
			"SELECT CAST(substr(e.date_ecriture,6,2) AS INTEGER) m,
			   COALESCE(SUM(CASE WHEN c.numero LIKE '7%' THEN el.credit - el.debit ELSE 0 END),0) produits,
			   COALESCE(SUM(CASE WHEN c.numero LIKE '6%' THEN el.debit - el.credit ELSE 0 END),0) charges
			 FROM ecriture_lignes el
			 JOIN ecritures e ON e.id = el.ecriture_id
			 JOIN comptes c ON c.id = el.compte_id
			 WHERE e.date_ecriture BETWEEN ? AND ? AND ( c.numero LIKE '6%' OR c.numero LIKE '7%' ) " . self::horsCloture() . "
			 GROUP BY m",
			array( $b[0], $b[1] )
		)->fetchAll();
		foreach ( $rows as $r ) {
			$m = (int) $r['m'];
			if ( isset( $mois[ $m ] ) ) {
				$mois[ $m ]['produits'] = (float) $r['produits'];
				$mois[ $m ]['charges']  = (float) $r['charges'];
				$mois[ $m ]['resultat'] = (float) $r['produits'] - (float) $r['charges'];
			}
		}
		return $mois;
	}
}
