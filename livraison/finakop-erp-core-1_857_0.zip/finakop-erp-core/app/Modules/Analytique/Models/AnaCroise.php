<?php
/**
 * TABLEAU CROISÉ SUR DEUX AXES (1.826.0).
 *
 * « Quel est le résultat du projet Alpha À Abidjan ? », « Quels clients
 * font la marge de chaque division ? » — les résultats par axe répondaient
 * axe par axe, jamais au croisement.
 *
 * Chaque ligne d'écriture de gestion (classes 6, 7, 8) porte, sur chaque
 * axe, soit une valeur (100 %), soit une ventilation (des parts), soit rien.
 * Sa contribution à la case (x, y) vaut :
 *
 *     montant × part sur l'axe X de x × part sur l'axe Y de y
 *
 * où « rien » compte comme une part de 100 % sur « Non affecté ». Les parts
 * d'une ligne totalisent 100 % sur chaque axe : les totaux de lignes égalent
 * donc les résultats par axe de X, les totaux de colonnes ceux de Y, et le
 * total général le compte de résultat analytique. Rien ne se perd au
 * croisement.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaCroise {

	const MESURES = array(
		'resultat'     => 'Résultat',
		'produits'     => 'Produits',
		'charges'      => 'Charges',
		'resultat_net' => 'Résultat net (avec HAO)',
	);

	/** Lignes de gestion de l'exercice : [id => [nature, montant signé, division_id, …]]. */
	protected static function lignesPeriode( $annee, $avecInfos = false ) {
		$params = array();
		$f = FKC_Division::filtrePeriode( $annee, $params );
		$cols = $avecInfos
			? ", e.id ecriture_id, e.date_ecriture, e.piece, e.numero ecriture_numero, COALESCE(NULLIF(el.libelle,''), e.libelle) libelle, c.libelle compte_libelle"
			: '';
		$out = array();
		foreach ( FKC_DB::q(
			"SELECT el.id, el.debit, el.credit, el.division_id, c.numero {$cols}
			 FROM ecriture_lignes el JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
			 WHERE " . FKC_Division::sqlGestion() . " {$f}",
			$params
		)->fetchAll() as $r ) {
			$cl = substr( (string) $r['numero'], 0, 1 );
			$r['nature'] = '7' === $cl ? 'produit' : ( '6' === $cl ? 'charge' : 'hao' );
			$r['montant'] = 'charge' === $r['nature'] ? (float) $r['debit'] - (float) $r['credit'] : (float) $r['credit'] - (float) $r['debit'];
			$out[ (int) $r['id'] ] = $r;
		}
		return $out;
	}

	/**
	 * Parts de chaque ligne sur un axe : [ligne_id => [valeur_id => fraction]].
	 * Les lignes absentes sont entièrement « non affectées » (valeur 0).
	 */
	protected static function parts( array $axe, $annee, array $lignes ) {
		FKC_Ventilation::ensure();
		$axeId = (int) $axe['id'];
		$estDiv = 'DIV' === $axe['code'];
		$m = array();
		if ( $estDiv ) {
			foreach ( $lignes as $id => $l ) { if ( ! empty( $l['division_id'] ) ) { $m[ $id ][ (int) $l['division_id'] ] = 1.0; } }
		} else {
			$params = array( $axeId );
			$f = FKC_Division::filtrePeriode( $annee, $params );
			foreach ( FKC_DB::q(
				"SELECT la.ecriture_ligne_id l, la.valeur_id v FROM ligne_affectations la
				 JOIN ecriture_lignes el ON el.id = la.ecriture_ligne_id JOIN ecritures e ON e.id = el.ecriture_id
				 WHERE la.axe_id = ? {$f}",
				$params
			)->fetchAll() as $r ) { $m[ (int) $r['l'] ][ (int) $r['v'] ] = 1.0; }
		}
		$params = array( $axeId );
		$f = FKC_Division::filtrePeriode( $annee, $params );
		foreach ( FKC_DB::q(
			"SELECT lv.ecriture_ligne_id l, lv.valeur_id v, lv.pourcentage p FROM ligne_ventilations lv
			 JOIN ecriture_lignes el ON el.id = lv.ecriture_ligne_id JOIN ecritures e ON e.id = el.ecriture_id
			 WHERE lv.axe_id = ? {$f}",
			$params
		)->fetchAll() as $r ) {
			$l = (int) $r['l'];
			if ( isset( $m[ $l ] ) && ! isset( $m[ $l ]['_v'] ) ) { continue; } // affectation directe : elle prime (même garde que partout)
			$m[ $l ][ (int) $r['v'] ] = ( $m[ $l ][ (int) $r['v'] ] ?? 0 ) + (float) $r['p'] / 100;
			$m[ $l ]['_v'] = true;
		}
		// Une valeur (ou division) disparue rejoint le non affecté, comme dans les résultats par axe.
		$connues = self::libelles( $axe );
		foreach ( $m as $l => $p ) {
			unset( $m[ $l ]['_v'] );
			foreach ( $m[ $l ] as $v => $f ) {
				if ( 0 !== $v && ! isset( $connues[ $v ] ) ) { unset( $m[ $l ][ $v ] ); $m[ $l ][0] = ( $m[ $l ][0] ?? 0 ) + $f; }
			}
			$reste = 1.0 - array_sum( $m[ $l ] );
			if ( $reste > 0.000001 ) { $m[ $l ][0] = ( $m[ $l ][0] ?? 0 ) + $reste; } // part d'une valeur disparue
		}
		return $m;
	}

	/** Libellés des valeurs d'un axe (toutes, actives ou non). */
	protected static function libelles( array $axe ) {
		$out = array();
		if ( 'DIV' === $axe['code'] ) {
			foreach ( FKC_Division::all() as $d ) { $out[ (int) $d['id'] ] = array( $d['code'], $d['libelle'] ); }
		} else {
			foreach ( FKC_Valeur::byAxe( $axe['id'] ) as $v ) { $out[ (int) $v['id'] ] = array( $v['code'], $v['libelle'] ); }
		}
		$out[0] = array( '—', 'DIV' === $axe['code'] ? 'Non imputé' : 'Non affecté' );
		return $out;
	}

	public static function mesure( array $c, $mesure ) {
		switch ( $mesure ) {
			case 'produits': return $c['produits'];
			case 'charges': return $c['charges'];
			case 'resultat_net': return $c['produits'] - $c['charges'] + $c['hao'];
			default: return $c['produits'] - $c['charges'];
		}
	}

	/**
	 * Calcule la matrice.
	 * @return array{ok:bool,message:string,axeX:array,axeY:array,lignes:array,colonnes:array,cases:array,totL:array,totC:array,total:array}
	 *   lignes/colonnes : [valeur_id => [code, libelle]] (ordre d'affichage) ;
	 *   cases[x][y], totL[x], totC[y], total : ['produits','charges','hao'].
	 */
	public static function calculer( $axeXId, $axeYId, $annee ) {
		$axeX = FKC_Axe::find( $axeXId ); $axeY = FKC_Axe::find( $axeYId );
		$vide = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		$out = array( 'ok' => false, 'message' => '', 'axeX' => $axeX, 'axeY' => $axeY, 'lignes' => array(), 'colonnes' => array(),
			'cases' => array(), 'totL' => array(), 'totC' => array(), 'total' => $vide );
		if ( ! $axeX || ! $axeY ) { $out['message'] = 'Choisissez deux axes.'; return $out; }
		if ( (int) $axeX['id'] === (int) $axeY['id'] ) { $out['message'] = 'Choisissez deux axes différents : un axe croisé avec lui-même ne dit rien de plus que ses résultats.'; return $out; }

		$lignes = self::lignesPeriode( $annee );
		$px = self::parts( $axeX, $annee, $lignes );
		$py = self::parts( $axeY, $annee, $lignes );
		$k = array( 'produit' => 'produits', 'charge' => 'charges', 'hao' => 'hao' );
		foreach ( $lignes as $id => $l ) {
			$bx = $px[ $id ] ?? array( 0 => 1.0 );
			$by = $py[ $id ] ?? array( 0 => 1.0 );
			$cle = $k[ $l['nature'] ];
			foreach ( $bx as $x => $fx ) {
				foreach ( $by as $y => $fy ) {
					$v = $l['montant'] * $fx * $fy;
					if ( ! isset( $out['cases'][ $x ][ $y ] ) ) { $out['cases'][ $x ][ $y ] = $vide; }
					$out['cases'][ $x ][ $y ][ $cle ] += $v;
					if ( ! isset( $out['totL'][ $x ] ) ) { $out['totL'][ $x ] = $vide; }
					if ( ! isset( $out['totC'][ $y ] ) ) { $out['totC'][ $y ] = $vide; }
					$out['totL'][ $x ][ $cle ] += $v;
					$out['totC'][ $y ][ $cle ] += $v;
					$out['total'][ $cle ] += $v;
				}
			}
		}
		// Ordre : valeurs dans l'ordre de l'axe, « non affecté » en dernier ; seules celles qui portent quelque chose.
		foreach ( array( 'lignes' => array( $axeX, 'totL' ), 'colonnes' => array( $axeY, 'totC' ) ) as $cle => $def ) {
			$lib = self::libelles( $def[0] );
			$ids = array_keys( $out[ $def[1] ] );
			$ordre = array_flip( array_keys( $lib ) );
			usort( $ids, function ( $a, $b ) use ( $ordre ) {
				if ( 0 === $a ) { return 1; } if ( 0 === $b ) { return -1; }
				return ( $ordre[ $a ] ?? PHP_INT_MAX ) <=> ( $ordre[ $b ] ?? PHP_INT_MAX );
			} );
			foreach ( $ids as $i ) { $out[ $cle ][ $i ] = $lib[ $i ] ?? array( '#' . $i, '#' . $i ); }
		}
		$out['ok'] = true;
		return $out;
	}

	/**
	 * Au-delà de $max colonnes, les plus petites (en valeur absolue de la
	 * mesure) sont regroupées dans « Autres » — l'écran reste lisible sur une
	 * tablette ; l'export garde tout.
	 * @return array [colonnes affichées, ids regroupés]
	 */
	public static function colonnesAffichees( array $m, $mesure, $max = 12 ) {
		$cols = $m['colonnes'];
		if ( count( $cols ) <= $max ) { return array( $cols, array() ); }
		$poids = array();
		foreach ( $cols as $y => $x ) { $poids[ $y ] = 0 === $y ? PHP_INT_MAX : abs( self::mesure( $m['totC'][ $y ], $mesure ) ); }
		arsort( $poids );
		$garde = array_slice( array_keys( $poids ), 0, $max - 1, true );
		$aff = array(); $autres = array();
		foreach ( $cols as $y => $x ) { if ( in_array( $y, $garde, true ) ) { $aff[ $y ] = $x; } else { $autres[] = $y; } }
		return array( $aff, $autres );
	}

	/** Somme de plusieurs cases (regroupement « Autres »). */
	public static function somme( array $cases ) {
		$s = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		foreach ( $cases as $c ) { foreach ( $s as $k => $v ) { $s[ $k ] += $c[ $k ] ?? 0; } }
		return $s;
	}

	/**
	 * Lignes d'écriture d'une case, au format de FKC_AnaDetail::lignes()
	 * (la part est le produit des deux parts).
	 */
	public static function detailCase( $axeXId, $x, $axeYId, $y, $annee, array $opts = array() ) {
		$axeX = FKC_Axe::find( $axeXId ); $axeY = FKC_Axe::find( $axeYId );
		$tot = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		$res = array( 'axe' => $axeX, 'axe2' => $axeY, 'valeur' => '', 'lignes' => array(), 'nb' => 0, 'tronque' => false,
			'totaux' => $tot + array( 'resultat' => 0.0, 'resultat_net' => 0.0 ) );
		if ( ! $axeX || ! $axeY ) { return $res; }
		$lignes = self::lignesPeriode( $annee, true );
		$px = self::parts( $axeX, $annee, $lignes );
		$py = self::parts( $axeY, $annee, $lignes );
		$k = array( 'produit' => 'produits', 'charge' => 'charges', 'hao' => 'hao' );
		$out = array();
		foreach ( $lignes as $id => $l ) {
			$fx = ( $px[ $id ] ?? array( 0 => 1.0 ) )[ (int) $x ] ?? 0;
			$fy = ( $py[ $id ] ?? array( 0 => 1.0 ) )[ (int) $y ] ?? 0;
			if ( $fx <= 0 || $fy <= 0 ) { continue; }
			if ( ! empty( $opts['nature'] ) && $opts['nature'] !== $l['nature'] ) { continue; }
			if ( ! empty( $opts['mois'] ) && substr( $l['date_ecriture'], 0, 7 ) !== $opts['mois'] ) { continue; }
			if ( ! empty( $opts['compte'] ) && 0 !== strpos( (string) $l['numero'], (string) $opts['compte'] ) ) { continue; }
			$l['part'] = $fx * $fy * 100; $l['impute'] = $l['montant'] * $fx * $fy; $l['repartition_id'] = null;
			$tot[ $k[ $l['nature'] ] ] += $l['impute'];
			$out[] = $l;
		}
		usort( $out, function ( $a, $b ) { return array( $b['date_ecriture'], $b['id'] ) <=> array( $a['date_ecriture'], $a['id'] ); } );
		$limite = (int) ( $opts['limite'] ?? 0 );
		$res['valeur'] = FKC_AnaDetail::libelleValeur( $axeX, $x ) . ' × ' . FKC_AnaDetail::libelleValeur( $axeY, $y );
		$res['nb'] = count( $out );
		$res['tronque'] = $limite > 0 && $res['nb'] > $limite;
		$res['lignes'] = $limite > 0 ? array_slice( $out, 0, $limite ) : $out;
		$res['totaux'] = $tot + array( 'resultat' => $tot['produits'] - $tot['charges'], 'resultat_net' => $tot['produits'] - $tot['charges'] + $tot['hao'] );
		return $res;
	}

	/** Matrice complète en CSV (toutes les colonnes). */
	public static function csv( $axeXId, $axeYId, $annee, $mesure ) {
		$m = self::calculer( $axeXId, $axeYId, $annee );
		if ( ! $m['ok'] ) { return array( array( $m['message'] ) ); }
		$n = function ( $c ) use ( $mesure ) { return FKC_AnaDetail::nombre( self::mesure( $c, $mesure ) ); };
		$rows = array(
			array( 'Mesure', self::MESURES[ $mesure ] ?? $mesure, 'Exercice', (string) $annee ),
			array( 'Lignes', FKC_AnaDetail::cellule( $m['axeX']['libelle'] ), 'Colonnes', FKC_AnaDetail::cellule( $m['axeY']['libelle'] ) ),
			array(),
		);
		$tete = array( FKC_AnaDetail::cellule( $m['axeX']['libelle'] . ' \\ ' . $m['axeY']['libelle'] ) );
		foreach ( $m['colonnes'] as $y => $c ) { $tete[] = FKC_AnaDetail::cellule( $c[1] ); }
		$tete[] = 'Total';
		$rows[] = $tete;
		$vide = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		foreach ( $m['lignes'] as $x => $l ) {
			$r = array( FKC_AnaDetail::cellule( $l[1] ) );
			foreach ( $m['colonnes'] as $y => $c ) { $r[] = $n( $m['cases'][ $x ][ $y ] ?? $vide ); }
			$r[] = $n( $m['totL'][ $x ] );
			$rows[] = $r;
		}
		$r = array( 'Total' );
		foreach ( $m['colonnes'] as $y => $c ) { $r[] = $n( $m['totC'][ $y ] ); }
		$r[] = $n( $m['total'] );
		$rows[] = $r;
		return $rows;
	}
}
