<?php
/** Paramétrage général analytique : exercices + paramètres (devise, période, granularité). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaExercice {

	public static function all() {
		return FKC_DB::q( 'SELECT * FROM analytique_exercices ORDER BY date_debut DESC' )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM analytique_exercices WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function create( $d ) {
		FKC_DB::q(
			'INSERT INTO analytique_exercices(libelle,date_debut,date_fin,statut) VALUES(?,?,?,?)',
			array( trim( (string) $d['libelle'] ), $d['date_debut'], $d['date_fin'], in_array( $d['statut'] ?? 'ouvert', array( 'ouvert', 'clos' ), true ) ? ( $d['statut'] ?? 'ouvert' ) : 'ouvert' )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		FKC_DB::q(
			'UPDATE analytique_exercices SET libelle=?, date_debut=?, date_fin=?, statut=? WHERE id=?',
			array( trim( (string) $d['libelle'] ), $d['date_debut'], $d['date_fin'], in_array( $d['statut'] ?? 'ouvert', array( 'ouvert', 'clos' ), true ) ? ( $d['statut'] ?? 'ouvert' ) : 'ouvert', (int) $id )
		);
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM analytique_exercices WHERE id=?', array( (int) $id ) ); }

	/*
	 * Paramètres (par tenant) — revus en 1.822.0.
	 *
	 * « Devise », « période » et « granularité » étaient enregistrés mais lus
	 * NULLE PART : l'écran promettait des réglages sans effet. La devise est
	 * celle du dossier, la granularité n'existait dans aucun calcul ; seuls
	 * restent les réglages réellement branchés. Idem pour les « exercices
	 * analytiques » : aucun calcul ne les consultait, l'analytique suit
	 * toujours les exercices COMPTABLES. Les anciens restent listés (sans
	 * effet), supprimables, et on ne peut plus en créer.
	 */

	/** Exercice affiché par défaut sur les écrans analytiques ('' = l'exercice en cours). */
	public static function exerciceDefaut() {
		$v = preg_replace( '/\D/', '', (string) FKC_License::param( 'ana_exercice_defaut', '' ) );
		return 4 === strlen( $v ) ? $v : '';
	}
	public static function params() {
		return array( 'exercice_defaut' => self::exerciceDefaut() );
	}
	public static function saveParams( $d ) {
		$v = preg_replace( '/\D/', '', (string) ( $d['exercice_defaut'] ?? '' ) );
		FKC_License::setParam( 'ana_exercice_defaut', 4 === strlen( $v ) ? $v : '' );
	}
}
