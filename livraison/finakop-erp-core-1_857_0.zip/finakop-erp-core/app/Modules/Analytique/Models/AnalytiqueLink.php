<?php
/**
 * Liaison dynamique Analytique ↔ autres modules.
 * Chaque entité métier (client, fournisseur, artiste, œuvre…) est reflétée comme
 * une VALEUR analytique sous l'AXE correspondant, créé automatiquement si besoin.
 * Idempotent : la liaison se fait par (source_type, source_id), jamais de doublon.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnalytiqueLink {

	/** Sources gérées : clé => [code axe, libellé axe, table, colonne code, colonne libellé, préfixe, codes équivalents, (filtre SQL optionnel)]. */
	public static function sources() {
		return array(
			'client'      => array( 'CLIENTS', 'Clients', 'clients', 'code', 'nom', 'CLI', array( 'CLIENTS', 'CLI', 'CLIENT' ) ),
			'fournisseur' => array( 'FOURN', 'Fournisseurs', 'fournisseurs', 'code', 'nom', 'FRN', array( 'FOURN', 'FRN', 'FOURNISSEUR', 'FOURNISSEURS' ) ),
			'artiste'     => array( 'ARTISTES', 'Artistes', 'lbl_artistes', 'code', 'nom_scene', 'ART', array( 'ARTISTES', 'ART', 'ARTISTE' ) ),
			'catalogue'   => array( 'CATALOGUE', 'Catalogue', 'lbl_oeuvres', 'code', 'titre', 'CAT', array( 'CATALOGUE', 'CAT', 'OEUVRES', 'OEUVRE' ) ),
			// Axes natifs alimentés depuis leurs sources naturelles.
			'division'    => array( 'DIV', 'Division', 'divisions', 'code', 'libelle', 'DIV', array( 'DIV', 'DIVISION', 'DIVISIONS' ), "type IS NULL OR type<>'projet'" ),
			'projet'      => array( 'PROJ', 'Projet', 'divisions', 'code', 'libelle', 'PRJ', array( 'PROJ', 'PROJET', 'PROJETS' ), "type='projet'" ),
			'produit'     => array( 'PROD', 'Produit / Service', 'items_facturation', 'code', 'libelle', 'PRD', array( 'PROD', 'PRODUIT', 'PRODUITS', 'ITEMS', 'ITEM' ) ),
		);
	}

	protected static function enabled() {
		if ( class_exists( 'FKC_License' ) && ! FKC_License::moduleEnabled( 'analytique' ) ) { return false; }
		if ( class_exists( 'FKC_License' ) && '0' === (string) FKC_License::param( 'ana_autolink', '1' ) ) { return false; }
		return true;
	}

	protected static function tableExists( $t ) {
		try { return (bool) FKC_DB::q( "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", array( $t ) )->fetch(); }
		catch ( \Throwable $e ) { return false; }
	}

	/** Garantit l'existence de l'axe d'une source et renvoie son id (réutilise un axe équivalent existant). */
	public static function axeFor( $key ) {
		$src = self::sources();
		if ( ! isset( $src[ $key ] ) ) { return 0; }
		$code = $src[ $key ][0]; $libelle = $src[ $key ][1];
		$alts = $src[ $key ][6] ?? array( $code );
		try {
			// Réutiliser un axe équivalent déjà présent (évite les doublons type ART/ARTISTES, CLI/CLIENTS).
			$ph = implode( ',', array_fill( 0, count( $alts ), '?' ) );
			$rows = FKC_DB::q( "SELECT id, code FROM analytique_axes WHERE code IN ($ph)", $alts )->fetchAll();
			if ( $rows ) {
				foreach ( $rows as $r ) { if ( $r['code'] === $code ) { return (int) $r['id']; } }
				return (int) $rows[0]['id'];
			}
			FKC_DB::q( 'INSERT INTO analytique_axes(code,libelle,actif,ordre) VALUES(?,?,1,?)', array( $code, $libelle, 50 ) );
			return (int) FKC_DB::conn()->lastInsertId();
		} catch ( \Throwable $e ) { return 0; }
	}

	/** Crée/maj une valeur analytique liée à une entité. Renvoie l'id de la valeur ou 0. */
	public static function sync( $key, $sourceId, $code, $libelle ) {
		if ( ! self::enabled() ) { return 0; }
		$axeId = self::axeFor( $key );
		if ( ! $axeId ) { return 0; }
		$sourceId = (int) $sourceId;
		$libelle = trim( (string) $libelle ) ?: ( $code ?: ( $key . ' ' . $sourceId ) );
		$code = strtoupper( trim( (string) $code ) );
		if ( '' === $code ) {
			$pref = self::sources()[ $key ][5];
			$code = $pref . '-' . $sourceId;
		}
		try {
			$ex = FKC_DB::q( 'SELECT id, code, libelle, actif, source_orpheline FROM analytique_valeurs WHERE source_type=? AND source_id=?', array( $key, $sourceId ) )->fetch();
			if ( $ex ) {
				/*
				 * ─────────────────────────────────────────────────────────
				 * LE CODE NE SUIVAIT PAS SA FICHE (1.554.0)
				 *
				 * Seul le LIBELLÉ était rafraîchi. Renommer le code d'un
				 * client dans son module — passer de « CLI-12 » à un code
				 * parlant, harmoniser un plan de codification — laissait la
				 * valeur analytique sur l'ancien : les états par axe
				 * affichaient un code que plus personne ne reconnaissait, et
				 * qui ne correspondait à rien dans le référentiel. Le libellé
				 * étant juste, l'incohérence passait longtemps inaperçue.
				 *
				 * Le code est donc repris — mais PAS à n'importe quel prix :
				 * il porte une contrainte d'unicité par axe. Si le nouveau
				 * code est déjà pris par une AUTRE valeur du même axe, on
				 * garde l'ancien plutôt que de faire échouer la
				 * synchronisation : mieux vaut un code périmé qu'un backfill
				 * qui s'interrompt et laisse les valeurs suivantes non créées.
				 * ─────────────────────────────────────────────────────────
				 */
				$maj = array(); $args = array();
				if ( (string) $ex['libelle'] !== $libelle ) { $maj[] = 'libelle=?'; $args[] = $libelle; }
				if ( '' !== $code && strtoupper( (string) $ex['code'] ) !== $code ) {
					$pris = FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE axe_id=? AND code=? AND id<>?',
						array( $axeId, $code, (int) $ex['id'] ) )->fetch();
					if ( ! $pris ) { $maj[] = 'code=?'; $args[] = $code; }
				}
				// La fiche est réapparue (ou n'avait jamais disparu) : on lève
				// le drapeau d'orpheline posé par un précédent balayage.
				if ( ! empty( $ex['source_orpheline'] ) ) { $maj[] = 'source_orpheline=0'; }
				if ( $maj ) {
					$args[] = (int) $ex['id'];
					FKC_DB::q( 'UPDATE analytique_valeurs SET ' . implode( ', ', $maj ) . ' WHERE id=?', $args );
				}
				return (int) $ex['id'];
			}
			// Éviter une collision de code dans l'axe.
			$dup = FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE axe_id=? AND code=?', array( $axeId, $code ) )->fetch();
			if ( $dup ) { $code .= '-' . $sourceId; }
			FKC_DB::q(
				'INSERT INTO analytique_valeurs(axe_id,code,libelle,actif,ordre,source_type,source_id) VALUES(?,?,?,1,0,?,?)',
				array( $axeId, $code, $libelle, $key, $sourceId )
			);
			return (int) FKC_DB::conn()->lastInsertId();
		} catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Synchronise toutes les entités existantes vers leurs valeurs analytiques.
	 * Idempotent et efficace : n'insère que les valeurs manquantes. Renvoie le nb créé.
	 */
	public static function backfill() {
		if ( ! self::enabled() ) { return 0; }

		/*
		 * PHASE 1 — relever ce qui existe réellement dans chaque référentiel.
		 * On lit tout AVANT de créer quoi que ce soit : sans cette vue
		 * d'ensemble, on ne peut pas distinguer une fiche DISPARUE d'une fiche
		 * REQUALIFIÉE, et les deux se traitent très différemment.
		 */
		$presents = array();
		foreach ( self::sources() as $key => $def ) {
			list( $axeCode, $axeLib, $table, $colCode, $colLib, $pref ) = $def;
			$where = isset( $def[7] ) ? (string) $def[7] : '';
			if ( ! self::tableExists( $table ) ) { continue; }
			try {
				$sql = "SELECT id, {$colCode} AS c, {$colLib} AS l FROM {$table}";
				if ( '' !== $where ) { $sql .= " WHERE {$where}"; }
				$presents[ $key ] = array();
				foreach ( FKC_DB::q( $sql )->fetchAll() as $row ) {
					$presents[ $key ][ (int) $row['id'] ] = array( 'c' => $row['c'] ?? '', 'l' => $row['l'] ?? '' );
				}
			} catch ( \Throwable $e ) { /* colonnes différentes : source ignorée */ }
		}

		// PHASE 2 — requalifications d'abord : elles DÉPLACENT une valeur
		// existante, il ne faut donc pas qu'une création l'ait doublée avant.
		self::migrerRequalifiees( $presents );

		$created = 0;
		foreach ( $presents as $key => $fiches ) {
			$axeId = self::axeFor( $key );
			if ( ! $axeId ) { continue; }
			try {
				$existing = array();
				foreach ( FKC_DB::q( 'SELECT source_id FROM analytique_valeurs WHERE source_type=?', array( $key ) )->fetchAll() as $r ) {
					$existing[ (int) $r['source_id'] ] = true;
				}
				foreach ( $fiches as $id => $f ) {
					// On repasse par sync() même pour les valeurs déjà liées :
					// c'est ce qui rafraîchit code et libellé quand la fiche a
					// changé. Auparavant, seules les créations y passaient.
					$vid = self::sync( $key, $id, $f['c'], $f['l'] );
					if ( $vid && ! isset( $existing[ $id ] ) ) { $created++; }
				}
			} catch ( \Throwable $e ) { /* base partielle */ }
		}

		self::marquerOrphelines( $presents );
		return $created;
	}

	/**
	 * Déplace une valeur dont la fiche a CHANGÉ DE NATURE, au lieu de la doubler.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UNE DIVISION PASSÉE EN PROJET EXISTAIT SUR LES DEUX AXES (1.554.0)
	 *
	 * `division` et `projet` lisent la MÊME table avec deux filtres opposés
	 * (`type<>'projet'` / `type='projet'`). Requalifier une section de
	 * « division » en « projet » la faisait créer sous l'axe PROJ, tandis que
	 * la valeur déjà présente sous l'axe DIV restait là : la même section
	 * existait en double, sur deux axes. Ses écritures futures partaient sur
	 * PROJ pendant que l'ancienne valeur, toujours proposée à la saisie,
	 * continuait de porter l'historique — sans que rien ne relie les deux.
	 *
	 * Plutôt que de créer un doublon puis de désactiver l'ancien, on DÉPLACE
	 * la valeur existante : même id, donc mêmes affectations, mêmes budgets,
	 * mêmes clés de répartition — tout ce qui pointe dessus suit sans être
	 * touché. La section change d'axe comme elle a changé de nature, et son
	 * historique la suit au lieu de rester derrière.
	 *
	 * Ne s'applique qu'entre sources partageant la MÊME TABLE : c'est ce qui
	 * garantit qu'il s'agit bien de la même fiche, et non de deux entités
	 * différentes portant le même identifiant dans deux référentiels.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @return int nombre de valeurs déplacées.
	 */
	protected static function migrerRequalifiees( $presents ) {
		$src = self::sources();
		$n = 0;
		foreach ( $presents as $key => $fiches ) {
			if ( ! isset( $src[ $key ] ) ) { continue; }
			$table = $src[ $key ][2];
			// Sources sœurs : même table, clé différente (division ↔ projet).
			$soeurs = array();
			foreach ( $src as $k2 => $d2 ) {
				if ( $k2 !== $key && $d2[2] === $table ) { $soeurs[] = $k2; }
			}
			if ( ! $soeurs ) { continue; }
			$axeId = self::axeFor( $key );
			if ( ! $axeId ) { continue; }
			$ph = implode( ',', array_fill( 0, count( $soeurs ), '?' ) );
			foreach ( $fiches as $id => $f ) {
				try {
					$args = array_merge( $soeurs, array( (int) $id ) );
					$anc = FKC_DB::q( "SELECT id, code FROM analytique_valeurs WHERE source_type IN ($ph) AND source_id=?", $args )->fetch();
					if ( ! $anc ) { continue; }
					// Déjà une valeur sous la bonne clé ? Alors on ne déplace
					// pas : on laisserait deux valeurs pour une seule fiche.
					$deja = FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE source_type=? AND source_id=?', array( $key, (int) $id ) )->fetch();
					if ( $deja ) { continue; }
					$code = strtoupper( trim( (string) ( $f['c'] ?: $anc['code'] ) ) );
					if ( '' === $code ) { $code = $src[ $key ][5] . '-' . (int) $id; }
					$pris = FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE axe_id=? AND code=? AND id<>?', array( $axeId, $code, (int) $anc['id'] ) )->fetch();
					if ( $pris ) { $code .= '-' . (int) $id; }
					FKC_DB::q(
						'UPDATE analytique_valeurs SET axe_id=?, source_type=?, code=?, source_orpheline=0 WHERE id=?',
						array( $axeId, $key, $code, (int) $anc['id'] )
					);
					$n++;
				} catch ( \Throwable $e ) { /* base partielle */ }
			}
		}
		return $n;
	}

	/**
	 * Marque les valeurs dont la fiche d'origine a disparu — sans les détruire.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UNE VALEUR SANS FICHE RESTAIT PROPOSÉE À LA SAISIE (1.554.0)
	 *
	 * Supprimer un client, un fournisseur ou un article dans son module
	 * laissait sa valeur analytique intacte. C'est VOULU : l'effacer perdrait
	 * toutes les imputations passées, et un résultat par axe amputé de ses
	 * lignes historiques cesserait de se rapprocher du compte de résultat.
	 * Ce qui ne l'était pas, c'est le silence : la valeur continuait
	 * d'apparaître dans les sélecteurs, et on pouvait imputer une charge de
	 * l'exercice en cours à un fournisseur qui n'existe plus — en croyant
	 * qu'il existait encore, puisque l'écran le proposait.
	 *
	 * On la DÉSACTIVE donc et on la marque : elle quitte la saisie, reste
	 * lisible dans les états, et l'écran des valeurs explique pourquoi. Si la
	 * fiche réapparaît (restauration, ré-import), sync() lève le drapeau et
	 * la valeur redevient utilisable — la désactivation n'est pas réversée
	 * automatiquement, parce qu'une valeur peut aussi avoir été désactivée à
	 * la main : c'est à l'utilisateur de la réactiver s'il le veut.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @param array $presents source_type => [source_id => fiche]
	 * @return int nombre de valeurs nouvellement marquées.
	 */
	protected static function marquerOrphelines( $presents ) {
		$n = 0;
		foreach ( $presents as $key => $ids ) {
			try {
				$rows = FKC_DB::q(
					'SELECT id, source_id FROM analytique_valeurs WHERE source_type=? AND COALESCE(source_orpheline,0)=0',
					array( $key )
				)->fetchAll();
				foreach ( $rows as $r ) {
					if ( isset( $ids[ (int) $r['source_id'] ] ) ) { continue; }
					FKC_DB::q( 'UPDATE analytique_valeurs SET source_orpheline=1, actif=0 WHERE id=?', array( (int) $r['id'] ) );
					$n++;
				}
			} catch ( \Throwable $e ) { /* colonne absente sur une base ancienne */ }
		}
		return $n;
	}

}
