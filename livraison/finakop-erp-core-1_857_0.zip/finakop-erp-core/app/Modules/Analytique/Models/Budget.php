<?php
/** Budgets analytiques par division/exercice + contrôle budgétaire (budget vs réalisé). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Budget {

	public static function all( $annee ) {
		return FKC_DB::q( 'SELECT b.*, d.code, d.libelle FROM budgets b JOIN divisions d ON d.id=b.division_id WHERE b.annee=? ORDER BY d.ordre, d.libelle COLLATE NOCASE', array( (string) $annee ) )->fetchAll();
	}
	public static function find( $divisionId, $annee ) {
		$r = FKC_DB::q( 'SELECT * FROM budgets WHERE division_id=? AND annee=?', array( (int) $divisionId, (string) $annee ) )->fetch();
		return $r ?: null;
	}
	/** Insère ou met à jour le budget d'une division pour un exercice (+ prévision). */
	public static function upsert( $divisionId, $annee, $produits, $charges, $note = '', $prevProduits = 0, $prevCharges = 0 ) {
		FKC_DB::q(
			'INSERT INTO budgets(division_id,annee,budget_produits,budget_charges,prev_produits,prev_charges,note,created_by,updated_at)
			 VALUES(?,?,?,?,?,?,?,?,datetime(\'now\',\'localtime\'))
			 ON CONFLICT(division_id,annee) DO UPDATE SET budget_produits=excluded.budget_produits, budget_charges=excluded.budget_charges, prev_produits=excluded.prev_produits, prev_charges=excluded.prev_charges, note=excluded.note, updated_at=excluded.updated_at',
			array( (int) $divisionId, (string) $annee, (float) $produits, (float) $charges, (float) $prevProduits, (float) $prevCharges, trim( (string) $note ) ?: null, FKC_Auth::id() )
		);
	}
	public static function delete( $divisionId, $annee ) {
		FKC_DB::q( 'DELETE FROM budgets WHERE division_id=? AND annee=?', array( (int) $divisionId, (string) $annee ) );
	}

	/**
	 * Contrôle budgétaire : budget vs réalisé par division pour un exercice, avec écarts et taux.
	 * Réalisé issu de FKC_Division::resultats (réutilisé, pas de recalcul parallèle).
	 */
	public static function controle( $annee ) {
		$res = FKC_Division::resultats( $annee );
		$budgets = array();
		foreach ( self::all( $annee ) as $b ) { $budgets[ (int) $b['division_id'] ] = $b; }

		$lignes = array();
		$tot = array( 'bp' => 0.0, 'bc' => 0.0, 'rp' => 0.0, 'rc' => 0.0 );
		foreach ( $res['lignes'] as $l ) {
			$b = $budgets[ $l['id'] ] ?? null;
			$bp = $b ? (float) $b['budget_produits'] : 0.0;
			$bc = $b ? (float) $b['budget_charges'] : 0.0;
			$rp = (float) $l['produits'];
			$rc = (float) $l['charges'];
			$lignes[] = array(
				'id' => $l['id'], 'code' => $l['code'], 'libelle' => $l['libelle'], 'nature' => $l['nature'] ?? 'mixte',
				'budget_produits' => $bp, 'reel_produits' => $rp, 'ecart_produits' => $rp - $bp,
				'budget_charges' => $bc, 'reel_charges' => $rc, 'ecart_charges' => $rc - $bc,
				'budget_resultat' => $bp - $bc, 'reel_resultat' => $rp - $rc,
				'conso_charges' => $bc > 0 ? round( $rc / $bc * 100 ) : null,
				'real_produits' => $bp > 0 ? round( $rp / $bp * 100 ) : null,
				'a_budget' => (bool) $b,
			);
			$tot['bp'] += $bp; $tot['bc'] += $bc; $tot['rp'] += $rp; $tot['rc'] += $rc;
		}
		$tot['ecart_produits'] = $tot['rp'] - $tot['bp'];
		$tot['ecart_charges']  = $tot['rc'] - $tot['bc'];
		$tot['budget_resultat'] = $tot['bp'] - $tot['bc'];
		$tot['reel_resultat']   = $tot['rp'] - $tot['rc'];
		return array( 'lignes' => $lignes, 'totaux' => $tot );
	}

	/**
	 * Budgets comparatifs par division pour un exercice :
	 *   Réel (réalisé N) · Budget · Prévision (ré-estimation) · N-1 (réalisé N-1).
	 * Renvoie les 4 séries (produits, charges, résultat) + écarts Réel vs Budget,
	 * Réel vs Prévision, et variation Réel vs N-1, par division et en total.
	 */
	public static function comparatif( $annee ) {
		$annee  = (string) $annee;
		$prec   = (string) ( (int) $annee - 1 );
		$resN   = FKC_Division::resultats( $annee );
		$resN1  = FKC_Division::resultats( $prec );

		$reelN1 = array();
		foreach ( $resN1['lignes'] as $l ) { $reelN1[ (int) $l['id'] ] = $l; }
		$budgets = array();
		foreach ( self::all( $annee ) as $b ) { $budgets[ (int) $b['division_id'] ] = $b; }

		$ecart = function ( $reel, $ref ) {
			$d = $reel - $ref;
			return array( 'val' => $d, 'pct' => ( abs( $ref ) > 0.0001 ) ? round( $d / abs( $ref ) * 100, 1 ) : null );
		};

		$lignes = array();
		$tot = array(
			'reel_p' => 0.0, 'reel_c' => 0.0, 'bud_p' => 0.0, 'bud_c' => 0.0,
			'prev_p' => 0.0, 'prev_c' => 0.0, 'n1_p' => 0.0, 'n1_c' => 0.0,
		);
		foreach ( $resN['lignes'] as $l ) {
			$id = (int) $l['id'];
			$b  = $budgets[ $id ] ?? null;
			$n1 = $reelN1[ $id ] ?? null;

			$reel_p = (float) $l['produits'];           $reel_c = (float) $l['charges'];
			$bud_p  = $b ? (float) $b['budget_produits'] : 0.0;  $bud_c  = $b ? (float) $b['budget_charges'] : 0.0;
			$prev_p = $b ? (float) $b['prev_produits']   : 0.0;  $prev_c = $b ? (float) $b['prev_charges']   : 0.0;
			$n1_p   = $n1 ? (float) $n1['produits'] : 0.0;       $n1_c   = $n1 ? (float) $n1['charges'] : 0.0;

			$reel_r = $reel_p - $reel_c; $bud_r = $bud_p - $bud_c; $prev_r = $prev_p - $prev_c; $n1_r = $n1_p - $n1_c;

			$lignes[] = array(
				'id' => $id, 'code' => $l['code'], 'libelle' => $l['libelle'], 'nature' => $l['nature'] ?? 'mixte',
				'reel' => array( 'produits' => $reel_p, 'charges' => $reel_c, 'resultat' => $reel_r ),
				'budget' => array( 'produits' => $bud_p, 'charges' => $bud_c, 'resultat' => $bud_r ),
				'prevision' => array( 'produits' => $prev_p, 'charges' => $prev_c, 'resultat' => $prev_r ),
				'n1' => array( 'produits' => $n1_p, 'charges' => $n1_c, 'resultat' => $n1_r ),
				'ecart_budget'    => $ecart( $reel_r, $bud_r ),
				'ecart_prevision' => $ecart( $reel_r, $prev_r ),
				'var_n1'          => $ecart( $reel_r, $n1_r ),
				'a_budget' => (bool) $b,
			);
			$tot['reel_p'] += $reel_p; $tot['reel_c'] += $reel_c;
			$tot['bud_p']  += $bud_p;  $tot['bud_c']  += $bud_c;
			$tot['prev_p'] += $prev_p; $tot['prev_c'] += $prev_c;
			$tot['n1_p']   += $n1_p;   $tot['n1_c']   += $n1_c;
		}
		$tot['reel_r'] = $tot['reel_p'] - $tot['reel_c'];
		$tot['bud_r']  = $tot['bud_p']  - $tot['bud_c'];
		$tot['prev_r'] = $tot['prev_p'] - $tot['prev_c'];
		$tot['n1_r']   = $tot['n1_p']   - $tot['n1_c'];
		$tot['ecart_budget']    = $ecart( $tot['reel_r'], $tot['bud_r'] );
		$tot['ecart_prevision'] = $ecart( $tot['reel_r'], $tot['prev_r'] );
		$tot['var_n1']          = $ecart( $tot['reel_r'], $tot['n1_r'] );

		return array( 'lignes' => $lignes, 'totaux' => $tot, 'annee' => $annee, 'annee_prec' => $prec );
	}

	/* ── Budgets par axe/valeur (Division, Projet, Client, Produit…) ── */

	public static function allAxe( $axeId, $annee ) {
		return FKC_DB::q(
			'SELECT b.*, v.code, v.libelle FROM budgets_axes b JOIN analytique_valeurs v ON v.id=b.valeur_id WHERE b.axe_id=? AND b.annee=? ORDER BY v.ordre, v.libelle COLLATE NOCASE',
			array( (int) $axeId, (string) $annee )
		)->fetchAll();
	}
	public static function upsertAxe( $axeId, $valeurId, $annee, $produits, $charges, $note = '' ) {
		FKC_DB::q(
			'INSERT INTO budgets_axes(axe_id,valeur_id,annee,budget_produits,budget_charges,note,updated_at)
			 VALUES(?,?,?,?,?,?,datetime(\'now\',\'localtime\'))
			 ON CONFLICT(axe_id,valeur_id,annee) DO UPDATE SET budget_produits=excluded.budget_produits, budget_charges=excluded.budget_charges, note=excluded.note, updated_at=excluded.updated_at',
			array( (int) $axeId, (int) $valeurId, (string) $annee, (float) $produits, (float) $charges, trim( (string) $note ) ?: null )
		);
	}
	public static function deleteAxe( $axeId, $valeurId, $annee ) {
		FKC_DB::q( 'DELETE FROM budgets_axes WHERE axe_id=? AND valeur_id=? AND annee=?', array( (int) $axeId, (int) $valeurId, (string) $annee ) );
	}

	/**
	 * Contrôle budgétaire par axe (budget vs réalisé via affectations), avec écarts + alertes.
	 * $seuilAlerte = % de consommation des charges déclenchant l'alerte.
	 */
	public static function controleAxe( $axeId, $annee, $seuilAlerte = 90 ) {
		$res = FKC_Affectation::resultatsParAxe( $axeId, $annee );
		$budgets = array();
		foreach ( self::allAxe( $axeId, $annee ) as $b ) { $budgets[ (int) $b['valeur_id'] ] = $b; }

		$lignes = array(); $tot = array( 'bp' => 0.0, 'bc' => 0.0, 'rp' => 0.0, 'rc' => 0.0 );
		foreach ( $res['lignes'] as $l ) {
			$b = $budgets[ (int) $l['valeur_id'] ] ?? null;
			$bp = $b ? (float) $b['budget_produits'] : 0.0;
			$bc = $b ? (float) $b['budget_charges'] : 0.0;
			$rp = (float) $l['produits']; $rc = (float) $l['charges'];
			$conso = $bc > 0 ? round( $rc / $bc * 100 ) : null;
			$lignes[] = array(
				'valeur_id' => (int) $l['valeur_id'], 'code' => $l['code'], 'libelle' => $l['libelle'],
				'budget_produits' => $bp, 'reel_produits' => $rp, 'ecart_produits' => $rp - $bp,
				'budget_charges' => $bc, 'reel_charges' => $rc, 'ecart_charges' => $rc - $bc,
				'budget_resultat' => $bp - $bc, 'reel_resultat' => $rp - $rc,
				'conso_charges' => $conso, 'a_budget' => (bool) $b,
				'alerte' => ( null !== $conso && $conso >= $seuilAlerte ),
			);
			$tot['bp'] += $bp; $tot['bc'] += $bc; $tot['rp'] += $rp; $tot['rc'] += $rc;
		}
		$tot['ecart_charges'] = $tot['rc'] - $tot['bc'];
		$tot['ecart_produits'] = $tot['rp'] - $tot['bp'];
		return array( 'lignes' => $lignes, 'totaux' => $tot, 'seuil' => $seuilAlerte );
	}
}
