<?php
/**
 * Affectations analytiques multi-axes : chaque ligne d'écriture (charge/produit) peut
 * porter plusieurs axes simultanément (table ligne_affectations : ligne · axe · valeur).
 * Fournit aussi le moteur de résultats analytiques par axe, base du Reporting BI.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Affectation {

	/** Affectations d'une ligne : map axe_id => valeur_id (l'axe DIV reflète ecriture_lignes.division_id). */
	public static function forLigne( $ligneId ) {
		$m = array();
		foreach ( FKC_DB::q( 'SELECT axe_id, valeur_id FROM ligne_affectations WHERE ecriture_ligne_id=?', array( (int) $ligneId ) )->fetchAll() as $r ) {
			$m[ (int) $r['axe_id'] ] = (int) $r['valeur_id'];
		}
		$divAxe = FKC_DB::q( "SELECT id FROM analytique_axes WHERE code='DIV'" )->fetchColumn();
		if ( $divAxe ) {
			$div = FKC_DB::q( 'SELECT division_id FROM ecriture_lignes WHERE id=?', array( (int) $ligneId ) )->fetchColumn();
			if ( $div ) { $m[ (int) $divAxe ] = (int) $div; }
		}
		return $m;
	}

	/** Fragment SQL « ligne sans ventilation » (vide si le modèle n'est pas chargé). */
	protected static function nonVentilee() {
		return class_exists( 'FKC_Ventilation' ) ? ' AND ' . FKC_Ventilation::sqlNonVentilee() : '';
	}

	/** Remplace les affectations d'une ligne. $axes = map axe_id => valeur_id (0/'' = retirer). */
	public static function setForLigne( $ligneId, $axes ) {
		$divAxe = FKC_DB::q( "SELECT id FROM analytique_axes WHERE code='DIV'" )->fetchColumn();
		$divAxe = $divAxe ? (int) $divAxe : 0;
		foreach ( (array) $axes as $axeId => $valeurId ) {
			$axeId = (int) $axeId; $valeurId = (int) $valeurId;
			// Une valeur unique posée sur un axe remplace sa ventilation (1.823.0).
			if ( $valeurId > 0 && class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::effacerAxe( $ligneId, $axeId ); }
			if ( $divAxe && $axeId === $divAxe ) {
				// L'axe Division pilote la colonne legacy ecriture_lignes.division_id.
				FKC_DB::q( 'UPDATE ecriture_lignes SET division_id=? WHERE id=?', array( $valeurId > 0 ? $valeurId : null, (int) $ligneId ) );
				continue;
			}
			FKC_DB::q( 'DELETE FROM ligne_affectations WHERE ecriture_ligne_id=? AND axe_id=?', array( (int) $ligneId, $axeId ) );
			if ( $valeurId > 0 ) {
				FKC_DB::q( 'INSERT INTO ligne_affectations(ecriture_ligne_id,axe_id,valeur_id) VALUES(?,?,?)', array( (int) $ligneId, $axeId, $valeurId ) );
			}
		}
	}

	/**
	 * Filtre de période. Délègue à FKC_Division::filtrePeriode, qui honore un
	 * exercice décalé (1.547.0) : l'ancien substr(date,1,4) découpait l'année
	 * civile même chez un dossier clôturant en juin.
	 */
	protected static function filtreAnnee( $annee, &$params, $alias = 'e' ) {
		if ( class_exists( 'FKC_Division' ) && method_exists( 'FKC_Division', 'filtrePeriode' ) ) {
			return FKC_Division::filtrePeriode( $annee, $params, $alias );
		}
		if ( '' === (string) $annee ) { return ''; }
		$params[] = (string) $annee;
		return " AND substr({$alias}.date_ecriture,1,4)=? ";
	}

	/**
	 * Lignes analytiques (cl.6 / cl.7) d'une période, pour l'écran d'affectation.
	 *
	 * @param string $annee    Exercice.
	 * @param int    $limit    Nombre de lignes.
	 * @param array  $opts     'non_affectees' => true pour ne montrer que ce
	 *                         qui reste à faire (le cas d'usage réel de
	 *                         l'écran : sur un dossier chargé, les 300
	 *                         dernières lignes sont déjà toutes affectées et
	 *                         le travail restant est invisible).
	 */
	public static function lignesAnalytiques( $annee, $limit = 300, $opts = array() ) {
		$params = array();
		$f = self::filtreAnnee( $annee, $params );
		$reste = '';
		if ( ! empty( $opts['non_affectees'] ) ) {
			$reste = " AND el.division_id IS NULL
			           AND NOT EXISTS ( SELECT 1 FROM ligne_affectations la WHERE la.ecriture_ligne_id = el.id ) " . self::nonVentilee();
		}
		$sql = "SELECT el.id, e.date_ecriture, e.piece, COALESCE(NULLIF(el.libelle,''), e.libelle) libelle,
			   c.numero, c.libelle compte_libelle, el.debit, el.credit,
			   CASE WHEN c.numero LIKE '7%' OR ( c.numero LIKE '8%' AND el.credit > 0 ) THEN 'produit' ELSE 'charge' END sens
			 FROM ecriture_lignes el
			 JOIN ecritures e ON e.id = el.ecriture_id
			 JOIN comptes c ON c.id = el.compte_id
			 WHERE " . FKC_Division::sqlGestion() . " {$f} {$reste}
			 ORDER BY e.date_ecriture DESC, el.id DESC LIMIT " . (int) $limit
			 . ( empty( $opts['offset'] ) ? '' : ' OFFSET ' . max( 0, (int) $opts['offset'] ) );
		return FKC_DB::q( $sql, $params )->fetchAll();
	}

	/** Nombre total de lignes que lignesAnalytiques() peut montrer (pour la pagination). */
	public static function compterLignes( $annee, $opts = array() ) {
		$params = array();
		$f = self::filtreAnnee( $annee, $params );
		$reste = empty( $opts['non_affectees'] ) ? '' : " AND el.division_id IS NULL
			AND NOT EXISTS ( SELECT 1 FROM ligne_affectations la WHERE la.ecriture_ligne_id = el.id ) " . self::nonVentilee();
		try {
			return (int) FKC_DB::q(
				"SELECT COUNT(*) FROM ecriture_lignes el
				 JOIN ecritures e ON e.id = el.ecriture_id
				 JOIN comptes c ON c.id = el.compte_id
				 WHERE " . FKC_Division::sqlGestion() . " {$f} {$reste}",
				$params
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Lignes par page de l'écran d'affectation (1.822.0).
	 *
	 * PHP ignore sans prévenir les champs au-delà de max_input_vars (1000
	 * par défaut). L'ancien écran affichait 300 lignes × N axes dans UN
	 * formulaire : avec 4 axes, 1 200 champs — la fin était perdue en
	 * silence. La page est dimensionnée pour que tout arrive.
	 */
	public static function taillePage( $nbAxes ) {
		$max = (int) ini_get( 'max_input_vars' );
		if ( $max <= 0 ) { $max = 1000; }
		$n = (int) floor( ( $max - 20 ) / max( 1, (int) $nbAxes ) );
		return max( 5, min( 50, $n ) );
	}

	/** La ligne appartient-elle à un exercice clôturé ? Ses affectations sont alors figées. */
	public static function estVerrouillee( $date ) {
		return class_exists( 'FKC_Cloture' ) && method_exists( 'FKC_Cloture', 'isExerciceClos' )
			&& FKC_Cloture::isExerciceClos( substr( (string) $date, 0, 10 ) );
	}

	/**
	 * Enregistre un lot d'affectations saisi à l'écran (1.822.0).
	 *
	 * Seules les valeurs qui CHANGENT sont écrites. Chaque changement est
	 * contrôlé : ligne de gestion (classe 6/7/8) existante, exercice non
	 * clôturé, valeur appartenant bien à l'axe (ou division existante) et
	 * active. Le lot accepté est tracé à l'audit, avec l'avant/après.
	 *
	 * @param array $data aff[ligne_id][axe_id] = valeur_id ('' = retirer).
	 * @return array ['modifiees'=>int, 'lignes'=>int, 'refus'=>[message…]]
	 */
	public static function enregistrerLot( array $data ) {
		$out = array( 'modifiees' => 0, 'lignes' => 0, 'refus' => array() );
		$axes = array();
		foreach ( FKC_Axe::all() as $a ) { $axes[ (int) $a['id'] ] = $a; }
		$trace = array();
		foreach ( $data as $ligneId => $vals ) {
			$ligneId = (int) $ligneId;
			if ( $ligneId <= 0 || ! is_array( $vals ) ) { continue; }
			$l = FKC_DB::q(
				'SELECT el.id, e.date_ecriture, c.numero FROM ecriture_lignes el
				 JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
				 WHERE el.id=? AND ' . FKC_Division::sqlGestion(),
				array( $ligneId )
			)->fetch();
			if ( ! $l ) { $out['refus'][] = 'Ligne #' . $ligneId . ' : introuvable ou hors classes 6/7/8.'; continue; }
			$avant = self::forLigne( $ligneId );
			$chg = array();
			foreach ( $vals as $axeId => $valeurId ) {
				$axeId = (int) $axeId; $valeurId = (int) $valeurId;
				if ( (int) ( $avant[ $axeId ] ?? 0 ) === $valeurId ) { continue; }
				if ( ! isset( $axes[ $axeId ] ) ) { $out['refus'][] = 'Ligne #' . $ligneId . ' : axe inconnu.'; continue; }
				if ( $valeurId > 0 && ! self::valeurValide( $axes[ $axeId ], $valeurId ) ) {
					$out['refus'][] = 'Ligne #' . $ligneId . ' : la valeur choisie n\'appartient pas à l\'axe ' . $axes[ $axeId ]['code'] . ' (ou elle est désactivée).';
					continue;
				}
				$chg[ $axeId ] = $valeurId;
			}
			if ( ! $chg ) { continue; }
			if ( self::estVerrouillee( $l['date_ecriture'] ) ) {
				$out['refus'][] = 'Ligne #' . $ligneId . ' (' . $l['date_ecriture'] . ') : exercice clôturé, affectation figée.';
				continue;
			}
			self::setForLigne( $ligneId, $chg );
			$out['lignes']++;
			$out['modifiees'] += count( $chg );
			foreach ( $chg as $axeId => $v ) {
				$trace[] = '#' . $ligneId . ' ' . $axes[ $axeId ]['code'] . ':' . (int) ( $avant[ $axeId ] ?? 0 ) . '→' . $v;
			}
		}
		if ( $trace && class_exists( 'FKC_Security' ) ) {
			$d = count( $trace ) . ' changement(s) · ' . implode( ', ', $trace );
			FKC_Security::audit( 'analytique_affectation', mb_strimwidth( $d, 0, 1900, '…' ) );
		}
		return $out;
	}

	/** Une valeur est-elle choisissable pour cet axe ? */
	protected static function valeurValide( array $axe, $valeurId ) {
		if ( 'DIV' === $axe['code'] ) {
			return (bool) FKC_DB::q( 'SELECT 1 FROM divisions WHERE id=? AND actif=1', array( (int) $valeurId ) )->fetchColumn();
		}
		return (bool) FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE id=? AND axe_id=? AND actif=1', array( (int) $valeurId, (int) $axe['id'] ) )->fetchColumn();
	}

	/** Combien de lignes cl.6/cl.7 restent sans aucune imputation analytique. */
	public static function resteAAffecter( $annee ) {
		$params = array();
		$f = self::filtreAnnee( $annee, $params );
		try {
			return (int) FKC_DB::q(
				"SELECT COUNT(*) FROM ecriture_lignes el
				 JOIN ecritures e ON e.id = el.ecriture_id
				 JOIN comptes c ON c.id = el.compte_id
				 WHERE " . FKC_Division::sqlGestion() . " {$f}
				   AND el.division_id IS NULL
				   AND NOT EXISTS ( SELECT 1 FROM ligne_affectations la WHERE la.ecriture_ligne_id = el.id )" . self::nonVentilee(),
				$params
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Efface les affectations devenues sans objet.
	 *
	 * `ligne_affectations` ne porte AUCUNE clé étrangère : la table n'est donc
	 * jamais nettoyée par cascade. Purge de période, suppression d'écriture,
	 * remise à zéro d'un exercice, suppression d'un axe ou d'une valeur —
	 * chacune laissait derrière elle des lignes pointant dans le vide. Elles
	 * ne faussent aucun total (les états joignent ecriture_lignes, donc les
	 * orphelines sont écartées), mais elles gonflent la base indéfiniment et
	 * rendent tout diagnostic illisible.
	 *
	 * Idempotent. @param int|null $ligneId pour ne purger qu'une ligne précise.
	 * @return int nombre de lignes retirées.
	 */
	public static function purgerOrphelins( $ligneId = null ) {
		$n = 0;
		try {
			if ( null !== $ligneId ) {
				$st = FKC_DB::q( 'DELETE FROM ligne_affectations WHERE ecriture_ligne_id=?', array( (int) $ligneId ) );
				$n = (int) $st->rowCount();
				if ( class_exists( 'FKC_Ventilation' ) ) {
					FKC_Ventilation::ensure();
					$n += (int) FKC_DB::q( 'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id=?', array( (int) $ligneId ) )->rowCount();
				}
				return $n;
			}
			foreach ( array(
				'DELETE FROM ligne_affectations WHERE ecriture_ligne_id NOT IN (SELECT id FROM ecriture_lignes)',
				'DELETE FROM ligne_affectations WHERE axe_id NOT IN (SELECT id FROM analytique_axes)',
				'DELETE FROM ligne_affectations WHERE valeur_id NOT IN (SELECT id FROM analytique_valeurs)',
			) as $sql ) {
				$n += (int) FKC_DB::q( $sql )->rowCount();
			}
			if ( class_exists( 'FKC_Ventilation' ) ) { $n += FKC_Ventilation::purgerOrphelins(); }
		} catch ( \Throwable $e ) { /* base partielle */ }
		return $n;
	}

	/** Totaux P&L de la période (toutes lignes cl.6/cl.7), pour le « non affecté ». */
	protected static function totauxPeriode( $annee ) {
		$params = array();
		$f = self::filtreAnnee( $annee, $params );
		$r = FKC_DB::q(
			"SELECT " . FKC_Division::sqlBlocs() . "
			 FROM ecriture_lignes el
			 JOIN ecritures e ON e.id = el.ecriture_id
			 JOIN comptes c ON c.id = el.compte_id
			 WHERE " . FKC_Division::sqlGestion() . " {$f}",
			$params
		)->fetch();
		return array( 'produits' => (float) $r['produits'], 'charges' => (float) $r['charges'], 'hao' => (float) $r['hao'] );
	}

	/**
	 * Résultats analytiques par valeur d'un axe (produits / charges / résultat), + « Non affecté ».
	 * Pour l'axe DIV, réutilise les divisions existantes (compatibilité ascendante).
	 */
	public static function resultatsParAxe( $axeId, $annee = '' ) {
		$axe = FKC_Axe::find( $axeId );
		if ( ! $axe ) { return array( 'axe' => null, 'lignes' => array(), 'non_affecte' => null, 'totaux' => array( 'produits' => 0, 'charges' => 0, 'resultat' => 0 ) ); }

		if ( 'DIV' === $axe['code'] ) {
			$res = FKC_Division::resultats( $annee );
			$lignes = array();
			foreach ( $res['lignes'] as $l ) {
				$lignes[] = array( 'valeur_id' => $l['id'], 'code' => $l['code'], 'libelle' => $l['libelle'], 'produits' => $l['produits'], 'charges' => $l['charges'], 'resultat' => $l['resultat'],
					'hao' => $l['hao'], 'resultat_net' => $l['resultat_net'] );
			}
			$ni = $res['non_impute'];
			return array(
				'axe' => $axe, 'lignes' => $lignes,
				'non_affecte' => array( 'produits' => $ni['produits'], 'charges' => $ni['charges'], 'resultat' => $ni['resultat'], 'hao' => $ni['hao'], 'resultat_net' => $ni['resultat_net'] ),
				'totaux' => $res['totaux'],
				'couverture' => self::couverture( $res['totaux'], $ni ),
			);
		}

		$params = array( (int) $axeId );
		$f = self::filtreAnnee( $annee, $params );
		$rows = FKC_DB::q(
			"SELECT v.id valeur_id, v.code, v.libelle, " . FKC_Division::sqlBlocs() . "
			 FROM ligne_affectations a
			 JOIN analytique_valeurs v ON v.id = a.valeur_id
			 JOIN ecriture_lignes el ON el.id = a.ecriture_ligne_id
			 JOIN ecritures e ON e.id = el.ecriture_id
			 JOIN comptes c ON c.id = el.compte_id
			 WHERE a.axe_id = ? AND " . FKC_Division::sqlGestion() . " {$f}
			 GROUP BY v.id ORDER BY v.ordre, v.libelle COLLATE NOCASE",
			$params
		)->fetchAll();

		/* Parts ventilées sur cet axe (1.823.0) : ajoutées à leur valeur. */
		$vent = class_exists( 'FKC_Ventilation' ) ? FKC_Ventilation::montantsAxe( $axeId, $annee ) : array();
		if ( $vent ) {
			$idx = array();
			foreach ( $rows as $i => $r ) { $idx[ (int) $r['valeur_id'] ] = $i; }
			foreach ( $vent as $vid => $m ) {
				if ( isset( $idx[ $vid ] ) ) {
					foreach ( $m as $k => $x ) { $rows[ $idx[ $vid ] ][ $k ] = (float) $rows[ $idx[ $vid ] ][ $k ] + $x; }
					continue;
				}
				$v = FKC_Valeur::find( $vid );
				if ( ! $v ) { continue; } // valeur disparue : la part reste au non affecté
				$rows[] = array( 'valeur_id' => $vid, 'code' => $v['code'], 'libelle' => $v['libelle'] ) + $m;
			}
			$ordres = array();
			foreach ( FKC_DB::q( 'SELECT id, ordre FROM analytique_valeurs WHERE axe_id=?', array( (int) $axeId ) )->fetchAll() as $o ) { $ordres[ (int) $o['id'] ] = (int) $o['ordre']; }
			usort( $rows, function ( $a, $b ) use ( $ordres ) {
				$o = ( $ordres[ (int) $a['valeur_id'] ] ?? 0 ) <=> ( $ordres[ (int) $b['valeur_id'] ] ?? 0 );
				return $o ?: strcasecmp( (string) $a['libelle'], (string) $b['libelle'] );
			} );
		}

		$lignes = array(); $aff = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		foreach ( $rows as $r ) {
			$p = (float) $r['produits']; $ch = (float) $r['charges']; $h = (float) $r['hao'];
			$lignes[] = array( 'valeur_id' => (int) $r['valeur_id'], 'code' => $r['code'], 'libelle' => $r['libelle'], 'produits' => $p, 'charges' => $ch, 'resultat' => $p - $ch,
				'hao' => $h, 'resultat_net' => $p - $ch + $h );
			$aff['produits'] += $p; $aff['charges'] += $ch; $aff['hao'] += $h;
		}
		$tot = self::totauxPeriode( $annee );
		$ni = array( 'produits' => $tot['produits'] - $aff['produits'], 'charges' => $tot['charges'] - $aff['charges'], 'hao' => $tot['hao'] - $aff['hao'] );
		$ni['resultat'] = $ni['produits'] - $ni['charges'];
		$ni['resultat_net'] = $ni['resultat'] + $ni['hao'];
		$totaux = array( 'produits' => $tot['produits'], 'charges' => $tot['charges'], 'resultat' => $tot['produits'] - $tot['charges'],
			'hao' => $tot['hao'], 'resultat_net' => $tot['produits'] - $tot['charges'] + $tot['hao'] );
		return array(
			'axe' => $axe, 'lignes' => $lignes, 'non_affecte' => $ni,
			'totaux' => $totaux,
			'couverture' => self::couverture( $totaux, $ni ),
		);
	}

	/**
	 * Part du mouvement de la période réellement rattachée à une valeur de
	 * l'axe, en %. Un axe à 40 % de couverture rend tout classement trompeur :
	 * le « meilleur client » n'est peut-être que le mieux affecté. L'écran
	 * doit pouvoir le dire.
	 *
	 * @return int|null null quand il n'y a aucun mouvement à couvrir.
	 */
	public static function couverture( $totaux, $nonAffecte ) {
		$masse = abs( (float) $totaux['produits'] ) + abs( (float) $totaux['charges'] );
		if ( $masse <= 0.005 ) { return null; }
		$hors = abs( (float) $nonAffecte['produits'] ) + abs( (float) $nonAffecte['charges'] );
		return (int) max( 0, min( 100, round( ( $masse - $hors ) / $masse * 100 ) ) );
	}
}
