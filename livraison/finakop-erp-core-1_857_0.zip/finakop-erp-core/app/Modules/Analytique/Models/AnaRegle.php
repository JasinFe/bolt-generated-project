<?php
/**
 * RÈGLES D'IMPUTATION AUTOMATIQUE (1.824.0).
 *
 * « Tout 622 du fournisseur SCI Plateau va à Abidjan », « l'électricité se
 * ventile selon la clé ÉLEC ». Sans règle, chaque ligne récurrente devait
 * être affectée à la main, mois après mois — et ce qui ne l'était pas
 * finissait en « non imputé ».
 *
 * Une règle combine des CRITÈRES (au moins un) :
 *   - compte : préfixe de classe 6, 7 ou 8 (« 622 », « 6051 ») ;
 *   - journal ;
 *   - tiers : le fournisseur ou le client porté par l'écriture (le tiers est
 *     sur la ligne 401/411, la règle regarde donc toute l'écriture) ;
 *   - libellé contient (ligne ou écriture, sans tenir compte de la casse) ;
 * et une ACTION sur un axe : une valeur, OU une clé de répartition (fixe ou
 * dynamique) qui ventile la ligne.
 *
 * Principes :
 *   - la règle ne REMPLACE jamais une imputation existante : elle ne remplit
 *     que les axes encore vides de la ligne. Une saisie manuelle gagne ;
 *   - par axe, la première règle qui correspond l'emporte (priorité, puis
 *     ancienneté) ; plusieurs règles peuvent agir sur des axes différents ;
 *   - elle s'applique à chaque écriture comptabilisée (y compris à la
 *     validation du journal temporaire), et à la demande sur les lignes déjà
 *     passées des exercices ouverts, après un aperçu ;
 *   - jamais sur une écriture de clôture ni sur une contre-passation (qui
 *     reprend l'imputation de la ligne qu'elle annule, ni plus ni moins).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaRegle {

	protected static $ready = false;
	protected static $cache = null;

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS ana_regles(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					libelle TEXT NOT NULL,
					priorite INTEGER NOT NULL DEFAULT 10,
					actif INTEGER NOT NULL DEFAULT 1,
					compte_prefixe TEXT,
					journal_id INTEGER,
					tiers_type TEXT,
					tiers_id INTEGER,
					libelle_contient TEXT,
					axe_id INTEGER NOT NULL,
					valeur_id INTEGER,
					repartition_id INTEGER,
					appliquees INTEGER NOT NULL DEFAULT 0,
					created_at TEXT DEFAULT(datetime('now','localtime'))
				);
			" );
		} catch ( \Throwable $e ) { self::$ready = false; }
	}

	/** Réinitialise les mémoïsations (changement de société, tests). */
	public static function reset() { self::$ready = false; self::$cache = null; }

	public static function all() {
		self::ensure();
		try { return FKC_DB::q( 'SELECT * FROM ana_regles ORDER BY priorite, id' )->fetchAll(); }
		catch ( \Throwable $e ) { return array(); }
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM ana_regles WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/** Règles actives, mémorisées pour la requête (la comptabilisation en lit une par écriture). */
	protected static function actives() {
		if ( null === self::$cache ) {
			self::$cache = array_values( array_filter( self::all(), function ( $r ) { return ! empty( $r['actif'] ); } ) );
		}
		return self::$cache;
	}

	/* ── Création, gestion ────────────────────────────────────────────── */

	/** @return array{0:bool,1:string,2:int} */
	public static function creer( array $d ) {
		self::ensure();
		$lib = trim( (string) ( $d['libelle'] ?? '' ) );
		$compte = preg_replace( '/\D/', '', (string) ( $d['compte_prefixe'] ?? '' ) );
		$journal = (int) ( $d['journal_id'] ?? 0 );
		$tiersT = null; $tiersI = null;
		if ( preg_match( '/^(fournisseur|client):(\d+)$/', (string) ( $d['tiers'] ?? '' ), $m ) ) { $tiersT = $m[1]; $tiersI = (int) $m[2]; }
		$contient = trim( (string) ( $d['libelle_contient'] ?? '' ) );
		$axeId = (int) ( $d['axe_id'] ?? 0 );
		$valeur = (int) ( $d['valeur_id'] ?? 0 );
		$rep = (int) ( $d['repartition_id'] ?? 0 );

		if ( '' === $lib ) { return array( false, 'Donnez un nom à la règle.', 0 ); }
		if ( '' !== $compte && ! in_array( $compte[0], array( '6', '7', '8' ), true ) ) {
			return array( false, 'Le compte doit commencer par 6, 7 ou 8 : seules les charges et les produits s\'imputent en analytique.', 0 );
		}
		if ( '' === $compte && ! $journal && ! $tiersI && '' === $contient ) {
			return array( false, 'Indiquez au moins un critère (compte, journal, tiers ou libellé) : une règle sans critère imputerait toute la comptabilité.', 0 );
		}
		$axe = FKC_Axe::find( $axeId );
		if ( ! $axe ) { return array( false, 'Choisissez l\'axe sur lequel la règle impute.', 0 ); }
		if ( ( $valeur > 0 ) === ( $rep > 0 ) ) { return array( false, 'Choisissez SOIT une valeur, SOIT une clé de répartition.', 0 ); }
		if ( $valeur && ! FKC_Ventilation::valeurValide( $axeId, $valeur ) ) {
			return array( false, 'La valeur choisie n\'appartient pas à l\'axe « ' . $axe['libelle'] . ' », ou elle est désactivée.', 0 );
		}
		if ( $rep ) {
			$r = FKC_Repartition::find( $rep );
			if ( ! $r ) { return array( false, 'Clé de répartition introuvable.', 0 ); }
			$cible = 'dynamique' === $r['type'] && ! empty( $r['base_axe_id'] ) ? (int) $r['base_axe_id'] : (int) $r['axe_id'];
			if ( $cible !== $axeId ) { return array( false, 'La clé « ' . $r['code'] . ' » ventile un autre axe que « ' . $axe['libelle'] . ' ».', 0 ); }
		}
		FKC_DB::q(
			'INSERT INTO ana_regles(libelle,priorite,actif,compte_prefixe,journal_id,tiers_type,tiers_id,libelle_contient,axe_id,valeur_id,repartition_id) VALUES(?,?,1,?,?,?,?,?,?,?,?)',
			array( $lib, max( 0, (int) ( $d['priorite'] ?? 10 ) ), '' !== $compte ? $compte : null, $journal ?: null, $tiersT, $tiersI,
				'' !== $contient ? $contient : null, $axeId, $valeur ?: null, $rep ?: null )
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		self::$cache = null;
		FKC_Security::audit( 'analytique_regle', 'Règle #' . $id . ' « ' . $lib . ' » créée : ' . self::decrire( self::find( $id ) ) );
		return array( true, 'Règle « ' . $lib . ' » créée. Elle s\'appliquera aux prochaines écritures ; « Appliquer aux lignes déjà passées » la rattrape sur l\'existant.', $id );
	}

	public static function basculer( $id ) {
		$r = self::find( $id );
		if ( ! $r ) { return; }
		FKC_DB::q( 'UPDATE ana_regles SET actif=? WHERE id=?', array( empty( $r['actif'] ) ? 1 : 0, (int) $id ) );
		self::$cache = null;
		FKC_Security::audit( 'analytique_regle', 'Règle #' . (int) $id . ' « ' . $r['libelle'] . ' » ' . ( empty( $r['actif'] ) ? 'réactivée' : 'suspendue' ) . '.' );
	}

	/** Supprimer une règle ne défait pas ce qu'elle a imputé : les lignes gardent leur imputation. */
	public static function supprimer( $id ) {
		$r = self::find( $id );
		if ( ! $r ) { return; }
		FKC_DB::q( 'DELETE FROM ana_regles WHERE id=?', array( (int) $id ) );
		self::$cache = null;
		FKC_Security::audit( 'analytique_regle', 'Règle #' . (int) $id . ' « ' . $r['libelle'] . ' » supprimée (' . (int) $r['appliquees'] . ' imputation(s) passées conservées).' );
	}

	/** Lecture humaine d'une règle : « compte 622… · fournisseur SCI → Division : Abidjan ». */
	public static function decrire( $r ) {
		if ( ! $r ) { return ''; }
		$c = array();
		if ( ! empty( $r['compte_prefixe'] ) ) { $c[] = 'compte ' . $r['compte_prefixe'] . '…'; }
		if ( ! empty( $r['journal_id'] ) ) {
			$j = FKC_DB::q( 'SELECT code FROM journaux WHERE id=?', array( (int) $r['journal_id'] ) )->fetchColumn();
			$c[] = 'journal ' . ( $j ?: '#' . (int) $r['journal_id'] );
		}
		if ( ! empty( $r['tiers_id'] ) ) {
			$t = 'fournisseur' === $r['tiers_type'] ? 'fournisseurs' : 'clients';
			$nom = '';
			try { $nom = (string) FKC_DB::q( "SELECT nom FROM {$t} WHERE id=?", array( (int) $r['tiers_id'] ) )->fetchColumn(); } catch ( \Throwable $e ) { /* */ }
			$c[] = $r['tiers_type'] . ' ' . ( '' !== $nom ? $nom : '#' . (int) $r['tiers_id'] );
		}
		if ( ! empty( $r['libelle_contient'] ) ) { $c[] = 'libellé contient « ' . $r['libelle_contient'] . ' »'; }
		$axe = FKC_Axe::find( $r['axe_id'] );
		$cible = '';
		if ( ! empty( $r['repartition_id'] ) ) {
			$rep = FKC_Repartition::find( $r['repartition_id'] );
			$cible = 'clé ' . ( $rep['code'] ?? '#' . (int) $r['repartition_id'] );
		} elseif ( ! empty( $r['valeur_id'] ) ) {
			$cible = $axe && 'DIV' === $axe['code']
				? ( FKC_Division::find( $r['valeur_id'] )['libelle'] ?? '#' . (int) $r['valeur_id'] )
				: ( FKC_Valeur::find( $r['valeur_id'] )['libelle'] ?? '#' . (int) $r['valeur_id'] );
		}
		return implode( ' · ', $c ) . ' → ' . ( $axe['libelle'] ?? 'axe ?' ) . ' : ' . $cible;
	}

	/* ── Correspondance ───────────────────────────────────────────────── */

	/** Contexte d'une écriture : ses lignes de gestion, ses tiers, son journal, ses libellés. */
	protected static function contexte( $ecritureId ) {
		$e = FKC_DB::q( 'SELECT * FROM ecritures WHERE id=?', array( (int) $ecritureId ) )->fetch();
		if ( ! $e ) { return null; }
		$lignes = FKC_DB::q(
			'SELECT el.id, el.libelle, el.division_id, el.tiers_type, el.tiers_id, c.numero
			 FROM ecriture_lignes el JOIN comptes c ON c.id = el.compte_id WHERE el.ecriture_id=?',
			array( (int) $ecritureId )
		)->fetchAll();
		$tiers = array();
		foreach ( $lignes as $l ) {
			if ( ! empty( $l['tiers_type'] ) && ! empty( $l['tiers_id'] ) ) { $tiers[ $l['tiers_type'] . ':' . (int) $l['tiers_id'] ] = true; }
		}
		return array( 'e' => $e, 'lignes' => $lignes, 'tiers' => $tiers );
	}

	/** Une écriture que les règles ne touchent pas : clôture, contre-passation. */
	protected static function exclue( array $e ) {
		if ( 0 === strpos( (string) ( $e['reference'] ?? '' ), 'ANN#' ) ) { return true; }
		if ( 'annulation' === (string) ( $e['type_ecriture'] ?? '' ) ) { return true; }
		if ( 'resultat' === (string) ( $e['origine'] ?? '' ) || 'cloture' === (string) ( $e['source'] ?? '' ) ) { return true; }
		return false;
	}

	protected static function correspond( array $r, array $l, array $ctx ) {
		if ( ! empty( $r['compte_prefixe'] ) && 0 !== strpos( (string) $l['numero'], (string) $r['compte_prefixe'] ) ) { return false; }
		if ( ! empty( $r['journal_id'] ) && (int) $r['journal_id'] !== (int) $ctx['e']['journal_id'] ) { return false; }
		if ( ! empty( $r['tiers_id'] ) && empty( $ctx['tiers'][ $r['tiers_type'] . ':' . (int) $r['tiers_id'] ] ) ) { return false; }
		if ( ! empty( $r['libelle_contient'] ) ) {
			$txt = mb_strtolower( (string) $l['libelle'] . ' ' . (string) $ctx['e']['libelle'] );
			if ( false === mb_strpos( $txt, mb_strtolower( (string) $r['libelle_contient'] ) ) ) { return false; }
		}
		return true;
	}

	/** Axes déjà imputés d'une ligne (affectation ou ventilation). */
	protected static function axesPris( $ligneId ) {
		$pris = array();
		foreach ( FKC_Affectation::forLigne( $ligneId ) as $a => $v ) { if ( $v ) { $pris[ (int) $a ] = true; } }
		foreach ( FKC_Ventilation::pourLigne( $ligneId ) as $a => $p ) { $pris[ (int) $a ] = true; }
		return $pris;
	}

	/**
	 * Ce que les règles feraient sur une écriture : [ [ligne_id, regle, axe_id] … ].
	 * Par axe, la première règle qui correspond ; les axes déjà imputés sont laissés.
	 */
	protected static function plan( $ecritureId, array $regles, $seulementLigne = null ) {
		$ctx = self::contexte( $ecritureId );
		if ( ! $ctx || self::exclue( $ctx['e'] ) ) { return array(); }
		$plan = array();
		foreach ( $ctx['lignes'] as $l ) {
			if ( null !== $seulementLigne && (int) $l['id'] !== (int) $seulementLigne ) { continue; }
			if ( ! in_array( substr( (string) $l['numero'], 0, 1 ), array( '6', '7', '8' ), true ) ) { continue; }
			$pris = self::axesPris( $l['id'] );
			foreach ( $regles as $r ) {
				$axe = (int) $r['axe_id'];
				if ( isset( $pris[ $axe ] ) ) { continue; }
				if ( ! self::correspond( $r, $l, $ctx ) ) { continue; }
				$plan[] = array( (int) $l['id'], $r, $axe );
				$pris[ $axe ] = true; // première règle de l'axe : elle l'emporte
			}
		}
		return array( $plan, $ctx['e'] );
	}

	/** Exécute une imputation planifiée. @return array{0:bool,1:string} */
	protected static function executer( $ligneId, array $r, $date ) {
		if ( ! empty( $r['repartition_id'] ) ) {
			$an = class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::annee( $date ) : substr( (string) $date, 0, 4 );
			list( $ok, $msg, $axeId, $parts ) = FKC_Ventilation::partsCle( (int) $r['repartition_id'], $an );
			if ( ! $ok ) { return array( false, $msg ); }
			if ( (int) $axeId !== (int) $r['axe_id'] ) { return array( false, 'La clé ne ventile plus cet axe.' ); }
			return FKC_Ventilation::definir( $ligneId, $axeId, $parts, array( 'repartition_id' => (int) $r['repartition_id'], 'audit' => false ) );
		}
		if ( ! FKC_Ventilation::valeurValide( $r['axe_id'], $r['valeur_id'] ) ) { return array( false, 'Valeur désactivée ou supprimée.' ); }
		if ( FKC_Affectation::estVerrouillee( $date ) ) { return array( false, 'Exercice clôturé.' ); }
		FKC_Affectation::setForLigne( $ligneId, array( (int) $r['axe_id'] => (int) $r['valeur_id'] ) );
		return array( true, '' );
	}

	/**
	 * Appelé par FKC_Ecriture::save() après l'insertion des lignes.
	 * Ne lève jamais : une règle cassée ne doit pas empêcher de comptabiliser.
	 * @return int nombre d'imputations posées.
	 */
	public static function appliquerEcriture( $ecritureId ) {
		try {
			self::ensure();
			$regles = self::actives();
			if ( ! $regles ) { return 0; }
			$p = self::plan( $ecritureId, $regles );
			if ( ! $p ) { return 0; }
			list( $plan, $e ) = $p;
			$n = 0;
			foreach ( $plan as $x ) {
				list( $ok ) = self::executer( $x[0], $x[1], $e['date_ecriture'] );
				if ( $ok ) {
					$n++;
					FKC_DB::q( 'UPDATE ana_regles SET appliquees = appliquees + 1 WHERE id=?', array( (int) $x[1]['id'] ) );
				}
			}
			return $n;
		} catch ( \Throwable $ex ) {
			if ( function_exists( 'fkc_log' ) ) { fkc_log( 'AnaRegle::appliquerEcriture ' . $ex->getMessage(), 'WARN' ); }
			return 0;
		}
	}

	/* ── Rattrapage sur les lignes déjà passées ───────────────────────── */

	/** Écritures de l'exercice portant au moins une ligne 6/7/8 (exercice ouvert seulement). */
	protected static function ecrituresExercice( $annee ) {
		$params = array();
		$f = FKC_Division::filtrePeriode( $annee, $params );
		$b = FKC_Division::bornes( $annee );
		if ( $b && FKC_Affectation::estVerrouillee( $b[1] ) ) { return array(); }
		return array_map( 'intval', FKC_DB::q(
			"SELECT DISTINCT e.id FROM ecritures e JOIN ecriture_lignes el ON el.ecriture_id = e.id JOIN comptes c ON c.id = el.compte_id
			 WHERE " . FKC_Division::sqlGestion() . " {$f} ORDER BY e.id",
			$params
		)->fetchAll( PDO::FETCH_COLUMN ) );
	}

	/**
	 * Aperçu : combien de lignes chaque règle imputerait sur l'exercice, sans rien écrire.
	 * @return array{par_regle:array, lignes:int, clos:bool}
	 */
	public static function apercu( $annee, $regleId = null ) {
		self::ensure();
		$regles = self::actives();
		if ( null !== $regleId ) { $regles = array_values( array_filter( $regles, function ( $r ) use ( $regleId ) { return (int) $r['id'] === (int) $regleId; } ) ); }
		$b = FKC_Division::bornes( $annee );
		$out = array( 'par_regle' => array(), 'lignes' => 0, 'clos' => $b && FKC_Affectation::estVerrouillee( $b[1] ) );
		if ( ! $regles || $out['clos'] ) { return $out; }
		$lignes = array();
		foreach ( self::ecrituresExercice( $annee ) as $eid ) {
			$p = self::plan( $eid, $regles );
			if ( ! $p ) { continue; }
			foreach ( $p[0] as $x ) {
				$rid = (int) $x[1]['id'];
				$out['par_regle'][ $rid ] = ( $out['par_regle'][ $rid ] ?? 0 ) + 1;
				$lignes[ $x[0] ] = true;
			}
		}
		$out['lignes'] = count( $lignes );
		return $out;
	}

	/**
	 * Applique les règles aux lignes déjà passées d'un exercice ouvert.
	 * @return array{imputations:int, lignes:int, refus:array, clos:bool}
	 */
	public static function appliquerExercice( $annee, $regleId = null ) {
		self::ensure();
		$regles = self::actives();
		if ( null !== $regleId ) { $regles = array_values( array_filter( $regles, function ( $r ) use ( $regleId ) { return (int) $r['id'] === (int) $regleId; } ) ); }
		$b = FKC_Division::bornes( $annee );
		$out = array( 'imputations' => 0, 'lignes' => 0, 'refus' => array(), 'clos' => $b && FKC_Affectation::estVerrouillee( $b[1] ) );
		if ( ! $regles || $out['clos'] ) { return $out; }
		$lignes = array(); $parRegle = array();
		foreach ( self::ecrituresExercice( $annee ) as $eid ) {
			$p = self::plan( $eid, $regles );
			if ( ! $p ) { continue; }
			foreach ( $p[0] as $x ) {
				list( $ok, $msg ) = self::executer( $x[0], $x[1], $p[1]['date_ecriture'] );
				if ( ! $ok ) { $out['refus'][] = '« ' . $x[1]['libelle'] . ' » : ' . $msg; continue; }
				$out['imputations']++;
				$lignes[ $x[0] ] = true;
				$parRegle[ (int) $x[1]['id'] ] = ( $parRegle[ (int) $x[1]['id'] ] ?? 0 ) + 1;
			}
		}
		foreach ( $parRegle as $rid => $n ) { FKC_DB::q( 'UPDATE ana_regles SET appliquees = appliquees + ? WHERE id=?', array( $n, $rid ) ); }
		$out['lignes'] = count( $lignes );
		$out['refus'] = array_values( array_unique( $out['refus'] ) );
		if ( $out['imputations'] ) {
			$d = array();
			foreach ( $parRegle as $rid => $n ) { $d[] = '#' . $rid . '×' . $n; }
			FKC_Security::audit( 'analytique_regle', 'Règles appliquées à l\'exercice ' . $annee . ' : ' . $out['imputations'] . ' imputation(s) sur ' . $out['lignes'] . ' ligne(s) (' . implode( ', ', $d ) . ').' );
		}
		return $out;
	}
}
