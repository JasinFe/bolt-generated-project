<?php
/** KPIs analytiques : marge, rentabilité, performance, recouvrement. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaKpi {

	/** Bornes de l'exercice — déléguées au module, qui honore un exercice décalé. */
	protected static function bornes( $annee ) {
		if ( class_exists( 'FKC_Division' ) && method_exists( 'FKC_Division', 'bornes' ) ) {
			return FKC_Division::bornes( $annee );
		}
		$y = (string) $annee;
		return preg_match( '/^\d{4}$/', $y ) ? array( $y . '-01-01', $y . '-12-31' ) : null;
	}

	/**
	 * Somme orientée d'un préfixe de compte sur l'exercice — FLUX de la période
	 * (sens = produit:credit-debit, charge:debit-credit).
	 * C'est la bonne lecture pour un compte de gestion (classes 6 et 7), dont
	 * le solde repart de zéro à chaque exercice.
	 */
	protected static function prefixe( $prefixe, $annee, $sens = 'charge' ) {
		$expr = ( 'produit' === $sens ) ? 'el.credit - el.debit' : 'el.debit - el.credit';
		$params = array( $prefixe . '%' );
		$f = '';
		$b = self::bornes( $annee );
		if ( $b ) { $f = ' AND e.date_ecriture BETWEEN ? AND ? '; $params[] = $b[0]; $params[] = $b[1]; }
		/* Hors écriture de détermination du résultat (1.822.0) : sans cela, un exercice clôturé affichait un CA nul. */
		if ( class_exists( 'FKC_Division' ) && method_exists( 'FKC_Division', 'horsCloture' ) ) { $f .= FKC_Division::horsCloture(); }
		return (float) FKC_DB::q(
			"SELECT COALESCE(SUM({$expr}),0) FROM ecriture_lignes el
			 JOIN ecritures e ON e.id=el.ecriture_id JOIN comptes c ON c.id=el.compte_id
			 WHERE c.numero LIKE ? {$f}",
			$params
		)->fetchColumn();
	}

	/**
	 * SOLDE CUMULÉ d'un préfixe de compte à la clôture de l'exercice.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LE DSO ÉTAIT FAUX DÈS QU'IL EXISTAIT DES CRÉANCES ANTÉRIEURES (1.547.0)
	 *
	 * `creances` était calculé par `prefixe('41', $annee)` : le FLUX de
	 * l'année seulement. Une facture de décembre N-1 toujours impayée en
	 * juin N ne comptait pas — alors que c'est très exactement la créance
	 * qui fait mal. Le DSO affiché était donc systématiquement inférieur au
	 * réel, et d'autant plus que le retard était ancien. Un compte de tiers
	 * n'est pas un compte de gestion : son solde se REPORTE, il ne se
	 * recalcule pas.
	 *
	 * Comment on lit un solde reporté ici, sans double compte :
	 *
	 *   • Si l'exercice a été OUVERT, il porte son écriture d'à-nouveaux (D
	 *     ou C sur les classes 1 à 5, au journal AN) : le solde d'ouverture
	 *     est déjà DANS la période. On somme donc la période, exactement
	 *     comme le fait le bilan — cumuler depuis l'origine compterait deux
	 *     fois les mouvements antérieurs, une fois en direct et une fois via
	 *     l'à-nouveau.
	 *
	 *   • Si l'exercice n'a PAS été ouvert (aucune écriture AN sur la
	 *     période), il n'y a aucun report : on cumule alors depuis l'origine
	 *     jusqu'à la clôture. Sans ce repli, un dossier qui n'ouvre pas ses
	 *     exercices verrait ses créances repartir de zéro chaque 1er janvier.
	 *
	 * Le choix est déterminé par la base, pas par un réglage : les deux
	 * dossiers donnent le même chiffre, qui est le vrai.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @param string $prefixe Préfixe de compte (ex. '41').
	 * @param string $annee   Exercice ; vide = tout l'historique.
	 * @param string $sens    'debit' (actif) ou 'credit' (passif).
	 */
	protected static function soldeCumule( $prefixe, $annee, $sens = 'debit' ) {
		$expr   = ( 'credit' === $sens ) ? 'el.credit - el.debit' : 'el.debit - el.credit';
		$b      = self::bornes( $annee );
		$params = array( $prefixe . '%' );
		$f      = '';
		if ( $b ) {
			if ( self::exerciceReporte( $b ) ) {
				$f = ' AND e.date_ecriture BETWEEN ? AND ? ';
				$params[] = $b[0]; $params[] = $b[1];
			} else {
				$f = ' AND e.date_ecriture <= ? ';
				$params[] = $b[1];
			}
		}
		try {
			return (float) FKC_DB::q(
				"SELECT COALESCE(SUM({$expr}),0) FROM ecriture_lignes el
				 JOIN ecritures e ON e.id=el.ecriture_id JOIN comptes c ON c.id=el.compte_id
				 WHERE c.numero LIKE ? {$f}",
				$params
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/** L'exercice porte-t-il une écriture d'à-nouveaux (journal AN) ? */
	protected static function exerciceReporte( $bornes ) {
		try {
			return (bool) FKC_DB::q(
				"SELECT 1 FROM ecritures e JOIN journaux j ON j.id=e.journal_id
				 WHERE j.code='AN' AND e.date_ecriture BETWEEN ? AND ? LIMIT 1",
				array( $bornes[0], $bornes[1] )
			)->fetch();
		} catch ( \Throwable $e ) { return false; }
	}

	public static function compute( $annee ) {
		$ca          = self::prefixe( '70', $annee, 'produit' );  // ventes
		$produits    = self::prefixe( '7',  $annee, 'produit' );
		$achats      = self::prefixe( '60', $annee, 'charge' );   // achats consommés
		$persoCharge = self::prefixe( '66', $annee, 'charge' );   // charges de personnel
		$charges     = self::prefixe( '6',  $annee, 'charge' );
		// Créances clients : SOLDE cumulé à la clôture, pas le flux de l'année.
		$creances    = self::soldeCumule( '41', $annee, 'debit' );
		if ( $creances < 0 ) { $creances = 0.0; } // solde créditeur net : rien à recouvrer
		$resultat    = $produits - $charges;
		$base        = $ca > 0 ? $ca : $produits;

		/*
		 * DSO — le dénominateur doit être HOMOGÈNE au numérateur.
		 *
		 * Les créances du compte 41 sont TTC (le client doit aussi la TVA), le
		 * CA du compte 70 est HT. Rapporter l'un à l'autre gonflait le délai
		 * d'encaissement du taux de TVA lui-même — près de 18 % de DSO en trop
		 * sur un dossier assujetti, soit une dizaine de jours inventés.
		 * On reconstitue donc le CA TTC en ajoutant la TVA facturée de la
		 * période (443x, et 4421 pour les plans antérieurs). Un dossier non
		 * assujetti n'a pas de TVA collectée : la base reste le CA HT et le
		 * calcul est exactement celui d'avant.
		 */
		$tvaCollectee = self::prefixe( '443', $annee, 'produit' ) + self::prefixe( '4421', $annee, 'produit' );
		if ( $tvaCollectee < 0 ) { $tvaCollectee = 0.0; }
		$baseDso = $base + $tvaCollectee;

		$margeBrute = $ca - $achats;
		return array(
			'ca' => $ca, 'produits' => $produits, 'charges' => $charges, 'resultat' => $resultat,
			'marge_brute' => $margeBrute,
			'taux_marge_brute' => $ca > 0 ? round( $margeBrute / $ca * 100, 1 ) : null,
			'rentabilite' => $produits > 0 ? round( $resultat / $produits * 100, 1 ) : null,
			'cout_salarie' => $persoCharge,
			'taux_cout_salarie' => $base > 0 ? round( $persoCharge / $base * 100, 1 ) : null,
			'creances' => $creances,
			'base_dso' => $baseDso,
			'dso_ttc'  => $tvaCollectee > 0,
			/*
			 * null, et non 0 : sans activité, le délai d'encaissement n'est pas
			 * « nul », il est indéterminé. Afficher « 0 j » laissait croire que
			 * tout était encaissé alors que rien n'avait été facturé.
			 */
			'dso' => $baseDso > 0 ? (int) round( $creances / $baseDso * 365 ) : null,
		);
	}
}
