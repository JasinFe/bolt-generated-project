<?php
/**
 * BUDGET MENSUEL PAR NATURE (1.831.0).
 *
 * Le budget analytique existant tenait en deux nombres par division et par
 * an : « produits » et « charges ». Impossible d'y lire qu'en mars le loyer
 * est tenu mais que les transports dérapent, ni de comparer au mois écoulé :
 * un budget annuel comparé à un réalisé de trois mois paraît toujours
 * « sous-consommé ».
 *
 * Ici le budget se saisit par NATURE — les comptes à deux chiffres du plan
 * SYSCOHADA (60 Achats, 61 Transports, 62 Services extérieurs, 66 Personnel,
 * 70 Ventes…) — et par MOIS de l'exercice (décalé compris), pour l'entreprise
 * entière ou pour une division. Le suivi compare mois par mois et en cumul
 * à fin de mois, avec le réalisé lu au grand livre (ventilations comprises
 * pour une division).
 *
 * Classes 6 et 7 seulement : c'est le budget d'exploitation. Les opérations
 * hors activités ordinaires (classe 8) ne se budgètent pas au mois.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_BudgetMensuel {

	protected static $ready = false;

	/** Libellés de repli (plan SYSCOHADA révisé), si le plan du dossier n'a pas le compte titre. */
	const NATURES_DEFAUT = array(
		'60' => 'Achats', '61' => 'Transports', '62' => 'Services extérieurs', '63' => 'Autres services extérieurs',
		'64' => 'Impôts et taxes', '65' => 'Autres charges', '66' => 'Charges de personnel', '67' => 'Frais financiers',
		'68' => 'Dotations aux amortissements', '69' => 'Dotations aux provisions',
		'70' => 'Ventes', '71' => 'Subventions d\'exploitation', '72' => 'Production immobilisée', '73' => 'Variations de stocks produits',
		'75' => 'Autres produits', '77' => 'Revenus financiers', '78' => 'Transferts de charges', '79' => 'Reprises de provisions',
	);

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS ana_budget_mensuel(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					annee TEXT NOT NULL,
					division_id INTEGER NOT NULL DEFAULT 0,
					nature TEXT NOT NULL,
					mois INTEGER NOT NULL,
					montant REAL NOT NULL DEFAULT 0,
					updated_at TEXT DEFAULT(datetime('now','localtime')),
					UNIQUE(annee, division_id, nature, mois)
				);
				CREATE INDEX IF NOT EXISTS idx_bm_sec ON ana_budget_mensuel(annee, division_id);
			" );
		} catch ( \Throwable $e ) { self::$ready = false; }
	}

	public static function reset() { self::$ready = false; }

	/** Natures budgétables : [code => ['libelle', 'sens' => charge|produit]]. */
	public static function natures() {
		$out = array();
		foreach ( self::NATURES_DEFAUT as $k => $lib ) { $out[ $k ] = array( 'libelle' => $lib, 'sens' => '6' === $k[0] ? 'charge' : 'produit' ); }
		try {
			foreach ( FKC_DB::q( "SELECT numero, libelle FROM comptes WHERE type='titre' AND ( numero LIKE '6_' OR numero LIKE '7_' OR numero LIKE '6_0000' OR numero LIKE '7_0000' )" )->fetchAll() as $r ) {
				$k = substr( (string) $r['numero'], 0, 2 );
				if ( isset( $out[ $k ] ) || in_array( $k[0], array( '6', '7' ), true ) ) {
					$out[ $k ] = array( 'libelle' => (string) $r['libelle'], 'sens' => '6' === $k[0] ? 'charge' : 'produit' );
				}
			}
		} catch ( \Throwable $e ) { /* plan absent : libellés de repli */ }
		ksort( $out, SORT_STRING );
		return $out;
	}

	/** Les douze mois de l'exercice : [1 => 'AAAA-MM', …, 12 => 'AAAA-MM']. */
	public static function moisExercice( $annee ) {
		$b = FKC_Division::bornes( $annee );
		$c = $b ? substr( $b[0], 0, 7 ) : ( (int) $annee ) . '-01';
		$out = array();
		for ( $i = 1; $i <= 12; $i++ ) { $out[ $i ] = $c; $c = date( 'Y-m', strtotime( $c . '-01 +1 month' ) ); }
		return $out;
	}

	/** Libellé court d'un mois : « janv. 26 ». */
	public static function libMois( $ym ) {
		$n = array( 1 => 'janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.' );
		return $n[ (int) substr( $ym, 5, 2 ) ] . ' ' . substr( $ym, 2, 2 );
	}

	/** Budget saisi : [nature => [mois => montant]]. */
	public static function budget( $annee, $divisionId ) {
		self::ensure();
		$out = array();
		foreach ( FKC_DB::q( 'SELECT nature, mois, montant FROM ana_budget_mensuel WHERE annee=? AND division_id=?', array( (string) $annee, (int) $divisionId ) )->fetchAll() as $r ) {
			$out[ (string) $r['nature'] ][ (int) $r['mois'] ] = (float) $r['montant'];
		}
		return $out;
	}

	/** Sections budgétées sur l'exercice (0 = entreprise). */
	public static function sectionsBudgetees( $annee ) {
		self::ensure();
		return array_map( 'intval', FKC_DB::q( 'SELECT DISTINCT division_id FROM ana_budget_mensuel WHERE annee=?', array( (string) $annee ) )->fetchAll( PDO::FETCH_COLUMN ) );
	}

	/**
	 * Réalisé : [nature => [mois => montant]] — charges au débit, produits au
	 * crédit, en positif. Pour une division : imputations directes + parts
	 * ventilées. Écriture de clôture exclue (filtre de période commun).
	 */
	public static function reel( $annee, $divisionId ) {
		$mois = array_flip( self::moisExercice( $annee ) );
		$out = array();
		$signe = "CASE WHEN c.numero LIKE '6%' THEN el.debit - el.credit ELSE el.credit - el.debit END";
		$classes = " ( c.numero LIKE '6%' OR c.numero LIKE '7%' ) ";
		$blocs = array();
		$p = array();
		$f = FKC_Division::filtrePeriode( $annee, $p );
		if ( (int) $divisionId ) {
			array_unshift( $p, (int) $divisionId );
			$blocs[] = array( "SELECT substr(c.numero,1,2) nat, substr(e.date_ecriture,1,7) ym, SUM({$signe}) m
				FROM ecriture_lignes el JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
				WHERE el.division_id = ? AND {$classes} {$f} GROUP BY nat, ym", $p );
			FKC_Ventilation::ensure();
			$axe = FKC_Ventilation::axeDivision();
			if ( $axe ) {
				$p2 = array();
				$f2 = FKC_Division::filtrePeriode( $annee, $p2 );
				$p2 = array_merge( array( $axe, (int) $divisionId ), $p2 );
				$blocs[] = array( "SELECT substr(c.numero,1,2) nat, substr(e.date_ecriture,1,7) ym, SUM(({$signe}) * lv.pourcentage / 100.0) m
					FROM ligne_ventilations lv JOIN ecriture_lignes el ON el.id = lv.ecriture_ligne_id
					JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
					WHERE lv.axe_id = ? AND lv.valeur_id = ? AND el.division_id IS NULL AND {$classes} {$f2} GROUP BY nat, ym", $p2 );
			}
		} else {
			$blocs[] = array( "SELECT substr(c.numero,1,2) nat, substr(e.date_ecriture,1,7) ym, SUM({$signe}) m
				FROM ecriture_lignes el JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
				WHERE {$classes} {$f} GROUP BY nat, ym", $p );
		}
		foreach ( $blocs as $b ) {
			try {
				foreach ( FKC_DB::q( $b[0], $b[1] )->fetchAll() as $r ) {
					if ( ! isset( $mois[ $r['ym'] ] ) ) { continue; }
					$i = $mois[ $r['ym'] ];
					$out[ (string) $r['nat'] ][ $i ] = ( $out[ (string) $r['nat'] ][ $i ] ?? 0 ) + (float) $r['m'];
				}
			} catch ( \Throwable $e ) { /* base partielle */ }
		}
		return $out;
	}

	/** Exercice clôturé : son budget ne se modifie plus. */
	public static function estFige( $annee ) {
		$b = FKC_Division::bornes( $annee );
		return $b && FKC_Affectation::estVerrouillee( $b[1] );
	}

	/**
	 * Remplace le budget d'une section. $grille[nature][mois] = montant.
	 * @return array{0:bool,1:string}
	 */
	public static function enregistrer( $annee, $divisionId, array $grille ) {
		self::ensure();
		if ( self::estFige( $annee ) ) { return array( false, 'L\'exercice ' . $annee . ' est clôturé : son budget est figé.' ); }
		if ( (int) $divisionId && ! FKC_Division::find( $divisionId ) ) { return array( false, 'Division introuvable.' ); }
		$nat = self::natures();
		$avant = self::totaux( self::budget( $annee, $divisionId ) );
		$n = 0;
		$fn = function () use ( $annee, $divisionId, $grille, $nat, &$n ) {
			FKC_DB::q( 'DELETE FROM ana_budget_mensuel WHERE annee=? AND division_id=?', array( (string) $annee, (int) $divisionId ) );
			foreach ( $grille as $k => $mois ) {
				$k = (string) $k;
				if ( ! isset( $nat[ $k ] ) || ! is_array( $mois ) ) { continue; }
				foreach ( $mois as $i => $v ) {
					$i = (int) $i;
					$v = round( (float) str_replace( array( ' ', "\u{202f}", ',' ), array( '', '', '.' ), (string) $v ) );
					if ( $i < 1 || $i > 12 || 0.0 === $v ) { continue; }
					if ( $v < 0 ) { continue; } // un budget se saisit en positif, le sens vient de la nature
					FKC_DB::q( 'INSERT INTO ana_budget_mensuel(annee,division_id,nature,mois,montant) VALUES(?,?,?,?,?)', array( (string) $annee, (int) $divisionId, $k, $i, $v ) );
					$n++;
				}
			}
		};
		if ( class_exists( 'FKC_Tx' ) ) { FKC_Tx::executer( $fn ); } else { $fn(); }
		$apres = self::totaux( self::budget( $annee, $divisionId ) );
		FKC_Security::audit( 'analytique_budget_mensuel', 'Budget mensuel ' . $annee . ' · ' . self::nomSection( $divisionId )
			. ' : charges ' . round( $avant['charges'] ) . ' → ' . round( $apres['charges'] ) . ', produits ' . round( $avant['produits'] ) . ' → ' . round( $apres['produits'] ) . '.' );
		return array( true, 'Budget mensuel ' . $annee . ' enregistré (' . self::nomSection( $divisionId ) . ') : charges ' . fkc_money( $apres['charges'] ) . ' F, produits ' . fkc_money( $apres['produits'] ) . ' F.' );
	}

	public static function nomSection( $divisionId ) {
		if ( ! (int) $divisionId ) { return 'Entreprise'; }
		$d = FKC_Division::find( $divisionId );
		return $d ? $d['libelle'] : '#' . (int) $divisionId;
	}

	/** Totaux charges / produits d'une grille. */
	public static function totaux( array $grille ) {
		$t = array( 'charges' => 0.0, 'produits' => 0.0 );
		foreach ( $grille as $k => $mois ) {
			$s = array_sum( (array) $mois );
			if ( '6' === ( (string) $k )[0] ) { $t['charges'] += $s; } else { $t['produits'] += $s; }
		}
		return $t;
	}

	/**
	 * Budget = réalisé de l'exercice précédent, mois pour mois, ajusté de $pct %.
	 * Remplace la grille de la section.
	 */
	public static function copierN1( $annee, $divisionId, $pct = 0.0 ) {
		$prec = (string) ( (int) $annee - 1 );
		$r = self::reel( $prec, $divisionId );
		if ( ! $r ) { return array( false, 'Aucun réalisé sur l\'exercice ' . $prec . ' pour ' . self::nomSection( $divisionId ) . ' : rien à reprendre.' ); }
		$k = 1 + (float) $pct / 100;
		$g = array();
		foreach ( $r as $nat => $mois ) { foreach ( $mois as $i => $v ) { if ( $v > 0 ) { $g[ $nat ][ $i ] = round( $v * $k ); } } }
		list( $ok, $msg ) = self::enregistrer( $annee, $divisionId, $g );
		return array( $ok, $ok ? 'Budget ' . $annee . ' repris du réalisé ' . $prec . ( $pct ? ' (' . ( $pct > 0 ? '+' : '' ) . $pct . ' %)' : '' ) . '. ' . $msg : $msg );
	}

	/**
	 * Saisonnalité N-1 d'une section : [nature => [mois => poids 0..1]], pour
	 * répartir un total annuel comme l'an passé plutôt qu'en douzièmes.
	 */
	public static function saisonnalite( $annee, $divisionId ) {
		$r = self::reel( (string) ( (int) $annee - 1 ), $divisionId );
		$out = array();
		foreach ( $r as $nat => $mois ) {
			$pos = array(); foreach ( $mois as $i => $v ) { if ( $v > 0 ) { $pos[ $i ] = $v; } }
			$s = array_sum( $pos );
			if ( $s <= 0 ) { continue; }
			for ( $i = 1; $i <= 12; $i++ ) { $out[ $nat ][ $i ] = round( ( $pos[ $i ] ?? 0 ) / $s, 6 ); }
		}
		return $out;
	}

	/**
	 * Suivi à fin du mois $jusqua (1..12) : par nature, budget et réel du mois,
	 * cumuls, écart, consommation de l'année. Alerte quand une charge dépasse
	 * son budget cumulé de plus de $seuil %, ou qu'un produit reste en deçà.
	 */
	public static function suivi( $annee, $divisionId, $jusqua, $seuil = 5 ) {
		$jusqua = max( 1, min( 12, (int) $jusqua ) );
		$bud = self::budget( $annee, $divisionId );
		$reel = self::reel( $annee, $divisionId );
		$nat = self::natures();
		$codes = array_unique( array_merge( array_keys( $bud ), array_keys( $reel ) ) );
		sort( $codes, SORT_STRING );
		$lignes = array();
		$tot = array();
		foreach ( array( 'charge', 'produit' ) as $s ) { $tot[ $s ] = array( 'bm' => 0.0, 'rm' => 0.0, 'bc' => 0.0, 'rc' => 0.0, 'ba' => 0.0 ); }
		$serie = array( 'budget_charges' => array_fill( 1, 12, 0.0 ), 'reel_charges' => array_fill( 1, 12, 0.0 ),
			'budget_produits' => array_fill( 1, 12, 0.0 ), 'reel_produits' => array_fill( 1, 12, 0.0 ) );
		foreach ( $codes as $k ) {
			$k = (string) $k;
			if ( ! in_array( $k[0], array( '6', '7' ), true ) ) { continue; }
			$sens = '6' === $k[0] ? 'charge' : 'produit';
			$b = $bud[ $k ] ?? array(); $r = $reel[ $k ] ?? array();
			$bc = 0.0; $rc = 0.0;
			for ( $i = 1; $i <= $jusqua; $i++ ) { $bc += $b[ $i ] ?? 0; $rc += $r[ $i ] ?? 0; }
			$ba = array_sum( $b );
			for ( $i = 1; $i <= 12; $i++ ) {
				$serie[ 'budget_' . $sens . 's' ][ $i ] += $b[ $i ] ?? 0;
				if ( $i <= $jusqua ) { $serie[ 'reel_' . $sens . 's' ][ $i ] += $r[ $i ] ?? 0; }
			}
			$ecart = $rc - $bc;
			$alerte = $bc > 0
				? ( 'charge' === $sens ? $ecart > $bc * $seuil / 100 : -$ecart > $bc * $seuil / 100 )
				: ( 'charge' === $sens && $rc > 0.5 ); // charge engagée sans budget
			$lignes[] = array(
				'nature' => $k, 'libelle' => $nat[ $k ]['libelle'] ?? $k, 'sens' => $sens,
				'budget_mois' => (float) ( $b[ $jusqua ] ?? 0 ), 'reel_mois' => (float) ( $r[ $jusqua ] ?? 0 ),
				'budget_cumul' => $bc, 'reel_cumul' => $rc, 'ecart' => $ecart,
				'ecart_pct' => $bc > 0 ? round( $ecart / $bc * 100, 1 ) : null,
				'budget_annuel' => $ba, 'conso' => $ba > 0 ? round( $rc / $ba * 100 ) : null,
				'alerte' => $alerte, 'sans_budget' => $ba <= 0,
			);
			$t = &$tot[ $sens ];
			$t['bm'] += (float) ( $b[ $jusqua ] ?? 0 ); $t['rm'] += (float) ( $r[ $jusqua ] ?? 0 );
			$t['bc'] += $bc; $t['rc'] += $rc; $t['ba'] += $ba;
			unset( $t );
		}
		return array(
			'lignes' => $lignes, 'totaux' => $tot, 'jusqua' => $jusqua, 'mois' => self::moisExercice( $annee ), 'serie' => $serie,
			'resultat' => array(
				'budget_cumul' => $tot['produit']['bc'] - $tot['charge']['bc'],
				'reel_cumul' => $tot['produit']['rc'] - $tot['charge']['rc'],
				'budget_annuel' => $tot['produit']['ba'] - $tot['charge']['ba'],
			),
			'alertes' => count( array_filter( $lignes, function ( $l ) { return $l['alerte']; } ) ),
			'a_budget' => (bool) $bud,
		);
	}

	/** Mois « en cours » pour le suivi : le dernier mois écoulé de l'exercice (12 s'il est passé). */
	public static function moisCourant( $annee ) {
		$ym = date( 'Y-m' );
		foreach ( self::moisExercice( $annee ) as $i => $m ) { if ( $m === $ym ) { return $i; } }
		$mois = self::moisExercice( $annee );
		return $ym > $mois[12] ? 12 : 1;
	}

	/**
	 * Reporte les totaux annuels (produits, charges) dans le budget annuel de
	 * la division — celui du contrôle budgétaire et des budgets comparatifs —
	 * en gardant sa prévision et sa note.
	 */
	public static function reporterAnnuel( $annee, $divisionId ) {
		if ( ! (int) $divisionId ) { return array( false, 'Le budget annuel se tient par division : choisissez une division.' ); }
		$t = self::totaux( self::budget( $annee, $divisionId ) );
		$b = FKC_Budget::find( $divisionId, $annee );
		FKC_Budget::upsert( $divisionId, $annee, $t['produits'], $t['charges'], $b['note'] ?? '', $b['prev_produits'] ?? 0, $b['prev_charges'] ?? 0 );
		return array( true, 'Budget annuel ' . $annee . ' de ' . self::nomSection( $divisionId ) . ' mis à jour : produits ' . fkc_money( $t['produits'] ) . ' F, charges ' . fkc_money( $t['charges'] ) . ' F.' );
	}

	/** CSV du suivi (toutes les natures, mois par mois). */
	public static function csv( $annee, $divisionId ) {
		$mois = self::moisExercice( $annee );
		$bud = self::budget( $annee, $divisionId );
		$reel = self::reel( $annee, $divisionId );
		$nat = self::natures();
		$rows = array(
			array( 'Budget mensuel', FKC_AnaDetail::cellule( self::nomSection( $divisionId ) ), 'Exercice', (string) $annee ),
			array(),
		);
		$tete = array( 'Nature', 'Libellé', 'Série' );
		foreach ( $mois as $m ) { $tete[] = self::libMois( $m ); }
		$tete[] = 'Total';
		$rows[] = $tete;
		$codes = array_unique( array_merge( array_keys( $bud ), array_keys( $reel ) ) );
		sort( $codes, SORT_STRING );
		foreach ( $codes as $k ) {
			foreach ( array( 'Budget' => $bud[ $k ] ?? array(), 'Réel' => $reel[ $k ] ?? array() ) as $lib => $v ) {
				$r = array( (string) $k, FKC_AnaDetail::cellule( $nat[ $k ]['libelle'] ?? $k ), $lib );
				for ( $i = 1; $i <= 12; $i++ ) { $r[] = FKC_AnaDetail::nombre( $v[ $i ] ?? 0 ); }
				$r[] = FKC_AnaDetail::nombre( array_sum( $v ) );
				$rows[] = $r;
			}
		}
		return $rows;
	}
}
