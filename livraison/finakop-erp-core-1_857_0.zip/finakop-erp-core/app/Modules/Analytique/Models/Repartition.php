<?php
/** Répartitions analytiques : clés de ventilation fixe (% saisis) ou dynamique (poids réels d'un axe). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Repartition {

	public static function types() { return array( 'fixe' => 'Fixe (pourcentages saisis)', 'dynamique' => 'Dynamique (poids réels d\'un axe)' ); }

	public static function all() {
		return FKC_DB::q( 'SELECT r.*, a.libelle axe_libelle FROM analytique_repartitions r LEFT JOIN analytique_axes a ON a.id=r.axe_id ORDER BY r.id DESC' )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM analytique_repartitions WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		$r['cles'] = FKC_DB::q( 'SELECT cl.*, v.libelle FROM repartition_cles cl JOIN analytique_valeurs v ON v.id=cl.valeur_id WHERE cl.repartition_id=? ORDER BY cl.id', array( (int) $id ) )->fetchAll();
		return $r;
	}
	public static function codeExists( $code, $exceptId = 0 ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM analytique_repartitions WHERE code=? AND id<>?', array( strtoupper( $code ), (int) $exceptId ) )->fetch();
	}
	public static function create( $d ) {
		FKC_DB::q(
			'INSERT INTO analytique_repartitions(code,libelle,axe_id,type,base_axe_id,actif) VALUES(?,?,?,?,?,1)',
			array( strtoupper( trim( (string) $d['code'] ) ), trim( (string) $d['libelle'] ), (int) $d['axe_id'],
				in_array( $d['type'] ?? 'fixe', array( 'fixe', 'dynamique' ), true ) ? ( $d['type'] ?? 'fixe' ) : 'fixe',
				! empty( $d['base_axe_id'] ) ? (int) $d['base_axe_id'] : null )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}
	/**
	 * Définit la part d'une valeur dans une clé fixe.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UNE PART À 0 % EST UNE DÉCISION, PAS UNE ABSENCE (1.547.0)
	 *
	 * Saisir 0 % effaçait la ligne. C'était compact, et trompeur à deux
	 * titres. D'abord, le tableau des clés ne montrait plus que les valeurs
	 * servies : rien ne distinguait « cette section ne reçoit rien cette
	 * année », qui est un arbitrage, de « on a oublié de la mettre », qui est
	 * un oubli — et c'est exactement ce qu'on veut relire six mois plus tard
	 * devant un contrôleur de gestion. Ensuite, la seule façon de retirer une
	 * valeur d'une clé était de la mettre à 0 : l'utilisateur qui voulait
	 * réellement écrire zéro n'avait aucun moyen de le faire, et celui qui
	 * voulait supprimer devait deviner ce détour.
	 *
	 * Une part à 0 % est donc désormais ENREGISTRÉE et affichée. Le retrait
	 * d'une valeur passe par `removeCle()`, geste explicite avec son propre
	 * bouton. Un pourcentage négatif n'a pas de sens dans une clé de
	 * répartition : il est refusé plutôt que silencieusement ramené à zéro.
	 *
	 * La ventilation, elle, ignore les parts nulles — une part à 0 % ne
	 * produit pas de ligne d'écriture à zéro franc.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function setCle( $repId, $valeurId, $pourcentage ) {
		$pct = (float) $pourcentage;
		if ( $pct < 0 ) {
			return array( false, 'Un pourcentage négatif n\'a pas de sens dans une clé de répartition. '
				. 'Pour retirer une valeur de la clé, utilisez « Retirer ».' );
		}
		if ( $pct > 100 ) {
			return array( false, 'Une part ne peut pas dépasser 100 %.' );
		}
		FKC_DB::q( 'DELETE FROM repartition_cles WHERE repartition_id=? AND valeur_id=?', array( (int) $repId, (int) $valeurId ) );
		FKC_DB::q( 'INSERT INTO repartition_cles(repartition_id,valeur_id,pourcentage) VALUES(?,?,?)', array( (int) $repId, (int) $valeurId, $pct ) );
		return array( true, $pct > 0
			? 'Part fixée à ' . rtrim( rtrim( number_format( $pct, 2, ',', ' ' ), '0' ), ',' ) . ' %.'
			: 'Part fixée à 0 % : la valeur reste déclarée dans la clé, mais ne recevra rien.' );
	}

	/** Retire une valeur de la clé — geste explicite, distinct d'une part à 0 %. */
	public static function removeCle( $repId, $valeurId ) {
		FKC_DB::q( 'DELETE FROM repartition_cles WHERE repartition_id=? AND valeur_id=?', array( (int) $repId, (int) $valeurId ) );
	}
	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM repartition_cles WHERE repartition_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM analytique_repartitions WHERE id=?', array( (int) $id ) );
	}

	/** Somme des pourcentages saisis d'une clé fixe. */
	public static function sommeCles( $repId ) {
		try {
			return round( (float) FKC_DB::q( 'SELECT COALESCE(SUM(pourcentage),0) FROM repartition_cles WHERE repartition_id=?', array( (int) $repId ) )->fetchColumn(), 2 );
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/** Une clé fixe est applicable si elle ventile exactement 100 %, à un centime près. */
	public static function estComplete( $repId ) {
		return abs( self::sommeCles( $repId ) - 100.0 ) <= 0.01;
	}

	/**
	 * Simule la ventilation d'un montant selon la clé.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LA SIMULATION NE CONTRÔLAIT PAS LA SOMME DES CLÉS (1.547.0)
	 *
	 * Une clé à 70 % ventilait 70 % du montant et se taisait sur les 30 %
	 * restants ; une clé à 130 % en ventilait 130 % — dans les deux cas la
	 * simulation s'affichait sans le moindre signal, et l'utilisateur en
	 * déduisait que sa clé était bonne. Le tableau des clés affichait bien un
	 * total en orange, mais rien ne reliait ce total à la ventilation
	 * proposée juste en dessous.
	 *
	 * La simulation renvoie désormais son propre diagnostic. Elle continue de
	 * calculer et d'afficher le détail — on ne cache pas le résultat, on dit
	 * qu'il n'est pas applicable — et c'est `Posting::ventiler()` qui refuse
	 * d'appliquer une clé incomplète à une écriture réelle.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @return array{lignes:array,type:string,total_pct:float,complete:bool,ventile:float,message:?string}
	 */
	public static function simuler( $repId, $montant, $annee = '' ) {
		$vide = array( 'lignes' => array(), 'type' => 'fixe', 'total_pct' => 0.0, 'complete' => false, 'ventile' => 0.0, 'message' => 'Répartition introuvable.' );
		$r = self::find( $repId );
		if ( ! $r ) { return $vide; }
		$montant = (float) $montant;
		$out = array();
		$message = null;
		$type = (string) $r['type'];

		if ( 'dynamique' === $type ) {
			/*
			 * Même calcul que l'application réelle (1.823.0) : ce qu'on simule
			 * est exactement ce qui sera posé sur les lignes. Poids lus sur les
			 * imputations DIRECTES de l'axe de base, valeurs actives seules.
			 */
			$an = '' !== (string) $annee ? (string) $annee : ( class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::courant() : date( 'Y' ) );
			list( $ok, $msgCle, $axeId, $parts ) = FKC_Ventilation::partsCle( $repId, $an );
			$estDiv = $axeId === FKC_Ventilation::axeDivision();
			foreach ( $parts as $v => $pc ) {
				$lib = $estDiv ? ( FKC_Division::find( $v )['libelle'] ?? '#' . $v ) : ( FKC_Valeur::find( $v )['libelle'] ?? '#' . $v );
				$out[] = array( 'valeur_id' => (int) $v, 'libelle' => $lib, 'pourcentage' => round( $pc, 2 ), 'montant' => round( $montant * $pc / 100 ) );
			}
			$complete = $ok && ! empty( $out );
			$total    = $complete ? 100.0 : 0.0;
			if ( ! $complete ) {
				$message = $msgCle ?: 'L\'axe de base ne porte aucun mouvement sur cet exercice : la clé ne peut rien pondérer.';
			}
		} else {
			foreach ( $r['cles'] as $cl ) { $out[] = array( 'valeur_id' => (int) $cl['valeur_id'], 'libelle' => $cl['libelle'], 'pourcentage' => (float) $cl['pourcentage'], 'montant' => round( $montant * (float) $cl['pourcentage'] / 100 ) ); }
			$total    = self::sommeCles( $repId );
			$complete = abs( $total - 100.0 ) <= 0.01;
			if ( ! $out ) {
				$message = 'Aucune clé saisie : cette répartition ne ventile rien.';
			} elseif ( ! $complete ) {
				$ecart = round( 100.0 - $total, 2 );
				$message = 'Clé inapplicable : les pourcentages totalisent ' . $total . ' % ('
					. ( $ecart > 0 ? 'il manque ' . $ecart : 'excédent de ' . abs( $ecart ) ) . ' points). '
					. 'Tant que la somme ne fait pas 100 %, la ventilation automatique des écritures est refusée.';
			}
		}

		$ventile = 0.0;
		foreach ( $out as $o ) { $ventile += (float) $o['montant']; }
		return array(
			'lignes' => $out, 'type' => $type, 'total_pct' => (float) $total,
			'complete' => (bool) $complete, 'ventile' => $ventile, 'message' => $message,
		);
	}
}
