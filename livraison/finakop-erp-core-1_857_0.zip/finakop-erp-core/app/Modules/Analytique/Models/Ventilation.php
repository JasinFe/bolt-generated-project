<?php
/**
 * VENTILATION ANALYTIQUE D'UNE LIGNE EN POURCENTAGES (1.823.0).
 *
 * Jusqu'ici une ligne ne pouvait porter qu'UNE valeur par axe : un loyer
 * commun à trois agences allait à l'une d'elles, ou restait « non imputé ».
 * Les clés de répartition existaient, mais ne s'appliquaient qu'aux écritures
 * générées par un schéma qui les déclarait — jamais à une ligne déjà passée.
 *
 * Une ventilation répartit une ligne entre plusieurs valeurs d'un même axe
 * (60 % Abidjan, 40 % Bouaké). Elle vit HORS du grand livre : la ligne
 * comptable n'est ni éclatée ni modifiée, ce qui permet de ventiler une
 * écriture validée sans y toucher.
 *
 * Règles :
 *  - sur un axe donné, une ligne porte SOIT une valeur unique (affectation),
 *    SOIT une ventilation — poser l'une retire l'autre, jamais les deux
 *    (sinon le montant serait compté deux fois) ;
 *  - les parts totalisent exactement 100 % : le montant ventilé égale le
 *    montant de la ligne, rien ne se perd ni ne se crée ;
 *  - une ligne d'exercice clôturé est figée, comme pour les affectations ;
 *  - une clé fixe applique ses pourcentages ; une clé dynamique les calcule
 *    sur les poids réels de l'axe à la date d'application, et se
 *    RÉAPPLIQUE quand ces poids ont bougé.
 *
 * L'axe Division garde ses valeurs dans `divisions` : pour lui, valeur_id
 * est un id de division, comme partout ailleurs dans le module.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Ventilation {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS ligne_ventilations(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					ecriture_ligne_id INTEGER NOT NULL,
					axe_id INTEGER NOT NULL,
					valeur_id INTEGER NOT NULL,
					pourcentage REAL NOT NULL,
					repartition_id INTEGER,
					created_at TEXT DEFAULT(datetime('now','localtime')),
					UNIQUE(ecriture_ligne_id, axe_id, valeur_id)
				);
				CREATE INDEX IF NOT EXISTS idx_vent_ligne ON ligne_ventilations(ecriture_ligne_id);
				CREATE INDEX IF NOT EXISTS idx_vent_axe ON ligne_ventilations(axe_id, valeur_id);
				CREATE INDEX IF NOT EXISTS idx_vent_rep ON ligne_ventilations(repartition_id);
			" );
		} catch ( \Throwable $e ) { self::$ready = false; }
	}

	/** Réinitialise la mémoïsation (changement de société, tests). */
	public static function reset() { self::$ready = false; }

	protected static function divAxe() {
		try { return (int) FKC_DB::q( "SELECT id FROM analytique_axes WHERE code='DIV'" )->fetchColumn(); }
		catch ( \Throwable $e ) { return 0; }
	}

	/* ── Lecture ──────────────────────────────────────────────────────── */

	/** Ventilations d'une ligne : [axe_id => [valeur_id => ['pourcentage'=>, 'repartition_id'=>]]]. */
	public static function pourLigne( $ligneId ) {
		$m = self::pourLignes( array( (int) $ligneId ) );
		return $m[ (int) $ligneId ] ?? array();
	}

	/** Idem pour un lot de lignes : [ligne_id => [axe_id => [valeur_id => …]]]. */
	public static function pourLignes( array $ids ) {
		self::ensure();
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		if ( ! $ids ) { return array(); }
		$out = array();
		try {
			$ph = implode( ',', array_fill( 0, count( $ids ), '?' ) );
			foreach ( FKC_DB::q( "SELECT * FROM ligne_ventilations WHERE ecriture_ligne_id IN ($ph) ORDER BY pourcentage DESC, id", $ids )->fetchAll() as $r ) {
				$out[ (int) $r['ecriture_ligne_id'] ][ (int) $r['axe_id'] ][ (int) $r['valeur_id'] ] = array(
					'pourcentage' => (float) $r['pourcentage'],
					'repartition_id' => null !== $r['repartition_id'] ? (int) $r['repartition_id'] : null,
				);
			}
		} catch ( \Throwable $e ) { /* table absente */ }
		return $out;
	}

	/** Forme compacte pour une reprise (contre-passation) : [axe_id => [valeur_id => pct]]. */
	public static function compact( $ligneId ) {
		$out = array();
		foreach ( self::pourLigne( $ligneId ) as $axe => $parts ) {
			foreach ( $parts as $v => $p ) { $out[ $axe ][ $v ] = $p['pourcentage']; }
		}
		return $out;
	}

	/**
	 * Montants ventilés d'un axe sur une période, par valeur : [valeur_id => produits/charges/hao].
	 *
	 * Deux garde-fous contre le double compte, au cas où une base ancienne
	 * porterait à la fois une affectation et une ventilation sur le même axe :
	 * la ligne n'est prise en ventilation que si elle n'a pas d'affectation
	 * directe sur cet axe (colonne division_id pour DIV).
	 */
	public static function montantsAxe( $axeId, $annee = '' ) {
		self::ensure();
		$axeId = (int) $axeId;
		$estDiv = $axeId === self::divAxe();
		$params = array( $axeId );
		$f = FKC_Division::filtrePeriode( $annee, $params );
		$garde = $estDiv ? ' AND el.division_id IS NULL '
			: ' AND NOT EXISTS ( SELECT 1 FROM ligne_affectations la WHERE la.ecriture_ligne_id = el.id AND la.axe_id = lv.axe_id ) ';
		$out = array();
		try {
			foreach ( FKC_DB::q(
				"SELECT lv.valeur_id v, " . FKC_Division::sqlBlocs( 'el', 'c', 'lv.pourcentage / 100.0' ) . "
				 FROM ligne_ventilations lv
				 JOIN ecriture_lignes el ON el.id = lv.ecriture_ligne_id
				 JOIN ecritures e ON e.id = el.ecriture_id
				 JOIN comptes c ON c.id = el.compte_id
				 WHERE lv.axe_id = ? AND " . FKC_Division::sqlGestion() . " {$f} {$garde}
				 GROUP BY lv.valeur_id",
				$params
			)->fetchAll() as $r ) {
				$out[ (int) $r['v'] ] = array( 'produits' => (float) $r['produits'], 'charges' => (float) $r['charges'], 'hao' => (float) $r['hao'] );
			}
		} catch ( \Throwable $e ) { /* table absente */ }
		return $out;
	}

	/** Fragment SQL : « la ligne el n'est ventilée sur aucun axe ». */
	public static function sqlNonVentilee( $alias = 'el' ) {
		self::ensure();
		return " NOT EXISTS ( SELECT 1 FROM ligne_ventilations lv WHERE lv.ecriture_ligne_id = {$alias}.id ) ";
	}

	/* ── Contrôle ─────────────────────────────────────────────────────── */

	/** Une valeur est-elle choisissable sur cet axe ? (division active pour DIV) */
	public static function valeurValide( $axeId, $valeurId ) {
		$axe = FKC_Axe::find( $axeId );
		if ( ! $axe ) { return false; }
		if ( 'DIV' === $axe['code'] ) {
			return (bool) FKC_DB::q( 'SELECT 1 FROM divisions WHERE id=? AND actif=1', array( (int) $valeurId ) )->fetchColumn();
		}
		return (bool) FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE id=? AND axe_id=? AND actif=1', array( (int) $valeurId, (int) $axeId ) )->fetchColumn();
	}

	/**
	 * Contrôle un jeu de parts [valeur_id => pourcentage].
	 * @return array{0:bool,1:string,2:array} ok, message, parts nettoyées (> 0).
	 */
	public static function valider( $axeId, array $parts ) {
		$clean = array(); $somme = 0.0;
		foreach ( $parts as $v => $p ) {
			$v = (int) $v; $p = round( (float) str_replace( ',', '.', (string) $p ), 4 );
			if ( $v <= 0 ) { continue; }
			if ( $p < 0 || $p > 100 ) { return array( false, 'Chaque part doit être comprise entre 0 et 100 %.', array() ); }
			if ( $p <= 0 ) { continue; } // une part nulle ne ventile rien
			if ( ! self::valeurValide( $axeId, $v ) ) {
				return array( false, 'Une des valeurs choisies n\'appartient pas à cet axe, ou elle est désactivée.', array() );
			}
			$clean[ $v ] = ( $clean[ $v ] ?? 0 ) + $p;
			$somme += $p;
		}
		if ( ! $clean ) { return array( false, 'Aucune part saisie.', array() ); }
		if ( abs( $somme - 100.0 ) > 0.01 ) {
			$e = round( 100.0 - $somme, 2 );
			return array( false, 'Les parts totalisent ' . round( $somme, 2 ) . ' % : ' . ( $e > 0 ? 'il manque ' . $e : 'excédent de ' . abs( $e ) ) . ' point(s). Une ventilation doit faire exactement 100 %.', array() );
		}
		// Le centième d'arrondi va à la plus grosse part : total exact.
		if ( abs( $somme - 100.0 ) > 0.00001 ) {
			arsort( $clean ); $k = array_key_first( $clean ); $clean[ $k ] = round( $clean[ $k ] + ( 100.0 - $somme ), 4 );
		}
		return array( true, '', $clean );
	}

	/** Ligne de gestion (6/7/8) existante, avec sa date — ou null. */
	protected static function ligne( $ligneId ) {
		$r = FKC_DB::q(
			'SELECT el.id, el.debit, el.credit, el.division_id, e.date_ecriture, c.numero FROM ecriture_lignes el
			 JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
			 WHERE el.id=? AND ' . FKC_Division::sqlGestion(),
			array( (int) $ligneId )
		)->fetch();
		return $r ?: null;
	}

	/* ── Écriture ─────────────────────────────────────────────────────── */

	/**
	 * Ventile une ligne sur un axe. Remplace toute affectation ou ventilation
	 * existante SUR CET AXE (les autres axes ne bougent pas).
	 *
	 * Une seule part à 100 % n'est pas une ventilation : c'est une
	 * affectation, et elle est enregistrée comme telle.
	 *
	 * @param array $opts 'repartition_id' => clé d'origine ; 'audit' => false pour un lot (tracé par l'appelant).
	 * @return array{0:bool,1:string}
	 */
	public static function definir( $ligneId, $axeId, array $parts, array $opts = array() ) {
		self::ensure();
		$ligneId = (int) $ligneId; $axeId = (int) $axeId;
		$l = self::ligne( $ligneId );
		if ( ! $l ) { return array( false, 'Ligne introuvable ou hors classes 6/7/8.' ); }
		if ( ! FKC_Axe::find( $axeId ) ) { return array( false, 'Axe inconnu.' ); }
		if ( FKC_Affectation::estVerrouillee( $l['date_ecriture'] ) ) {
			return array( false, 'Exercice clôturé : la ventilation de cette ligne est figée.' );
		}
		list( $ok, $msg, $clean ) = self::valider( $axeId, $parts );
		if ( ! $ok ) { return array( false, $msg ); }

		$avant = self::pourLigne( $ligneId )[ $axeId ] ?? array();
		$rep = ! empty( $opts['repartition_id'] ) ? (int) $opts['repartition_id'] : null;
		$fn = function () use ( $ligneId, $axeId, $clean, $rep ) {
			FKC_DB::q( 'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id=? AND axe_id=?', array( $ligneId, $axeId ) );
			if ( 1 === count( $clean ) ) {
				// 100 % sur une seule valeur : c'est une affectation.
				FKC_Affectation::setForLigne( $ligneId, array( $axeId => (int) array_key_first( $clean ) ) );
				return;
			}
			FKC_Affectation::setForLigne( $ligneId, array( $axeId => 0 ) ); // retire l'affectation unique de l'axe
			foreach ( $clean as $v => $p ) {
				FKC_DB::q( 'INSERT INTO ligne_ventilations(ecriture_ligne_id,axe_id,valeur_id,pourcentage,repartition_id) VALUES(?,?,?,?,?)',
					array( $ligneId, $axeId, (int) $v, (float) $p, $rep ) );
			}
		};
		if ( class_exists( 'FKC_Tx' ) ) { FKC_Tx::executer( $fn ); } else { $fn(); }

		if ( ! isset( $opts['audit'] ) || $opts['audit'] ) {
			FKC_Security::audit( 'analytique_ventilation', self::trace( $ligneId, $axeId, $avant, $clean, $rep ) );
		}
		return array( true, 1 === count( $clean ) ? 'Une seule valeur à 100 % : enregistrée comme une affectation simple.' : 'Ventilation enregistrée : ' . count( $clean ) . ' parts.' );
	}

	/** Retire la ventilation d'une ligne sur un axe : la ligne redevient non affectée sur cet axe. */
	public static function retirer( $ligneId, $axeId ) {
		self::ensure();
		$l = self::ligne( $ligneId );
		if ( ! $l ) { return array( false, 'Ligne introuvable.' ); }
		if ( FKC_Affectation::estVerrouillee( $l['date_ecriture'] ) ) {
			return array( false, 'Exercice clôturé : la ventilation de cette ligne est figée.' );
		}
		$avant = self::pourLigne( $ligneId )[ (int) $axeId ] ?? array();
		if ( ! $avant ) { return array( true, 'Rien à retirer.' ); }
		FKC_DB::q( 'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id=? AND axe_id=?', array( (int) $ligneId, (int) $axeId ) );
		FKC_Security::audit( 'analytique_ventilation', self::trace( $ligneId, $axeId, $avant, array(), null ) );
		return array( true, 'Ventilation retirée : la ligne n\'est plus imputée sur cet axe.' );
	}

	/** Appelé quand une affectation unique est posée sur un axe : la ventilation de cet axe cède. */
	public static function effacerAxe( $ligneId, $axeId ) {
		self::ensure();
		try { FKC_DB::q( 'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id=? AND axe_id=?', array( (int) $ligneId, (int) $axeId ) ); }
		catch ( \Throwable $e ) { /* table absente */ }
	}

	/**
	 * Reprise d'une ventilation compacte [axe => [valeur => pct]] sur une ligne
	 * neuve (contre-passation, validation du journal temporaire). Sans contrôle
	 * de verrou : la ligne vient d'être créée dans une période ouverte.
	 */
	public static function reprendre( $ligneId, array $vent ) {
		self::ensure();
		foreach ( $vent as $axeId => $parts ) {
			if ( ! is_array( $parts ) || count( $parts ) < 2 ) { continue; }
			foreach ( $parts as $v => $p ) {
				if ( (int) $v > 0 && (float) $p > 0 ) {
					FKC_DB::q( 'INSERT OR IGNORE INTO ligne_ventilations(ecriture_ligne_id,axe_id,valeur_id,pourcentage) VALUES(?,?,?,?)',
						array( (int) $ligneId, (int) $axeId, (int) $v, (float) $p ) );
				}
			}
		}
	}

	protected static function trace( $ligneId, $axeId, array $avant, array $apres, $rep ) {
		$fmt = function ( $parts ) {
			$s = array();
			foreach ( $parts as $v => $p ) { $s[] = $v . ':' . rtrim( rtrim( number_format( is_array( $p ) ? $p['pourcentage'] : $p, 2, '.', '' ), '0' ), '.' ) . '%'; }
			return $s ? implode( ' ', $s ) : '—';
		};
		$a = FKC_Axe::find( $axeId );
		return 'Ligne #' . (int) $ligneId . ' · axe ' . ( $a['code'] ?? $axeId ) . ' : ' . $fmt( $avant ) . ' → ' . $fmt( $apres )
			. ( $rep ? ' (clé #' . (int) $rep . ')' : '' );
	}

	/* ── Clés de répartition appliquées ───────────────────────────────── */

	/**
	 * Parts d'une clé pour un exercice donné.
	 *
	 * Clé FIXE : ses pourcentages, sur son axe (pour l'axe Division, les
	 * valeurs de la clé sont traduites en divisions).
	 * Clé DYNAMIQUE : les poids réels (|produits| + |charges|) des valeurs de
	 * l'axe de base, lus sur les SEULES imputations directes — une ligne déjà
	 * ventilée ne pèse pas dans le calcul de sa propre clé.
	 *
	 * @return array{0:bool,1:string,2:int,3:array} ok, message, axe_id, [valeur_id => pct]
	 */
	public static function partsCle( $repId, $annee ) {
		$r = FKC_Repartition::find( $repId );
		if ( ! $r ) { return array( false, 'Répartition introuvable.', 0, array() ); }
		if ( empty( $r['actif'] ) ) { return array( false, 'Cette répartition est désactivée.', 0, array() ); }

		if ( 'dynamique' === $r['type'] ) {
			$axeId = (int) ( $r['base_axe_id'] ?: $r['axe_id'] );
			$poids = self::poidsDirects( $axeId, $annee );
			$somme = array_sum( $poids );
			if ( $somme <= 0 ) {
				return array( false, 'Clé « ' . $r['code'] . ' » : l\'axe de base ne porte aucune imputation directe sur l\'exercice ' . $annee . ', rien à pondérer.', $axeId, array() );
			}
			$parts = array();
			foreach ( $poids as $v => $w ) { $parts[ $v ] = round( $w / $somme * 100, 4 ); }
			arsort( $parts ); $k = array_key_first( $parts ); $parts[ $k ] = round( $parts[ $k ] + ( 100.0 - array_sum( $parts ) ), 4 );
			return array( true, '', $axeId, $parts );
		}

		$axeId = (int) $r['axe_id'];
		$estDiv = $axeId === self::divAxe();
		$parts = array();
		foreach ( $r['cles'] as $cl ) {
			if ( (float) $cl['pourcentage'] <= 0 ) { continue; }
			$v = (int) $cl['valeur_id'];
			if ( $estDiv ) {
				$v = (int) FKC_DB::q( "SELECT source_id FROM analytique_valeurs WHERE id=? AND source_type='division'", array( $v ) )->fetchColumn();
				if ( ! $v ) { return array( false, 'Clé « ' . $r['code'] . ' » : une valeur ne correspond à aucune division.', $axeId, array() ); }
			}
			$parts[ $v ] = ( $parts[ $v ] ?? 0 ) + (float) $cl['pourcentage'];
		}
		if ( ! $parts ) { return array( false, 'Clé « ' . $r['code'] . ' » : aucune part saisie.', $axeId, array() ); }
		if ( abs( array_sum( $parts ) - 100.0 ) > 0.01 ) {
			return array( false, 'Clé « ' . $r['code'] . ' » inapplicable : ses parts totalisent ' . round( array_sum( $parts ), 2 ) . ' % au lieu de 100 %.', $axeId, array() );
		}
		return array( true, '', $axeId, $parts );
	}

	/** Poids |produits|+|charges| par valeur d'un axe, imputations directes seulement. */
	public static function poidsDirects( $axeId, $annee ) {
		$params = array();
		$f = FKC_Division::filtrePeriode( $annee, $params );
		$estDiv = (int) $axeId === self::divAxe();
		$sql = $estDiv
			? "SELECT el.division_id v, " . FKC_Division::sqlBlocs() . " FROM ecriture_lignes el
			   JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
			   WHERE el.division_id IS NOT NULL AND ( c.numero LIKE '6%' OR c.numero LIKE '7%' ) {$f}
			   GROUP BY el.division_id"
			: "SELECT la.valeur_id v, " . FKC_Division::sqlBlocs() . " FROM ligne_affectations la
			   JOIN ecriture_lignes el ON el.id = la.ecriture_ligne_id
			   JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id
			   WHERE la.axe_id = " . (int) $axeId . " AND ( c.numero LIKE '6%' OR c.numero LIKE '7%' ) {$f}
			   GROUP BY la.valeur_id";
		$out = array();
		try {
			foreach ( FKC_DB::q( $sql, $params )->fetchAll() as $r ) {
				$w = abs( (float) $r['produits'] ) + abs( (float) $r['charges'] );
				// Seules les valeurs encore actives reçoivent une part.
				if ( $w > 0 && self::valeurValide( $axeId, (int) $r['v'] ) ) { $out[ (int) $r['v'] ] = $w; }
			}
		} catch ( \Throwable $e ) { /* base partielle */ }
		return $out;
	}

	/**
	 * Applique une clé à des lignes existantes.
	 * Une clé dynamique est calculée PAR EXERCICE : chaque ligne reçoit les
	 * poids de l'exercice auquel elle appartient.
	 *
	 * @return array{appliquees:int, refus:array}
	 */
	public static function appliquerCle( $repId, array $ligneIds ) {
		self::ensure();
		$out = array( 'appliquees' => 0, 'refus' => array() );
		$cache = array();
		$trace = array();
		foreach ( array_unique( array_map( 'intval', $ligneIds ) ) as $lid ) {
			if ( $lid <= 0 ) { continue; }
			$l = self::ligne( $lid );
			if ( ! $l ) { $out['refus'][] = 'Ligne #' . $lid . ' : introuvable ou hors classes 6/7/8.'; continue; }
			$an = class_exists( 'FKC_Exercice' ) ? (string) FKC_Exercice::annee( $l['date_ecriture'] ) : substr( $l['date_ecriture'], 0, 4 );
			if ( ! isset( $cache[ $an ] ) ) { $cache[ $an ] = self::partsCle( $repId, $an ); }
			list( $ok, $msg, $axeId, $parts ) = $cache[ $an ];
			if ( ! $ok ) { $out['refus'][] = $msg; continue; }
			list( $ok2, $msg2 ) = self::definir( $lid, $axeId, $parts, array( 'repartition_id' => $repId, 'audit' => false ) );
			if ( ! $ok2 ) { $out['refus'][] = 'Ligne #' . $lid . ' : ' . $msg2; continue; }
			$out['appliquees']++;
			$trace[] = '#' . $lid;
		}
		$out['refus'] = array_values( array_unique( $out['refus'] ) );
		if ( $trace ) {
			$r = FKC_Repartition::find( $repId );
			FKC_Security::audit( 'analytique_ventilation', 'Clé « ' . ( $r['code'] ?? $repId ) . ' » appliquée à ' . count( $trace ) . ' ligne(s) : '
				. mb_strimwidth( implode( ' ', $trace ), 0, 1800, '…' ) );
		}
		return $out;
	}

	/** Lignes ventilées par une clé (hors exercices clôturés si $ouvertesSeules). */
	public static function lignesDeCle( $repId, $ouvertesSeules = false ) {
		self::ensure();
		$rows = FKC_DB::q(
			'SELECT DISTINCT lv.ecriture_ligne_id id, e.date_ecriture FROM ligne_ventilations lv
			 JOIN ecriture_lignes el ON el.id = lv.ecriture_ligne_id JOIN ecritures e ON e.id = el.ecriture_id
			 WHERE lv.repartition_id=?',
			array( (int) $repId )
		)->fetchAll();
		$ids = array();
		foreach ( $rows as $r ) {
			if ( $ouvertesSeules && FKC_Affectation::estVerrouillee( $r['date_ecriture'] ) ) { continue; }
			$ids[] = (int) $r['id'];
		}
		return $ids;
	}

	/** Nombre de lignes ventilées par clé : [repartition_id => [total, figees]]. */
	public static function usageCles() {
		self::ensure();
		$out = array();
		try {
			foreach ( FKC_DB::q( 'SELECT lv.repartition_id r, lv.ecriture_ligne_id l, MIN(e.date_ecriture) d FROM ligne_ventilations lv
				JOIN ecriture_lignes el ON el.id = lv.ecriture_ligne_id JOIN ecritures e ON e.id = el.ecriture_id
				WHERE lv.repartition_id IS NOT NULL GROUP BY lv.repartition_id, lv.ecriture_ligne_id' )->fetchAll() as $r ) {
				$k = (int) $r['r'];
				if ( ! isset( $out[ $k ] ) ) { $out[ $k ] = array( 'total' => 0, 'figees' => 0 ); }
				$out[ $k ]['total']++;
				if ( FKC_Affectation::estVerrouillee( $r['d'] ) ) { $out[ $k ]['figees']++; }
			}
		} catch ( \Throwable $e ) { /* table absente */ }
		return $out;
	}

	/**
	 * Réapplique une clé à toutes les lignes qu'elle ventile (exercices
	 * ouverts). Indispensable pour une clé dynamique : appliquée en mars,
	 * elle portait les poids de mars ; en décembre, les poids ont changé.
	 * Utile aussi pour une clé fixe dont on a modifié les pourcentages.
	 */
	public static function reappliquerCle( $repId ) {
		return self::appliquerCle( $repId, self::lignesDeCle( $repId, true ) );
	}

	/* ── Entretien ────────────────────────────────────────────────────── */

	/** Retire les ventilations orphelines. @return int */
	public static function purgerOrphelins() {
		self::ensure();
		$n = 0;
		$div = self::divAxe();
		foreach ( array(
			'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id NOT IN (SELECT id FROM ecriture_lignes)',
			'DELETE FROM ligne_ventilations WHERE axe_id NOT IN (SELECT id FROM analytique_axes)',
			'DELETE FROM ligne_ventilations WHERE axe_id <> ' . (int) $div . ' AND valeur_id NOT IN (SELECT id FROM analytique_valeurs)',
			'DELETE FROM ligne_ventilations WHERE axe_id = ' . (int) $div . ' AND valeur_id NOT IN (SELECT id FROM divisions)',
		) as $sql ) {
			try { $n += (int) FKC_DB::q( $sql )->rowCount(); } catch ( \Throwable $e ) { /* */ }
		}
		return $n;
	}

	/** Comptage pour les impacts (axe, valeur, division). */
	public static function compter( $col, $id, $axeId = null ) {
		self::ensure();
		try {
			if ( null !== $axeId ) {
				return (int) FKC_DB::q( "SELECT COUNT(DISTINCT ecriture_ligne_id) FROM ligne_ventilations WHERE {$col}=? AND axe_id=?", array( (int) $id, (int) $axeId ) )->fetchColumn();
			}
			return (int) FKC_DB::q( "SELECT COUNT(DISTINCT ecriture_ligne_id) FROM ligne_ventilations WHERE {$col}=?", array( (int) $id ) )->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/** Suppression en cascade (axe, valeur, division). */
	public static function supprimerPour( $col, $id, $axeId = null ) {
		self::ensure();
		try {
			if ( null !== $axeId ) {
				FKC_DB::q( "DELETE FROM ligne_ventilations WHERE {$col}=? AND axe_id=?", array( (int) $id, (int) $axeId ) );
			} else {
				FKC_DB::q( "DELETE FROM ligne_ventilations WHERE {$col}=?", array( (int) $id ) );
			}
		} catch ( \Throwable $e ) { /* table absente */ }
	}

	/** Axe Division (id) — exposé pour les appelants. */
	public static function axeDivision() { return self::divAxe(); }
}
