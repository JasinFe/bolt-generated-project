<?php
/** Axes analytiques (analyse multi-axes : Division, Projet, Activité, Région…). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Axe {

	public static function all( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE actif=1' : '';
		return FKC_DB::q( "SELECT * FROM analytique_axes{$w} ORDER BY ordre, libelle COLLATE NOCASE" )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM analytique_axes WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function map() {
		$m = array();
		foreach ( self::all() as $a ) { $m[ (int) $a['id'] ] = $a['libelle']; }
		return $m;
	}
	public static function codeExists( $code, $exceptId = 0 ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM analytique_axes WHERE code=? AND id<>?', array( strtoupper( $code ), (int) $exceptId ) )->fetch();
	}
	public static function create( $d ) {
		FKC_DB::q(
			'INSERT INTO analytique_axes(code,libelle,actif,ordre) VALUES(?,?,?,?)',
			array( strtoupper( trim( (string) $d['code'] ) ), trim( (string) $d['libelle'] ), empty( $d['actif'] ) ? 0 : 1, (int) ( $d['ordre'] ?? 0 ) )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		FKC_DB::q(
			'UPDATE analytique_axes SET code=?, libelle=?, actif=?, ordre=? WHERE id=?',
			array( strtoupper( trim( (string) $d['code'] ) ), trim( (string) $d['libelle'] ), empty( $d['actif'] ) ? 0 : 1, (int) ( $d['ordre'] ?? 0 ), (int) $id )
		);
	}
	/** Ce qu'un axe entraîne dans sa suppression. Calculé avant d'agir. */
	public static function impact( $id ) {
		$id = (int) $id;
		$n  = function ( $sql, $args ) {
			try { return (int) FKC_DB::q( $sql, $args )->fetchColumn(); } catch ( \Throwable $e ) { return 0; }
		};
		return array(
			'valeurs'      => $n( 'SELECT COUNT(*) FROM analytique_valeurs WHERE axe_id=?', array( $id ) ),
			'affectations' => $n( 'SELECT COUNT(*) FROM ligne_affectations WHERE axe_id=?', array( $id ) )
				+ ( class_exists( 'FKC_Ventilation' ) ? FKC_Ventilation::compter( 'axe_id', $id ) : 0 ),
			'budgets'      => $n( 'SELECT COUNT(*) FROM budgets_axes WHERE axe_id=?', array( $id ) ),
			'repartitions' => $n( 'SELECT COUNT(*) FROM analytique_repartitions WHERE axe_id=?', array( $id ) ),
			'divisions'    => $n( 'SELECT COUNT(*) FROM divisions WHERE axe_id=?', array( $id ) ),
			'bases'        => $n( 'SELECT COUNT(*) FROM analytique_repartitions WHERE base_axe_id=?', array( $id ) ),
		);
	}

	/**
	 * Supprime un axe et TOUT ce qui n'a plus de sens sans lui. L'axe DIV est
	 * protégé (il porte le référentiel des divisions).
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LA SUPPRESSION LAISSAIT QUATRE TABLES ORPHELINES (1.547.0)
	 *
	 * Seuls `divisions.axe_id` et `analytique_valeurs` étaient traités.
	 * Survivaient à l'axe : ses affectations de lignes, ses budgets par
	 * valeur, les clés de répartition qui le visaient, et les répartitions
	 * dynamiques qui s'en servaient comme axe de BASE. Ces dernières étaient
	 * les plus nuisibles : `Repartition::simuler()` interrogeait un axe
	 * inexistant, ne trouvait aucun poids, et ventilait 0 % partout sans rien
	 * dire — une charge commune cessait silencieusement d'être répartie.
	 *
	 * Une répartition dont l'axe CIBLE disparaît n'a plus d'objet : elle est
	 * supprimée avec ses clés. Une répartition dont seul l'axe de BASE
	 * disparaît garde son objet : elle repasse en type « fixe », base vidée —
	 * l'utilisateur retrouve une clé à re-paramétrer, pas une clé muette.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @return array|false Compte de ce qui a été retiré, ou false si refusé.
	 */
	public static function delete( $id ) {
		$id = (int) $id;
		$a  = self::find( $id );
		if ( ! $a || 'DIV' === $a['code'] ) { return false; }
		$imp = self::impact( $id );

		$run = function ( $sql, $args = array() ) {
			try { FKC_DB::q( $sql, $args ); } catch ( \Throwable $e ) { /* table absente */ }
		};
		$purge = function () use ( $id, $run ) {
			$run( 'UPDATE divisions SET axe_id=NULL WHERE axe_id=?', array( $id ) );
			// Répartitions dont l'axe est la CIBLE : sans objet, avec leurs clés.
			$run( 'DELETE FROM repartition_cles WHERE repartition_id IN (SELECT id FROM analytique_repartitions WHERE axe_id=?)', array( $id ) );
			$run( 'DELETE FROM analytique_repartitions WHERE axe_id=?', array( $id ) );
			// Répartitions dont l'axe n'était que la BASE : elles redeviennent fixes.
			$run( "UPDATE analytique_repartitions SET base_axe_id=NULL, type='fixe' WHERE base_axe_id=?", array( $id ) );
			// Clés pointant une valeur de l'axe (cas d'une clé sur un autre axe mal saisie).
			$run( 'DELETE FROM repartition_cles WHERE valeur_id IN (SELECT id FROM analytique_valeurs WHERE axe_id=?)', array( $id ) );
			$run( 'DELETE FROM budgets_axes WHERE axe_id=?', array( $id ) );
			$run( 'DELETE FROM ligne_affectations WHERE axe_id=?', array( $id ) );
			if ( class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::supprimerPour( 'axe_id', $id ); }
			$run( 'DELETE FROM analytique_valeurs WHERE axe_id=?', array( $id ) );
			$run( 'DELETE FROM analytique_axes WHERE id=?', array( $id ) );
		};
		// Tout ou rien : un axe à demi supprimé serait pire que pas supprimé.
		if ( class_exists( 'FKC_Tx' ) ) {
			try { FKC_Tx::executer( $purge ); } catch ( \Throwable $e ) { return false; }
		} else {
			$purge();
		}
		return $imp;
	}
}
