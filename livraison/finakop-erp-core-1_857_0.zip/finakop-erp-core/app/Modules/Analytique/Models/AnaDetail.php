<?php
/**
 * DÉTAIL D'UN MONTANT ANALYTIQUE ET EXPORTS (1.825.0).
 *
 * « D'où sort ce chiffre ? » — première question devant un résultat par
 * division ou par axe, et jusqu'ici sans réponse à l'écran : il fallait
 * refaire le calcul au grand livre, ligne par ligne, en devinant quelles
 * écritures avaient été imputées où.
 *
 * Le détail liste les lignes d'écriture qui composent le montant d'une
 * valeur (ou du « non imputé ») sur un exercice, avec pour chacune la part
 * retenue : 100 % pour une affectation, la part de ventilation sinon, et
 * pour le non imputé ce qui n'a été ventilé nulle part. La somme des
 * montants imputés égale, au franc près, le chiffre affiché au résultat.
 *
 * Les exports donnent la même chose en CSV (séparateur « ; », UTF-8 avec
 * BOM, lisible tel quel par Excel en français).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaDetail {

	const NATURES = array( 'produit' => 'Produit', 'charge' => 'Charge', 'hao' => 'HAO' );

	/** Filtres optionnels : nature (produit|charge|hao) et mois (AAAA-MM). */
	protected static function filtres( array $opts, array &$params ) {
		$sql = '';
		$n = (string) ( $opts['nature'] ?? '' );
		if ( 'produit' === $n ) { $sql .= " AND c.numero LIKE '7%' "; }
		elseif ( 'charge' === $n ) { $sql .= " AND c.numero LIKE '6%' "; }
		elseif ( 'hao' === $n ) { $sql .= " AND c.numero LIKE '8%' "; }
		if ( ! empty( $opts['mois'] ) && preg_match( '/^\d{4}-\d{2}$/', (string) $opts['mois'] ) ) {
			$sql .= ' AND substr(e.date_ecriture,1,7) = ? ';
			$params[] = (string) $opts['mois'];
		}
		// Préfixe de compte (1.831.0) : « 62 » = la nature Services extérieurs du budget mensuel.
		if ( ! empty( $opts['compte'] ) && preg_match( '/^[678]\d{0,5}$/', (string) $opts['compte'] ) ) {
			$sql .= ' AND c.numero LIKE ? ';
			$params[] = (string) $opts['compte'] . '%';
		}
		return $sql;
	}

	/** Colonnes communes. */
	protected static function colonnes() {
		return "el.id, e.id ecriture_id, e.date_ecriture, e.piece, e.numero ecriture_numero,
			COALESCE(NULLIF(el.libelle,''), e.libelle) libelle, c.numero, c.libelle compte_libelle, el.debit, el.credit";
	}

	/** Libellé d'une valeur d'axe (0 = non imputé). */
	public static function libelleValeur( array $axe, $valeurId ) {
		$valeurId = (int) $valeurId;
		if ( ! $valeurId ) { return 'DIV' === $axe['code'] ? 'Non imputé' : 'Non affecté'; }
		if ( 'DIV' === $axe['code'] ) { $d = FKC_Division::find( $valeurId ); return $d ? $d['libelle'] : '#' . $valeurId; }
		$v = FKC_Valeur::find( $valeurId );
		return $v ? $v['libelle'] : '#' . $valeurId;
	}

	/**
	 * Lignes qui composent le montant d'une valeur sur un exercice.
	 *
	 * @param int   $valeurId 0 = non imputé / non affecté.
	 * @param array $opts     'nature', 'mois', 'limite' (lignes rendues ; les totaux portent toujours sur tout).
	 * @return array{axe:array,valeur:string,lignes:array,nb:int,tronque:bool,totaux:array}
	 */
	public static function lignes( $axeId, $valeurId, $annee, array $opts = array() ) {
		FKC_Ventilation::ensure();
		$axe = FKC_Axe::find( $axeId );
		$vide = array( 'axe' => $axe, 'valeur' => '', 'lignes' => array(), 'nb' => 0, 'tronque' => false,
			'totaux' => array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0, 'resultat' => 0.0, 'resultat_net' => 0.0 ) );
		if ( ! $axe ) { return $vide; }
		$axeId = (int) $axeId; $valeurId = (int) $valeurId;
		$estDiv = 'DIV' === $axe['code'];
		$cols = self::colonnes();
		$base = ' FROM ecriture_lignes el JOIN ecritures e ON e.id = el.ecriture_id JOIN comptes c ON c.id = el.compte_id ';
		$gestion = ' WHERE ' . FKC_Division::sqlGestion();
		$blocs = array(); $params = array();

		$periode = function ( array &$p ) use ( $annee, $opts ) {
			$f = FKC_Division::filtrePeriode( $annee, $p );
			return $f . self::filtres( $opts, $p );
		};

		if ( $valeurId ) {
			// 1. Imputation directe, à 100 %.
			$p = array();
			if ( $estDiv ) {
				$p[] = $valeurId;
				$sql = "SELECT {$cols}, 100.0 part, NULL repartition_id {$base} {$gestion} AND el.division_id = ? " . $periode( $p );
			} else {
				$p[] = $axeId; $p[] = $valeurId;
				$sql = "SELECT {$cols}, 100.0 part, NULL repartition_id {$base}
					JOIN ligne_affectations la ON la.ecriture_ligne_id = el.id AND la.axe_id = ? AND la.valeur_id = ?
					{$gestion} " . $periode( $p );
			}
			$blocs[] = $sql; $params = array_merge( $params, $p );
			// 2. Parts ventilées (même garde-fou contre le double compte que FKC_Ventilation::montantsAxe).
			$p = array( $axeId, $valeurId );
			$garde = $estDiv ? ' AND el.division_id IS NULL '
				: ' AND NOT EXISTS ( SELECT 1 FROM ligne_affectations la WHERE la.ecriture_ligne_id = el.id AND la.axe_id = lv.axe_id ) ';
			$blocs[] = "SELECT {$cols}, lv.pourcentage part, lv.repartition_id {$base}
				JOIN ligne_ventilations lv ON lv.ecriture_ligne_id = el.id AND lv.axe_id = ? AND lv.valeur_id = ?
				{$gestion} {$garde} " . $periode( $p );
			$params = array_merge( $params, $p );
		} else {
			// Non imputé : ce qui reste de chaque ligne une fois retirées ses parts sur l'axe.
			// Les « ? » suivent l'ordre du texte SQL : CASE (axe), somme ventilée (axe), puis la période.
			$ventile = "COALESCE(( SELECT SUM(lv.pourcentage) FROM ligne_ventilations lv WHERE lv.ecriture_ligne_id = el.id AND lv.axe_id = ? ), 0)";
			if ( $estDiv ) {
				$p = array( $axeId );
				$blocs[] = "SELECT * FROM ( SELECT {$cols}, 100.0 - {$ventile} part, NULL repartition_id {$base}
					{$gestion} AND el.division_id IS NULL " . $periode( $p ) . " ) WHERE part > 0.0001";
			} else {
				$p = array( $axeId, $axeId );
				$blocs[] = "SELECT * FROM ( SELECT {$cols},
						CASE WHEN EXISTS ( SELECT 1 FROM ligne_affectations la WHERE la.ecriture_ligne_id = el.id AND la.axe_id = ? ) THEN 0
						     ELSE 100.0 - {$ventile} END part, NULL repartition_id {$base}
					{$gestion} " . $periode( $p ) . " ) WHERE part > 0.0001";
			}
			$params = array_merge( $params, $p );
		}

		$sql = 'SELECT * FROM ( ' . implode( ' UNION ALL ', $blocs ) . ' ) ORDER BY date_ecriture DESC, id DESC';
		$rows = FKC_DB::q( $sql, $params )->fetchAll();

		$tot = array( 'produits' => 0.0, 'charges' => 0.0, 'hao' => 0.0 );
		$out = array();
		foreach ( $rows as $r ) {
			$cl = substr( (string) $r['numero'], 0, 1 );
			$nature = '7' === $cl ? 'produit' : ( '6' === $cl ? 'charge' : 'hao' );
			$signe = 'charge' === $nature ? (float) $r['debit'] - (float) $r['credit'] : (float) $r['credit'] - (float) $r['debit'];
			$part = (float) $r['part'];
			$impute = $signe * $part / 100;
			$tot[ 'produit' === $nature ? 'produits' : ( 'charge' === $nature ? 'charges' : 'hao' ) ] += $impute;
			$r['nature'] = $nature; $r['montant'] = $signe; $r['part'] = $part; $r['impute'] = $impute;
			$out[] = $r;
		}
		$limite = (int) ( $opts['limite'] ?? 0 );
		$nb = count( $out );
		return array(
			'axe' => $axe, 'valeur' => self::libelleValeur( $axe, $valeurId ),
			'lignes' => $limite > 0 ? array_slice( $out, 0, $limite ) : $out,
			'nb' => $nb, 'tronque' => $limite > 0 && $nb > $limite,
			'totaux' => array(
				'produits' => $tot['produits'], 'charges' => $tot['charges'], 'hao' => $tot['hao'],
				'resultat' => $tot['produits'] - $tot['charges'], 'resultat_net' => $tot['produits'] - $tot['charges'] + $tot['hao'],
			),
		);
	}

	/* ── Exports CSV ──────────────────────────────────────────────────── */

	/**
	 * Cellule texte sûre pour un tableur : un libellé qui commence par « = »,
	 * « + », « - » ou « @ » serait exécuté comme une formule à l'ouverture.
	 */
	public static function cellule( $v ) {
		$v = (string) $v;
		return ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) ? "'" . $v : $v;
	}

	/** Montant pour Excel en français : entier arrondi, sans séparateur de milliers. */
	public static function nombre( $v ) {
		return (string) round( (float) $v );
	}

	/** Lignes CSV du détail d'une valeur. */
	public static function csvDetail( $axeId, $valeurId, $annee, array $opts = array() ) {
		return self::csvDepuis( self::lignes( $axeId, $valeurId, $annee, array_diff_key( $opts, array( 'limite' => 1 ) ) ), $annee );
	}

	/** CSV à partir d'un détail déjà calculé (valeur simple ou case d'un tableau croisé). */
	public static function csvDepuis( array $d, $annee ) {
		$axeLib = ( $d['axe']['libelle'] ?? '' ) . ( ! empty( $d['axe2'] ) ? ' × ' . $d['axe2']['libelle'] : '' );
		$rows = array(
			array( 'Axe', self::cellule( $axeLib ), 'Valeur', self::cellule( $d['valeur'] ), 'Exercice', (string) $annee ),
			array(),
			array( 'Date', 'Pièce', 'N° écriture', 'Libellé', 'Compte', 'Intitulé du compte', 'Nature', 'Montant de la ligne', 'Part (%)', 'Montant imputé' ),
		);
		foreach ( $d['lignes'] as $l ) {
			$rows[] = array(
				date( 'd/m/Y', strtotime( $l['date_ecriture'] ) ), self::cellule( $l['piece'] ), self::cellule( $l['ecriture_numero'] ?: $l['ecriture_id'] ),
				self::cellule( $l['libelle'] ), (string) $l['numero'], self::cellule( $l['compte_libelle'] ), self::NATURES[ $l['nature'] ],
				self::nombre( $l['montant'] ), str_replace( '.', ',', (string) round( $l['part'], 4 ) ), self::nombre( $l['impute'] ),
			);
		}
		$t = $d['totaux'];
		$rows[] = array();
		$rows[] = array( 'Total produits', '', '', '', '', '', '', '', '', self::nombre( $t['produits'] ) );
		$rows[] = array( 'Total charges', '', '', '', '', '', '', '', '', self::nombre( $t['charges'] ) );
		if ( abs( $t['hao'] ) >= 0.5 ) { $rows[] = array( 'Total HAO', '', '', '', '', '', '', '', '', self::nombre( $t['hao'] ) ); }
		$rows[] = array( 'Résultat', '', '', '', '', '', '', '', '', self::nombre( abs( $t['hao'] ) >= 0.5 ? $t['resultat_net'] : $t['resultat'] ) );
		return $rows;
	}

	/**
	 * Lignes CSV du résultat d'un axe, tel que l'écran l'affiche (répartition
	 * secondaire comprise quand elle est active).
	 */
	public static function csvResultats( $axeId, $annee ) {
		$axe = FKC_Axe::find( $axeId );
		if ( ! $axe ) { return array( array( 'Axe introuvable' ) ); }
		$res = FKC_Affectation::resultatsParAxe( $axeId, $annee );
		if ( class_exists( 'FKC_AnaAuxiliaire' ) ) { $res = FKC_AnaAuxiliaire::appliquer( $res, $axeId, $annee ); }
		$aux = ! empty( $res['repartition']['active'] );
		$tete = array( 'Code', 'Valeur', 'Produits' );
		if ( $aux ) { $tete[] = 'Charges propres'; $tete[] = 'Déversement'; }
		$tete = array_merge( $tete, array( 'Charges', 'Résultat', 'Marge (%)', 'HAO', 'Résultat net' ) );
		$rows = array(
			array( 'Axe', self::cellule( $axe['libelle'] ), 'Exercice', (string) $annee ),
			array(),
			$tete,
		);
		$ligne = function ( $code, $lib, $l ) use ( $aux ) {
			$p = (float) $l['produits']; $r = (float) $l['resultat'];
			$x = array( self::cellule( $code ), self::cellule( $lib ), self::nombre( $p ) );
			if ( $aux ) {
				$x[] = self::nombre( $l['charges_propres'] ?? $l['charges'] );
				$x[] = self::nombre( (float) ( $l['charges_recues'] ?? 0 ) - (float) ( $l['charges_deversees'] ?? 0 ) );
			}
			return array_merge( $x, array(
				self::nombre( $l['charges'] ), self::nombre( $r ),
				$p > 0 ? str_replace( '.', ',', (string) round( $r / $p * 100, 1 ) ) : '',
				self::nombre( $l['hao'] ?? 0 ), self::nombre( $l['resultat_net'] ?? $r ),
			) );
		};
		foreach ( $res['lignes'] as $l ) { $rows[] = $ligne( $l['code'], $l['libelle'], $l ); }
		$ni = $res['non_affecte'];
		if ( $ni ) { $rows[] = $ligne( '—', 'DIV' === $axe['code'] ? 'Non imputé' : 'Non affecté', $ni ); }
		$rows[] = $ligne( '', 'Total', $res['totaux'] );
		return $rows;
	}

	/** Nom de fichier sans accent ni espace. */
	public static function slug( $s ) {
		$s = strtolower( (string) ( function_exists( 'iconv' ) ? @iconv( 'UTF-8', 'ASCII//TRANSLIT//IGNORE', (string) $s ) : $s ) );
		return trim( preg_replace( '/[^a-z0-9]+/', '-', $s ), '-' ) ?: 'export';
	}
}
