<?php
/**
 * SECTIONS AUXILIAIRES — RÉPARTITION SECONDAIRE DES CHARGES (1.775.0).
 *
 * ── LE BESOIN ────────────────────────────────────────────────────────────
 *
 * Une entreprise a presque toujours au moins une entité qui TRAVAILLE POUR
 * LES AUTRES sans vendre elle-même : le siège, l'administration, la
 * direction générale. Elle porte des salaires, un loyer, de l'électricité,
 * et n'a en face aucun produit.
 *
 * Lue telle quelle, cette entité affiche un résultat massivement négatif —
 * « KOPHI'S GROUP : 0 de produits, 1 104 982 de charges » — et toutes les
 * autres affichent un résultat trop beau, puisqu'elles consomment ce support
 * sans en porter le coût. Aucun des deux chiffres n'est faux
 * comptablement ; les deux sont trompeurs en gestion.
 *
 * La comptabilité analytique règle cela depuis toujours par une RÉPARTITION
 * SECONDAIRE : les charges de la section auxiliaire sont déversées sur les
 * sections principales, selon une clé — effectif, chiffre d'affaires, mètres
 * carrés, ou un pourcentage négocié.
 *
 * ── TROIS PRINCIPES QUI NE SE NÉGOCIENT PAS ──────────────────────────────
 *
 *  1. LA COMPTABILITÉ GÉNÉRALE N'EST PAS TOUCHÉE. Aucune écriture n'est
 *     créée ni modifiée. Le déversement est une lecture de gestion, calculée
 *     à l'affichage. Le grand livre, la balance et les états financiers
 *     restent exactement ce qu'ils étaient — c'est ce qui permet de changer
 *     une clé sans rien contrepasser, et de rendre des comptes sur la
 *     répartition sans rendre des comptes sur les écritures.
 *
 *  2. LE TOTAL NE BOUGE JAMAIS. Ce qui sort d'une section entre dans une
 *     autre, au franc près. Une répartition qui modifie le total des charges
 *     de l'entreprise n'est pas une répartition, c'est une erreur.
 *
 *  3. AUCUNE CIRCULARITÉ. Si le siège déverse sur la production et la
 *     production sur le siège, le résultat dépend de l'ordre de calcul —
 *     autant dire qu'il n'existe pas. Une section cible ne peut donc pas
 *     être elle-même une section source, et c'est refusé à la saisie plutôt
 *     que débrouillé au calcul.
 *
 * ── CE QUE LA CLÉ RÉPARTIT ───────────────────────────────────────────────
 *
 * Les CHARGES, pas le résultat. Une section auxiliaire qui encaisse
 * accessoirement quelque chose — une refacturation, un produit financier —
 * garde ce produit chez elle : il ne s'agit pas d'un coût à faire supporter
 * aux autres. On déverse ce qu'elle a coûté, on ne déverse pas ce qu'elle a
 * gagné.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AnaAuxiliaire {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS ana_auxiliaires(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				axe_id INTEGER NOT NULL,
				source_id INTEGER NOT NULL,       -- valeur de l'axe (ou division si axe DIV)
				libelle TEXT,
				note TEXT,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(axe_id, source_id)
			);
			CREATE TABLE IF NOT EXISTS ana_auxiliaire_parts(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				auxiliaire_id INTEGER NOT NULL,
				cible_id INTEGER NOT NULL,
				part REAL NOT NULL DEFAULT 0,
				UNIQUE(auxiliaire_id, cible_id)
			);
			CREATE INDEX IF NOT EXISTS idx_auxp_aux ON ana_auxiliaire_parts(auxiliaire_id);
		" );
	}

	/* ── Valeurs d'un axe, quelle que soit sa nature ─────────────────────
	 *
	 * L'axe « Division » n'est pas stocké comme les autres : ses valeurs
	 * vivent dans `divisions`, pas dans `analytique_valeurs`. Sans cette
	 * indirection, la fonctionnalité aurait marché partout SAUF sur l'axe où
	 * elle est la plus utile — celui du siège.
	 */

	public static function estAxeDivision( $axeId ) {
		$a = class_exists( 'FKC_Axe' ) ? FKC_Axe::find( $axeId ) : null;
		return $a && 'DIV' === ( $a['code'] ?? '' );
	}

	/** @return array<int, array{id:int, code:string, libelle:string}> */
	public static function valeursAxe( $axeId ) {
		$out = array();
		if ( self::estAxeDivision( $axeId ) ) {
			if ( ! class_exists( 'FKC_Division' ) ) { return $out; }
			foreach ( FKC_Division::all( true ) as $d ) {
				$out[] = array( 'id' => (int) $d['id'], 'code' => (string) $d['code'], 'libelle' => (string) $d['libelle'] );
			}
			return $out;
		}
		if ( ! class_exists( 'FKC_Valeur' ) ) { return $out; }
		foreach ( FKC_Valeur::byAxe( (int) $axeId, true ) as $v ) {
			$out[] = array( 'id' => (int) $v['id'], 'code' => (string) $v['code'], 'libelle' => (string) $v['libelle'] );
		}
		return $out;
	}

	/* ── Lecture ─────────────────────────────────────────────────────────── */

	/** Sections auxiliaires d'un axe, avec leurs parts. */
	public static function parAxe( $axeId, $actifOnly = false ) {
		self::ensure();
		$w = $actifOnly ? ' AND actif=1' : '';
		try { $rows = FKC_DB::q( "SELECT * FROM ana_auxiliaires WHERE axe_id=?{$w} ORDER BY id", array( (int) $axeId ) )->fetchAll(); }
		catch ( \Throwable $e ) { return array(); }
		$noms = array();
		foreach ( self::valeursAxe( $axeId ) as $v ) { $noms[ $v['id'] ] = $v; }
		foreach ( $rows as &$r ) {
			$r['source'] = $noms[ (int) $r['source_id'] ] ?? null;
			$r['parts'] = FKC_DB::q( 'SELECT * FROM ana_auxiliaire_parts WHERE auxiliaire_id=? ORDER BY part DESC, id', array( (int) $r['id'] ) )->fetchAll();
			$total = 0.0;
			foreach ( $r['parts'] as &$p ) {
				$p['cible'] = $noms[ (int) $p['cible_id'] ] ?? null;
				$total += (float) $p['part'];
			}
			unset( $p );
			$r['total'] = round( $total, 4 );
			$r['complete'] = abs( $r['total'] - 100.0 ) < 0.01;
		}
		unset( $r );
		return $rows;
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM ana_auxiliaires WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		foreach ( self::parAxe( (int) $r['axe_id'] ) as $x ) {
			if ( (int) $x['id'] === (int) $id ) { return $x; }
		}
		return null;
	}

	/* ── Écriture ────────────────────────────────────────────────────────── */

	/**
	 * Déclare une section auxiliaire.
	 * @return array{0:bool,1:string,2:int}
	 */
	public static function creer( $axeId, $sourceId, $libelle = '', $note = '' ) {
		self::ensure();
		$axeId = (int) $axeId; $sourceId = (int) $sourceId;
		if ( ! $axeId || ! $sourceId ) { return array( false, 'Axe et section à répartir requis.', 0 ); }

		$noms = array();
		foreach ( self::valeursAxe( $axeId ) as $v ) { $noms[ $v['id'] ] = $v; }
		if ( ! isset( $noms[ $sourceId ] ) ) { return array( false, 'Cette section n\'appartient pas à l\'axe choisi.', 0 ); }

		/*
		 * Une section déjà CIBLE d'une autre répartition ne peut pas devenir
		 * source : ce serait la circularité, par l'autre bout.
		 */
		if ( self::estCible( $axeId, $sourceId ) ) {
			return array( false, '« ' . $noms[ $sourceId ]['libelle'] . ' » reçoit déjà les charges d\'une autre section : elle ne peut pas en déverser à son tour, le calcul dépendrait de l\'ordre.', 0 );
		}
		try {
			FKC_DB::q( 'INSERT INTO ana_auxiliaires(axe_id,source_id,libelle,note,actif) VALUES(?,?,?,?,1)',
				array( $axeId, $sourceId, trim( (string) $libelle ) ?: null, trim( (string) $note ) ?: null ) );
		} catch ( \Throwable $e ) {
			return array( false, 'Cette section est déjà déclarée comme auxiliaire sur cet axe.', 0 );
		}
		$id = (int) FKC_DB::conn()->lastInsertId();
		return array( true, '« ' . $noms[ $sourceId ]['libelle'] . ' » est déclarée section auxiliaire. Répartissez maintenant ses charges à 100 %.', $id );
	}

	/** La section est-elle destinataire d'une répartition sur cet axe ? */
	public static function estCible( $axeId, $valeurId ) {
		self::ensure();
		try {
			return (bool) FKC_DB::q(
				'SELECT 1 FROM ana_auxiliaire_parts p JOIN ana_auxiliaires a ON a.id=p.auxiliaire_id
				 WHERE a.axe_id=? AND p.cible_id=? AND p.part > 0 LIMIT 1',
				array( (int) $axeId, (int) $valeurId ) )->fetch();
		} catch ( \Throwable $e ) { return false; }
	}

	/** La section est-elle source d'une répartition sur cet axe ? */
	public static function estSource( $axeId, $valeurId ) {
		self::ensure();
		try {
			return (bool) FKC_DB::q( 'SELECT 1 FROM ana_auxiliaires WHERE axe_id=? AND source_id=? LIMIT 1',
				array( (int) $axeId, (int) $valeurId ) )->fetch();
		} catch ( \Throwable $e ) { return false; }
	}

	/**
	 * Fixe la part d'une section destinataire.
	 *
	 * Une part à 0 % est CONSERVÉE, pas effacée : elle dit « cette section
	 * ne reçoit rien », ce qui est un arbitrage, et se distingue de « on l'a
	 * oubliée », qui est un oubli. C'est la même règle que pour les clés de
	 * ventilation, et pour la même raison : on doit pouvoir relire la
	 * décision six mois plus tard.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function setPart( $auxId, $cibleId, $part ) {
		self::ensure();
		$aux = self::find( $auxId );
		if ( ! $aux ) { return array( false, 'Section auxiliaire introuvable.' ); }
		$cibleId = (int) $cibleId;
		if ( $cibleId === (int) $aux['source_id'] ) {
			return array( false, 'Une section ne peut pas se déverser sur elle-même.' );
		}
		if ( self::estSource( (int) $aux['axe_id'], $cibleId ) ) {
			return array( false, 'Cette section est elle-même auxiliaire : lui déverser des charges créerait une boucle.' );
		}
		$noms = array();
		foreach ( self::valeursAxe( (int) $aux['axe_id'] ) as $v ) { $noms[ $v['id'] ] = $v; }
		if ( ! isset( $noms[ $cibleId ] ) ) { return array( false, 'Section destinataire inconnue sur cet axe.' ); }

		$p = (float) str_replace( ',', '.', (string) $part );
		if ( $p < 0 || $p > 100 ) { return array( false, 'La part doit être comprise entre 0 et 100 %.' ); }

		// Le dépassement est refusé À LA SAISIE : laisser enregistrer 130 %
		// puis signaler l'anomalie plus loin obligerait à retrouver laquelle
		// des lignes corriger.
		$autres = 0.0;
		foreach ( $aux['parts'] as $x ) { if ( (int) $x['cible_id'] !== $cibleId ) { $autres += (float) $x['part']; } }
		if ( $autres + $p > 100.01 ) {
			return array( false, 'Total à ' . str_replace( '.', ',', (string) round( $autres + $p, 2 ) )
				. ' % : les autres sections en prennent déjà ' . str_replace( '.', ',', (string) round( $autres, 2 ) ) . ' %.' );
		}

		$ex = FKC_DB::q( 'SELECT id FROM ana_auxiliaire_parts WHERE auxiliaire_id=? AND cible_id=?', array( (int) $auxId, $cibleId ) )->fetchColumn();
		if ( $ex ) { FKC_DB::q( 'UPDATE ana_auxiliaire_parts SET part=? WHERE id=?', array( $p, (int) $ex ) ); }
		else { FKC_DB::q( 'INSERT INTO ana_auxiliaire_parts(auxiliaire_id,cible_id,part) VALUES(?,?,?)', array( (int) $auxId, $cibleId, $p ) ); }

		$total = round( $autres + $p, 2 );
		$msg = $noms[ $cibleId ]['libelle'] . ' : ' . str_replace( '.', ',', (string) round( $p, 2 ) ) . ' %. Total réparti ' . str_replace( '.', ',', (string) $total ) . ' %.';
		if ( $total < 99.99 ) {
			$msg .= ' Il reste ' . str_replace( '.', ',', (string) round( 100 - $total, 2 ) )
				. ' % non répartis : cette part restera sur la section auxiliaire.';
		}
		return array( true, $msg );
	}

	public static function retirerPart( $auxId, $cibleId ) {
		self::ensure();
		FKC_DB::q( 'DELETE FROM ana_auxiliaire_parts WHERE auxiliaire_id=? AND cible_id=?', array( (int) $auxId, (int) $cibleId ) );
		return array( true, 'Section destinataire retirée de la clé.' );
	}

	public static function basculer( $auxId ) {
		self::ensure();
		$a = FKC_DB::q( 'SELECT actif FROM ana_auxiliaires WHERE id=?', array( (int) $auxId ) )->fetch();
		if ( ! $a ) { return array( false, 'Introuvable.' ); }
		$n = empty( $a['actif'] ) ? 1 : 0;
		FKC_DB::q( 'UPDATE ana_auxiliaires SET actif=? WHERE id=?', array( $n, (int) $auxId ) );
		return array( true, $n ? 'Répartition activée : les résultats par axe en tiennent compte.' : 'Répartition désactivée : les charges restent sur la section auxiliaire.' );
	}

	public static function supprimer( $auxId ) {
		self::ensure();
		FKC_DB::q( 'DELETE FROM ana_auxiliaire_parts WHERE auxiliaire_id=?', array( (int) $auxId ) );
		FKC_DB::q( 'DELETE FROM ana_auxiliaires WHERE id=?', array( (int) $auxId ) );
		return array( true, 'Section auxiliaire supprimée — ses charges restent chez elle.' );
	}

	/* ── Application au résultat ─────────────────────────────────────────── */

	/**
	 * Déverse les charges des sections auxiliaires sur leurs destinataires.
	 *
	 * Le tableau reçu n'est PAS remplacé : chaque ligne est enrichie de
	 * `charges_propres`, `charges_deversees`, `charges_recues`, `charges` et
	 * `resultat` recalculés. Conserver le montant d'origine n'est pas une
	 * précaution de confort : c'est ce qui permet de répondre à « d'où sort
	 * ce chiffre ? » sans rejouer le calcul, et de rapprocher l'écran de la
	 * balance générale, qui elle ne connaît que les charges propres.
	 *
	 * Un seul passage suffit, puisqu'une cible ne peut pas être une source.
	 *
	 * @return array Le tableau de résultats, enrichi de la clé `repartition`.
	 */
	public static function appliquer( array $res, $axeId, $annee = '' ) {
		self::ensure();
		$res['repartition'] = array( 'active' => false, 'sections' => array(), 'incompletes' => array() );
		if ( empty( $res['lignes'] ) ) { return $res; }

		$aux = self::parAxe( $axeId, true );
		if ( ! $aux ) { return $res; }

		// Index des lignes par identifiant de valeur, pour écrire en place.
		$parId = array();
		foreach ( $res['lignes'] as $i => $l ) { $parId[ (int) $l['valeur_id'] ] = $i; }

		foreach ( $res['lignes'] as &$l ) {
			$l['charges_propres']   = (float) $l['charges'];
			$l['charges_deversees'] = 0.0;
			$l['charges_recues']    = 0.0;
			$l['auxiliaire']        = false;
		}
		unset( $l );

		$sections = array(); $incompletes = array();
		foreach ( $aux as $a ) {
			$sid = (int) $a['source_id'];
			if ( ! isset( $parId[ $sid ] ) ) { continue; }   // section sans mouvement sur la période
			$idx = $parId[ $sid ];
			$base = (float) $res['lignes'][ $idx ]['charges_propres'];
			$res['lignes'][ $idx ]['auxiliaire'] = true;
			if ( $base <= 0 ) { continue; }

			$deverse = 0.0;
			foreach ( $a['parts'] as $p ) {
				$cid = (int) $p['cible_id'];
				$pct = (float) $p['part'];
				if ( $pct <= 0 || ! isset( $parId[ $cid ] ) ) { continue; }
				$m = round( $base * $pct / 100, 2 );
				$res['lignes'][ $parId[ $cid ] ]['charges_recues'] += $m;
				$deverse += $m;
			}
			/*
			 * Le déversé est BORNÉ par la base. Les arrondis ligne à ligne
			 * peuvent dépasser de quelques centimes ; laisser passer ce
			 * dépassement ferait sortir d'une section plus qu'elle n'a
			 * coûté, et le total des charges ne retomberait plus juste.
			 */
			if ( $deverse > $base ) {
				$ecart = $deverse - $base;
				// On reprend l'écart sur la plus grosse part, la moins
				// sensible en pourcentage à cette correction.
				$plusGrosse = null; $max = -1;
				foreach ( $a['parts'] as $p ) {
					$cid = (int) $p['cible_id'];
					if ( isset( $parId[ $cid ] ) && (float) $p['part'] > $max ) { $max = (float) $p['part']; $plusGrosse = $parId[ $cid ]; }
				}
				if ( null !== $plusGrosse ) { $res['lignes'][ $plusGrosse ]['charges_recues'] -= $ecart; }
				$deverse = $base;
			}
			$res['lignes'][ $idx ]['charges_deversees'] = $deverse;

			$sections[] = array(
				'libelle'  => $a['source']['libelle'] ?? ( 'Section #' . $sid ),
				'code'     => $a['source']['code'] ?? '',
				'base'     => $base,
				'deverse'  => $deverse,
				'reste'    => round( $base - $deverse, 2 ),
				'total'    => (float) $a['total'],
				'complete' => (bool) $a['complete'],
			);
			if ( ! $a['complete'] ) { $incompletes[] = $a['source']['libelle'] ?? ( 'Section #' . $sid ); }
		}

		if ( ! $sections ) { return $res; }

		foreach ( $res['lignes'] as &$l ) {
			$l['charges']  = round( (float) $l['charges_propres'] - (float) $l['charges_deversees'] + (float) $l['charges_recues'], 2 );
			$l['resultat'] = round( (float) $l['produits'] - (float) $l['charges'], 2 );
		}
		unset( $l );

		$res['repartition'] = array(
			'active' => true, 'sections' => $sections, 'incompletes' => $incompletes,
		);
		return $res;
	}

	/**
	 * Contrôle d'intégrité : le total des charges doit être identique avant
	 * et après. Sert aux vérifications et à l'écran, qui l'affiche : une
	 * répartition qu'on ne peut pas contrôler ne mérite pas qu'on s'y fie.
	 *
	 * @return array{avant: float, apres: float, ecart: float, ok: bool}
	 */
	public static function controle( array $res ) {
		$avant = 0.0; $apres = 0.0;
		foreach ( $res['lignes'] as $l ) {
			$avant += (float) ( $l['charges_propres'] ?? $l['charges'] );
			$apres += (float) $l['charges'];
		}
		$ecart = round( $apres - $avant, 2 );
		return array( 'avant' => round( $avant, 2 ), 'apres' => round( $apres, 2 ),
			'ecart' => $ecart, 'ok' => ( abs( $ecart ) < 0.01 ) );
	}
}
