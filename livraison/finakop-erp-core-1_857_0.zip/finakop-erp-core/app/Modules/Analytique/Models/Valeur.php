<?php
/** Valeurs analytiques (le tableau central des valeurs de chaque axe). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Valeur {

	public static function byAxe( $axeId, $actifOnly = false ) {
		$w = $actifOnly ? ' AND actif=1' : '';
		return FKC_DB::q( "SELECT * FROM analytique_valeurs WHERE axe_id=?{$w} ORDER BY ordre, libelle COLLATE NOCASE", array( (int) $axeId ) )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM analytique_valeurs WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function map( $axeId ) {
		$m = array();
		foreach ( self::byAxe( $axeId ) as $v ) { $m[ (int) $v['id'] ] = $v['libelle']; }
		return $m;
	}
	public static function codeExists( $axeId, $code, $exceptId = 0 ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM analytique_valeurs WHERE axe_id=? AND code=? AND id<>?', array( (int) $axeId, strtoupper( $code ), (int) $exceptId ) )->fetch();
	}
	public static function create( $axeId, $code, $libelle, $ordre = 0 ) {
		FKC_DB::q( 'INSERT INTO analytique_valeurs(axe_id,code,libelle,actif,ordre) VALUES(?,?,?,1,?)', array( (int) $axeId, strtoupper( trim( $code ) ), trim( $libelle ), (int) $ordre ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $code, $libelle, $actif, $ordre = 0 ) {
		FKC_DB::q( 'UPDATE analytique_valeurs SET code=?, libelle=?, actif=?, ordre=? WHERE id=?', array( strtoupper( trim( $code ) ), trim( $libelle ), $actif ? 1 : 0, (int) $ordre, (int) $id ) );
	}
	/** Active / désactive une valeur : elle quitte les sélecteurs, garde son histoire. */
	public static function setActif( $id, $actif ) {
		FKC_DB::q( 'UPDATE analytique_valeurs SET actif=? WHERE id=?', array( $actif ? 1 : 0, (int) $id ) );
	}

	/** Ce que porte une valeur : affectations, budgets, clés de répartition. */
	public static function impact( $id ) {
		$id = (int) $id;
		$n  = function ( $sql ) use ( $id ) {
			try { return (int) FKC_DB::q( $sql, array( $id ) )->fetchColumn(); } catch ( \Throwable $e ) { return 0; }
		};
		$aff = $n( 'SELECT COUNT(*) FROM ligne_affectations WHERE valeur_id=?' )
			+ ( class_exists( 'FKC_Ventilation' ) ? FKC_Ventilation::compter( 'valeur_id', $id, (int) FKC_DB::q( 'SELECT axe_id FROM analytique_valeurs WHERE id=?', array( $id ) )->fetchColumn() ) : 0 );
		$bud = $n( 'SELECT COUNT(*) FROM budgets_axes WHERE valeur_id=?' );
		$cle = $n( 'SELECT COUNT(*) FROM repartition_cles WHERE valeur_id=?' );
		return array( 'affectations' => $aff, 'budgets' => $bud, 'cles' => $cle, 'total' => $aff + $bud + $cle );
	}

	/**
	 * Supprime une valeur analytique.
	 *
	 * REFUS MOTIVÉ (1.547.0), pour deux raisons distinctes :
	 *
	 *   • Elle porte des AFFECTATIONS : les effacer perdait, sans un mot, tout
	 *     le travail d'imputation fait sur ces lignes — et les budgets et clés
	 *     de répartition qui la visaient restaient en base à pointer dans le
	 *     vide. On désactive plutôt : la valeur quitte les sélecteurs de
	 *     saisie et reste lisible dans les résultats par axe.
	 *
	 *   • Elle est LIÉE À UNE SOURCE (client, fournisseur, artiste, produit…) :
	 *     la supprimer ne servait à rien, le prochain passage sur un écran
	 *     analytique la recréait par backfill. La désactivation, elle, tient.
	 *
	 * @param bool $forcer Nettoyage délibéré (valeur saisie par erreur).
	 * @return array{0:bool,1:string}
	 */
	public static function delete( $id, $forcer = false ) {
		$id = (int) $id;
		$v  = self::find( $id );
		if ( ! $v ) { return array( false, 'Valeur introuvable.' ); }

		if ( ! $forcer && ! empty( $v['source_type'] ) && empty( $v['source_orpheline'] ) ) {
			return array( false, 'Suppression refusée : « ' . $v['libelle'] . ' » reflète une fiche du référentiel ('
				. $v['source_type'] . '). Elle serait recréée au prochain affichage d\'un écran analytique. '
				. 'Désactivez-la, ou supprimez la fiche d\'origine dans son module.' );
		}
		/*
		 * Une valeur ORPHELINE (fiche d'origine supprimée dans son module) ne
		 * sera plus recréée : le motif de refus ci-dessus ne s'applique donc
		 * pas. Elle reste protégée par le contrôle d'imputations qui suit —
		 * ce sont ses affectations passées qui valent d'être gardées, pas son
		 * lien vers une fiche qui n'existe plus (1.554.0).
		 */

		$imp = self::impact( $id );
		if ( $imp['total'] > 0 && ! $forcer ) {
			$quoi = array();
			if ( $imp['affectations'] ) { $quoi[] = $imp['affectations'] . ' ligne(s) affectée(s)'; }
			if ( $imp['budgets'] )      { $quoi[] = $imp['budgets'] . ' budget(s)'; }
			if ( $imp['cles'] )         { $quoi[] = $imp['cles'] . ' clé(s) de répartition'; }
			return array( false, 'Suppression refusée : « ' . $v['libelle'] . ' » porte ' . implode( ', ', $quoi )
				. '. Désactivez la valeur : elle quitte les sélecteurs et conserve son historique.' );
		}

		// Trace posée dans le modèle : elle suit l'acte, pas l'écran.
		if ( $forcer && ( $imp['total'] > 0 || ! empty( $v['source_type'] ) ) && class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'analytique_valeur_suppression_forcee',
				'Valeur « ' . $v['code'] . ' — ' . $v['libelle'] . ' » (axe #' . (int) $v['axe_id'] . ') supprimée malgré son contenu : '
				. $imp['affectations'] . ' affectation(s), ' . $imp['budgets'] . ' budget(s), ' . $imp['cles'] . ' clé(s) de répartition.' );
		}
		$run = function ( $sql ) use ( $id ) {
			try { FKC_DB::q( $sql, array( $id ) ); } catch ( \Throwable $e ) { /* table absente */ }
		};
		$run( 'DELETE FROM ligne_affectations WHERE valeur_id=?' );
		if ( class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::supprimerPour( 'valeur_id', $id, (int) $v['axe_id'] ); }
		$run( 'DELETE FROM budgets_axes WHERE valeur_id=?' );
		$run( 'DELETE FROM repartition_cles WHERE valeur_id=?' );
		$run( 'DELETE FROM analytique_valeurs WHERE id=?' );
		return array( true, 'Valeur « ' . $v['libelle'] . ' » supprimée.' );
	}
}
