<?php
/**
 * Service FNE (Facture Normalisée Électronique — DGI Côte d'Ivoire).
 * Certifie une facture via l'API d'interfaçage DGI : POST {api_url}/external/invoices/sign
 * en-tête « Authorization: Bearer {clé} ». Stocke référence, token, solde de stickers.
 * Disponible pour TOUTES les éditions (le module Facturation est inclus partout).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Fne {

	const KEYS = array(
		'fne_api_url', 'fne_api_key', 'fne_ncc', 'fne_establishment', 'fne_point_of_sale',
		'fne_regime', 'fne_tva_default', 'fne_commercial_message', 'fne_footer', 'fne_verify_url',
		'fne_company_name', 'fne_compte_vente',
	);

	/**
	 * Clés de configuration qui sont des SECRETS.
	 *
	 * Elles ne transitent jamais par `parametres` ni par la vue : elles vivent
	 * dans FKC_Vault, chiffrées au repos par FKC_Crypto.
	 */
	const SECRETS = array( 'fne_api_key' );

	/* ---- Le coffre ---- */

	/**
	 * Nom du secret dans le coffre, cloisonné par société.
	 *
	 * POURQUOI LE CLOISONNEMENT EST OBLIGATOIRE ICI
	 *
	 * `cab_secrets` vit dans la base MASTER et sa clé primaire est la seule
	 * colonne `cle` — elle est donc commune à toutes les sociétés, alors que
	 * `parametres` est propre à chacune. Y déposer « fne_api_key » tel quel
	 * ferait que la deuxième société enregistrée écraserait la clé de la
	 * première, et signerait ensuite ses factures avec le compte DGI d'une
	 * autre entreprise : des factures normalisées émises sous le NCC d'autrui,
	 * sans que rien ne le signale.
	 *
	 * Le suffixe société rend la collision impossible.
	 */
	protected static function secretCle( $cle ) {
		$sid = class_exists( 'FKC_Tenant' ) ? (int) FKC_Tenant::id() : 0;
		return (string) $cle . ( $sid > 0 ? ':s' . $sid : '' );
	}

	/**
	 * Lit un secret, en migrant au passage l'ancienne valeur en clair.
	 *
	 * La migration est silencieuse et se fait une seule fois : la valeur est
	 * copiée dans le coffre, puis EFFACÉE de `parametres`. La laisser en place
	 * « au cas où » reviendrait à ne rien avoir chiffré — un secret dupliqué
	 * est un secret exposé.
	 */
	public static function secret( $cle ) {
		if ( ! class_exists( 'FKC_Vault' ) ) {
			return (string) FKC_License::param( $cle, '' );
		}
		try {
			$v = (string) FKC_Vault::get( self::secretCle( $cle ), '' );
			if ( '' !== $v ) { return $v; }
		} catch ( \Throwable $e ) { return (string) FKC_License::param( $cle, '' ); }

		// Reprise de l'existant : la clé était stockée en clair dans `parametres`.
		$legacy = trim( (string) FKC_License::param( $cle, '' ) );
		if ( '' === $legacy ) { return ''; }
		try {
			FKC_Vault::set( self::secretCle( $cle ), $legacy );
			FKC_License::setParam( $cle, '' );
			if ( class_exists( 'FKC_Security' ) ) {
				FKC_Security::audit( 'fne_secret_migre', $cle . ' déplacé de parametres vers le coffre chiffré' );
			}
		} catch ( \Throwable $e ) { /* la clé reste lisible : on ne bloque pas la certification */ }
		return $legacy;
	}

	/** Enregistre un secret. Une valeur vide n'efface RIEN (voir saveConfig). */
	protected static function setSecret( $cle, $valeur ) {
		$valeur = trim( (string) $valeur );
		if ( ! class_exists( 'FKC_Vault' ) ) { FKC_License::setParam( $cle, $valeur ); return; }
		try {
			FKC_Vault::set( self::secretCle( $cle ), $valeur );
			// Purge d'une éventuelle trace en clair laissée par une version antérieure.
			if ( '' !== (string) FKC_License::param( $cle, '' ) ) { FKC_License::setParam( $cle, '' ); }
		} catch ( \Throwable $e ) { FKC_License::setParam( $cle, $valeur ); }
	}

	/** Supprime un secret du coffre. */
	protected static function oublierSecret( $cle ) {
		if ( class_exists( 'FKC_Vault' ) ) {
			try { FKC_Vault::forget( self::secretCle( $cle ) ); } catch ( \Throwable $e ) {}
		}
		FKC_License::setParam( $cle, '' );
	}

	/** La clé API, en clair — usage interne uniquement (appels HTTP). */
	public static function cleApi() { return self::secret( 'fne_api_key' ); }

	/**
	 * Empreinte affichable d'un secret : quatre derniers caractères.
	 *
	 * Assez pour qu'un exploitant reconnaisse SA clé et vérifie qu'elle est
	 * bien celle de son espace FNE ; pas assez pour qu'une capture d'écran,
	 * un cache de navigateur ou un journal de proxy la restitue.
	 *
	 * Le masque est de longueur FIXE, à dessein : le calquer sur la taille
	 * réelle divulguerait le format de la clé, donc l'espace à parcourir pour
	 * qui voudrait la deviner.
	 */
	public static function empreinte( $cle = 'fne_api_key' ) {
		$v = self::secret( $cle );
		if ( '' === $v ) { return ''; }
		return str_repeat( '•', 12 ) . substr( $v, -4 );
	}

	/* ---- Configuration (non sensible : `parametres`) ---- */

	/**
	 * Configuration destinée à l'AFFICHAGE et aux appels internes.
	 *
	 * `fne_api_key` y figure toujours, pour ne rien casser chez les appelants
	 * existants — mais la valeur vient désormais du coffre, pas de la table
	 * `parametres`. Les vues, elles, doivent utiliser `empreinte()`.
	 */
	public static function config() {
		$cfg = array();
		foreach ( self::KEYS as $k ) {
			$cfg[ $k ] = in_array( $k, self::SECRETS, true )
				? self::secret( $k )
				: (string) FKC_License::param( $k, '' );
		}
		$cfg['fne_regime'] = self::regime();
		return $cfg;
	}

	/** Configuration sans aucun secret — c'est CELLE-CI que les vues reçoivent. */
	public static function configPublique() {
		$cfg = self::config();
		foreach ( self::SECRETS as $k ) { $cfg[ $k ] = ''; }
		$cfg['fne_api_key_empreinte'] = self::empreinte( 'fne_api_key' );
		$cfg['fne_chiffrement_ok']    = class_exists( 'FKC_Crypto' ) && FKC_Crypto::available();
		return $cfg;
	}

	/**
	 * Enregistre la configuration.
	 *
	 * UN CHAMP SECRET VIDE NE VIDE PAS LE SECRET. Le formulaire n'affiche
	 * plus la clé : la renvoyer vide signifie « je n'y touche pas », pas
	 * « supprime-la ». Sans cette règle, le premier exploitant qui corrigerait
	 * une faute de frappe dans le pied de facture effacerait sa clé de
	 * signature et ses factures cesseraient d'être certifiées.
	 *
	 * La suppression volontaire passe par la case dédiée du formulaire.
	 */
	public static function saveConfig( $data ) {
		// Raccourcis de l'écran : bac à sable ou production, sans risque de
		// faute de frappe sur l'hôte (1.801.1).
		$preset = (string) ( $data['fne_api_url_preset'] ?? '' );
		if ( 'test' === $preset ) { $data['fne_api_url'] = self::URL_TEST; }
		if ( 'production' === $preset ) { $data['fne_api_url'] = self::URL_PRODUCTION; }
		foreach ( self::KEYS as $k ) {
			// Le régime vient de la Fiscalité depuis la 1.753.0 : un champ
			// posté ne doit plus pouvoir le contredire.
			if ( 'fne_regime' === $k ) { continue; }
			if ( ! array_key_exists( $k, $data ) ) { continue; }
			$v = trim( (string) $data[ $k ] );
			if ( 'fne_api_url' === $k ) { $v = self::normaliserUrl( $v ); }
			if ( in_array( $k, self::SECRETS, true ) ) {
				if ( '' !== $v ) { self::setSecret( $k, $v ); }
				continue;
			}
			FKC_License::setParam( $k, $v );
		}
		if ( ! empty( $data['fne_api_key_supprimer'] ) ) {
			self::oublierSecret( 'fne_api_key' );
		}
	}

	/**
	 * NORMALISE L'ADRESSE DE L'API (1.801.0).
	 *
	 * L'adresse attendue est la BASE de l'interface (elle se termine par /ws
	 * chez la DGI) ; FinaKop y ajoute lui-même /external/invoices/sign. Une
	 * adresse collée depuis la documentation contient souvent déjà ce chemin,
	 * ou une barre finale, ou des espaces invisibles : la requête partait
	 * alors vers .../external/invoices/sign/external/invoices/sign et le
	 * serveur répondait, à juste titre, 404. On coupe ici ce qui doit l'être.
	 */
	/** Bac à sable public de la DGI. */
	const URL_TEST = 'http://54.247.95.108/ws';

	/**
	 * Adresse de PRODUCTION de l'interface FNE, vérifiée : c'est avec elle que
	 * les spécimens de KOPHI'S GROUP ont été validés par la DGI (extension
	 * km-compta-erp 2.1.17). Le « www. » n'est pas décoratif — sans lui, le
	 * serveur répond 404 : c'était la cause de l'échec de certification.
	 */
	const URL_PRODUCTION = 'https://www.services.fne.dgi.gouv.ci/ws';

	public static function normaliserUrl( $u ) {
		$u = trim( preg_replace( '/\s+/u', '', (string) $u ) );
		if ( '' === $u ) { return ''; }
		$u = rtrim( $u, '/' );
		// Chemins d'endpoint collés à la base.
		$u = preg_replace( '#/external/invoices(/sign|/[^/]+/refund)?$#i', '', $u );
		$u = rtrim( $u, '/' );
		// L'hôte de production ne répond que sous « www. » : on corrige au lieu
		// de laisser un 404 inexplicable (1.801.1).
		$u = preg_replace( '#^https?://services\.fne\.dgi\.gouv\.ci#i', 'https://www.services.fne.dgi.gouv.ci', $u );
		return $u;
	}

	/** L'URL complète réellement appelée pour signer — celle qu'il faut montrer en cas d'erreur. */
	public static function endpointSign() {
		$base = self::normaliserUrl( self::config()['fne_api_url'] );
		return '' === $base ? '' : $base . '/external/invoices/sign';
	}

	/**
	 * Anomalies de l'adresse configurée, AVANT tout appel. Une adresse de
	 * production ne s'invente pas : la DGI la communique avec la clé de
	 * production, à la validation des spécimens.
	 */
	public static function diagnosticUrl() {
		$base = self::normaliserUrl( self::config()['fne_api_url'] );
		$out = array();
		if ( '' === $base ) { return array( 'Aucune adresse d\'API FNE n\'est renseignée.' ); }
		if ( ! preg_match( '#^https?://#i', $base ) ) { $out[] = 'L\'adresse doit commencer par http:// ou https://.'; }
		$host = (string) parse_url( $base, PHP_URL_HOST );
		if ( '' === $host ) { $out[] = 'Adresse illisible : ' . $base; }
		if ( ! preg_match( '#/ws$#', $base ) && '54.247.95.108' !== $host ) {
			$out[] = 'L\'adresse ne se termine pas par /ws : la base de l\'interface DGI en production est ' . self::URL_PRODUCTION . ' (bac à sable : ' . self::URL_TEST . ').';
		}
		if ( 'services.fne.dgi.gouv.ci' === $host ) {
			$out[] = 'L\'hôte de production s\'écrit avec « www. » : ' . self::URL_PRODUCTION . ' — sans lui, le serveur répond 404.';
		}
		return $out;
	}

	public static function isConfigured() {
		return '' !== self::cleApi() && '' !== (string) FKC_License::param( 'fne_establishment', '' );
	}

	/**
	 * L'environnement se déduit de l'ADRESSE, et seule celle du bac à sable
	 * DGI est connue d'avance (1.801.0) : l'adresse de production est
	 * communiquée par la DGI à chaque contribuable, FinaKop ne la devine pas.
	 */
	public static function environment() {
		$u = self::normaliserUrl( self::config()['fne_api_url'] );
		if ( '' === $u ) { return 'non configuré'; }
		if ( false !== strpos( $u, '54.247.95.108' ) ) { return 'test (bac à sable DGI)'; }
		if ( false !== strpos( $u, 'services.fne.dgi.gouv.ci' ) ) { return 'production (DGI)'; }
		return 0 === stripos( $u, 'https://' ) ? 'production' : 'personnalisé';
	}

	/** URL de vérification publique encodée dans le QR code. */
	public static function verifyUrl( $facture ) {
		$base = self::config()['fne_verify_url'] ?: 'https://e-impots.gouv.ci/verifier';
		$q = http_build_query( array( 'ref' => $facture['fne_reference'], 'token' => $facture['fne_token'] ) );
		return $base . '?' . $q;
	}

	/* ---- Certification ---- */

	public static function certify( $factureId ) {
		$f = FKC_Facture::find( $factureId );
		if ( ! $f ) { return array( 'ok' => false, 'error' => 'Facture introuvable.' ); }
		if ( 'CERTIFIE' === $f['fne_status'] ) { return array( 'ok' => false, 'error' => 'Facture déjà certifiée.' ); }

		$cfg = self::config();
		if ( '' === $cfg['fne_api_key'] ) {
			return array( 'ok' => false, 'error' => 'Clé API FNE non configurée — renseignez-la dans Facturation › Paramètres FNE.' );
		}
		if ( '' === $cfg['fne_establishment'] ) {
			return array( 'ok' => false, 'error' => 'Établissement FNE non configuré — saisissez le nom exact tel qu\'enregistré dans votre espace FNE DGI.' );
		}
		if ( 'B2B' === $f['template'] ) {
			$ncc = '';
			if ( ! empty( $f['client_id'] ) ) {
				$cli = FKC_Client::find( $f['client_id'] );
				$ncc = $cli['ncc'] ?? '';
			}
			if ( '' === trim( (string) $ncc ) ) {
				return array( 'ok' => false, 'error' => 'Facture B2B : le NCC du client est obligatoire.' );
			}
		}

		$payload = self::buildPayload( $f, $cfg );
		$url     = self::normaliserUrl( $cfg['fne_api_url'] ) . '/external/invoices/sign';
		list( $code, $body, $err ) = self::http( $url, $cfg['fne_api_key'], wp_json_safe( $payload ) );

		if ( $err ) {
			FKC_DB::q( "UPDATE factures SET fne_status='ERROR',fne_error=? WHERE id=?", array( 'Réseau : ' . $err, $factureId ) );
			return array( 'ok' => false, 'error' => 'Erreur réseau : ' . $err );
		}
		$resp = json_decode( $body, true );

		if ( 200 === $code || 201 === $code ) {
			$ref     = $resp['reference']              ?? '';
			$token   = $resp['token']                  ?? '';
			$invId   = $resp['invoice']['id']          ?? '';
			$balance = $resp['balance_sticker']        ?? null;
			$warning = ! empty( $resp['warning'] ) ? 1 : 0;
			$items   = $resp['invoice']['items']       ?? array();

			FKC_DB::q(
				"UPDATE factures SET fne_status='CERTIFIE', statut='certifiee', fne_reference=?, fne_token=?, fne_invoice_id=?, fne_balance_sticker=?, fne_warning=?, fne_certified_at=datetime('now','localtime'), fne_error=NULL WHERE id=?",
				array( $ref, $token, $invId, $balance, $warning, $factureId )
			);
			// Associer les item ids FNE aux lignes (par ordre).
			foreach ( $f['lignes'] as $idx => $lig ) {
				if ( isset( $items[ $idx ]['id'] ) ) {
					FKC_DB::q( 'UPDATE facture_lignes SET fne_item_id=? WHERE id=?', array( $items[ $idx ]['id'], $lig['id'] ) );
				}
			}
			return array( 'ok' => true, 'reference' => $ref, 'balance' => $balance, 'warning' => (bool) $warning );
		}

		$msg = self::errorMessage( $code, $resp, $body, $cfg );
		FKC_DB::q( "UPDATE factures SET fne_status='ERROR',fne_error=? WHERE id=?", array( $msg, $factureId ) );
		return array( 'ok' => false, 'error' => $msg );
	}

	/** Avoir / note de crédit FNE — annule une facture certifiée via /refund. */
	public static function refund( $factureId ) {
		$f = FKC_Facture::find( $factureId );
		if ( ! $f ) { return array( 'ok' => false, 'error' => 'Facture introuvable.' ); }
		if ( 'CERTIFIE' !== $f['fne_status'] || empty( $f['fne_invoice_id'] ) ) {
			return array( 'ok' => false, 'error' => 'La facture doit être certifiée FNE avant de pouvoir être annulée.' );
		}
		if ( ! empty( $f['fne_avoir_reference'] ) ) {
			return array( 'ok' => false, 'error' => 'Un avoir a déjà été émis pour cette facture.' );
		}
		$cfg = self::config();
		$items = array();
		foreach ( $f['lignes'] as $l ) {
			if ( empty( $l['fne_item_id'] ) ) {
				return array( 'ok' => false, 'error' => 'IDs de lignes FNE manquants — re-certifiez la facture d\'origine.' );
			}
			$items[] = array(
				'id'              => $l['fne_item_id'],
				'taxes'           => array( self::codeTaxe( $l['tva_code'] ) ),
				'customTaxes'     => array(),
				'reference'       => $f['numero'] . '-AV',
				'description'     => 'Annulation : ' . $l['designation'],
				'quantity'        => (int) max( 1, (float) $l['quantite'] ),
				'amount'          => (int) round( $l['pu_ht'] ),
				'discount'        => 0,
				'measurementUnit' => $l['unite'] ?: 'pièce',
			);
		}
		$url = self::normaliserUrl( $cfg['fne_api_url'] ) . '/external/invoices/' . rawurlencode( $f['fne_invoice_id'] ) . '/refund';
		list( $code, $body, $err ) = self::http( $url, $cfg['fne_api_key'], wp_json_safe( array( 'items' => $items ) ) );
		if ( $err ) { return array( 'ok' => false, 'error' => 'Erreur réseau : ' . $err ); }
		$resp = json_decode( $body, true );
		if ( 200 === $code || 201 === $code ) {
			$ref   = $resp['reference'] ?? '';
			$token = $resp['token'] ?? '';
			$bal   = $resp['balance_sticker'] ?? null;
			FKC_DB::q(
				"UPDATE factures SET statut='annulee', fne_avoir_reference=?, fne_avoir_token=?, fne_avoir_certified_at=datetime('now','localtime'), fne_balance_sticker=COALESCE(?,fne_balance_sticker) WHERE id=?",
				array( $ref, $token, $bal, $factureId )
			);
			return array( 'ok' => true, 'reference' => $ref, 'balance' => $bal );
		}
		$msg = self::errorMessage( $code, $resp, $body, $cfg );
		return array( 'ok' => false, 'error' => $msg );
	}

	/** Teste la clé/connexion en appelant l'endpoint avec un corps vide. */
	public static function testConnection() {
		$cfg = self::config();
		if ( '' === $cfg['fne_api_key'] ) { return array( 'ok' => false, 'error' => 'Aucune clé API saisie.' ); }
		$anomalies = self::diagnosticUrl();
		$url = self::endpointSign();
		if ( $anomalies ) { return array( 'ok' => false, 'error' => implode( ' ', $anomalies ) . ' Adresse appelée : ' . $url ); }
		list( $code, $body, $err ) = self::http( $url, $cfg['fne_api_key'], '{}', 10 );
		if ( $err ) { return array( 'ok' => false, 'error' => 'Réseau : ' . $err . ' (adresse appelée : ' . $url . ')' ); }
		/*
		 * 1.801.0 — un 404 était compté comme un succès : le test répondait
		 * « connexion établie » alors que le serveur ne connaissait même pas
		 * l'adresse, et l'exploitant ne découvrait la panne qu'à sa première
		 * facture. Chaque code dit maintenant ce qu'il veut dire :
		 *   401/403 → la clé est refusée ;
		 *   404/405 → l'ADRESSE est fausse, la clé n'a pas même été lue ;
		 *   5xx     → la plateforme DGI est indisponible ;
		 *   400/422 → la clé est acceptée, seul le corps vide est rejeté : OK.
		 */
		if ( in_array( $code, array( 401, 403 ), true ) ) { return array( 'ok' => false, 'error' => "Clé API refusée (HTTP {$code}). L'adresse répond, mais la clé n'est pas acceptée : vérifiez qu'elle vient bien de l'espace FNE de cette société et qu'elle est activée pour la signature." ); }
		if ( in_array( $code, array( 404, 405 ), true ) ) {
			return array( 'ok' => false, 'error' => "Adresse inconnue du serveur (HTTP {$code}) : {$url}. Ce n'est pas la clé qui est en cause — c'est le chemin. "
				. 'Production : ' . self::URL_PRODUCTION . ' · bac à sable : ' . self::URL_TEST . '.' );
		}
		if ( $code >= 500 ) { return array( 'ok' => false, 'error' => "Plateforme FNE indisponible (HTTP {$code}) : réessayez plus tard. Adresse appelée : {$url}" ); }
		if ( 0 === $code ) { return array( 'ok' => false, 'error' => 'Aucune réponse du serveur (adresse appelée : ' . $url . ').' ); }
		return array( 'ok' => true, 'message' => "Connexion établie (HTTP {$code}) sur {$url}. Clé acceptée par l'API FNE." );
	}

	/* ---- Interne ---- */

	/**
	 * CODE DE TAXE ACCEPTÉ PAR LA PLATEFORME (1.753.0).
	 *
	 * La procédure d'interfaçage de la DGI ferme la liste à TVA, TVAB, TVAC et
	 * TVAD. Le code interne partait tel quel : une ligne à `TEX` — produite
	 * par le folio d'acompte, le socle prestations, la vente verticale et les
	 * reçus dès que le taux est nul — envoyait à la DGI un code qu'elle ne
	 * connaît pas. On traduit ici, au seul endroit qui parle à la plateforme,
	 * plutôt que de réécrire l'historique des lignes déjà enregistrées.
	 */
	public static function codeTaxe( $code ) {
		$code = strtoupper( trim( (string) $code ) );
		$connus = array( 'TVA', 'TVAB', 'TVAC', 'TVAD' );
		if ( in_array( $code, $connus, true ) ) { return $code; }
		if ( ! class_exists( 'FKC_Facture' ) ) { return 'TVAC'; }
		if ( 'TEX' === $code ) { return FKC_Facture::codeExonere(); }
		$defaut = FKC_Facture::codeDefaut();
		return in_array( $defaut, $connus, true ) ? $defaut : 'TVAC';
	}

	/**
	 * Régime affiché sur la facture — DÉRIVÉ du régime fiscal (1.753.0).
	 *
	 * L'API de certification ne transporte AUCUN régime : il est attaché au
	 * compte de l'entreprise sur la plateforme FNE. Le réglage local ne servait
	 * donc qu'à la mention imprimée, et constituait une troisième liste de
	 * régimes, sans lien avec la Fiscalité ni avec la fiche société.
	 */
	public static function regime() {
		if ( class_exists( 'FKC_FiscalConfig' ) ) {
			try {
				$cfg = FKC_FiscalConfig::get();
				$code = FKC_FiscalConfig::CODES_SOCIETE[ $cfg['regime'] ] ?? '';
				if ( '' !== $code ) { return $code; }
			} catch ( \Throwable $e ) { /* repli sur la valeur stockée */ }
		}
		return (string) FKC_License::param( 'fne_regime', '' );
	}

	protected static function buildPayload( $f, $cfg ) {
		$client_phone = preg_replace( '/\D/', '', (string) '' );
		$cli = ! empty( $f['client_id'] ) ? FKC_Client::find( $f['client_id'] ) : null;
		$phone = $cli ? preg_replace( '/\D/', '', (string) ( $cli['telephone'] ?? '' ) ) : '';
		if ( strlen( $phone ) < 8 ) { $phone = '0700000000'; }
		$email = ( $cli && ! empty( $cli['email'] ) && filter_var( $cli['email'], FILTER_VALIDATE_EMAIL ) ) ? $cli['email'] : 'client@kophisgroup.com';

		$items = array();
		foreach ( $f['lignes'] as $l ) {
			$items[] = array(
				'taxes'           => array( self::codeTaxe( $l['tva_code'] ) ),
				'customTaxes'     => array(),
				'reference'       => $f['numero'],
				'description'     => $l['designation'],
				'quantity'        => (int) max( 1, (float) $l['quantite'] ),
				'amount'          => (int) round( $l['pu_ht'] ),
				'discount'        => 0,
				'measurementUnit' => $l['unite'] ?: 'pièce',
			);
		}

		$payload = array(
			'invoiceType'         => 'sale',
			'paymentMethod'       => $f['payment_method'] ?: 'cash',
			'template'            => $f['template'] ?: 'B2C',
			'isRne'               => false,
			'rne'                 => null,
			'clientCompanyName'   => $f['client_nom'] ?: 'Client',
			'clientPhone'         => $phone,
			'clientEmail'         => $email,
			'pointOfSale'         => $cfg['fne_point_of_sale'],
			'establishment'       => $cfg['fne_establishment'],
			'commercialMessage'   => $f['commercial_message'] ?: $cfg['fne_commercial_message'],
			'footer'              => $f['footer'] ?: ( $cfg['fne_footer'] ?: ( 'NCC : ' . $cfg['fne_ncc'] ) ),
			'foreignCurrency'     => '',
			'foreignCurrencyRate' => 0,
			'items'               => $items,
			'customTaxes'         => array(),
			'discount'            => 0,
		);
		if ( 'B2B' === $payload['template'] && $cli && ! empty( $cli['ncc'] ) ) {
			$payload['clientNcc'] = $cli['ncc'];
		}
		return $payload;
	}

	/** POST JSON via flux (pas de dépendance cURL). @return array(code,body,error) */
	protected static function http( $url, $apiKey, $json, $timeout = 30 ) {
		$opts = array(
			'http' => array(
				'method'        => 'POST',
				'header'        => "Content-Type: application/json\r\nAccept: application/json\r\nAuthorization: Bearer " . $apiKey . "\r\n",
				'content'       => $json,
				'timeout'       => $timeout,
				'ignore_errors' => true,
				// Aucune redirection suivie (1.801.1) : un Bearer ne se
				// renvoie pas à l'aveugle vers l'hôte qu'un 301 désigne, et une
				// redirection silencieuse masquerait une adresse fautive.
				'follow_location' => 0,
				'max_redirects'   => 1,
			),
		);
		if ( 0 === stripos( $url, 'https://' ) ) {
			$opts['ssl'] = array( 'verify_peer' => true, 'verify_peer_name' => true );
		}
		$ctx  = stream_context_create( $opts );
		$body = @file_get_contents( $url, false, $ctx );
		if ( false === $body ) {
			$e = error_get_last();
			return array( 0, '', $e['message'] ?? 'connexion impossible' );
		}
		$code = 0;
		// Voir Core/Http.php : $http_response_header est dépréciée en PHP 8.5
		// et son avertissement pollue la sortie. http_get_last_response_headers()
		// la remplace depuis 8.4 ; repli sur la variable magique en deçà.
		$entetes = function_exists( 'http_get_last_response_headers' )
			? (array) http_get_last_response_headers()
			: ( $http_response_header ?? array() );
		$location = '';
		foreach ( $entetes as $h ) {
			if ( preg_match( '#^HTTP/\S+\s+(\d{3})#', $h, $m ) ) { $code = (int) $m[1]; }
			if ( preg_match( '#^Location:\s*(.+)$#i', $h, $m ) ) { $location = trim( $m[1] ); }
		}
		if ( in_array( $code, array( 301, 302, 307, 308 ), true ) ) {
			return array( $code, $body, 'l\'adresse renvoie vers ' . ( $location ?: 'une autre adresse' ) . ' : corrigez-la dans les paramètres FNE plutôt que de la suivre à l\'aveugle (la clé ne doit pas partir ailleurs).' );
		}
		return array( $code, $body, null );
	}

	/** Explication publique d'un code d'erreur HTTP — utilisée par l'écran et par le harnais. */
	public static function expliquerErreur( $code, $resp = array(), $raw = '' ) {
		return self::errorMessage( $code, (array) $resp, (string) $raw, self::config() );
	}

	protected static function errorMessage( $code, $resp, $raw, $cfg ) {
		$parts = array( "HTTP {$code}" );
		/*
		 * 1.801.0 — « HTTP 404 | Not Found » ne disait pas QUOI était
		 * introuvable, et se lisait comme une panne de la facture. C'est
		 * l'ADRESSE qui est introuvable : la requête n'a jamais atteint le
		 * service de signature. On nomme l'adresse appelée et la marche à
		 * suivre, au lieu de laisser chercher.
		 */
		if ( in_array( (int) $code, array( 404, 405 ), true ) ) {
			$parts[] = 'adresse inconnue du serveur : ' . self::endpointSign()
				. ' — la facture n\'est pas en cause, seul le chemin de l\'API l\'est. Corrigez l\'adresse dans Facturation › Paramètres FNE :'
				. ' production ' . self::URL_PRODUCTION . ' (le « www. » est indispensable), bac à sable ' . self::URL_TEST . '.';
		}
		if ( $code >= 500 ) { $parts[] = 'la plateforme FNE est indisponible : la facture reste valide, relancez la certification plus tard.'; }
		if ( isset( $resp['error'] ) && 'invoice_signing_error' === $resp['error'] ) {
			$parts[] = "Causes possibles : solde de stickers DGI épuisé ; ou l'établissement « {$cfg['fne_establishment']} » / le point de vente ne correspondent pas exactement aux noms enregistrés dans votre espace FNE ; ou clé API non activée pour la signature.";
		}
		if ( isset( $resp['message'] ) ) { $parts[] = (string) $resp['message']; }
		if ( isset( $resp['errors'] ) && is_array( $resp['errors'] ) ) {
			foreach ( $resp['errors'] as $field => $msgs ) {
				$msgs = is_array( $msgs ) ? implode( ', ', $msgs ) : $msgs;
				$parts[] = "{$field} : {$msgs}";
			}
		}
		if ( ! $resp && $raw ) { $parts[] = 'Réponse : ' . substr( strip_tags( $raw ), 0, 300 ); }
		return implode( ' | ', $parts );
	}
}

/** json_encode portable (sans dépendance WP en contexte autonome). */
if ( ! function_exists( 'wp_json_safe' ) ) {
	function wp_json_safe( $data ) {
		return json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	}
}
