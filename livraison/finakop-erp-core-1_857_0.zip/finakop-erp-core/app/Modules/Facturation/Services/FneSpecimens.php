<?php
/**
 * SPÉCIMENS FNE — DOSSIER DE VALIDATION DGI (1.802.0).
 *
 * ═════════════════════════════════════════════════════════════════════════
 *  À QUOI ÇA SERT
 * ═════════════════════════════════════════════════════════════════════════
 *  Avant de délivrer une clé de PRODUCTION, la DGI demande à chaque
 *  contribuable de produire, dans son bac à sable, un jeu de factures
 *  certifiées — les « spécimens » — et de les lui transmettre. Tant que ce
 *  dossier n'est pas validé, aucune facture normalisée ne peut être émise.
 *
 *  Ce service fabrique ce dossier : factures de vente (B2C et B2B, espèces et
 *  virement, avec et sans TVA), puis les AVOIRS correspondants — la DGI
 *  vérifie l'annulation autant que la vente —, les certifie contre le bac à
 *  sable, et exporte le tout en un fichier à joindre au courriel de demande.
 *
 *  TROIS GARDE-FOUS, parce qu'un jeu d'essai n'a rien à faire dans une
 *  comptabilité :
 *    1. la génération est REFUSÉE hors du bac à sable — on ne consomme pas
 *       les stickers de production, et on ne certifie pas de fausses ventes
 *       au nom réel de la société ;
 *    2. un spécimen n'est pas comptabilisable : le produit n'existe pas, la
 *       créance non plus ;
 *    3. une fois la clé de production obtenue, tout se supprime d'un geste.
 *
 *  Les jeux de données sont NEUTRES et valables pour n'importe quelle
 *  société : clients fictifs, libellés génériques, montants ronds. Rien de
 *  propre à un dossier — c'est ce qui rend l'outil réutilisable.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_FneSpecimens {

	protected static $ready = array();

	/** Courriel de dépôt du dossier chez la DGI. */
	const CONTACT_DGI = 'support.fne@dgi.gouv.ci';

	public static function ensure() {
		$cle = FKC_DB::file();
		if ( isset( self::$ready[ $cle ] ) ) { return; }
		self::$ready[ $cle ] = true;
		try {
			$cols = array_column( FKC_DB::q( 'PRAGMA table_info(factures)' )->fetchAll(), 'name' );
			if ( $cols && ! in_array( 'specimen', $cols, true ) ) {
				FKC_DB::conn()->exec( 'ALTER TABLE factures ADD COLUMN specimen INTEGER NOT NULL DEFAULT 0' );
			}
			if ( $cols && ! in_array( 'specimen_cle', $cols, true ) ) {
				FKC_DB::conn()->exec( 'ALTER TABLE factures ADD COLUMN specimen_cle TEXT NOT NULL DEFAULT \'\'' );
			}
		} catch ( \Throwable $e ) {}
	}

	/**
	 * LES CAS DEMANDÉS. Chacun montre à la DGI une situation différente :
	 * particulier au comptant, entreprise avec NCC, opération exonérée,
	 * plusieurs lignes, quantités et unités. Les montants sont ronds pour que
	 * la lecture du dossier soit immédiate.
	 */
	public static function modeles() {
		return array(
			array(
				'cle' => 'b2c_especes', 'libelle' => 'Vente à un particulier, payée en espèces',
				'client' => array( 'nom' => 'Client Particulier (spécimen)', 'telephone' => '0700000001', 'email' => 'specimen1@example.ci' ),
				'template' => 'B2C', 'payment_method' => 'cash',
				'lignes' => array( array( 'designation' => 'Prestation de service - spécimen', 'quantite' => 1, 'pu_ht' => 50000, 'tva_code' => 'TVA' ) ),
			),
			array(
				'cle' => 'b2c_multi', 'libelle' => 'Vente à un particulier, plusieurs lignes et quantités',
				'client' => array( 'nom' => 'Client Détail (spécimen)', 'telephone' => '0700000002', 'email' => 'specimen2@example.ci' ),
				'template' => 'B2C', 'payment_method' => 'mobile-money',
				'lignes' => array(
					array( 'designation' => 'Article A - spécimen', 'quantite' => 3, 'pu_ht' => 15000, 'tva_code' => 'TVA' ),
					array( 'designation' => 'Article B - spécimen', 'quantite' => 2, 'pu_ht' => 7500, 'tva_code' => 'TVA' ),
				),
			),
			array(
				'cle' => 'b2b_virement', 'libelle' => 'Vente à une entreprise (NCC), payée par virement',
				'client' => array( 'nom' => 'Entreprise Cliente SARL (spécimen)', 'telephone' => '0700000003', 'email' => 'specimen3@example.ci', 'ncc' => '1234567A' ),
				'template' => 'B2B', 'payment_method' => 'bank-transfer',
				'lignes' => array( array( 'designation' => 'Prestation professionnelle - spécimen', 'quantite' => 1, 'pu_ht' => 500000, 'tva_code' => 'TVA' ) ),
			),
			array(
				'cle' => 'b2b_cheque', 'libelle' => 'Vente à une entreprise (NCC), payée par chèque',
				'client' => array( 'nom' => 'Société Partenaire SA (spécimen)', 'telephone' => '0700000004', 'email' => 'specimen4@example.ci', 'ncc' => '7654321B' ),
				'template' => 'B2B', 'payment_method' => 'check',
				'lignes' => array( array( 'designation' => 'Fourniture - spécimen', 'quantite' => 10, 'pu_ht' => 25000, 'tva_code' => 'TVA' ) ),
			),
			array(
				'cle' => 'exonere', 'libelle' => 'Opération exonérée de TVA',
				'client' => array( 'nom' => 'Organisme Exonéré (spécimen)', 'telephone' => '0700000005', 'email' => 'specimen5@example.ci', 'ncc' => '2468135C' ),
				'template' => 'B2B', 'payment_method' => 'bank-transfer',
				'lignes' => array( array( 'designation' => 'Opération exonérée - spécimen', 'quantite' => 1, 'pu_ht' => 300000, 'tva_code' => 'TVAD' ) ),
			),
		);
	}

	/** Les deux ventes dont on tire un avoir : une B2C et une B2B. */
	public static function clesAvoir() {
		return array( 'b2c_especes', 'b2b_virement' );
	}

	/* ══ Génération ══════════════════════════════════════════════════════ */

	protected static function bacASable() {
		return false !== strpos( (string) FKC_Fne::normaliserUrl( FKC_Fne::config()['fne_api_url'] ), '54.247.95.108' );
	}

	protected static function client( array $d ) {
		$nom = (string) $d['nom'];
		try {
			$ex = FKC_DB::q( 'SELECT id FROM clients WHERE nom=? LIMIT 1', array( $nom ) )->fetchColumn();
			if ( $ex ) { return (int) $ex; }
		} catch ( \Throwable $e ) {}
		return (int) FKC_Client::create( array(
			'nom' => $nom, 'type' => isset( $d['ncc'] ) ? 'B2B' : 'B2C',
			'telephone' => $d['telephone'] ?? '', 'email' => $d['email'] ?? '', 'ncc' => $d['ncc'] ?? '',
		) );
	}

	/**
	 * Crée les factures de vente du dossier et les certifie contre le bac à
	 * sable. Idempotent : un modèle déjà généré n'est pas refait.
	 *
	 * @return array{0:bool,1:string,2:array}
	 */
	public static function genererVentes( $date = null ) {
		self::ensure();
		if ( ! self::bacASable() ) {
			return array( false, 'Génération refusée : les spécimens se produisent dans le BAC À SABLE de la DGI (' . FKC_Fne::URL_TEST
				. '). En production, ils consommeraient vos stickers et certifieraient de fausses ventes à votre nom.', array() );
		}
		if ( ! FKC_Fne::isConfigured() ) {
			return array( false, 'Renseignez d\'abord la clé API de test et le nom de l\'établissement dans Facturation › Paramètres FNE.', array() );
		}
		$date = FKC_RnPeriode::estDate( $date ?? '' ) ? $date : date( 'Y-m-d' );
		$faits = self::parCle();
		$res = array(); $crees = 0; $certifies = 0;
		foreach ( self::modeles() as $m ) {
			if ( isset( $faits[ $m['cle'] ] ) ) { $res[] = array( 'cle' => $m['cle'], 'statut' => 'existant', 'facture' => $faits[ $m['cle'] ]['numero'] ); continue; }
			$cid = self::client( $m['client'] );
			list( $ok, $msg, $fid ) = FKC_Facture::save( array(
				'client_id' => $cid, 'client_nom' => $m['client']['nom'], 'date_facture' => $date,
				'echeance' => $date, 'devise' => 'XOF', 'payment_method' => $m['payment_method'],
				'template' => $m['template'], 'note' => 'SPÉCIMEN DE VALIDATION FNE — ' . $m['libelle'],
			), $m['lignes'] );
			if ( ! $ok ) { $res[] = array( 'cle' => $m['cle'], 'statut' => 'echec', 'erreur' => $msg ); continue; }
			FKC_DB::q( 'UPDATE factures SET specimen=1, specimen_cle=? WHERE id=?', array( $m['cle'], (int) $fid ) );
			$crees++;
			$c = FKC_Fne::certify( $fid );
			if ( ! empty( $c['ok'] ) ) { $certifies++; $res[] = array( 'cle' => $m['cle'], 'statut' => 'certifie', 'facture_id' => (int) $fid ); }
			else { $res[] = array( 'cle' => $m['cle'], 'statut' => 'non_certifie', 'facture_id' => (int) $fid, 'erreur' => (string) ( $c['error'] ?? '' ) ); }
		}
		$msg = $crees . ' facture(s) de vente créée(s), ' . $certifies . ' certifiée(s) par le bac à sable.';
		$ech = array_filter( $res, function ( $r ) { return in_array( $r['statut'], array( 'echec', 'non_certifie' ), true ); } );
		if ( $ech ) { $msg .= ' ' . count( $ech ) . ' en échec : ' . implode( ' | ', array_column( $ech, 'erreur' ) ); }
		return array( true, $msg, $res );
	}

	/**
	 * Crée les avoirs du dossier à partir des ventes certifiées, et les
	 * certifie à leur tour (endpoint /refund de la DGI).
	 */
	public static function genererAvoirs() {
		self::ensure();
		if ( ! self::bacASable() ) { return array( false, 'Génération refusée hors du bac à sable DGI.', array() ); }
		$ventes = self::parCle();
		$res = array(); $n = 0;
		foreach ( self::clesAvoir() as $cle ) {
			if ( empty( $ventes[ $cle ] ) ) { $res[] = array( 'cle' => $cle, 'statut' => 'vente_absente' ); continue; }
			$v = $ventes[ $cle ];
			if ( 'CERTIFIE' !== (string) $v['fne_status'] ) { $res[] = array( 'cle' => $cle, 'statut' => 'vente_non_certifiee', 'facture' => $v['numero'] ); continue; }
			$deja = FKC_DB::q( 'SELECT id FROM factures WHERE avoir_origine_id=? LIMIT 1', array( (int) $v['id'] ) )->fetchColumn();
			if ( $deja ) {
				$res[] = array( 'cle' => $cle, 'statut' => 'existant', 'facture_id' => (int) $deja );
				continue;
			}
			list( $ok, $msg, $aid ) = FKC_Facture::createAvoir( (int) $v['id'] );
			if ( ! $ok ) { $res[] = array( 'cle' => $cle, 'statut' => 'echec', 'erreur' => $msg ); continue; }
			FKC_DB::q( 'UPDATE factures SET specimen=1, specimen_cle=? WHERE id=?', array( 'avoir_' . $cle, (int) $aid ) );
			$r = FKC_Fne::refund( (int) $aid );
			$n++;
			$res[] = array( 'cle' => 'avoir_' . $cle, 'statut' => ! empty( $r['ok'] ) ? 'certifie' : 'non_certifie',
				'facture_id' => (int) $aid, 'erreur' => (string) ( $r['error'] ?? '' ) );
		}
		$ko = array_filter( $res, function ( $r ) { return in_array( $r['statut'], array( 'echec', 'non_certifie' ), true ); } );
		return array( true, $n . ' avoir(s) créé(s).' . ( $ko ? ' ' . count( $ko ) . ' en échec : ' . implode( ' | ', array_filter( array_column( $ko, 'erreur' ) ) ) : '' ), $res );
	}

	/* ══ État et dossier ═════════════════════════════════════════════════ */

	/** Spécimens indexés par clé de modèle. */
	public static function parCle() {
		self::ensure();
		$out = array();
		try {
			foreach ( FKC_DB::q( 'SELECT * FROM factures WHERE specimen=1 ORDER BY id' )->fetchAll() as $f ) {
				$out[ (string) $f['specimen_cle'] ] = $f;
			}
		} catch ( \Throwable $e ) {}
		return $out;
	}

	public static function lister() {
		self::ensure();
		try { return FKC_DB::q( 'SELECT * FROM factures WHERE specimen=1 ORDER BY type DESC, id' )->fetchAll(); }
		catch ( \Throwable $e ) { return array(); }
	}

	/** Où en est le dossier ? */
	public static function etat() {
		$sp = self::lister();
		$ventes = 0; $ventesCert = 0; $avoirs = 0; $avoirsCert = 0;
		foreach ( $sp as $f ) {
			$avoir = 'avoir' === (string) ( $f['type'] ?? 'facture' );
			if ( $avoir ) { $avoirs++; if ( 'CERTIFIE' === $f['fne_status'] ) { $avoirsCert++; } }
			else { $ventes++; if ( 'CERTIFIE' === $f['fne_status'] ) { $ventesCert++; } }
		}
		$attendusV = count( self::modeles() ); $attendusA = count( self::clesAvoir() );
		$manques = array();
		if ( $ventesCert < $attendusV ) { $manques[] = ( $attendusV - $ventesCert ) . ' facture(s) de vente à certifier'; }
		if ( $avoirsCert < $attendusA ) { $manques[] = ( $attendusA - $avoirsCert ) . ' avoir(s) à certifier'; }
		return array(
			'bac_a_sable' => self::bacASable(), 'environnement' => FKC_Fne::environment(),
			'ventes' => $ventes, 'ventes_certifiees' => $ventesCert, 'ventes_attendues' => $attendusV,
			'avoirs' => $avoirs, 'avoirs_certifies' => $avoirsCert, 'avoirs_attendus' => $attendusA,
			'manques' => $manques, 'complet' => ! $manques && $ventesCert > 0,
		);
	}

	/**
	 * LE DOSSIER À ENVOYER. Tout ce que la DGI demande pour rapprocher les
	 * spécimens de son propre journal : identification du contribuable,
	 * environnement utilisé, et pour chaque pièce son numéro, son type, ses
	 * montants, sa référence FNE, son jeton et son lien de vérification.
	 */
	public static function dossier() {
		$cfg = FKC_Fne::config();
		$etat = self::etat();
		$pieces = array();
		foreach ( self::lister() as $f ) {
			$pieces[] = array(
				'numero' => $f['numero'],
				'type' => 'avoir' === (string) ( $f['type'] ?? 'facture' ) ? 'avoir' : 'facture',
				'cas' => (string) $f['specimen_cle'],
				'date' => $f['date_facture'],
				'client' => $f['client_nom'],
				'template' => $f['template'],
				'mode_paiement' => $f['payment_method'],
				'montant_ht' => (float) $f['montant_ht'],
				'montant_tva' => (float) $f['montant_tva'],
				'montant_ttc' => (float) $f['montant_ttc'],
				'fne_statut' => $f['fne_status'],
				'fne_reference' => (string) $f['fne_reference'],
				'fne_token' => (string) $f['fne_token'],
				'fne_verification' => ( 'CERTIFIE' === $f['fne_status'] && class_exists( 'FKC_Fne' ) ) ? FKC_Fne::verifyUrl( $f ) : '',
				'fne_erreur' => (string) $f['fne_error'],
			);
		}
		return array(
			'genere_le' => date( 'c' ),
			'logiciel' => array( 'nom' => 'FinaKop ERP Core', 'version' => defined( 'FKC_VERSION' ) ? FKC_VERSION : '' ),
			'contribuable' => array(
				'raison_sociale' => class_exists( 'FKC_Tenant' ) ? (string) ( FKC_Tenant::current()['nom'] ?? '' ) : '',
				'ncc' => (string) $cfg['fne_ncc'],
				'etablissement' => (string) $cfg['fne_establishment'],
				'point_de_vente' => (string) $cfg['fne_point_of_sale'],
			),
			'environnement' => array(
				'nom' => FKC_Fne::environment(),
				'api' => FKC_Fne::endpointSign(),
				'cle_api_empreinte' => FKC_Fne::empreinte( 'fne_api_key' ),
			),
			'etat' => $etat,
			'destinataire' => self::CONTACT_DGI,
			'pieces' => $pieces,
		);
	}

	/** Nettoyage après obtention de la clé de production. */
	public static function supprimer() {
		self::ensure();
		$sp = self::lister();
		if ( ! $sp ) { return array( false, 'Aucun spécimen à supprimer.' ); }
		$comptabilisees = array_filter( $sp, function ( $f ) { return ! empty( $f['ecriture_id'] ); } );
		if ( $comptabilisees ) {
			return array( false, count( $comptabilisees ) . ' spécimen(s) portent une écriture comptable : contre-passez-la avant de les supprimer.' );
		}
		$n = 0;
		foreach ( $sp as $f ) {
			FKC_DB::q( 'DELETE FROM facture_lignes WHERE facture_id=?', array( (int) $f['id'] ) );
			FKC_DB::q( 'DELETE FROM factures WHERE id=?', array( (int) $f['id'] ) );
			$n++;
		}
		return array( true, $n . ' spécimen(s) supprimé(s). Les clients fictifs restent en base : supprimez-les depuis la fiche client si vous le souhaitez.' );
	}
}
