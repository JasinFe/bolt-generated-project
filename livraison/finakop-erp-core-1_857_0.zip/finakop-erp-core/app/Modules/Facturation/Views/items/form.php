<?php /** @var array|null $item @var string $sens @var array $taxes @var array $errors */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'facturation', 'back' => 'facturation/items', 'backLabel' => 'Articles' ) );
$ed = (bool) ( $item && ! empty( $item['id'] ) );
$v  = function ( $k, $d = '' ) use ( $item ) { return e( $item[ $k ] ?? $d ); };
$action = $ed ? url( 'referentiels/items/' . (int) $item['id'] ) : url( 'referentiels/items' );
?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:720px"><div class="card-head">
	<h2><?= $ed ? 'Modifier l\'item de facturation' : 'Nouvel item de facturation' ?></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/items' ) ) ?>">← Retour</a>
</div><div class="card-body">
<form method="post" action="<?= e( $action ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Sens *</span>
			<select name="sens">
				<option value="vente" <?= 'vente' === $sens ? 'selected' : '' ?>>Vente (produit 70x)</option>
				<option value="achat" <?= 'achat' === $sens ? 'selected' : '' ?>>Achat (charge 60x/61x/62x)</option>
			</select>
		</label>
		<label class="fld"><span>Code (auto si vide)</span><input name="code" value="<?= $v( 'code' ) ?>" placeholder="ex. VTE-PRESTA"></label>
	</div>
	<label class="fld"><span>Libellé *</span><input name="libelle" value="<?= $v( 'libelle' ) ?>" required placeholder="ex. Prestations de services"></label>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
		<label class="fld"><span>Compte comptable *</span><input name="compte" value="<?= $v( 'compte' ) ?>" required placeholder="ex. 706000"></label>
		<label class="fld"><span>TVA par défaut</span>
			<select name="tva_code">
				<?php foreach ( $taxes as $code => $t ) : ?>
					<option value="<?= e( $code ) ?>" <?= ( $item && ( $item['tva_code'] ?? 'TVA' ) === $code ) ? 'selected' : ( ( ! $item && 'TVA' === $code ) ? 'selected' : '' ) ?>><?= e( $t['label'] ?? $code ) ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<label class="fld"><span>PU HT par défaut</span><input type="number" step="0.01" name="pu_ht" value="<?= $v( 'pu_ht' ) ?>" placeholder="0"></label>
	</div>
	<label class="chk" style="margin-top:4px;display:flex;align-items:center;gap:8px">
		<input type="hidden" name="actif" value="0"><input type="checkbox" name="actif" value="1" <?= ( ! $item || ! empty( $item['actif'] ) ) ? 'checked' : '' ?> style="width:auto"> Actif (proposé à la facturation)
	</label>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $ed ? 'Enregistrer' : 'Créer l\'item' ?></button><a class="btn btn-ghost" href="<?= e( url( 'referentiels/items' ) ) ?>">Annuler</a></div>
</form>
</div></div>
<p class="help">Le <strong>compte</strong> détermine l'imputation comptable : à la comptabilisation d'une facture, le montant HT de chaque ligne est porté au crédit (ventes) ou au débit (achats) du compte de l'item choisi. Comptes SYSCOHADA usuels — ventes : 701 marchandises, 702 produits finis, 704 travaux, 706 prestations, 707 accessoires ; achats : 601 marchandises, 602 matières, 605 énergie, 611 transport, 622 services extérieurs, 632 honoraires.</p>
