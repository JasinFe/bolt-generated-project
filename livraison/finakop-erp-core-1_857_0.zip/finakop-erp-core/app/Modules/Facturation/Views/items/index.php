<?php /** @var array $ventes @var array $achats @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$table = function ( $rows, $sens ) { ?>
	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : code, libellé, compte…' ) ); ?>
<div class="card card-flush" style="margin-bottom:18px">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
			<h2><?= 'vente' === $sens ? '🟢 Items de vente (produits 70x)' : '🟠 Items d\'achat (charges 60x/61x/62x)' ?></h2>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/items/nouveau?sens=' . $sens ) ) ?>">+ Ajouter</a>
		</div>
		<table class="table">
			<thead><tr><th>Code</th><th>Libellé</th><th>Compte</th><th>TVA</th><th class="num">PU HT défaut</th><th>Type</th><th></th></tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?><tr><td colspan="7" class="empty">Aucun item.</td></tr>
			<?php else : foreach ( $rows as $it ) : ?>
				<tr>
					<td><span class="code"><?= e( $it['code'] ) ?></span></td>
					<td><strong><?= e( $it['libelle'] ) ?></strong></td>
					<td class="mono"><?= e( $it['compte'] ) ?></td>
					<td><?= e( $it['tva_code'] ) ?></td>
					<td class="num"><?= $it['pu_ht'] > 0 ? e( fkc_money( $it['pu_ht'] ) ) : '—' ?></td>
					<td><?php if ( 0 === strpos( (string) $it['code'], 'CRE-' ) ) : ?><span class="modbadge b-on" style="background:rgba(155,123,224,.18);color:#b9a4ec;border-color:rgba(155,123,224,.4)">Creative</span><?php elseif ( $it['standard'] ) : ?><span class="modbadge b-on">Standard</span><?php else : ?><span class="modbadge">Personnalisé</span><?php endif; ?><?= $it['actif'] ? '' : ' <span class="muted">(inactif)</span>' ?></td>
					<td class="right" style="white-space:nowrap">
						<a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/items/' . (int) $it['id'] . '/modifier' ) ) ?>">Éditer</a>
						<?php if ( ! $it['standard'] ) : ?>
						<form method="post" action="<?= e( url( 'referentiels/items/' . (int) $it['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer cet item ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" style="color:var(--danger)">Suppr</button></form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
	</div>
<?php }; ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted" style="flex-basis:100%">Items de facturation — chaque item est rattaché à un compte comptable, sélectionnable lors de la saisie d'une facture (vente) ou d'un achat (fournisseur).</span>
</div>
<?php $table( $ventes, 'vente' ); ?>
<?php $table( $achats, 'achat' ); ?>
<p class="help">Les items <strong>standard</strong> sont fournis par défaut (non supprimables). Ajoutez vos propres items pour des comptes spécifiques. À la facturation, choisir un item renseigne automatiquement la désignation, le prix, la TVA et le <strong>compte de produit/charge</strong> utilisé à la comptabilisation.</p>
