<?php /** @var array $facture @var array $taxes @var array $methods @var bool $fneReady @var string $fneEnv @var string $verifyUrl @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f = $facture; $st = $f['fne_status'];
$methodLbl = $methods[ $f['payment_method'] ] ?? $f['payment_method']; ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<?php if ( ! empty( $avisEncours ) && in_array( $avisEncours['avis'] ?? '', array( 'attention', 'refus' ), true ) ) : ?>
	<div class="alert alert-<?= 'refus' === $avisEncours['avis'] ? 'err' : 'warn' ?>"><strong>Contrôle d'encours :</strong> <?= e( $avisEncours['message'] ?? '' ) ?>
		<?php if ( 'refus' === $avisEncours['avis'] ) : ?> L'émission de cette facture est suspendue ; vous pouvez passer outre en le cochant au moment d'émettre.<?php endif; ?></div>
<?php endif; ?>

<?php
/*
 * LE MILLÉSIME DU NUMÉRO NE CORRESPOND PAS À LA DATE (1.728.0).
 *
 * Le formulaire attribuait le numéro à l'OUVERTURE de l'écran, avant qu'une
 * date soit saisie : une facture de novembre 2025 créée en 2026 repartait en
 * « FAC-2026-0001 ». Les factures créées depuis le correctif ne connaissent
 * plus ce cas ; celles qui existent déjà, si — d'où ce bandeau, et le seul
 * geste qui les répare.
 */
if ( ! empty( $millesimeIncoherent ) ) : ?>
	<div class="alert alert-warn">
		<strong>Le numéro ne correspond pas à l'exercice de la facture.</strong>
		Cette facture est datée du <?= e( date( 'd/m/Y', strtotime( (string) $f['date_facture'] ) ) ) ?>
		mais porte un numéro de l'exercice <?= e( preg_replace( '/^[A-Z]+-(\d{4}).*$/', '$1', (string) $f['numero'] ) ) ?>.
		Elle laisse donc un trou dans la série de son propre exercice et une avance dans l'autre.
		<?php if ( 'brouillon' === (string) $f['statut'] && empty( $f['ecriture_id'] )
			&& 'NON_CERTIFIE' === (string) ( $f['fne_status'] ?? 'NON_CERTIFIE' ) ) : ?>
			<div style="margin-top:10px">
				<form method="post" action="<?= e( url( 'facturation/factures/' . (int) $f['id'] . '/renumeroter' ) ) ?>"
					onsubmit="return confirm('Réattribuer un numéro dans la série de <?= e( date( 'Y', strtotime( (string) $f['date_facture'] ) ) ) ?> ?')">
					<?= FKC_Csrf::field() ?>
					<button class="btn btn-primary btn-sm">Renuméroter dans le bon exercice</button>
				</form>
			</div>
		<?php else : ?>
			<br><span class="muted">Cette facture est comptabilisée, certifiée ou réglée : son numéro ne peut plus
			changer. Un document sorti ne se renumérote pas — mentionnez l'écart au dossier de clôture.</span>
		<?php endif; ?>
	</div>
<?php endif; ?>

<div class="fac-layout">
	<!-- Facture -->
	<div class="card" style="margin:0">
		<div class="card-head">
			<h2>Facture <span class="code"><?= e( $f['numero'] ) ?></span></h2>
			<div style="display:flex;gap:8px">
				<?php
				/* 1.850.0 — trois situations, trois gestes :
				   non comptabilisée → Modifier (même numéro) ou Annuler (sans avoir) ;
				   comptabilisée → Corriger = avoir + facture corrigée pré-remplie ;
				   annulée ou déjà sous avoir → Ressaisir la facture corrigée. */
				$estFacture = 'avoir' !== ( $f['type'] ?? 'facture' );
				$certifiee  = 'CERTIFIE' === ( $f['fne_status'] ?? '' );
				$avoirExistant = $avoirExistant ?? null;
				?>
				<?php if ( FKC_Facture::editable( $f ) ) : ?>
					<a class="btn btn-primary btn-sm" href="<?= e( url( 'facturation/factures/' . $f['id'] . '/modifier' ) ) ?>">✏️ Modifier</a>
					<?php if ( $estFacture ) : ?>
					<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/annuler' ) ) ?>" style="margin:0" onsubmit="return confirm('Annuler cette facture ? Elle n\'est pas comptabilisée : aucun avoir n\'est nécessaire, son numéro reste dans la série, marqué annulé.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">⊘ Annuler</button></form>
					<?php endif; ?>
				<?php elseif ( $estFacture && ! $certifiee && ! empty( $f['ecriture_id'] ) && ! $avoirExistant && 'annulee' !== ( $f['statut'] ?? '' ) ) : ?>
					<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/corriger' ) ) ?>" style="margin:0" onsubmit="return confirm('Corriger cette facture comptabilisée ?\n\nUn avoir l\'annulera, puis la facture corrigée s\'ouvrira pré-remplie. Elle recevra un nouveau numéro : une facture de vente émise ne se réécrit pas.')"><?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" type="submit">✏️ Corriger</button></form>
				<?php elseif ( $estFacture && ( $avoirExistant || 'annulee' === ( $f['statut'] ?? '' ) ) ) : ?>
					<a class="btn btn-primary btn-sm" href="<?= e( url( 'facturation/factures/' . $f['id'] . '/ressaisir' ) ) ?>">✏️ Ressaisir la facture corrigée</a>
				<?php endif; ?>
				<?php if ( $estFacture && 'annulee' !== ( $f['statut'] ?? '' ) && ! FKC_Facture::editable( $f ) && ! $avoirExistant && ( ! empty( $f['ecriture_id'] ) || $certifiee ) ) : ?>
					<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/avoir-note' ) ) ?>" style="margin:0" onsubmit="return confirm('Créer une facture d\'avoir (note de crédit) annulant cette facture ? Un nouveau document AV-… sera généré.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">↩️ Créer un avoir</button></form>
				<?php endif; ?>
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/factures/' . $f['id'] . '/imprimer' ) ) ?>" target="_blank">🖨️ Imprimer / PDF</a>
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/factures' ) ) ?>">← Retour</a>
			</div>
		</div>
		<div class="card-body">
			<div class="meta">
				<div><span class="stat-label">Date</span><strong><?= e( date( 'd/m/Y', strtotime( $f['date_facture'] ) ) ) ?></strong></div>
				<div><span class="stat-label">Client</span><strong><?= e( $f['client_nom'] ) ?></strong></div>
				<div><span class="stat-label">Modèle</span><strong><?= e( $f['template'] ) ?></strong></div>
				<div><span class="stat-label">Règlement</span><strong><?= e( $methodLbl ) ?></strong></div>
			</div>
			<table class="table bordered">
				<thead><tr><th>Désignation</th><th class="num">Qté</th><th class="num">PU HT</th><th>TVA</th><th class="num">Montant HT</th></tr></thead>
				<tbody>
				<?php foreach ( $f['lignes'] as $l ) : ?>
					<tr>
						<td><?= e( $l['designation'] ) ?></td>
						<td class="num"><?= e( fkc_money( $l['quantite'] ) ) ?></td>
						<td class="num"><?= e( fkc_money( $l['pu_ht'] ) ) ?></td>
						<td class="muted"><?= e( $l['tva_code'] ) ?> (<?= (int) $l['tva_taux'] ?>%)</td>
						<td class="num"><?= e( fkc_money( $l['montant_ht'] ) ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot>
					<tr class="total"><td colspan="4" class="right">Total HT</td><td class="num"><?= e( fkc_money( $f['montant_ht'] ) ) ?></td></tr>
					<tr class="total"><td colspan="4" class="right">TVA</td><td class="num"><?= e( fkc_money( $f['montant_tva'] ) ) ?></td></tr>
					<tr class="total"><td colspan="4" class="right">Total TTC</td><td class="num" style="color:var(--orange)"><?= e( fkc_money( $f['montant_ttc'] ) ) ?> <?= e( $f['devise'] ) ?></td></tr>
				</tfoot>
			</table>

			<div class="compta-box">
				<?php if ( ! empty( $f['ecriture_id'] ) ) : ?>
					<span class="compta-ok">✓ Comptabilisée — écriture n°<?= (int) $f['ecriture_id'] ?>
						<a href="<?= e( url( 'comptabilite/ecritures/' . (int) $f['ecriture_id'] ) ) ?>">voir l'écriture</a></span>
				<?php elseif ( 'annulee' !== $f['statut'] ) : ?>
					<?php $wf = $wf ?? array( 'required' => false, 'state' => 'none', 'vid' => 0 ); $wfReq = ! empty( $wf['required'] ); $wfState = $wf['state'] ?? 'none'; $canComptaWf = ( ! $wfReq ) || 'approuve' === $wfState || FKC_Auth::isAdmin(); ?>
					<?php
					/*
					 * « NON COMPTABILISÉE » ÉTAIT UN MENSONGE PAR OMISSION (1.729.0).
					 *
					 * Quand la politique de comptabilisation range les ventes au
					 * journal temporaire — son réglage par défaut — l'écriture EST
					 * produite, mais elle attend d'être validée. L'écran disait
					 * pourtant « Non comptabilisée » et proposait à nouveau le
					 * bouton, qui répondait « déjà au brouillard ». L'utilisateur
					 * concluait que la comptabilisation échouait, et cherchait la
					 * panne dans la facturation — alors que tout attendait un clic,
					 * ailleurs, dans un écran qu'il ignorait.
					 */
					$auBrouillard = class_exists( 'FKC_Brouillard' )
						&& FKC_Brouillard::hasPendingFor( 'factures', (int) $f['id'] );
					?>
					<?php if ( $auBrouillard ) : ?>
						<span class="tag" style="background:var(--warn-bg);color:var(--warn)">⏳ Au journal temporaire</span>
						<span class="muted">L'écriture est produite et attend d'être validée : tant qu'elle l'est,
						elle ne compte ni dans le chiffre d'affaires, ni au compte de résultat.</span>
						<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/brouillard' ) ) ?>">Valider au journal temporaire</a>
					<?php else : ?>
						<span class="muted">Non comptabilisée</span>
					<?php endif; ?>
					<?php if ( $wfReq && 'approuve' === $wfState ) : ?>
						<span class="tag" style="background:var(--ok-bg);color:var(--ok)">✓ Validation approuvée</span>
					<?php elseif ( $wfReq && 'en_attente' === $wfState ) : ?>
						<span class="tag" style="background:var(--warn-bg);color:var(--warn)">Validation en attente</span>
						<a class="btn btn-ghost btn-sm" href="<?= e( url( 'validations/' . (int) $wf['vid'] ) ) ?>">Voir la demande</a>
					<?php elseif ( $wfReq ) : ?>
						<span class="tag" style="background:var(--warn-bg);color:var(--warn)"><?= 'refuse' === $wfState ? 'Validation refusée' : 'Validation requise (au-dessus du seuil)' ?></span>
						<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/demander-validation' ) ) ?>" style="margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Demander la validation</button></form>
					<?php endif; ?>
					<?php if ( $canComptaWf && ! $auBrouillard ) : ?>
					<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/comptabiliser' ) ) ?>" style="margin:0">
						<?= FKC_Csrf::field() ?>
						<?php if ( ! empty( $avisEncours ) && 'refus' === ( $avisEncours['avis'] ?? '' ) ) : ?><label style="display:inline-flex;gap:6px;align-items:center;font-size:.85em"><input type="checkbox" name="forcer_encours" value="1"> passer outre le contrôle d'encours</label><?php endif; ?>
						<button class="btn btn-ghost btn-sm" type="submit">Comptabiliser (journal VE)</button>
					</form>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<!-- Panneau FNE -->
	<div class="card fne-panel fne-<?= e( strtolower( $st ) ) ?>" style="margin:0">
		<div class="card-head"><h2>🧾 Facture Normalisée Électronique</h2>
			<span class="muted" style="font-size:11px">env. <?= e( $fneEnv ) ?></span></div>
		<div class="card-body">

		<?php if ( 'CERTIFIE' === $st ) : ?>
			<div class="fne-ok-head"><span class="fne-check">✓</span> Certifiée par la DGI</div>
			<table class="kv" style="margin-bottom:14px">
				<tr><th>Référence FNE</th><td><span class="code"><?= e( $f['fne_reference'] ) ?></span></td></tr>
				<tr><th>Certifiée le</th><td><?= e( $f['fne_certified_at'] ? date( 'd/m/Y H:i', strtotime( $f['fne_certified_at'] ) ) : '—' ) ?></td></tr>
				<?php if ( null !== $f['fne_balance_sticker'] ) : ?><tr><th>Stickers restants</th><td><?= e( fkc_money( $f['fne_balance_sticker'] ) ) ?></td></tr><?php endif; ?>
			</table>
			<div class="fne-qr-wrap">
				<div id="fne-qr" data-url="<?= e( $verifyUrl ) ?>"></div>
				<div class="fne-visuel">
					<div class="fne-visuel-tag">FNE</div>
					<div class="fne-visuel-sub">Scannez pour vérifier<br>l'authenticité sur e-impots.gouv.ci</div>
				</div>
			</div>
			<?php if ( ! empty( $f['fne_warning'] ) ) : ?><div class="alert alert-warn" style="margin:14px 0 0">⚠️ Stock de stickers bas — pensez à recharger sur votre espace FNE.</div><?php endif; ?>

			<div class="fne-avoir">
			<?php if ( ! empty( $f['fne_avoir_reference'] ) ) : ?>
				<div class="alert alert-warn" style="margin:0">⊘ <strong>Facture annulée par un avoir FNE</strong> — réf. avoir <span class="code"><?= e( $f['fne_avoir_reference'] ) ?></span><?= $f['fne_avoir_certified_at'] ? ' le ' . e( date( 'd/m/Y', strtotime( $f['fne_avoir_certified_at'] ) ) ) : '' ?>.</div>
			<?php else : ?>
				<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/avoir' ) ) ?>" onsubmit="return confirm('Émettre un avoir FNE et annuler cette facture ? Cette action est définitive côté DGI.')" style="margin:0">
					<?= FKC_Csrf::field() ?>
					<button class="btn btn-ghost btn-sm danger" type="submit">⊘ Créer un avoir (annulation FNE)</button>
				</form>
			<?php endif; ?>
			</div>
		<?php elseif ( 'ERROR' === $st ) : ?>
			<div class="alert alert-err" style="margin-bottom:14px"><?= e( $f['fne_error'] ?: 'Échec de la certification.' ) ?></div>
			<?php
			/*
			 * 1.801.0 — un échec dont la cause est l'ADRESSE de l'API se règle
			 * dans les paramètres, pas en réessayant : on le dit, et on y mène.
			 */
			$fneAdresse = class_exists( 'FKC_Fne' ) && preg_match( '/HTTP (404|405)/', (string) $f['fne_error'] );
			?>
			<?php if ( $fneAdresse ) : ?>
				<p class="help" style="margin:-8px 0 12px">L'adresse de l'API est inconnue du serveur : la facture n'est pas en cause.
					<a href="<?= e( url( 'facturation/fne' ) ) ?>">Corriger les paramètres FNE</a> avant de réessayer.</p>
			<?php endif; ?>
			<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/certifier' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<?php if ( ! empty( $avisEncours ) && 'refus' === ( $avisEncours['avis'] ?? '' ) ) : ?><label style="display:inline-flex;gap:6px;align-items:center;font-size:.85em"><input type="checkbox" name="forcer_encours" value="1"> passer outre le contrôle d'encours</label><?php endif; ?>
				<button class="btn btn-primary" type="submit" <?= $fneReady ? '' : 'disabled' ?>>Réessayer la certification</button>
			</form>
			<?php if ( ! $fneReady ) : ?><p class="help" style="margin-top:10px">Configurez d'abord la FNE. <a href="<?= e( url( 'facturation/fne' ) ) ?>">Paramètres FNE</a></p><?php endif; ?>

		<?php else : ?>
			<p class="help" style="margin:0 0 14px">Cette facture est en <strong>brouillon</strong>. Certifiez-la pour générer sa référence DGI, son QR code et son visuel FNE.</p>
			<?php if ( $fneReady ) : ?>
				<form method="post" action="<?= e( url( 'facturation/factures/' . $f['id'] . '/certifier' ) ) ?>">
					<?= FKC_Csrf::field() ?>
					<?php if ( ! empty( $avisEncours ) && 'refus' === ( $avisEncours['avis'] ?? '' ) ) : ?><label style="display:inline-flex;gap:6px;align-items:center;font-size:.85em"><input type="checkbox" name="forcer_encours" value="1"> passer outre le contrôle d'encours</label><?php endif; ?>
					<button class="btn btn-primary" type="submit">🔏 Certifier via la FNE</button>
				</form>
			<?php else : ?>
				<div class="alert alert-warn" style="margin:0">La certification FNE n'est pas configurée. <a href="<?= e( url( 'facturation/fne' ) ) ?>">Configurer la FNE</a></div>
			<?php endif; ?>
		<?php endif; ?>
		</div>
	</div>
</div>

<style>
.fac-layout{display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start}
@media(max-width:980px){.fac-layout{grid-template-columns:1fr}}
.fne-panel.fne-certifie{border-color:rgba(57,184,126,.4)}
.fne-panel.fne-error{border-color:rgba(229,103,95,.4)}
.fne-ok-head{display:flex;align-items:center;gap:10px;font-family:Syne,sans-serif;font-weight:800;font-size:16px;color:var(--ok);margin-bottom:14px}
.fne-check{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:var(--ok-bg);border:1px solid var(--ok)}
.fne-qr-wrap{display:flex;gap:14px;align-items:center;padding:14px;background:#fff;border-radius:12px}
.fne-qr-wrap #fne-qr{width:120px;height:120px;flex-shrink:0}
.fne-qr-wrap #fne-qr svg,.fne-qr-wrap #fne-qr img{width:120px;height:120px;display:block}
.fne-visuel{display:flex;flex-direction:column;gap:6px}
.fne-visuel-tag{display:inline-block;align-self:flex-start;background:linear-gradient(135deg,var(--blue),var(--blue-d));color:#fff;font-family:Syne,sans-serif;font-weight:800;letter-spacing:2px;padding:5px 12px;border-radius:7px;font-size:15px}
.fne-visuel-sub{color:#3a4660;font-size:11px;line-height:1.5;font-weight:600}
.modbadge.b-err{background:var(--danger-bg);color:var(--danger)}
.compta-box{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:14px;padding:12px 14px;background:var(--bg2);border:1px solid var(--line);border-radius:10px;font-size:13px}
.compta-ok{color:var(--ok);font-weight:600}.compta-ok a{color:var(--blue);text-decoration:underline;margin-left:8px;font-weight:600}
.fne-avoir{margin-top:14px;padding-top:14px;border-top:1px solid var(--line)}
</style>
<?php if ( 'CERTIFIE' === $st ) : ?>
<script src="<?= e( fkc_asset( 'js/qrcode.js' ) ) ?>"></script>
<script>
(function(){
  var el=document.getElementById('fne-qr'); if(!el||typeof qrcode==='undefined')return;
  try{ var q=qrcode(0,'M'); q.addData(el.getAttribute('data-url')); q.make();
    el.innerHTML=q.createSvgTag({cellSize:4,margin:0,scalable:true}); }catch(e){ el.textContent='QR indisponible'; }
})();
</script>
<?php endif; ?>

<?php FKC_View::partial( 'comptabilite::_pieces', array(
	'pieces'       => $pieces ?? array(),
	'piecesUpload' => 'facturation/factures/' . (int) $facture['id'] . '/pieces',
	'piecesBase'   => 'facturation/factures/piece',
) ); ?>
