<?php /** @var array $factures @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Proforma / devis — factures non encore certifiées (document non fiscal). <?= count( $factures ) ?> document(s).</span>
	<a class="btn btn-primary" href="<?= e( url( 'facturation/factures/nouvelle' ) ) ?>">+ Nouvelle facture</a>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : n°, client, date…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>N° (provisoire)</th><th>Date</th><th>Client</th><th class="num">TTC</th><th>État</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $factures ) : ?><tr><td colspan="6" class="empty">Aucune proforma en attente. Toutes les factures sont certifiées.</td></tr>
	<?php else : foreach ( $factures as $f ) : ?>
		<tr>
			<td><span class="code"><?= e( $f['numero'] ) ?></span></td>
			<td class="num"><?= e( date( 'd/m/Y', strtotime( $f['date_facture'] ) ) ) ?></td>
			<td><?= e( $f['client_nom'] ?: '—' ) ?></td>
			<td class="num"><?= e( fkc_money( $f['montant_ttc'] ) ) ?></td>
			<td><span class="modbadge b-off">Proforma</span></td>
			<td class="right" style="white-space:nowrap">
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/factures/' . (int) $f['id'] ) ) ?>">Ouvrir / Certifier</a>
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/factures/' . (int) $f['id'] . '/imprimer' ) ) ?>" target="_blank">Imprimer</a>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
<p class="help">Une proforma devient une facture fiscale définitive une fois certifiée via la FNE depuis sa fiche.</p>
