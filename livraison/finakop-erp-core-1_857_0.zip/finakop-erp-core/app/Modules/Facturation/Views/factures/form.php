<?php /** @var array $clients @var array $taxes @var array $methods @var string $numero @var array $errors @var string $tab @var array $divisions @var bool $showDivision @var array $items @var array|null $facture @var array $lignesEdit */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f      = $facture ?? null;
$isEdit = $f && FKC_Facture::editable( $f );
$action = $isEdit ? url( 'facturation/factures/' . (int) $f['id'] . '/modifier' ) : url( 'facturation/factures' );
$pm     = $f['payment_method'] ?? '';
$cid    = $f['client_id'] ?? '';
$did    = $f['division_id'] ?? '';
?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>

<?php if ( ! empty( $remplace ) ) : ?>
	<div class="alert alert-info">
		<?php if ( ! empty( $flashInfo ) ) : ?><div style="margin-bottom:6px"><?= e( $flashInfo ) ?></div><?php endif; ?>
		<strong>Facture corrigée — elle remplace <?= e( $remplace['numero'] ) ?>.</strong>
		Une facture de vente comptabilisée ne se réécrit pas : elle est annulée par son avoir, et la version corrigée prend un nouveau numéro, pour que la série reste chronologique et continue (et, pour une facture certifiée, pour que la DGI voie les deux). Tout est pré-rempli : corrigez, puis enregistrez.
	</div>
<?php endif; ?>
<form method="post" action="<?= e( $action ) ?>" id="facture-form">
	<?= FKC_Csrf::field() ?>
	<?php if ( ! empty( $remplace ) ) : ?><input type="hidden" name="remplace_id" value="<?= (int) $remplace['id'] ?>"><?php endif; ?>
	<div class="card">
		<div class="card-head"><h2><?= $isEdit ? 'Modifier' : 'En-tête' ?>
			<?php if ( '' !== (string) $numero ) : ?>
				· <span class="code"><?= e( $numero ) ?></span>
			<?php else : ?>
				<span class="muted" style="font-weight:400;font-size:13px">· numéro attribué à l'enregistrement, d'après la date de facture</span>
			<?php endif; ?>
		</h2></div>
		<div class="card-body">
			<?php
			/*
			 * On ne renvoie le numéro QUE s'il en existe déjà un, c'est-à-dire
			 * en modification. Pour une facture neuve, le champ reste absent :
			 * c'est l'enregistrement qui attribue, à partir de la date saisie.
			 */
			if ( '' !== (string) $numero ) : ?>
				<input type="hidden" name="numero" value="<?= e( $numero ) ?>">
			<?php endif; ?>
			<div class="form-grid">
				<label class="fld"><span>Client</span>
					<select name="client_id" id="client-select">
						<option value="">— Particulier (B2C) —</option>
						<?php foreach ( $clients as $c ) : ?>
							<option value="<?= (int) $c['id'] ?>" data-type="<?= e( $c['type'] ) ?>" <?= ( (int) $cid === (int) $c['id'] ) ? 'selected' : '' ?>><?= e( $c['nom'] . ( 'B2B' === $c['type'] ? ' · B2B' : '' ) ) ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="fld"><span>Date</span><input type="date" name="date_facture" value="<?= e( $f['date_facture'] ?? date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>Échéance</span><input type="date" name="echeance" value="<?= e( $f['echeance'] ?? '' ) ?>"></label>
				<label class="fld"><span>Règlement</span>
					<select name="payment_method">
						<?php foreach ( $methods as $k => $lbl ) : ?><option value="<?= e( $k ) ?>" <?= ( (string) $pm === (string) $k ) ? 'selected' : '' ?>><?= e( $lbl ) ?></option><?php endforeach; ?>
					</select>
				</label>
				<?php if ( ! empty( $showDivision ) && ! empty( $divisions ) ) : ?>
				<label class="fld"><span>Division (analytique)</span>
					<select name="division_id">
						<option value="">— non imputé —</option>
						<?php foreach ( $divisions as $dv ) : ?><option value="<?= (int) $dv['id'] ?>" <?= ( (int) $did === (int) $dv['id'] ) ? 'selected' : '' ?>><?= e( $dv['libelle'] ) ?></option><?php endforeach; ?>
					</select>
				</label>
				<?php endif; ?>
				<?php if ( ! empty( $showAxes ) ) : $fAxe = (int) ( $f['axe_id'] ?? 0 ); $fVal = (int) ( $f['valeur_id'] ?? 0 ); ?>
				<label class="fld"><span>Axe analytique</span>
					<select name="axe_id" id="fac-axe">
						<option value="">— aucun axe —</option>
						<?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= $fAxe === (int) $a['id'] ? 'selected' : '' ?>><?= e( $a['code'] . ' · ' . $a['libelle'] ) ?></option><?php endforeach; ?>
					</select>
				</label>
				<label class="fld"><span>Valeur analytique</span>
					<select name="valeur_id" id="fac-valeur"><option value="">— valeur —</option></select>
				</label>
				<?php endif; ?>
			</div>
			<p class="help" id="b2b-hint" style="display:none">Client B2B sélectionné : la facture sera émise en modèle <strong>B2B</strong> (NCC requis et déjà renseigné sur la fiche client).</p>
		</div>
	</div>

	<div class="card card-flush">
		<div class="card-head"><h2>Lignes</h2>
			<button type="button" class="btn btn-ghost btn-sm" id="add-fl">+ Ajouter une ligne</button></div>
		<table class="table" id="fl">
			<thead><tr>
				<th style="width:210px">Item (compte)</th>
				<th>Désignation</th><th style="width:80px">Qté</th>
				<th class="num" style="width:130px">PU HT</th><th style="width:140px">TVA</th>
				<th class="num" style="width:130px">Montant HT</th><th style="width:36px"></th>
			</tr></thead>
			<tbody id="fl-body"></tbody>
			<tfoot>
				<tr class="total"><td colspan="5" class="right">Total HT</td><td class="num" id="t-ht">0</td><td></td></tr>
				<tr class="total"><td colspan="5" class="right">TVA</td><td class="num" id="t-tva">0</td><td></td></tr>
				<tr class="total"><td colspan="5" class="right">Total TTC</td><td class="num" id="t-ttc" style="color:var(--orange)">0</td><td></td></tr>
			</tfoot>
		</table>
		<p class="help" style="padding:10px 16px;margin:0">Choisissez un <strong>item</strong> pour remplir automatiquement la désignation, le prix, la TVA et le <strong>compte</strong> de produit utilisé à la comptabilisation. <a href="<?= e( url( 'referentiels/items' ) ) ?>" target="_blank">Gérer les items →</a></p>
	</div>

	<div class="card">
		<div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Message commercial (optionnel)</span><input type="text" name="commercial_message" value="<?= e( $f['commercial_message'] ?? '' ) ?>" placeholder="Merci de votre confiance"></label>
				<label class="fld"><span>Pied de facture (optionnel)</span><input type="text" name="footer" value="<?= e( $f['footer'] ?? '' ) ?>" placeholder="Conditions, mentions…"></label>
			</div>
		</div>
	</div>

	<div class="actions">
		<button class="btn btn-primary" type="submit"><?= $isEdit ? 'Enregistrer les modifications' : 'Enregistrer la facture' ?></button>
		<a class="btn btn-ghost" href="<?= e( $isEdit ? url( 'facturation/factures/' . (int) $f['id'] ) : url( 'facturation/factures' ) ) ?>">Annuler</a>
	</div>
	<?php if ( ! $isEdit ) : ?><p class="help" style="margin-top:10px">La facture est d'abord enregistrée en brouillon. Vous pouvez la modifier tant qu'elle n'est ni comptabilisée ni certifiée. Vous la certifiez ensuite via la FNE depuis sa page.</p><?php endif; ?>
</form>

<script>
window.FKC_TAXES = <?= json_encode( array_map( function ( $code, $t ) {
	return array( 'code' => $code, 'label' => $t['label'], 'taux' => $t['taux'] );
}, array_keys( $taxes ), array_values( $taxes ) ), JSON_UNESCAPED_UNICODE ) ?>;
window.FKC_ITEMS = <?= json_encode( array_map( function ( $it ) {
	return array( 'id' => (int) $it['id'], 'label' => $it['libelle'], 'compte' => $it['compte'], 'tva' => $it['tva_code'], 'pu' => (float) $it['pu_ht'] );
}, $items ), JSON_UNESCAPED_UNICODE ) ?>;
window.FKC_LINES = <?= json_encode( array_map( function ( $l ) {
	return array(
		'designation' => $l['designation'] ?? '', 'quantite' => (float) ( $l['quantite'] ?? 1 ),
		'pu_ht' => (float) ( $l['pu_ht'] ?? 0 ), 'tva_code' => $l['tva_code'] ?? 'TVA',
		'compte' => $l['compte'] ?? '', 'item_id' => (int) ( $l['item_id'] ?? 0 ),
	);
}, $lignesEdit ), JSON_UNESCAPED_UNICODE ) ?>;
</script>
<script src="<?= e( fkc_asset( 'js/facture.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>"></script>
<?php if ( ! empty( $showAxes ) ) : ?>
<script>
(function(){
	var valeurs = <?= json_encode( $valeursMap ?? array(), JSON_UNESCAPED_UNICODE ) ?>;
	var saved = <?= (int) ( $f['valeur_id'] ?? 0 ) ?>;
	var axe = document.getElementById('fac-axe'), val = document.getElementById('fac-valeur');
	if(!axe||!val) return;
	function fill(){
		var list = valeurs[axe.value] || [];
		val.innerHTML = '<option value="">— valeur —</option>' + list.map(function(v){
			return '<option value="'+v.id+'"'+(v.id===saved?' selected':'')+'>'+v.t+'</option>';
		}).join('');
	}
	axe.addEventListener('change', function(){ saved = 0; fill(); });
	fill();
})();
</script>
<?php endif; ?>
