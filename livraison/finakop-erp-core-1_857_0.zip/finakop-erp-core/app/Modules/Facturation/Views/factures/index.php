<?php /** @var array $factures @var bool $fneReady @var array|null $flash @var string $tab @var array $etats @var array $nbEtat @var string $filtreCompta */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$badge = array( 'CERTIFIE' => array( 'Certifiée FNE', 'b-on' ), 'NON_CERTIFIE' => array( 'Non certifiée', 'b-off' ), 'ERROR' => array( 'Erreur FNE', 'b-err' ) ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<?php if ( ! $fneReady ) : ?><div class="alert alert-warn">La certification FNE n'est pas encore configurée. <a href="<?= e( url( 'facturation/fne' ) ) ?>">Configurer la FNE</a></div><?php endif; ?>
<div class="bar">
	<span class="muted">Factures de vente</span>
	<a class="btn btn-primary" href="<?= e( url( 'facturation/factures/nouvelle' ) ) ?>">+ Nouvelle facture</a>
</div>
<?php $opts = $opts ?? array(); $clients = $clients ?? array();
$etats = $etats ?? array(); $nbEtat = $nbEtat ?? FKC_EtatCompta::compter( array() ); $filtreCompta = $filtreCompta ?? ''; $paiements = $paiements ?? array(); ?>
<form method="get" action="<?= e( url( 'facturation/factures' ) ) ?>" class="card" style="margin-bottom:12px"><div class="card-body">
	<div class="form-grid" style="grid-template-columns:1.4fr 1.2fr 1fr 1fr .9fr .9fr auto;align-items:end;gap:10px">
		<label class="fld"><span>Recherche (n° / client)</span><input name="q" value="<?= e( $opts['q'] ?? '' ) ?>" placeholder="FAC-2026 ou nom"></label>
		<label class="fld"><span>Client</span><select name="client_id"><option value="">— Tous —</option><?php foreach ( $clients as $c ) : ?><option value="<?= (int) $c['id'] ?>" <?= ( (int)($opts['client_id']??0) === (int)$c['id'] ) ? 'selected' : '' ?>><?= e( $c['nom'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld"><span>Statut FNE</span><select name="fne"><option value="">— Tous —</option><?php foreach ( array('CERTIFIE'=>'Certifiée','NON_CERTIFIE'=>'Non certifiée','ERROR'=>'Erreur') as $k=>$v ) : ?><option value="<?= $k ?>" <?= ($opts['fne']??'')===$k?'selected':'' ?>><?= e($v) ?></option><?php endforeach; ?></select></label>
		<label class="fld"><span>Type</span><select name="type"><option value="">— Tous —</option><option value="facture" <?= ($opts['type']??'')==='facture'?'selected':'' ?>>Factures</option><option value="avoir" <?= ($opts['type']??'')==='avoir'?'selected':'' ?>>Avoirs</option></select></label>
		<label class="fld"><span>Du</span><input type="date" name="from" value="<?= e( $opts['from'] ?? '' ) ?>"></label>
		<label class="fld"><span>Au</span><input type="date" name="to" value="<?= e( $opts['to'] ?? '' ) ?>"></label>
		<?php if ( $filtreCompta ) : ?><input type="hidden" name="compta" value="<?= e( $filtreCompta ) ?>"><?php endif; ?>
		<div style="display:flex;gap:6px"><button class="btn btn-primary" type="submit">Filtrer</button><a class="btn btn-ghost" href="<?= e( url( 'facturation/factures' ) ) ?>">Réinit.</a></div>
	</div>
</div></form>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : n°, client, date, statut…' ) ); ?>
<?php FKC_View::partial( '_etat_compta_compteurs', array( 'nb' => $nbEtat, 'base' => 'facturation/factures', 'actif' => $filtreCompta, 'garder' => $opts ) ); ?>
<div class="card card-flush">
	<table class="table">
		<thead><tr><th>Numéro</th><th>Date</th><th>Client</th><th class="num">TTC</th><th>Statut FNE</th><th>Paiement</th><th>Comptabilité</th><th></th></tr></thead>
		<tbody>
		<?php if ( empty( $factures ) ) : ?>
			<tr><td colspan="8" class="empty"><?= $filtreCompta ? 'Aucune facture dans cet état de comptabilisation.' : 'Aucune facture. Créez-en une pour la certifier via la FNE.' ?></td></tr>
		<?php else : foreach ( $factures as $f ) : $b = $badge[ $f['fne_status'] ] ?? $badge['NON_CERTIFIE'];
			$ec = $etats[ (int) $f['id'] ] ?? null;
			$fAnnulee = 0 === stripos( (string) ( $f['statut'] ?? '' ), 'annul' );
			$ecCls = $fAnnulee ? '' : ( array( 'comptabilisee' => 'compta-ok', 'attente' => 'compta-attente', 'a_comptabiliser' => 'compta-a-faire' )[ $ec['etat'] ?? '' ] ?? '' ); ?>
			<tr class="<?= e( $ecCls ) ?>">
				<td><span class="code"><?= e( $f['numero'] ) ?></span><?php if ( 'avoir' === ( $f['type'] ?? 'facture' ) ) : ?> <span class="modbadge b-off">Avoir</span><?php endif; ?></td>
				<td class="num"><?= e( date( 'd/m/Y', strtotime( $f['date_facture'] ) ) ) ?></td>
				<td><?= e( $f['client_nom'] ) ?><?php if ( ! empty( $pieces[ $f['id'] ] ) ) : ?> <span class="pj-flag" title="<?= (int) $pieces[ $f['id'] ] ?> pièce(s) jointe(s)">📎<?= (int) $pieces[ $f['id'] ] > 1 ? '<sup>' . (int) $pieces[ $f['id'] ] . '</sup>' : '' ?></span><?php endif; ?></td>
				<td class="num"><?= e( fkc_money( $f['montant_ttc'] ) ) ?></td>
				<td><span class="modbadge <?= $b[1] ?>"><?= e( $b[0] ) ?></span><?php if ( $fAnnulee ) : ?> <span class="modbadge b-off">Annulée</span><?php endif; ?></td>
				<td><?php
				/* 1.745.0 — état de paiement calculé ; un encaissement annulé rouvre la facture. */
				$pay = $paiements[ (int) $f['id'] ] ?? null;
				$payLib = array( 'payee' => array( 'Encaissée', 'b-on' ), 'partielle' => array( 'Partielle', 'b-warn' ), 'a_payer' => array( 'À encaisser', 'b-warn' ) );
				if ( $pay && isset( $payLib[ $pay['etat'] ] ) ) : ?><span class="modbadge <?= e( $payLib[ $pay['etat'] ][1] ) ?>" data-etat-paiement="<?= e( $pay['etat'] ) ?>"><?= e( $payLib[ $pay['etat'] ][0] ) ?></span><?php if ( 'partielle' === $pay['etat'] ) : ?><br><small class="muted">reste <?= e( fkc_money( $pay['reste'] ) ) ?></small><?php endif; ?>
				<?php else : ?><span class="muted">—</span><?php endif; ?></td>
				<td><?php
				/* Une facture client annulée l'est par AVOIR : son écriture reste
				   au journal et c'est l'avoir qui la neutralise — elle demeure donc
				   « comptabilisée », pas « contre-passée ». */
				FKC_View::partial( '_etat_compta', array( 'ec' => $ec, 'annulee' => false ) ); ?></td>
				<td class="right"><?php FKC_View::partial( '_connect_bouton', array( 'cx_type' => 'facture', 'cx_id' => (int) $f['id'] ) ); ?>
					<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/factures/' . $f['id'] ) ) ?>">Ouvrir</a></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
