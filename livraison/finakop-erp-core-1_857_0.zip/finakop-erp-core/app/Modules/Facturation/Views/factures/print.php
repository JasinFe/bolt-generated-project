<?php /** @var array $facture @var array|null $client @var array $cfg @var string $verifyUrl */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f   = $facture;
$soc = FKC_Tenant::current();
$logo = ( $soc && FKC_Societe::hasLogo( $soc ) ) ? FKC_Societe::logoUrl( $soc ) : null;

/* ── Émetteur : société active en priorité, configuration FNE en repli ── */
$em_nom    = trim( (string) ( $soc['raison_sociale'] ?? '' ) ) ?: ( $cfg['fne_company_name'] ?: ( $cfg['fne_establishment'] ?: 'Votre société' ) );
$em_forme  = trim( (string) ( $soc['forme_juridique'] ?? '' ) );
$em_nom_aff = $em_nom . ( ( $em_forme && stripos( $em_nom, $em_forme ) === false && strlen( $em_forme ) <= 10 ) ? ' ' . strtoupper( $em_forme ) : '' );
$em_ncc    = trim( (string) ( $soc['ncc'] ?? '' ) ) ?: $cfg['fne_ncc'];
$em_rccm   = trim( (string) ( $soc['rccm'] ?? '' ) );
$em_adr    = trim( (string) ( $soc['adresse'] ?? '' ) ) ?: $cfg['fne_establishment'];
$em_ville  = trim( (string) ( $soc['ville'] ?? '' ) );
$em_tel    = trim( (string) ( $soc['telephone'] ?? '' ) );
$em_email  = trim( (string) ( $soc['email'] ?? '' ) );
$devise    = trim( (string) ( $soc['devise'] ?? 'XOF' ) ) ?: 'XOF';
$cur       = 'XOF' === $devise ? 'F CFA' : $devise;

$certified = ( 'CERTIFIE' === $f['fne_status'] && ! empty( $f['fne_reference'] ) );
$annulee   = ( 'annulee' === $f['statut'] );
$is_avoir  = ( 'avoir' === ( $f['type'] ?? '' ) );
$doc_titre = $is_avoir ? 'FACTURE D\'AVOIR' : ( 'B2B' === ( $f['template'] ?? '' ) ? 'FACTURE CLIENT' : 'FACTURE' );

/* Régime fiscal (libellé court) pour la mention légale. */
$regime = trim( (string) ( $soc['regime_fiscal'] ?? '' ) ) ?: trim( (string) ( $cfg['fne_regime'] ?? '' ) );
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e( $doc_titre . ' ' . $f['numero'] ) ?></title>
<style>
  :root{--navy:#16264A;--navy2:#1E3A6E;--gold:#C9A227;--gold-d:#A07E12;--ink:#1c2433;--muted:#6b7589;--line:#e6e9f0;--soft:#f6f8fc;}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:"Segoe UI",system-ui,Arial,sans-serif;background:#54607a;color:var(--ink);padding:24px 16px 60px;font-size:13px}
  .bar{max-width:794px;margin:0 auto 16px;display:flex;gap:10px;justify-content:flex-end}
  .bar button,.bar a{padding:11px 20px;border-radius:9px;border:none;font-weight:700;cursor:pointer;font-size:13px;text-decoration:none;display:inline-flex;align-items:center;gap:8px}
  .bar .print{background:var(--gold);color:#241500}.bar .back{background:var(--navy);color:#fff}
  .sheet{background:#fff;max-width:794px;margin:0 auto;padding:40px 44px;box-shadow:0 12px 44px rgba(0,0,0,.32);border-radius:5px;position:relative}

  /* En-tête émetteur */
  .head{display:flex;justify-content:space-between;align-items:flex-start;gap:28px;padding-bottom:18px}
  .em{display:flex;gap:16px;align-items:flex-start;min-width:0}
  .em-logo{width:78px;height:78px;flex-shrink:0;border-radius:12px;border:1px solid var(--line);object-fit:contain;padding:4px;background:#fff}
  .em-id h1{font-family:Georgia,"Times New Roman",serif;font-size:20px;color:var(--navy);font-weight:800;letter-spacing:.2px;line-height:1.1}
  .em-id p{color:var(--muted);font-size:11.5px;margin-top:4px;line-height:1.7}
  .em-id .fix{color:var(--ink)}
  .badges{margin-top:8px;display:flex;gap:8px;flex-wrap:wrap}
  .badge{font-family:ui-monospace,Consolas,monospace;font-size:10.5px;color:var(--navy);background:var(--soft);border:1px solid var(--line);border-radius:6px;padding:3px 9px;letter-spacing:.5px}
  .doc{text-align:right;flex-shrink:0}
  .doc .ttl{font-family:Georgia,serif;font-size:26px;font-weight:800;color:var(--navy);letter-spacing:.5px;line-height:1}
  .doc .num{font-family:ui-monospace,Consolas,monospace;font-size:17px;color:var(--gold-d);font-weight:700;margin-top:6px}
  .doc .dt{color:var(--muted);font-size:11.5px;margin-top:8px;line-height:1.6}
  .rule{height:3px;background:linear-gradient(90deg,var(--gold),var(--navy));border-radius:2px;margin:6px 0 22px}

  .warn{display:flex;gap:9px;align-items:center;justify-content:center;background:#fff8e8;border:1px dashed var(--gold-d);color:#7a5e00;border-radius:10px;padding:11px 14px;font-size:12px;font-weight:600;margin-bottom:22px}

  /* Parties */
  .parties{display:flex;justify-content:space-between;gap:24px;margin-bottom:22px}
  .to{flex:1;border-left:3px solid var(--gold);padding:2px 0 2px 14px}
  .to .t,.meta .t{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);font-weight:700;margin-bottom:5px}
  .to .nom{font-size:16px;font-weight:800;color:var(--navy)}
  .to .v{font-size:12px;line-height:1.7;color:#3a4660;margin-top:3px}
  .to .cli{display:inline-block;margin-top:7px;font-family:ui-monospace,Consolas,monospace;font-size:10.5px;color:#fff;background:var(--navy);border-radius:6px;padding:3px 9px;letter-spacing:.5px}
  .meta{text-align:right;min-width:170px}
  .meta .v{font-size:13px;font-weight:700;color:var(--ink)}

  table{width:100%;border-collapse:collapse;margin-bottom:18px}
  thead th{background:var(--navy);color:#fff;text-align:left;padding:11px 13px;font-size:10.5px;text-transform:uppercase;letter-spacing:.5px;font-weight:700}
  th.r,td.r{text-align:right}th.c,td.c{text-align:center}
  tbody td{padding:11px 13px;border-bottom:1px solid var(--line);font-size:12.5px;vertical-align:top}
  tbody tr:nth-child(even){background:var(--soft)}
  .desig{font-weight:700;color:var(--ink)}.desig small{display:block;font-weight:400;color:var(--muted);font-size:11px;margin-top:2px}

  .bas{display:flex;justify-content:space-between;gap:24px;align-items:flex-start;margin-top:6px}
  .pay{flex:1;max-width:330px}
  .pay .blk{background:var(--soft);border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin-bottom:10px}
  .pay .lbl{font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);font-weight:700}
  .pay .val{font-size:14px;font-weight:700;color:var(--navy);margin-top:3px}
  .pay .legal{font-size:11px;color:#3a4660;line-height:1.6}
  .tot{width:300px;flex-shrink:0;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tot .row{display:flex;justify-content:space-between;padding:10px 16px;font-size:13px;border-bottom:1px solid var(--line)}
  .tot .row span:first-child{color:var(--muted)}
  .tot .ttc{background:var(--navy);color:#fff;padding:14px 16px;border:none}
  .tot .ttc .lab{font-size:11px;letter-spacing:1px;text-transform:uppercase;opacity:.85}
  .tot .ttc .amt{font-size:20px;font-weight:800;color:var(--gold);font-family:Georgia,serif}

  .fne{display:flex;gap:18px;align-items:center;margin-top:24px;padding:16px;border:1px solid var(--line);border-left:4px solid var(--navy);border-radius:10px;background:var(--soft)}
  .fne #qr{width:100px;height:100px;flex-shrink:0}.fne #qr svg{width:100px;height:100px}
  .fne .tag{display:inline-block;background:var(--navy);color:#fff;font-weight:800;letter-spacing:2px;padding:4px 12px;border-radius:6px;font-size:13px}
  .fne .info{font-size:11.5px;color:#3a4660;line-height:1.7}.fne .info .code{font-family:ui-monospace,monospace;color:var(--navy);font-weight:700}
  .annul{margin-top:18px;padding:11px;border:2px solid #c0392b;color:#c0392b;text-align:center;font-weight:800;border-radius:8px;letter-spacing:2px}
  .foot{margin-top:28px;border-top:2px solid var(--navy);padding-top:15px}
  .foot-cols{display:flex;gap:26px;justify-content:space-between}
  .foot-col{flex:1;min-width:0}
  .foot-col h4{font-size:9px;letter-spacing:1.2px;text-transform:uppercase;color:var(--gold-d);margin-bottom:7px;font-weight:800}
  .foot-col strong{display:block;color:var(--navy);font-size:11.5px;margin-bottom:3px;font-weight:700}
  .foot-col .l{display:block;color:var(--muted);font-size:10.5px;line-height:1.7}
  .foot-col .l b{color:var(--ink);font-weight:600}
  .foot-legal{text-align:center;color:var(--muted);font-size:9.5px;margin-top:15px;padding-top:11px;border-top:1px solid var(--line);line-height:1.65}
  .foot-legal .code{font-family:ui-monospace,Consolas,monospace;color:var(--navy)}

  @media print{
    @page{size:A4;margin:12mm}
    body{background:#fff;padding:0;font-size:12px}
    .sheet{box-shadow:none;max-width:none;margin:0;padding:0;border-radius:0}
    .bar{display:none}
    thead th{-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .tot .ttc,thead th{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  }
</style>
</head>
<body>
<div class="bar">
  <a class="back" href="<?= e( url( 'facturation/factures/' . $f['id'] ) ) ?>">← Retour</a>
  <button class="print" onclick="window.print()">🖨️ Imprimer / Enregistrer en PDF</button>
</div>

<div class="sheet">
  <div class="head">
    <div class="em">
      <?php if ( $logo ) : ?><img class="em-logo" src="<?= e( $logo ) ?>" alt=""><?php endif; ?>
      <div class="em-id">
        <h1><?= e( $em_nom_aff ) ?></h1>
        <p>
          <?php if ( $em_adr ) : ?><?= e( $em_adr ) ?><br><?php endif; ?>
          <?php if ( $em_ville ) : ?><?= e( $em_ville ) ?><br><?php endif; ?>
          <?php if ( $em_tel ) : ?><span class="fix">Tél : <?= e( $em_tel ) ?></span><?php endif; ?>
          <?php if ( $em_email ) : ?><?= $em_tel ? ' &nbsp;·&nbsp; ' : '' ?><?= e( $em_email ) ?><?php endif; ?>
        </p>
        <div class="badges">
          <?php if ( $em_ncc ) : ?><span class="badge">NCC : <?= e( $em_ncc ) ?></span><?php endif; ?>
          <?php if ( $em_rccm ) : ?><span class="badge">RCCM : <?= e( $em_rccm ) ?></span><?php endif; ?>
        </div>
      </div>
    </div>
    <div class="doc">
      <div class="ttl"><?= e( $doc_titre ) ?></div>
      <div class="num"><?= e( $f['numero'] ) ?></div>
      <div class="dt">Date : <?= e( date( 'd/m/Y', strtotime( $f['date_facture'] ) ) ) ?>
        <?php if ( $f['echeance'] ) : ?><br>Échéance : <?= e( date( 'd/m/Y', strtotime( $f['echeance'] ) ) ) ?><?php endif; ?>
      </div>
    </div>
  </div>
  <div class="rule"></div>

  <?php if ( ! $certified && ! $annulee ) : ?>
    <div class="warn">⚠️ Facture non certifiée FNE — à certifier depuis FinaKop ERP avant remise au client.</div>
  <?php endif; ?>

  <div class="parties">
    <div class="to">
      <div class="t">Facturé à</div>
      <div class="nom"><?= e( $f['client_nom'] ) ?></div>
      <div class="v">
        <?php if ( $client ) : ?>
          <?php if ( 'B2B' === ( $client['type'] ?? '' ) && ! empty( $client['ncc'] ) ) : ?>NCC : <?= e( $client['ncc'] ) ?><br><?php endif; ?>
          <?php if ( ! empty( $client['telephone'] ) ) : ?><?= e( $client['telephone'] ) ?><br><?php endif; ?>
          <?php $cv = trim( implode( ', ', array_filter( array( $client['adresse'] ?? '', $client['ville'] ?? '' ) ) ) ); ?>
          <?php if ( $cv ) : ?><?= e( $cv ) ?><?php endif; ?>
        <?php endif; ?>
      </div>
      <?php if ( $client && ! empty( $client['code'] ) ) : ?><span class="cli"><?= e( $client['code'] ) ?></span><?php endif; ?>
    </div>
    <div class="meta">
      <div class="t">Modèle / Règlement</div>
      <div class="v"><?= e( $f['template'] ) ?> · <?= e( $f['payment_method'] ) ?></div>
    </div>
  </div>

  <table>
    <thead><tr>
      <th>Désignation</th><th class="c">Qté</th><th class="r">P.U. HT</th>
      <th class="r">Montant HT</th><th class="c">TVA</th><th class="r">Montant TTC</th>
    </tr></thead>
    <tbody>
      <?php foreach ( $f['lignes'] as $l ) :
        $ht  = (float) $l['montant_ht'];
        $tx  = (float) $l['tva_taux'];
        $pu  = (float) $l['pu_ht'];
        if ( $is_avoir ) { $ht = abs( $ht ); $pu = abs( $pu ); }
        $ttc = $ht * ( 1 + $tx / 100 ); ?>
        <tr>
          <td class="desig"><?= e( $l['designation'] ) ?></td>
          <td class="c"><?= e( fkc_money( $l['quantite'] ) ) ?></td>
          <td class="r"><?= e( fkc_money( $pu ) ) ?></td>
          <td class="r"><?= e( fkc_money( $ht ) ) ?></td>
          <td class="c"><?= (int) $tx ?> %</td>
          <td class="r"><?= e( fkc_money( $ttc ) ) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="bas">
    <div class="pay">
      <div class="blk">
        <div class="lbl">Mode de règlement</div>
        <div class="val"><?= e( $f['payment_method'] ?: '—' ) ?></div>
      </div>
      <?php if ( $regime ) : ?>
      <div class="blk">
        <div class="lbl">Régime fiscal</div>
        <div class="legal"><?= e( $regime ) ?></div>
      </div>
      <?php endif; ?>
      <?php if ( $f['commercial_message'] ) : ?>
      <div class="blk"><div class="legal"><?= e( $f['commercial_message'] ) ?></div></div>
      <?php endif; ?>
    </div>
    <div class="tot">
      <div class="row"><span>Sous-total HT</span><span><?= e( fkc_money( $is_avoir ? abs( $f['montant_ht'] ) : $f['montant_ht'] ) ) ?> <?= e( $cur ) ?></span></div>
      <div class="row"><span>TVA</span><span><?= e( fkc_money( $is_avoir ? abs( $f['montant_tva'] ) : $f['montant_tva'] ) ) ?> <?= e( $cur ) ?></span></div>
      <div class="ttc"><span class="lab"><?= $is_avoir ? 'Net à déduire' : 'Net à payer' ?></span><br><span class="amt"><?= e( fkc_money( $is_avoir ? abs( $f['montant_ttc'] ) : $f['montant_ttc'] ) ) ?> <?= e( $cur ) ?></span></div>
    </div>
  </div>

  <?php if ( $annulee ) : ?>
    <div class="annul">FACTURE ANNULÉE — AVOIR FNE <?= e( $f['fne_avoir_reference'] ) ?></div>
  <?php endif; ?>

  <?php if ( $certified ) : ?>
  <div class="fne">
    <div id="qr" data-url="<?= e( $verifyUrl ) ?>"></div>
    <div class="info">
      <span class="tag">FNE</span><br><br>
      Facture certifiée par la DGI · Réf. <span class="code"><?= e( $f['fne_reference'] ) ?></span><br>
      Scannez le QR code pour vérifier l'authenticité sur e-impots.gouv.ci
    </div>
  </div>
  <?php endif; ?>

  <div class="foot">
    <div class="foot-cols">
      <div class="foot-col">
        <h4>Émetteur</h4>
        <strong><?= e( $em_nom_aff ) ?></strong>
        <?php if ( $em_adr ) : ?><span class="l"><?= e( $em_adr ) ?></span><?php endif; ?>
        <?php if ( $em_ville ) : ?><span class="l"><?= e( $em_ville ) ?></span><?php endif; ?>
      </div>
      <div class="foot-col">
        <h4>Identifiants légaux</h4>
        <?php if ( $em_ncc ) : ?><span class="l">NCC : <b><?= e( $em_ncc ) ?></b></span><?php endif; ?>
        <?php if ( $em_rccm ) : ?><span class="l">RCCM : <b><?= e( $em_rccm ) ?></b></span><?php endif; ?>
        <?php if ( $regime ) : ?><span class="l">Régime : <b><?= e( $regime ) ?></b></span><?php endif; ?>
      </div>
      <div class="foot-col">
        <h4>Contact</h4>
        <?php if ( $em_tel ) : ?><span class="l">Tél : <b><?= e( $em_tel ) ?></b></span><?php endif; ?>
        <?php if ( $em_email ) : ?><span class="l"><?= e( $em_email ) ?></span><?php endif; ?>
      </div>
    </div>
    <div class="foot-legal">
      <?php
      $foot_custom = trim( (string) ( $f['footer'] ?: ( $cfg['fne_footer'] ?? '' ) ) );
      if ( $foot_custom ) { echo e( $foot_custom ) . ' &nbsp;·&nbsp; '; }
      ?>Facture générée par FinaKop ERP<?php if ( $certified ) : ?> &nbsp;·&nbsp; Émise conformément à l'Arrêté n°0337 du 9 mai 2025 — FNE DGI CI<?php endif; ?>
      &nbsp;·&nbsp; <span class="code"><?= e( $f['numero'] ) ?></span> &nbsp;·&nbsp; <?= e( date( 'd/m/Y', strtotime( $f['date_facture'] ) ) ) ?>
    </div>
  </div>
</div>

<?php if ( $certified && $verifyUrl ) : ?>
<script src="<?= e( fkc_asset( 'js/qrcode.js' ) ) ?>"></script>
<script>
(function(){var el=document.getElementById('qr');if(!el||typeof qrcode==='undefined')return;
try{var q=qrcode(0,'M');q.addData(el.getAttribute('data-url'));q.make();el.innerHTML=q.createSvgTag({cellSize:4,margin:0,scalable:true});}catch(e){}})();
</script>
<?php endif; ?>
</body>
</html>
