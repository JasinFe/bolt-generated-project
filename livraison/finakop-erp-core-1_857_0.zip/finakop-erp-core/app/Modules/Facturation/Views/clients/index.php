<?php /** @var array $clients @var string|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'facturation::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted"><?= count( $clients ) ?> client(s)</span>
	<a class="btn btn-primary" href="<?= e( url( 'facturation/clients/nouveau' ) ) ?>">+ Nouveau client</a>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : nom, NCC, téléphone, e-mail…' ) ); ?>
<div class="card card-flush">
	<table class="table">
		<thead><tr><th>Nom</th><th>Type</th><th>NCC</th><th>Téléphone</th><th>Email</th><th></th></tr></thead>
		<tbody>
		<?php if ( empty( $clients ) ) : ?>
			<tr><td colspan="6" class="empty">Aucun client.</td></tr>
		<?php else : foreach ( $clients as $c ) : ?>
			<tr>
				<td><strong><?= e( $c['nom'] ) ?></strong></td>
				<td><span class="modbadge <?= 'B2B' === $c['type'] ? 'b-on' : 'b-off' ?>"><?= e( $c['type'] ) ?></span></td>
				<td><span class="code"><?= e( $c['ncc'] ?: '—' ) ?></span></td>
				<td class="muted"><?= e( $c['telephone'] ?: '—' ) ?></td>
				<td class="muted"><?= e( $c['email'] ?: '—' ) ?></td>
				<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/clients/' . $c['id'] . '/modifier' ) ) ?>">Éditer</a></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
