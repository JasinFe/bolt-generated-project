<?php /** @var array|null $client @var array $errors @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$edit = (bool) $client; $type = $edit ? $client['type'] : old( 'type', 'B2C' ); ?>
<?php FKC_View::partial( 'facturation::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:620px">
	<div class="card-head"><h2><?= $edit ? 'Modifier le client' : 'Nouveau client' ?></h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( $edit ? url( 'facturation/clients/' . $client['id'] ) : url( 'facturation/clients' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Numéro / ID client</span><input type="text" name="code" value="<?= e( $edit ? ( $client['code'] ?? '' ) : old( 'code' ) ) ?>" placeholder="ex. CLI-0001"></label>
				<label class="fld"><span>Nom / Raison sociale</span><input type="text" name="nom" value="<?= e( $edit ? $client['nom'] : old( 'nom' ) ) ?>" required></label>
				<label class="fld"><span>Type</span>
					<select name="type" id="cli-type">
						<option value="B2C" <?= 'B2C' === $type ? 'selected' : '' ?>>Particulier (B2C)</option>
						<option value="B2B" <?= 'B2B' === $type ? 'selected' : '' ?>>Entreprise (B2B)</option>
					</select>
				</label>
			</div>
			<label class="fld" id="ncc-fld"><span>NCC (Numéro Compte Contribuable) — requis pour B2B</span>
				<input type="text" name="ncc" class="code" value="<?= e( $edit ? $client['ncc'] : old( 'ncc' ) ) ?>" placeholder="ex. 2506650V"></label>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Téléphone</span><input type="text" name="telephone" value="<?= e( $edit ? $client['telephone'] : old( 'telephone' ) ) ?>" placeholder="07 00 00 00 00"></label>
				<label class="fld"><span>Email</span><input type="email" name="email" value="<?= e( $edit ? $client['email'] : old( 'email' ) ) ?>"></label>
			</div>
			<label class="fld"><span>Adresse</span><input type="text" name="adresse" value="<?= e( $edit ? $client['adresse'] : old( 'adresse' ) ) ?>"></label>
			<div class="actions">
				<button class="btn btn-primary" type="submit"><?= $edit ? 'Enregistrer' : 'Créer le client' ?></button>
				<a class="btn btn-ghost" href="<?= e( url( 'facturation/clients' ) ) ?>">Annuler</a>
			</div>
		</form>
	</div>
</div>
<script>
(function(){var s=document.getElementById('cli-type'),f=document.getElementById('ncc-fld');
function t(){f.style.opacity=(s.value==='B2B')?'1':'.6';}s.addEventListener('change',t);t();})();
</script>
