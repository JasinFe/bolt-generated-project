<?php /** @var string $title @var string $tab @var bool $ready @var string $env @var array|null $synth @var array $attente @var array|null $flash */ ?>
<div class="card" style="max-width:1000px">
	<div class="card-head"><h2>Suivi de la certification FNE</h2></div>
	<div class="card-body">

		<?php if ( $flash ) : ?>
			<p class="<?= 'ok' === $flash['type'] ? 'msg-ok' : 'msg-err' ?>"><?= e( $flash['msg'] ) ?></p>
		<?php endif; ?>

		<?php if ( ! $ready ) : ?>
			<p class="help" style="margin-top:0">
				La FNE n'est pas configurée sur ce dossier. Rien n'est envoyé à la DGI, et cet écran restera vide.
				<a href="<?= e( url( 'facturation/fne' ) ) ?>">Renseigner les paramètres FNE</a>.
			</p>
		<?php elseif ( is_array( $synth ) ) : ?>

			<?php
			/*
			 * TROIS CHIFFRES, ET ILS NE DISENT PAS LA MÊME CHOSE.
			 *
			 * « En attente » compte tout ce qui n'a pas son cachet. « En file »
			 * est ce que le moteur va représenter tout seul. La différence —
			 * « à traiter » — est le seul nombre sur lequel l'exploitant peut
			 * agir, et c'est donc celui qui doit ressortir. Afficher un total
			 * unique de douze factures ferait croire à douze gestes à faire,
			 * alors que onze se règlent d'elles-mêmes.
			 */
			?>
			<div class="kpi row" style="gap:14px;flex-wrap:wrap;margin-bottom:14px">
				<div class="stat <?= $synth['a_traiter'] ? 'kpi-neg' : 'kpi-pos' ?>" style="min-width:180px">
					<span class="muted">à traiter — demandent un geste</span>
					<span class="stat-value"><?= (int) $synth['a_traiter'] ?></span>
				</div>
				<div class="stat" style="min-width:180px">
					<span class="muted">reprises automatiquement</span>
					<span class="stat-value"><?= (int) $synth['en_file'] ?></span>
				</div>
				<div class="stat" style="min-width:180px">
					<span class="muted">certifiées sur 30 jours</span>
					<span class="stat-value"><?= (int) $synth['certifiees_30j'] ?></span>
				</div>
				<div class="stat" style="min-width:180px">
					<span class="muted">stickers restants</span>
					<span class="stat-value"><?= null !== $synth['stickers'] ? (int) $synth['stickers'] : '—' ?></span>
				</div>
			</div>

			<?php if ( null !== $synth['stickers'] ) : ?>
				<p class="help" style="margin-top:0">
					Le solde de stickers est celui que la DGI a renvoyé lors de la dernière certification
					(<?= e( $synth['stickers_le'] ) ?>). <strong>Ce n'est pas un solde temps réel</strong> —
					aucune API ne le donne autrement, et le présenter comme actuel serait inexact.
				</p>
			<?php endif; ?>

			<?php if ( $synth['causes'] ) : ?>
				<h3 style="font-size:14px;margin:18px 0 6px">Pourquoi elles n'ont pas de cachet</h3>
				<p class="help" style="margin-top:0">
					Regroupé par cause : douze factures bloquées par le même NCC manquant sont
					<strong>un</strong> problème, pas douze.
				</p>
				<table class="tbl">
					<thead><tr><th>Cause</th><th>Factures</th><th>Reprise</th><th>Message de la plateforme</th></tr></thead>
					<tbody>
					<?php foreach ( $synth['causes'] as $c ) : ?>
						<tr>
							<td><?= e( $c['cause'] ) ?></td>
							<td><strong><?= (int) $c['nombre'] ?></strong></td>
							<td><?= $c['rejouable'] ? '<span style="color:var(--ok)">automatique</span>' : '<span style="color:var(--warn)">à vous</span>' ?></td>
							<td class="muted" style="font-size:12px"><?= e( mb_substr( (string) $c['detail'], 0, 90 ) ) ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<form method="post" action="<?= e( url( 'facturation/fne/relancer' ) ) ?>" style="margin:14px 0">
				<?= FKC_Csrf::field() ?>
				<button class="btn">Relancer les tentatives rattrapables</button>
				<span class="help">Ne relance que ce qui a échoué sur le réseau. Une facture bloquée par un NCC
					manquant ou des stickers épuisés ne repassera pas tant que la cause n'est pas levée&nbsp;:
					la relancer en boucle masquerait les vrais retards.</span>
			</form>

			<h3 style="font-size:14px;margin:18px 0 6px">Factures sans cachet fiscal</h3>
			<?php if ( ! $attente ) : ?>
				<p class="muted">Aucune. Toutes les factures émises portent leur certification.</p>
			<?php else : ?>
				<p class="help" style="margin-top:0">
					<strong>Ne remettez aucune de ces factures à son client.</strong> La FNE valide le document
					AVANT sa remise&nbsp;: une facture sans cachet est refusée en déduction, chez votre client
					comme chez vous.
				</p>
				<table class="tbl">
					<thead><tr><th>Numéro</th><th>Date</th><th>Client</th><th class="num">Montant TTC</th><th>État</th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $attente as $f ) : ?>
						<tr>
							<td><?= e( $f['numero'] ) ?></td>
							<td><?= e( $f['date_facture'] ) ?></td>
							<td><?= e( $f['client_nom'] ) ?></td>
							<td class="num"><?= fkc_money( $f['montant_ttc'] ) ?></td>
							<td><span style="color:var(--warn)"><?= e( $f['fne_status'] ) ?></span></td>
							<td><a class="btn btn-sm" href="<?= e( url( 'facturation/factures/' . (int) $f['id'] ) ) ?>">Ouvrir</a></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

		<?php endif; ?>
	</div>
</div>
