<?php /** @var array $cfg @var string $env @var bool $ready @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'facturation::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<span class="muted">Interfaçage API · DGI Côte d'Ivoire</span>
	<span class="modbadge <?= $ready ? 'b-on' : 'b-off' ?>"><?= $ready ? 'Configurée · env. ' . e( $env ) : 'Non configurée' ?></span>
</div>

<div class="card" style="max-width:760px;margin-bottom:12px"><div class="card-body" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
	<span>Pas encore de clé de production ? Constituez le dossier de spécimens demandé par la DGI.</span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/fne/specimens' ) ) ?>">Spécimens de validation</a>
</div></div>
<div class="card" style="max-width:760px">
	<div class="card-head"><h2>Paramètres de connexion FNE</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'facturation/fne' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>URL de l'API FNE (base, sans l'endpoint)</span>
				<input type="text" name="fne_api_url" value="<?= e( $cfg['fne_api_url'] ) ?>" placeholder="http://54.247.95.108/ws">
			</label>
			<p class="help">
				Bac à sable DGI : <code><?= e( FKC_Fne::URL_TEST ) ?></code> · Production : <code><?= e( FKC_Fne::URL_PRODUCTION ) ?></code>
				— le <code>www.</code> est indispensable, sans lui le serveur répond 404.
				Saisissez la BASE seulement : FinaKop y ajoute <code>/external/invoices/sign</code>.
			</p>
			<p class="help">
				<button class="btn btn-ghost btn-sm" type="submit" name="fne_api_url_preset" value="test">Utiliser le bac à sable</button>
				<button class="btn btn-ghost btn-sm" type="submit" name="fne_api_url_preset" value="production">Utiliser la production</button>
			</p>
			<?php $anomalies = FKC_Fne::diagnosticUrl(); $ep = FKC_Fne::endpointSign(); ?>
			<p class="help">Adresse réellement appelée : <code><?= e( $ep ?: '—' ) ?></code></p>
			<?php foreach ( $anomalies as $a ) : ?>
				<p class="help" style="color:#ffb020"><?= e( $a ) ?></p>
			<?php endforeach; ?>
			<?php
			/*
			 * LA CLÉ N'EST JAMAIS RÉAFFICHÉE.
			 *
			 * Elle vit dans le coffre chiffré (FKC_Vault), cloisonnée par
			 * société. Le champ sert à en POSER une nouvelle : laissé vide, il
			 * ne touche à rien. L'empreinte suffit à vérifier qu'on a bien la
			 * bonne — c'est ce dont un exploitant a besoin, et rien de plus.
			 */
			$emp = (string) ( $cfg['fne_api_key_empreinte'] ?? '' );
			?>
			<label class="fld"><span>Clé API (Bearer)</span>
				<input type="password" name="fne_api_key" value="" autocomplete="new-password" spellcheck="false"
				       placeholder="<?= $emp ? 'laisser vide pour conserver la clé actuelle' : 'clé fournie par votre espace FNE' ?>">
			</label>
			<?php if ( $emp ) : ?>
				<p class="help">Clé enregistrée : <code><?= e( $emp ) ?></code> — conservée chiffrée. Saisissez-en une nouvelle uniquement pour la remplacer.</p>
				<label class="fld" style="display:flex;align-items:center;gap:8px">
					<input type="checkbox" name="fne_api_key_supprimer" value="1">
					<span style="font-weight:400">Supprimer la clé enregistrée (la certification cessera)</span>
				</label>
			<?php else : ?>
				<p class="help">Aucune clé enregistrée — la certification des factures est inactive.</p>
			<?php endif; ?>
			<?php if ( empty( $cfg['fne_chiffrement_ok'] ) ) : ?>
				<div class="alert alert-warn">⚠️ Le chiffrement au repos est indisponible sur cet hébergement (ni libsodium ni OpenSSL AES-256-GCM) : la clé sera stockée telle quelle. Définissez <code>FKC_ENCRYPTION_KEY</code> dans <code>wp-config.php</code> et activez l'une des deux extensions.</div>
			<?php endif; ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>NCC de l'entreprise</span><input type="text" name="fne_ncc" class="code" value="<?= e( $cfg['fne_ncc'] ) ?>" placeholder="ex. 2506650V"></label>
				<label class="fld"><span>Régime</span>
					<input type="text" value="<?= e( $cfg['fne_regime'] ?: '—' ) ?>" readonly>
					<small class="help">Repris de la Fiscalité — l'API de certification ne transporte pas le régime, il est attaché à votre compte FNE.
						<a href="<?= e( url( 'fiscalite/regime' ) ) ?>">Modifier le régime</a></small>
				</label>
			</div>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Établissement (nom exact espace FNE)</span><input type="text" name="fne_establishment" value="<?= e( $cfg['fne_establishment'] ) ?>" placeholder="Siège social"></label>
				<label class="fld"><span>Point de vente</span><input type="text" name="fne_point_of_sale" value="<?= e( $cfg['fne_point_of_sale'] ) ?>" placeholder="Abidjan"></label>
			</div>
			<p class="help">⚠️ L'établissement et le point de vente doivent correspondre <strong>exactement</strong> aux noms enregistrés dans votre espace FNE DGI, sinon la signature échoue.</p>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Message commercial par défaut</span><input type="text" name="fne_commercial_message" value="<?= e( $cfg['fne_commercial_message'] ) ?>"></label>
				<label class="fld"><span>Pied de facture par défaut</span><input type="text" name="fne_footer" value="<?= e( $cfg['fne_footer'] ) ?>"></label>
			</div>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Raison sociale (en-tête des factures)</span><input type="text" name="fne_company_name" value="<?= e( $cfg['fne_company_name'] ) ?>" placeholder="KOPHI'S GROUP SAS"></label>
				<label class="fld"><span>Compte de vente (écriture auto)</span><input type="text" name="fne_compte_vente" class="code" value="<?= e( $cfg['fne_compte_vente'] ) ?>" placeholder="701000"></label>
			</div>
			<label class="fld"><span>URL de vérification (QR code)</span><input type="text" name="fne_verify_url" value="<?= e( $cfg['fne_verify_url'] ) ?>" placeholder="https://e-impots.gouv.ci/verifier"></label>
			<div class="actions">
				<button class="btn btn-primary" type="submit">Enregistrer</button>
			</div>
		</form>

		<div class="auth-divider" style="margin:22px 0 16px"></div>
		<form method="post" action="<?= e( url( 'facturation/fne/test' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-ghost" type="submit">Tester la connexion à l'API FNE</button>
			<span class="help" style="margin-left:10px">Vérifie que la clé est acceptée par la DGI (enregistrez d'abord).</span>
		</form>
	</div>
</div>

<div class="card" style="max-width:760px">
	<div class="card-head"><h2>Comment ça marche</h2></div>
	<div class="card-body">
		<p class="help" style="margin:0">1. Saisissez une facture (Factures › Nouvelle facture). &nbsp; 2. Ouvrez-la et cliquez sur <strong>« Certifier via la FNE »</strong>. &nbsp; 3. FinaKop envoie la facture à l'API DGI, récupère la <strong>référence</strong>, le <strong>QR code</strong> et le <strong>visuel FNE</strong>, et décrémente votre solde de stickers. La fonction est disponible dans <strong>toutes les éditions</strong> (Starter → Creative).</p>
	</div>
</div>
