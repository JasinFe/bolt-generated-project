<?php
/**
 * SPÉCIMENS DE VALIDATION FNE (1.802.0) — le dossier à transmettre à la DGI
 * pour obtenir sa clé de production.
 *
 * @var array $etat @var array $modeles @var array $pieces @var string $contact
 * @var string $urlTest @var array|null $flash @var string $tab
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'facturation::_subnav', array( 'tab' => $tab ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="max-width:900px"><div class="card-head"><h2 style="margin:0">Spécimens de validation DGI</h2></div><div class="card-body">
	<p class="muted" style="margin:0 0 8px;font-size:12.5px">
		Avant de délivrer une clé de production, la DGI demande un jeu de factures certifiées dans son bac à sable — les spécimens — et leurs avoirs.
		FinaKop les fabrique, les certifie et prépare le dossier à joindre à votre demande, adressée à <code><?= e( $contact ) ?></code>.
	</p>
	<p style="margin:0">
		Environnement : <strong style="color:<?= $etat['bac_a_sable'] ? '#3ddc84' : '#ff6b6b' ?>"><?= e( $etat['environnement'] ) ?></strong>
		<?php if ( ! $etat['bac_a_sable'] ) : ?>
			— la génération est refusée hors du bac à sable (<code><?= e( $urlTest ) ?></code>) : en production, elle consommerait vos stickers et certifierait de fausses ventes à votre nom.
			<a href="<?= e( url( 'facturation/fne' ) ) ?>">Changer d'adresse</a>
		<?php endif; ?>
	</p>
	<p style="margin:8px 0 0">
		Ventes : <strong><?= (int) $etat['ventes_certifiees'] ?> / <?= (int) $etat['ventes_attendues'] ?></strong> certifiée(s) ·
		Avoirs : <strong><?= (int) $etat['avoirs_certifies'] ?> / <?= (int) $etat['avoirs_attendus'] ?></strong> certifié(s)
		<?php if ( $etat['complet'] ) : ?><span style="color:#3ddc84"> — dossier complet</span>
		<?php else : ?><span style="color:#ffb020"> — reste : <?= e( implode( ', ', $etat['manques'] ) ) ?></span><?php endif; ?>
	</p>
</div>
<div class="card-body" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;border-top:1px solid rgba(255,255,255,.06)">
	<form method="post" action="<?= e( url( 'facturation/fne/specimens/ventes' ) ) ?>" style="display:flex;gap:6px;align-items:center;margin:0">
		<?= FKC_Csrf::field() ?><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>">
		<button class="btn btn-primary btn-sm" <?= $etat['bac_a_sable'] ? '' : 'disabled' ?>>1 · Générer et certifier les ventes</button>
	</form>
	<form method="post" action="<?= e( url( 'facturation/fne/specimens/avoirs' ) ) ?>" style="margin:0">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-ghost btn-sm" <?= $etat['bac_a_sable'] && $etat['ventes_certifiees'] ? '' : 'disabled' ?>>2 · Générer et certifier les avoirs</button>
	</form>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'facturation/fne/specimens/dossier' ) ) ?>">3 · Télécharger le dossier (JSON)</a>
	<form method="post" action="<?= e( url( 'facturation/fne/specimens/supprimer' ) ) ?>" style="margin:0"
		onsubmit="return confirm('Supprimer tous les spécimens ? À faire une fois la clé de production obtenue.');">
		<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Supprimer les spécimens</button>
	</form>
</div></div>

<div class="card card-flush" style="max-width:900px;margin-top:12px"><div class="card-head"><h3 style="margin:0">Cas couverts</h3></div>
<table class="table"><thead><tr><th>Cas</th><th>Modèle</th><th>Paiement</th><th>Pièce</th><th>Statut FNE</th></tr></thead><tbody>
<?php
$parCle = array();
foreach ( $pieces as $p ) { $parCle[ (string) $p['specimen_cle'] ] = $p; }
$lignes = array();
foreach ( $modeles as $m ) { $lignes[] = array( $m['cle'], $m['libelle'], $m['template'], $m['payment_method'] ); }
foreach ( FKC_FneSpecimens::clesAvoir() as $c ) { $lignes[] = array( 'avoir_' . $c, 'Avoir sur « ' . $c . ' »', 'avoir', '—' ); }
?>
<?php foreach ( $lignes as $l ) : $p = $parCle[ $l[0] ] ?? null; ?>
	<tr>
		<td><code><?= e( $l[0] ) ?></code></td>
		<td><?= e( $l[1] ) ?></td>
		<td><?= e( $l[3] ) ?></td>
		<td><?php if ( $p ) : ?><a href="<?= e( url( 'facturation/factures/' . (int) $p['id'] ) ) ?>"><?= e( $p['numero'] ) ?></a>
			<div class="muted" style="font-size:12px"><?= fkc_money( $p['montant_ttc'] ) ?> F TTC</div><?php else : ?><span class="muted">à générer</span><?php endif; ?></td>
		<td><?php if ( ! $p ) : ?><span class="muted">—</span>
			<?php elseif ( 'CERTIFIE' === $p['fne_status'] ) : ?><span style="color:#3ddc84">certifié</span>
				<div class="muted" style="font-size:12px"><?= e( $p['fne_reference'] ) ?></div>
			<?php else : ?><span style="color:#ff6b6b"><?= e( $p['fne_status'] ) ?></span>
				<div class="muted" style="font-size:12px"><?= e( $p['fne_error'] ) ?></div><?php endif; ?></td>
	</tr>
<?php endforeach; ?>
</tbody></table>
<div class="card-body"><p class="muted" style="margin:0;font-size:12.5px">
	Un spécimen ne se comptabilise pas : ce sont des pièces d'essai, elles n'entrent ni au chiffre d'affaires, ni à la TVA collectée, ni au poste client.
	Une fois votre clé de production obtenue, supprimez-les et basculez l'adresse de l'API sur la production.
</p></div></div>
