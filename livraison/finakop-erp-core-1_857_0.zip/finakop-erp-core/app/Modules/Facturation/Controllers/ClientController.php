<?php
/** Clients de facturation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ClientController {

	public function index() {
		FKC_View::render( 'facturation::clients.index', array(
			'title' => 'Facturation · Clients', 'tab' => 'clients',
			'clients' => FKC_Client::all(), 'flash' => $this->flash(),
		) );
	}

	public function create() {
		FKC_View::render( 'facturation::clients.form', array(
			'title' => 'Nouveau client', 'tab' => 'clients', 'client' => null, 'errors' => array(),
		) );
	}

	public function store() {
		$d = $this->input();
		$errs = $this->validate( $d );
		if ( $errs ) {
			$_SESSION['__old'] = $d;
			return FKC_View::render( 'facturation::clients.form', array(
				'title' => 'Nouveau client', 'tab' => 'clients', 'client' => null, 'errors' => $errs,
			) );
		}
		FKC_Client::create( $d );
		unset( $_SESSION['__old'] );
		$this->setFlash( 'Client « ' . $d['nom'] . ' » créé.' );
		redirect( 'facturation/clients' );
	}

	public function edit( $id ) {
		$c = FKC_Client::find( $id );
		if ( ! $c ) { redirect( 'facturation/clients' ); }
		FKC_View::render( 'facturation::clients.form', array(
			'title' => 'Modifier le client', 'tab' => 'clients', 'client' => $c, 'errors' => array(),
		) );
	}

	public function update( $id ) {
		$c = FKC_Client::find( $id );
		if ( ! $c ) { redirect( 'facturation/clients' ); }
		$d = $this->input();
		$errs = $this->validate( $d );
		if ( $errs ) {
			return FKC_View::render( 'facturation::clients.form', array(
				'title' => 'Modifier le client', 'tab' => 'clients', 'client' => $c, 'errors' => $errs,
			) );
		}
		FKC_Client::update( $id, $d );
		$this->setFlash( 'Client mis à jour.' );
		redirect( 'facturation/clients' );
	}

	protected function input() {
		return array(
			'code'      => trim( (string) ( $_POST['code'] ?? '' ) ),
			'nom'       => trim( (string) ( $_POST['nom'] ?? '' ) ),
			'type'      => 'B2B' === ( $_POST['type'] ?? 'B2C' ) ? 'B2B' : 'B2C',
			'ncc'       => trim( (string) ( $_POST['ncc'] ?? '' ) ),
			'telephone' => trim( (string) ( $_POST['telephone'] ?? '' ) ),
			'email'     => trim( (string) ( $_POST['email'] ?? '' ) ),
			'adresse'   => trim( (string) ( $_POST['adresse'] ?? '' ) ),
		);
	}
	protected function validate( $d ) {
		$e = array();
		if ( '' === $d['nom'] ) { $e[] = 'Le nom du client est requis.'; }
		if ( 'B2B' === $d['type'] && '' === $d['ncc'] ) { $e[] = 'Un client B2B doit avoir un NCC (obligatoire pour la FNE).'; }
		if ( '' !== $d['email'] && ! filter_var( $d['email'], FILTER_VALIDATE_EMAIL ) ) { $e[] = 'Email invalide.'; }
		return $e;
	}
	protected function setFlash( $m ) { $_SESSION['__flash_cli'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_cli'] ?? null; unset( $_SESSION['__flash_cli'] ); return $m; }
}
