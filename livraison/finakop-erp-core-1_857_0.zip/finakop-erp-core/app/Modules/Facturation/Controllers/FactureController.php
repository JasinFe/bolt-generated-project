<?php
/** Factures clients + certification FNE. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_FactureController {

	public function index() {
		FKC_Facture::comptabiliserAvoirsEnAttente();
		$opts = array(
			'q'         => trim( (string) ( $_GET['q'] ?? '' ) ) ?: null,
			'client_id' => (int) ( $_GET['client_id'] ?? 0 ) ?: null,
			'fne'       => in_array( $_GET['fne'] ?? '', array( 'CERTIFIE', 'NON_CERTIFIE', 'ERROR' ), true ) ? ( $_GET['fne'] ?? '' ) : null,
			'type'      => in_array( $_GET['type'] ?? '', array( 'facture', 'avoir' ), true ) ? ( $_GET['type'] ?? '' ) : null,
			'from'      => trim( (string) ( $_GET['from'] ?? '' ) ) ?: null,
			'to'        => trim( (string) ( $_GET['to'] ?? '' ) ) ?: null,
		);
		$active = (bool) array_filter( $opts );
		$factures = $active ? FKC_Facture::search( $opts ) : FKC_Facture::all();
		/*
		 * ÉTAT DE COMPTABILISATION (1.742.0). La liste montrait le statut FNE
		 * mais rien de la comptabilité : une facture passée au journal et une
		 * facture oubliée s'y ressemblaient. Les compteurs portent sur le
		 * résultat des filtres de l'écran ; le filtre « compta » s'y ajoute.
		 */
		$etats  = FKC_EtatCompta::pour( 'factures', $factures );
		$nbEtat = FKC_EtatCompta::compter( $etats );
		$filtre = FKC_EtatCompta::filtreDemande();
		if ( $filtre ) { $factures = FKC_EtatCompta::filtrer( $factures, $etats, $filtre ); }
		FKC_View::render( 'facturation::factures.index', array(
			'title'    => 'Facturation · Factures',
			'tab'      => 'factures',
			'factures' => $factures,
			'etats'    => $etats,
			'nbEtat'   => $nbEtat,
			'filtreCompta' => $filtre,
			'paiements'    => class_exists( 'FKC_Imputation' ) ? FKC_Imputation::etatsPaiement( $factures, 'client' ) : array(),
			'pieces'   => FKC_PieceJointe::countMap( 'facture', array_column( $factures, 'id' ) ),
			'clients'  => FKC_Client::all(),
			'opts'     => $opts,
			'fneReady' => FKC_Fne::isConfigured(),
			'flash'    => $this->flash(),
		) );
	}

	/** Proforma / devis : factures non encore certifiées (document non fiscal). */
	public function proforma() {
		$all = FKC_Facture::all();
		$proformas = array();
		foreach ( $all as $f ) {
			if ( 'CERTIFIE' !== ( $f['fne_status'] ?? '' ) ) { $proformas[] = $f; }
		}
		FKC_View::render( 'facturation::factures.proforma', array(
			'title'    => 'Facturation · Proforma',
			'tab'      => 'factures',
			'factures' => $proformas,
			'flash'    => $this->flash(),
		) );
	}

	public function create() {
		FKC_View::render( 'facturation::factures.form', array(
			'title'   => 'Nouvelle facture', 'tab' => 'factures',
			'clients' => FKC_Client::all(),
			'taxes'   => FKC_Facture::taxes(),
			'methods' => FKC_Facture::paymentMethods(),
			/*
			 * AUCUN NUMÉRO N'EST PRÉ-ATTRIBUÉ (1.728.0).
			 *
			 * Le formulaire affichait le prochain numéro AVANT que la facture
			 * existe, et le renvoyait tel quel en champ caché : il était donc
			 * calculé à l'ouverture de l'écran, quand aucune date n'était
			 * encore saisie. Une facture datée du 09/11/2025 ouverte en 2026
			 * repartait en « FAC-2026-0001 » — le correctif de 1.726.0 ne
			 * pouvait rien, le numéro lui arrivait déjà fait.
			 *
			 * Deux défauts en un, d'ailleurs : deux utilisateurs ouvrant le
			 * formulaire en même temps voyaient LE MÊME numéro, et le second à
			 * enregistrer en obtenait un autre sans comprendre pourquoi.
			 * Montrer un numéro avant que la pièce existe, c'est promettre ce
			 * qu'on ne peut pas tenir.
			 */
			'numero'  => '',
			'errors'  => array(),
			'items'   => FKC_ItemFacturation::all( 'vente', true ),
			'facture' => null, 'lignesEdit' => array(),
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	/** Divisions actives pour l'imputation analytique. */
	protected function divisions() {
		if ( ! class_exists( 'FKC_Division' ) ) { return array(); }
		try { return FKC_Division::all( true ); } catch ( Exception $e ) { return array(); }
	}
	protected function analytiqueOn() {
		$lic = FKC_License::resolve();
		return in_array( 'analytique', $lic['modules'] ?? array(), true );
	}
	protected function axes() {
		if ( ! class_exists( 'FKC_Axe' ) ) { return array(); }
		try { return FKC_Axe::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	protected function valeursMap() {
		$map = array();
		if ( ! class_exists( 'FKC_Valeur' ) ) { return $map; }
		foreach ( $this->axes() as $a ) {
			$opts = array();
			try { foreach ( FKC_Valeur::byAxe( (int) $a['id'], true ) as $v ) { $opts[] = array( 'id' => (int) $v['id'], 't' => $v['code'] . ' · ' . $v['libelle'] ); } } catch ( \Throwable $e ) {}
			$map[ (int) $a['id'] ] = $opts;
		}
		return $map;
	}
	protected function showAxes() {
		return $this->analytiqueOn() && count( $this->axes() ) > 0;
	}

	public function store() {
		$clientId = (int) ( $_POST['client_id'] ?? 0 );
		$client   = $clientId ? FKC_Client::find( $clientId ) : null;
		$entete = array(
			'numero'             => trim( (string) ( $_POST['numero'] ?? '' ) ),
			'client_id'          => $clientId ?: null,
			'client_nom'         => $client ? $client['nom'] : trim( (string) ( $_POST['client_nom'] ?? 'Client' ) ),
			'date_facture'       => trim( (string) ( $_POST['date_facture'] ?? '' ) ),
			'echeance'           => trim( (string) ( $_POST['echeance'] ?? '' ) ),
			'devise'             => 'XOF',
			'payment_method'     => (string) ( $_POST['payment_method'] ?? 'cash' ),
			'template'           => $client ? ( 'B2B' === $client['type'] ? 'B2B' : 'B2C' ) : 'B2C',
			'commercial_message' => trim( (string) ( $_POST['commercial_message'] ?? '' ) ),
			'footer'             => trim( (string) ( $_POST['footer'] ?? '' ) ),
			'division_id'        => ! empty( $_POST['division_id'] ) ? (int) $_POST['division_id'] : null,
			'axe_id'             => ! empty( $_POST['axe_id'] ) ? (int) $_POST['axe_id'] : null,
			'valeur_id'          => ! empty( $_POST['valeur_id'] ) ? (int) $_POST['valeur_id'] : null,
			'created_by'         => FKC_Auth::id(),
		);
		$lignes = array();
		foreach ( (array) ( $_POST['designation'] ?? array() ) as $i => $des ) {
			$lignes[] = array(
				'designation' => $des,
				'quantite'    => $this->num( $_POST['quantite'][ $i ] ?? 0 ),
				'pu_ht'       => $this->num( $_POST['pu_ht'][ $i ] ?? 0 ),
				'tva_code'    => $_POST['tva_code'][ $i ] ?? 'TVA',
				'unite'       => $_POST['unite'][ $i ] ?? 'pièce',
				'compte'      => $_POST['compte'][ $i ] ?? '',
				'item_id'     => $_POST['item_id'][ $i ] ?? 0,
			);
		}

		$errs = array();
		if ( '' === $entete['date_facture'] ) { $errs[] = 'La date de facture est requise.'; }
		if ( ! $errs ) {
			list( $ok, $msg, $fid ) = FKC_Facture::save( $entete, $lignes );
			// Facture ressaisie après un avoir : elle est reliée à celle qu'elle remplace.
			$remplace = (int) ( $_POST['remplace_id'] ?? 0 );
			if ( $ok && $remplace > 0 && class_exists( 'FKC_BPE' ) && FKC_Facture::find( $remplace ) ) {
				FKC_BPE::lier( 'facture', $remplace, 'facture', (int) $fid, 'corrige' );
				$msg .= ' Elle remplace la facture ' . FKC_Facture::find( $remplace )['numero'] . '.';
			}
			if ( $ok ) { $this->setFlash( $msg ); redirect( 'facturation/factures/' . $fid ); }
			$errs[] = $msg;
		}
		FKC_View::render( 'facturation::factures.form', array(
			'title' => 'Nouvelle facture', 'tab' => 'factures',
			'clients' => FKC_Client::all(), 'taxes' => FKC_Facture::taxes(),
			'methods' => FKC_Facture::paymentMethods(), 'numero' => $entete['numero'],
			'errors' => $errs, 'items' => FKC_ItemFacturation::all( 'vente', true ),
			'facture' => null, 'lignesEdit' => array(),
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	/** Édition d'une facture brouillon (avant comptabilisation/certification). */
	public function edit( $id ) {
		$f = FKC_Facture::find( $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); return; }
		if ( ! FKC_Facture::editable( $f ) ) {
			$this->setFlash( 'Cette facture n\'est plus modifiable.' );
			redirect( 'facturation/factures/' . (int) $id );
			return;
		}
		FKC_View::render( 'facturation::factures.form', array(
			'title'   => 'Modifier la facture ' . $f['numero'], 'tab' => 'factures',
			'clients' => FKC_Client::all(), 'taxes' => FKC_Facture::taxes(),
			'methods' => FKC_Facture::paymentMethods(), 'numero' => $f['numero'],
			'errors'  => array(), 'items' => FKC_ItemFacturation::all( 'vente', true ),
			'facture' => $f, 'lignesEdit' => $f['lignes'] ?? array(),
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	public function update( $id ) {
		$f = FKC_Facture::find( $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); return; }
		$clientId = (int) ( $_POST['client_id'] ?? 0 );
		$client   = $clientId ? FKC_Client::find( $clientId ) : null;
		$entete = array(
			'client_id'          => $clientId ?: null,
			'client_nom'         => $client ? $client['nom'] : trim( (string) ( $_POST['client_nom'] ?? $f['client_nom'] ) ),
			'date_facture'       => trim( (string) ( $_POST['date_facture'] ?? '' ) ),
			'echeance'           => trim( (string) ( $_POST['echeance'] ?? '' ) ),
			'payment_method'     => (string) ( $_POST['payment_method'] ?? 'cash' ),
			'template'           => $client ? ( 'B2B' === $client['type'] ? 'B2B' : 'B2C' ) : ( $f['template'] ?? 'B2C' ),
			'commercial_message' => trim( (string) ( $_POST['commercial_message'] ?? '' ) ),
			'footer'             => trim( (string) ( $_POST['footer'] ?? '' ) ),
			'division_id'        => ! empty( $_POST['division_id'] ) ? (int) $_POST['division_id'] : null,
			'axe_id'             => ! empty( $_POST['axe_id'] ) ? (int) $_POST['axe_id'] : null,
			'valeur_id'          => ! empty( $_POST['valeur_id'] ) ? (int) $_POST['valeur_id'] : null,
		);
		$lignes = array();
		foreach ( (array) ( $_POST['designation'] ?? array() ) as $i => $des ) {
			$lignes[] = array(
				'designation' => $des,
				'quantite'    => $this->num( $_POST['quantite'][ $i ] ?? 0 ),
				'pu_ht'       => $this->num( $_POST['pu_ht'][ $i ] ?? 0 ),
				'tva_code'    => $_POST['tva_code'][ $i ] ?? 'TVA',
				'unite'       => $_POST['unite'][ $i ] ?? 'pièce',
				'compte'      => $_POST['compte'][ $i ] ?? '',
				'item_id'     => $_POST['item_id'][ $i ] ?? 0,
			);
		}
		$errs = array();
		if ( '' === $entete['date_facture'] ) { $errs[] = 'La date de facture est requise.'; }
		if ( ! $errs ) {
			list( $ok, $msg ) = FKC_Facture::update( (int) $id, $entete, $lignes );
			if ( $ok ) { $this->setFlash( $msg ); redirect( 'facturation/factures/' . (int) $id ); return; }
			$errs[] = $msg;
		}
		$fres = FKC_Facture::find( $id );
		FKC_View::render( 'facturation::factures.form', array(
			'title' => 'Modifier la facture ' . $f['numero'], 'tab' => 'factures',
			'clients' => FKC_Client::all(), 'taxes' => FKC_Facture::taxes(),
			'methods' => FKC_Facture::paymentMethods(), 'numero' => $f['numero'],
			'errors' => $errs, 'items' => FKC_ItemFacturation::all( 'vente', true ),
			'facture' => $fres, 'lignesEdit' => $lignes,
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	/* ═══════════ Corriger une facture client (1.850.0) ═══════════ */

	/** Annule une facture jamais comptabilisée : pas d'avoir, le numéro reste dans la série. */
	public function annuler( $id ) {
		list( $ok, $msg ) = FKC_Facture::annulerNonComptabilisee( (int) $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/factures/' . (int) $id );
	}

	/**
	 * Corrige une facture COMPTABILISÉE (non certifiée) : l'avoir est émis,
	 * puis la facture corrigée se saisit pré-remplie. Le nouveau numéro n'est
	 * pas un choix : une facture de vente émise ne se réécrit pas, la série
	 * doit rester chronologique et continue.
	 */
	public function corriger( $id ) {
		$f = FKC_Facture::find( (int) $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); return; }
		if ( FKC_Facture::editable( $f ) ) { redirect( 'facturation/factures/' . (int) $id . '/modifier' ); return; }
		if ( 'CERTIFIE' === (string) ( $f['fne_status'] ?? '' ) ) {
			$this->setFlash( 'Facture certifiée FNE : l\'avoir doit être émis auprès de la DGI (bouton « Créer un avoir (annulation FNE) »), puis vous pourrez ressaisir la facture corrigée.', 'err' );
			redirect( 'facturation/factures/' . (int) $id ); return;
		}
		list( $ok, $msg, $aid ) = FKC_Facture::createAvoir( (int) $id );
		$existe = FKC_Facture::avoirDe( (int) $id );
		if ( ! $ok && ! $existe ) { $this->setFlash( $msg, 'err' ); redirect( 'facturation/factures/' . (int) $id ); return; }
		$this->setFlash( ( $ok ? $msg : 'Un avoir existe déjà (' . $existe['numero'] . ').' ) . ' Saisissez maintenant la facture corrigée : elle recevra un nouveau numéro.' );
		redirect( 'facturation/factures/' . (int) $id . '/ressaisir' );
	}

	/** Formulaire de la facture corrigée, pré-rempli depuis celle qu'elle remplace. */
	public function ressaisir( $id ) {
		$f = FKC_Facture::find( (int) $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); return; }
		if ( FKC_Facture::editable( $f ) ) { redirect( 'facturation/factures/' . (int) $id . '/modifier' ); return; }
		if ( ! FKC_Facture::avoirDe( (int) $id ) && 'annulee' !== (string) $f['statut'] ) {
			$this->setFlash( 'Cette facture est toujours en vigueur : corrigez-la (l\'avoir est émis d\'abord) avant d\'en ressaisir une autre.', 'err' );
			redirect( 'facturation/factures/' . (int) $id ); return;
		}
		$flash = $this->flash();
		$source = $f;
		$source['date_facture'] = date( 'Y-m-d' );   // une facture corrigée est émise aujourd'hui
		$source['echeance'] = '';
		FKC_View::render( 'facturation::factures.form', array(
			'title' => 'Facture corrigée — remplace ' . $f['numero'], 'tab' => 'factures',
			'clients' => FKC_Client::all(), 'taxes' => FKC_Facture::taxes(),
			'methods' => FKC_Facture::paymentMethods(), 'numero' => '',
			'errors' => array(), 'items' => FKC_ItemFacturation::all( 'vente', true ),
			'facture' => $source, 'lignesEdit' => (array) ( $f['lignes'] ?? array() ),
			'remplace' => $f, 'flashInfo' => $flash ? (string) $flash['msg'] : '',
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	/** Renumérotation d'une facture mal millésimée — refus tenus par le modèle. */
	public function renumeroter( $id ) {
		list( $ok, $msg ) = FKC_Facture::renumeroter( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/factures/' . (int) $id );
	}

	public function show( $id ) {
		$f = FKC_Facture::find( $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); }
		FKC_View::render( 'facturation::factures.show', array(
			'title'    => 'Facture ' . $f['numero'],
			'tab'      => 'factures',
			'facture'  => $f,
			'taxes'    => FKC_Facture::taxes(),
			'methods'  => FKC_Facture::paymentMethods(),
			'fneReady' => FKC_Fne::isConfigured(),
			'fneEnv'   => FKC_Fne::environment(),
			'verifyUrl'=> ( 'CERTIFIE' === $f['fne_status'] ) ? FKC_Fne::verifyUrl( $f ) : '',
			'pieces'   => FKC_PieceJointe::forSource( 'facture', $id ),
			'millesimeIncoherent' => FKC_Facture::millesimeIncoherent( $f ),
			'flash'    => $this->flash(),
			'wf'       => $this->wfFacture( $f ),
			'avisEncours' => $this->avisEncours( $f ),
			'avoirExistant' => FKC_Facture::avoirDe( (int) $id ),
			'enAttente' => FKC_Facture::enAttenteAuBrouillard( (int) $id ),
		) );
	}

	/**
	 * AVIS DE LIMITE DE CRÉDIT AU MOMENT D'ÉMETTRE (1.841.3).
	 *
	 * Le contrôle d'encours existait pour la brique verticale, la caisse et
	 * les ventes à crédit du commerce — pas pour le module Facturation, le
	 * chemin le plus courant. Une facture de dix millions pouvait partir
	 * chez un client déjà en contentieux sans que rien ne le signale.
	 *
	 * Ce n'est qu'un avis tant qu'on ne dépasse pas : au-delà, l'émission
	 * (comptabilisation ou certification FNE) est suspendue, et l'on peut
	 * passer outre en le disant — le geste est tracé.
	 *
	 * @return array|null avis de FKC_CreditManagement, null si sans objet
	 */
	protected function avisEncours( array $f ) {
		if ( ! empty( $f['ecriture_id'] ) || 'avoir' === ( $f['type'] ?? 'facture' ) || (float) $f['montant_ttc'] <= 0 ) { return null; }
		if ( empty( $f['client_id'] ) || ! class_exists( 'FKC_CreditManagement' ) ) { return null; }
		try {
			$dossier = class_exists( 'FKC_RecouvrementSuivi' ) ? FKC_RecouvrementSuivi::dossierActif( (int) $f['client_id'] ) : null;
			/*
			 * Sans limite convenue, l'avis ne dit rien d'utile ici (« aucune
			 * limite définie ») : l'afficher sur chaque facture de chaque
			 * client l'userait en une semaine. On ne parle que lorsqu'une
			 * limite existe ou que le client est en contentieux.
			 */
			$sit = FKC_CreditManagement::situation( (int) $f['client_id'] );
			if ( null === ( $sit['limite'] ?? null ) && ! $dossier ) { return null; }
			$a = FKC_CreditManagement::avisCommande( (int) $f['client_id'], (float) $f['montant_ttc'] );
			// Un client en contentieux : on ne lui ouvre pas de crédit supplémentaire sans le dire.
			if ( $dossier ) {
				$statuts = FKC_RecouvrementSuivi::statutsDossier();
				$a = array( 'avis' => 'refus', 'message' => 'Client en dossier « ' . ( $statuts[ $dossier['statut'] ] ?? $dossier['statut'] )
					. ' » au recouvrement. ' . ( null === ( $sit['limite'] ?? null ) ? '' : (string) ( $a['message'] ?? '' ) ) );
			}
			return $a;
		} catch ( \Throwable $e ) { return null; }
	}

	/**
	 * @return array{0:bool,1:string} autorisé, avertissement à joindre au message
	 */
	protected function controleEncours( array $f ) {
		$a = $this->avisEncours( $f );
		if ( ! $a ) { return array( true, '' ); }
		if ( 'refus' === ( $a['avis'] ?? '' ) ) {
			if ( empty( $_POST['forcer_encours'] ) ) {
				return array( false, 'Émission suspendue par le contrôle d\'encours — ' . ( $a['message'] ?? '' )
					. ' Cochez « passer outre » pour émettre malgré tout.' );
			}
			if ( class_exists( 'FKC_Security' ) ) {
				FKC_Security::audit( 'encours_force', 'Facture ' . ( $f['numero'] ?? $f['id'] ) . ' émise malgré le contrôle d\'encours : ' . ( $a['message'] ?? '' ) );
			}
			if ( class_exists( 'FKC_RecouvrementSuivi' ) ) {
				FKC_RecouvrementSuivi::ajouterAction( (int) $f['client_id'], (int) $f['id'], 'note',
					'Facture ' . ( $f['numero'] ?? '' ) . ' émise en passant outre le contrôle d\'encours (' . ( $a['message'] ?? '' ) . ').' );
			}
		}
		return array( true, in_array( $a['avis'] ?? '', array( 'attention', 'refus' ), true ) ? ' ⚠ Contrôle d\'encours : ' . ( $a['message'] ?? '' ) : '' );
	}

	/** État du workflow de validation pour une facture. */
	protected function wfFacture( $f ) {
		$seuil = class_exists( 'FKC_Validation' ) ? FKC_Validation::seuilFacture() : 0;
		$ttc   = abs( (float) ( $f['montant_ttc'] ?? 0 ) );
		$required = $seuil > 0 && $ttc >= $seuil && 'avoir' !== ( $f['type'] ?? 'facture' );
		$state = 'none'; $vid = 0;
		if ( $required && class_exists( 'FKC_Validation' ) ) {
			$last = FKC_Validation::latestFor( 'facture', (int) $f['id'] );
			if ( $last ) { $state = $last['statut']; $vid = (int) $last['id']; }
		}
		return array( 'required' => $required, 'state' => $state, 'vid' => $vid, 'seuil' => $seuil );
	}

	/** Crée une demande de validation pour une facture. */
	public function demanderValidation( $id ) {
		$f = FKC_Facture::find( (int) $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); }
		if ( ! empty( $f['ecriture_id'] ) ) { $this->setFlash( 'Facture déjà comptabilisée.', 'err' ); redirect( 'facturation/factures/' . (int) $id ); }
		if ( FKC_Validation::pendingExists( 'facture', (int) $id ) ) { $this->setFlash( 'Une demande de validation est déjà en attente.', 'warn' ); redirect( 'facturation/factures/' . (int) $id ); }
		$u = FKC_Auth::user();
		FKC_Validation::create( array(
			'type' => 'facture', 'ref_type' => 'facture', 'ref_id' => (int) $id,
			'objet' => 'Facture ' . ( $f['numero'] ?? ( '#' . $id ) ) . ( ! empty( $f['client_nom'] ) ? ' — ' . $f['client_nom'] : '' ),
			'montant' => abs( (float) $f['montant_ttc'] ),
			'demandeur_id' => FKC_Auth::id(), 'demandeur_nom' => $u['nom_complet'] ?? '',
			'url' => 'facturation/factures/' . (int) $id,
		) );
		$this->setFlash( 'Demande de validation envoyée.' );
		redirect( 'facturation/factures/' . (int) $id );
	}

	/** Ajoute une pièce justificative à une facture. */
	public function pieceUpload( $id ) {
		$f = FKC_Facture::find( $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); }
		list( $ok, $msg ) = FKC_PieceJointe::add( 'facture', $id, $_FILES['piece'] ?? array() );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/factures/' . (int) $id );
	}
	public function pieceDownload( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj || 'facture' !== $pj['source_type'] ) { http_response_code( 404 ); echo 'Pièce introuvable.'; return; }
		FKC_PieceJointe::stream( $pj );
	}
	public function pieceDelete( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj ) { redirect( 'facturation/factures' ); }
		$fid = (int) $pj['source_id'];
		list( $ok, $msg ) = FKC_PieceJointe::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/factures/' . $fid );
	}

	/** Action : certifier la facture via l'API FNE (puis comptabilisation auto). */
	public function certify( $id ) {
		$fc = FKC_Facture::find( (int) $id );
		if ( ! $fc ) { redirect( 'facturation/factures' ); }
		// 1.844.0 — le régime décide de la TVA facturée : pas de certification sans lui.
		if ( class_exists( 'FKC_FiscalConfig' ) ) {
			list( $okR, $msgR ) = FKC_FiscalConfig::exigerRegime( 'Certification impossible' );
			if ( ! $okR ) { $this->setFlash( $msgR, 'err' ); redirect( 'facturation/factures/' . (int) $id ); }
		}
		// Contrôle d'encours AVANT la transmission à la DGI : une facture
		// certifiée ne se retire plus (1.841.3).
		list( $encOk, $encMsg ) = $this->controleEncours( $fc );
		if ( ! $encOk ) { $this->setFlash( $encMsg, 'err' ); redirect( 'facturation/factures/' . (int) $id ); }
		$res = FKC_Fne::certify( (int) $id );
		if ( $res['ok'] ) {
			$bal = ( null !== $res['balance'] ) ? ' Stickers restants : ' . (int) $res['balance'] . '.' : '';
			$w   = ! empty( $res['warning'] ) ? ' ⚠️ Stock de stickers bas.' : '';
			$msg = 'Facture certifiée FNE — réf. ' . $res['reference'] . '.' . $bal . $w;
			// Comptabilisation automatique de la vente.
			list( $cok, $cmsg ) = FKC_Facture::comptabiliser( (int) $id );
			$msg .= ' ' . $cmsg . $encMsg;
			$this->setFlash( $msg );
		} else {
			/*
			 * MISE EN FILE SI L'ÉCHEC EST PASSAGER (1.689.0).
			 *
			 * Jusqu'ici l'écran affichait l'erreur et s'arrêtait là : la
			 * facture restait en ERROR jusqu'à ce qu'un humain repense à
			 * recliquer, sans qu'aucun compteur ne signale l'arriéré. Une
			 * coupure de dix minutes un jour chargé laissait donc des factures
			 * non certifiées, invisibles, chez un contribuable dont les
			 * factures non conformes sont refusées en déduction.
			 *
			 * On ne met en file QUE ce qui vient du transport : un NCC absent
			 * ou des stickers épuisés exigent un geste humain, et boucler
			 * dessus masquerait les vrais retards.
			 */
			$erreur = (string) $res['error'];
			if ( class_exists( 'FKC_FneFile' ) && FKC_FneFile::rejouable( $erreur ) ) {
				FKC_FneFile::enfiler( (int) $id );
				$this->setFlash(
					'La plateforme FNE n\'a pas répondu. La facture est EN ATTENTE DE CERTIFICATION et sera '
					. 'représentée automatiquement — inutile de recliquer. Ne la remettez pas au client tant que '
					. 'le cachet fiscal n\'est pas obtenu. (' . $erreur . ')', 'err' );
			} else {
				$this->setFlash( 'Échec de certification : ' . $erreur, 'err' );
			}
		}
		redirect( 'facturation/factures/' . (int) $id );
	}

	/** Action : générer l'écriture comptable de vente (manuel). */
	public function comptabiliser( $id ) {
		$f = FKC_Facture::find( (int) $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); }
		// 1.844.0 — le régime décide de la TVA facturée : pas d'émission sans lui.
		if ( class_exists( 'FKC_FiscalConfig' ) ) {
			list( $okR, $msgR ) = FKC_FiscalConfig::exigerRegime( 'Comptabilisation impossible' );
			if ( ! $okR ) { $this->setFlash( $msgR, 'err' ); redirect( 'facturation/factures/' . (int) $id ); }
		}
		// Workflow : au-delà du seuil, une approbation est requise (les administrateurs peuvent passer outre).
		$wf = $this->wfFacture( $f );
		if ( $wf['required'] && 'approuve' !== $wf['state'] && ! FKC_Auth::isAdmin() ) {
			$this->setFlash(
				'en_attente' === $wf['state']
					? 'Comptabilisation bloquée : la demande de validation est en attente d\'approbation.'
					: 'Cette facture dépasse le seuil de validation et doit être approuvée avant comptabilisation.',
				'err'
			);
			redirect( 'facturation/factures/' . (int) $id );
		}
		list( $encOk, $encMsg ) = $this->controleEncours( $f );
		if ( ! $encOk ) { $this->setFlash( $encMsg, 'err' ); redirect( 'facturation/factures/' . (int) $id ); }
		list( $ok, $msg ) = FKC_Facture::comptabiliser( (int) $id );
		$this->setFlash( $msg . ( $ok ? $encMsg : '' ), $ok ? 'ok' : 'err' );
		if ( $ok && class_exists( 'FKC_Notification' ) ) {
			$f = FKC_Facture::find( (int) $id );
			$num = $f['numero'] ?? ( '#' . (int) $id );
			FKC_Notification::notifyAdmins( 'Facture comptabilisée', 'Facture ' . $num . ( ! empty( $f['client_nom'] ) ? ' — ' . $f['client_nom'] : '' ), 'succes', 'facturation/factures/' . (int) $id );
		}
		redirect( 'facturation/factures/' . (int) $id );
	}

	/** Crée une facture d'avoir comptable (note de crédit), indépendante de la FNE. */
	public function avoirNote( $id ) {
		list( $ok, $msg, $aid ) = FKC_Facture::createAvoir( (int) $id );
		$this->setFlash( $msg );
		redirect( $ok && $aid ? 'facturation/factures/' . (int) $aid : 'facturation/factures/' . (int) $id );
	}

	/** Action : avoir / annulation FNE. */
	public function avoir( $id ) {
		$res = FKC_Fne::refund( (int) $id );
		if ( $res['ok'] ) {
			$bal = ( null !== $res['balance'] ) ? ' Stickers restants : ' . (int) $res['balance'] . '.' : '';
			$this->setFlash( 'Avoir FNE émis — réf. ' . $res['reference'] . '. Facture annulée.' . $bal );
		} else {
			$this->setFlash( 'Échec de l\'avoir : ' . $res['error'], 'err' );
		}
		redirect( 'facturation/factures/' . (int) $id );
	}

	/** Facture imprimable (PDF via navigateur), sans habillage de l'app. */
	public function imprimer( $id ) {
		$f = FKC_Facture::find( $id );
		if ( ! $f ) { redirect( 'facturation/factures' ); }
		$cli = ! empty( $f['client_id'] ) ? FKC_Client::find( $f['client_id'] ) : null;
		FKC_View::render( 'facturation::factures.print', array(
			'facture'   => $f,
			'client'    => $cli,
			'cfg'       => FKC_Fne::configPublique(),
			'verifyUrl' => ( 'CERTIFIE' === $f['fne_status'] || ! empty( $f['fne_reference'] ) ) ? FKC_Fne::verifyUrl( $f ) : '',
		), false );
	}

	protected function num( $v ) { return (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $v ); }
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_fac'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_fac'] ?? null; unset( $_SESSION['__flash_fac'] ); return $m; }
}
