<?php
/** Paramètres FNE + test de connexion. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_FneController {

	public function config() {
		FKC_View::render( 'facturation::fne.config', array(
			'title' => 'Facturation · Paramètres FNE', 'tab' => 'fne',
			// configPublique() et non config() : la clé de signature ne doit
			// pas descendre jusqu'au gabarit, où elle finirait dans le HTML,
			// l'historique du navigateur et tout cache intermédiaire.
			'cfg'   => FKC_Fne::configPublique(), 'env' => FKC_Fne::environment(),
			'ready' => FKC_Fne::isConfigured(), 'flash' => $this->flash(),
		) );
	}

	/**
	 * Supervision FNE : ce qui attend son cachet, et ce qu'il faut faire.
	 *
	 * SÉPARÉ DE L'ÉCRAN DE PARAMÈTRES, délibérément. Les paramètres se
	 * règlent une fois ; la supervision se consulte. Les mêler obligerait
	 * l'exploitant à traverser un formulaire de clés API pour savoir combien
	 * de factures attendent — et lui ferait courir le risque d'enregistrer
	 * par mégarde une configuration qu'il ne venait pas modifier.
	 */
	public function supervision() {
		FKC_View::render( 'facturation::fne.supervision', array(
			'title'   => 'Facturation · Suivi FNE', 'tab' => 'fne',
			'ready'   => FKC_Fne::isConfigured(),
			'env'     => FKC_Fne::environment(),
			'synth'   => class_exists( 'FKC_FneFile' ) ? FKC_FneFile::synthese() : null,
			'attente' => class_exists( 'FKC_FneFile' ) ? FKC_FneFile::enAttente( 100 ) : array(),
			'flash'   => $this->flash(),
		) );
	}

	/** Remet en file toutes les factures dont l'échec est rattrapable. */
	public function relancer() {
		if ( ! class_exists( 'FKC_FneFile' ) ) { redirect( 'facturation/fne/suivi' ); }
		$n = FKC_FneFile::relancerTout();
		$this->setFlash(
			$n
				? $n . ' facture(s) remises en file. Elles seront représentées à la DGI au prochain passage du moteur — inutile de rester sur cette page.'
				: 'Rien à relancer : les factures qui restent attendent un geste de votre part, pas une nouvelle tentative.',
			$n ? 'ok' : 'err'
		);
		redirect( 'facturation/fne/suivi' );
	}

	/* ══ Spécimens du dossier de validation DGI (1.802.0) ════════════════ */

	public function specimens() {
		FKC_View::render( 'facturation::fne.specimens', array(
			'title' => 'Facturation · Spécimens FNE', 'tab' => 'fne',
			'etat' => FKC_FneSpecimens::etat(),
			'modeles' => FKC_FneSpecimens::modeles(),
			'pieces' => FKC_FneSpecimens::lister(),
			'contact' => FKC_FneSpecimens::CONTACT_DGI,
			'urlTest' => FKC_Fne::URL_TEST,
			'flash' => $this->flash(),
		) );
	}

	public function specimensVentes() {
		list( $ok, $msg ) = FKC_FneSpecimens::genererVentes( (string) ( $_POST['date'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/fne/specimens' );
	}

	public function specimensAvoirs() {
		list( $ok, $msg ) = FKC_FneSpecimens::genererAvoirs();
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/fne/specimens' );
	}

	public function specimensSupprimer() {
		list( $ok, $msg ) = FKC_FneSpecimens::supprimer();
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'facturation/fne/specimens' );
	}

	/** Dossier complet en JSON, à joindre au courriel de demande de clé. */
	public function specimensDossier() {
		$json = json_encode( FKC_FneSpecimens::dossier(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="FNE_specimens_' . date( 'Ymd_His' ) . '.json"' );
		echo $json;
		exit;
	}

	public function save() {
		FKC_Fne::saveConfig( $_POST );
		$this->setFlash( 'Paramètres FNE enregistrés.' );
		redirect( 'facturation/fne' );
	}

	public function test() {
		$res = FKC_Fne::testConnection();
		$this->setFlash( $res['ok'] ? ( '✓ ' . $res['message'] ) : ( '✗ ' . $res['error'] ), $res['ok'] ? 'ok' : 'err' );
		redirect( 'facturation/fne' );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_fne'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_fne'] ?? null; unset( $_SESSION['__flash_fne'] ); return $m; }
}
