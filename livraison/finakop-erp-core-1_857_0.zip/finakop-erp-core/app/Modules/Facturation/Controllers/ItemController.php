<?php
/** CRUD du référentiel des items de facturation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ItemController {

	protected function guard() {
		$lic = FKC_License::resolve();
		$ok  = FKC_Auth::isAdmin()
			|| ( in_array( 'facturation', $lic['modules'], true ) && FKC_Auth::can( 'facturation' ) )
			|| ( in_array( 'comptabilite', $lic['modules'], true ) && FKC_Auth::can( 'comptabilite' ) );
		if ( ! $ok ) { redirect( '' ); return false; }
		return true;
	}

	public function index() {
		if ( ! $this->guard() ) { return; }
		FKC_View::render( 'facturation::items.index', array(
			'title'   => 'Référentiels · Items de facturation', 'tab' => 'items',
			'ventes'  => FKC_ItemFacturation::all( 'vente' ),
			'achats'  => FKC_ItemFacturation::all( 'achat' ),
			'flash'   => $this->flash(),
		) );
	}

	public function create() {
		if ( ! $this->guard() ) { return; }
		$sens = 'achat' === ( $_GET['sens'] ?? '' ) ? 'achat' : 'vente';
		FKC_View::render( 'facturation::items.form', array(
			'title' => 'Nouvel item de facturation', 'tab' => 'items',
			'item'  => null, 'sens' => $sens, 'taxes' => FKC_Facture::taxes(), 'errors' => array(),
		) );
	}

	public function store() {
		if ( ! $this->guard() ) { return; }
		$errs = FKC_ItemFacturation::validate( $_POST, 0 );
		if ( ! $errs ) {
			FKC_ItemFacturation::create( $_POST );
			$this->setFlash( 'Item de facturation créé.' );
			redirect( 'referentiels/items' );
			return;
		}
		FKC_View::render( 'facturation::items.form', array(
			'title' => 'Nouvel item de facturation', 'tab' => 'items',
			'item'  => $_POST, 'sens' => ( 'achat' === ( $_POST['sens'] ?? '' ) ? 'achat' : 'vente' ),
			'taxes' => FKC_Facture::taxes(), 'errors' => $errs,
		) );
	}

	public function edit( $id ) {
		if ( ! $this->guard() ) { return; }
		$it = FKC_ItemFacturation::find( $id );
		if ( ! $it ) { redirect( 'referentiels/items' ); return; }
		FKC_View::render( 'facturation::items.form', array(
			'title' => 'Modifier l\'item', 'tab' => 'items',
			'item'  => $it, 'sens' => $it['sens'], 'taxes' => FKC_Facture::taxes(), 'errors' => array(),
		) );
	}

	public function update( $id ) {
		if ( ! $this->guard() ) { return; }
		$errs = FKC_ItemFacturation::validate( $_POST, (int) $id );
		if ( ! $errs ) {
			FKC_ItemFacturation::update( $id, $_POST );
			$this->setFlash( 'Item mis à jour.' );
			redirect( 'referentiels/items' );
			return;
		}
		$it = array_merge( (array) FKC_ItemFacturation::find( $id ), $_POST, array( 'id' => $id ) );
		FKC_View::render( 'facturation::items.form', array(
			'title' => 'Modifier l\'item', 'tab' => 'items',
			'item'  => $it, 'sens' => ( 'achat' === ( $_POST['sens'] ?? '' ) ? 'achat' : 'vente' ),
			'taxes' => FKC_Facture::taxes(), 'errors' => $errs,
		) );
	}

	public function delete( $id ) {
		if ( ! $this->guard() ) { return; }
		FKC_ItemFacturation::delete( $id );
		$this->setFlash( 'Item supprimé.' );
		redirect( 'referentiels/items' );
	}

	protected function setFlash( $m ) { $_SESSION['__flash_item'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_item'] ?? null; unset( $_SESSION['__flash_item'] ); return $m; }
}
