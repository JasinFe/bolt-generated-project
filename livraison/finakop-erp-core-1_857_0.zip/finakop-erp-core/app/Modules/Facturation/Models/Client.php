<?php
/** Clients — référentiel tiers (B2C / B2B), conforme SYSCOHADA/DGI. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Client {

	/** Régimes fiscaux DGI (CI). */
	public static function regimes() {
		return array(
			''                => '— Régime fiscal —',
			'reel_normal'     => 'Réel Normal (RNI)',
			'reel_simplifie'  => 'Réel Simplifié (RSI)',
			'tee'             => "Taxe d'État de l'Entreprenant (TEE)",
			'micro'           => 'Microentreprise',
			'exonere'         => 'Exonéré',
		);
	}
	/** Formes juridiques usuelles (OHADA). */
	public static function formes() {
		return array( '', 'SA', 'SAS', 'SASU', 'SARL', 'SARLU', 'SUARL', 'SNC', 'SCS', 'GIE', 'Entreprise individuelle', 'Coopérative', 'Association', 'ONG', 'Établissement public', 'Autre' );
	}

	public static function all( $actifsOnly = false ) {
		$sql = 'SELECT * FROM clients' . ( $actifsOnly ? ' WHERE COALESCE(actif,1)=1' : '' ) . ' ORDER BY nom ASC';
		return FKC_DB::q( $sql )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM clients WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function count() { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM clients' )->fetchColumn(); }

	/** Recherche un client par son numéro (code) ; $exceptId permet d'ignorer la fiche en cours d'édition. */
	public static function findByCode( $code, $exceptId = 0 ) {
		$code = trim( (string) $code );
		if ( '' === $code ) { return null; }
		$r = FKC_DB::q( 'SELECT * FROM clients WHERE code=? AND id<>? LIMIT 1', array( $code, (int) $exceptId ) )->fetch();
		return $r ?: null;
	}

	/**
	 * Prochain numéro client chronologique : CLI-0001, CLI-0002, …
	 * Basé sur le plus grand suffixe numérique déjà attribué (préfixe configurable).
	 */
	public static function nextCode( $prefix = 'CLI-' ) {
		$max = 0;
		try {
			$rows = FKC_DB::q( "SELECT code FROM clients WHERE code LIKE ?", array( $prefix . '%' ) )->fetchAll();
			foreach ( $rows as $r ) {
				if ( preg_match( '/(\d+)\s*$/', (string) $r['code'], $m ) ) { $max = max( $max, (int) $m[1] ); }
			}
		} catch ( \Throwable $e ) { /* table absente */ }
		return $prefix . str_pad( (string) ( $max + 1 ), 4, '0', STR_PAD_LEFT );
	}

	protected static function values( $d ) {
		return array(
			'code'            => ( $d['code'] ?? '' ) ?: null,
			'nom'             => trim( (string) ( $d['nom'] ?? '' ) ),
			'type'            => ( 'B2B' === ( $d['type'] ?? 'B2C' ) ) ? 'B2B' : 'B2C',
			'ncc'             => ( $d['ncc'] ?? '' ) ?: null,
			'rccm'            => ( $d['rccm'] ?? '' ) ?: null,
			'regime_fiscal'   => ( $d['regime_fiscal'] ?? '' ) ?: null,
			'forme_juridique' => ( $d['forme_juridique'] ?? '' ) ?: null,
			'compte'          => ( $d['compte'] ?? '' ) ?: FKC_PlanMetier::COMPTE_CLIENT,
			'contact'         => ( $d['contact'] ?? '' ) ?: null,
			'telephone'       => ( $d['telephone'] ?? '' ) ?: null,
			'email'           => ( $d['email'] ?? '' ) ?: null,
			'adresse'         => ( $d['adresse'] ?? '' ) ?: null,
			'ville'           => ( $d['ville'] ?? '' ) ?: null,
			'bp'              => ( $d['bp'] ?? '' ) ?: null,
			'pays'            => ( $d['pays'] ?? '' ) ?: "Côte d'Ivoire",
			'assujetti_tva'   => ! empty( $d['assujetti_tva'] ) ? 1 : 0,
			'delai_paiement'  => (int) ( $d['delai_paiement'] ?? 0 ),
			'devise'          => ( $d['devise'] ?? '' ) ?: 'XOF',
			'notes'           => ( $d['notes'] ?? '' ) ?: null,
			'actif'           => isset( $d['actif'] ) ? ( $d['actif'] ? 1 : 0 ) : 1,
			/*
			 * ZONE et GROUPE — la note 21A de la liasse ventile le chiffre
			 * d'affaires selon l'implantation du client. Aucun compte ne le
			 * dit : l'information se gagne ici, une fois, sur la fiche.
			 */
			'zone'            => in_array( $d['zone'] ?? '', array( 'etat_partie', 'region', 'hors_region' ), true ) ? $d['zone'] : 'etat_partie',
			'groupe'          => ! empty( $d['groupe'] ) ? 1 : 0,
		);
	}

	public static function create( $d ) {
		if ( empty( $d['code'] ) || '' === trim( (string) $d['code'] ) ) { $d['code'] = self::nextCode(); }
		$v = self::values( $d );
		FKC_DB::q(
			'INSERT INTO clients(code,nom,type,ncc,rccm,regime_fiscal,forme_juridique,compte,contact,telephone,email,adresse,ville,bp,pays,assujetti_tva,delai_paiement,devise,notes,actif,zone,groupe) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array_values( $v )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		$v = self::values( $d );
		FKC_DB::q(
			'UPDATE clients SET code=?,nom=?,type=?,ncc=?,rccm=?,regime_fiscal=?,forme_juridique=?,compte=?,contact=?,telephone=?,email=?,adresse=?,ville=?,bp=?,pays=?,assujetti_tva=?,delai_paiement=?,devise=?,notes=?,actif=?,zone=?,groupe=? WHERE id=?',
			array_merge( array_values( $v ), array( (int) $id ) )
		);
	}

	/** Suppression sécurisée : interdite si des pièces référencent le client. */
	public static function delete( $id ) {
		$id = (int) $id;
		$nbFac = (int) FKC_DB::q( 'SELECT COUNT(*) FROM factures WHERE client_id=?', array( $id ) )->fetchColumn();
		$nbReg = (int) FKC_DB::q( "SELECT COUNT(*) FROM reglements WHERE tiers_type='client' AND tiers_id=?", array( $id ) )->fetchColumn();
		if ( $nbFac > 0 || $nbReg > 0 ) {
			return array( false, 'Suppression impossible : ce client est lié à ' . $nbFac . ' facture(s) et ' . $nbReg . ' règlement(s). Désactivez-le plutôt.' );
		}
		FKC_DB::q( 'DELETE FROM clients WHERE id=?', array( $id ) );
		return array( true, 'Client supprimé.' );
	}
}
