<?php
/** Référentiel des items de facturation (vente / achat) rattachés à un compte. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ItemFacturation {

	/** Items d'un sens donné (vente|achat), actifs d'abord. */
	public static function all( $sens = null, $actifOnly = false ) {
		$w = array(); $p = array();
		if ( $sens ) { $w[] = 'sens=?'; $p[] = $sens; }
		if ( $actifOnly ) { $w[] = 'actif=1'; }
		$sql = 'SELECT * FROM items_facturation';
		if ( $w ) { $sql .= ' WHERE ' . implode( ' AND ', $w ); }
		$sql .= ' ORDER BY standard DESC, ordre, libelle COLLATE NOCASE';
		return FKC_DB::q( $sql, $p )->fetchAll();
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM items_facturation WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	public static function findByCode( $code, $exceptId = 0 ) {
		$code = trim( (string) $code );
		if ( '' === $code ) { return null; }
		$r = FKC_DB::q( 'SELECT * FROM items_facturation WHERE code=? AND id<>? LIMIT 1', array( $code, (int) $exceptId ) )->fetch();
		return $r ?: null;
	}

	/** Prochain code auto : ITM-0001… (préfixe selon sens). */
	public static function nextCode( $sens = 'vente' ) {
		$prefix = 'achat' === $sens ? 'ACHX-' : 'VTEX-';
		$max = 0;
		foreach ( FKC_DB::q( 'SELECT code FROM items_facturation WHERE code LIKE ?', array( $prefix . '%' ) )->fetchAll() as $r ) {
			if ( preg_match( '/(\d+)\s*$/', (string) $r['code'], $m ) ) { $max = max( $max, (int) $m[1] ); }
		}
		return $prefix . str_pad( (string) ( $max + 1 ), 4, '0', STR_PAD_LEFT );
	}

	protected static function clean( $d ) {
		$sens = 'achat' === ( $d['sens'] ?? 'vente' ) ? 'achat' : 'vente';
		$tva  = FKC_Facture::codeTaxeValide( $d['tva_code'] ?? '' );
		return array(
			'code'     => trim( (string) ( $d['code'] ?? '' ) ),
			'libelle'  => trim( (string) ( $d['libelle'] ?? '' ) ),
			'sens'     => $sens,
			'compte'   => trim( (string) ( $d['compte'] ?? '' ) ),
			'tva_code' => $tva,
			'pu_ht'    => (float) ( $d['pu_ht'] ?? 0 ),
			'actif'    => empty( $d['actif'] ) ? 0 : 1,
		);
	}

	public static function create( $d ) {
		$v = self::clean( $d );
		if ( '' === $v['code'] ) { $v['code'] = self::nextCode( $v['sens'] ); }
		FKC_DB::q(
			'INSERT INTO items_facturation(code,libelle,sens,compte,tva_code,pu_ht,standard,actif,ordre) VALUES(?,?,?,?,?,?,0,?,999)',
			array( $v['code'], $v['libelle'], $v['sens'], $v['compte'], $v['tva_code'], $v['pu_ht'], $v['actif'] )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	public static function update( $id, $d ) {
		$v = self::clean( $d );
		FKC_DB::q(
			'UPDATE items_facturation SET code=?,libelle=?,sens=?,compte=?,tva_code=?,pu_ht=?,actif=? WHERE id=?',
			array( $v['code'], $v['libelle'], $v['sens'], $v['compte'], $v['tva_code'], $v['pu_ht'], $v['actif'], (int) $id )
		);
	}

	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM items_facturation WHERE id=? AND standard=0', array( (int) $id ) );
	}

	/**
	 * Intitulé DÉCLARÉ d'un compte absent du dossier, ou '' (1.743.0).
	 *
	 * Seules font autorité les bibliothèques que le validateur du plan
	 * contrôle : socle transversal, socle FinaKop, packs métier. On n'invente
	 * jamais un intitulé — un compte mal nommé se propage dans tous les états.
	 */
	public static function libelleDeclare( $numero ) {
		$n = (string) $numero;
		// L'identité canonique d'abord, comme le générateur de plan : un même
		// numéro porte le même intitulé dans tous les dossiers.
		if ( class_exists( 'FKC_PlanCanonique' ) ) {
			$c = trim( (string) FKC_PlanCanonique::libelle( $n ) );
			if ( '' !== $c ) { return $c; }
		}
		if ( ! class_exists( 'FKC_PlanMetier' ) ) { return ''; }
		foreach ( array( FKC_PlanMetier::socleTransversal(), FKC_PlanMetier::socleCommun() ) as $liste ) {
			if ( isset( $liste[ $n ] ) ) { return trim( (string) $liste[ $n ] ); }
		}
		foreach ( (array) FKC_PlanMetier::bibliotheque() as $comptes ) {
			if ( isset( $comptes[ $n ] ) ) { return trim( (string) $comptes[ $n ] ); }
		}
		return '';
	}

	/**
	 * Ouvre au plan du dossier les comptes visés par les items actifs (1.743.0).
	 *
	 * LE PIÈGE. Un item peut viser une subdivision métier (627120) que le
	 * dossier n'a pas encore : le générateur de plan ne l'a pas posée. Le
	 * formulaire d'achat affichait alors « … (627120) », mais le sélecteur de
	 * compte n'ayant pas cette option, le choix de l'item ne changeait RIEN —
	 * la charge partait sur le compte déjà sélectionné, 601000 par défaut.
	 * Un item qui promet un compte et en impute un autre est pire qu'aucun
	 * item.
	 *
	 * Le compte n'est ouvert que s'il est DÉCLARÉ (libelleDeclare()). Sinon
	 * l'item reste inutilisable et comptesManquants() le signale.
	 *
	 * @return string[] numéros ouverts
	 */
	public static function assurerComptes( $sens = null ) {
		$ouverts = array();
		if ( ! class_exists( 'FKC_Compte' ) ) { return $ouverts; }
		foreach ( self::all( $sens, true ) as $it ) {
			$num = trim( (string) $it['compte'] );
			if ( '' === $num || FKC_Compte::byNumero( $num ) ) { continue; }
			$lib = self::libelleDeclare( $num );
			if ( '' === $lib ) { continue; }
			try {
				FKC_Compte::create( $num, $lib, 'detail', 'finakop', null ); // même origine que le générateur de plan
				if ( FKC_Compte::byNumero( $num ) ) { $ouverts[] = $num; }
			} catch ( \Throwable $e ) {
				if ( function_exists( 'fkc_log' ) ) { fkc_log( 'Item ' . $it['code'] . ' — compte ' . $num . ' : ' . $e->getMessage(), 'WARN' ); }
			}
		}
		return $ouverts;
	}

	/** Items actifs dont le compte n'existe pas au plan du dossier. */
	public static function comptesManquants( $sens = null ) {
		$out = array();
		if ( ! class_exists( 'FKC_Compte' ) ) { return $out; }
		foreach ( self::all( $sens, true ) as $it ) {
			if ( ! FKC_Compte::byNumero( (string) $it['compte'] ) ) { $out[] = $it; }
		}
		return $out;
	}

	/** Validation ; renvoie un tableau d'erreurs. */
	public static function validate( $d, $id = 0 ) {
		$e = array();
		if ( '' === trim( (string) ( $d['libelle'] ?? '' ) ) ) { $e[] = 'Le libellé est requis.'; }
		$cpt = trim( (string) ( $d['compte'] ?? '' ) );
		if ( '' === $cpt ) { $e[] = 'Le compte comptable est requis.'; }
		elseif ( class_exists( 'FKC_Compte' ) && ! FKC_Compte::byNumero( $cpt ) && '' === self::libelleDeclare( $cpt ) ) {
			// Un item vers un compte inexistant se choisit sans effet à la saisie.
			$e[] = 'Le compte « ' . $cpt . ' » n\'existe pas au plan comptable : créez-le d\'abord (Comptabilité → Plan comptable).';
		}
		$code = trim( (string) ( $d['code'] ?? '' ) );
		if ( '' !== $code && self::findByCode( $code, $id ) ) { $e[] = 'Ce code « ' . $code . ' » est déjà utilisé.'; }
		return $e;
	}
}
