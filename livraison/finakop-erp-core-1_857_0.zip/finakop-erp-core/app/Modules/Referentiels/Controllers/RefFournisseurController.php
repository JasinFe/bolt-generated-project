<?php
/** Référentiel Fournisseurs : CRUD complet (SYSCOHADA/DGI). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RefFournisseurController {

	public function index() {
		$q = trim( (string) ( $_GET['q'] ?? '' ) );
		$rows = array();
		foreach ( FKC_Fournisseur::all() as $f ) {
			if ( '' !== $q ) {
				$hay = mb_strtolower( ( $f['nom'] ?? '' ) . ' ' . ( $f['code'] ?? '' ) . ' ' . ( $f['email'] ?? '' ) . ' ' . ( $f['telephone'] ?? '' ) . ' ' . ( $f['ncc'] ?? '' ) );
				if ( false === mb_strpos( $hay, mb_strtolower( $q ) ) ) { continue; }
			}
			$f['solde'] = FKC_Fournisseur::solde( $f['id'] );
			$rows[] = $f;
		}
		FKC_View::render( 'referentiels::fournisseurs.index', array(
			'title' => 'Référentiels · Fournisseurs', 'tab' => 'fournisseurs',
			'fournisseurs' => $rows, 'q' => $q, 'flash' => $this->flash(),
		) );
	}

	public function create() {
		FKC_View::render( 'referentiels::fournisseurs.form', array(
			'title' => 'Référentiels · Nouveau fournisseur', 'tab' => 'fournisseurs-new',
			'fournisseur' => null, 'errors' => array(),
		) );
	}

	public function store() {
		$d = $this->fromPost();
		$errs = $this->validate( $d, 0 );
		if ( ! $errs ) {
			FKC_Fournisseur::create( $d );
			$this->setFlash( 'Fournisseur « ' . $d['nom'] . ' » créé.' );
			redirect( 'referentiels/fournisseurs' );
		}
		FKC_View::render( 'referentiels::fournisseurs.form', array(
			'title' => 'Référentiels · Nouveau fournisseur', 'tab' => 'fournisseurs-new',
			'fournisseur' => $d, 'errors' => $errs,
		) );
	}

	public function edit( $id ) {
		$f = FKC_Fournisseur::find( $id );
		if ( ! $f ) { redirect( 'referentiels/fournisseurs' ); }
		FKC_View::render( 'referentiels::fournisseurs.form', array(
			'title' => 'Référentiels · Modifier ' . $f['nom'], 'tab' => 'fournisseurs',
			'fournisseur' => $f, 'errors' => array(),
		) );
	}

	public function update( $id ) {
		$f = FKC_Fournisseur::find( $id );
		if ( ! $f ) { redirect( 'referentiels/fournisseurs' ); }
		$d = $this->fromPost();
		$errs = $this->validate( $d, (int) $id );
		if ( ! $errs ) {
			FKC_Fournisseur::update( $id, $d );
			$this->setFlash( 'Fournisseur « ' . $d['nom'] . ' » mis à jour.' );
			redirect( 'referentiels/fournisseurs' );
		}
		$d['id'] = (int) $id;
		FKC_View::render( 'referentiels::fournisseurs.form', array(
			'title' => 'Référentiels · Modifier ' . $f['nom'], 'tab' => 'fournisseurs',
			'fournisseur' => $d, 'errors' => $errs,
		) );
	}

	public function destroy( $id ) {
		list( $ok, $msg ) = FKC_Fournisseur::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'referentiels/fournisseurs' );
	}

	protected function fromPost() {
		return array(
			'code'            => trim( (string) ( $_POST['code'] ?? '' ) ),
			'nom'             => trim( (string) ( $_POST['nom'] ?? '' ) ),
			'type'            => $_POST['type'] ?? 'local',
			'ncc'             => trim( (string) ( $_POST['ncc'] ?? '' ) ),
			'rccm'            => trim( (string) ( $_POST['rccm'] ?? '' ) ),
			'regime_fiscal'   => $_POST['regime_fiscal'] ?? '',
			'forme_juridique' => $_POST['forme_juridique'] ?? '',
			'compte'          => trim( (string) ( $_POST['compte'] ?? '' ) ),
			'contact'         => trim( (string) ( $_POST['contact'] ?? '' ) ),
			'telephone'       => trim( (string) ( $_POST['telephone'] ?? '' ) ),
			'email'           => trim( (string) ( $_POST['email'] ?? '' ) ),
			'adresse'         => trim( (string) ( $_POST['adresse'] ?? '' ) ),
			'ville'           => trim( (string) ( $_POST['ville'] ?? '' ) ),
			'bp'              => trim( (string) ( $_POST['bp'] ?? '' ) ),
			'pays'            => trim( (string) ( $_POST['pays'] ?? '' ) ),
			'assujetti_tva'   => isset( $_POST['assujetti_tva'] ) ? 1 : 0,
			'delai_paiement'  => (int) ( $_POST['delai_paiement'] ?? 0 ),
			'zone'            => (string) ( $_POST['zone'] ?? 'etat_partie' ),
			'groupe'          => ! empty( $_POST['groupe'] ) ? 1 : 0,
			'devise'          => trim( (string) ( $_POST['devise'] ?? 'XOF' ) ),
			'notes'           => trim( (string) ( $_POST['notes'] ?? '' ) ),
			'actif'           => isset( $_POST['actif'] ) ? 1 : 0,
		);
	}

	protected function validate( $d, $id = 0 ) {
		$e = array();
		if ( '' === $d['nom'] ) { $e[] = 'La raison sociale / le nom est requis.'; }
		if ( '' !== $d['code'] && FKC_Fournisseur::findByCode( $d['code'], $id ) ) { $e[] = 'Ce numéro fournisseur (« ' . $d['code'] .' ») est déjà attribué à un autre fournisseur.'; }
		if ( 'local' === $d['type'] && '' === $d['ncc'] ) { $e[] = 'Le NCC est obligatoire pour un fournisseur local — conformité DGI.'; }
		if ( '' !== $d['email'] && ! filter_var( $d['email'], FILTER_VALIDATE_EMAIL ) ) { $e[] = "L'adresse e-mail n'est pas valide."; }
		if ( '' !== $d['compte'] && ! preg_match( '/^4\d{2,5}$/', $d['compte'] ) ) { $e[] = 'Le compte collectif fournisseur doit être un compte de classe 4 (ex : 401000).'; }
		return $e;
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_reff'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_reff'] ?? null; unset( $_SESSION['__flash_reff'] ); return $m; }
}
