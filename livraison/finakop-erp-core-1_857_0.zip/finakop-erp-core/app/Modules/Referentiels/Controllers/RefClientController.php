<?php
/** Référentiel Clients : CRUD complet (SYSCOHADA/DGI). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RefClientController {

	public function index() {
		$q = trim( (string) ( $_GET['q'] ?? '' ) );
		$rows = array();
		foreach ( FKC_Client::all() as $c ) {
			if ( '' !== $q ) {
				$hay = mb_strtolower( ( $c['nom'] ?? '' ) . ' ' . ( $c['code'] ?? '' ) . ' ' . ( $c['email'] ?? '' ) . ' ' . ( $c['telephone'] ?? '' ) . ' ' . ( $c['ncc'] ?? '' ) );
				if ( false === mb_strpos( $hay, mb_strtolower( $q ) ) ) { continue; }
			}
			$c['solde'] = FKC_Reglement::soldeClient( $c['id'] )['solde'];
			$rows[] = $c;
		}
		FKC_View::render( 'referentiels::clients.index', array(
			'title' => 'Référentiels · Clients', 'tab' => 'clients',
			'clients' => $rows, 'q' => $q, 'flash' => $this->flash(),
		) );
	}

	public function create() {
		FKC_View::render( 'referentiels::clients.form', array(
			'title' => 'Référentiels · Nouveau client', 'tab' => 'clients-new',
			'client' => null, 'errors' => array(),
		) );
	}

	public function store() {
		$d = $this->fromPost();
		$errs = $this->validate( $d, 0 );
		if ( ! $errs ) {
			$id = FKC_Client::create( $d );
			$this->setFlash( 'Client « ' . $d['nom'] . ' » créé.' );
			redirect( 'referentiels/clients' );
		}
		FKC_View::render( 'referentiels::clients.form', array(
			'title' => 'Référentiels · Nouveau client', 'tab' => 'clients-new',
			'client' => $d, 'errors' => $errs,
		) );
	}

	public function edit( $id ) {
		$c = FKC_Client::find( $id );
		if ( ! $c ) { redirect( 'referentiels/clients' ); }
		FKC_View::render( 'referentiels::clients.form', array(
			'title' => 'Référentiels · Modifier ' . $c['nom'], 'tab' => 'clients',
			'client' => $c, 'errors' => array(),
		) );
	}

	public function update( $id ) {
		$c = FKC_Client::find( $id );
		if ( ! $c ) { redirect( 'referentiels/clients' ); }
		$d = $this->fromPost();
		$errs = $this->validate( $d, (int) $id );
		if ( ! $errs ) {
			FKC_Client::update( $id, $d );
			$this->setFlash( 'Client « ' . $d['nom'] . ' » mis à jour.' );
			redirect( 'referentiels/clients' );
		}
		$d['id'] = (int) $id;
		FKC_View::render( 'referentiels::clients.form', array(
			'title' => 'Référentiels · Modifier ' . $c['nom'], 'tab' => 'clients',
			'client' => $d, 'errors' => $errs,
		) );
	}

	public function destroy( $id ) {
		list( $ok, $msg ) = FKC_Client::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'referentiels/clients' );
	}

	protected function fromPost() {
		return array(
			'code'            => trim( (string) ( $_POST['code'] ?? '' ) ),
			'nom'             => trim( (string) ( $_POST['nom'] ?? '' ) ),
			'type'            => $_POST['type'] ?? 'B2C',
			'ncc'             => trim( (string) ( $_POST['ncc'] ?? '' ) ),
			'rccm'            => trim( (string) ( $_POST['rccm'] ?? '' ) ),
			'regime_fiscal'   => $_POST['regime_fiscal'] ?? '',
			'forme_juridique' => $_POST['forme_juridique'] ?? '',
			'compte'          => trim( (string) ( $_POST['compte'] ?? '' ) ),
			'contact'         => trim( (string) ( $_POST['contact'] ?? '' ) ),
			'telephone'       => trim( (string) ( $_POST['telephone'] ?? '' ) ),
			'email'           => trim( (string) ( $_POST['email'] ?? '' ) ),
			'adresse'         => trim( (string) ( $_POST['adresse'] ?? '' ) ),
			'ville'           => trim( (string) ( $_POST['ville'] ?? '' ) ),
			'bp'              => trim( (string) ( $_POST['bp'] ?? '' ) ),
			'pays'            => trim( (string) ( $_POST['pays'] ?? '' ) ),
			'assujetti_tva'   => isset( $_POST['assujetti_tva'] ) ? 1 : 0,
			'delai_paiement'  => (int) ( $_POST['delai_paiement'] ?? 0 ),
			'zone'            => (string) ( $_POST['zone'] ?? 'etat_partie' ),
			'groupe'          => ! empty( $_POST['groupe'] ) ? 1 : 0,
			'devise'          => trim( (string) ( $_POST['devise'] ?? 'XOF' ) ),
			'notes'           => trim( (string) ( $_POST['notes'] ?? '' ) ),
			'actif'           => isset( $_POST['actif'] ) ? 1 : 0,
		);
	}

	protected function validate( $d, $id = 0 ) {
		$e = array();
		if ( '' === $d['nom'] ) { $e[] = 'La raison sociale / le nom est requis.'; }
		if ( '' !== $d['code'] && FKC_Client::findByCode( $d['code'], $id ) ) { $e[] = 'Ce numéro client (« ' . $d['code'] .' ») est déjà attribué à un autre client.'; }
		if ( 'B2B' === $d['type'] && '' === $d['ncc'] ) { $e[] = 'Le NCC est obligatoire pour un client professionnel (B2B) — conformité DGI.'; }
		if ( '' !== $d['email'] && ! filter_var( $d['email'], FILTER_VALIDATE_EMAIL ) ) { $e[] = "L'adresse e-mail n'est pas valide."; }
		if ( '' !== $d['compte'] && ! preg_match( '/^4\d{2,5}$/', $d['compte'] ) ) { $e[] = 'Le compte collectif client doit être un compte de classe 4 (ex : 411100).'; }
		return $e;
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_refc'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_refc'] ?? null; unset( $_SESSION['__flash_refc'] ); return $m; }
}
