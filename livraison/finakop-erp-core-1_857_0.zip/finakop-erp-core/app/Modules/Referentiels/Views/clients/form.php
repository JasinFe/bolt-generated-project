<?php /** @var array|null $client @var array $errors @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$edit = ! empty( $client['id'] );
$v = function ( $k, $def = '' ) use ( $client ) { return e( $client[ $k ] ?? $def ); };
$sel = function ( $k, $val ) use ( $client ) { return ( ( $client[ $k ] ?? '' ) === $val ) ? 'selected' : ''; };
$chk = function ( $k, $defOn = true ) use ( $client, $edit ) {
	if ( ! $edit && null === $client ) { return $defOn ? 'checked' : ''; }
	return ! empty( $client[ $k ] ) ? 'checked' : '';
};
$action = $edit ? url( 'referentiels/clients/' . (int) $client['id'] ) : url( 'referentiels/clients' );
$regimes = FKC_Client::regimes();
$formes  = FKC_Client::formes(); ?>
<?php FKC_View::partial( 'referentiels::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>

<form method="post" action="<?= e( $action ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="card">
		<div class="card-head"><h2>Identification</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Numéro / ID client</span>
					<input type="text" name="code" value="<?= $v('code') ?>" placeholder="Ex : CLI-0001 (laisser vide = automatique)"></label>
				<label class="fld"><span>Nom / Raison sociale *</span>
					<input type="text" name="nom" value="<?= $v('nom') ?>" required placeholder="Ex : KOPHI'S GROUP SAS"></label>
				<label class="fld"><span>Type de client</span>
					<select name="type">
						<option value="B2C" <?= $sel('type','B2C') ?>>Particulier (B2C)</option>
						<option value="B2B" <?= $sel('type','B2B') ?>>Entreprise / Professionnel (B2B)</option>
					</select></label>
				<label class="fld"><span>Forme juridique</span>
					<select name="forme_juridique">
						<?php foreach ( $formes as $f ) : ?><option value="<?= e( $f ) ?>" <?= $sel('forme_juridique',$f) ?>><?= e( $f ?: '—' ) ?></option><?php endforeach; ?>
					</select></label>
			</div>
		</div>
	</div>

	<div class="card">
		<div class="card-head"><h2>Fiscalité (DGI)</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>NCC (N° Compte Contribuable)</span>
					<input type="text" name="ncc" value="<?= $v('ncc') ?>" placeholder="Ex : 2506650 V"></label>
				<label class="fld"><span>RCCM</span>
					<input type="text" name="rccm" value="<?= $v('rccm') ?>" placeholder="Ex : CI-ABJ-2024-B-12345"></label>
				<label class="fld"><span>Régime fiscal</span>
					<select name="regime_fiscal">
						<?php foreach ( $regimes as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $sel('regime_fiscal',$k) ?>><?= e( $lib ) ?></option><?php endforeach; ?>
					</select></label>
				<label class="fld-check">
					<input type="checkbox" name="assujetti_tva" value="1" <?= $chk('assujetti_tva') ?>>
					<span>Assujetti à la TVA</span></label>
			</div>
			<p class="help" style="margin:8px 0 0">Le NCC est obligatoire pour les clients professionnels (B2B) afin d'émettre des factures normalisées DGI/FNE.</p>
		</div>
	</div>

	<div class="card">
		<div class="card-head"><h2>Comptabilité</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Compte collectif / auxiliaire</span>
					<input type="text" name="compte" value="<?= $v('compte','411100') ?>" placeholder="411100"></label>
				<label class="fld"><span>Délai de paiement (jours)</span>
					<input type="number" name="delai_paiement" min="0" value="<?= $v('delai_paiement','0') ?>"></label>
				<label>Zone (liasse DGI)
					<select name="zone">
						<option value="etat_partie"<?= 'region' !== $v('zone','etat_partie') && 'hors_region' !== $v('zone','etat_partie') ? ' selected' : '' ?>>Dans l'État partie</option>
						<option value="region"<?= 'region' === $v('zone','etat_partie') ? ' selected' : '' ?>>Autres États parties de la Région</option>
						<option value="hors_region"<?= 'hors_region' === $v('zone','etat_partie') ? ' selected' : '' ?>>Hors Région</option>
					</select></label>
				<label class="inline"><input type="checkbox" name="groupe" value="1"<?= $v('groupe','0') ? ' checked' : '' ?>> Société du groupe</label>
				<label class="fld"><span>Devise</span>
					<input type="text" name="devise" value="<?= $v('devise','XOF') ?>" placeholder="XOF"></label>
			</div>
			<p class="help" style="margin:8px 0 0">Compte de classe 4 (411100 par défaut). Vous pouvez attribuer un compte auxiliaire dédié (ex : 411 + code client) après l'avoir créé dans le plan comptable.</p>
		</div>
	</div>

	<div class="card">
		<div class="card-head"><h2>Coordonnées</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Personne à contacter</span>
					<input type="text" name="contact" value="<?= $v('contact') ?>"></label>
				<label class="fld"><span>Téléphone</span>
					<input type="text" name="telephone" value="<?= $v('telephone') ?>" placeholder="+225 ..."></label>
				<label class="fld"><span>E-mail</span>
					<input type="email" name="email" value="<?= $v('email') ?>"></label>
				<label class="fld" style="grid-column:1/-1"><span>Adresse</span>
					<input type="text" name="adresse" value="<?= $v('adresse') ?>"></label>
				<label class="fld"><span>Ville</span>
					<input type="text" name="ville" value="<?= $v('ville') ?>"></label>
				<label class="fld"><span>Boîte postale</span>
					<input type="text" name="bp" value="<?= $v('bp') ?>"></label>
				<label class="fld"><span>Pays</span>
					<input type="text" name="pays" value="<?= $v('pays', "Côte d'Ivoire") ?>"></label>
			</div>
		</div>
	</div>

	<div class="card">
		<div class="card-body">
			<label class="fld" style="grid-column:1/-1"><span>Observations</span>
				<textarea name="notes" rows="2"><?= $v('notes') ?></textarea></label>
			<label class="fld-check" style="margin-top:8px">
				<input type="checkbox" name="actif" value="1" <?= $chk('actif') ?>>
				<span>Client actif</span></label>
		</div>
	</div>

	<div class="actions">
		<button class="btn btn-primary" type="submit"><?= $edit ? 'Enregistrer les modifications' : 'Créer le client' ?></button>
		<a class="btn btn-ghost" href="<?= e( url( 'referentiels/clients' ) ) ?>">Annuler</a>
	</div>
</form>
