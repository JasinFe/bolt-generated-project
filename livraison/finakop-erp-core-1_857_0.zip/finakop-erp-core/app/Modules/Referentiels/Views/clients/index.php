<?php /** @var array $clients @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$regimes = FKC_Client::regimes(); ?>
<?php FKC_View::partial( 'referentiels::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted"><?= count( $clients ) ?> client(s) · référentiel tiers</span>
	<a class="btn btn-primary" href="<?= e( url( 'referentiels/clients/nouveau' ) ) ?>">+ Nouveau client</a>
</div>
<form method="get" action="<?= e( url( 'referentiels/clients' ) ) ?>" class="inline wrap" style="margin-bottom:12px;gap:8px">
	<input name="q" value="<?= e( $q ?? '' ) ?>" placeholder="Rechercher : nom, code, NCC, téléphone, e-mail…" style="min-width:320px">
	<button class="btn btn-primary btn-sm" type="submit">Rechercher</button>
	<?php if ( ! empty( $q ) ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/clients' ) ) ?>">Réinit.</a><?php endif; ?>
</form>
<div class="card card-flush"><table class="table">
	<thead><tr><th>N°</th><th>Nom / Raison sociale</th><th>Type</th><th>NCC</th><th>Compte</th><th>Téléphone</th><th class="num">Solde dû</th><th>Statut</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $clients ) : ?>
		<tr><td colspan="9" class="empty">Aucun client. Créez votre premier client.</td></tr>
	<?php else : foreach ( $clients as $c ) : ?>
		<tr>
			<td class="code"><?= e( $c['code'] ?? '' ?: '—' ) ?></td>
			<td>
				<strong><?= e( $c['nom'] ) ?></strong>
				<?php if ( ! empty( $c['forme_juridique'] ) ) : ?><span class="muted"> · <?= e( $c['forme_juridique'] ) ?></span><?php endif; ?>
				<?php if ( ! empty( $c['ville'] ) ) : ?><br><span class="muted" style="font-size:.85em"><?= e( $c['ville'] ) ?></span><?php endif; ?>
			</td>
			<td><span class="modbadge <?= 'B2B' === $c['type'] ? 'b-on' : '' ?>"><?= e( $c['type'] ) ?></span></td>
			<td class="code"><?= e( $c['ncc'] ?: '—' ) ?></td>
			<td class="code"><?= e( $c['compte'] ?: '411100' ) ?></td>
			<td><?= e( $c['telephone'] ?: '—' ) ?></td>
			<td class="num" style="color:var(--orange)"><?= e( fkc_money( $c['solde'] ) ) ?></td>
			<td><?php if ( empty( $c['actif'] ) ) : ?><span class="muted">Inactif</span><?php else : ?><span class="ok">Actif</span><?php endif; ?></td>
			<td class="right" style="white-space:nowrap">
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/clients/' . (int) $c['id'] . '/modifier' ) ) ?>">Éditer</a>
				<form method="post" action="<?= e( url( 'referentiels/clients/' . (int) $c['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer ce client ? (impossible s\'il a des pièces liées)');">
					<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Supprimer</button>
				</form>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
