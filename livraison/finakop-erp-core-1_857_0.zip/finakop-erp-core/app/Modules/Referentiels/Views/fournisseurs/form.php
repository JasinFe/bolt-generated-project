<?php /** @var array|null $fournisseur @var array $errors @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f = $fournisseur;
$edit = ! empty( $f['id'] );
$v = function ( $k, $def = '' ) use ( $f ) { return e( $f[ $k ] ?? $def ); };
$sel = function ( $k, $val ) use ( $f ) { return ( ( $f[ $k ] ?? '' ) === $val ) ? 'selected' : ''; };
$chk = function ( $k, $defOn = true ) use ( $f, $edit ) {
	if ( ! $edit && null === $f ) { return $defOn ? 'checked' : ''; }
	return ! empty( $f[ $k ] ) ? 'checked' : '';
};
$action = $edit ? url( 'referentiels/fournisseurs/' . (int) $f['id'] ) : url( 'referentiels/fournisseurs' );
$regimes = FKC_Fournisseur::regimes();
$formes  = FKC_Fournisseur::formes();
$types   = FKC_Fournisseur::types(); ?>
<?php FKC_View::partial( 'referentiels::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>

<form method="post" action="<?= e( $action ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="card">
		<div class="card-head"><h2>Identification</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Numéro / ID fournisseur</span>
					<input type="text" name="code" value="<?= $v('code') ?>" placeholder="Ex : FRN-0001 (laisser vide = automatique)"></label>
				<label class="fld"><span>Nom / Raison sociale *</span>
					<input type="text" name="nom" value="<?= $v('nom') ?>" required></label>
				<label class="fld"><span>Type de fournisseur</span>
					<select name="type">
						<?php foreach ( $types as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $sel('type',$k) ?>><?= e( $lib ) ?></option><?php endforeach; ?>
					</select></label>
				<label class="fld"><span>Forme juridique</span>
					<select name="forme_juridique">
						<?php foreach ( $formes as $ff ) : ?><option value="<?= e( $ff ) ?>" <?= $sel('forme_juridique',$ff) ?>><?= e( $ff ?: '—' ) ?></option><?php endforeach; ?>
					</select></label>
			</div>
		</div>
	</div>

	<div class="card">
		<div class="card-head"><h2>Fiscalité (DGI)</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>NCC (N° Compte Contribuable)</span>
					<input type="text" name="ncc" value="<?= $v('ncc') ?>"></label>
				<label class="fld"><span>RCCM</span>
					<input type="text" name="rccm" value="<?= $v('rccm') ?>"></label>
				<label class="fld"><span>Régime fiscal</span>
					<select name="regime_fiscal">
						<?php foreach ( $regimes as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $sel('regime_fiscal',$k) ?>><?= e( $lib ) ?></option><?php endforeach; ?>
					</select></label>
				<label class="fld-check">
					<input type="checkbox" name="assujetti_tva" value="1" <?= $chk('assujetti_tva') ?>>
					<span>Assujetti à la TVA</span></label>
			</div>
			<p class="help" style="margin:8px 0 0">Le NCC est obligatoire pour un fournisseur local (déductibilité de la TVA et conformité DGI).</p>
		</div>
	</div>

	<div class="card">
		<div class="card-head"><h2>Comptabilité</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Compte collectif / auxiliaire</span>
					<input type="text" name="compte" value="<?= $v('compte','401000') ?>" placeholder="401000"></label>
				<label class="fld"><span>Délai de paiement (jours)</span>
					<input type="number" name="delai_paiement" min="0" value="<?= $v('delai_paiement','0') ?>"></label>
				<label>Zone (liasse DGI)
					<select name="zone">
						<option value="etat_partie"<?= 'region' !== $v('zone','etat_partie') && 'hors_region' !== $v('zone','etat_partie') ? ' selected' : '' ?>>Dans l'État partie</option>
						<option value="region"<?= 'region' === $v('zone','etat_partie') ? ' selected' : '' ?>>Autres États parties de la Région</option>
						<option value="hors_region"<?= 'hors_region' === $v('zone','etat_partie') ? ' selected' : '' ?>>Hors Région</option>
					</select></label>
				<label class="inline"><input type="checkbox" name="groupe" value="1"<?= $v('groupe','0') ? ' checked' : '' ?>> Société du groupe</label>
				<label class="fld"><span>Devise</span>
					<input type="text" name="devise" value="<?= $v('devise','XOF') ?>" placeholder="XOF"></label>
			</div>
			<p class="help" style="margin:8px 0 0">Compte de classe 4 (401000 par défaut).</p>
		</div>
	</div>

	<div class="card">
		<div class="card-head"><h2>Coordonnées</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Personne à contacter</span>
					<input type="text" name="contact" value="<?= $v('contact') ?>"></label>
				<label class="fld"><span>Téléphone</span>
					<input type="text" name="telephone" value="<?= $v('telephone') ?>" placeholder="+225 ..."></label>
				<label class="fld"><span>E-mail</span>
					<input type="email" name="email" value="<?= $v('email') ?>"></label>
				<label class="fld" style="grid-column:1/-1"><span>Adresse</span>
					<input type="text" name="adresse" value="<?= $v('adresse') ?>"></label>
				<label class="fld"><span>Ville</span>
					<input type="text" name="ville" value="<?= $v('ville') ?>"></label>
				<label class="fld"><span>Boîte postale</span>
					<input type="text" name="bp" value="<?= $v('bp') ?>"></label>
				<label class="fld"><span>Pays</span>
					<input type="text" name="pays" value="<?= $v('pays', "Côte d'Ivoire") ?>"></label>
			</div>
		</div>
	</div>

	<div class="card">
		<div class="card-body">
			<label class="fld" style="grid-column:1/-1"><span>Observations</span>
				<textarea name="notes" rows="2"><?= $v('notes') ?></textarea></label>
			<label class="fld-check" style="margin-top:8px">
				<input type="checkbox" name="actif" value="1" <?= $chk('actif') ?>>
				<span>Fournisseur actif</span></label>
		</div>
	</div>

	<div class="actions">
		<button class="btn btn-primary" type="submit"><?= $edit ? 'Enregistrer les modifications' : 'Créer le fournisseur' ?></button>
		<a class="btn btn-ghost" href="<?= e( url( 'referentiels/fournisseurs' ) ) ?>">Annuler</a>
	</div>
</form>
