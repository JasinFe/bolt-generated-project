<?php /** @var array $fournisseurs @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$types = FKC_Fournisseur::types(); ?>
<?php FKC_View::partial( 'referentiels::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted"><?= count( $fournisseurs ) ?> fournisseur(s) · référentiel tiers</span>
	<a class="btn btn-primary" href="<?= e( url( 'referentiels/fournisseurs/nouveau' ) ) ?>">+ Nouveau fournisseur</a>
</div>
<form method="get" action="<?= e( url( 'referentiels/fournisseurs' ) ) ?>" class="inline wrap" style="margin-bottom:12px;gap:8px">
	<input name="q" value="<?= e( $q ?? '' ) ?>" placeholder="Rechercher : nom, code, NCC, téléphone, e-mail…" style="min-width:320px">
	<button class="btn btn-primary btn-sm" type="submit">Rechercher</button>
	<?php if ( ! empty( $q ) ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/fournisseurs' ) ) ?>">Réinit.</a><?php endif; ?>
</form>
<div class="card card-flush"><table class="table">
	<thead><tr><th>N°</th><th>Nom / Raison sociale</th><th>Type</th><th>NCC</th><th>Compte</th><th>Téléphone</th><th class="num">Solde dû</th><th>Statut</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $fournisseurs ) : ?>
		<tr><td colspan="9" class="empty">Aucun fournisseur. Créez votre premier fournisseur.</td></tr>
	<?php else : foreach ( $fournisseurs as $f ) : ?>
		<tr>
			<td class="code"><?= e( $f['code'] ?? '' ?: '—' ) ?></td>
			<td>
				<strong><?= e( $f['nom'] ) ?></strong>
				<?php if ( ! empty( $f['forme_juridique'] ) ) : ?><span class="muted"> · <?= e( $f['forme_juridique'] ) ?></span><?php endif; ?>
				<?php if ( ! empty( $f['ville'] ) ) : ?><br><span class="muted" style="font-size:.85em"><?= e( $f['ville'] ) ?></span><?php endif; ?>
			</td>
			<td><span class="modbadge"><?= e( $types[ $f['type'] ?? 'local' ] ?? ucfirst( $f['type'] ?? 'local' ) ) ?></span></td>
			<td class="code"><?= e( $f['ncc'] ?: '—' ) ?></td>
			<td class="code"><?= e( $f['compte'] ?: '401000' ) ?></td>
			<td><?= e( $f['telephone'] ?: '—' ) ?></td>
			<td class="num" style="color:var(--orange)"><?= e( fkc_money( $f['solde'] ) ) ?></td>
			<td><?php if ( empty( $f['actif'] ) ) : ?><span class="muted">Inactif</span><?php else : ?><span class="ok">Actif</span><?php endif; ?></td>
			<td class="right" style="white-space:nowrap">
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'referentiels/fournisseurs/' . (int) $f['id'] . '/modifier' ) ) ?>">Éditer</a>
				<form method="post" action="<?= e( url( 'referentiels/fournisseurs/' . (int) $f['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer ce fournisseur ? (impossible s\'il a des pièces liées)');">
					<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Supprimer</button>
				</form>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
