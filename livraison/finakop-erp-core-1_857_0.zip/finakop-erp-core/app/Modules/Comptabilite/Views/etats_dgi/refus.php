<?php
/**
 * REFUS D'ÉDITION D'UNE LIASSE INCOHÉRENTE.
 *
 * Cette page ne s'affiche que si le bilan ne s'équilibre pas ou si les trois
 * expressions du résultat divergent — donc si les états sont FAUX, et non
 * simplement provisoires. Un document faux qui sort du logiciel ne revient
 * jamais : il part à la DGI, à la banque, à l'expert-comptable.
 *
 * Elle dit ce qui ne va pas, et elle laisse la main : le lien « éditer quand
 * même » existe, parce que c'est le dossier qui décide. Le document forcé part
 * estampillé NON CONFORME.
 *
 * @var array $controle @var int $annee @var string $systeme
 * @var string $retour @var string $forcer
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$incoherences = array_values( array_filter( (array) $controle['anomalies'], function ( $a ) {
	return 'incoherence' === $a['niveau'];
} ) );
?><!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Édition refusée — États financiers <?= (int) $annee ?></title>
<style>
:root{--danger:#C0392B;--muted:#6b7280;--line:#e5e7eb}
*{box-sizing:border-box}
body{margin:0;padding:32px 20px;font:15px/1.65 system-ui,-apple-system,"Segoe UI",sans-serif;color:#111;background:#f7f7f8}
.box{max-width:720px;margin:0 auto;background:#fff;border:1px solid var(--line);border-top:4px solid var(--danger);border-radius:12px;padding:28px 32px}
h1{margin:0 0 4px;font-size:20px;color:var(--danger)}
.sub{color:var(--muted);font-size:13.5px;margin-bottom:20px}
ul{margin:0 0 20px;padding-left:20px}
li{margin-bottom:8px}
.why{background:#fdf6f5;border-left:3px solid var(--danger);padding:12px 16px;font-size:13.5px;border-radius:0 6px 6px 0;margin-bottom:22px}
.acts{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
a.btn{display:inline-block;padding:9px 18px;border-radius:8px;text-decoration:none;font-weight:600;font-size:14px}
a.primary{background:#111;color:#fff}
a.ghost{border:1px solid var(--line);color:#374151}
a.force{color:var(--danger);font-size:13px;text-decoration:underline}
</style></head><body>
<div class="box">
	<h1>Édition refusée</h1>
	<div class="sub">Exercice <?= e( $controle['libelle'] ) ?> · <?= 'sn' === $systeme ? 'Système Normal' : 'Système Minimal de Trésorerie' ?></div>

	<p>Ces états ne se tiennent pas arithmétiquement. Ce n'est pas une liasse
	incomplète, c'est un document faux :</p>

	<ul>
		<?php foreach ( $incoherences as $a ) : ?><li><?= e( $a['texte'] ) ?></li><?php endforeach; ?>
	</ul>

	<div class="why">
		Une liasse éditée quitte le logiciel pour de bon — elle part à
		l'administration, à la banque, au conseil. Tant que l'écart n'est pas
		expliqué, l'éditer ferait circuler un chiffre faux sous une présentation
		officielle. Vérifiez d'abord les écritures de l'exercice, puis revenez.
	</div>

	<div class="acts">
		<a class="btn primary" href="<?= e( url( $retour ) ) ?>">Revenir aux états financiers</a>
		<a class="btn ghost" href="<?= e( url( 'comptabilite/ecritures' ) ) ?>">Voir les écritures</a>
		<a class="force" href="<?= e( url( $forcer ) ) ?>">Éditer quand même (le document portera la mention NON CONFORME)</a>
	</div>
</div>
</body></html>
