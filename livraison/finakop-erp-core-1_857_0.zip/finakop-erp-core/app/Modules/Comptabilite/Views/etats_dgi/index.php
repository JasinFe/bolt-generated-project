<?php /** @var string $proposition_note2 @var int $annee @var string $systeme @var string $vue @var array $entete @var array $bilan @var array $charges
 * @var array $cr @var array $crsn @var array $controle @var array $annees @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f = function ( $v ) { return fkc_money( (float) $v ); };
$fz = function ( $v ) use ( $f ) { return abs( (float) $v ) < 0.004 ? '' : $f( $v ); };
$sysLabel = 'sn' === $systeme ? 'Système Normal (SN)' : 'Système Minimal de Trésorerie (SMT)';
$vueLabel = array( 'bilan' => 'Bilan', 'resultat' => 'Compte de résultat', 'charges' => 'COMP-CHARGES', 'flux' => 'Flux de trésorerie', 'notes' => 'Notes annexes', 'teleliasse' => 'Codes de liasse' )[ $vue ] ?? 'Bilan';
$lnk = function ( $sys, $v, $an ) { return url( 'comptabilite/etats-dgi?systeme=' . $sys . '&vue=' . $v . '&annee=' . $an ); };
$cls = function ( $t ) { return 'grand' === $t ? 'grand' : ( 'total' === $t ? 'total' : ( 'sub' === $t ? 'subtotal' : '' ) ); }; ?>

<?php FKC_View::partial( 'comptabilite::_etats_style' ); ?>
<?php FKC_View::partial( 'comptabilite::_etat_entete', array(
	'etat' => 'Liasse DGI — ' . $sysLabel . ' · ' . $vueLabel,
	'periode' => 'Exercice ' . $entete['libelle'] . ' (clos le ' . $entete['cloture'] . ')',
	'note' => 'Durée : ' . $entete['duree'] . ' mois',
) ); ?>

<?php FKC_View::partial( 'comptabilite::_etats_controle', array( 'controle' => $controle ) ); ?>

<?php if ( ! empty( $flash ) && 'notes' !== $vue ) : ?>
	<div class="note-flash <?= 'ok' === ( $flash['type'] ?? 'ok' ) ? 'ok' : 'ko' ?>" style="margin:0 0 14px"><?= e( $flash['msg'] ?? '' ) ?></div>
<?php endif; ?>

<div class="ef-head">
	<div class="ef-title">📑 <span>États financiers DGI</span> — <?= e( $sysLabel ) ?></div>
	<div class="ef-exports">
		<?php
		/*
		 * Les boutons restent CLIQUABLES même quand les états sont incohérents :
		 * un bouton grisé sans explication n'apprend rien. C'est la page de
		 * refus qui dit ce qui ne va pas et qui offre de passer outre.
		 */
		$mention = FKC_EtatsDgi::mention( $controle );
		?>
		<?php if ( '' !== $mention ) : ?>
			<span class="ef-mention <?= empty( $controle['coherent'] ) ? 'ko' : '' ?>"><?= e( $mention ) ?></span>
		<?php endif; ?>
		<?php if ( ! empty( $depot ) ) : ?>
			<a class="ef-depot <?= $depot['modifiee'] ? 'ko' : 'ok' ?>" href="<?= e( $lnk( $systeme, 'teleliasse', $annee ) ) ?>#depot"
				title="<?= $depot['modifiee'] ? 'La comptabilité a changé depuis le dépôt : un dépôt rectificatif est nécessaire.' : 'La liasse éditée est identique à la liasse déposée.' ?>">
				<?= $depot['modifiee'] ? '⚠ Modifiée depuis le dépôt' : '✓ Déposée' ?> du <?= e( date( 'd/m/Y', strtotime( $depot['depose_le'] ) ) ) ?></a>
		<?php endif; ?>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/etats-dgi/edi?systeme=' . $systeme . '&annee=' . $annee ) ) ?>"
			title="Fichier EDI XML importable dans le module Téléliasse d'e-impots<?= isset( $edi['nb'] ) ? ' (' . (int) $edi['nb'] . ' champs)' : '' ?>">⬇ XML e-impots</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/etats-dgi/export?systeme=' . $systeme . '&quoi=' . $vue . '&annee=' . $annee ) ) ?>">⬇ CSV</a>
		<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/etats-dgi/imprimer?systeme=' . $systeme . '&annee=' . $annee ) ) ?>" target="_blank" rel="noopener">🖨 Imprimer / PDF</a>
	</div>
</div>

<div class="ef-years">
	<?php foreach ( array_slice( $annees, 0, 6 ) as $yy ) : $yy = (int) $yy; ?>
		<a class="ef-pill <?= $annee === $yy ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, $vue, $yy ) ) ?>"><?= $yy ?></a>
	<?php endforeach; ?>
	<form method="get" action="<?= e( url( 'comptabilite/etats-dgi' ) ) ?>" class="inline" style="margin-left:4px">
		<input type="hidden" name="systeme" value="<?= e( $systeme ) ?>"><input type="hidden" name="vue" value="<?= e( $vue ) ?>">
		<input type="number" name="annee" value="<?= (int) $annee ?>" min="2000" max="2100" aria-label="Autre exercice" onchange="this.form.submit()">
	</form>
	<span class="ef-period">Du <?= e( $entete['ouvert'] ) ?> au <?= e( $entete['cloture'] ) ?> · <?= (int) $entete['duree'] ?> mois</span>
</div>

<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
	<div class="sys-tabs">
		<a class="sys-tab <?= 'smt' === $systeme ? 'on' : '' ?>" href="<?= e( $lnk( 'smt', $vue, $annee ) ) ?>">🏛 Système Minimal (SMT)</a>
		<a class="sys-tab <?= 'sn' === $systeme ? 'on' : '' ?>" href="<?= e( $lnk( 'sn', $vue, $annee ) ) ?>">🏦 Système Normal (SN)</a>
	</div>
	<?php if ( isset( $systeme_dossier ) && $systeme !== $systeme_dossier ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/etats-dgi/systeme' ) ) ?>" class="inline" style="margin-bottom:12px">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="systeme" value="<?= e( $systeme ) ?>"><input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<button type="submit" class="btn btn-ghost btn-sm" title="La liasse s'ouvrira désormais sur ce système">★ Définir comme système du dossier</button>
		</form>
	<?php endif; ?>
</div>

<?php FKC_View::partial( 'comptabilite::_etats_kpi', array( 'synthese' => $synthese ?? null, 'systeme' => $systeme ) ); ?>

<div class="dgi-tabs">
	<a class="dgi-tab <?= 'bilan' === $vue ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, 'bilan', $annee ) ) ?>">Bilan <?= strtoupper( $systeme ) ?></a>
	<a class="dgi-tab <?= 'resultat' === $vue ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, 'resultat', $annee ) ) ?>">Compte de résultat <?= strtoupper( $systeme ) ?></a>
	<?php if ( 'sn' === $systeme ) : ?>
		<a class="dgi-tab <?= 'flux' === $vue ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, 'flux', $annee ) ) ?>">Flux de trésorerie</a>
	<?php endif; ?>
	<a class="dgi-tab <?= 'notes' === $vue ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, 'notes', $annee ) ) ?>">Notes annexes</a>
	<a class="dgi-tab <?= 'teleliasse' === $vue ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, 'teleliasse', $annee ) ) ?>">Codes de liasse</a>
	<a class="dgi-tab <?= 'charges' === $vue ? 'on' : '' ?>" href="<?= e( $lnk( $systeme, 'charges', $annee ) ) ?>">COMP-CHARGES</a>
	<?php if ( 'bilan' === $vue ) : ?>
		<span class="dgi-eq <?= $bilan['equilibre'] ? 'ok' : 'ko' ?>"><?= $bilan['equilibre'] ? '✓ Bilan équilibré' : '⚠ Déséquilibre ' . $f( $bilan['total_actif']['n'] - $bilan['total_passif']['n'] ) ?></span>
	<?php endif; ?>
</div>

<?php /* ═════════ BILAN ═════════ */ if ( 'bilan' === $vue ) : ?>

	<?php if ( 'sn' === $systeme ) : /* ---- Bilan Système Normal officiel ---- */ ?>
	<div class="ef-card">
		<div class="ef-band">Bilan — Système Normal — au <?= e( $entete['cloture'] ) ?></div>
		<div class="sn-bilan">
			<div class="ef-scroll"><table class="table ef-tbl sn-actif">
				<thead>
					<tr><th rowspan="2">Réf</th><th rowspan="2">ACTIF</th><th rowspan="2" class="ctr">Note</th><th colspan="3" class="ctr grp">Exercice au <?= e( $entete['cloture'] ) ?></th><th rowspan="2" class="num">N-1<br><small>Net</small></th></tr>
					<tr><th class="num">Brut</th><th class="num">Amort/Dépr.</th><th class="num">Net</th></tr>
				</thead>
				<tbody>
				<?php foreach ( $bilan['actif'] as $l ) : ?>
					<tr class="<?= $cls( $l['type'] ) ?>">
						<td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= e( $l['note'] ) ?></td>
						<td class="num muted"><?= e( $fz( $l['brut'] ) ) ?></td>
						<td class="num muted"><?= e( $fz( $l['amort'] ) ) ?></td>
						<td class="num <?= in_array($l['type'],array('total','grand','sub'),true)?'':'val' ?>"><?= e( $fz( $l['net'] ) ) ?></td>
						<td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
			<div class="ef-scroll"><table class="table ef-tbl sn-passif">
				<thead>
					<tr><th rowspan="2">Réf</th><th rowspan="2">PASSIF</th><th rowspan="2" class="ctr">Note</th><th class="num grp">Exercice au <?= e( $entete['cloture'] ) ?><br><small>Net</small></th><th class="num">N-1<br><small>Net</small></th></tr>
					<tr style="display:none"><th></th></tr>
				</thead>
				<tbody>
				<?php foreach ( $bilan['passif'] as $l ) : $res = ( 'CJ' === $l['code'] ); ?>
					<tr class="<?= $cls( $l['type'] ) ?>">
						<td class="code"><?= e( $l['code'] ) ?></td>
						<td><?= e( $l['libelle'] ) ?><?php if ( $res && (float) $l['net'] != 0 ) : ?> <span class="tag <?= (float)$l['net']>=0?'pos':'neg' ?>">(<?= (float) $l['net'] >= 0 ? 'bénéfice' : 'perte' ?>)</span><?php endif; ?></td>
						<td class="note"><?= e( $l['note'] ) ?></td>
						<td class="num <?= in_array($l['type'],array('total','grand','sub'),true)?'':( $res ? ((float)$l['net']>=0?'pos':'neg') : 'val' ) ?>"><?= e( $fz( $l['net'] ) ) ?></td>
						<td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		</div>
		<div class="ef-eqbar <?= $bilan['equilibre'] ? 'ok' : 'ko' ?>">
			<?= $bilan['equilibre'] ? '✓ Bilan équilibré — Total général Actif = Passif = ' . $f( $bilan['total_actif']['n'] ) . ' F CFA' : '⚠️ Déséquilibre — Actif : ' . $f( $bilan['total_actif']['n'] ) . ' / Passif : ' . $f( $bilan['total_passif']['n'] ) . ' F CFA. Vérifiez à-nouveaux, capitaux propres et imputation du résultat.' ?>
		</div>
	</div>

	<?php else : /* ---- Bilan SMT ---- */ ?>
	<div class="ef-card">
		<div class="ef-band">Bilan — Système Minimal de Trésorerie — au <?= e( $entete['cloture'] ) ?></div>
		<div class="ef-bilan">
			<div class="ef-scroll"><table class="table ef-tbl">
				<thead><tr><th class="th-cote" colspan="5">ACTIF</th></tr><tr><th>Réf</th><th>Actif</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
				<tbody>
				<?php foreach ( $bilan['actif'] as $l ) : ?>
					<tr><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= e( $l['note'] ?? '' ) ?></td><td class="num val"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr class="total"><td class="code">GZ</td><td>TOTAL ACTIF</td><td></td><td class="num"><?= e( $f( $bilan['total_actif']['n'] ) ) ?></td><td class="num"><?= e( $f( $bilan['total_actif']['n1'] ) ) ?></td></tr></tfoot>
			</table></div>
			<div class="ef-scroll"><table class="table ef-tbl">
				<thead><tr><th class="th-cote" colspan="5">PASSIF</th></tr><tr><th>Réf</th><th>Passif</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
				<tbody>
				<?php foreach ( $bilan['passif'] as $l ) : $isRes = ( 'HB' === $l['code'] ); ?>
					<tr><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= e( $l['note'] ?? '' ) ?></td><td class="num <?= $isRes?((float)$l['n']>=0?'pos':'neg'):'val' ?>"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
				<tfoot><tr class="total"><td class="code">HZ</td><td>TOTAL PASSIF</td><td></td><td class="num"><?= e( $f( $bilan['total_passif']['n'] ) ) ?></td><td class="num"><?= e( $f( $bilan['total_passif']['n1'] ) ) ?></td></tr></tfoot>
			</table></div>
		</div>
		<div class="ef-eqbar <?= $bilan['equilibre'] ? 'ok' : 'ko' ?>"><?= $bilan['equilibre'] ? '✓ Bilan équilibré — Actif = Passif = ' . $f( $bilan['total_actif']['n'] ) . ' F CFA' : '⚠️ Bilan non équilibré — Actif : ' . $f( $bilan['total_actif']['n'] ) . ' / Passif : ' . $f( $bilan['total_passif']['n'] ) . ' F CFA.' ?></div>
	</div>
	<?php endif; ?>

<?php /* ═════════ COMPTE DE RÉSULTAT ═════════ */ elseif ( 'resultat' === $vue ) : ?>
<div class="ef-card">
	<div class="ef-band">Compte de Résultat — <?= e( $sysLabel ) ?> — <?= e( $annee ) ?></div>
	<?php if ( 'sn' === $systeme ) : ?>
		<div class="ef-scroll"><table class="table ef-tbl">
			<thead><tr><th style="width:46px">Réf</th><th>Libellés</th><th class="ctr">(2)</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $crsn['lignes'] as $l ) : $t = $l['type']; ?>
				<tr class="<?= 'g'===$t?'grand':( 's'===$t?'subtotal':'' ) ?>">
					<td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td>
					<td class="ctr sgn"><?= e( $l['signe'] ) ?></td><td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num <?= 'g'===$t?( $l['n']>=0?'pos':'neg' ):( 's'===$t?'':'val' ) ?>"><?= e( $fz( $l['n'] ) ) ?> <?php if ( abs((float)$l['n'])>=0.004 ) : ?><small>F CFA</small><?php endif; ?></td>
					<td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<p class="help" style="padding:0 18px 14px">(2) Signe structurel du solde. Cascade SYSCOHADA SN : Marge commerciale → Chiffre d'affaires → Valeur ajoutée → EBE → Résultat d'exploitation → Résultat financier → RAO → Résultat HAO → Résultat net.</p>
	<?php else : ?>
		<div class="ef-scroll"><table class="table ef-tbl">
			<thead><tr><th style="width:46px">Réf</th><th>Libellés</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $cr['produits'] as $l ) : ?>
				<tr class="<?= ! empty( $l['bold'] ) ? 'subtotal' : '' ?>"><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note">7</td><td class="num <?= empty($l['bold'])?'val':'' ?>"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			<tr class="ef-spacer"><td colspan="5"></td></tr>
			<?php foreach ( $cr['charges'] as $l ) : ?>
				<tr class="<?= ! empty( $l['bold'] ) ? 'subtotal' : '' ?>"><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note">7</td><td class="num"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr class="total"><td class="code"><?= e( $cr['kz']['code'] ) ?></td><td colspan="2"><?= e( $cr['kz']['libelle'] ) ?></td><td class="num"><?= e( $f( $cr['kz']['n'] ) ) ?></td><td class="num muted"><?= e( $f( $cr['kz']['n1'] ) ) ?></td></tr>
				<?php foreach ( $cr['variations'] as $v ) : ?>
					<tr class="corr"><td class="code"><?= e( $v['code'] ) ?></td><td colspan="2"><?= e( $v['libelle'] ) ?></td><td class="num <?= $v['n'] < 0 ? 'neg' : '' ?>"><?= e( $f( $v['n'] ) ) ?></td><td class="num muted"><?= e( $f( $v['n1'] ) ) ?></td></tr>
				<?php endforeach; ?>
				<tr><td class="code"><?= e( $cr['jg']['code'] ) ?></td><td colspan="2"><?= e( $cr['jg']['libelle'] ) ?></td><td class="num"><?= e( $f( $cr['jg']['n'] ) ) ?></td><td class="num muted"><?= e( $f( $cr['jg']['n1'] ) ) ?></td></tr>
				<tr class="grand"><td class="code"><?= e( $cr['kzc']['code'] ) ?></td><td colspan="2"><strong><?= e( $cr['kzc']['libelle'] ) ?></strong></td><td class="num <?= $cr['kzc']['n']>=0?'pos':'neg' ?>"><strong><?= e( $f( $cr['kzc']['n'] ) ) ?> F CFA</strong></td><td class="num muted"><?= e( $f( $cr['kzc']['n1'] ) ) ?></td></tr>
			</tfoot>
		</table></div>
	<?php endif; ?>
</div>

<?php /* ═════════ FLUX DE TRÉSORERIE ═════════ */ elseif ( 'flux' === $vue ) : /* ---- Tableau des flux de trésorerie (SN) ---- */ ?>
<div class="ef-card">
	<div class="ef-band">Tableau des flux de trésorerie — du <?= e( date( 'd/m/Y', strtotime( $flux['du'] ) ) ) ?> au <?= e( date( 'd/m/Y', strtotime( $flux['au'] ) ) ) ?></div>
	<div class="ef-scroll"><table class="table ef-tbl tft">
		<thead><tr><th style="width:46px">Réf</th><th>Flux de trésorerie</th><th class="ctr" style="width:64px">Note</th><th class="num" style="width:170px">Exercice <?= e( $annee ) ?></th><th class="num" style="width:150px">N-1</th></tr></thead>
		<tbody>
		<?php foreach ( $flux['lignes'] as $l ) : ?>
			<?php if ( 'entete' === $l['type'] ) : ?>
				<tr class="subtotal"><td></td><td colspan="4"><strong><?= e( $l['libelle'] ) ?></strong></td></tr>
			<?php else : ?>
				<tr class="<?= 'grand' === $l['type'] ? 'grand' : ( 'total' === $l['type'] ? 'total' : '' ) ?>">
					<td class="code"><?= e( $l['code'] ) ?></td>
					<td><?= e( $l['libelle'] ) ?></td>
					<td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num val <?= $l['valeur'] < 0 ? 'neg' : '' ?>"><?= e( $f( $l['valeur'] ) ) ?></td>
					<td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td>
				</tr>
			<?php endif; ?>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<div class="tft-check <?= 0 === (int) $flux['ecart'] ? 'ok' : 'ko' ?>">
		<?php if ( 0 === (int) $flux['ecart'] ) : ?>
			✓ La trésorerie de clôture du tableau (<?= e( $f( $flux['cloture'] ) ) ?>) est bien celle du bilan.
		<?php else : ?>
			⚠ Le tableau annonce <?= e( $f( $flux['cloture'] ) ) ?> quand le bilan montre <?= e( $f( $flux['tresorerie_bilan'] ) ) ?> — écart de <?= e( $f( $flux['ecart'] ) ) ?>.
		<?php endif; ?>
	</div>
	<p class="help" style="padding:0 18px 14px">
		Troisième état de synthèse du Système Normal. Il explique le passage de la trésorerie d'ouverture
		à celle de clôture, en séparant ce que l'activité a produit, ce que les investissements ont
		consommé et ce que le financement a apporté. La capacité d'autofinancement (FA) est le résultat
		débarrassé des écritures sans mouvement de trésorerie : dotations, valeur comptable et prix des
		cessions.
	</p>
</div>

<?php /* ═════════ NOTES ANNEXES ═════════ */ elseif ( 'notes' === $vue ) : ?>
<div class="ef-card">
	<div class="ef-band">Notes annexes — exercice <?= e( $entete['libelle'] ) ?></div>
	<?php if ( empty( $notes['notes'] ) ) : ?>
		<p class="help" style="padding:16px 18px">Aucun compte mouvementé sur cet exercice : les notes annexes sont vides.</p>
	<?php else : ?>
		<?php foreach ( $notes['notes'] as $note ) : ?>
			<div class="note-blk">
				<div class="note-hd">
					<span class="note-num">Note <?= e( $note['numero'] ) ?></span>
					<span class="note-ttl"><?= e( $note['titre'] ) ?></span>
					<span class="note-tot"><?= e( $f( $note['total'] ) ) ?> F CFA</span>
				</div>
				<div class="ef-scroll"><table class="table ef-tbl">
					<thead><tr><th style="width:90px">Compte</th><th>Libellé</th><th class="ctr" style="width:52px">Poste</th><th class="num" style="width:150px">Exercice N</th><th class="num" style="width:150px">N-1</th></tr></thead>
					<tbody>
					<?php foreach ( $note['lignes'] as $l ) : ?>
						<tr><td class="code"><?= e( $l['numero'] ) ?></td><td><?= e( $l['libelle'] ) ?></td>
							<td class="note"><?= e( $l['poste'] ) ?></td>
							<td class="num val <?= $l['n'] < 0 ? 'neg' : '' ?>"><?= e( $f( $l['n'] ) ) ?></td>
							<td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
					<?php endforeach; ?>
					</tbody>
					<tfoot><tr class="total"><td></td><td><strong>TOTAL</strong></td><td></td>
						<td class="num"><strong><?= e( $f( $note['total'] ) ) ?></strong></td>
						<td class="num muted"><?= e( $f( $note['total_n1'] ) ) ?></td></tr></tfoot>
				</table></div>
				<?php if ( ! empty( $note['mouvements'] ) ) : ?>
					<div class="ef-scroll"><table class="table ef-tbl" style="margin-top:2px">
						<thead><tr><th style="width:90px">Compte</th><th>Variation de l'exercice</th><th class="num">Ouverture</th><th class="num">Entrées</th><th class="num">Sorties</th><th class="num">Clôture</th></tr></thead>
						<tbody>
						<?php foreach ( $note['mouvements'] as $m ) : ?>
							<tr><td class="code"><?= e( $m['numero'] ) ?></td>
								<td><?= e( $m['libelle'] ) ?> <span class="muted">(<?= e( $m['nature'] ) ?>)</span></td>
								<td class="num muted"><?= e( $f( $m['ouverture'] ) ) ?></td>
								<td class="num"><?= e( $f( $m['entrees'] ) ) ?></td>
								<td class="num"><?= e( $f( $m['sorties'] ) ) ?></td>
								<td class="num val"><?= e( $f( $m['cloture'] ) ) ?></td></tr>
						<?php endforeach; ?>
						</tbody>
					</table></div>
				<?php endif; ?>
				<?php if ( 0 !== (int) $note['ecart'] ) : ?>
					<div class="note-ko">⚠ Le total de cette note diffère de <?= e( $f( $note['ecart'] ) ) ?> du poste qu'elle détaille (<?= e( $f( $note['poste_total'] ) ) ?>).</div>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
		<p class="help" style="padding:0 18px 14px">
			Quatrième état de synthèse. Chaque note détaille, compte par compte, le poste de la liasse
			qui y renvoie — la colonne « Poste » donne la référence. Les notes s'appuient sur le même
			routage que le bilan et le compte de résultat : leur total est, par construction, celui du
			poste détaillé.
		</p>
	<?php endif; ?>
</div>

<?php $t3c = $tableau3c ?? null; if ( $t3c && $t3c['lignes'] ) : ?>
<div class="ef-card">
	<div class="ef-band">Note 3C — tableau des amortissements, registre ↔ grand livre
		<span class="<?= $t3c['concordant'] ? 'ok-tag' : 'ko-tag' ?>" style="margin-left:8px;font-size:12px;font-weight:600;color:<?= $t3c['concordant'] ? 'var(--green, #1a7f37)' : 'var(--danger)' ?>"><?= $t3c['concordant'] ? '✓ concordant' : '⚠ écart' ?></span></div>
	<div class="ef-scroll"><table class="table ef-tbl">
		<thead>
			<tr><th rowspan="2" style="width:52px">Poste</th><th rowspan="2">Libellé</th>
				<th colspan="4" class="ctr">Registre des immobilisations</th><th colspan="2" class="ctr">Grand livre (28)</th><th rowspan="2" class="num">Écart</th></tr>
			<tr><th class="num">Ouverture</th><th class="num">Dotations</th><th class="num">Sorties</th><th class="num">Clôture</th>
				<th class="num">Dotations</th><th class="num">Clôture</th></tr>
		</thead>
		<tbody>
		<?php foreach ( $t3c['lignes'] as $l ) : ?>
			<tr><td class="note"><?= e( $l['poste'] ) ?></td><td><?= e( $l['libelle'] ) ?></td>
				<td class="num muted"><?= e( $f( $l['registre']['ouverture'] ) ) ?></td>
				<td class="num"><?= e( $f( $l['registre']['dotations'] ) ) ?></td>
				<td class="num"><?= e( $f( $l['registre']['sorties'] ) ) ?></td>
				<td class="num val"><?= e( $f( $l['registre']['cloture'] ) ) ?></td>
				<td class="num"><?= e( $f( $l['gl']['dotations'] ) ) ?></td>
				<td class="num val"><?= e( $f( $l['gl']['cloture'] ) ) ?></td>
				<td class="num <?= abs( $l['ecart'] ) >= 1 ? 'neg' : 'muted' ?>"><?= e( $f( $l['ecart'] ) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr class="total"><td></td><td><strong>TOTAL</strong></td>
			<td class="num"><?= e( $f( $t3c['total']['registre']['ouverture'] ) ) ?></td>
			<td class="num"><?= e( $f( $t3c['total']['registre']['dotations'] ) ) ?></td>
			<td class="num"><?= e( $f( $t3c['total']['registre']['sorties'] ) ) ?></td>
			<td class="num"><strong><?= e( $f( $t3c['total']['registre']['cloture'] ) ) ?></strong></td>
			<td class="num"><?= e( $f( $t3c['total']['gl']['dotations'] ) ) ?></td>
			<td class="num"><strong><?= e( $f( $t3c['total']['gl']['cloture'] ) ) ?></strong></td>
			<td class="num"><?= e( $f( $t3c['total']['ecart'] ) ) ?></td></tr></tfoot>
	</table></div>
	<p class="help" style="padding:0 18px 14px">
		Le registre (<?= (int) $t3c['biens'] ?> bien(s)) relit la note 3C bien par bien. Un écart signale une dotation passée hors du module,
		une fiche manquante ou un amortissement repris à tort —
		<a href="<?= e( url( 'comptabilite/immobilisations' ) ) ?>">rapprochement détaillé dans Immobilisations →</a>
	</p>
</div>
<?php endif; ?>

<div class="ef-card">
	<div class="ef-band">Annexe descriptive — exercice <?= e( $entete['libelle'] ) ?></div>
	<?php if ( ! empty( $flash ) ) : ?>
		<div class="note-flash <?= 'ok' === ( $flash['type'] ?? 'ok' ) ? 'ok' : 'ko' ?>"><?= e( $flash['msg'] ?? '' ) ?></div>
	<?php endif; ?>
	<p class="help" style="padding:12px 18px 6px">
		Ces notes-là ne se calculent pas : les méthodes retenues, les engagements hors bilan et les
		faits marquants ne sont écrits nulle part dans les écritures. Le Système Normal les exige ;
		seul le dossier peut les rédiger.
	</p>
	<?php /* Les trois formulaires n'avaient pas de jeton CSRF : le routeur
	         rejette tout POST sans « _csrf » (419). L'annexe descriptive, le NTD
	         et la reprise N-1 ne pouvaient donc pas s'enregistrer. */ ?>
	<form method="post" action="<?= e( url( 'comptabilite/etats-dgi/notes?systeme=' . $systeme . '&annee=' . $annee ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<?php foreach ( $notes_texte['notes'] as $nt ) : ?>
			<div class="note-txt <?= ( $nt['obligatoire'] && '' === $nt['contenu'] && empty( $nt['differable'] ) ) ? 'vide' : '' ?>">
				<label for="nt-<?= e( $nt['cle'] ) ?>">
					<span class="note-num">Note <?= e( $nt['cle'] ) ?></span>
					<span class="note-ttl"><?= e( $nt['titre'] ) ?></span>
					<?php if ( $nt['obligatoire'] ) : ?><span class="note-oblig"><?= ! empty( $nt['differable'] ) ? 'obligatoire au dépôt · peut être complétée après la clôture' : 'obligatoire' ?></span><?php endif; ?>
					<?php if ( $nt['updated_at'] ) : ?><span class="note-maj">maj <?= e( $nt['updated_at'] ) ?></span><?php endif; ?>
				</label>
				<p class="note-aide"><?= e( $nt['aide'] ) ?></p>
				<?php $prop = ( '2' === (string) $nt['cle'] && '' === $nt['contenu'] && ! empty( $proposition_note2 ) ) ? (string) $proposition_note2 : ''; ?>
				<?php if ( '' !== $prop ) : ?>
					<p class="note-aide note-prop">Proposition rédigée d'après les paramètres et registres du dossier — relisez, complétez la partie entre crochets, puis enregistrez. Tant qu'elle n'est pas enregistrée, la note reste manquante.</p>
				<?php endif; ?>
				<textarea id="nt-<?= e( $nt['cle'] ) ?>" name="note[<?= e( $nt['cle'] ) ?>]" rows="<?= '' !== $prop ? 12 : 4 ?>"
					placeholder="Non renseignée"><?= e( '' !== $prop ? $prop : $nt['contenu'] ) ?></textarea>
			</div>
		<?php endforeach; ?>
		<div class="note-acts">
			<button type="submit" class="btn btn-primary btn-sm">Enregistrer l'annexe descriptive</button>
			<span class="muted" style="font-size:12px">Un champ vidé efface la note.</span>
		</div>
	</form>
	<form method="post" action="<?= e( url( 'comptabilite/etats-dgi/ntd?systeme=' . $systeme . '&annee=' . $annee ) ) ?>" class="note-acts">
		<?= FKC_Csrf::field() ?>
		<label for="ntd" style="font-size:12.5px">N° de télédéclarant (NTD)</label>
		<input id="ntd" name="ntd" value="<?= e( $entete['ntd'] ) ?>" placeholder="Non renseigné" maxlength="40" autocomplete="off">
		<button type="submit" class="btn btn-ghost btn-sm">Enregistrer</button>
		<span class="muted" style="font-size:12px">Réclamé par chaque feuillet de la liasse, à côté du NCC.</span>
	</form>
	<form method="post" action="<?= e( url( 'comptabilite/etats-dgi/notes-reprise?systeme=' . $systeme . '&annee=' . $annee ) ) ?>" class="note-acts">
		<?= FKC_Csrf::field() ?>
		<button type="submit" class="btn btn-ghost btn-sm">Reprendre les notes de <?= (int) $annee - 1 ?></button>
		<span class="muted" style="font-size:12px">Ne remplit que les notes vides ; relisez-les, elles engagent cet exercice.</span>
	</form>
</div>

<?php /* ═════════ CODES DE LIASSE — ASSISTANT DE SAISIE TÉLÉLIASSE ═════════ */ elseif ( 'teleliasse' === $vue ) : ?>
<div class="ef-card">
	<div class="ef-band">Codes de liasse — <?= 'sn' === $systeme ? 'Système Normal' : 'Système Minimal de Trésorerie' ?> · exercice <?= e( $entete['libelle'] ) ?></div>
	<div class="tl-note tl-edi">
		<strong>Dépôt direct : le fichier XML.</strong> Le bouton « XML e-impots » en haut de page produit le fichier
		<em>EDI</em> attendu par le portail — <?= (int) $edi['nb'] ?> champs pour cette liasse, répartis sur
		<?= count( $edi['tableaux'] ) ?> tableaux. À l'étape 1 de la déclaration, chargez-le dans
		« Import des états financiers au format XML ».
		<br><br>
		<strong>Attention :</strong> l'import <em>écrase</em> tout ce qui est déjà saisi sur le portail. Les tableaux
		que FinaKop ne sait pas alimenter ne sont pas envoyés remplis de zéros — ils sont simplement absents
		du fichier, et restent à saisir à la main.
		<br><br>
		<strong>Ce qui part :</strong> <?= e( implode( ', ', array_keys( $edi['tableaux'] ) ) ) ?>.
		<br>
		<strong>Ce qui reste à saisir :</strong> les notes qui réclament des ventilations que la comptabilité ne porte
		pas — répartition <em>géographique</em> des achats, des ventes et des services extérieurs (dans l'État partie,
		dans les autres États de la Région, hors Région), et répartition par <em>échéance</em> des créances et des
		dettes (à un an au plus, de un à deux ans, au-delà). Ces ventilations ne se déduisent pas du grand livre ;
		les remplir au jugé dans un document qui part à l'administration serait pire que de les laisser vides.
	</div>
	<div class="tl-note">
		<strong>À quoi sert cette page.</strong> Les états financiers se déposent par voie électronique sur le
		module <em>Téléliasse</em> du portail e-impots.gouv.ci, champ par champ, chaque champ portant son code
		de référence SYSCOHADA. Cette page suit l'ordre des feuillets : cherchez le code sur le portail,
		cliquez sur la valeur pour la copier, cochez la ligne. Ce qui reste à saisir est toujours visible.
		<br><br>
		Elle reste utile pour les tableaux non couverts par le fichier XML, et pour vérifier une valeur
		champ par champ. Le suivi des cases cochées reste dans ce navigateur et n'est transmis nulle part.
	</div>

	<div class="tl-depot" id="depot">
		<div class="tl-depot-hd"><strong>Dépôt de la liasse</strong>
			<span class="muted">L'empreinte des soldes N et N-1, de l'annexe et de l'identification est figée au dépôt ; toute écriture qui la modifie ensuite est signalée.</span></div>
		<?php if ( ! empty( $depot ) ) : ?>
			<div class="ext-alert <?= $depot['modifiee'] ? 'ko' : 'ok' ?>" style="margin:8px 0">
				<?php if ( $depot['modifiee'] ) : ?>
					⚠ La liasse déposée le <?= e( date( 'd/m/Y', strtotime( $depot['depose_le'] ) ) ) ?><?= '' !== $depot['reference'] ? ' (réf. ' . e( $depot['reference'] ) . ')' : '' ?> ne correspond plus à la comptabilité<?= $depot['ecritures_apres'] ? ' : ' . (int) $depot['ecritures_apres'] . ' écriture(s) de l\'exercice passée(s) depuis' : '' ?>.
					Résultat déposé <?= e( $f( $depot['depose']['resultat'] ?? 0 ) ) ?> → actuel <?= e( $f( $depot['actuel']['resultat'] ?? 0 ) ) ?> ;
					total du bilan <?= e( $f( $depot['depose']['total_bilan'] ?? 0 ) ) ?> → <?= e( $f( $depot['actuel']['total_bilan'] ?? 0 ) ) ?>. Un dépôt rectificatif est nécessaire.
				<?php else : ?>
					✓ Liasse déposée le <?= e( date( 'd/m/Y', strtotime( $depot['depose_le'] ) ) ) ?><?= '' !== $depot['reference'] ? ' (réf. ' . e( $depot['reference'] ) . ')' : '' ?> — la comptabilité n'a pas changé depuis.
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $controle['coherent'] ) ) : ?>
			<form method="post" action="<?= e( url( 'comptabilite/etats-dgi/depot?systeme=' . $systeme . '&annee=' . $annee ) ) ?>" class="note-acts" style="padding:4px 0">
				<?= FKC_Csrf::field() ?>
				<label for="dep-ref" style="font-size:12.5px">Référence e-impots</label>
				<input id="dep-ref" name="reference" placeholder="N° d'accusé de dépôt" maxlength="80" autocomplete="off">
				<input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>" aria-label="Date du dépôt" style="width:160px">
				<button type="submit" class="btn btn-primary btn-sm"><?= empty( $depot ) ? 'Marquer comme déposée' : 'Enregistrer un dépôt rectificatif' ?></button>
			</form>
		<?php else : ?>
			<p class="muted" style="font-size:12.5px;margin:6px 0">Une liasse incohérente ne peut pas être marquée déposée.</p>
		<?php endif; ?>
		<?php if ( ! empty( $depots ) && count( $depots ) > 1 ) : ?>
			<details style="font-size:12.5px;margin-top:4px"><summary>Historique des dépôts (<?= count( $depots ) ?>)</summary>
				<ul style="margin:6px 0 0;padding-left:18px">
				<?php foreach ( $depots as $dp ) : ?>
					<li><?= e( date( 'd/m/Y', strtotime( $dp['depose_le'] ) ) ) ?> · <?= e( strtoupper( $dp['systeme'] ) ) ?><?= '' !== (string) $dp['reference'] ? ' · réf. ' . e( $dp['reference'] ) : '' ?> · résultat <?= e( $f( $dp['resume']['resultat'] ?? 0 ) ) ?></li>
				<?php endforeach; ?>
				</ul></details>
		<?php endif; ?>
	</div>

	<div class="tl-bar">
		<input type="search" id="tl-q" placeholder="Filtrer par code ou libellé (ex. « BI », « clients »)…" autocomplete="off">
		<label class="tl-chk"><input type="checkbox" id="tl-reste"> N'afficher que ce qui reste</label>
		<span class="tl-prog"><span id="tl-fait">0</span> / <?= (int) $codes['nb'] ?> champs reportés</span>
		<button type="button" class="btn btn-ghost btn-sm" id="tl-raz">Réinitialiser le suivi</button>
	</div>
	<div class="tl-jauge"><span id="tl-jauge"></span></div>

	<div class="ef-scroll"><table class="table ef-tbl tl" id="tl-tbl">
		<thead><tr><th style="width:34px"></th><th style="width:70px">Code</th><th>Libellé</th><th class="num" style="width:170px">Exercice <?= e( $annee ) ?></th><th class="num" style="width:150px">N-1</th></tr></thead>
		<tbody>
		<?php $fc = null; foreach ( $codes['lignes'] as $l ) : ?>
			<?php if ( $l['feuillet'] !== $fc ) : $fc = $l['feuillet']; ?>
				<tr class="subtotal tl-feuillet" data-feuillet="<?= e( $fc ) ?>"><td colspan="5"><strong><?= e( $fc ) ?></strong></td></tr>
			<?php endif; ?>
			<tr class="tl-row" data-code="<?= e( $l['code'] ) ?>" data-cle="<?= e( $l['etat'] . '.' . $l['code'] ) ?>"
				data-recherche="<?= e( mb_strtolower( $l['code'] . ' ' . $l['libelle'] ) ) ?>">
				<td><input type="checkbox" class="tl-fait" aria-label="Champ reporté"></td>
				<td class="code"><strong><?= e( $l['code'] ) ?></strong></td>
				<td><?= e( $l['libelle'] ) ?>
					<?php if ( isset( $l['texte'] ) ) : ?>
						<div class="tl-texte"><?= '' === $l['texte'] ? '<em>Note obligatoire non rédigée — onglet Notes annexes.</em>' : nl2br( e( $l['texte'] ) ) ?></div>
					<?php endif; ?>
				</td>
				<td class="num">
					<?php if ( null === $l['n'] ) : ?><span class="muted">—</span>
					<?php else : ?><button type="button" class="tl-copie <?= $l['n'] < 0 ? 'neg' : '' ?>" data-v="<?= e( (string) round( $l['n'] ) ) ?>" title="Copier la valeur"><?= e( $f( $l['n'] ) ) ?></button><?php endif; ?>
				</td>
				<td class="num muted"><?= null === $l['n1'] ? '' : e( $f( $l['n1'] ) ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<p class="help" style="padding:10px 18px 14px"><?= (int) $codes['nb'] ?> champs répartis sur <?= count( $codes['feuillets'] ) ?> feuillets. Le bouton CSV en haut de page exporte cette liste dans le même ordre.</p>
</div>
<script>
(function () {
	var tbl = document.getElementById('tl-tbl');
	if (!tbl) { return; }
	/* Le suivi est propre au dossier, à l'exercice et au système : deux
	   liasses différentes ne doivent pas partager leurs cases cochées. */
	var cle = 'fkc.tl.<?= (int) ( $societe['id'] ?? 0 ) ?>.<?= e( $systeme ) ?>.<?= (int) $annee ?>';
	var etat = {};
	try { etat = JSON.parse(localStorage.getItem(cle) || '{}') || {}; } catch (e) { etat = {}; }

	var rows = Array.prototype.slice.call(tbl.querySelectorAll('.tl-row'));
	var total = rows.length;
	var champFait = document.getElementById('tl-fait');
	var jauge = document.getElementById('tl-jauge');
	var q = document.getElementById('tl-q');
	var reste = document.getElementById('tl-reste');

	function enregistrer() {
		try { localStorage.setItem(cle, JSON.stringify(etat)); } catch (e) {}
	}
	function compter() {
		var n = 0;
		rows.forEach(function (r) { if (etat[r.dataset.cle]) { n++; } });
		champFait.textContent = n;
		jauge.style.width = total ? (100 * n / total) + '%' : '0%';
	}
	function filtrer() {
		var t = (q.value || '').toLowerCase().trim();
		var seulReste = reste.checked;
		rows.forEach(function (r) {
			var ok = (!t || r.dataset.recherche.indexOf(t) !== -1) && (!seulReste || !etat[r.dataset.cle]);
			r.style.display = ok ? '' : 'none';
		});
		/* Un feuillet dont toutes les lignes sont masquées se masque aussi :
		   un intitulé seul, sans ligne dessous, ne veut rien dire. */
		Array.prototype.slice.call(tbl.querySelectorAll('.tl-feuillet')).forEach(function (h) {
			var n = h.nextElementSibling, visible = false;
			while (n && !n.classList.contains('tl-feuillet')) {
				if (n.classList.contains('tl-row') && n.style.display !== 'none') { visible = true; break; }
				n = n.nextElementSibling;
			}
			h.style.display = visible ? '' : 'none';
		});
	}

	rows.forEach(function (r) {
		var c = r.querySelector('.tl-fait');
		if (etat[r.dataset.cle]) { c.checked = true; r.classList.add('fait'); }
		c.addEventListener('change', function () {
			if (c.checked) { etat[r.dataset.cle] = 1; r.classList.add('fait'); }
			else { delete etat[r.dataset.cle]; r.classList.remove('fait'); }
			enregistrer(); compter(); if (reste.checked) { filtrer(); }
		});
	});

	tbl.addEventListener('click', function (ev) {
		var b = ev.target.closest ? ev.target.closest('.tl-copie') : null;
		if (!b) { return; }
		var v = b.dataset.v;
		var fini = function () {
			var av = b.textContent;
			b.classList.add('copie'); b.textContent = 'copié';
			setTimeout(function () { b.classList.remove('copie'); b.textContent = av; }, 900);
		};
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(v).then(fini, function () {});
		} else {
			var t = document.createElement('textarea');
			t.value = v; document.body.appendChild(t); t.select();
			try { document.execCommand('copy'); fini(); } catch (e) {}
			document.body.removeChild(t);
		}
	});

	q.addEventListener('input', filtrer);
	reste.addEventListener('change', filtrer);
	document.getElementById('tl-raz').addEventListener('click', function () {
		etat = {}; enregistrer();
		rows.forEach(function (r) { r.querySelector('.tl-fait').checked = false; r.classList.remove('fait'); });
		compter(); filtrer();
	});
	compter();
})();
</script>

<?php /* ═════════ COMP-CHARGES ═════════ */ else : ?>
<div class="ef-card">
	<div class="ef-band">État complémentaire — Détail des charges (FCFA) — <?= e( $annee ) ?></div>
	<div class="ef-scroll"><table class="table ef-tbl cc">
		<thead><tr><th style="width:70px">Compte</th><th>Détail des charges</th><th class="num">Exercice N</th><th class="num">Exercice N-1</th><th class="num">Var. valeur</th><th class="num">Var. %</th></tr></thead>
		<tbody>
		<?php foreach ( $charges['groupes'] as $g ) : ?>
			<?php foreach ( $g['lignes'] as $l ) : ?>
				<tr><td class="code"><?= e( $l['numero'] ) ?></td><td><?= e( $l['libelle'] ) ?><?php if ( ! empty( $l['repli'] ) ) : ?><span class="repli" title="Compte hors plan de base : rangé dans la ligne la plus proche de sa nature">repli</span><?php endif; ?></td>
					<td class="num"><?= e( $fz( $l['n'] ) ) ?></td><td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td>
					<td class="num"><?= e( $fz( $l['var']['val'] ) ) ?></td>
					<td class="num <?= ($l['var']['pct']!==null && $l['var']['pct']<0)?'neg':'' ?>"><?= null===$l['var']['pct']?'':e( $l['var']['pct'] ).' %' ?></td></tr>
			<?php endforeach; ?>
			<tr class="subtotal"><td class="code"><?= e( $g['code'] ) ?></td><td><strong><?= e( $g['libelle'] ) ?></strong></td>
				<td class="num"><?= e( $f( $g['n'] ) ) ?></td><td class="num muted"><?= e( $f( $g['n1'] ) ) ?></td>
				<td class="num"><?= e( $f( $g['var']['val'] ) ) ?></td>
				<td class="num"><?= null===$g['var']['pct']?'':e( $g['var']['pct'] ).' %' ?></td></tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr class="grand"><td></td><td><strong>TOTAL DES CHARGES</strong></td><td class="num"><strong><?= e( $f( $charges['total'] ) ) ?></strong></td><td class="num muted"><?= e( $f( $charges['total_n1'] ) ) ?></td><td class="num"><?= e( $f( $charges['var_total']['val'] ) ) ?></td><td class="num"><?= null===$charges['var_total']['pct']?'':e( $charges['var_total']['pct'] ).' %' ?></td></tr></tfoot>
	</table></div>
	<p class="help" style="padding:0 18px 14px">État complémentaire DGI « Détail des charges » : ventilation des comptes de charges (classe 6) sous les rubriques RA…RN du compte de résultat SN — même rattachement, compte par compte — avec variation N/N-1 en valeur et en pourcentage.</p>
</div>
<?php endif; ?>

<p class="help" style="margin-top:14px">Liasse <strong><?= e( $sysLabel ) ?></strong> du référentiel <strong>SYSCOHADA révisé</strong>, présentation DGI. Choisissez le système (SMT ou SN) selon le régime de votre entreprise. À valider avec votre expert-comptable avant dépôt.</p>

