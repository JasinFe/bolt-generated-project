<?php /**
 * Feuille d'impression de la liasse DGI.
 *
 * Elle n'imprimait que le Système Minimal de Trésorerie, quel que soit le
 * système consulté à l'écran : un dossier au Système Normal repartait avec
 * une liasse qui n'était pas la sienne. Elle rend désormais l'un ou l'autre,
 * et reporte en tête les réserves du contrôle de cohérence — une liasse
 * imprimée circule sans le bandeau de l'écran.
 *
 * @var int $annee @var string $systeme @var array $entete @var array $controle
 * @var array $bilan @var array $cr @var array $crsn @var string $societe @var string $ncc
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f = function($v){ return number_format((float)$v,0,' ',' '); };
$sn = isset( $systeme ) && 'sn' === $systeme;
$sysLabel = $sn ? 'Système Normal (SN)' : 'Système Minimal de Trésorerie (SMT)';
$reserves = array_values( array_filter( (array) ( $controle['anomalies'] ?? array() ), function ( $a ) { return 'information' !== $a['niveau']; } ) );
$mention  = isset( $mention ) ? (string) $mention : ''; ?>
<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">
<title>États financiers DGI <?= $annee ?> — <?= e($societe) ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;color:#111;background:#f3f4f6;padding:18px;font-size:12px}
.sheet{background:#fff;max-width:900px;margin:0 auto 18px;padding:26px 30px;box-shadow:0 1px 6px rgba(0,0,0,.12)}
.hd{display:flex;justify-content:space-between;border-bottom:2px solid #0A0F1C;padding-bottom:10px;margin-bottom:14px}
.hd h1{font-size:17px;color:#0A0F1C}.hd .sub{font-size:11px;color:#555;margin-top:3px}
.hd .right{text-align:right;font-size:11px;color:#555}
h2{font-size:13px;background:#0A0F1C;color:#fff;padding:6px 10px;margin:16px 0 0;border-radius:3px}
table{width:100%;border-collapse:collapse;margin-top:2px}
th,td{border:1px solid #ccc;padding:4px 8px;text-align:left}
th{background:#eef1f6;font-size:10px;text-transform:uppercase;letter-spacing:.3px}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
.code{font-family:monospace;color:#C0392B;font-weight:700;width:36px}
.tot{background:#f0f3f8;font-weight:700}
.res{background:#fdf0db;font-weight:700}
.note{color:#888;text-align:center;width:46px}
.foot{margin-top:18px;font-size:10px;color:#777;text-align:center}
.reserves{border:1px solid #C0392B;background:#fdf1ef;padding:8px 12px;margin-bottom:12px;font-size:10.5px;border-radius:3px}
.reserves b{color:#C0392B;display:block;margin-bottom:3px}
.reserves ul{margin:0;padding-left:16px}
/*
 * Filigrane. Une liasse provisoire imprimée traîne sur un bureau et se
 * retrouve six mois plus tard à côté de la définitive : le bandeau du haut
 * ne suffit pas, il faut que chaque page se reconnaisse d'un coup d'œil.
 * `position:fixed` se répète sur toutes les pages à l'impression.
 */
.filigrane{position:fixed;top:44%;left:0;right:0;text-align:center;font-size:64px;font-weight:900;
	letter-spacing:6px;color:rgba(192,57,43,.11);transform:rotate(-24deg);z-index:0;pointer-events:none}
.sheet{position:relative;z-index:1}
.toolbar{max-width:900px;margin:0 auto 14px;text-align:right}
.btn{background:#3D6FE0;color:#fff;border:0;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:13px}
@media print{body{background:#fff;padding:0}.toolbar{display:none}.sheet{box-shadow:none;margin:0;max-width:none}}
</style></head><body>
<div class="toolbar"><button class="btn" onclick="window.print()">🖨 Imprimer / Enregistrer en PDF</button></div>
<div class="sheet">
	<?php if ( '' !== $mention ) : ?><div class="filigrane"><?= e( $mention ) ?></div><?php endif; ?>
	<div class="hd">
		<div><h1><?= e($societe) ?></h1><div class="sub"><?= $ncc?'NCC : '.e($ncc).' · ':'' ?><?= !empty($entete['ntd'])?'NTD : '.e($entete['ntd']).' · ':'' ?>États financiers — <?= e($sysLabel) ?> (DGI)</div></div>
		<div class="right">Exercice clos le<br><strong><?= e($entete['cloture']) ?></strong><br><?= (int) $entete['duree'] ?> mois · Montants en FCFA<?php if ( '' !== $mention ) : ?><br><strong style="color:#C0392B"><?= e( $mention ) ?></strong><?php endif; ?></div>
	</div>

	<?php if ( $reserves ) : ?>
		<div class="reserves"><b>Réserves sur cette liasse</b><ul>
			<?php foreach ( $reserves as $r ) : ?><li><?= e( $r['texte'] ) ?></li><?php endforeach; ?>
		</ul></div>
	<?php endif; ?>

	<h2>BILAN</h2>
	<?php if ( $sn ) : ?>
		<table><thead><tr><th class="code">Réf</th><th>ACTIF</th><th class="note">Note</th><th class="num">Brut</th><th class="num">Amort/Dépr.</th><th class="num">Net</th><th class="num">N-1</th></tr></thead><tbody>
		<?php foreach ( $bilan['actif'] as $l ) : ?>
			<tr class="<?= in_array($l['type'],array('total','grand'),true)?'tot':'' ?>"><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td><td class="note"><?= e($l['note']) ?></td>
				<td class="num"><?= null===$l['brut']?'':e($f($l['brut'])) ?></td><td class="num"><?= null===$l['amort']?'':e($f($l['amort'])) ?></td>
				<td class="num"><?= e($f($l['net'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
		<table style="margin-top:8px"><thead><tr><th class="code">Réf</th><th>PASSIF</th><th class="note">Note</th><th class="num">Net</th><th class="num">N-1</th></tr></thead><tbody>
		<?php foreach ( $bilan['passif'] as $l ) : ?>
			<tr class="<?= in_array($l['type'],array('total','grand'),true)?'tot':'' ?>"><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td><td class="note"><?= e($l['note']) ?></td>
				<td class="num"><?= e($f($l['net'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
	<?php else : ?>
		<table><thead><tr><th class="code">Réf</th><th>ACTIF</th><th class="note">Note</th><th class="num">Exercice N</th><th class="num">Exercice N-1</th></tr></thead><tbody>
		<?php foreach ( $bilan['actif'] as $l ) : ?>
			<tr><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td><td class="note"><?= e($l['note']) ?></td><td class="num"><?= e($f($l['n'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
		<?php endforeach; ?>
			<tr class="tot"><td class="code">GZ</td><td>TOTAL ACTIF</td><td></td><td class="num"><?= e($f($bilan['total_actif']['n'])) ?></td><td class="num"><?= e($f($bilan['total_actif']['n1'])) ?></td></tr>
		</tbody></table>
		<table style="margin-top:8px"><thead><tr><th class="code">Réf</th><th>PASSIF</th><th class="note">Note</th><th class="num">Exercice N</th><th class="num">Exercice N-1</th></tr></thead><tbody>
		<?php foreach ( $bilan['passif'] as $l ) : ?>
			<tr><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td><td class="note"><?= e($l['note']) ?></td><td class="num"><?= e($f($l['n'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
		<?php endforeach; ?>
			<tr class="tot"><td class="code">HZ</td><td>TOTAL PASSIF</td><td></td><td class="num"><?= e($f($bilan['total_passif']['n'])) ?></td><td class="num"><?= e($f($bilan['total_passif']['n1'])) ?></td></tr>
		</tbody></table>
	<?php endif; ?>

	<h2>COMPTE DE RÉSULTAT</h2>
	<?php if ( $sn ) : ?>
		<table><thead><tr><th class="code">Réf</th><th>SOLDES INTERMÉDIAIRES DE GESTION</th><th class="note">Note</th><th class="num">Exercice N</th><th class="num">Exercice N-1</th></tr></thead><tbody>
		<?php foreach ( $crsn['lignes'] as $l ) : ?>
			<tr class="<?= 'g'===$l['type']?'res':('s'===$l['type']?'tot':'') ?>"><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td>
				<td class="note"><?= e($l['note']) ?></td><td class="num"><?= e($f($l['n'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
	<?php else : ?>
	<table><thead><tr><th class="code">Réf</th><th>RECETTES / DÉPENSES</th><th class="note">Note</th><th class="num">Exercice N</th><th class="num">Exercice N-1</th></tr></thead><tbody>
	<?php foreach ( $cr['produits'] as $l ) : ?>
		<tr class="<?= !empty($l['bold'])?'tot':'' ?>"><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td><td class="note">7</td><td class="num"><?= e($f($l['n'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
	<?php endforeach; ?>
	<?php foreach ( $cr['charges'] as $l ) : ?>
		<tr class="<?= !empty($l['bold'])?'tot':'' ?>"><td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td><td class="note">7</td><td class="num"><?= e($f($l['n'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
	<?php endforeach; ?>
		<tr class="tot"><td class="code"><?= e($cr['kz']['code']) ?></td><td colspan="2"><?= e($cr['kz']['libelle']) ?></td><td class="num"><?= e($f($cr['kz']['n'])) ?></td><td class="num"><?= e($f($cr['kz']['n1'])) ?></td></tr>
		<?php /* Ordre du modèle : C, puis D, E, F, puis G, puis H (1.853.0) —
		         la dotation (G) était imprimée avant les variations. */ ?>
		<?php foreach ( $cr['variations'] as $v ) : ?>
			<tr><td class="code"><?= e($v['code']) ?></td><td colspan="2"><?= e($v['libelle']) ?></td><td class="num"><?= e($f($v['n'])) ?></td><td class="num"><?= e($f($v['n1'])) ?></td></tr>
		<?php endforeach; ?>
		<tr><td class="code"><?= e($cr['jg']['code']) ?></td><td colspan="2"><?= e($cr['jg']['libelle']) ?></td><td class="num"><?= e($f($cr['jg']['n'])) ?></td><td class="num"><?= e($f($cr['jg']['n1'])) ?></td></tr>
		<tr class="res"><td class="code"><?= e($cr['kzc']['code']) ?></td><td colspan="2"><?= e($cr['kzc']['libelle']) ?></td><td class="num"><?= e($f($cr['kzc']['n'])) ?></td><td class="num"><?= e($f($cr['kzc']['n1'])) ?></td></tr>
	</tbody></table>
	<?php endif; ?>

	<?php if ( $sn && isset( $flux ) ) : ?>
		<h2>TABLEAU DES FLUX DE TRÉSORERIE</h2>
		<table><thead><tr><th class="code">Réf</th><th>Flux de trésorerie</th><th class="note">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead><tbody>
		<?php foreach ( $flux['lignes'] as $l ) : ?>
			<?php if ( 'entete' === $l['type'] ) : ?>
				<tr class="tot"><td></td><td colspan="4"><?= e($l['libelle']) ?></td></tr>
			<?php else : ?>
				<tr class="<?= 'grand'===$l['type']?'res':('total'===$l['type']?'tot':'') ?>">
					<td class="code"><?= e($l['code']) ?></td><td><?= e($l['libelle']) ?></td>
					<td class="note"><?= e($l['note']) ?></td><td class="num"><?= e($f($l['valeur'])) ?></td>
					<td class="num"><?= e($f($l['n1'])) ?></td></tr>
			<?php endif; ?>
		<?php endforeach; ?>
		</tbody></table>
	<?php endif; ?>

	<?php if ( ! empty( $notes['notes'] ) ) : ?>
		<h2>NOTES ANNEXES</h2>
		<?php foreach ( $notes['notes'] as $note ) : ?>
			<table style="margin-bottom:8px"><thead>
				<tr><th class="code">N<?= e($note['numero']) ?></th><th colspan="2"><?= e($note['titre']) ?></th><th class="num">Exercice N</th><th class="num">N-1</th></tr>
			</thead><tbody>
			<?php foreach ( $note['lignes'] as $l ) : ?>
				<tr><td class="code"><?= e($l['numero']) ?></td><td colspan="2"><?= e($l['libelle']) ?></td>
					<td class="num"><?= e($f($l['n'])) ?></td><td class="num"><?= e($f($l['n1'])) ?></td></tr>
			<?php endforeach; ?>
				<tr class="tot"><td></td><td colspan="2">TOTAL</td><td class="num"><?= e($f($note['total'])) ?></td><td class="num"><?= e($f($note['total_n1'])) ?></td></tr>
			</tbody></table>
		<?php endforeach; ?>
	<?php endif; ?>

	<?php if ( ! empty( $notes_texte['notes'] ) ) : ?>
		<?php $descr = array_filter( $notes_texte['notes'], function ( $n ) { return '' !== $n['contenu']; } ); ?>
		<?php if ( $descr ) : ?>
			<h2>ANNEXE DESCRIPTIVE</h2>
			<?php foreach ( $descr as $n ) : ?>
				<p style="margin:0 0 8px"><strong>Note <?= e($n['cle']) ?> — <?= e($n['titre']) ?></strong><br>
				<?= nl2br( e( $n['contenu'] ) ) ?></p>
			<?php endforeach; ?>
		<?php endif; ?>
	<?php endif; ?>

	<div class="foot">Document d'aide au renseignement de la liasse des états financiers DGI (<?= e($sysLabel) ?>). Généré par FinaKop ERP Core — à valider avec l'expert-comptable avant dépôt.</div>
</div>
</body></html>
