<?php /** @var array $brouillons @var bool $actif @var array|null $flash @var string $tab @var array $synthese @var array $declencheurs @var array $lots @var array $politiques @var array $echeances @var float $delaiDefaut @var array $engorgement @var int $total @var array $planif */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$srcLib = array( 'manuelle' => 'Saisie', 'vente' => 'Vente', 'achat' => 'Achat', 'reglement' => 'Règlement', 'paie' => 'OD paie', 'immo' => 'Immobilisation' );

/*
 * CET ÉCRAN EST RENDU DEPUIS PLUS D'UN ENDROIT.
 *
 * Le contrôleur lui passe tout ; les harnais de vérification le rendent hors
 * routeur, avec la liste de variables qu'ils recopient à la main. Trois blocs
 * ajoutés en 1.538.0 (temporisation, échéances, engorgement) ont donc fait
 * apparaître des « Undefined variable » chez l'appelant qui ne les
 * connaissait pas encore.
 *
 * On ne demande pas à chaque appelant de suivre : un bloc d'affichage
 * supplémentaire doit pouvoir arriver sans casser ceux qui l'ignorent. Absent
 * = non affiché, jamais un avertissement.
 */
$echeances   = isset( $echeances ) ? (array) $echeances : array();
$planif      = isset( $planif ) ? (array) $planif : array();
$engorgement = isset( $engorgement ) ? (array) $engorgement : array();
$delaiDefaut = isset( $delaiDefaut ) ? $delaiDefaut
	: ( class_exists( 'FKC_PolitiqueCompta' ) ? FKC_PolitiqueCompta::DELAI_DEFAUT : 6 );
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<?php
/*
 * CLÔTURE DU JOURNAL TEMPORAIRE
 *
 * Le comptable voit ce qui attend, d'où cela vient, et sous quel régime : ce
 * qui se publiera sur un événement métier, ce qui réclame sa signature. Puis il
 * clôture, déclencheur par déclencheur.
 *
 * Les lots vides ne sont pas affichés : un bouton qui ne fait rien apprend à
 * ne plus lire les boutons.
 */
$modeLib = array(
	'immediate'  => array( 'Immédiate',  'b-on' ),
	'batch'      => array( 'Lot',        'b-warn' ),
	'manuelle'   => array( 'Validation', 'b-off' ),
	'temporisee' => array( 'Temporisée', 'b-warn' ),
);
/*
 * ALERTE D'ENGORGEMENT.
 *
 * Depuis que rien ne se comptabilise tout seul, le risque s'est déplacé : ce
 * n'est plus la publication hâtive, c'est le journal temporaire que personne
 * n'ouvre. Une comptabilité qui s'arrête n'a l'air de rien — les états ne
 * bougent plus, voilà tout. On le dit donc en haut de l'écran, avant que le
 * mois se termine dessus.
 */
?>
<?php if ( ! empty( $engorgement['nb'] ) ) : ?>
	<div class="alert alert-err">
		<strong><?= (int) $engorgement['nb'] ?> écriture(s)</strong> attendent depuis plus de
		<?= (int) $engorgement['seuil'] ?> jours (la plus ancienne : <?= (int) $engorgement['plus_ancien'] ?> jours).
		Tant qu'elles sont ici, elles ne figurent dans aucun état : ni balance, ni résultat, ni déclaration.
	</div>
<?php endif; ?>
<?php
$totalAttente = 0;
foreach ( (array) $synthese as $x ) { $totalAttente += (int) $x['nb']; }
?>
<div class="card">
	<div class="card-head"><h2>Journal temporaire — <?= (int) $totalAttente ?> écriture(s) en attente</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Le stock et la valorisation sont <strong>toujours</strong> à jour en temps réel.
			Seule la publication comptable suit la politique choisie pour chaque origine.
		</p>

		<?php if ( ! $synthese ) : ?>
			<p class="muted">Aucune écriture en attente : tout est publié.</p>
		<?php else : ?>
			<div class="ckp-table-wrap">
				<table class="ckp-table">
					<thead><tr><th>Origine</th><th>Régime</th><th>Déclencheur</th><th class="num">En attente</th></tr></thead>
					<tbody>
						<?php foreach ( $synthese as $x ) :
							$m = $modeLib[ $x['mode'] ] ?? array( $x['mode'], 'b-off' ); ?>
							<tr>
								<td><strong><?= e( $x['source'] ) ?></strong></td>
								<td><span class="modbadge <?= e( $m[1] ) ?>"><?= e( $m[0] ) ?></span></td>
								<td><?= $x['declencheur'] ? e( $declencheurs[ $x['declencheur'] ] ?? $x['declencheur'] ) : '—' ?></td>
								<td class="num"><?= (int) $x['nb'] ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

		<?php $aLot = false; foreach ( (array) $lots as $n ) { if ( $n > 0 ) { $aLot = true; } } ?>
		<?php if ( $aLot ) : ?>
			<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
				<?php foreach ( $declencheurs as $code => $lib ) : if ( empty( $lots[ $code ] ) ) { continue; } ?>
					<form method="post" action="<?= e( url( 'comptabilite/brouillard/cloturer/' . $code ) ) ?>" style="display:inline"
						onsubmit="return confirm('Publier <?= (int) $lots[ $code ] ?> écriture(s) aux journaux définitifs ?')">
						<?= FKC_Csrf::field() ?>
						<button class="btn btn-primary btn-sm" type="submit">
							✓ Clôturer — <?= e( $lib ) ?> (<?= (int) $lots[ $code ] ?>)
						</button>
					</form>
				<?php endforeach; ?>
			</div>
			<p class="help">
				Chaque bouton ne publie que son lot. Une écriture refusée par les contrôles reste
				au journal temporaire et sera reprise une fois sa cause corrigée.
			</p>
		<?php endif; ?>
	</div>
</div>

<?php
/*
 * PANNEAU REPLIABLE (1.740.0).
 *
 * Ce bloc est un RÉGLAGE, pas une opération. Il occupait pourtant le milieu
 * d'un écran qu'on ouvre pour valider des écritures, entre le lot à publier
 * et les échéances : deux écrans de texte à faire défiler chaque fois, pour
 * un contenu qu'on ne change que rarement.
 *
 * On emploie `<details>`, comme ailleurs dans le produit : le pliage est natif,
 * il fonctionne sans JavaScript, il reste accessible au clavier et il
 * s'imprime déplié. Ajouter un script pour ce que le navigateur sait faire
 * serait du travail en trop, et une panne de plus le jour où il échoue.
 *
 * REPLIÉ NE DOIT PAS VOULOIR DIRE CACHÉ. Le résumé porte donc l'essentiel —
 * combien d'origines, et combien dans chaque régime — pour qu'on sache sans
 * ouvrir si le réglage est celui qu'on croit. Un panneau fermé sur un titre
 * seul ferait perdre l'information ; fermé sur son résumé, il ne fait perdre
 * que le défilement.
 *
 * Il s'ouvre de lui-même au retour d'un enregistrement, sans quoi l'on
 * ressaisirait en croyant que rien n'a été pris.
 */
$parMode = array();
foreach ( (array) $politiques as $p ) {
	$m = (string) ( $p['mode'] ?? 'manuelle' );
	$parMode[ $m ] = ( $parMode[ $m ] ?? 0 ) + 1;
}
$libMode = array(
	'manuelle'   => 'en validation comptable',
	'temporisee' => 'temporisée(s)',
	'batch'      => 'en lot sur déclencheur',
	'immediate'  => 'en publication immédiate',
);
$resume = array();
foreach ( $libMode as $k => $lbl ) {
	if ( ! empty( $parMode[ $k ] ) ) { $resume[] = $parMode[ $k ] . ' ' . $lbl; }
}
$politiqueOuverte = ! empty( $_GET['politique'] );
?>
<details class="card fkc-acc"<?= $politiqueOuverte ? ' open' : '' ?>>
	<summary class="card-head">
		<h2>Politique de comptabilisation</h2>
		<span class="muted" style="font-size:12.5px">
			<?= (int) count( (array) $politiques ) ?> origine(s)<?= $resume ? ' · ' . e( implode( ', ', $resume ) ) : '' ?>
		</span>
	</summary>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Chaque origine choisit le moment où ses écritures deviennent définitives.
			FinaKop livre <strong>toutes</strong> les origines en « validation comptable » :
			aucune écriture ne rejoint les journaux sans qu'un humain l'ait vue.
		</p>
		<p class="help" style="margin-top:0">
			La <strong>temporisation</strong> assouplit cette règle sans l'abandonner :
			l'écriture reste consultable et corrigeable pendant le délai que vous fixez,
			puis part d'elle-même si personne ne l'a retenue. À réserver aux flux
			répétitifs — tickets, sorties de stock. Ce qui engage l'entreprise envers un
			tiers (achat, règlement, amortissement) gagne à rester en validation :
			<em>une écriture publiée au bout de six heures sans que personne ne l'ait
			regardée n'a pas été contrôlée, elle a seulement pu l'être.</em>
		</p>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr><th>Origine</th><th>Régime</th><th>Déclencheur</th><th></th></tr></thead>
				<tbody>
					<?php foreach ( $politiques as $src => $p ) : ?>
						<tr>
							<td><strong><?= e( $src ) ?></strong>
								<?php if ( 'defaut' === $p['origine'] ) : ?><span class="muted" style="font-size:11px"> — défaut</span><?php endif; ?>
							</td>
							<td colspan="3">
								<form method="post" action="<?= e( url( 'comptabilite/brouillard/politique' ) ) ?>"
									style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
									<?= FKC_Csrf::field() ?>
									<input type="hidden" name="source" value="<?= e( $src ) ?>">
									<select name="mode" class="fld">
										<?php foreach ( array( 'manuelle' => 'Validation comptable', 'temporisee' => 'Temporisée (délai puis publication)', 'batch' => 'Lot sur déclencheur', 'immediate' => 'Publication immédiate' ) as $k => $lbl ) : ?>
											<option value="<?= e( $k ) ?>" <?= $p['mode'] === $k ? 'selected' : '' ?>><?= e( $lbl ) ?></option>
										<?php endforeach; ?>
									</select>
									<select name="declencheur" class="fld">
										<option value="">—</option>
										<?php foreach ( $declencheurs as $code => $lib ) : ?>
											<option value="<?= e( $code ) ?>" <?= $p['declencheur'] === $code ? 'selected' : '' ?>><?= e( $lib ) ?></option>
										<?php endforeach; ?>
									</select>
									<?php
									/*
									 * Le délai n'est PAS pré-rempli à une valeur que
									 * l'éditeur aurait choisie : un champ déjà rempli se
									 * lit comme une recommandation, et personne n'a à
									 * recommander à une entreprise le temps qu'elle
									 * accorde à sa propre relecture. La valeur n'apparaît
									 * qu'en indication de saisie.
									 */
									?>
									<input type="number" name="delai" class="fld" style="max-width:110px" min="0.25" step="0.25"
										value="<?= ( 'temporisee' === $p['mode'] && ! empty( $p['delai'] ) ) ? e( (string) $p['delai'] ) : '' ?>"
										placeholder="<?= e( (string) $delaiDefaut ) ?> h" title="Délai avant publication automatique, en heures (mode temporisé)">
									<button class="btn btn-ghost btn-sm" type="submit">Enregistrer</button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</details>

<?php
/*
 * ÉCHÉANCES DE TEMPORISATION.
 *
 * Un délai qui court sans être visible est un délai qui surprend. Celui qui
 * dispose de six heures pour se relire doit savoir combien il lui en reste,
 * et pouvoir arrêter le compte à rebours sur une pièce douteuse — sans quoi
 * il la retrouverait publiée le lendemain, justificatif toujours manquant.
 */
?>
<?php if ( ! empty( $echeances ) ) : ?>
<div class="card">
	<div class="card-head"><h2>Publication temporisée — <?= count( $echeances ) ?> écriture(s)</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Le décompte démarre à l'arrivée au journal temporaire. Il s'agit d'un
			<strong>minimum</strong> : la publication a lieu au premier passage suivant
			l'échéance, pas à la seconde près.
		</p>
		<?php
		/*
		 * ON DIT SI LE PASSAGE AURA VRAIMENT LIEU.
		 *
		 * Une temporisation réglée mais jamais déclenchée est une promesse en
		 * l'air : les écritures attendraient indéfiniment un rendez-vous que
		 * personne n'honore. Trois états possibles, et on les distingue —
		 * annoncer « automatique » dans les trois serait mentir dans deux.
		 */
		?>
		<?php if ( ! empty( $planif['cron_coupe'] ) ) : ?>
			<div class="alert alert-warn">
				Le planificateur de WordPress est désactivé sur ce serveur (<code>DISABLE_WP_CRON</code>).
				C'est un réglage d'hébergement courant et sain, mais il suppose qu'un vrai cron système
				prenne le relais : faites-lui exécuter
				<code>wp cron event run fkc_balayage_temporisation</code> au moins une fois par heure.
				<strong>Sans cela, les écritures temporisées ne partiront qu'à l'occasion d'une visite.</strong>
			</div>
		<?php elseif ( empty( $planif['planifie'] ) ) : ?>
			<div class="alert alert-warn">
				Aucun passage automatique n'est programmé. Les écritures temporisées ne partiront
				qu'à l'occasion d'une visite de l'application. Désactiver puis réactiver l'extension
				repose la planification ; en attendant, le bouton ci-dessous fait le travail.
			</div>
		<?php elseif ( ! empty( $planif['prochain'] ) ) : ?>
			<p class="help" style="margin-top:0">
				Prochain passage automatique : <strong><?= e( date( 'd/m/Y H:i', (int) $planif['prochain'] ) ) ?></strong>.
			</p>
		<?php endif; ?>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr><th>Pièce</th><th>Libellé</th><th>Origine</th><th class="num">Publication</th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $echeances as $x ) : ?>
					<tr>
						<td><?= e( (string) ( $x['piece'] ?: ( '#' . $x['id'] ) ) ) ?></td>
						<td><?= e( (string) $x['libelle'] ) ?></td>
						<td class="muted"><?= e( (string) $x['source'] ) ?></td>
						<td class="num">
							<?php if ( ! empty( $x['retenu'] ) ) : ?>
								<span class="b-off">Retenue</span>
							<?php elseif ( 0 === (int) $x['reste_min'] ) : ?>
								<span class="b-warn">Échue</span>
							<?php elseif ( $x['reste_min'] >= 60 ) : ?>
								dans <?= (int) floor( $x['reste_min'] / 60 ) ?> h <?= (int) ( $x['reste_min'] % 60 ) ?> min
							<?php else : ?>
								dans <?= (int) $x['reste_min'] ?> min
							<?php endif; ?>
						</td>
						<td>
							<form method="post" action="<?= e( url( 'comptabilite/brouillard/' . (int) $x['id'] . '/retenir' ) ) ?>"
								style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
								<?= FKC_Csrf::field() ?>
								<?php if ( ! empty( $x['retenu'] ) ) : ?>
									<button class="btn btn-ghost btn-sm" type="submit">Relâcher</button>
								<?php else : ?>
									<input type="hidden" name="retenir" value="1">
									<input type="text" name="motif" class="fld" style="max-width:190px" placeholder="Motif de la retenue">
									<button class="btn btn-ghost btn-sm" type="submit">Retenir</button>
								<?php endif; ?>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<form method="post" action="<?= e( url( 'comptabilite/brouillard/publier-echues' ) ) ?>" style="margin-top:10px">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-ghost btn-sm" type="submit">Publier maintenant ce dont le délai est écoulé</button>
		</form>
	</div>
</div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Vérification avant comptabilisation</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">Lorsque cette option est active, chaque écriture générée (saisie manuelle, ventes, achats, règlements de trésorerie et OD de paie) est d'abord déposée au <strong>brouillard</strong>. Vous pouvez la contrôler et la modifier, puis la comptabiliser. Tant qu'une écriture est au brouillard, elle n'impacte aucun état comptable.</p>
		<form method="post" action="<?= e( url( 'comptabilite/brouillard/parametre' ) ) ?>" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld-check" style="margin:0">
				<input type="checkbox" name="actif" value="1" <?= $actif ? 'checked' : '' ?> onchange="this.form.submit()">
				<span>Vérifier les écritures avant comptabilisation</span>
			</label>
			<span class="modbadge <?= $actif ? 'b-on' : 'b-off' ?>"><?= $actif ? 'Activé' : 'Désactivé' ?></span>
			<noscript><button class="btn btn-sm" type="submit">Enregistrer</button></noscript>
		</form>
	</div>
</div>

<div class="bar">
	<?php
	/*
	 * On distingue CE QUI EST AFFICHÉ de CE QUI EXISTE (1.543.0).
	 *
	 * La liste est bornée pour rester lisible. Écrire le nombre de lignes
	 * affichées comme s'il s'agissait du total ferait croire à un journal
	 * temporaire soldé alors qu'il en resterait des milliers — et cette
	 * illusion coûte cher depuis que toute écriture y passe.
	 */
	$affichees = count( $brouillons );
	$total     = isset( $total ) ? (int) $total : $affichees;
	?>
	<span class="muted">
		<?php if ( $total > $affichees ) : ?>
			<?= (int) $affichees ?> écriture(s) affichée(s) sur <strong><?= (int) $total ?></strong> en attente de vérification
		<?php else : ?>
			<?= (int) $total ?> écriture(s) en attente de vérification
		<?php endif; ?>
	</span>
	<?php if ( $brouillons ) : ?>
	<form method="post" action="<?= e( url( 'comptabilite/brouillard/valider-tout' ) ) ?>" onsubmit="return confirm('Comptabiliser toutes les écritures équilibrées du brouillard ?');">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-primary" type="submit">Tout comptabiliser</button>
	</form>
	<?php endif; ?>
</div>

<div class="card card-flush"><table class="table">
	<thead><tr><th>Date</th><th>Journal</th><th>Pièce</th><th>Libellé</th><th>Origine</th><th class="num">Débit</th><th class="num">Crédit</th><th>État</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $brouillons ) : ?>
		<tr><td colspan="9" class="empty">Aucune écriture en attente. Les écritures comptabilisées directement n'apparaissent pas ici.</td></tr>
	<?php else : foreach ( $brouillons as $b ) :
		$eq = abs( (float) $b['total_debit'] - (float) $b['total_credit'] ) < 1; ?>
		<tr>
			<td class="code"><?= e( $b['date_ecriture'] ) ?></td>
			<td><span class="code"><?= e( $b['journal_code'] ) ?></span></td>
			<td class="muted"><?= e( $b['piece'] ?: '—' ) ?></td>
			<td><?= e( $b['libelle'] ) ?><?php if ( ! empty( $pieces[ $b['id'] ] ) ) : ?> <span class="pj-flag" title="<?= (int) $pieces[ $b['id'] ] ?> pièce(s) jointe(s)">📎<?= (int) $pieces[ $b['id'] ] > 1 ? '<sup>' . (int) $pieces[ $b['id'] ] . '</sup>' : '' ?></span><?php endif; ?></td>
			<td><span class="modbadge"><?= e( $srcLib[ $b['source'] ] ?? ucfirst( $b['source'] ) ) ?></span></td>
			<td class="num"><?= e( fkc_money( $b['total_debit'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $b['total_credit'] ) ) ?></td>
			<td><?php if ( $eq ) : ?><span class="ok">Équilibrée</span><?php else : ?><span class="ko">Déséquilibre</span><?php endif; ?></td>
			<td class="right" style="white-space:nowrap">
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/brouillard/' . (int) $b['id'] ) ) ?>">Vérifier</a>
				<?php if ( $eq ) : ?>
				<form method="post" action="<?= e( url( 'comptabilite/brouillard/' . (int) $b['id'] . '/valider' ) ) ?>" style="display:inline" onsubmit="return confirm('Comptabiliser cette écriture ?');">
					<?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" type="submit">Comptabiliser</button>
				</form>
				<?php endif; ?>
				<form method="post" action="<?= e( url( 'comptabilite/brouillard/' . (int) $b['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer définitivement ce brouillon ?');">
					<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Supprimer</button>
				</form>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
