<?php /** @var array $b @var array $journaux @var array $comptes @var array $errors @var string $tab @var array $controle */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
/*
 * IMPUTATIONS MODIFIABLES (1.763.0).
 *
 * La division, l'axe et la valeur ne voyageaient ici qu'en champs CACHÉS :
 * l'écran les conservait, mais ne permettait pas de les corriger. Or le
 * brouillard est l'endroit où l'on relit avant de comptabiliser, et une
 * imputation fausse ne se voit souvent qu'à ce moment-là — après quoi il
 * fallait supprimer le brouillon et tout ressaisir.
 */
$hasDiv  = ! empty( $showDivision ) && ! empty( $divisions );
$hasAxes = ! empty( $showAxes ) && ! empty( $axes );
$colsAna = ( $hasDiv ? 1 : 0 ) + ( $hasAxes ? 2 : 0 );
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>

<div class="bar"><span class="muted">Brouillon n°<?= (int) $b['id'] ?> — origine : <?= e( $b['source'] ) ?></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/brouillard' ) ) ?>">← Retour au brouillard</a></div>

<?php
/* ── Contrôles avant comptabilisation ─────────────────────────────────────
   Le bouton « Comptabiliser » existait sans qu'aucun état des lieux ne soit
   affiché : on validait sans savoir quoi. Trois niveaux — un bloquant empêche
   la comptabilisation, un avertissement la laisse passer sous la
   responsabilité de l'utilisateur, une information signale un effet de bord. */
$ctl = isset( $controle ) && is_array( $controle ) ? $controle : array( 'controles' => array(), 'bloquants' => 0, 'avertissements' => 0, 'ok' => true );
$icones = array( 'ok' => '✔', 'avertissement' => '⚠', 'bloquant' => '⛔', 'info' => 'ℹ' );
$couleurs = array( 'ok' => '#0a7f3f', 'avertissement' => '#996800', 'bloquant' => '#b32d2e', 'info' => '#4a5568' );
?>
<?php if ( ! empty( $ctl['controles'] ) ) : ?>
<div class="card">
	<div class="card-head"><h2>Contrôles avant comptabilisation</h2>
		<span class="muted" style="margin-left:auto">
			<?php if ( $ctl['bloquants'] ) : ?>
				<strong style="color:#b32d2e"><?= (int) $ctl['bloquants'] ?> bloquant<?= $ctl['bloquants'] > 1 ? 's' : '' ?></strong>
			<?php elseif ( $ctl['avertissements'] ) : ?>
				<strong style="color:#996800"><?= (int) $ctl['avertissements'] ?> point<?= $ctl['avertissements'] > 1 ? 's' : '' ?> d'attention</strong>
			<?php else : ?>
				<strong style="color:#0a7f3f">Tout est en ordre</strong>
			<?php endif; ?>
		</span>
	</div>
	<div class="card-body">
		<ul style="list-style:none;margin:0;padding:0;display:grid;gap:6px">
		<?php foreach ( $ctl['controles'] as $c ) :
			$n = isset( $c['niveau'] ) ? $c['niveau'] : 'info'; ?>
			<li style="display:flex;gap:8px;align-items:flex-start">
				<span style="color:<?= e( $couleurs[ $n ] ?? '#4a5568' ) ?>;flex:0 0 auto"><?= e( $icones[ $n ] ?? '·' ) ?></span>
				<span<?= 'bloquant' === $n ? ' style="color:#b32d2e"' : '' ?>><?= e( $c['texte'] ) ?></span>
			</li>
		<?php endforeach; ?>
		</ul>
		<?php if ( $ctl['bloquants'] ) : ?>
			<p class="help" style="margin-top:10px;color:#b32d2e">
				La comptabilisation est refusée tant qu'un point bloquant subsiste. Corrigez l'écriture ci-dessous, puis enregistrez.
			</p>
		<?php elseif ( $ctl['avertissements'] ) : ?>
			<p class="help" style="margin-top:10px">
				Ces points n'empêchent pas la comptabilisation, mais une écriture comptabilisée ne peut plus être modifiée :
				elle ne se corrige qu'en la contre-passant. Autant régler ce qui peut l'être maintenant.
			</p>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

<form method="post" action="<?= e( url( 'comptabilite/brouillard/' . (int) $b['id'] ) ) ?>" id="brl-form">
	<?= FKC_Csrf::field() ?>
	<div class="card">
		<div class="card-head"><h2>En-tête</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Journal</span>
					<select name="journal_id" required>
						<?php foreach ( $journaux as $j ) : ?>
							<option value="<?= (int) $j['id'] ?>" <?= (int) $j['id'] === (int) $b['journal_id'] ? 'selected' : '' ?>><?= e( $j['code'] . ' · ' . $j['libelle'] ) ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="fld"><span>Date</span><input type="date" name="date_ecriture" value="<?= e( $b['date_ecriture'] ) ?>" required></label>
				<label class="fld"><span>N° de pièce</span><input type="text" name="piece" value="<?= e( $b['piece'] ) ?>"></label>
				<label class="fld"><span>Référence</span><input type="text" name="reference" value="<?= e( $b['reference'] ) ?>"></label>
			</div>
			<label class="fld"><span>Libellé de l'écriture</span>
				<input type="text" name="libelle" value="<?= e( $b['libelle'] ) ?>" required></label>
		</div>
	</div>

	<div class="card card-flush">
		<div class="card-head"><h2>Lignes (partie double)</h2>
			<button type="button" class="btn btn-ghost btn-sm" id="brl-add">+ Ajouter une ligne</button></div>
		<table class="table" id="brl-table">
			<thead><tr><th style="width:<?= $colsAna ? 24 : 32 ?>%">Compte</th><th>Libellé</th>
				<?php if ( $hasDiv ) : ?><th style="width:150px">Division</th><?php endif; ?>
				<?php if ( $hasAxes ) : ?><th style="width:140px">Axe</th><th style="width:160px">Valeur analytique</th><?php endif; ?>
				<th class="num" style="width:140px">Débit</th>
				<th class="num" style="width:140px">Crédit</th><th style="width:40px"></th></tr></thead>
			<tbody id="brl-body"></tbody>
			<tfoot>
				<tr class="total"><td colspan="<?= 2 + $colsAna ?>" class="right">Totaux</td>
					<td class="num" id="brl-td">0</td><td class="num" id="brl-tc">0</td><td></td></tr>
				<tr><td colspan="<?= 5 + $colsAna ?>" class="balance-state" id="brl-state"></td></tr>
			</tfoot>
		</table>
	</div>

	<div class="actions">
		<button class="btn btn-primary" type="submit" id="brl-submit">Enregistrer les modifications</button>
		<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/brouillard' ) ) ?>">Annuler</a>
	</div>
</form>

<script>
window.BRL_COMPTES = <?= json_encode( array_map( function ( $c ) {
	return array( 'id' => (int) $c['id'], 't' => $c['numero'] . ' · ' . $c['libelle'] );
}, $comptes ), JSON_UNESCAPED_UNICODE ) ?>;
window.BRL_SEED = <?= json_encode( array_map( function ( $l ) {
	return array(
		'compte_id' => (int) $l['compte_id'],
		'libelle'   => (string) $l['libelle'],
		'debit'     => (float) $l['debit'],
		'credit'    => (float) $l['credit'],
		'division'  => isset( $l['division_id'] ) && $l['division_id'] ? (int) $l['division_id'] : '',
		'axe'       => isset( $l['axe_id'] ) && $l['axe_id'] ? (int) $l['axe_id'] : '',
		'valeur'    => isset( $l['valeur_id'] ) && $l['valeur_id'] ? (int) $l['valeur_id'] : '',
		// Affectations des AUTRES axes, reportées telles quelles (1.763.0).
		'affect'    => ! empty( $l['affectations'] ) ? (string) $l['affectations'] : '',
	);
}, $b['lignes'] ), JSON_UNESCAPED_UNICODE ) ?>;
window.BRL_SHOW_DIV = <?= $hasDiv ? 'true' : 'false' ?>;
window.BRL_DIVISIONS = <?= json_encode( array_map( function ( $d ) {
	return array( 'id' => (int) $d['id'], 't' => $d['libelle'] );
}, $divisions ?? array() ), JSON_UNESCAPED_UNICODE ) ?>;
window.BRL_SHOW_AXES = <?= $hasAxes ? 'true' : 'false' ?>;
window.BRL_AXES = <?= json_encode( array_map( function ( $a ) {
	return array( 'id' => (int) $a['id'], 't' => $a['code'] . ' · ' . $a['libelle'] );
}, $axes ?? array() ), JSON_UNESCAPED_UNICODE ) ?>;
window.BRL_VALEURS = <?= json_encode( $valeursMap ?? array(), JSON_UNESCAPED_UNICODE ) ?>;
(function () {
	var body = document.getElementById('brl-body'); if (!body) return;
	var comptes = window.BRL_COMPTES || [];
	var showDiv = !!window.BRL_SHOW_DIV, divisions = window.BRL_DIVISIONS || [];
	var showAxes = !!window.BRL_SHOW_AXES, axes = window.BRL_AXES || [];
	var valeursByAxe = window.BRL_VALEURS || {};
	function sel(list, val, vide) {
		return '<option value="">' + vide + '</option>' + list.map(function (o) {
			return '<option value="' + o.id + '"' + (String(o.id) === String(val) ? ' selected' : '') + '>' + o.t + '</option>';
		}).join('');
	}
	function valeursDe(axeId, val) {
		return sel((axeId && valeursByAxe[axeId]) ? valeursByAxe[axeId] : [], val, '— valeur —');
	}
	function opts(sel){ return '<option value="">—</option>' + comptes.map(function(c){ return '<option value="'+c.id+'"'+(c.id==sel?' selected':'')+'>'+c.t+'</option>'; }).join(''); }
	function num(v){ return parseFloat((v||'0').toString().replace(/\s/g,'').replace(',','.'))||0; }
	function fmt(n){ return n.toLocaleString('fr-FR'); }
	function recompute(){
		var td=0, tc=0;
		body.querySelectorAll('tr').forEach(function(tr){ td+=num(tr.querySelector('[name="debit[]"]').value); tc+=num(tr.querySelector('[name="credit[]"]').value); });
		document.getElementById('brl-td').textContent=fmt(td);
		document.getElementById('brl-tc').textContent=fmt(tc);
		var st=document.getElementById('brl-state'), btn=document.getElementById('brl-submit');
		var diff=Math.round((td-tc)*100)/100;
		if(td===0&&tc===0){ st.innerHTML=''; }
		else if(diff===0){ st.innerHTML='<span class="ok">Écriture équilibrée ✓</span>'; }
		else { st.innerHTML='<span class="ko">Déséquilibre : '+fmt(Math.abs(diff))+' FCFA</span>'; }
	}
	function bind(tr){
		tr.querySelectorAll('.amount').forEach(function(i){ i.addEventListener('input', recompute); });
		tr.querySelector('.del').addEventListener('click', function(){ tr.remove(); recompute(); });
		var axeSel = tr.querySelector('.brl-axe');
		if (axeSel) {
			axeSel.addEventListener('change', function () {
				var v = tr.querySelector('.brl-val');
				if (v) { v.innerHTML = valeursDe(axeSel.value, ''); }
			});
		}
	}
	function addLine(seed){
		seed = seed || {};
		var tr=document.createElement('tr');
		tr.innerHTML =
			'<td><select name="compte_id[]">'+opts(seed.compte_id||'')+'</select>'+
			/* Les affectations des autres axes repartent telles quelles. */
			'<input type="hidden" name="affectations[]" value="'+(seed.affect?String(seed.affect).replace(/"/g,'&quot;'):'')+'">'+
			(showDiv ? '' : '<input type="hidden" name="division_id[]" value="'+(seed.division!==undefined?seed.division:'')+'">')+
			(showAxes ? '' :
				'<input type="hidden" name="axe_id[]" value="'+(seed.axe!==undefined?seed.axe:'')+'">'+
				'<input type="hidden" name="valeur_id[]" value="'+(seed.valeur!==undefined?seed.valeur:'')+'">')+
			'</td>'+
			'<td><input name="ligne_libelle[]" value="'+(seed.libelle?String(seed.libelle).replace(/"/g,'&quot;'):'')+'" placeholder="libellé ligne"></td>'+
			(showDiv ? '<td><select name="division_id[]">'+sel(divisions, seed.division, '— non imputé —')+'</select></td>' : '')+
			(showAxes
				? '<td><select name="axe_id[]" class="brl-axe">'+sel(axes, seed.axe, '— aucun axe —')+'</select></td>'+
				  '<td><select name="valeur_id[]" class="brl-val">'+valeursDe(seed.axe, seed.valeur)+'</select></td>'
				: '')+
			'<td><input class="amount num" name="debit[]" inputmode="decimal" value="'+(seed.debit?seed.debit:'')+'" placeholder="0"></td>'+
			'<td><input class="amount num" name="credit[]" inputmode="decimal" value="'+(seed.credit?seed.credit:'')+'" placeholder="0"></td>'+
			'<td style="text-align:center"><button type="button" class="btn btn-ghost btn-sm del">×</button></td>';
		body.appendChild(tr); bind(tr);
	}
	document.getElementById('brl-add').addEventListener('click', function(){ addLine(); recompute(); });
	(window.BRL_SEED||[]).forEach(addLine);
	if(!(window.BRL_SEED||[]).length){ addLine(); addLine(); }
	recompute();
})();
</script>

<?php FKC_View::partial( 'comptabilite::_pieces', array(
	'pieces'       => $pieces ?? array(),
	'piecesUpload' => 'comptabilite/brouillard/' . (int) $b['id'] . '/pieces',
	'piecesBase'   => 'comptabilite/brouillard/piece',
) ); ?>
