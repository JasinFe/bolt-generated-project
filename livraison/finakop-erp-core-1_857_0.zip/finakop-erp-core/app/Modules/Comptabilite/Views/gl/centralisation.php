<?php /** @var int $annee @var array $journaux @var float $produits @var float $charges @var float $resultat @var array $clotures @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$types = FKC_Cloture::types(); $td=0;$tc=0; foreach($journaux as $j){$td+=$j['d'];$tc+=$j['c'];} ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Centralisation — exercice <?= $annee ?></span>
	<div style="display:flex;gap:8px;align-items:center">
		<form method="get" action="<?= e( url('comptabilite/gl') ) ?>" class="inline"><input type="number" name="annee" value="<?= $annee ?>" style="width:90px" onchange="this.form.submit()"></form>
		<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/ecritures/nouvelle') ) ?>">+ Opération diverse (OD)</a>
	</div>
</div>

<div class="fac-layout" style="grid-template-columns:2fr 1fr">
	<div class="card card-flush" style="margin:0"><div class="card-head"><h2>Centralisation des journaux</h2></div>
		<table class="table"><thead><tr><th>Journal</th><th class="num">Écritures</th><th class="num">Débit</th><th class="num">Crédit</th></tr></thead>
		<tbody>
		<?php foreach ( $journaux as $j ) : ?>
			<tr><td><span class="code"><?= e($j['code']) ?></span> <?= e($j['libelle']) ?></td><td class="num muted"><?= (int)$j['nb'] ?></td>
			<td class="num"><?= e( fkc_money($j['d']) ) ?></td><td class="num"><?= e( fkc_money($j['c']) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr class="total"><td class="right">TOTAL</td><td></td><td class="num"><?= e( fkc_money($td) ) ?></td><td class="num"><?= e( fkc_money($tc) ) ?></td></tr></tfoot>
		</table>
	</div>
	<div class="card" style="margin:0"><div class="card-head"><h2>Résultat <?= $annee ?></h2></div><div class="card-body">
		<div class="kv"><span>Produits (cl. 7)</span><strong><?= e( fkc_money($produits) ) ?></strong></div>
		<div class="kv"><span>Charges (cl. 6)</span><strong><?= e( fkc_money($charges) ) ?></strong></div>
		<hr style="border-color:var(--line);margin:10px 0">
		<div class="kv"><span style="font-weight:700">Résultat <?= $resultat>=0?'(bénéfice)':'(perte)' ?></span>
			<strong style="font-size:18px;color:<?= $resultat>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money($resultat) ) ?> F</strong></div>
	</div></div>
</div>

<div class="card" style="margin-top:20px"><div class="card-head"><h2>Clôtures de période</h2></div><div class="card-body">
	<form method="post" action="<?= e( url('comptabilite/gl/cloturer') ) ?>" class="cloture-form">
		<?= FKC_Csrf::field() ?>
		<label class="fld"><span>Type</span><select name="type" id="clType"><?php foreach($types as $k=>$v):?><option value="<?= e($k) ?>"><?= e($v) ?></option><?php endforeach;?></select></label>
		<label class="fld"><span>Année</span><input type="number" name="annee" value="<?= (int)date('Y') ?>"></label>
		<label class="fld"><span id="subLbl">Mois (1-12)</span><input type="number" name="sub" id="clSub" value="<?= (int)date('n') ?>" min="1" max="12"></label>
		<button class="btn btn-primary" type="submit">Clôturer</button>
	</form>
	<p class="help" style="margin:6px 0 14px">Une période clôturée est verrouillée : plus aucune écriture ne peut y être saisie. La clôture annuelle génère en plus l'écriture de détermination du résultat (classes 6 & 7 → compte 130).</p>
	<table class="table bordered">
		<thead><tr><th>Type</th><th>Période</th><th class="num">Résultat</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $clotures ) : ?><tr><td colspan="4" class="empty">Aucune clôture.</td></tr>
		<?php else : foreach ( $clotures as $c ) : ?>
			<tr><td><span class="modbadge b-on"><?= e( $types[$c['type']] ?? $c['type'] ) ?></span></td>
			<td><?= e( date('d/m/Y',strtotime($c['periode_debut'])) ) ?> → <?= e( date('d/m/Y',strtotime($c['periode_fin'])) ) ?></td>
			<td class="num"><?= null!==$c['resultat']?e(fkc_money($c['resultat'])):'—' ?></td>
			<td class="right"><form method="post" action="<?= e( url('comptabilite/gl/rouvrir/'.$c['id']) ) ?>" onsubmit="return confirm('Rouvrir cette période ?')" style="margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Rouvrir</button></form></td></tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div></div>
<script>
(function(){var t=document.getElementById('clType'),s=document.getElementById('clSub'),l=document.getElementById('subLbl');
if(!t)return;t.addEventListener('change',function(){var v=t.value;if(v==='mensuelle'){l.textContent='Mois (1-12)';s.max=12;s.disabled=false;}else if(v==='trimestrielle'){l.textContent='Trimestre (1-4)';s.max=4;s.disabled=false;}else if(v==='semestrielle'){l.textContent='Semestre (1-2)';s.max=2;s.disabled=false;}else{l.textContent='(année entière)';s.disabled=true;}});})();
</script>
<style>.cloture-form{display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap}.kv{display:flex;justify-content:space-between;padding:4px 0}.kv span{color:var(--muted)}</style>
