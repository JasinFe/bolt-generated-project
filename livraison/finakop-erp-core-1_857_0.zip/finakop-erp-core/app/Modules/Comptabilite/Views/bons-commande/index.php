<?php /** @var array $bons @var array $statuts @var array $factures @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted"><?= count( $bons ) ?> bon(s) de commande</span>
	<a class="btn btn-primary" href="<?= e( url( 'comptabilite/bons-commande/nouveau' ) ) ?>">+ Nouveau bon de commande</a>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : n°, fournisseur, statut…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>N°</th><th>Date</th><th>Fournisseur</th><th>Objet</th><th class="num">Montant TTC</th><th>Statut</th><th>Facture liée</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $bons ) : ?><tr><td colspan="8" class="empty">Aucun bon de commande. Créez-en un.</td></tr>
	<?php else : foreach ( $bons as $b ) : ?>
		<tr>
			<td class="code"><?= e( $b['numero'] ) ?></td>
			<td class="code"><?= e( $b['date_bc'] ) ?></td>
			<td><?= e( $b['fournisseur_nom'] ?: '—' ) ?></td>
			<td><?= e( $b['objet'] ?: '—' ) ?></td>
			<td class="num"><?= e( fkc_money( $b['montant_ttc'] ) ) ?></td>
			<td>
				<?php $st = $b['statut']; $cls = 'rattache' === $st ? 'b-on' : ( 'annule' === $st ? 'b-off' : '' ); ?>
				<span class="modbadge <?= $cls ?>"><?= e( $statuts[ $st ] ?? $st ) ?></span>
			</td>
			<td class="code"><?= e( $b['facture_numero'] ?: '—' ) ?></td>
			<td class="right" style="white-space:nowrap">
				<?php if ( 'annule' === $b['statut'] ) : ?>
					<span class="muted">—</span>
				<?php elseif ( $b['facture_fournisseur_id'] ) : ?>
					<form method="post" action="<?= e( url( 'comptabilite/bons-commande/' . (int) $b['id'] . '/detacher' ) ) ?>" style="display:inline">
						<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Détacher</button>
					</form>
				<?php else : ?>
					<form method="post" action="<?= e( url( 'comptabilite/bons-commande/' . (int) $b['id'] . '/rattacher' ) ) ?>" style="display:inline-flex;gap:4px;align-items:center">
						<?= FKC_Csrf::field() ?>
						<select name="facture_fournisseur_id" class="fld" style="margin:0;min-width:160px" required>
							<option value="">Rattacher à…</option>
							<?php foreach ( $factures as $f ) : ?>
								<option value="<?= (int) $f['id'] ?>"><?= e( $f['numero'] ) ?> · <?= e( fkc_money( $f['montant_ttc'] ) ) ?></option>
							<?php endforeach; ?>
						</select>
						<button class="btn btn-ghost btn-sm" type="submit">OK</button>
					</form>
					<form method="post" action="<?= e( url( 'comptabilite/bons-commande/' . (int) $b['id'] . '/annuler' ) ) ?>" style="display:inline" onsubmit="return confirm('Annuler ce bon de commande ?');">
						<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Annuler</button>
					</form>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
