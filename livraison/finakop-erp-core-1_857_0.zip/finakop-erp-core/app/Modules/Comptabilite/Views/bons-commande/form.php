<?php /** @var array $fournisseurs @var array $errors */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>
<form method="post" action="<?= e( url( 'comptabilite/bons-commande' ) ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="card">
		<div class="card-head"><h2>Nouveau bon de commande</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Fournisseur</span>
					<select name="fournisseur_id">
						<option value="">— Sélectionner (référentiel) —</option>
						<?php foreach ( $fournisseurs as $f ) : ?><option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option><?php endforeach; ?>
					</select></label>
				<label class="fld"><span>… ou fournisseur libre</span>
					<input type="text" name="fournisseur_nom" placeholder="Nom du fournisseur"></label>
				<label class="fld"><span>Date du bon</span>
					<input type="date" name="date_bc" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld"><span>Date de livraison souhaitée</span>
					<input type="date" name="date_livraison"></label>
				<label class="fld" style="grid-column:1/-1"><span>Objet</span>
					<input type="text" name="objet" placeholder="Ex : Fournitures de bureau"></label>
				<label class="fld"><span>Montant HT</span>
					<input type="number" name="montant_ht" min="0" value="0"></label>
				<label class="fld"><span>Montant TTC *</span>
					<input type="number" name="montant_ttc" min="0" value="0" required></label>
				<label class="fld" style="grid-column:1/-1"><span>Notes</span>
					<textarea name="notes" rows="2"></textarea></label>
			</div>
			<p class="help" style="margin:8px 0 0">Le bon de commande pourra ensuite être rattaché à une facture fournisseur depuis la liste.</p>
		</div>
	</div>
	<div class="actions">
		<button class="btn btn-primary" type="submit">Créer le bon de commande</button>
		<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/bons-commande' ) ) ?>">Annuler</a>
	</div>
</form>
