<?php /** @var array|null $resultat @var array $errors @var string $type @var array $opts @var bool $peut_confirmer @var bool $apres_execution */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$errors = $errors ?? array();
$r = $resultat;
$fmt = function ( $v ) { return fkc_money( (float) $v ) . ' F'; };
FKC_View::partial( 'comptabilite::_subnav' );
?>
<div class="card">
	<div class="card-head"><h2>🔄 Migration / Reprise de comptabilité</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">Reprenez la comptabilité d'un autre logiciel (Odoo, Sage, SAP Business One, Cegid, Dynamics 365, Dolibarr, ERPNext…) pour continuer votre exercice dans FinaKop. Ces logiciels exportent tous une <strong>balance</strong> et un <strong>journal d'écritures</strong> au format CSV : c'est ce fichier que vous déposez ici. Chaque import se fait en deux temps — un <strong>aperçu</strong> qui contrôle et totalise sans rien enregistrer, puis une <strong>confirmation</strong> qui écrit les écritures.</p>
	</div>
</div>

<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>

<?php /* ══ RÉSULTAT (aperçu ou après exécution) ══ */ ?>
<?php if ( $r ) : $t = $r['_type'] ?? 'balance'; $anos = $r['anomalies'] ?? array(); ?>
	<?php if ( $apres_execution && ! empty( $r['ok'] ) && ! empty( $r['execute'] ) ) : ?>
		<div class="alert alert-ok">
			<strong>✅ Reprise enregistrée.</strong>
			<?php if ( 'balance' === $t ) : ?>
				<?= count( $r['ecritures'] ?? array() ) ?> écriture(s) de reprise créée(s)<?php if ( ! empty( $r['comptes_a_creer'] ) ) : ?>, <?= (int) $r['comptes_a_creer'] ?> compte(s) créé(s)<?php endif; ?>.
			<?php elseif ( 'ecritures' === $t ) : ?>
				<?= (int) ( $r['ecritures'] ?? 0 ) ?> écriture(s) importée(s) (<?= (int) ( $r['lignes'] ?? 0 ) ?> lignes).
			<?php else : ?>
				Plan comptable : <?= (int) ( $r['crees'] ?? 0 ) ?> compte(s) créé(s), <?= (int) ( $r['existants'] ?? 0 ) ?> déjà présent(s).
			<?php endif; ?>
		</div>
		<div class="card"><div class="card-body">
			<a class="btn btn-primary" href="<?= e( url( 'comptabilite/ecritures' ) ) ?>">Voir les écritures</a>
			<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/migration' ) ) ?>">Nouvel import</a>
		</div></div>
	<?php else : ?>
		<?php /* Aperçu : synthèse + anomalies éventuelles */ ?>
		<div class="card card-flush">
			<div class="card-head"><h2>👁️ Aperçu — <?= 'balance' === $t ? 'balance de reprise' : ( 'ecritures' === $t ? 'écritures détaillées' : 'plan comptable' ) ?></h2>
				<span class="tag" style="color:<?= empty( $anos ) ? 'var(--ok)' : 'var(--danger)' ?>"><?= empty( $anos ) ? '● Prêt à confirmer' : '● ' . count( $anos ) . ' anomalie(s)' ?></span>
			</div>
			<div class="card-body">
				<?php if ( 'balance' === $t ) : ?>
					<table class="table">
						<tbody>
						<tr><td>Mode de reprise</td><td style="text-align:right"><strong><?= 'complete' === ( $r['mode'] ?? '' ) ? 'Balance complète (en cours d\'exercice)' : 'À-nouveaux (ouverture d\'exercice)' ?></strong></td></tr>
						<tr><td>Date de reprise</td><td style="text-align:right"><?= e( $r['date'] ?? '' ) ?></td></tr>
						<?php if ( 'complete' === ( $r['mode'] ?? '' ) ) : ?>
						<tr><td>Début d'exercice (à-nouveaux)</td><td style="text-align:right"><?= e( $r['debut_exercice'] ?? '' ) ?></td></tr>
						<?php endif; ?>
						<tr><td>Comptes de bilan repris</td><td style="text-align:right"><?= (int) ( $r['nb_bilan'] ?? 0 ) ?></td></tr>
						<?php if ( 'complete' === ( $r['mode'] ?? '' ) ) : ?>
						<tr><td>Comptes de gestion (charges/produits)</td><td style="text-align:right"><?= (int) ( $r['nb_gestion'] ?? 0 ) ?></td></tr>
						<tr><td>Charges de la période</td><td style="text-align:right"><?= $fmt( $r['charges_periode'] ?? 0 ) ?></td></tr>
						<tr><td>Produits de la période</td><td style="text-align:right"><?= $fmt( $r['produits_periode'] ?? 0 ) ?></td></tr>
						<tr style="font-weight:700"><td>Résultat de la période reprise</td><td style="text-align:right;color:<?= ( $r['resultat_periode'] ?? 0 ) >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= $fmt( $r['resultat_periode'] ?? 0 ) ?><?= ( $r['resultat_periode'] ?? 0 ) >= 0 ? ' (bénéfice)' : ' (perte)' ?></td></tr>
						<?php else : ?>
						<tr><td>Soldes de gestion ignorés (classes 6-7)</td><td style="text-align:right"><?= (int) ( $r['ignorees_gestion'] ?? 0 ) ?></td></tr>
						<?php endif; ?>
						<tr><td>Total débit / crédit du bilan</td><td style="text-align:right"><?= $fmt( $r['total_debit'] ?? 0 ) ?> / <?= $fmt( $r['total_credit'] ?? 0 ) ?></td></tr>
						<?php if ( ! empty( $r['comptes_a_creer'] ) ) : ?>
						<tr><td>Comptes à créer automatiquement</td><td style="text-align:right"><?= (int) $r['comptes_a_creer'] ?></td></tr>
						<?php endif; ?>
						</tbody>
					</table>
				<?php elseif ( 'ecritures' === $t ) : ?>
					<table class="table"><tbody>
						<tr><td>Écritures reconstituées</td><td style="text-align:right"><strong><?= (int) ( $r['ecritures'] ?? 0 ) ?></strong></td></tr>
						<tr><td>Lignes au total</td><td style="text-align:right"><?= (int) ( $r['lignes'] ?? 0 ) ?></td></tr>
						<tr><td>Total mouvementé</td><td style="text-align:right"><?= $fmt( $r['total_debit'] ?? 0 ) ?></td></tr>
						<?php if ( ! empty( $r['comptes_a_creer'] ) ) : ?><tr><td>Comptes à créer</td><td style="text-align:right"><?= (int) $r['comptes_a_creer'] ?></td></tr><?php endif; ?>
					</tbody></table>
				<?php else : ?>
					<table class="table"><tbody>
						<tr><td>Comptes à créer</td><td style="text-align:right"><strong><?= (int) ( $r['crees'] ?? 0 ) ?></strong></td></tr>
						<tr><td>Déjà présents</td><td style="text-align:right"><?= (int) ( $r['existants'] ?? 0 ) ?></td></tr>
					</tbody></table>
				<?php endif; ?>

				<?php if ( ! empty( $r['doublon'] ) ) : ?>
					<div class="alert alert-warn" style="margin-top:12px">⚠️ Cette reprise semble <strong>déjà avoir été importée</strong> (même date et mêmes montants). Vous pouvez forcer un nouvel import si c'est volontaire.</div>
				<?php endif; ?>

				<?php if ( $anos ) : ?>
					<div class="alert alert-err" style="margin-top:12px"><strong>À corriger avant de continuer :</strong></div>
					<ul style="margin:0;padding-left:18px">
						<?php foreach ( array_slice( $anos, 0, 40 ) as $a ) : ?><li class="muted" style="margin:4px 0"><?= e( $a ) ?></li><?php endforeach; ?>
						<?php if ( count( $anos ) > 40 ) : ?><li class="muted">… et <?= count( $anos ) - 40 ?> autre(s).</li><?php endif; ?>
					</ul>
				<?php endif; ?>

				<div style="margin-top:16px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
					<?php if ( $peut_confirmer ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/migration/confirmer' ) ) ?>" style="display:inline">
							<?= FKC_Csrf::field() ?>
							<button class="btn btn-primary" type="submit" onclick="return confirm('Confirmer l\'enregistrement de cette reprise en comptabilité ?');">✓ Confirmer et enregistrer</button>
						</form>
					<?php elseif ( ! empty( $r['doublon'] ) ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/migration/confirmer' ) ) ?>" style="display:inline">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="forcer_doublon" value="1">
							<button class="btn btn-primary" type="submit" onclick="return confirm('Forcer un nouvel import malgré le doublon détecté ?');">Forcer le ré-import</button>
						</form>
					<?php endif; ?>
					<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/migration' ) ) ?>">Recommencer</a>
				</div>
			</div>
		</div>
	<?php endif; ?>
<?php endif; ?>

<?php /* ══ FORMULAIRE (masqué juste après une exécution réussie) ══ */ ?>
<?php if ( ! ( $apres_execution && $r && ! empty( $r['ok'] ) ) ) : ?>
<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>1 · Type d'import</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/migration/apercu' ) ) ?>" enctype="multipart/form-data" id="migform">
			<?= FKC_Csrf::field() ?>
			<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px">
				<label class="fld-check" style="align-items:flex-start;margin:0">
					<input type="radio" name="type" value="balance" <?= 'balance' === $type ? 'checked' : '' ?> style="margin-top:3px">
					<span><strong>Balance de reprise</strong> — le cas le plus courant. Génère l'écriture de reprise à partir des soldes de comptes.</span>
				</label>
				<label class="fld-check" style="align-items:flex-start;margin:0">
					<input type="radio" name="type" value="ecritures" <?= 'ecritures' === $type ? 'checked' : '' ?> style="margin-top:3px">
					<span><strong>Écritures détaillées</strong> — reprend le journal ligne à ligne (pour conserver le détail de l'exercice).</span>
				</label>
				<label class="fld-check" style="align-items:flex-start;margin:0">
					<input type="radio" name="type" value="plan" <?= 'plan' === $type ? 'checked' : '' ?> style="margin-top:3px">
					<span><strong>Plan comptable seul</strong> — importe uniquement la liste des comptes personnalisés.</span>
				</label>
			</div>

			<div class="card-head" style="padding-left:0"><h2>2 · Options de reprise</h2></div>
			<div id="opts-balance" style="margin:12px 0">
				<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:12px">
					<label class="fld-check" style="align-items:flex-start;margin:0;flex:1;min-width:240px">
						<input type="radio" name="mode" value="anouveaux" <?= 'complete' === ( $opts['mode'] ?? '' ) ? '' : 'checked' ?> style="margin-top:3px">
						<span><strong>Ouverture d'exercice</strong> (à-nouveaux) — reprise au 1er jour. Seuls les comptes de bilan sont repris.</span>
					</label>
					<label class="fld-check" style="align-items:flex-start;margin:0;flex:1;min-width:240px">
						<input type="radio" name="mode" value="complete" <?= 'complete' === ( $opts['mode'] ?? '' ) ? 'checked' : '' ?> style="margin-top:3px">
						<span><strong>En cours d'exercice</strong> (après T1, S1…) — reprend aussi les charges et produits déjà réalisés, avec le résultat de la période.</span>
					</label>
				</div>
				<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:end">
					<label class="fld" style="margin:0"><span>Date de reprise</span><input type="date" name="date" value="<?= e( $opts['date'] ?? date( 'Y-m-d' ) ) ?>"></label>
					<label class="fld opt-complete" style="margin:0"><span>Début d'exercice</span><input type="date" name="debut_exercice" value="<?= e( $opts['debut_exercice'] ?? ( date( 'Y' ) . '-01-01' ) ) ?>"></label>
					<label class="fld opt-complete" style="margin:0"><span>Compte de résultat</span><input name="compte_resultat" value="<?= e( $opts['compte_resultat'] ?? '130000' ) ?>" style="width:120px"></label>
					<label class="fld" style="margin:0"><span>Journal</span><input name="journal" value="<?= e( $opts['journal'] ?? 'OD' ) ?>" style="width:80px"></label>
				</div>
			</div>
			<label class="fld-check" style="margin:12px 0">
				<input type="checkbox" name="creer_comptes" value="1" <?= empty( $opts['creer_comptes'] ) ? '' : 'checked' ?>>
				<span>Créer automatiquement les comptes absents du plan comptable</span>
			</label>

			<div class="card-head" style="padding-left:0"><h2>3 · Fichier CSV</h2></div>
			<div style="display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin-top:12px">
				<label class="fld" style="margin:0"><span>Fichier exporté de votre ancien logiciel</span>
					<input type="file" name="fichier" accept=".csv,text/csv,text/plain" required></label>
				<button class="btn btn-primary" type="submit">Analyser (aperçu)</button>
			</div>
			<p class="help" style="margin-bottom:0">Formats reconnus automatiquement : séparateur <code>;</code> <code>,</code> ou tabulation, entêtes français ou anglais (Compte/Account, Débit/Debit…), montants « 1 234,56 » ou « 1,234.56 », dates JJ/MM/AAAA ou AAAA-MM-JJ. Colonnes attendues : pour une balance <strong>compte ; libellé ; débit ; crédit</strong> ; pour des écritures <strong>date ; journal ; pièce ; compte ; libellé ; débit ; crédit</strong> ; pour un plan <strong>numéro ; libellé</strong>.</p>
		</form>
	</div>
</div>
<script>
(function(){
	var form=document.getElementById('migform'); if(!form)return;
	function sync(){
		var type=(form.querySelector('input[name=type]:checked')||{}).value||'balance';
		var mode=(form.querySelector('input[name=mode]:checked')||{}).value||'anouveaux';
		form.querySelector('#opts-balance').style.display=(type==='balance')?'':'none';
		form.querySelectorAll('.opt-complete').forEach(function(el){ el.style.display=(type==='balance'&&mode==='complete')?'':'none'; });
	}
	form.addEventListener('change',sync); sync();
})();
</script>
<?php endif; ?>
