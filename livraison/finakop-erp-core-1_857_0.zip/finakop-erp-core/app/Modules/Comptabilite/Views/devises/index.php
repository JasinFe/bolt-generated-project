<?php
/**
 * Cours de change.
 *
 * @var string $pivot @var array $catalogue @var array $historique
 * @var string $filtre @var array $utilisees @var string $tab @var array|null $flash
 * @var array $fournisseurs @var string $source @var bool $xe_ok @var string|null $derniere_maj @var array|null $auto
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( $flash['type'] ?? 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<span class="muted">Comptes tenus en <strong><?= e( $pivot ) ?></strong></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/devises/revalorisation' ) ) ?>" style="margin-left:auto">Revalorisation de clôture →</a>
</div>

<?php if ( $utilisees ) : ?>
<div class="alert alert-info">
	Devises présentes dans vos écritures : <strong><?= e( implode( ', ', $utilisees ) ) ?></strong>.
	Un cours de clôture est nécessaire pour chacune afin de pouvoir revaloriser.
</div>
<?php endif; ?>

<?php
/* ── Source des cours ─────────────────────────────────────────────────────
   Le convertisseur public de xe.com est une interface humaine : la moissonner
   revient à lire du HTML dont la structure change sans préavis, et sort du cadre
   d'utilisation du site. Xe publie pour cela une API dédiée, sur abonnement —
   c'est elle qui est intégrée, avec vos identifiants. Une source ouverte est
   proposée en repli pour qui n'a pas d'abonnement. */
$fournisseurs = $fournisseurs ?? array();
$source = $source ?? 'manuel';
$xe_ok  = ! empty( $xe_ok );
?>
<?php if ( ! empty( $auto ) && ! empty( $auto['message'] ) ) : ?>
	<div class="alert alert-<?= $auto['ok'] ? 'ok' : 'warn' ?>"><?= e( $auto['message'] ) ?></div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Source des cours</h2>
		<?php if ( ! empty( $derniere_maj ) ) : ?>
			<span class="muted" style="margin-left:auto">dernière récupération : <?= e( $derniere_maj ) ?></span>
		<?php endif; ?>
	</div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/devises/source' ) ) ?>" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="min-width:280px"><span>Fournisseur</span>
				<select name="fournisseur">
					<?php foreach ( $fournisseurs as $code => $f ) : ?>
						<option value="<?= e( $code ) ?>"<?= $code === $source ? ' selected' : '' ?>><?= e( $f['label'] ) ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<button class="btn btn-ghost btn-sm">Appliquer</button>
		</form>
		<p class="help" style="margin-top:8px"><?= e( $fournisseurs[ $source ]['aide'] ?? '' ) ?></p>

		<?php if ( 'xe' === $source ) : ?>
			<div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)">
				<?php if ( $xe_ok ) : ?>
					<p class="help" style="margin-top:0"><strong style="color:#0a7f3f">✔ Identifiants Xe enregistrés</strong> — conservés chiffrés dans le coffre à secrets.</p>
					<form method="post" action="<?= e( url( 'comptabilite/devises/identifiants' ) ) ?>">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="oublier" value="1">
						<button class="btn btn-ghost btn-sm">Supprimer les identifiants</button>
					</form>
				<?php else : ?>
					<form method="post" action="<?= e( url( 'comptabilite/devises/identifiants' ) ) ?>" class="grid-form">
						<?= FKC_Csrf::field() ?>
						<label class="fld"><span>Identifiant de compte Xe</span><input type="text" name="account_id" autocomplete="off" required></label>
						<label class="fld"><span>Clé d'API</span><input type="password" name="api_key" autocomplete="new-password" required></label>
						<div style="grid-column:1/-1"><button class="btn btn-primary btn-sm">Enregistrer les identifiants</button></div>
					</form>
					<p class="help">Ils sont chiffrés avant écriture et ne sont jamais réaffichés.</p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( 'manuel' !== $source ) : ?>
			<div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)">
				<form method="post" action="<?= e( url( 'comptabilite/devises/recuperer' ) ) ?>" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
					<?= FKC_Csrf::field() ?>
					<label class="fld"><span>Date d'application</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
					<label style="display:flex;gap:6px;align-items:center;padding-bottom:8px">
						<input type="checkbox" name="ecraser" value="1"> <span class="muted">écraser un cours saisi à la main</span>
					</label>
					<button class="btn btn-primary btn-sm">Récupérer les cours maintenant</button>
				</form>
				<p class="help" style="margin-top:8px">
					Les <strong>parités fixes</strong> ne sont jamais interrogées : l'euro est arrimé au franc CFA par accord
					de coopération monétaire, ce n'est pas un cours de marché. Un cours que vous avez saisi vous-même
					n'est pas écrasé sans que vous le demandiez.
				</p>
				<p class="help">
					<strong>Pour une clôture, restez prudent.</strong> Un agrégateur donne un cours moyen de marché, qui n'est
					ni celui de l'administration fiscale ni celui que votre banque vous appliquera. Le cours de la BCEAO ou
					l'avis de votre banque font foi. Cette récupération sert le quotidien — convertir un relevé de royalties,
					valoriser une commande — pas à décider seule d'une revalorisation de bilan.
				</p>
			</div>
		<?php endif; ?>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Enregistrer un cours</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/devises/enregistrer' ) ) ?>" class="grid-form">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Devise</span>
				<select name="devise" required>
					<option value="">—</option>
					<?php foreach ( $catalogue as $code => $lib ) :
						if ( $code === $pivot ) { continue; }
						$fixe = FKC_Devise::pariteFixe( $code, $pivot ); ?>
						<option value="<?= e( $code ) ?>"<?= $fixe ? ' disabled' : '' ?>>
							<?= e( $code ) ?> — <?= e( $lib ) ?><?= $fixe ? ' (parité fixe : ' . $fixe . ')' : '' ?>
						</option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Cours — combien de <?= e( $pivot ) ?> pour 1 unité</span>
				<input type="text" name="taux" inputmode="decimal" placeholder="605,50" required>
			</label>
			<label class="fld"><span>Date du cours</span>
				<input type="date" name="date_taux" value="<?= e( date( 'Y-m-d' ) ) ?>" required>
			</label>
			<label class="fld"><span>Source</span>
				<select name="source">
					<option value="BCEAO">BCEAO</option>
					<option value="banque">Cours de la banque</option>
					<option value="moyen mensuel">Cours moyen mensuel</option>
					<option value="manuel">Saisie manuelle</option>
				</select>
			</label>
			<label class="fld" style="grid-column:1/-1"><span>Note (facultative)</span>
				<input type="text" name="note" placeholder="Référence de l'avis de cours, du relevé bancaire…">
			</label>
			<div style="grid-column:1/-1"><button class="btn btn-primary">Enregistrer le cours</button></div>
		</form>
		<p class="help" style="margin-top:10px">
			Le cours retenu pour une opération est le plus récent <strong>à sa date ou avant</strong> :
			un cours postérieur n'est jamais appliqué rétroactivement, il reviendrait à comptabiliser
			avec une information dont on ne disposait pas.
		</p>
		<p class="help">
			Les parités fixes ne se saisissent pas : l'euro est arrimé au franc CFA par accord de
			coopération monétaire à <strong>655,957</strong>. Ce n'est pas un cours de marché.
		</p>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Cours enregistrés</h2>
		<?php if ( $filtre ) : ?>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/devises' ) ) ?>" style="margin-left:auto">Tous les cours</a>
		<?php endif; ?>
	</div>
	<div class="card-body">
		<?php if ( ! $historique ) : ?>
			<p class="muted">Aucun cours enregistré.</p>
		<?php else : ?>
		<table class="table">
			<thead><tr><th>Date</th><th>Devise</th><th class="num">Cours</th><th>Source</th><th>Note</th></tr></thead>
			<tbody>
			<?php foreach ( $historique as $h ) : ?>
				<tr>
					<td><?= e( $h['date_taux'] ) ?></td>
					<td><a href="<?= e( url( 'comptabilite/devises?devise=' . urlencode( $h['devise'] ) ) ) ?>"><?= e( $h['devise'] ) ?></a> / <?= e( $h['pivot'] ) ?></td>
					<td class="num"><?= e( rtrim( rtrim( number_format( (float) $h['taux'], 6, ',', ' ' ), '0' ), ',' ) ) ?></td>
					<td><?= e( $h['source'] ?? '' ) ?></td>
					<td class="muted"><?= e( $h['note'] ?? '' ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
	</div>
</div>
