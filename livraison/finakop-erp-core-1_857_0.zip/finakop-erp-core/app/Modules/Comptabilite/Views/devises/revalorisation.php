<?php /** @var string $title @var string $tab @var string $date @var array $apercu @var array $historique @var mixed $flash */
/**
 * Revalorisation de clôture.
 *
 * L'aperçu chiffré précède toujours l'action : cette écriture modifie le bilan
 * sur la seule base d'un cours de clôture.
 *
 * @var string $date @var array $apercu @var array $historique
 * @var string $tab @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ap = $apercu;
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( $flash['type'] ?? 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<form method="get" action="<?= e( url( 'comptabilite/devises/revalorisation' ) ) ?>" style="display:flex;gap:8px;align-items:center">
		<label class="muted">Date de clôture</label>
		<input type="date" name="date" value="<?= e( $date ) ?>">
		<button class="btn btn-ghost btn-sm">Recalculer l'aperçu</button>
	</form>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/devises' ) ) ?>" style="margin-left:auto">← Cours de change</a>
</div>

<div class="alert alert-info">
	<strong>Deux traitements distincts, et c'est la règle SYSCOHADA.</strong>
	Les <strong>créances et dettes</strong> en devises donnent un écart <em>latent</em> : il passe par les comptes
	d'écart de conversion 478/479 et doit être <strong>extourné à l'ouverture</strong> de l'exercice suivant.
	Les <strong>disponibilités</strong> (banque, caisse) donnent un écart tenu pour <em>réalisé</em> : il va
	directement au résultat en 676/776, sans extourne — il n'y a pas d'incertitude sur une encaisse.
	Les immobilisations et les stocks ne se revalorisent pas : ils restent au coût historique.
</div>

<?php if ( ! empty( $ap['sans_taux'] ) ) : ?>
<div class="alert alert-err">
	<strong>Cours de clôture manquant</strong> pour <?= e( implode( ', ', $ap['sans_taux'] ) ) ?>.
	Saisissez-les au <?= e( $date ) ?> avant de revaloriser : une revalorisation partielle donnerait un bilan faux.
</div>
<?php endif; ?>

<?php if ( ! empty( $ap['non_tracees'] ) ) : ?>
<div class="alert alert-warn">
	<?= (int) $ap['non_tracees'] ?> ligne(s) en devise sans montant d'origine ni cours enregistré.
	Elles ne peuvent pas être revalorisées — elles proviennent d'écritures antérieures à la traçabilité devise.
</div>
<?php endif; ?>

<div class="cards-row">
	<div class="card"><div class="card-body an-kpi">
		<span class="l">Perte latente</span><span class="v"><?= e( fkc_money( $ap['perte_latente'] ) ) ?></span>
		<span class="help">créances / dettes → 4781, 4782 · extournée</span>
	</div></div>
	<div class="card"><div class="card-body an-kpi">
		<span class="l">Gain latent</span><span class="v"><?= e( fkc_money( $ap['gain_latent'] ) ) ?></span>
		<span class="help">créances / dettes → 4791, 4792 · extourné</span>
	</div></div>
	<div class="card"><div class="card-body an-kpi">
		<span class="l">Perte réalisée</span><span class="v"><?= e( fkc_money( $ap['perte_realisee'] ) ) ?></span>
		<span class="help">disponibilités → 676 · définitive</span>
	</div></div>
	<div class="card"><div class="card-body an-kpi">
		<span class="l">Gain réalisé</span><span class="v"><?= e( fkc_money( $ap['gain_realise'] ) ) ?></span>
		<span class="help">disponibilités → 776 · définitif</span>
	</div></div>
</div>

<?php if ( $ap['provision_a_examiner'] > 0 ) : ?>
<div class="alert alert-warn">
	<strong>Provision pour perte de change à examiner : <?= e( fkc_money( $ap['provision_a_examiner'] ) ) ?>.</strong>
	La prudence impose de provisionner une perte probable, alors qu'un gain latent ne se comptabilise pas en résultat.
	<strong>Cette provision n'est pas passée automatiquement</strong> : son caractère probable et son montant relèvent
	d'une appréciation professionnelle, pas d'un calcul. À constater le cas échéant au compte 194.
</div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Positions au <?= e( $date ) ?></h2></div>
	<div class="card-body">
		<?php if ( empty( $ap['positions'] ) ) : ?>
			<p class="muted">Aucune position en devises à revaloriser à cette date.</p>
		<?php else : ?>
		<table class="table">
			<thead><tr>
				<th>Compte</th><th>Devise</th><th>Nature</th>
				<th class="num">Solde en devise</th><th class="num">Cours</th>
				<th class="num">Valeur comptable</th><th class="num">Valeur au cours</th>
				<th class="num">Écart</th><th>Traitement</th>
			</tr></thead>
			<tbody>
			<?php foreach ( $ap['positions'] as $p ) :
				$natures = array( 'creance' => 'Créance', 'dette' => 'Dette', 'disponibilite' => 'Disponibilité' );
				$perte = ( (float) $p['ecart'] < 0 );
				if ( $p['latent'] ) {
					$cpt = ( 'creance' === $p['nature'] ) ? ( $perte ? '4781' : '4791' ) : ( $perte ? '4782' : '4792' );
					$traitement = $cpt . ' · ' . ( $perte ? 'perte latente' : 'gain latent' ) . ' · extourné';
				} else {
					$traitement = ( $perte ? '676' : '776' ) . ' · ' . ( $perte ? 'perte' : 'gain' ) . ' réalisé · définitif';
				}
			?>
				<tr>
					<td><strong><?= e( $p['compte_numero'] ) ?></strong> <span class="muted"><?= e( $p['compte_libelle'] ) ?></span></td>
					<td><?= e( $p['devise'] ) ?></td>
					<td><?= e( $natures[ $p['nature'] ] ?? $p['nature'] ) ?></td>
					<td class="num"><?= e( number_format( (float) $p['montant_devise'], FKC_Devise::decimales( $p['devise'] ), ',', ' ' ) ) ?></td>
					<td class="num"><?= e( rtrim( rtrim( number_format( (float) $p['taux_cloture'], 6, ',', ' ' ), '0' ), ',' ) ) ?></td>
					<td class="num"><?= e( fkc_money( $p['valeur_comptable'] ) ) ?></td>
					<td class="num"><?= e( fkc_money( $p['valeur_cloture'] ) ) ?></td>
					<td class="num" style="color:<?= $perte ? '#b32d2e' : '#0a7f3f' ?>">
						<?= $perte ? '' : '+' ?><?= e( fkc_money( $p['ecart'] ) ) ?>
					</td>
					<td class="muted"><?= e( $traitement ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
	</div>
</div>

<?php if ( ! empty( $ap['positions'] ) && empty( $ap['sans_taux'] ) ) : ?>
<div class="card">
	<div class="card-head"><h2>Comptabiliser</h2></div>
	<div class="card-body">
		<?php if ( $ap['deja_fait'] ) : ?>
			<p>Une revalorisation existe déjà au <?= e( $date ) ?> — écriture n°<?= (int) $ap['deja_fait'] ?>.</p>
			<form method="post" action="<?= e( url( 'comptabilite/devises/extourner' ) ) ?>"
				onsubmit="return confirm('Extourner les écarts de conversion latents ?\n\nLes écarts réalisés sur disponibilités ne sont pas extournés : ils sont définitifs.')">
				<?= FKC_Csrf::field() ?>
				<input type="hidden" name="date" value="<?= e( $date ) ?>">
				<label class="fld" style="max-width:260px"><span>Date d'extourne</span>
					<input type="date" name="date_ouverture" value="<?= e( date( 'Y-m-d', strtotime( $date . ' +1 day' ) ) ) ?>">
				</label>
				<button class="btn btn-primary btn-sm">Extourner les écarts latents à l'ouverture</button>
			</form>
			<p class="help" style="margin-top:8px">
				L'extourne est <strong>obligatoire</strong> : les comptes 478/479 photographient une situation
				à une date précise. Les laisser courir ferait porter à l'exercice suivant une valorisation périmée.
			</p>
		<?php else : ?>
			<form method="post" action="<?= e( url( 'comptabilite/devises/passer-revalorisation' ) ) ?>"
				onsubmit="return confirm('Comptabiliser la revalorisation au <?= e( $date ) ?> ?\n\nElle modifie la valeur des postes en devises au bilan.')">
				<?= FKC_Csrf::field() ?>
				<input type="hidden" name="date" value="<?= e( $date ) ?>">
				<button class="btn btn-primary">Comptabiliser la revalorisation au <?= e( $date ) ?></button>
			</form>
			<p class="help" style="margin-top:8px">
				Si le brouillard est actif, l'écriture y sera déposée pour vérification avant comptabilisation définitive.
			</p>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

<?php if ( $historique ) : ?>
<div class="card">
	<div class="card-head"><h2>Historique des revalorisations</h2></div>
	<div class="card-body">
		<table class="table">
			<thead><tr><th>Clôture</th><th>Compte</th><th>Devise</th><th class="num">Cours</th><th>Nature</th><th class="num">Écart</th><th>Écriture</th><th>Extourne</th></tr></thead>
			<tbody>
			<?php foreach ( $historique as $h ) : ?>
				<tr>
					<td><?= e( $h['date_cloture'] ) ?></td>
					<td><?= e( $h['compte_numero'] ?? '—' ) ?></td>
					<td><?= e( $h['devise'] ) ?></td>
					<td class="num"><?= e( rtrim( rtrim( number_format( (float) $h['taux_cloture'], 6, ',', ' ' ), '0' ), ',' ) ) ?></td>
					<td><?= e( $h['nature'] ) ?></td>
					<td class="num"><?= e( fkc_money( $h['ecart'] ) ) ?></td>
					<td><?= $h['ecriture_id'] ? 'n°' . (int) $h['ecriture_id'] : '—' ?></td>
					<td><?= $h['extourne_id'] ? 'n°' . (int) $h['extourne_id'] : '<span class="muted">à faire</span>' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endif; ?>
