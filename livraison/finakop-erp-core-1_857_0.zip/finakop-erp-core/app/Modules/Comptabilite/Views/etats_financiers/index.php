<?php /** @var int $annee @var array $annees @var string $systeme @var string $systeme_dossier @var array|null $societe @var array $entete
 * @var array $controle @var array $synthese @var array $bilan @var array $cr @var array $crsn @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f  = function ( $v ) { return fkc_money( (float) $v ); };
$fz = function ( $v ) use ( $f ) { return abs( (float) $v ) < 0.004 ? '' : $f( $v ); };
$sn = ( 'sn' === $systeme );
$sysLabel = $sn ? 'Système Normal (SN)' : 'Système Minimal de Trésorerie (SMT)';
$lien = function ( $sys, $an ) { return url( 'comptabilite/etats-financiers?systeme=' . $sys . '&annee=' . $an ); };
$dgi  = function ( $vue ) use ( $systeme, $annee ) { return url( 'comptabilite/etats-dgi?systeme=' . $systeme . '&vue=' . $vue . '&annee=' . $annee ); };
$exp  = function ( $quoi ) use ( $systeme, $annee ) { return url( 'comptabilite/etats-dgi/export?systeme=' . $systeme . '&quoi=' . $quoi . '&annee=' . $annee ); };
$mention = FKC_EtatsDgi::mention( $controle );
$ecart = (float) $bilan['total_actif']['n'] - (float) $bilan['total_passif']['n']; ?>

<?php FKC_View::partial( 'comptabilite::_etats_style' ); ?>
<?php FKC_View::partial( 'comptabilite::_etat_entete', array(
	'etat' => 'États financiers de synthèse — ' . ( $sn ? 'SN' : 'SMT' ),
	'periode' => 'Exercice ' . $entete['libelle'] . ' (clos le ' . $entete['cloture'] . ')',
	'note' => 'Durée : ' . $entete['duree'] . ' mois',
) ); ?>

<?php FKC_View::partial( 'comptabilite::_etats_controle', array( 'controle' => $controle ) ); ?>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="note-flash <?= 'ok' === ( $flash['type'] ?? 'ok' ) ? 'ok' : 'ko' ?>" style="margin:0 0 14px"><?= e( $flash['msg'] ?? '' ) ?></div>
<?php endif; ?>

<div class="ef-head">
	<div class="ef-title">📑 <span>États financiers</span> — <?= e( $sysLabel ) ?></div>
	<div class="ef-exports">
		<?php if ( '' !== $mention ) : ?><span class="ef-mention <?= empty( $controle['coherent'] ) ? 'ko' : '' ?>"><?= e( $mention ) ?></span><?php endif; ?>
		<?php /* Les exports sont ceux de la liasse — mêmes chiffres, même mention
		         PROVISOIRE / NON CONFORME, même barrage. L'ancien bouton « CSV »
		         exportait la BALANCE GÉNÉRALE sous ce nom. */ ?>
		<a class="btn btn-ghost btn-sm" href="<?= e( $exp( 'bilan' ) ) ?>">⬇ Bilan CSV</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( $exp( 'resultat' ) ) ?>">⬇ Résultat CSV</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( $dgi( 'bilan' ) ) ?>">🏛 Liasse DGI complète</a>
		<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/etats-dgi/imprimer?systeme=' . $systeme . '&annee=' . $annee ) ) ?>" target="_blank" rel="noopener">🖨 Imprimer / PDF</a>
	</div>
</div>

<div class="ef-years">
	<?php foreach ( array_slice( $annees, 0, 6 ) as $yy ) : $yy = (int) $yy; ?>
		<a class="ef-pill <?= $yy === (int) $annee ? 'on' : '' ?>" href="<?= e( $lien( $systeme, $yy ) ) ?>"><?= $yy ?></a>
	<?php endforeach; ?>
	<div class="sys-tabs" style="margin:0 0 0 8px">
		<a class="sys-tab <?= ! $sn ? 'on' : '' ?>" href="<?= e( $lien( 'smt', $annee ) ) ?>">SMT</a>
		<a class="sys-tab <?= $sn ? 'on' : '' ?>" href="<?= e( $lien( 'sn', $annee ) ) ?>">SN</a>
	</div>
	<?php if ( $systeme !== $systeme_dossier ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/etats-dgi/systeme' ) ) ?>" class="inline">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="systeme" value="<?= e( $systeme ) ?>"><input type="hidden" name="annee" value="<?= (int) $annee ?>"><input type="hidden" name="retour" value="etats-financiers">
			<button type="submit" class="btn btn-ghost btn-sm" title="Ouvrir désormais les états sur ce système">★ Définir comme système du dossier</button>
		</form>
	<?php endif; ?>
	<span class="ef-period">Exercice <strong><?= e( $entete['libelle'] ) ?></strong> — <span class="ok"><?= (int) $entete['duree'] ?> mois</span> · du <?= e( $entete['ouvert'] ) ?> au <?= e( $entete['cloture'] ) ?></span>
</div>

<?php FKC_View::partial( 'comptabilite::_etats_kpi', array( 'synthese' => $synthese, 'systeme' => $systeme ) ); ?>

<div class="ef-entete">
	<div><span class="el">Dénomination sociale</span><div class="ev <?= '—' === $entete['societe'] ? 'vide' : '' ?>"><?= '—' === $entete['societe'] ? 'Non renseignée — Paramètres › Société' : e( $entete['societe'] ) ?></div></div>
	<div><span class="el">NCC</span><div class="ev <?= $entete['ncc'] ? '' : 'vide' ?>"><?= e( $entete['ncc'] ?: 'Non renseigné' ) ?></div></div>
	<div><span class="el">N° télédéclarant</span><div class="ev <?= $entete['ntd'] ? '' : 'vide' ?>"><?= e( $entete['ntd'] ?: 'Non renseigné' ) ?></div></div>
	<div><span class="el">Exercice clos le</span><div class="ev"><?= e( $entete['cloture'] ) ?></div></div>
</div>

<!-- ───────── BILAN ───────── -->
<div class="ef-card">
	<div class="ef-band">Bilan — <?= e( $sysLabel ) ?> — au <?= e( $entete['cloture'] ) ?></div>
	<?php if ( $sn ) : ?>
	<div class="sn-bilan">
		<div class="ef-scroll"><table class="table ef-tbl">
			<thead><tr><th class="th-cote" colspan="5">ACTIF</th></tr>
				<tr><th>Réf</th><th>Actif</th><th class="ctr">Note</th><th class="num">Net N</th><th class="num">Net N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $bilan['actif'] as $l ) : $t = $l['type']; ?>
				<tr class="<?= 'grand' === $t ? 'grand' : ( 'total' === $t ? 'total' : ( 'sub' === $t ? 'subtotal' : '' ) ) ?>">
					<td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num val"><?= e( $fz( $l['net'] ) ) ?></td><td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<div class="ef-scroll"><table class="table ef-tbl">
			<thead><tr><th class="th-cote" colspan="5">PASSIF</th></tr>
				<tr><th>Réf</th><th>Passif</th><th class="ctr">Note</th><th class="num">Net N</th><th class="num">Net N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $bilan['passif'] as $l ) : $t = $l['type']; $isRes = ( 'CJ' === $l['code'] ); ?>
				<tr class="<?= 'grand' === $t ? 'grand' : ( 'total' === $t ? 'total' : ( 'sub' === $t ? 'subtotal' : '' ) ) ?>">
					<td class="code"><?= e( $l['code'] ) ?></td>
					<td><?= e( $l['libelle'] ) ?><?php if ( $isRes && abs( (float) $l['net'] ) >= 0.004 ) : ?><span class="tag <?= (float) $l['net'] >= 0 ? 'pos' : 'neg' ?>"><?= (float) $l['net'] >= 0 ? 'bénéfice' : 'perte' ?></span><?php endif; ?></td>
					<td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num <?= $isRes ? ( (float) $l['net'] >= 0 ? 'pos' : 'neg' ) : 'val' ?>"><?= e( $fz( $l['net'] ) ) ?></td><td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
	</div>
	<?php else : ?>
	<div class="ef-bilan">
		<div class="ef-scroll"><table class="table ef-tbl">
			<thead><tr><th class="th-cote" colspan="5">ACTIF</th></tr>
				<tr><th>Réf</th><th>Actif</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $bilan['actif'] as $l ) : ?>
				<tr><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num val <?= (float) $l['n'] < 0 ? 'neg' : '' ?>"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot><tr class="total"><td class="code">GZ</td><td>TOTAL ACTIF</td><td></td><td class="num"><?= e( $f( $bilan['total_actif']['n'] ) ) ?></td><td class="num"><?= e( $f( $bilan['total_actif']['n1'] ) ) ?></td></tr></tfoot>
		</table></div>
		<div class="ef-scroll"><table class="table ef-tbl">
			<thead><tr><th class="th-cote" colspan="5">PASSIF</th></tr>
				<tr><th>Réf</th><th>Passif</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $bilan['passif'] as $l ) : $isRes = ( 'HB' === $l['code'] ); ?>
				<tr><td class="code"><?= e( $l['code'] ) ?></td>
					<td><?= e( $l['libelle'] ) ?><?php if ( $isRes && abs( (float) $l['n'] ) >= 0.004 ) : ?><span class="tag <?= (float) $l['n'] >= 0 ? 'pos' : 'neg' ?>"><?= (float) $l['n'] >= 0 ? 'bénéfice' : 'perte' ?></span><?php endif; ?></td>
					<td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num <?= $isRes ? ( (float) $l['n'] >= 0 ? 'pos' : 'neg' ) : 'val' ?>"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot><tr class="total"><td class="code">HZ</td><td>TOTAL PASSIF</td><td></td><td class="num"><?= e( $f( $bilan['total_passif']['n'] ) ) ?></td><td class="num"><?= e( $f( $bilan['total_passif']['n1'] ) ) ?></td></tr></tfoot>
		</table></div>
	</div>
	<?php endif; ?>
	<?php if ( $bilan['equilibre'] ) : ?>
		<div class="ef-eqbar ok">✓ Bilan équilibré — Total actif = Total passif = <?= e( $f( $bilan['total_actif']['n'] ) ) ?> F CFA</div>
	<?php else : ?>
		<div class="ef-eqbar ko">⚠️ Bilan non équilibré — Actif : <?= e( $f( $bilan['total_actif']['n'] ) ) ?> F CFA / Passif : <?= e( $f( $bilan['total_passif']['n'] ) ) ?> F CFA. Écart de <?= e( $f( abs( $ecart ) ) ) ?> F CFA — vérifiez les capitaux propres (10x), les à-nouveaux et l'imputation du résultat.</div>
	<?php endif; ?>
</div>

<!-- ───────── COMPTE DE RÉSULTAT ───────── -->
<div class="ef-card">
	<div class="ef-band">Compte de résultat — <?= e( $sysLabel ) ?> — exercice <?= e( $entete['libelle'] ) ?></div>
	<div class="ef-scroll">
	<?php if ( $sn ) : ?>
		<table class="table ef-tbl">
			<thead><tr><th>Réf</th><th>Libellés</th><th class="ctr">Signe</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $crsn['lignes'] as $l ) : $t = $l['type']; ?>
				<tr class="<?= 'g' === $t ? 'grand' : ( 's' === $t ? 'subtotal' : '' ) ?>">
					<td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td>
					<td class="ctr sgn"><?= e( $l['signe'] ) ?></td><td class="note"><?= e( $l['note'] ) ?></td>
					<td class="num <?= 'g' === $t ? ( (float) $l['n'] >= 0 ? 'pos' : 'neg' ) : ( 's' === $t ? '' : 'val' ) ?>"><?= e( $fz( $l['n'] ) ) ?></td>
					<td class="num muted"><?= e( $fz( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<table class="table ef-tbl">
			<thead><tr><th>Réf</th><th>Libellés</th><th class="ctr">Note</th><th class="num">Exercice N</th><th class="num">N-1</th></tr></thead>
			<tbody>
			<?php foreach ( $cr['produits'] as $l ) : ?>
				<tr class="<?= ! empty( $l['bold'] ) ? 'subtotal' : '' ?>"><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= empty( $l['bold'] ) ? '7' : '' ?></td>
					<td class="num <?= empty( $l['bold'] ) ? 'val' : '' ?>"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			<tr class="ef-spacer"><td colspan="5"></td></tr>
			<?php foreach ( $cr['charges'] as $l ) : ?>
				<tr class="<?= ! empty( $l['bold'] ) ? 'subtotal' : '' ?>"><td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="note"><?= empty( $l['bold'] ) ? '7' : '' ?></td>
					<td class="num <?= empty( $l['bold'] ) ? 'val' : '' ?>"><?= e( $f( $l['n'] ) ) ?></td><td class="num muted"><?= e( $f( $l['n1'] ) ) ?></td></tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr class="total"><td class="code"><?= e( $cr['kz']['code'] ) ?></td><td colspan="2"><?= e( $cr['kz']['libelle'] ) ?></td><td class="num"><?= e( $f( $cr['kz']['n'] ) ) ?></td><td class="num muted"><?= e( $f( $cr['kz']['n1'] ) ) ?></td></tr>
				<?php /* Les trois corrections D, E, F manquaient : l'écran affichait
				         C, G et H sans ce qui les relie, et H ≠ C − G à l'œil. */ ?>
				<?php foreach ( $cr['variations'] as $v ) : ?>
					<tr class="corr"><td class="code"><?= e( $v['code'] ) ?></td><td colspan="2"><?= e( $v['libelle'] ) ?></td><td class="num <?= (float) $v['n'] < 0 ? 'neg' : '' ?>"><?= e( $f( $v['n'] ) ) ?></td><td class="num muted"><?= e( $f( $v['n1'] ) ) ?></td></tr>
				<?php endforeach; ?>
				<tr><td class="code"><?= e( $cr['jg']['code'] ) ?></td><td colspan="2"><?= e( $cr['jg']['libelle'] ) ?></td><td class="num"><?= e( $f( $cr['jg']['n'] ) ) ?></td><td class="num muted"><?= e( $f( $cr['jg']['n1'] ) ) ?></td></tr>
				<tr class="grand"><td class="code"><?= e( $cr['kzc']['code'] ) ?></td><td colspan="2"><?= e( $cr['kzc']['libelle'] ) ?></td>
					<td class="num <?= (float) $cr['kzc']['n'] >= 0 ? 'pos' : 'neg' ?>"><?= e( $f( $cr['kzc']['n'] ) ) ?> F CFA</td><td class="num muted"><?= e( $f( $cr['kzc']['n1'] ) ) ?></td></tr>
			</tfoot>
		</table>
	<?php endif; ?>
	</div>
</div>

<p class="ef-foot">Établi selon le <strong><?= e( $sysLabel ) ?></strong> du référentiel <strong>SYSCOHADA révisé</strong>, présentation DGI (références et colonnes N / N-1).
	Les états sont alimentés par les écritures du <strong>grand livre</strong> : celles qui attendent au journal temporaire n'y figurent pas, et le bandeau de contrôle les décompte.
	<?php if ( $sn ) : ?>Tableau des flux, notes annexes et fichier EDI : <a href="<?= e( $dgi( 'flux' ) ) ?>">liasse DGI</a>.<?php else : ?>Notes annexes et fichier EDI : <a href="<?= e( $dgi( 'notes' ) ) ?>">liasse DGI</a>.<?php endif; ?>
	À valider avec votre expert-comptable avant dépôt.</p>
