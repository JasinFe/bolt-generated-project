<?php
/**
 * Bloc « Pièces justificatives » réutilisable.
 * @var array  $pieces        liste des pièces (FKC_PieceJointe::forSource)
 * @var string $piecesUpload  URL d'action du formulaire d'upload (POST multipart)
 * @var string $piecesBase    base des routes pièce : {base}/{id} (téléchargement), {base}/{id}/supprimer
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$pieces = $pieces ?? array();
?>
<div class="card" style="max-width:860px">
	<div class="card-head"><h2>📎 Pièces justificatives <span class="muted">(<?= count( $pieces ) ?>)</span></h2></div>
	<div class="card-body">
		<?php if ( $pieces ) : ?>
		<table class="table bordered">
			<thead><tr><th>Document</th><th>Type</th><th class="num">Taille</th><th>Ajoutée le</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $pieces as $p ) : $isImg = strpos( (string) $p['mime'], 'image/' ) === 0; ?>
				<tr>
					<td><a href="<?= e( url( $piecesBase . '/' . (int) $p['id'] ) ) ?>" target="_blank" rel="noopener"><?= $isImg ? '🖼️' : '📄' ?> <?= e( $p['nom_origine'] ) ?></a></td>
					<td class="muted"><?= e( strtoupper( pathinfo( $p['nom_origine'], PATHINFO_EXTENSION ) ) ) ?></td>
					<td class="num muted"><?= e( FKC_PieceJointe::humanSize( $p['taille'] ) ) ?></td>
					<td class="muted"><?= e( ! empty( $p['created_at'] ) ? date( 'd/m/Y H:i', strtotime( $p['created_at'] ) ) : '—' ) ?></td>
					<td class="num">
						<?php if ( class_exists( 'FKC_GedDocument' ) ) : $retour = preg_replace( '#/pieces$#', '', (string) $piecesUpload ); ?>
						<form method="post" action="<?= e( url( 'ged/promouvoir-piece/' . (int) $p['id'] ) ) ?>" style="display:inline" title="Ajouter à la GED">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="retour" value="<?= e( $retour ) ?>">
							<button class="btn btn-ghost btn-sm" type="submit" title="Ajouter à la bibliothèque GED">→ GED</button>
						</form>
						<?php endif; ?>
						<form method="post" action="<?= e( url( $piecesBase . '/' . (int) $p['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer cette pièce jointe ?');" style="display:inline">
							<?= FKC_Csrf::field() ?>
							<button class="btn btn-ghost btn-sm" type="submit" title="Supprimer">🗑</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php else : ?>
		<p class="help" style="margin-top:0">Aucune pièce jointe. Ajoutez le scan ou le PDF de la facture, du reçu ou de la pièce comptable.</p>
		<?php endif; ?>
		<form method="post" action="<?= e( url( $piecesUpload ) ) ?>" enctype="multipart/form-data" class="bar" style="margin-top:10px;gap:10px">
			<?= FKC_Csrf::field() ?>
			<input type="file" name="piece" accept=".pdf,.jpg,.jpeg,.png,.webp,.gif" required>
			<button class="btn btn-primary btn-sm" type="submit">⬆ Joindre</button>
			<span class="help">PDF ou image (JPG, PNG, WEBP, GIF) — max 8 Mo.</span>
		</form>
	</div>
</div>
