<?php
/**
 * En-tête standard des états comptables.
 * @var string $etat    Nom de l'état (ex. « Balance générale »)
 * @var string|null $periode  Période / exercice (ex. « Exercice 2026 » ou « Du … au … »)
 * @var string|null $note    Mention complémentaire éventuelle
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$soc = FKC_Tenant::current();
$raison = FKC_License::param( 'fne_company_name', '' ) ?: ( $soc['raison_sociale'] ?? '—' );
$ncc    = FKC_License::param( 'fne_ncc', '' ) ?: ( $soc['ncc'] ?? '' );
$sigle  = $soc['sigle'] ?? '';
$now    = date( 'd/m/Y à H:i' );
?>
<div class="etat-entete">
	<div class="ee-left">
		<div class="ee-soc"><?= e( $raison ) ?><?php if ( $sigle ) : ?> <span class="ee-sigle">(<?= e( $sigle ) ?>)</span><?php endif; ?></div>
		<div class="ee-meta">
			<?php if ( $ncc ) : ?><span>NCC : <strong><?= e( $ncc ) ?></strong></span><?php endif; ?>
			<?php if ( ! empty( $periode ) ) : ?><span><?= e( $periode ) ?></span><?php endif; ?>
		</div>
	</div>
	<div class="ee-right">
		<div class="ee-etat"><?= e( $etat ) ?></div>
		<div class="ee-date">Édité le <?= e( $now ) ?></div>
		<?php if ( ! empty( $note ) ) : ?><div class="ee-note"><?= e( $note ) ?></div><?php endif; ?>
	</div>
</div>
<style>
.etat-entete{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;background:linear-gradient(120deg,var(--panel),var(--panel2));border:1px solid var(--line);border-left:3px solid var(--orange);border-radius:12px;padding:13px 18px;margin-bottom:16px}
.etat-entete .ee-soc{font-family:Syne,sans-serif;font-weight:800;font-size:16px}
.etat-entete .ee-sigle{color:var(--muted2);font-weight:600;font-size:13px}
.etat-entete .ee-meta{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:12.5px;margin-top:5px}
.etat-entete .ee-meta strong{color:var(--text)}
.etat-entete .ee-right{text-align:right}
.etat-entete .ee-etat{font-family:Syne,sans-serif;font-weight:800;font-size:15px;color:var(--orange)}
.etat-entete .ee-date{color:var(--muted2);font-size:11.5px;margin-top:4px}
.etat-entete .ee-note{color:var(--muted2);font-size:11.5px}
@media(max-width:700px){.etat-entete .ee-right{text-align:left}}
</style>
