<?php
/** Barre Retour / Fermer du sous-module Immobilisations (retour vers l'accordéon Immobilisations). */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'comptabilite', 'back' => 'comptabilite/menu/immo', 'backLabel' => 'Immobilisations' ) );
