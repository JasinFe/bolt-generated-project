<?php /** @var array $immos @var array|null $flash @var string $tab @var string $statut @var array $compteStatuts @var array $synthese @var array $rapprochement @var float $seuil */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$f = function ( $v ) { return fkc_money( (float) $v ); };
$sy = $synthese ?? array();
$rap = $rapprochement ?? array();
$statut = $statut ?? 'en_service';
$cs = $compteStatuts ?? array();
$filtres = array( 'en_service' => 'En service', 'cede' => 'Cédées', 'annulee' => 'Annulées', 'tous' => 'Toutes' );
$tot = array( 'va' => 0.0, 'cumul' => 0.0, 'vnc' => 0.0 );
foreach ( $immos as $im ) { $tot['va'] += (float) $im['valeur_acquisition']; $tot['cumul'] += (float) $im['cumul']; $tot['vnc'] += (float) $im['vnc']; }
$restant = max( 0.0, (float) ( $sy['dotation_prevue'] ?? 0 ) - (float) ( $sy['dotation_passee'] ?? 0 ) );
?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php FKC_View::partial( 'comptabilite::_etats_style' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="ef-head">
	<div class="ef-title">🏗️ <span>Immobilisations</span> — registre et amortissements</div>
	<div class="ef-exports">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/immobilisations/amortir' ) ) ?>">⚙ Lancer l'amortissement</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/immobilisations/plan' ) ) ?>">📈 Plan d'amortissement</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/extractions?vue=immobilisations' ) ) ?>">⬇ Registre CSV</a>
		<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/immobilisations/nouvelle' ) ) ?>">+ Nouvelle immobilisation</a>
	</div>
</div>

<?php if ( ! empty( $rap['a_rattacher'] ) ) : ?>
	<?php /* PONT ACHATS → IMMOBILISATIONS (1.855.0). L'événement « acquisition
	         détectée » était émis à chaque facture d'achat en classe 2, et
	         personne ne l'écoutait : l'achat restait au bilan sans fiche, donc
	         sans amortissement. */ ?>
	<div class="ext-alert warn" style="margin-bottom:14px">ⓘ <strong><?= (int) $rap['a_rattacher'] ?> acquisition(s)</strong> imputée(s) en classe 2 n'ont pas encore de fiche : elles ne s'amortiront pas.
		<a href="<?= e( url( 'comptabilite/immobilisations/import' ) ) ?>">Créer les fiches →</a></div>
<?php endif; ?>

<div class="ef-kpis" role="list">
	<div class="ef-kpi kpi-ca" role="listitem"><span class="ef-kpi-lbl">Valeur brute du parc</span>
		<span class="ef-kpi-val"><?= e( $f( $sy['brut'] ?? 0 ) ) ?> <small>F CFA</small></span>
		<span class="ef-kpi-foot muted"><?= (int) ( $sy['en_service'] ?? 0 ) ?> bien(s) en service<?= ! empty( $sy['non_amortissables'] ) ? ' · ' . (int) $sy['non_amortissables'] . ' non amortissable(s)' : '' ?></span></div>
	<div class="ef-kpi kpi-bilan" role="listitem"><span class="ef-kpi-lbl">Amortissements cumulés</span>
		<span class="ef-kpi-val"><?= e( $f( $sy['cumul'] ?? 0 ) ) ?> <small>F CFA</small></span>
		<span class="ef-kpi-foot muted"><?= ! empty( $sy['brut'] ) ? number_format( 100 * (float) $sy['cumul'] / (float) $sy['brut'], 1, ',', ' ' ) . ' % du brut' : '—' ?><?= ! empty( $sy['totalement_amorties'] ) ? ' · ' . (int) $sy['totalement_amorties'] . ' totalement amorti(s)' : '' ?></span></div>
	<div class="ef-kpi kpi-treso" role="listitem"><span class="ef-kpi-lbl">Valeur nette comptable</span>
		<span class="ef-kpi-val"><?= e( $f( $sy['vnc'] ?? 0 ) ) ?> <small>F CFA</small></span>
		<span class="ef-kpi-foot muted"><?= (int) ( $sy['cedees'] ?? 0 ) ?> cédé(s) · <?= (int) ( $sy['annulees'] ?? 0 ) ?> annulé(s)<?= ! empty( $sy['deprecie'] ) ? ' · dépréciations ' . e( $f( $sy['deprecie'] ) ) : '' ?><?= ! empty( $sy['en_cours'] ) ? ' · ' . (int) $sy['en_cours'] . ' en cours' : '' ?></span></div>
	<div class="ef-kpi <?= $restant > 0.5 ? 'kpi-neg' : 'kpi-pos' ?>" role="listitem"><span class="ef-kpi-lbl">Dotations <?= (int) ( $sy['exercice'] ?? 0 ) ?></span>
		<span class="ef-kpi-val"><?= e( $f( $sy['dotation_passee'] ?? 0 ) ) ?> <small>/ <?= e( $f( $sy['dotation_prevue'] ?? 0 ) ) ?></small></span>
		<span class="ef-kpi-foot"><?= $restant > 0.5 ? '<span class="ef-trend down">' . e( $f( $restant ) ) . ' à doter</span>' : '<span class="ef-trend up">✓ à jour</span>' ?></span></div>
</div>

<div class="immo-bar">
	<div class="sys-tabs" style="margin:0">
		<?php foreach ( $filtres as $k => $lib ) : ?>
			<a class="sys-tab <?= $statut === $k ? 'on' : '' ?>" href="<?= e( url( 'comptabilite/immobilisations?statut=' . $k ) ) ?>"><?= e( $lib ) ?> <span class="immo-n"><?= (int) ( $cs[ $k ] ?? 0 ) ?></span></a>
		<?php endforeach; ?>
	</div>
	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : code, libellé, compte…' ) ); ?>
</div>

<div class="ef-card"><div class="ef-scroll"><table class="table ef-tbl">
	<thead><tr><th>Immobilisation</th><th>Comptes</th><th>Acquisition</th><th class="num">Valeur</th><th class="num">Amorti</th><th class="num">VNC</th><th>Statut</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $immos ) : ?><tr><td colspan="8" class="empty">Aucune immobilisation<?= 'tous' !== $statut ? ' dans ce filtre' : '' ?>.</td></tr>
	<?php else : foreach ( $immos as $im ) : $etat = (string) $im['statut']; ?>
		<tr><td><a href="<?= e( url( 'comptabilite/immobilisations/' . $im['id'] ) ) ?>" style="color:inherit"><strong><?= e( $im['libelle'] ) ?></strong></a>
				<?php if ( $im['code'] ) : ?> <span class="code"><?= e( $im['code'] ) ?></span><?php endif; ?>
				<?php if ( ! empty( $pieces[ $im['id'] ] ) ) : ?> <span class="pj-flag" title="<?= (int) $pieces[ $im['id'] ] ?> pièce(s) jointe(s)">📎</span><?php endif; ?>
				<?php if ( empty( $im['amortissable'] ) && 'annulee' !== $etat ) : ?> <span class="repli" title="Terrain, titres, avance ou immobilisation en cours : se déprécie, ne s'amortit pas">non amortissable</span><?php endif; ?></td>
			<td class="muted" style="font-family:var(--mono);font-size:11.5px"><?= e( $im['compte_immo'] ) ?><?= '' !== (string) $im['compte_amort'] ? ' · ' . e( $im['compte_amort'] ) : '' ?></td>
			<td class="muted"><?= e( date( 'd/m/Y', strtotime( $im['date_acquisition'] ) ) ) ?></td>
			<td class="num"><?= e( $f( $im['valeur_acquisition'] ) ) ?></td>
			<td class="num muted"><?= e( $f( $im['cumul'] ) ) ?></td>
			<td class="num val"><strong><?= 'cede' === $etat ? '<span class="muted" title="Sorti le ' . e( date( 'd/m/Y', strtotime( (string) $im['date_cession'] ) ) ) . '">sorti</span>' : e( $f( $im['vnc'] ) ) ?></strong></td>
			<td><span class="modbadge <?= 'cede'===$etat?'b-off':('annulee'===$etat?'b-err':'b-on') ?>"><?= 'cede'===$etat?'Cédée':('annulee'===$etat?'Annulée':'En service') ?></span></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/immobilisations/' . $im['id'] ) ) ?>">Voir</a></td></tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $immos ) : ?>
	<tfoot><tr class="total"><td colspan="3">TOTAL · <?= count( $immos ) ?> fiche(s)</td>
		<td class="num"><?= e( $f( $tot['va'] ) ) ?></td><td class="num"><?= e( $f( $tot['cumul'] ) ) ?></td><td class="num"><?= e( $f( $tot['vnc'] ) ) ?></td><td colspan="2"></td></tr></tfoot>
	<?php endif; ?>
</table></div></div>

<?php if ( ! empty( $rap['lignes'] ) ) : ?>
<div class="ef-card">
	<div class="ef-band">Rapprochement registre ↔ grand livre — au <?= e( date( 'd/m/Y', strtotime( (string) $rap['date'] ) ) ) ?>
		<span class="dgi-eq <?= ! empty( $rap['concordant'] ) ? 'ok' : 'ko' ?>" style="margin-left:10px;text-transform:none;letter-spacing:0"><?= ! empty( $rap['concordant'] ) ? '✓ concordant' : '⚠ ' . count( $rap['ecarts'] ) . ' écart(s)' ?></span></div>
	<div class="ef-scroll"><table class="table ef-tbl">
		<thead><tr><th>Compte</th><th>Libellé</th><th>Nature</th><th class="num">Registre (fiches)</th><th class="num">Grand livre</th><th class="num">Écart</th></tr></thead>
		<tbody>
		<?php foreach ( $rap['lignes'] as $l ) : $ko = abs( (float) $l['ecart'] ) >= 1; ?>
			<tr><td class="code"><a href="<?= e( url( 'comptabilite/extractions?vue=gl&etat=grandlivre&compte_id=' . (int) ( FKC_Compte::byNumero( $l['compte'] )['id'] ?? 0 ) ) ) ?>" style="color:inherit"><?= e( $l['compte'] ) ?></a></td>
				<td><?= e( $l['libelle'] ) ?></td><td class="muted"><?= 'amort' === $l['nature'] ? 'Amortissements' : ( 'dep' === $l['nature'] ? 'Dépréciations' : 'Valeur brute' ) ?></td>
				<td class="num"><?= e( $f( $l['registre'] ) ) ?></td><td class="num"><?= e( $f( $l['gl'] ) ) ?></td>
				<td class="num <?= $ko ? 'neg' : 'muted' ?>"><?= $ko ? e( $f( $l['ecart'] ) ) : '—' ?></td></tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot>
			<tr class="total"><td colspan="3">Valeur brute</td><td class="num"><?= e( $f( $rap['brut']['registre'] ) ) ?></td><td class="num"><?= e( $f( $rap['brut']['gl'] ) ) ?></td><td class="num"><?= e( $f( $rap['brut']['gl'] - $rap['brut']['registre'] ) ) ?></td></tr>
			<tr class="total"><td colspan="3">Amortissements</td><td class="num"><?= e( $f( $rap['amort']['registre'] ) ) ?></td><td class="num"><?= e( $f( $rap['amort']['gl'] ) ) ?></td><td class="num"><?= e( $f( $rap['amort']['gl'] - $rap['amort']['registre'] ) ) ?></td></tr>
			<?php if ( ! empty( $rap['dep'] ) && ( abs( $rap['dep']['registre'] ) > 0.5 || abs( $rap['dep']['gl'] ) > 0.5 ) ) : ?>
			<tr class="total"><td colspan="3">Dépréciations</td><td class="num"><?= e( $f( $rap['dep']['registre'] ) ) ?></td><td class="num"><?= e( $f( $rap['dep']['gl'] ) ) ?></td><td class="num"><?= e( $f( $rap['dep']['gl'] - $rap['dep']['registre'] ) ) ?></td></tr>
			<?php endif; ?>
		</tfoot>
	</table></div>
	<p class="ef-foot" style="padding:0 16px 12px">Écart positif : le grand livre porte plus que les fiches (achat sans fiche → <a href="<?= e( url( 'comptabilite/immobilisations/import' ) ) ?>">importer</a>, dotation manuelle).
		Écart négatif : une fiche sans écriture d'acquisition, ou une dotation contre-passée restée au registre.</p>
</div>
<?php endif; ?>

<?php if ( ! empty( $isAdmin ) ) : ?>
<details class="ef-card" style="padding:12px 16px">
	<summary style="cursor:pointer;font-weight:600">Seuil d'immobilisation<?= ! empty( $seuil ) ? ' : ' . e( $f( $seuil ) ) . ' FCFA' : ' (désactivé)' ?></summary>
	<form method="post" action="<?= e( url('comptabilite/immobilisations/seuil') ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:10px 0 0">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:220px"><span>Seuil (FCFA)</span><input class="num" name="seuil" value="<?= e( $seuil ? fkc_money( $seuil ) : '' ) ?>" placeholder="0 = désactivé"></label>
		<button class="btn btn-ghost btn-sm" type="submit">Enregistrer le seuil</button>
		<span class="help" style="max-width:520px">En-dessous de ce montant, un bien est proposé en charges directes (SYSCOHADA — biens de faible valeur) plutôt qu'immobilisé et amorti. <strong>0 = aucun seuil.</strong></span>
	</form>
</details>
<?php endif; ?>
<style>
.immo-bar{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px}
.immo-bar .sys-tab{font-size:12.5px;padding:7px 14px}
.immo-n{display:inline-block;min-width:18px;padding:0 6px;margin-left:4px;border-radius:99px;background:rgba(255,255,255,.07);font-size:11px;font-family:var(--mono);color:var(--muted)}
.ext-alert{padding:10px 14px;border-radius:10px;font-size:12.8px;border:1px solid var(--line);border-left-width:3px;background:var(--panel)}
.ext-alert.warn{border-left-color:var(--orange)}.ext-alert a{color:var(--orange);font-weight:600;margin-left:6px}
</style>
