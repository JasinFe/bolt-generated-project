<?php /** @var array $immos @var array $comptes @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card">
	<div class="card-head"><h2>Céder une immobilisation</h2></div>
	<div class="card-body">
		<?php if ( ! $immos ) : ?>
			<p class="muted" style="margin:0">Aucune immobilisation en service à céder.</p>
		<?php else : ?>
		<p class="help" style="margin-top:0">La cession passe d'abord la <strong>dotation complémentaire</strong> de l'exercice (prorata jusqu'à la date de sortie), puis solde la valeur d'origine et les amortissements (81x / 28 / 2x) et constate le prix (82x) — 811/821 pour un bien incorporel, 812/822 corporel, 816/826 financier. Sans prix, c'est une <strong>mise au rebut</strong>.</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/ceder' ) ) ?>" id="cession-form" onsubmit="return confirm('Enregistrer la cession ?');">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid">
				<label class="fld" style="grid-column:1/-1"><span>Immobilisation</span>
					<select name="immo_id" required>
						<option value="">— Sélectionner —</option>
						<?php foreach ( $immos as $im ) : ?>
							<option value="<?= (int) $im['id'] ?>"><?= e( $im['libelle'] ) ?> — <?= e( fkc_money( $im['valeur_acquisition'] ) ) ?> FCFA (<?= e( $im['date_acquisition'] ) ?>)</option>
						<?php endforeach; ?>
					</select></label>
				<label class="fld"><span>Date de cession</span>
					<input type="date" name="date_cession" value="<?= e( date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>Prix de cession (FCFA)</span>
					<input class="num" name="valeur_cession" placeholder="0 = mise au rebut" inputmode="decimal"></label>
				<label class="fld"><span>Trésorerie (encaissement)</span>
					<select name="tresorerie_id">
						<option value="0">— aucun (mise au rebut) —</option>
						<?php foreach ( $comptes as $c ) : ?><option value="<?= (int) $c['id'] ?>"><?= e( $c['libelle'] ) ?></option><?php endforeach; ?>
					</select></label>
			</div>
			<div class="actions" style="margin-top:8px">
				<button class="btn btn-primary" type="submit">Enregistrer la cession</button>
			</div>
		</form>
		<?php endif; ?>
	</div>
</div>
