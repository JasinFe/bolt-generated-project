<?php /** @var array $sources @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Acquisitions imputées en classe 2 sans fiche · <?= count( $sources ) ?> — hors À-nouveaux, amortissements (28/29), cessions et écritures contre-passées. Les comptes d'amortissement et de dotation se déduisent du compte d'immobilisation.</span></div>
<?php if ( ! $sources ) : ?>
	<div class="card"><div class="card-body"><p class="muted" style="margin:0">Aucune écriture d'immobilisation à importer. Toutes les acquisitions de classe 2 sont déjà rattachées à une fiche.</p></div></div>
<?php else : foreach ( $sources as $s ) : ?>
<div class="card">
	<div class="card-head"><h2><?= e( $s['compte_numero'] ) ?> · <?= e( $s['ligne_libelle'] ?: $s['ecriture_libelle'] ) ?></h2>
		<span class="muted"><?= e( $s['date_ecriture'] ) ?> · pièce <?= e( $s['piece'] ?: '—' ) ?> · <?= e( fkc_money( $s['debit'] ) ) ?> FCFA</span></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/import' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="ecriture_acq_id" value="<?= (int) $s['ecriture_id'] ?>">
			<?php /* La LIGNE, pour que les autres biens de la même pièce restent importables (1.730.0). */ ?>
			<input type="hidden" name="ligne_acq_id" value="<?= (int) $s['ligne_id'] ?>">
			<input type="hidden" name="compte_immo" value="<?= e( $s['compte_numero'] ) ?>">
			<input type="hidden" name="valeur_acquisition" value="<?= e( $s['debit'] ) ?>">
			<input type="hidden" name="date_acquisition" value="<?= e( $s['date_ecriture'] ) ?>">
			<div class="form-grid">
				<label class="fld"><span>Libellé de l'immobilisation</span>
					<input type="text" name="libelle" value="<?= e( $s['ligne_libelle'] ?: $s['ecriture_libelle'] ) ?>" required></label>
				<label class="fld"><span>Durée (années)</span>
					<input type="number" name="duree_annees" step="0.5" min="0.5" value="5" required></label>
				<label class="fld"><span>Compte amortissement</span>
					<input type="text" name="compte_amort" value="" placeholder="déduit du compte <?= e( $s['compte_numero'] ) ?>"></label>
				<label class="fld"><span>Compte dotation</span>
					<input type="text" name="compte_dotation" value="" placeholder="déduit du compte"></label>
				<label class="fld"><span>Valeur résiduelle</span>
					<input type="number" name="valeur_residuelle" value="0"></label>
			</div>
			<div class="actions" style="margin-top:8px">
				<button class="btn btn-primary btn-sm" type="submit">Créer la fiche immobilisation</button>
				<span class="muted">Valeur reprise de l'écriture : <?= e( fkc_money( $s['debit'] ) ) ?> FCFA</span>
			</div>
		</form>
	</div>
</div>
<?php endforeach; endif; ?>
