<?php /** @var array $lignes @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Plan d'amortissement linéaire (prorata temporis) · <?= count( $lignes ) ?> immobilisation(s)</span></div>
<?php if ( ! $lignes ) : ?>
	<div class="card"><div class="card-body"><p class="muted" style="margin:0">Aucune immobilisation enregistrée.</p></div></div>
<?php else : foreach ( $lignes as $L ) : $im = $L['immo']; ?>
<div class="card card-flush">
	<div class="card-head"><h2><?= e( $im['libelle'] ) ?> <span class="muted">· <?= e( $im['compte_immo'] ) ?> · <?= e( fkc_money( $im['valeur_acquisition'] ) ) ?> FCFA · <?= e( $im['duree_annees'] ) ?> ans</span></h2>
		<?php if ( 'cede' === $im['statut'] ) : ?><span class="modbadge b-off">Cédée</span><?php else : ?><span class="modbadge b-on">VNC <?= e( fkc_money( $L['vnc'] ) ) ?></span><?php endif; ?>
	</div>
	<table class="table">
		<thead><tr><th>Exercice</th><th class="num">Dotation</th><th class="num">Cumul</th><th class="num">VNC</th></tr></thead>
		<tbody>
		<?php foreach ( $L['plan'] as $r ) : ?>
			<tr><td class="code"><?= (int) $r['exercice'] ?></td>
				<td class="num"><?= e( fkc_money( $r['dotation'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $r['cumul'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $r['vnc'] ) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endforeach; endif; ?>
