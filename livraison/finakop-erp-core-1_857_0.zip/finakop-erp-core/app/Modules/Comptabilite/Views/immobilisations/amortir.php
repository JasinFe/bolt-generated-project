<?php /** @var array $immos @var int $exercice @var bool $mensuel @var int $moisCourant @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$mensuel = ! empty( $mensuel );
$moisNoms = array( 1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre' );
?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card">
	<div class="card-head"><h2>Lancer l'amortissement<?= $mensuel ? ' du mois' : ' de l\'exercice' ?></h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">Comptabilise la dotation aux amortissements (D 6813 / C 28) pour toutes les immobilisations en service dont la dotation n'a pas encore été passée<?= $mensuel ? ' sur le mois choisi' : ' sur l\'exercice choisi' ?>. Les dotations déjà comptabilisées sont ignorées.</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/amortir' ) ) ?>" onsubmit="return confirm('Lancer l\'amortissement ?');" style="display:flex;align-items:end;gap:12px;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0"><span>Exercice</span>
				<input type="number" name="exercice" value="<?= (int) $exercice ?>" min="2000" max="2100" style="width:120px"></label>
			<?php if ( $mensuel ) : ?>
			<label class="fld" style="margin:0"><span>Mois</span>
				<select name="mois" style="width:150px">
					<?php foreach ( $moisNoms as $k => $nom ) : ?>
						<option value="<?= (int) $k ?>" <?= (int) $moisCourant === (int) $k ? 'selected' : '' ?>><?= e( $nom ) ?></option>
					<?php endforeach; ?>
				</select></label>
			<?php endif; ?>
			<button class="btn btn-primary" type="submit" <?= $immos ? '' : 'disabled' ?>>Lancer l'amortissement</button>
		</form>
	</div>
</div>
<div class="card" style="max-width:720px">
	<div class="card-head"><h2>Périodicité des dotations</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">En <strong>annuel</strong>, une seule dotation par exercice, datée de la clôture — l'usage d'un dossier arrêté une fois l'an.
			En <strong>mensuel</strong>, la dotation est découpée en douze et datée de la fin de chaque mois : la charge tombe dans le mois qu'elle concerne,
			et la marge mensuelle cesse d'être fausse onze mois sur douze. La somme des mensualités reste exactement l'annuité du plan.</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/periodicite' ) ) ?>" style="display:flex;align-items:end;gap:12px;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0"><span>Périodicité</span>
				<select name="periodicite" style="width:180px">
					<option value="annuelle" <?= $mensuel ? '' : 'selected' ?>>Annuelle</option>
					<option value="mensuelle" <?= $mensuel ? 'selected' : '' ?>>Mensuelle</option>
				</select></label>
			<button class="btn btn-ghost" type="submit">Enregistrer</button>
		</form>
		<p class="help">Le changement ne touche pas aux dotations déjà comptabilisées : il vaut pour celles qui restent à passer.</p>
	</div>
</div>
<div class="card card-flush">
	<div class="card-head"><h2>Immobilisations en service (<?= count( $immos ) ?>)</h2></div>
	<table class="table">
		<thead><tr><th>Libellé</th><th class="num">Valeur</th><th class="num">Durée</th><th>Acquisition</th></tr></thead>
		<tbody>
		<?php if ( ! $immos ) : ?><tr><td colspan="4" class="empty">Aucune immobilisation en service.</td></tr>
		<?php else : foreach ( $immos as $im ) : ?>
			<tr><td><?= e( $im['libelle'] ) ?></td>
				<td class="num"><?= e( fkc_money( $im['valeur_acquisition'] ) ) ?></td>
				<td class="num"><?= e( $im['duree_annees'] ) ?> ans</td>
				<td class="code"><?= e( $im['date_acquisition'] ) ?></td></tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
