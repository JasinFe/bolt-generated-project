<?php /** @var array|null $campagne @var array|null $rapport @var int $sansCode @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'comptabilite::_immo_subnav' );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === ( $flash['type'] ?? 'ok' ) ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="max-width:900px">
	<div class="card-head"><h2>🏛️ Récolement des immobilisations</h2></div>
	<div class="card-body">

	<p class="muted" style="margin-top:0">
		L'inventaire physique ne porte pas que sur les stocks. Vérifier périodiquement l'existence des actifs
		est une obligation comptable : sans elle, un matériel disparu, prêté sans trace ou cédé sans écriture
		continue de s'amortir dans les comptes, année après année.
	</p>

	<?php if ( $sansCode > 0 ) : ?>
		<div class="alert" style="margin:14px 0">
			<strong><?= (int) $sansCode ?> actif(s) sans code-barres.</strong>
			<span class="muted">Ils n'apparaîtront pas à la douchette. Les immobilisations créées depuis la mise à jour en reçoivent un automatiquement ; celles d'avant demandent un rattrapage.</span>
			<form method="post" action="<?= e( url( 'comptabilite/immobilisations/recolement' ) ) ?>" style="margin-top:8px">
				<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="codes">
				<button class="btn btn-sm" type="submit">Attribuer les codes manquants</button>
			</form>
		</div>
	<?php endif; ?>

	<?php if ( ! $campagne ) : ?>

		<h3 style="margin:18px 0 6px;font-size:15px">Ouvrir une campagne</h3>
		<p class="muted" style="font-size:12.5px;margin:0 0 10px">
			Une campagne à la fois. Une fois ouverte, une boîte de scan apparaît sur cette page : chaque code lu
			pointe l'actif comme vu, sans avoir à ouvrir un autre écran ni à choisir un contexte.
		</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/recolement' ) ) ?>" style="display:flex;gap:8px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="ouvrir">
			<label class="fld" style="min-width:260px"><span>Intitulé</span><input name="libelle" placeholder="Récolement annuel <?= e( date( 'Y' ) ) ?>"></label>
			<button class="btn btn-primary" type="submit">Ouvrir la campagne</button>
		</form>

	<?php else : ?>

		<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin:16px 0">
			<div>
				<strong><?= e( (string) $campagne['libelle'] ) ?></strong>
				<span class="muted">· ouverte le <?= e( (string) $campagne['ouverte_at'] ) ?></span>
			</div>
			<?php if ( $rapport ) : ?>
				<div style="font-size:15px">
					<strong><?= count( $rapport['vus'] ) ?></strong> vu(s) ·
					<strong><?= count( $rapport['manquants'] ) ?></strong> introuvable(s) ·
					<strong><?= e( (string) $rapport['taux'] ) ?> %</strong>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $rapport && $rapport['manquants'] ) : ?>
			<div class="alert" style="margin:0 0 14px">
				<strong><?= count( $rapport['manquants'] ) ?> actif(s) restent introuvables</strong>,
				pour <?= e( fkc_money( (float) $rapport['valeur_manquante'] ) ) ?> F de valeur d'acquisition.
				<span class="muted">Un actif introuvable peut être égaré, prêté ou volé — aucune écriture n'est passée d'office, la décision vous revient.</span>
			</div>
		<?php endif; ?>

		<?php
		/*
		 * LA DOUCHETTE SUR L'ÉCRAN OÙ L'ON TRAVAILLE.
		 *
		 * Le texte ci-dessus disait « scannez depuis la console, le mobile ou
		 * une douchette, en choisissant le contexte Récolement des actifs ».
		 * C'est trois écrans et un réglage pour un geste qui devrait tenir ici :
		 * on est déjà dans la campagne, le contexte ne se demande pas, il se
		 * déduit de la page ouverte.
		 *
		 * La même boîte accepte le scan, le code d'inventaire ou le libellé —
		 * l'étiquette d'un actif est souvent la première chose qui s'arrache.
		 */
		?>
		<h3 style="margin:18px 0 6px;font-size:15px">Scanner les actifs</h3>
		<p class="muted" style="font-size:12.5px;margin:0 0 8px">
			Chaque code lu pointe l'actif comme vu, immédiatement. Sans étiquette lisible, tapez le code
			d'inventaire ou le nom : le moteur reconnaît les trois.
		</p>
		<?php FKC_View::partial( 'scan::_scanbox', array(
			'contexte' => 'immobilisation',
			'route'    => 'comptabilite/immobilisations/recolement',
			'cible'    => 'recolementPointe',
			'autofocus' => true,
		) ); ?>
		<div id="recolementFlux" class="muted" style="font-size:.9em;margin:-4px 0 14px"></div>
		<script>
		// Le pointage est fait côté serveur par l'action du contexte : ici on
		// ne fait qu'accuser réception, puis on rafraîchit pour que les
		// compteurs et le tableau reflètent le parc réel.
		var recolementVus = 0;
		function recolementPointe(res) {
			var a = res.action || {}, zone = document.getElementById('recolementFlux');
			recolementVus++;
			zone.textContent = '✓ ' + (res.libelle || 'Actif') + ' pointé'
				+ (a.message ? ' — ' + a.message : '') + ' (' + recolementVus + ' depuis l\'ouverture de la page)';
            clearTimeout(window._recoTimer);
			window._recoTimer = setTimeout(function () { location.reload(); }, 1200);
		}
		</script>

		<h3 style="margin:18px 0 6px;font-size:15px">Pointer manuellement</h3>
		<p class="muted" style="font-size:12.5px;margin:0 0 10px">Tout le parc n'est pas accessible à la douchette : matériel scellé, véhicule en mission, étiquette arrachée.</p>
		<?php if ( $rapport && $rapport['manquants'] ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/recolement' ) ) ?>" style="display:flex;gap:8px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="pointer">
			<label class="fld" style="min-width:280px"><span>Actif</span>
				<select name="immobilisation_id" required>
					<?php foreach ( $rapport['manquants'] as $m ) : ?>
						<option value="<?= (int) $m['id'] ?>"><?= e( (string) $m['libelle'] ) ?> (<?= e( (string) ( $m['code'] ?? '' ) ) ?>)</option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Emplacement</span><input name="emplacement" placeholder="Bureau, atelier…"></label>
			<label class="fld"><span>Détenteur</span><input name="detenteur" placeholder="Nom"></label>
			<button class="btn" type="submit">Pointer</button>
		</form>
		<?php else : ?>
			<p class="help">Tous les actifs du périmètre ont été vus.</p>
		<?php endif; ?>

		<?php if ( $rapport ) : ?>
			<h3 style="margin:22px 0 6px;font-size:15px">État du parc</h3>
			<table class="table"><thead><tr>
				<th>Actif</th><th>Code interne</th><th>Code-barres</th><th>Emplacement</th><th class="num">Valeur</th><th>État</th>
			</tr></thead><tbody>
			<?php foreach ( array_merge( $rapport['manquants'], $rapport['vus'] ) as $r ) : $vu = ! empty( $r['vu_at'] ); ?>
				<tr<?= $vu ? '' : ' style="background:rgba(255,140,60,.08)"' ?>>
					<td><?= e( (string) $r['libelle'] ) ?></td>
					<td><?= e( (string) ( $r['code'] ?? '' ) ) ?></td>
					<td style="font-family:monospace;font-size:12px"><?= e( (string) ( $r['code_barres'] ?? '—' ) ) ?></td>
					<td><?= e( (string) ( $r['emplacement'] ?? '' ) ) ?></td>
					<td class="num"><?= e( fkc_money( (float) ( $r['valeur_acquisition'] ?? 0 ) ) ) ?></td>
					<td><?= $vu ? '✅ vu' : '⚠️ introuvable' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>

			<?php
			// Planche d'étiquettes : on ne propose que les actifs réellement codés.
			$codes = array();
			foreach ( array_merge( $rapport['vus'], $rapport['manquants'] ) as $r ) {
				if ( ! empty( $r['code_barres'] ) ) { $codes[] = (string) $r['code_barres']; }
			}
			?>
			<?php if ( $codes ) : ?>
				<a class="btn btn-ghost btn-sm" style="margin-top:12px" target="_blank"
				   href="<?= e( url( 'scan/planche?codes=' . rawurlencode( implode( ',', $codes ) ) . '&qte=1' ) ) ?>">
					🏷️ Imprimer les étiquettes du parc
				</a>
			<?php endif; ?>
		<?php endif; ?>

		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/recolement' ) ) ?>" style="margin-top:22px;display:flex;gap:8px;align-items:end;flex-wrap:wrap"
		      onsubmit="return confirm('Clôturer la campagne ? Le rapport restera consultable.')">
			<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="cloturer">
			<label class="fld" style="min-width:300px"><span>Note de clôture</span><input name="note" placeholder="Observations, décisions à prendre…"></label>
			<button class="btn btn-primary" type="submit">Clôturer le récolement</button>
		</form>

	<?php endif; ?>
	</div>
</div>
