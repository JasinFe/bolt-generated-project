<?php
/**
 * Fiche d'immobilisation — opérations avancées (1.856.0) : mise en service
 * d'un en-cours, unités d'œuvre, composants, dépréciation, réévaluation.
 *
 * @var array $im @var float $vnc
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$enService = FKC_Immobilisation::estEnService( $im );
$depreciations = (array) ( $depreciations ?? array() );
$cumulDeprecie = (float) ( $cumulDeprecie ?? 0 );
$numDep = (array) ( $numDep ?? array() );
$composants = (array) ( $composants ?? array() );
$reevaluations = (array) ( $reevaluations ?? array() );
$unites = (array) ( $unites ?? array() );
$enCours = (bool) ( $enCours ?? false );
$exercice = (int) ( $exercice ?? date( 'Y' ) );
$base = 'comptabilite/immobilisations/' . (int) $im['id'];
$methodes = FKC_Immobilisation::methodes();
$peutComposer = $enService && empty( $im['parent_id'] ) && FKC_Immobilisation::estAmortissable( $im ) && ! FKC_Immobilisation::dotations( (int) $im['id'] );
?>
<style>
.immo-ops{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:16px;margin-bottom:16px}
@media (max-width:560px){.immo-ops{grid-template-columns:1fr}}
.immo-ops .card{margin:0;min-width:0}
.immo-ops .card-body{overflow-x:auto}
.immo-ops .form-grid{gap:10px;grid-template-columns:repeat(auto-fit,minmax(130px,1fr))!important}
.immo-ops table.table td,.immo-ops table.table th{padding:6px 10px;font-size:13px}
.immo-ops .ops-tag{display:inline-block;font-size:11px;padding:1px 7px;border-radius:9px;background:var(--bg2);border:1px solid var(--line);margin-left:6px;vertical-align:middle}
</style>

<?php if ( $enCours && $enService ) : ?>
<div class="card" style="border-left:3px solid var(--orange)"><div class="card-head"><h2>Mettre en service <span class="ops-tag">en cours · <?= e( $im['compte_immo'] ) ?></span></h2></div><div class="card-body">
	<p class="help" style="margin-top:0">Une immobilisation en cours ne s'amortit pas. À sa réception, elle est virée à son compte définitif
		(D compte définitif / C <?= e( $im['compte_immo'] ) ?>) et son amortissement démarre à la date de mise en service.</p>
	<form method="post" action="<?= e( url( $base . '/mise-en-service' ) ) ?>" onsubmit="return confirm('Virer le bien à son compte définitif ?')">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr 1fr">
			<label class="fld"><span>Date de mise en service</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>" required></label>
			<label class="fld"><span>Compte définitif</span><input class="code" name="compte_immo" placeholder="<?= e( substr( (string) $im['compte_immo'], 0, 2 ) ) ?>1000" required></label>
			<label class="fld"><span>Durée (années)</span><input class="num" name="duree_annees" value="<?= e( (string) ( $im['duree_annees'] ?: '' ) ) ?>"></label>
			<label class="fld"><span>Méthode</span><select name="methode"><?php foreach ( $methodes as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
		</div>
		<div class="actions"><button class="btn btn-primary" type="submit">Mettre en service</button></div>
	</form>
</div></div>
<?php endif; ?>

<div class="immo-ops">
<?php if ( 'unites' === (string) $im['methode'] ) : ?>
	<div class="card"><div class="card-head"><h2>Unités d'œuvre</h2></div><div class="card-body">
		<p class="help" style="margin-top:0">Prévu : <strong><?= e( fkc_money( (float) $im['unites_total'] ) ) ?></strong> unités.
			Dotation de l'exercice = base amortissable × unités de l'exercice ÷ unités prévues.</p>
		<?php if ( $unites ) : ?>
		<table class="table"><thead><tr><th>Exercice</th><th class="num">Unités</th><th class="num">Dotation</th></tr></thead><tbody>
			<?php foreach ( $unites as $ex => $u ) : ?>
				<tr><td><?= (int) $ex ?></td><td class="num"><?= e( fkc_money( $u ) ) ?></td><td class="num"><?= e( fkc_money( FKC_Immobilisation::dotationPrevue( $im, $ex ) ) ) ?></td></tr>
			<?php endforeach; ?>
			<tr class="total"><td>Consommé</td><td class="num"><?= e( fkc_money( array_sum( $unites ) ) ) ?></td><td></td></tr>
		</tbody></table>
		<?php endif; ?>
		<?php if ( $enService ) : ?>
		<form method="post" action="<?= e( url( $base . '/unites' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr auto;align-items:end">
				<label class="fld"><span>Exercice</span><input class="num" name="exercice" value="<?= (int) $exercice ?>"></label>
				<label class="fld"><span>Unités consommées</span><input class="num" name="unites" required></label>
				<button class="btn btn-primary btn-sm" type="submit">Enregistrer</button>
			</div>
		</form>
		<?php endif; ?>
	</div></div>
<?php endif; ?>

<?php if ( $composants || $peutComposer || ! empty( $parent ) ) : ?>
	<div class="card"><div class="card-head"><h2>Composants</h2></div><div class="card-body">
		<?php if ( ! empty( $parent ) ) : ?>
			<p class="help" style="margin-top:0">Composant de <a href="<?= e( url( 'comptabilite/immobilisations/' . (int) $parent['id'] ) ) ?>"><?= e( $parent['libelle'] ) ?></a> — il s'amortit sur sa durée propre.</p>
		<?php endif; ?>
		<?php if ( $composants ) : ?>
		<table class="table"><thead><tr><th>Composant</th><th>Compte</th><th class="num">Valeur</th><th class="num">Durée</th></tr></thead><tbody>
			<?php foreach ( $composants as $c ) : ?>
				<tr><td><a href="<?= e( url( 'comptabilite/immobilisations/' . (int) $c['id'] ) ) ?>"><?= e( $c['libelle'] ) ?></a></td>
					<td class="code"><?= e( $c['compte_immo'] ) ?></td><td class="num"><?= e( fkc_money( $c['valeur_acquisition'] ) ) ?></td><td class="num"><?= e( (string) (float) $c['duree_annees'] ) ?> ans</td></tr>
			<?php endforeach; ?>
		</tbody></table>
		<?php endif; ?>
		<?php if ( $peutComposer ) : ?>
		<p class="help">Détacher un élément à durée propre (toiture, moteur, pneus…) — avant la première dotation. La valeur de la fiche principale diminue d'autant.</p>
		<form method="post" action="<?= e( url( $base . '/composant' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:2fr 1fr 1fr 1fr">
				<label class="fld"><span>Libellé</span><input name="libelle" required placeholder="Toiture"></label>
				<label class="fld"><span>Valeur</span><input class="num" name="valeur" required></label>
				<label class="fld"><span>Durée</span><input class="num" name="duree_annees" required></label>
				<label class="fld"><span>Compte</span><input class="code" name="compte_immo" placeholder="<?= e( $im['compte_immo'] ) ?>"></label>
			</div>
			<div class="actions"><button class="btn btn-ghost btn-sm" type="submit">Ajouter le composant</button></div>
		</form>
		<?php endif; ?>
	</div></div>
<?php endif; ?>

<?php if ( $enService || $depreciations ) : ?>
	<div class="card"><div class="card-head"><h2>Dépréciation<?php if ( $cumulDeprecie > 0 ) : ?> <span class="ops-tag"><?= e( fkc_money( $cumulDeprecie ) ) ?> FCFA</span><?php endif; ?></h2></div><div class="card-body">
		<p class="help" style="margin-top:0">Quand la valeur actuelle tombe sous la valeur comptable : D <?= e( $numDep['dotation'] ?? '6914' ) ?> / C <?= e( $numDep['depreciation'] ?? '29' ) ?>.
			Reprise : D <?= e( $numDep['depreciation'] ?? '29' ) ?> / C <?= e( $numDep['reprise'] ?? '7914' ) ?>.</p>
		<?php if ( $depreciations ) : ?>
		<table class="table"><thead><tr><th>Date</th><th>Opération</th><th class="num">Montant</th></tr></thead><tbody>
			<?php foreach ( $depreciations as $d ) : ?>
				<tr><td><?= e( date( 'd/m/Y', strtotime( (string) $d['date_operation'] ) ) ) ?></td>
					<td><?= (float) $d['montant'] >= 0 ? 'Constatation' : 'Reprise' ?><?= '' !== (string) $d['motif'] ? ' — <span class="muted">' . e( (string) $d['motif'] ) . '</span>' : '' ?>
						<?php if ( empty( $d['ecriture_id'] ) ) : ?><span class="modbadge b-warn">Au journal temporaire</span><?php endif; ?></td>
					<td class="num"><?= e( fkc_money( $d['montant'] ) ) ?></td></tr>
			<?php endforeach; ?>
		</tbody></table>
		<?php endif; ?>
		<?php if ( $enService ) : ?>
		<form method="post" action="<?= e( url( $base . '/deprecier' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
				<label class="fld"><span>Opération</span><select name="sens"><option value="constater">Constater</option><?php if ( $cumulDeprecie > 0 ) : ?><option value="reprise">Reprendre</option><?php endif; ?></select></label>
				<label class="fld"><span>Date</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>Montant</span><input class="num" name="montant" required></label>
			</div>
			<label class="fld"><span>Motif</span><input name="motif" placeholder="Expertise, sinistre, baisse du cours…"></label>
			<div class="actions"><button class="btn btn-ghost btn-sm" type="submit">Enregistrer</button></div>
		</form>
		<?php endif; ?>
	</div></div>
<?php endif; ?>

<?php if ( $enService || $reevaluations ) : ?>
	<div class="card"><div class="card-head"><h2>Réévaluation</h2></div><div class="card-body">
		<p class="help" style="margin-top:0">L'écart entre la valeur actuelle et la VNC (<?= e( fkc_money( $vnc ) ) ?>) s'ajoute à la valeur brute
			et s'inscrit en capitaux propres (compte 106), sans passer par le résultat. Les exercices suivants amortissent la nouvelle base.</p>
		<?php if ( $reevaluations ) : ?>
		<table class="table"><thead><tr><th>Date</th><th class="num">VNC avant</th><th class="num">Valeur actuelle</th><th class="num">Écart (106)</th></tr></thead><tbody>
			<?php foreach ( $reevaluations as $r ) : ?>
				<tr><td><?= e( date( 'd/m/Y', strtotime( (string) $r['date'] ) ) ) ?></td><td class="num"><?= e( fkc_money( $r['vnc_avant'] ) ) ?></td>
					<td class="num"><?= e( fkc_money( $r['valeur_actuelle'] ) ) ?></td><td class="num"><strong><?= e( fkc_money( $r['ecart'] ) ) ?></strong></td></tr>
			<?php endforeach; ?>
		</tbody></table>
		<?php endif; ?>
		<?php if ( $enService ) : ?>
		<form method="post" action="<?= e( url( $base . '/reevaluer' ) ) ?>" onsubmit="return confirm('Enregistrer la réévaluation ?')">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr 2fr">
				<label class="fld"><span>Date</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>Valeur actuelle</span><input class="num" name="valeur_actuelle" required></label>
				<label class="fld"><span>Motif</span><input name="motif" placeholder="Rapport d'expert…"></label>
			</div>
			<div class="actions"><button class="btn btn-ghost btn-sm" type="submit">Réévaluer</button></div>
		</form>
		<?php endif; ?>
	</div></div>
<?php endif; ?>
</div>
