<?php /** @var array $table @var array $audit @var string|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card card-flush">
	<div class="card-head"><h2>Comment l'amortissement trouve son compte</h2></div>
	<div style="padding:12px;line-height:1.7">
		Le SYSCOHADA a construit les comptes 28 et 29 <strong>en miroir</strong> de la classe 2 :
		<span class="code">213</span> Logiciels → <span class="code">2813</span> Amortissements des logiciels,
		<span class="code">245</span> Matériel de transport → <span class="code">2845</span>.
		La correspondance se <strong>déduit</strong> donc du compte d'immobilisation : elle n'a pas à être saisie.
		<br><br>
		Choisir le compte du bien suffit — l'amortissement et la dotation suivent. Un compte que vous avez
		délibérément choisi est conservé ; seul un compte manifestement incohérent est corrigé, et la correction
		est tracée.
	</div>
</div>

<?php
/*
 * Les fiches héritées d'abord, la table de référence ensuite : quelqu'un qui
 * ouvre cet écran a le plus souvent un problème à régler, pas une règle à
 * apprendre.
 */
?>
<?php if ( ! empty( $audit['incoherentes'] ) ) : ?>
<div class="card card-flush">
	<?php
/*
 * DÉCLARER UN RATTACHEMENT À N'IMPORTE QUEL NIVEAU (1.729.0).
 *
 * Le tableau ci-dessous ne liste que les racines à trois chiffres du
 * référentiel : c'est utile pour voir la règle, insuffisant pour la plier au
 * plan réel. Le matériel de bureau 2441xx s'amortit en 284410, l'informatique
 * 2442xx en 284420, le mobilier 2444xx en 284440 — aucun de ces comptes ne se
 * DÉDUIT du numéro d'origine, ils se DÉCLARENT. D'où ce formulaire, qui
 * accepte de trois à six chiffres.
 */
?>
<div class="card">
	<div class="card-head"><h2>Déclarer un rattachement</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Le compte d'amortissement n'est plus déduit du numéro d'immobilisation : il se déclare.
			Trois niveaux sont interrogés, <strong>du plus précis au plus général</strong> — le compte exact
			(<span class="code">241110</span>), puis la sous-racine (<span class="code">2411</span>),
			puis la racine SYSCOHADA (<span class="code">241</span>). Le premier qui répond gagne, ce qui
			permet de poser une règle de famille et d'y faire une exception.
		</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/comptes' ) ) ?>"
			style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Compte ou racine d'immobilisation</span>
				<input class="code" name="racine" placeholder="241110" required style="width:130px"></label>
			<label class="fld"><span>Compte d'amortissement</span>
				<input class="code" name="amortissement" placeholder="284410" style="width:130px"></label>
			<label class="fld"><span>Dépréciation (facultatif)</span>
				<input class="code" name="depreciation" placeholder="294xxx" style="width:130px"></label>
			<button class="btn btn-primary btn-sm">Enregistrer</button>
		</form>
		<p class="help" style="margin-bottom:0">
			Laisser le compte d'amortissement vide RETIRE la correspondance et rend le compte à la règle.
			Seule la classe est contrôlée — 28 pour un amortissement, 29 pour une dépréciation : le produit
			ne vérifie plus que le compte « ressemble » à celui qu'il aurait déduit, puisque c'est
			précisément ce qu'on abandonne.
		</p>
		<?php $decl = class_exists( 'FKC_MappingAmortissement' ) ? FKC_MappingAmortissement::correspondances() : array(); ?>
		<?php if ( $decl ) : ?>
			<table class="table" style="margin-top:14px">
				<thead><tr><th>Immobilisation</th><th>Niveau</th><th>Amortissement</th><th>Dépréciation</th><th></th></tr></thead>
				<tbody>
				<?php foreach ( $decl as $cle => $d ) : ?>
					<tr>
						<td class="code"><?= e( $cle ) ?></td>
						<td><?= e( 'exacte' === $d['niveau'] ? 'Compte exact' : ( 'sous_racine' === $d['niveau'] ? 'Sous-racine' : 'Racine' ) ) ?></td>
						<td class="code"><?= e( (string) $d['amortissement'] ) ?></td>
						<td class="code"><?= e( (string) ( $d['depreciation'] ?? '' ) ) ?></td>
						<td style="text-align:right">
							<form method="post" action="<?= e( url( 'comptabilite/immobilisations/comptes' ) ) ?>" style="display:inline">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="racine" value="<?= e( $cle ) ?>">
								<input type="hidden" name="amortissement" value="">
								<button class="btn btn-ghost btn-sm">Retirer</button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
</div>

<div class="card-head">
		<h2>Immobilisations mal rattachées</h2>
		<span class="muted"><?= count( $audit['incoherentes'] ) ?> sur <?= (int) $audit['total'] ?> fiches</span>
	</div>
	<div style="padding:12px" class="muted">
		Leur amortissement se crédite sur un compte qui ne correspond pas à la nature du bien. Le total du tableau
		des amortissements reste juste ; sa <strong>ventilation</strong> ne l'est pas — et c'est elle qu'un contrôleur regarde.
		Une fiche déjà dotée ne se corrige pas d'un clic : il faut un virement daté.
	</div>
	<table class="table">
		<thead><tr><th>Immobilisation</th><th style="width:100px">Compte du bien</th><th style="width:100px">Amortissement</th><th style="width:100px">Attendu</th><th>Intitulé attendu</th><th class="num" style="width:90px">Dotations</th></tr></thead>
		<tbody>
		<?php foreach ( $audit['incoherentes'] as $x ) : ?>
			<tr>
				<td><a href="<?= e( url( 'comptabilite/immobilisations/' . (int) $x['id'] ) ) ?>"><?= e( $x['libelle'] ) ?></a></td>
				<td class="code"><?= e( $x['compte_immo'] ) ?></td>
				<td class="code" style="color:var(--danger)"><?= e( $x['actuel'] ) ?></td>
				<td class="code" style="color:var(--ok)"><?= e( $x['attendu'] ) ?></td>
				<td class="muted"><?= e( $x['libelle_attendu'] ) ?></td>
				<td class="num"><?= (int) $x['dotations'] ?><?= $x['dotations'] > 0 ? ' <span class="muted" style="font-size:.8em">virement requis</span>' : '' ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>

<?php if ( ! empty( $audit['non_amortissables'] ) ) : ?>
<div class="card card-flush">
	<div class="card-head"><h2>Biens non amortissables</h2><span class="muted"><?= count( $audit['non_amortissables'] ) ?></span></div>
	<?php
	/*
	 * L'amortissement traduit la consommation d'un bien sur sa durée d'utilité.
	 * Un bien qui ne se consomme pas ne s'amortit pas : il se DÉPRÉCIE, si sa
	 * valeur baisse. Les confondre fait entrer au résultat une charge qui n'a
	 * pas lieu d'être — et un terrain amorti sur vingt ans, cela se voit.
	 */
	?>
	<table class="table">
		<thead><tr><th>Immobilisation</th><th style="width:100px">Compte</th><th>Pourquoi</th></tr></thead>
		<tbody>
		<?php foreach ( $audit['non_amortissables'] as $x ) : ?>
			<tr>
				<td><?= e( $x['libelle'] ) ?></td>
				<td class="code"><?= e( $x['compte_immo'] ) ?></td>
				<td class="muted"><?= e( $x['motif'] ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>

<div class="card card-flush">
	<div class="card-head">
		<h2>Table de correspondance</h2>
		<span class="muted"><?= count( $table ) ?> comptes d'immobilisation</span>
	</div>
	<table class="table">
		<thead><tr>
			<th style="width:90px">Bien</th><th>Nature</th>
			<th style="width:95px">Amortissement</th><th style="width:95px">Dépréciation</th>
			<th style="width:90px">Dotation</th><th style="width:110px">Origine</th><th style="width:90px"></th>
		</tr></thead>
		<tbody>
		<?php
		$origines = array(
			'regle' => array( 'Miroir 28/29', 'var(--muted)' ),
			'regle_elargie' => array( 'Poste principal', 'var(--muted)' ),
			'exception' => array( 'Exception', 'var(--orange)' ),
			'non_amortissable' => array( 'Non amortissable', 'var(--orange)' ),
			'societe' => array( '✎ Racine', 'var(--ok)' ),
			'sous_racine' => array( '✎ Sous-racine', 'var(--ok)' ),
			'exacte' => array( '✎ Compte exact', 'var(--ok)' ),
		);
		foreach ( $table as $racine => $m ) :
			list( $oLab, $oCol ) = $origines[ $m['source'] ] ?? array( $m['source'], 'var(--muted)' );
		?>
			<tr>
				<td class="code"><?= e( $racine ) ?>000</td>
				<td><?= e( $m['libelle_immo'] ) ?></td>
				<td class="code"><?= $m['amortissement'] ? e( $m['amortissement'] ) : '<span class="muted">—</span>' ?></td>
				<td class="code muted"><?= $m['depreciation'] ? e( $m['depreciation'] ) : '—' ?></td>
				<td class="code muted"><?= $m['dotation'] ? e( $m['dotation'] ) : '—' ?></td>
				<td><span class="muted" style="font-size:.85em;color:<?= e( $oCol ) ?>" title="<?= e( $m['motif'] ) ?>"><?= e( $oLab ) ?></span></td>
				<td class="right">
					<details><summary class="muted" style="cursor:pointer;font-size:.85em">Changer</summary>
						<form method="post" action="<?= e( url( 'comptabilite/immobilisations/comptes' ) ) ?>" style="margin-top:6px">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="racine" value="<?= e( $racine ) ?>">
							<input class="code" name="amortissement" style="width:90px" value="<?= e( (string) $m['amortissement'] ) ?>" placeholder="28xxxx">
							<input class="code" name="depreciation" style="width:90px" value="<?= e( (string) $m['depreciation'] ) ?>" placeholder="29xxxx">
							<button class="btn btn-ghost btn-sm" type="submit">Enregistrer</button>
							<small class="help">Videz le champ pour revenir à la règle du référentiel.</small>
						</form>
					</details>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
