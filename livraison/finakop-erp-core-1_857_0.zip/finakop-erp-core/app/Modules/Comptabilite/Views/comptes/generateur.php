<?php /** @var string $pack @var string $packLabel @var array $axes @var array $journaux @var array $metier @var array $socle @var int $nbOfficiels @var array $ecritures @var array $audit @var array|null $derniere @var string|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card card-flush">
	<div class="card-head">
		<h2>Générateur de dossier comptable</h2>
		<span class="muted">Métier actif : <strong><?= e( $packLabel ) ?></strong></span>
	</div>
	<div style="padding:12px;line-height:1.7">
		Le plan comptable de FinaKop tient sur <strong>deux niveaux</strong>. Le premier est le
		<strong>SYSCOHADA révisé officiel</strong> — <?= (int) $nbOfficiels ?> comptes dont ni le numéro ni l'intitulé
		réglementaire ne sont modifiables. Le second est la <strong>bibliothèque de subdivisions FinaKop</strong>,
		ouverte automatiquement selon le métier : chaque subdivision se rattache obligatoirement à un compte
		du premier niveau, de sorte que la liasse, la balance et les états DGI continuent d'agréger correctement.
		<br><br>
		Générer est <strong>additif et sans effet de bord</strong> : aucun compte existant n'est renommé, aucun journal
		dupliqué, aucune écriture déplacée. On peut donc relancer l'opération sur un dossier vivant chaque fois que
		la bibliothèque s'enrichit.
	</div>
	<div style="padding:0 12px 14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
		<form method="post" action="<?= e( url( 'comptabilite/plan/generer' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-primary" type="submit">⚙️ Générer le dossier pour « <?= e( $packLabel ) ?> »</button>
		</form>
		<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/comptes' ) ) ?>">Voir le plan comptable →</a>
		<?php if ( $derniere ) : ?>
			<span class="muted" style="font-size:.85em">Dernière génération : <?= e( $derniere['date'] ?? '' ) ?>
				(pack <?= e( $derniere['pack'] ?? '' ) ?>)</span>
		<?php endif; ?>
	</div>
</div>

<div class="form-grid">
	<div class="card card-flush">
		<div class="card-head"><h2>Ce que le métier pose</h2><span class="muted">9 étapes</span></div>
		<table class="table">
			<thead><tr><th>Étape</th><th class="num">Éléments</th><th>Source</th></tr></thead>
			<tbody>
				<tr><td>Plan comptable — niveau 1 (OHADA)</td><td class="num"><?= (int) $nbOfficiels ?></td><td class="muted">Référentiel réglementaire</td></tr>
				<tr><td>Plan comptable — niveau 2 (métier)</td><td class="num"><?= count( $socle ) + count( $metier ) ?></td><td class="muted">Bibliothèque FinaKop + pack</td></tr>
				<tr><td>Journaux</td><td class="num"><?= count( $journaux ) ?></td><td class="muted">Socle + journaux du métier</td></tr>
				<tr><td>Taxes et barèmes</td><td class="num">—</td><td class="muted">Configuration fiscale (DGI)</td></tr>
				<tr><td>Axes analytiques</td><td class="num"><?= count( $axes ) ?></td><td class="muted">Référentiel transverse du métier</td></tr>
				<tr><td>Modèles d'écritures</td><td class="num"><?= count( $ecritures ) ?></td><td class="muted">Événements comptables du métier</td></tr>
				<tr><td>KPI et tableaux de bord</td><td class="num">—</td><td class="muted">Cockpits par capacité</td></tr>
				<tr><td>Workflows</td><td class="num">—</td><td class="muted">Définitions du pack</td></tr>
				<tr><td>Modèles de documents</td><td class="num">—</td><td class="muted">Jeu de pièces du métier</td></tr>
			</tbody>
		</table>
	</div>

	<div class="card card-flush">
		<div class="card-head"><h2>Axes analytiques du métier</h2><span class="muted"><?= count( $axes ) ?> axes</span></div>
		<?php
		/*
		 * Les axes répondent à une question que le plan comptable ne pose pas.
		 * Le compte dit DE QUELLE NATURE est un montant ; l'axe dit POUR QUI et
		 * POUR QUOI. Une même écriture d'honoraires se ventile sur l'artiste,
		 * l'album et la campagne — trois lectures d'un seul chiffre.
		 */
		?>
		<div style="padding:12px;display:flex;gap:6px;flex-wrap:wrap">
			<?php foreach ( $axes as $a ) : ?>
				<span class="tag" title="<?= e( $a[0] ) ?>"><?= e( $a[1] ) ?></span>
			<?php endforeach; ?>
		</div>
		<div style="padding:0 12px 12px" class="muted">
			Chaque écriture peut être ventilée sur plusieurs de ces axes ; le module Analytique et le
			Cockpit de Direction les exploitent sans configuration supplémentaire.
		</div>
	</div>
</div>

<?php if ( ! empty( $ecritures ) ) : ?>
<div class="card card-flush">
	<div class="card-head">
		<h2>Modèles d'écritures</h2>
		<span class="muted"><?= count( $ecritures ) ?> événements — la comptabilité comme conséquence du geste métier</span>
	</div>
	<?php
	/*
	 * Ces schémas existent pour qu'un écran métier n'écrive jamais d'écriture
	 * lui-même : il émet un événement, le moteur applique le modèle. Sans eux,
	 * un gérant saisissait sa recette dans la caisse puis la ressaisissait au
	 * journal — le meilleur moyen de faire diverger deux chiffres qui devraient
	 * être le même.
	 */
	?>
	<table class="table">
		<thead><tr><th style="width:220px">Événement</th><th>Écriture produite</th><th style="width:80px">Journal</th></tr></thead>
		<tbody>
		<?php foreach ( $ecritures as $evt => $sch ) :
			$n = count( (array) ( $sch['lignes'] ?? array() ) );
			$c = 0;
			foreach ( (array) ( $sch['conditionnel'] ?? array() ) as $b ) { $c += count( (array) ( $b['lignes'] ?? array() ) ); }
		?>
			<tr>
				<td class="code"><?= e( $evt ) ?></td>
				<td><?= e( (string) ( $sch['libelle'] ?? '' ) ) ?>
					<span class="muted" style="font-size:.85em">— <?= (int) $n ?> ligne(s)<?= $c ? ' + ' . (int) $c . ' conditionnelle(s)' : '' ?></span></td>
				<td class="code muted"><?= e( (string) ( $sch['journal'] ?? 'OD' ) ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>

<?php if ( ! empty( $metier ) ) : ?>
<div class="card card-flush">
	<div class="card-head"><h2>Subdivisions du métier</h2><span class="muted"><?= count( $metier ) ?> comptes, tous rattachés au référentiel</span></div>
	<table class="table">
		<thead><tr><th style="width:110px">N°</th><th>Libellé métier</th><th style="width:110px">Rattaché à</th><th>Compte OHADA parent</th></tr></thead>
		<tbody>
		<?php foreach ( $metier as $num => $lib ) :
			$par = FKC_PlanSyscohada::parentOfficiel( $num ); ?>
			<tr>
				<td class="code"><?= e( $num ) ?></td>
				<td><?= e( $lib ) ?></td>
				<td class="code muted"><?= e( $par ?: '—' ) ?></td>
				<td class="muted"><?= e( $par ? ( FKC_PlanSyscohada::libelle( $par ) ?: '' ) : 'Aucun — serait refusé' ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>

<?php
/*
 * AUDIT DU PLAN — DEUX NIVEAUX, PARCE QU'ILS NE VOIENT PAS LA MÊME CHOSE.
 *
 * Le niveau NUMÉRIQUE trouve un numéro portant plusieurs sens : c'est ce qui
 * casse une balance consolidée, puisqu'elle additionne par numéro.
 *
 * Le niveau SÉMANTIQUE trouve l'inverse — plusieurs numéros pour un même sens.
 * Le premier niveau n'y voit rien, chaque numéro étant cohérent avec lui-même.
 * C'est pourtant le même défaut vu de l'autre côté : le plan enfle de comptes
 * qui font double emploi, et une consolidation les affiche sur deux lignes que
 * personne ne sait devoir additionner.
 *
 * Le cas des CLÉS ÉCRASÉES est à part : deux fois le même numéro dans un même
 * pack, PHP garde la dernière en silence, et le compte perdu n'apparaît nulle
 * part — pas même dans le niveau numérique, qui lit le tableau déjà évalué.
 */
$ap = (array) ( $auditPlan ?? array() );
$nbN = count( $ap['numerique'] ?? array() );
$nbC = count( $ap['cles'] ?? array() );
$nbS = count( $ap['semantique'] ?? array() );
?>
<?php if ( $nbN || $nbC || $nbS ) : ?>
<div class="card card-flush" style="margin-bottom:14px">
	<div class="card-head"><h2>Audit du référentiel</h2>
		<span class="muted"><?= (int) ( $nbN + $nbC + $nbS ) ?> point(s)</span></div>
	<table class="table">
		<thead><tr><th style="width:150px">Niveau</th><th>Constat</th><th>Comptes</th></tr></thead>
		<tbody>
		<?php foreach ( (array) ( $ap['cles'] ?? array() ) as $c ) : ?>
			<tr>
				<td><span class="tag" style="background:rgba(244,63,94,.14);color:#f43f5e">CLÉ ÉCRASÉE</span></td>
				<td>Déclaré deux fois dans le pack <strong><?= e( $c['pack'] ) ?></strong> : PHP ne garde que le dernier, l'autre compte n'existe pas.</td>
				<td><span class="code"><?= e( $c['numero'] ) ?></span><br><span class="muted" style="font-size:.85em"><?= e( implode( ' | ', $c['libelles'] ) ) ?></span></td>
			</tr>
		<?php endforeach; ?>
		<?php foreach ( (array) ( $ap['numerique'] ?? array() ) as $num => $sens ) : ?>
			<tr>
				<td><span class="tag" style="background:rgba(240,170,60,.14);color:var(--orange)">NUMÉRIQUE</span></td>
				<td>Un même numéro pour <?= count( $sens ) ?> significations : une balance consolidée les additionnerait.</td>
				<td><span class="code"><?= e( $num ) ?></span></td>
			</tr>
		<?php endforeach; ?>
		<?php foreach ( (array) ( $ap['semantique'] ?? array() ) as $d ) : ?>
			<tr>
				<td><span class="tag" style="background:rgba(96,165,250,.14);color:#60a5fa">SÉMANTIQUE</span></td>
				<td>
					« <?= e( $d['libelle'] ) ?> » existe sous <?= count( $d['numeros'] ) ?> numéros.
					<?php if ( ! empty( $d['meme_racine'] ) ) : ?>
						<span class="muted">Même racine : la fusion est sûre.</span>
					<?php else : ?>
						<span class="muted">Racines différentes : la nature diffère peut-être, à trancher.</span>
					<?php endif; ?>
				</td>
				<td class="code"><?= e( implode( ', ', $d['numeros'] ) ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>
<?php if ( ! empty( $audit['divergences'] ) ) : ?>
<div class="card card-flush">
	<div class="card-head">
		<h2>Comptes non conformes au SYSCOHADA révisé</h2>
		<span class="muted"><?= count( $audit['divergences'] ) ?> à arbitrer</span>
	</div>
	<?php
	/*
	 * On SIGNALE, on ne corrige pas d'office. Un compte porte des écritures,
	 * des lettrages et des états déjà déposés : le renuméroter dans le dos du
	 * comptable modifierait rétroactivement des exercices clos. Seuls les
	 * comptes VIERGES peuvent être basculés d'un clic ; les autres appellent un
	 * virement daté, décidé par un humain.
	 */
	?>
	<div style="padding:12px" class="muted">
		Ces comptes portent un numéro qui désigne autre chose dans le référentiel : leurs montants tombent
		dans la mauvaise rubrique de la liasse. Les comptes vierges peuvent être basculés immédiatement ;
		ceux qui portent des écritures demandent un virement daté, décidé par le comptable.
	</div>
	<?php
	/*
	 * BOUTON DE MASSE — il ne peut rien faire de plus que les boutons de ligne.
	 *
	 * Il enchaîne corrigerSiVierge() sur chaque compte non conforme, ce qui
	 * signifie qu'un compte mouvementé sera refusé ici exactement comme il le
	 * serait un par un. Le libellé le dit à l'avance : il annonce combien de
	 * comptes sont réellement concernés, pour que personne ne clique en croyant
	 * assainir la totalité.
	 */
	$vierges = 0; $bloques = 0;
	foreach ( $audit['divergences'] as $d ) {
		if ( (int) $d['ecritures'] > 0 ) { $bloques++; } else { $vierges++; }
	}
	?>
	<?php if ( $vierges > 0 ) : ?>
	<div style="padding:0 12px 12px">
		<form method="post" action="<?= e( url( 'comptabilite/plan/corriger' ) ) ?>"
			onsubmit="return confirm('Désactiver <?= (int) $vierges ?> compte(s) non conforme(s) et vierge(s) ?\n\nLes comptes qui portent des écritures ne seront pas touchés.');">
			<input type="hidden" name="tout" value="1">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-primary" type="submit">
				Désactiver les <?= (int) $vierges ?> compte(s) vierge(s)
			</button>
			<?php if ( $bloques > 0 ) : ?>
				<span class="muted" style="margin-left:10px">
					<?= (int) $bloques ?> compte(s) resteront : ils portent des écritures.
				</span>
			<?php endif; ?>
		</form>
	</div>
	<?php endif; ?>
	<table class="table">
		<thead><tr><th style="width:100px">Actuel</th><th>Libellé livré</th><th style="width:100px">Correct</th><th>Ce que dit le référentiel</th><th class="num" style="width:90px">Écritures</th><th style="width:110px"></th></tr></thead>
		<tbody>
		<?php foreach ( $audit['divergences'] as $d ) : ?>
			<tr>
				<td class="code" style="color:var(--danger)"><?= e( $d['numero'] ) ?></td>
				<td><?= e( $d['libelle'] ) ?></td>
				<td class="code" style="color:var(--ok)"><?= e( $d['correct'] ) ?></td>
				<td class="muted" style="font-size:.88em"><?= e( $d['raison'] ) ?></td>
				<td class="num"><?= (int) $d['ecritures'] ?></td>
				<td class="right">
					<?php if ( 0 === (int) $d['ecritures'] ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/plan/corriger' ) ) ?>"
							onsubmit="return confirm('Désactiver <?= e( $d['numero'] ) ?> au profit de <?= e( $d['correct'] ) ?> ?')">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="numero" value="<?= e( $d['numero'] ) ?>">
							<button class="btn btn-ghost btn-sm" type="submit">Basculer</button>
						</form>
					<?php else : ?>
						<?php
						/*
						 * BASCULE ASSISTÉE. « Virement requis » énonçait le
						 * problème et laissait l'utilisateur avec : il fallait
						 * calculer le solde, choisir le sens, saisir l'écriture
						 * à la main — et rien ne garantissait qu'il le fasse.
						 * Le bouton propose l'écriture ; il ne la passe qu'après
						 * confirmation, et le sens est déduit du solde réel.
						 */
						$prep = FKC_PlanAudit::preparerVirement( $d['numero'] );
						?>
						<?php if ( ! empty( $prep['ok'] ) && 'virer' === $prep['action'] ) : ?>
							<form method="post" action="<?= e( url( 'comptabilite/plan/virer' ) ) ?>"
								onsubmit="return confirm('<?= e( $prep['message'] ) ?>\n\nUne écriture datée du <?= e( $prep['date'] ) ?> sera passée au journal OD, puis <?= e( $d['numero'] ) ?> sera désactivé.\n\nContinuer ?');">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="numero" value="<?= e( $d['numero'] ) ?>">
								<button class="btn btn-ghost btn-sm" type="submit"
									title="<?= e( $prep['message'] ) ?>">Virer le solde</button>
							</form>
						<?php elseif ( ! empty( $prep['ok'] ) && 'desactiver' === $prep['action'] ) : ?>
							<form method="post" action="<?= e( url( 'comptabilite/plan/virer' ) ) ?>"
								onsubmit="return confirm('Ce compte est déjà soldé : aucune écriture ne sera passée, il sera simplement désactivé.');">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="numero" value="<?= e( $d['numero'] ) ?>">
								<button class="btn btn-ghost btn-sm" type="submit"
									title="Déjà soldé — aucune écriture nécessaire">Désactiver</button>
							</form>
						<?php else : ?>
							<span class="muted" style="font-size:.82em"
								title="<?= e( $prep['message'] ?? '' ) ?>">Virement manuel requis</span>
						<?php endif; ?>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>

<?php if ( ! empty( $audit['orphelins'] ) ) : ?>
<div class="card card-flush">
	<div class="card-head"><h2>Comptes sans rattachement</h2><span class="muted"><?= count( $audit['orphelins'] ) ?></span></div>
	<div style="padding:12px" class="muted">
		Ces comptes ne se rattachent à aucun compte du référentiel : leurs montants n'apparaissent dans
		aucune rubrique des états financiers.
	</div>
	<table class="table">
		<thead><tr><th style="width:110px">N°</th><th>Libellé</th><th class="num" style="width:90px">Écritures</th></tr></thead>
		<tbody>
		<?php foreach ( array_slice( $audit['orphelins'], 0, 20 ) as $o ) : ?>
			<tr><td class="code"><?= e( $o['numero'] ) ?></td><td><?= e( $o['libelle'] ) ?></td><td class="num"><?= (int) $o['ecritures'] ?></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endif; ?>
