<?php /** @var array|null $compte @var array $errors @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'comptabilite', 'back' => 'comptabilite/comptes', 'backLabel' => 'Plan comptable' ) );
$edit = (bool) $compte; ?>
<div class="bar"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/comptes' ) ) ?>">← Plan comptable</a></div>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:560px">
	<div class="card-head"><h2><?= $edit ? 'Modifier le compte' : 'Nouveau compte' ?></h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( $edit ? url( 'comptabilite/comptes/' . $compte['id'] ) : url( 'comptabilite/comptes' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Numéro de compte (SYSCOHADA)</span>
				<input type="text" class="code" name="numero" value="<?= e( $edit ? $compte['numero'] : old( 'numero' ) ) ?>" <?= $edit ? 'readonly' : 'placeholder="411000"' ?>>
			</label>
			<p class="help">Classe 1 à 8. Ex : 411 (Clients), 601 (Achats), 521 (Banque).</p>
			<label class="fld"><span>Libellé</span>
				<input type="text" name="libelle" value="<?= e( $edit ? $compte['libelle'] : old( 'libelle' ) ) ?>" required></label>
			<label class="fld"><span>Type</span>
				<select name="type">
					<?php foreach ( array( 'detail'=>'Compte de détail','collectif'=>'Compte collectif','centralisateur'=>'Centralisateur' ) as $v => $lbl ) : ?>
						<option value="<?= e( $v ) ?>" <?= ( $edit && $compte['type'] === $v ) ? 'selected' : '' ?>><?= e( $lbl ) ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<div class="actions">
				<button class="btn btn-primary" type="submit"><?= $edit ? 'Enregistrer' : 'Créer le compte' ?></button>
				<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/comptes' ) ) ?>">Annuler</a>
			</div>
		</form>
		<?php if ( $edit ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/comptes/' . $compte['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ce compte ?')" style="margin-top:14px">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-ghost btn-sm danger" type="submit">Supprimer ce compte</button>
		</form>
		<?php endif; ?>
	</div>
</div>
