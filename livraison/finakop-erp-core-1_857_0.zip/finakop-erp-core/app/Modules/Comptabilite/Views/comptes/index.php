<?php /** @var array $comptes @var string|null $flash @var string $tab @var int $total @var int $cl @var string $edition @var string $pack @var array $audit @var array $classement @var array $statutsConnus @var array $statuts */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$classes = FKC_PlanComptable::classes();
$grouped = array(); $present = array();
foreach ( $comptes as $c ) { $grouped[ (int) $c['classe'] ][] = $c; }
$editionLabel = 'creative' === $edition ? 'adapté Industrie Musicale / Label (Creative Suite)' : 'édition Core';
/*
 * Le plan se lit désormais sur DEUX NIVEAUX, et l'écran doit le montrer :
 * sans distinction visible, l'utilisateur ne sait pas ce qu'il a le droit de
 * renommer. Un compte réglementaire porte un cadenas ; une subdivision métier
 * ou maison s'édite librement.
 */
$badgeOrigine = function ( $c ) {
	$o = (string) ( $c['origine'] ?? 'societe' );
	if ( 'ohada' === $o ) { return array( '🔒 OHADA', 'background:rgba(70,130,200,.16);color:var(--blue)', 'Référentiel réglementaire — intitulé non modifiable' ); }
	if ( 'finakop' === $o ) { return array( '◆ Métier', 'background:rgba(240,170,60,.14);color:var(--orange)', 'Subdivision FinaKop du pack ' . (string) ( $c['pack'] ?? '' ) ); }
	return array( '✎ Maison', 'background:var(--ok-bg);color:var(--ok)', 'Compte créé par la société' );
};
$clsPresentes = FKC_DB::q( 'SELECT DISTINCT classe FROM comptes ORDER BY classe' )->fetchAll( PDO::FETCH_COLUMN );
?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div class="alert" style="background:rgba(70,130,200,.12);color:var(--text);border:1px solid rgba(70,130,200,.35)">
	ℹ️ Plan comptable <strong>SYSCOHADA révisé</strong> — <?= (int) $total ?> comptes ·
	<strong><?= (int) ( $audit['ohada'] ?? 0 ) ?></strong> réglementaires (verrouillés),
	<strong><?= (int) ( $audit['metier'] ?? 0 ) ?></strong> subdivisions métier,
	<strong><?= (int) ( $audit['societe'] ?? 0 ) ?></strong> propres à la société ·
	métier actif : <strong><?= e( $pack ) ?></strong>
</div>
<?php
/*
 * SYNTHÈSE DES QUATRE STATUTS.
 *
 * L'audit ne sert à rien s'il faut parcourir mille comptes pour le lire. La
 * barre ci-dessous donne le volume par statut ; la colonne du tableau donne
 * le détail compte par compte. Rien n'est corrigé automatiquement : un compte
 * qui porte des écritures ne se bascule pas sans arbitrage.
 */
$sc = $statutsConnus;
?>
<?php if ( ! empty( $classement['total'] ) ) : ?>
<div class="card" style="margin-bottom:14px">
	<div class="card-head"><h2>Audit du plan</h2><span class="muted"><?= (int) ( $classement['a_arbitrer'] ?? 0 ) ?> à arbitrer sur <?= (int) $classement['total'] ?> comptes actifs</span></div>
	<div class="card-body" style="display:flex;gap:18px;flex-wrap:wrap">
		<?php foreach ( $sc as $cle => $def ) : $n = (int) ( $classement['par_statut'][ $cle ] ?? 0 ); ?>
		<span title="<?= e( $def[2] ) ?>" style="display:flex;align-items:center;gap:7px">
			<span style="display:inline-block;width:11px;height:11px;border-radius:50%;background:<?= e( $def[1] ) ?>"></span>
			<strong><?= $n ?></strong> <span class="muted"><?= e( $def[0] ) ?></span>
		</span>
		<?php endforeach; ?>
	</div>
</div>
<?php endif; ?>
<?php if ( ! empty( $audit['divergences'] ) ) : ?>
<div class="alert alert-warn">
	⚠️ <strong><?= count( $audit['divergences'] ) ?> compte(s)</strong> portent un numéro qui ne correspond pas au SYSCOHADA
	révisé : leurs montants ne remontent pas dans la bonne rubrique des états financiers.
	<a href="<?= e( url( 'comptabilite/plan/generateur' ) ) ?>">Voir le détail et arbitrer →</a>
</div>
<?php endif; ?>

<div class="bar">
	<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
		<a class="tag" style="text-decoration:none;<?= 0 === $cl ? 'background:var(--orange);color:#241500' : '' ?>" href="<?= e( url( 'comptabilite/comptes' ) ) ?>">Toutes</a>
		<?php foreach ( $clsPresentes as $k ) : ?>
			<a class="tag" style="text-decoration:none;<?= $cl === (int) $k ? 'background:var(--orange);color:#241500' : '' ?>" href="<?= e( url( 'comptabilite/comptes?cl=' . (int) $k ) ) ?>" title="<?= e( $classes[ (int) $k ] ?? '' ) ?>">Cl.<?= (int) $k ?></a>
		<?php endforeach; ?>
	</div>
	<span style="display:flex;gap:8px"><a class="btn btn-ghost" href="<?= e( url( 'comptabilite/plan/purge' ) ) ?>" title="Doublons, comptes désactivés, comptes remplacés et jamais utilisés">🧹 Purge du plan</a><a class="btn btn-ghost" href="<?= e( url( 'comptabilite/comptes/export' . ( $cl ? '?cl=' . (int) $cl : '' ) ) ) ?>">⬇ Export CSV</a><a class="btn btn-primary" href="<?= e( url( 'comptabilite/comptes/nouveau' ) ) ?>">+ Nouveau compte</a></span>
</div>

<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Rechercher : n° de compte, libellé…' ) ); ?>

<?php foreach ( $classes as $k => $lab ) : if ( empty( $grouped[ $k ] ) ) { continue; } ?>
<div class="card card-flush" style="margin-bottom:14px">
	<div class="card-head"><h2>Classe <?= (int) $k ?> — <?= e( $lab ) ?></h2>
		<span class="muted"><?= count( $grouped[ $k ] ) ?> comptes</span></div>
	<table class="table">
		<thead><tr><th style="width:120px">N° compte</th><th>Libellé</th><th style="width:110px">Rattaché à</th><th style="width:110px">Origine</th><th style="width:120px">Statut</th><th style="width:100px">Nature</th><th style="width:170px">Action</th><th style="width:120px"></th></tr></thead>
		<tbody>
		<?php foreach ( $grouped[ $k ] as $c ) :
			$nat = FKC_PlanSyscohada::nature( $c['numero'] );
			list( $bLab, $bStyle, $bTitre ) = $badgeOrigine( $c );
			$par = (string) ( $c['parent'] ?? '' );
			$verr = ! empty( $c['verrouille'] ) || 'ohada' === ( $c['origine'] ?? '' );
			/*
			 * STATUT — proposition, jamais verdict.
			 *
			 * La pastille dit ce que le compte a l'air d'être, pas ce qu'il faut
			 * en faire. Un compte STANDARD qui porte trois ans d'écritures ne se
			 * bascule pas parce qu'un classificateur l'a rangé quelque part :
			 * c'est le rôle de l'infobulle de donner le motif, et celui du
			 * comptable de trancher.
			 */
			$st = $statuts[ (string) $c['numero'] ] ?? null;
			$stDef = $st ? ( $statutsConnus[ $st['statut'] ] ?? null ) : null;
		?>
			<tr<?= empty( $c['actif'] ) ? ' style="opacity:.5"' : '' ?>>
				<td><span class="code"><?= e( $c['numero'] ) ?></span><?= empty( $c['actif'] ) ? ' <span class="muted" style="font-size:.8em">(inactif)</span>' : '' ?></td>
				<td><?= e( $c['libelle'] ) ?></td>
			<?php
			/*
			 * « RATTACHÉ À » NE DOIT PAS AFFICHER « — » SUR LES RUBRIQUES DE TÊTE.
			 *
			 * Les 79 comptes à deux chiffres (11 Réserves, 21 Immobilisations
			 * incorporelles, 40 Fournisseurs…) n'ont pas de parent parce qu'ils
			 * SONT le tronc : leur seul ascendant est la classe, que le
			 * référentiel ne matérialise pas comme un compte. Un tiret à cet
			 * endroit se lit comme un défaut de rattachement, et poussait à
			 * chercher une anomalie là où il n'y en a pas.
			 */
			$rattache = $par;
			if ( '' === $rattache ) {
				$racine = rtrim( (string) $c['numero'], '0' );
				if ( strlen( $racine ) <= 2 ) {
					$rattache = 'Classe ' . (int) $c['classe'];
				}
			}
			?>
				<td class="muted code" style="font-size:.85em"><?= $rattache ? e( $rattache ) : '—' ?></td>
				<td><span class="tag" style="<?= e( $bStyle ) ?>" title="<?= e( $bTitre ) ?>"><?= e( $bLab ) ?></span></td>
				<td>
					<?php if ( $stDef ) : ?>
						<span title="<?= e( $stDef[2] . ' — ' . $st['motif'] ) ?>" style="white-space:nowrap;font-size:.82em">
							<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:<?= e( $stDef[1] ) ?>;margin-right:5px"></span><?= e( $stDef[0] ) ?>
						</span>
					<?php else : ?><span class="muted">—</span><?php endif; ?>
				</td>
				<td><span class="tag" style="<?= 'BILAN' === $nat ? 'background:rgba(240,170,60,.14);color:var(--orange)' : 'background:var(--ok-bg);color:var(--ok)' ?>"><?= e( $nat ) ?></span></td>
				<?php
				/*
				 * UN VERDICT SANS GESTE POSSIBLE EST PIRE QUE PAS DE VERDICT.
				 *
				 * La colonne Statut rangeait des comptes en DOUBLON ou en
				 * STANDARD sans qu'aucun bouton ne puisse les traiter : la
				 * correction ne consultait qu'une liste fermée de divergences
				 * héritées. L'avertissement revenait à chaque ouverture, sans
				 * issue — de quoi cesser de lire toutes les alertes.
				 *
				 * Le geste dépend du solde, pas du statut : un compte vierge se
				 * désactive, un compte mouvementé demande un virement daté.
				 */
				$act = ( $st && ! empty( $st['actionnable'] ) );
				?>
				<td class="right">
					<?php if ( $act && 0 === (int) ( $st['ecritures'] ?? 0 ) ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/plan/corriger' ) ) ?>"
							onsubmit="return confirm('Désactiver <?= e( $c['numero'] ) ?> au profit de <?= e( $st['cible'] ) ?> ?\n\nCe compte est vierge : aucune écriture ne sera passée.');">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="numero" value="<?= e( $c['numero'] ) ?>">
							<button class="btn btn-ghost btn-sm" type="submit"
								title="<?= e( $st['motif'] ) ?>">Fusionner dans <?= e( $st['cible'] ) ?></button>
						</form>
					<?php elseif ( $act ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/plan/virer' ) ) ?>"
							onsubmit="return confirm('Virer le solde de <?= e( $c['numero'] ) ?> vers <?= e( $st['cible'] ) ?> ?\n\nCe compte porte <?= (int) $st['ecritures'] ?> ligne(s) : une écriture datée du jour sera passée, puis le compte sera désactivé.');">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="numero" value="<?= e( $c['numero'] ) ?>">
							<button class="btn btn-ghost btn-sm" type="submit"
								title="<?= e( $st['motif'] ) ?> — <?= (int) $st['ecritures'] ?> écriture(s)">Virer vers <?= e( $st['cible'] ) ?></button>
						</form>
					<?php endif; ?>
				</td>
				<td class="right">
					<?php if ( $verr ) : ?>
						<span class="muted" style="font-size:.85em" title="Le référentiel réglementaire n'est pas modifiable ; créez une subdivision sous ce compte.">Réglementaire</span>
					<?php else : ?>
						<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/comptes/' . $c['id'] . '/modifier' ) ) ?>">Éditer</a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<?php endforeach; ?>
<?php if ( ! $comptes ) : ?><div class="card"><div class="card-body empty">Aucun compte pour ce filtre.</div></div><?php endif; ?>
