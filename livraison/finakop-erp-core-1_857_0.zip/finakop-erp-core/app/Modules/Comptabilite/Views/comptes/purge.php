<?php /** @var array $analyse @var array $verdicts @var array $motifs @var array $simulation @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$r = $analyse['resume'];
$cls = array( 'supprimable' => 'b-err', 'a_virer' => 'b-off', 'a_desactiver' => 'b-off', 'protege' => 'b-on' );
$mot = array( 'doublon' => '⧉', 'desactive' => '⊘', 'remplace' => '↪', 'inutilise' => '∅' );
?>
<?php if ( $flash ) : ?><div class="alert <?= false !== strpos( (string) $flash, '⚠️' ) ? 'alert-warn' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:4px">
	<h1 style="font-size:20px">Purge du plan comptable</h1>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/comptes' ) ) ?>">← Plan comptable</a>
</div>
<p class="muted" style="font-size:13px;margin-bottom:16px">
	<?= (int) $analyse['total'] ?> comptes analysés — doublons, comptes désactivés, comptes mal imputés remplacés depuis,
	et comptes jamais utilisés hors référentiel.
</p>

<?php /* La limite est dite AVANT les boutons : un plan comptable n'est pas une liste de préférences. */ ?>
<div class="card" style="margin-bottom:16px"><div class="card-body">
	<strong style="font-size:13px">Ce qu'une purge peut faire, et ce qu'elle ne peut pas</strong>
	<ul style="margin:8px 0 0;padding-left:20px;font-size:13px;line-height:1.75">
		<li><strong>Un compte mouvementé ne s'efface pas.</strong> Ses lignes d'écriture pointent son identifiant : le supprimer laisse un grand livre qui cite un compte introuvable et une balance qui ne boucle plus. On vire son solde vers le bon compte, puis on le désactive.</li>
		<li><strong>Un compte du référentiel ne s'efface pas utilement.</strong> Le plan se resynchronise à chaque affichage : il réapparaîtrait au rechargement suivant. On le désactive, ce qui le sort de la saisie et des états.</li>
		<li><strong>Un compte référencé ailleurs ne s'efface pas.</strong> Compte de trésorerie, caisse ou paramètre d'imputation : le mécanisme qui s'appuie dessus casserait en silence.</li>
	</ul>
	<p class="help" style="margin:8px 0 0">Ne sont réellement supprimés que les comptes qui ne sont rien de tout cela. <strong>Leur disparition ne change aucun solde.</strong></p>
</div></div>

<div class="kpis" style="margin-bottom:16px">
	<?php foreach ( $verdicts as $k => $v ) : ?>
		<div class="kpi"><span class="muted"><?= e( $v[0] ) ?></span><strong style="font-size:20px"><?= (int) ( $r[ $k ] ?? 0 ) ?></strong></div>
	<?php endforeach; ?>
</div>

<div class="form-rows" style="margin-bottom:16px">
	<div class="card"><div class="card-head"><h2>Supprimer définitivement</h2></div><div class="card-body">
		<?php if ( empty( $simulation['supprimes'] ) ) : ?>
			<p class="muted" style="font-size:13px;margin:0">Aucun compte n'est supprimable en l'état. C'est un bon signe : rien ne traîne.</p>
		<?php else : ?>
			<p style="font-size:13px"><strong><?= count( $simulation['supprimes'] ) ?> compte(s)</strong> seraient effacés du plan. Aucun ne porte d'écriture, aucun n'est cité ailleurs.</p>
			<div style="max-height:180px;overflow:auto;font-size:12px;margin-bottom:10px">
				<?php foreach ( $simulation['supprimes'] as $c ) : ?>
					<div><span class="code"><?= e( $c['numero'] ) ?></span> <?= e( $c['libelle'] ) ?>
						<span class="muted"><?php foreach ( $c['motifs'] as $m ) { echo ' ' . ( $mot[ $m ] ?? '' ); } ?></span></div>
				<?php endforeach; ?>
			</div>
			<?php /* Saisie du mot de confirmation : une action irréversible sur le plan comptable ne doit pas tenir à un seul clic. */ ?>
			<form method="post" action="<?= e( url( 'comptabilite/plan/purge/executer' ) ) ?>" onsubmit="return confirm('Suppression définitive et irréversible. Confirmer ?')">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Saisissez <strong>SUPPRIMER</strong> pour confirmer</span><input name="confirmation" placeholder="SUPPRIMER" autocomplete="off" required></label>
				<div class="actions"><button class="btn btn-danger">Supprimer définitivement</button></div>
			</form>
		<?php endif; ?>
	</div></div>

	<div class="card"><div class="card-head"><h2>Désactiver les comptes soldés</h2></div><div class="card-body">
		<p style="font-size:13px"><strong><?= (int) ( $r['a_desactiver'] ?? 0 ) ?> compte(s)</strong> portent des écritures sans compte cible : ils ne peuvent pas être effacés, mais n'ont plus à être proposés à la saisie.</p>
		<p class="help">Un compte dont le solde n'est pas nul reste actif : le désactiver le rendrait invisible avec de l'argent dessus. Virez d'abord son solde depuis l'écran du plan comptable.</p>
		<form method="post" action="<?= e( url( 'comptabilite/plan/purge/desactiver' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="actions"><button class="btn btn-primary">Désactiver les comptes soldés</button></div>
		</form>
	</div></div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Détail (<?= count( $analyse['comptes'] ) ?>)</h2></div>
	<table class="table"><thead><tr><th>Compte</th><th>Intitulé</th><th>Motif</th><th class="num">Écritures</th><th>Cible</th><th>Verdict</th><th>Pourquoi</th></tr></thead><tbody>
	<?php if ( ! $analyse['comptes'] ) : ?><tr><td colspan="7" class="empty">Plan sain : aucun doublon, aucun compte désactivé, aucun compte remplacé ou inutilisé.</td></tr>
	<?php else : foreach ( $analyse['comptes'] as $c ) : ?><tr>
		<td class="code"><?= e( $c['numero'] ) ?><?= $c['actif'] ? '' : ' <span class="muted" title="Désactivé">⊘</span>' ?></td>
		<td><?= e( $c['libelle'] ) ?></td>
		<td style="font-size:12px"><?php foreach ( $c['motifs'] as $m ) : ?><span class="muted" title="<?= e( $motifs[ $m ] ?? $m ) ?>"><?= e( $mot[ $m ] ?? '' ) ?> <?= e( $motifs[ $m ] ?? $m ) ?></span><br><?php endforeach; ?></td>
		<td class="num"><?= (int) $c['nb_lignes'] ?></td>
		<td class="code"><?= $c['cible'] ? e( $c['cible'] ) : '<span class="muted">—</span>' ?></td>
		<td><span class="modbadge <?= $cls[ $c['verdict'] ] ?? 'b-off' ?>"><?= e( $verdicts[ $c['verdict'] ][0] ?? $c['verdict'] ) ?></span></td>
		<td class="muted" style="font-size:12px"><?= e( $c['raison'] ) ?></td>
	</tr><?php endforeach; endif; ?>
	</tbody></table>
	<div class="card-body" style="padding-top:0"><p class="help" style="margin:0">Motifs : <strong>⧉</strong> doublon d'intitulé · <strong>⊘</strong> désactivé · <strong>↪</strong> mal imputé, remplacé par un autre compte · <strong>∅</strong> jamais utilisé et hors référentiel.</p></div>
</div>
