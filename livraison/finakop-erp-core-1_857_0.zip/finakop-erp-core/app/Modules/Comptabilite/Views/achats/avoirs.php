<?php
/**
 * Avoirs fournisseurs.
 *
 * @var array $avoirs @var array $natures @var array $fournisseurs @var array $taux
 * @var int|null $filtre @var mixed $flash @var string $tab
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$totalTtc = 0.0;
foreach ( $avoirs as $a ) { $totalTtc += (float) $a['montant_ttc']; }
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="dash-head">
	<h1 style="font-size:20px">↩️ Avoirs fournisseurs</h1>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats' ) ) ?>">← Factures d'achat</a>
</div>

<p class="help">
	Un avoir éteint tout ou partie d'une dette fournisseur. Sans lui, un retour de marchandise
	laisse le compte 401 à son montant d'origine : le solde ne se lettre pas et le règlement
	porte sur une somme qui ne correspond à aucune pièce.
</p>

<div class="card">
	<div class="card-head"><h2>Nouvel avoir</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/achats/avoirs' ) ) ?>" class="form-rows">
			<?= FKC_Csrf::field() ?>
			<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
				<label style="flex:1;min-width:180px">Fournisseur
					<select class="fld" name="fournisseur_id" required>
						<option value="">—</option>
						<?php foreach ( $fournisseurs as $f ) : ?>
							<option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option>
						<?php endforeach; ?>
					</select></label>
				<label style="min-width:200px">Nature
					<select class="fld" name="nature">
						<?php foreach ( $natures as $k => $lbl ) : ?>
							<option value="<?= e( $k ) ?>"><?= e( $lbl ) ?></option>
						<?php endforeach; ?>
					</select></label>
				<label style="width:150px">Date
					<input class="fld" type="date" name="date_avoir" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label style="width:150px">Référence
					<input class="fld" type="text" name="reference" placeholder="N° avoir fournisseur"></label>
			</div>
			<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
				<label style="width:150px">Montant HT
					<input class="fld" type="number" name="montant_ht" step="0.01" min="0" required></label>
				<label style="width:110px">TVA
					<select class="fld" name="taux_tva">
						<?php foreach ( $taux as $t ) : ?><option value="<?= e( $t ) ?>"><?= e( $t ) ?> %</option><?php endforeach; ?>
					</select></label>
				<label style="width:170px">Compte de contrepartie
					<input class="fld" type="text" name="compte_contrepartie" placeholder="auto selon la nature"></label>
				<label style="flex:1;min-width:180px">Motif
					<input class="fld" type="text" name="motif" placeholder="Lot défectueux, remise de fin d'année…"></label>
			</div>
			<p class="help" style="margin:0">
				<strong>Retour de marchandise</strong> : la charge d'achat est annulée et la TVA suit la marchandise.
				<strong>Rabais</strong> : la marchandise reste, seul le prix baisse — porté en
				<em>601900 Rabais, remises et ristournes obtenus</em>, pour que la négociation reste lisible
				au compte de résultat.
			</p>
			<button class="btn btn-primary" type="submit">Enregistrer l'avoir</button>
		</form>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2><?= count( $avoirs ) ?> avoir(s) — <?= e( fkc_money( $totalTtc ) ) ?> F TTC</h2></div>
	<div class="card-body">
		<?php if ( ! $avoirs ) : ?>
			<p class="muted">Aucun avoir enregistré.</p>
		<?php else : ?>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr>
					<th>N°</th><th>Date</th><th>Fournisseur</th><th>Nature</th>
					<th class="num">HT</th><th class="num">TVA</th><th class="num">TTC</th><th>Motif</th>
				</tr></thead>
				<tbody>
				<?php foreach ( $avoirs as $a ) : ?>
					<tr>
						<td><strong><?= e( $a['numero'] ) ?></strong>
							<?php if ( $a['reference'] ) : ?><br><span class="muted" style="font-size:11px"><?= e( $a['reference'] ) ?></span><?php endif; ?></td>
						<td><?= e( date( 'd/m/Y', strtotime( $a['date_avoir'] ) ) ) ?></td>
						<td><?= e( $a['fournisseur_nom'] ) ?></td>
						<td><span class="modbadge <?= 'retour' === $a['nature'] ? 'b-warn' : 'b-on' ?>"><?= e( $natures[ $a['nature'] ] ?? $a['nature'] ) ?></span></td>
						<td class="num"><?= e( fkc_money( $a['montant_ht'] ) ) ?></td>
						<td class="num muted"><?= e( fkc_money( $a['montant_tva'] ) ) ?></td>
						<td class="num"><strong><?= e( fkc_money( $a['montant_ttc'] ) ) ?></strong></td>
						<td class="muted" style="font-size:12px"><?= e( $a['motif'] ?: '—' ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif; ?>
	</div>
</div>
