<?php
/**
 * Bons de réception — marchandise reçue, facturée ou non.
 *
 * @var array $orphelines @var array $attente @var array $suspens
 * @var array $fournisseurs @var int|null $filtre @var mixed $flash @var string $tab
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$totalAttente = 0.0;
foreach ( $attente as $r ) { $totalAttente += (float) FKC_AchatReception::reste( $r ); }
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="dash-head">
	<h1 style="font-size:20px">📦 Bons de réception</h1>
	<div style="display:flex;gap:8px">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats/demandes' ) ) ?>">📝 Demandes</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats' ) ) ?>">🧾 Factures</a>
	</div>
</div>

<p class="help">
	Une réception fait entrer la marchandise en stock et constate la dette au compte
	<strong>408 — Fournisseurs, factures non parvenues</strong>. Rien n'est payable tant que
	la facture n'est pas arrivée : c'est elle qui extourne le 408 et ouvre la dette en 401.
</p>

<?php
/*
 * Les réceptions SANS FOURNISSEUR passent en tête, avec leur formulaire
 * d'attribution. Elles produisent une dette que rien ne peut apurer — aucun
 * règlement ne sait à qui l'imputer —, et le temps ne les résout pas : plus on
 * attend, moins on se souvient de qui a livré.
 */
?>
<?php if ( $orphelines ) : ?>
<div class="card">
	<div class="card-head"><h2>⚠ <?= count( $orphelines ) ?> réception(s) sans fournisseur —
		<?= e( fkc_money( $suspens['montant'] ) ) ?> F</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			La marchandise est là et la dette est constatée, mais aucun fournisseur n'est identifié :
			<strong>aucun règlement ne pourra l'apurer</strong>. Attribuez-le, l'écriture est corrigée
			en même temps.
		</p>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr><th>Date</th><th>Pièce</th><th>Article</th><th class="num">Montant HT</th><th>Attribuer à</th></tr></thead>
				<tbody>
				<?php foreach ( $orphelines as $r ) : ?>
					<tr>
						<td><?= e( date( 'd/m/Y', strtotime( $r['date_reception'] ) ) ) ?></td>
						<td><?= e( $r['piece'] ?: '—' ) ?></td>
						<td><?= e( $r['libelle'] ) ?>
							<?php if ( $r['pack'] ) : ?><span class="muted" style="font-size:11px"> · <?= e( $r['pack'] ) ?></span><?php endif; ?></td>
						<td class="num"><strong><?= e( fkc_money( $r['montant_ht'] ) ) ?></strong></td>
						<td>
							<form method="post" action="<?= e( url( 'comptabilite/achats/receptions/' . (int) $r['id'] . '/attribuer' ) ) ?>"
								style="display:flex;gap:6px">
								<?= FKC_Csrf::field() ?>
								<select class="fld" name="fournisseur_id" required style="min-width:140px">
									<option value="">Fournisseur…</option>
									<?php foreach ( $fournisseurs as $f ) : ?>
										<option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option>
									<?php endforeach; ?>
								</select>
								<button class="btn btn-primary btn-sm" type="submit">Attribuer</button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>En attente de facture —
		<?= e( fkc_money( $totalAttente ) ) ?> F restant à facturer</h2></div>
	<div class="card-body">
		<?php if ( ! $attente ) : ?>
			<p class="muted">Aucune réception en attente : toute la marchandise reçue est facturée.</p>
		<?php else : ?>
			<div class="ckp-table-wrap">
				<table class="ckp-table">
					<thead><tr>
						<th>Date</th><th>Pièce</th><th>Fournisseur</th><th>Article</th>
						<th class="num">Reçu HT</th><th class="num">Facturé</th><th class="num">Reste</th><th>État</th>
					</tr></thead>
					<tbody>
					<?php foreach ( $attente as $r ) :
						$reste = (float) FKC_AchatReception::reste( $r );
						$partiel = (float) $r['montant_facture'] > 0; ?>
						<tr>
							<td><?= e( date( 'd/m/Y', strtotime( $r['date_reception'] ) ) ) ?></td>
							<td><?= e( $r['piece'] ?: '—' ) ?></td>
							<td><?= e( $r['fournisseur_nom'] ?: '—' ) ?></td>
							<td><?= e( $r['libelle'] ) ?></td>
							<td class="num"><?= e( fkc_money( $r['montant_ht'] ) ) ?></td>
							<td class="num muted"><?= e( fkc_money( $r['montant_facture'] ) ) ?></td>
							<td class="num"><strong><?= e( fkc_money( $reste ) ) ?></strong></td>
							<td><span class="modbadge <?= $partiel ? 'b-warn' : 'b-on' ?>"><?= $partiel ? 'Partielle' : 'À facturer' ?></span></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<p class="help">
				Pour facturer, ouvrez <a href="<?= e( url( 'comptabilite/achats/nouvelle' ) ) ?>">une nouvelle
				facture d'achat</a> et rattachez-y les réceptions : la charge n'est pas recréée, le 408 est
				extourné et la TVA devient déductible.
			</p>
		<?php endif; ?>
	</div>
</div>
