<?php /** @var array $fournisseurs @var array $plan @var array $taux @var array $errors @var string $tab @var array $divisions @var bool $showDivision @var array $receptions @var array|null $source */
$receptions = $receptions ?? array();
/*
 * $source : la facture que l'on corrige, ou null pour une saisie neuve. Le même
 * écran sert aux deux — une saisie corrigée reste une saisie, et lui donner un
 * second formulaire condamnerait à corriger deux fois chaque évolution.
 */
$source = $source ?? null;
$srcLig = $source ? (array) ( $source['lignes'] ?? array() ) : array();
$val    = function ( $k, $def = '' ) use ( $source ) { return $source && isset( $source[ $k ] ) && '' !== (string) $source[ $k ] ? (string) $source[ $k ] : $def; };
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:960px"><div class="card-head"><h2><?= $source ? 'Correction de la facture ' . e( $source['numero'] ) : 'Nouvelle facture fournisseur' ?></h2></div><div class="card-body">
<?php if ( $source ) : ?>
	<div class="alert" style="background:var(--bg2);border:1px solid var(--line);color:var(--text)">
<?php if ( 'annulee' === (string) ( $source['statut'] ?? '' ) ) : ?>
		<strong>Ressaisie d'une facture annulée.</strong>
		<p class="help" style="margin:6px 0 0"><strong><?= e( $source['numero'] ) ?></strong> est annulée : une pièce annulée ne revit pas. L'enregistrement crée une nouvelle facture, pré-remplie à partir d'elle et liée à elle.</p>
<?php else : ?>
		<strong>Correction de la facture — elle garde son numéro.</strong>
		<p class="help" style="margin:6px 0 0">La pièce reste <strong><?= e( $source['numero'] ) ?></strong>, avec ses pièces jointes et ses règlements. Côté comptabilité, rien n'est réécrit : <?= empty( $source['ecriture_id'] ) ? 'son écriture, qui attend encore au brouillard, est remplacée' : 'son écriture est contre-passée à sa date et une écriture corrigée est passée' ?> — c'est ce qu'impose la règle SYSCOHADA. La version d'avant est conservée dans l'historique de la facture.</p>
<?php endif; ?>
	</div>
<?php endif; ?>
<?php if ( ! $fournisseurs ) : ?>
	<p class="help">Aucun fournisseur. <a href="<?= e( url('comptabilite/fournisseurs/nouveau') ) ?>">Créez d'abord un fournisseur.</a></p>
<?php else : ?>
<form method="post" action="<?= e( url('comptabilite/achats') ) ?>" enctype="multipart/form-data">
	<?= FKC_Csrf::field() ?>
	<?php if ( $source ) : ?><input type="hidden" name="corrige_id" value="<?= (int) $source['id'] ?>"><?php endif; ?>
<?php if ( $receptions ) : ?>
	<div class="alert" style="margin-bottom:14px">
		<strong>Marchandises reçues, pas encore facturées</strong>
		<p class="help" style="margin:6px 0 10px">Ces réceptions sont déjà en stock et provisionnées au compte 408. Cochez celles que couvre cette facture&nbsp;: leur provision sera extournée au lieu de créer une seconde charge. Le montant proposé est le reliquat restant à facturer&nbsp;; réduisez-le si la facture ne couvre qu'une partie de la livraison — le solde restera proposé sur la facture suivante. Un écart entre le bon de livraison et la facture apparaîtra en charge.</p>
		<?php $frnCourant = null; foreach ( $receptions as $r ) : ?>
			<?php if ( $frnCourant !== $r['fournisseur_nom'] ) : $frnCourant = $r['fournisseur_nom']; ?>
				<div class="muted" style="margin-top:8px;font-size:12px"><?= e( (string) $frnCourant ) ?></div>
			<?php endif; ?>
			<?php $reste = round( (float) $r['montant_ht'] - (float) ( $r['montant_facture'] ?? 0 ), 2 ); ?>
			<label style="display:flex;align-items:center;gap:8px;padding:3px 0;flex-wrap:wrap">
				<input type="checkbox" name="receptions[]" value="<?= (int) $r['id'] ?>" data-frn="<?= (int) $r['fournisseur_id'] ?>">
				<span style="flex:1;min-width:220px">
					<?= e( (string) $r['date_reception'] ) ?> — <?= e( (string) $r['libelle'] ) ?>
					<?php if ( ! empty( $r['piece'] ) ) : ?><span class="muted">(<?= e( (string) $r['piece'] ) ?>)</span><?php endif; ?>
					<span class="muted">· <?= e( (string) $r['pack'] ) ?></span>
					<?php if ( (float) ( $r['montant_facture'] ?? 0 ) > 0 ) : ?>
						<span class="muted">· déjà facturé <?= e( fkc_money( (float) $r['montant_facture'] ) ) ?> F sur <?= e( fkc_money( (float) $r['montant_ht'] ) ) ?> F</span>
					<?php endif; ?>
				</span>
				<span class="muted" style="font-size:12px">reste</span>
				<input class="num" style="width:110px" name="receptions_montants[<?= (int) $r['id'] ?>]" value="<?= e( (string) $reste ) ?>">
				<span class="muted" style="font-size:12px">F HT</span>
			</label>
		<?php endforeach; ?>
	</div>
<?php endif; ?>
	<div class="form-grid" style="grid-template-columns:2fr 1fr 1fr">
		<label class="fld"><span>Fournisseur</span><select name="fournisseur_id" required><?php foreach($fournisseurs as $fr):?><option value="<?= (int)$fr['id'] ?>" <?= $source && (int)$source['fournisseur_id']===(int)$fr['id'] ? 'selected' : '' ?>><?= e($fr['nom']) ?> (<?= e($fr['compte']) ?>)</option><?php endforeach;?></select></label>
		<label class="fld"><span>Date facture</span><input type="date" name="date_facture" value="<?= e( $val('date_facture', date('Y-m-d')) ) ?>" required></label>
		<label class="fld"><span>Échéance</span><input type="date" name="date_echeance" value="<?= e( $val('date_echeance') ) ?>"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr 1fr">
		<?php if ( ! empty( $items ) ) : ?>
		<label class="fld"><span>Item d'achat</span>
			<select id="ach-item">
				<option value="">— libre —</option>
				<?php foreach ( $items as $it ) : ?><option value="<?= e( $it['compte'] ) ?>" data-lib="<?= e( $it['libelle'] ) ?>"><?= e( $it['libelle'] . ' (' . $it['compte'] . ')' ) ?></option><?php endforeach; ?>
			</select>
		</label>
		<?php endif; ?>
		<label class="fld"><span>Référence facture</span><input id="ach-ref" name="reference" placeholder="N° du fournisseur" value="<?= e( $val('reference') ) ?>"></label>
		<label class="fld"><span>Compte de charge par défaut</span><select id="ach-compte" name="compte_charge"><?php foreach($plan as $c): if((int)$c['classe']!==6) continue;?><option value="<?= e($c['numero']) ?>" <?= ( $source ? (string)$source['compte_charge'] : '601000' )===$c['numero']?'selected':'' ?>><?= e($c['numero'].' '.$c['libelle']) ?></option><?php endforeach;?></select></label>
		<label class="fld"><span>TVA</span><select name="taux_tva"><?php foreach($taux as $t):?><option value="<?= $t ?>" <?= $source && (float)$source['taux_tva']===(float)$t ? 'selected' : '' ?>><?= $t ?> %</option><?php endforeach;?></select></label>
	</div>

	<?php
	/*
	 * LE DÉTAIL DE LA FACTURE (1.737.0).
	 *
	 * L'écran ne demandait qu'un montant global et un compte : on enregistrait
	 * « 450 000 F en 601000 » sans jamais dire CE QUE le fournisseur avait
	 * livré. La facture papier, elle, porte ses articles, ses quantités et ses
	 * prix ; la pièce enregistrée n'en gardait rien.
	 *
	 * Chaque ligne peut viser SON compte : une facture mêle couramment du
	 * consommable et une prestation, et les forcer sur un compte unique
	 * faussait le compte de résultat pour la seule raison que la saisie
	 * n'offrait qu'un champ.
	 *
	 * LE TOTAL N'EST PAS SAISI, IL EST CALCULÉ. Deux champs qui disent la même
	 * chose finissent toujours par se contredire, et c'est alors la saisie qui
	 * décide au lieu de la facture. Le repli « montant global » reste
	 * accessible d'un clic pour les reprises d'historique, où le détail
	 * n'existe pas.
	 */
	$compte6 = array();
	foreach ( $plan as $c ) { if ( 6 === (int) $c['classe'] ) { $compte6[] = $c; } }
	?>
	<div class="card" style="margin:14px 0;background:var(--panel2)"><div class="card-body">
		<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
			<strong>Détail de la facture</strong>
			<span class="help" style="margin:0">Reprenez les lignes du document reçu.</span>
			<label style="margin-left:auto;display:flex;align-items:center;gap:6px;font-size:13px">
				<input type="checkbox" id="ach-global" <?= ( $source && ! $srcLig ) ? 'checked' : '' ?>> Pas de détail : saisir un montant global
			</label>
		</div>

		<div id="ach-detail">
			<table class="table" style="margin-top:10px">
				<thead><tr>
					<th style="width:42%">Désignation</th><th style="width:10%">Qté</th>
					<th style="width:16%">P.U. HT</th><th style="width:22%">Compte</th>
					<th class="num" style="width:10%">Montant HT</th><th></th>
				</tr></thead>
				<tbody id="ach-lignes"></tbody>
				<tfoot><tr class="total">
					<td colspan="4" class="right">Total HT</td>
					<td class="num"><strong id="ach-total">0</strong></td><td></td>
				</tr></tfoot>
			</table>
			<button class="btn btn-ghost btn-sm" type="button" id="ach-plus">+ Ajouter une ligne</button>
		</div>

		<div id="ach-somme" style="display:none;margin-top:10px">
			<label class="fld" style="max-width:240px"><span>Montant HT</span>
				<input class="num" name="montant_ht" id="ach-ht" value="<?= e( $srcLig ? '' : $val('montant_ht') ) ?>"></label>
			<p class="help">Sans détail, la pièce ne gardera que ce total — c'est le comportement d'avant 1.737.0.</p>
		</div>
	</div></div>
	<?php
	/*
	 * IMPUTATION ANALYTIQUE (1.739.0) — la division répondait seule.
	 *
	 * La division dit « quelle entité de l'entreprise ». Les axes disent
	 * « selon quel angle » : projet, artiste, œuvre, chantier. Pour un label,
	 * « combien ce titre m'a-t-il coûté ? » n'est pas une question de
	 * division — et c'est pourtant la plus fréquente.
	 *
	 * Le moteur savait déjà le faire : `FKC_FactureFournisseur::create()` lit
	 * `axe_id` et `valeur_id` et les pose sur chaque ligne de charge. Seul cet
	 * écran ne les demandait pas, alors que la facture CLIENT les demandait
	 * depuis longtemps. Les charges partaient donc sans imputation, et le
	 * résultat par axe n'avait que des produits — une moitié de réponse, ce
	 * qui est le pire état pour un tableau analytique.
	 *
	 * Les deux blocs restent SÉPARÉS : une facture peut porter une division
	 * sans axe, ou l'inverse. Les lier ferait d'une commodité une contrainte.
	 */
	$fAxe = (int) ( $piece['axe_id'] ?? 0 );
	$fVal = (int) ( $piece['valeur_id'] ?? 0 );
	$colonnes = ( ! empty( $showDivision ) && ! empty( $divisions ) ? 1 : 0 ) + ( ! empty( $showAxes ) ? 2 : 0 );
	?>
	<?php if ( $colonnes > 0 ) : ?>
	<div class="form-grid" style="grid-template-columns:repeat(<?= (int) max( 1, $colonnes ) ?>,1fr)">
		<?php if ( ! empty( $showDivision ) && ! empty( $divisions ) ) : ?>
			<label class="fld"><span>Division (analytique)</span><select name="division_id"><option value="">— non imputé —</option><?php foreach($divisions as $dv):?><option value="<?= (int)$dv['id'] ?>" <?= $source && (int)($source['division_id'] ?? 0)===(int)$dv['id'] ? 'selected' : '' ?>><?= e($dv['libelle']) ?></option><?php endforeach;?></select></label>
		<?php endif; ?>
		<?php if ( ! empty( $showAxes ) ) : ?>
			<label class="fld"><span>Axe analytique</span>
				<select name="axe_id" id="ach-axe">
					<option value="">— aucun axe —</option>
					<?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= $fAxe === (int) $a['id'] ? 'selected' : '' ?>><?= e( $a['code'] . ' · ' . $a['libelle'] ) ?></option><?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Valeur analytique</span>
				<select name="valeur_id" id="ach-valeur"><option value="">— valeur —</option></select>
			</label>
		<?php endif; ?>
	</div>
	<?php if ( ! empty( $showAxes ) ) : ?>
	<p class="help">
		L'axe et la valeur sont portés par <strong>chaque ligne de charge</strong> de l'écriture — pas par la
		TVA ni par la dette fournisseur, qui n'ont pas d'existence analytique.
		Une valeur n'est retenue que si un axe l'est : seule, elle ne voudrait rien dire.
	</p>
	<script>
	(function(){
		/* La valeur dépend de l'axe : on ne propose que ce qui existe sous lui.
		   Même cascade que sur la facture client, pour que les deux écrans se
		   conduisent pareil — un utilisateur ne devrait pas avoir à réapprendre. */
		var valeurs = <?= json_encode( $valeursMap ?? array(), JSON_UNESCAPED_UNICODE ) ?>;
		var saved = <?= (int) $fVal ?>;
		var axe = document.getElementById('ach-axe'), val = document.getElementById('ach-valeur');
		if (!axe || !val) { return; }
		function fill(){
			var list = valeurs[axe.value] || [];
			val.innerHTML = '<option value="">— valeur —</option>' + list.map(function(v){
				return '<option value="'+v.id+'"'+(v.id===saved?' selected':'')+'>'+v.t+'</option>';
			}).join('');
		}
		axe.addEventListener('change', function(){ saved = 0; fill(); });
		fill();
	})();
	</script>
	<?php endif; ?>
	<?php endif; ?>
	<?php
	/*
	 * LE JUSTIFICATIF, DÈS LA SAISIE (1.738.0).
	 *
	 * La facture d'achat était le seul document comptable à ne pas pouvoir
	 * porter sa pièce — et c'est justement celle dont l'ORIGINAL NE SORT PAS
	 * du logiciel : on le reçoit par courrier, par e-mail ou en main propre.
	 * Il fallait enregistrer le montant d'abord, rouvrir la fiche ensuite, et
	 * dans la pratique la moitié des scans ne suivait jamais.
	 *
	 * Le champ est ici, au moment où l'on a le document sous les yeux.
	 */
	?>
	<div class="form-grid" style="grid-template-columns:1fr">
		<label class="fld">
			<span>Pièces justificatives <span class="muted">(scan ou PDF de la facture reçue)</span></span>
			<input type="file" name="pieces[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.gif">
		</label>
	</div>
	<p class="help" style="margin-top:-4px">PDF ou image (JPG, PNG, WEBP, GIF) — 8 Mo par fichier. Vous pourrez en ajouter d'autres depuis la fiche.</p>

	<div class="actions"><button class="btn btn-primary" type="submit">Enregistrer &amp; comptabiliser</button><a class="btn btn-ghost" href="<?= e( url('comptabilite/achats') ) ?>">Annuler</a></div>
	<p class="help" style="margin-top:8px">Écriture générée (journal AC) : une ligne de charge par ligne de détail, portant sa désignation et son compte, + TVA déductible (445200) au débit, fournisseur (TTC) au crédit. La TVA alimente la déclaration de TVA.</p>
</form>
<script>
(function(){
	var it=document.getElementById('ach-item'), cp=document.getElementById('ach-compte'), rf=document.getElementById('ach-ref');
	if(it&&cp){
		it.addEventListener('change',function(){
			var v=it.value; if(!v)return;
			for(var i=0;i<cp.options.length;i++){ if(cp.options[i].value===v){ cp.selectedIndex=i; break; } }
			var lib=it.options[it.selectedIndex].getAttribute('data-lib');
			if(rf && !rf.value && lib){ rf.value=lib; }
		});
	}

	/* ── Les lignes de détail ──────────────────────────────────────────── */
	var comptes = <?= json_encode( array_map( function ( $c ) { return array( 'n' => $c['numero'], 'l' => $c['numero'] . ' ' . $c['libelle'] ); }, $compte6 ), JSON_UNESCAPED_UNICODE ) ?>;
	var corps = document.getElementById('ach-lignes');
	var total = document.getElementById('ach-total');
	var n = 0;

	function lire(v){ v=String(v||'').replace(/[\s\u00a0']/g,'').replace(',','.'); var x=parseFloat(v); return isNaN(x)?0:x; }
	function fmt(x){ return Math.round(x).toLocaleString('fr-FR').replace(/\u202f/g,' '); }

	function recalc(){
		var s=0;
		Array.prototype.forEach.call(corps.querySelectorAll('tr'),function(tr){
			var q=lire(tr.querySelector('.q').value)||1, p=lire(tr.querySelector('.p').value);
			var m=q*p;
			tr.querySelector('.m').textContent = m ? fmt(m) : '—';
			s+=m;
		});
		total.textContent = fmt(s);
	}

	function ajouter(){
		var i=n++;
		var tr=document.createElement('tr');
		var td1=document.createElement('td');
		var des=document.createElement('input'); des.name='lignes['+i+'][designation]';
		des.placeholder='Ce que le fournisseur a livré'; des.style.width='100%';
		td1.appendChild(des);
		var td2=document.createElement('td');
		var q=document.createElement('input'); q.className='num q'; q.name='lignes['+i+'][quantite]';
		q.value='1'; q.style.width='100%'; q.inputMode='decimal'; td2.appendChild(q);
		var td3=document.createElement('td');
		var p=document.createElement('input'); p.className='num p'; p.name='lignes['+i+'][pu_ht]';
		p.style.width='100%'; p.inputMode='decimal'; td3.appendChild(p);
		var td4=document.createElement('td');
		var c=document.createElement('select'); c.name='lignes['+i+'][compte_charge]'; c.style.width='100%';
		var o0=document.createElement('option'); o0.value=''; o0.textContent='— compte par défaut —'; c.appendChild(o0);
		comptes.forEach(function(x){ var o=document.createElement('option'); o.value=x.n; o.textContent=x.l; c.appendChild(o); });
		td4.appendChild(c);
		var td5=document.createElement('td'); td5.className='num'; var m=document.createElement('span'); m.className='m'; m.textContent='—'; td5.appendChild(m);
		var td6=document.createElement('td');
		var sup=document.createElement('button'); sup.type='button'; sup.className='btn btn-ghost btn-sm'; sup.textContent='✕';
		sup.addEventListener('click',function(){ tr.remove(); recalc(); });
		td6.appendChild(sup);
		[td1,td2,td3,td4,td5,td6].forEach(function(td){ tr.appendChild(td); });
		corps.appendChild(tr);
		[q,p].forEach(function(x){ x.addEventListener('input',recalc); });
		return des;
	}

	document.getElementById('ach-plus').addEventListener('click',function(){ ajouter().focus(); });
	/* Trois lignes d'avance : assez pour commencer à taper sans cliquer, et
	   les vides sont ignorées à l'enregistrement. */
	/*
	 * Correction : on repart des lignes de la facture extournée. Les ressaisir
	 * à la main serait la première occasion de se tromper — or on corrige
	 * justement parce qu'une erreur s'est glissée quelque part.
	 */
	var reprise = <?= json_encode( array_map( function ( $l ) {
		return array( 'd' => (string) $l['designation'], 'q' => (float) $l['quantite'],
			'p' => (float) $l['pu_ht'], 'c' => (string) ( $l['compte_charge'] ?? '' ) );
	}, $srcLig ), JSON_UNESCAPED_UNICODE ) ?>;
	if (reprise.length) {
		reprise.forEach(function (r) {
			ajouter();
			var tr = corps.lastElementChild;
			tr.querySelector('input[name$="[designation]"]').value = r.d;
			tr.querySelector('.q').value = r.q;
			tr.querySelector('.p').value = r.p;
			var sel = tr.querySelector('select');
			if (r.c) {
				for (var i = 0; i < sel.options.length; i++) {
					if (sel.options[i].value === r.c) { sel.selectedIndex = i; break; }
				}
			}
		});
		ajouter(); /* une ligne libre pour ajouter ce qui manquait */
	} else {
	for(var k=0;k<3;k++){ ajouter(); }
	}
	recalc();

	/* Le repli « montant global ». On DÉSACTIVE les champs cachés plutôt que
	   de les laisser partir : un détail invisible qui contredit le total saisi
	   serait la pire des ambiguïtés. */
	var bascule=document.getElementById('ach-global');
	var zoneDetail=document.getElementById('ach-detail'), zoneSomme=document.getElementById('ach-somme');
	var champHt=document.getElementById('ach-ht');
	function majMode(){
		var global=bascule.checked;
		zoneDetail.style.display = global ? 'none' : '';
		zoneSomme.style.display  = global ? '' : 'none';
		champHt.disabled = !global;
		champHt.required = global;
		Array.prototype.forEach.call(corps.querySelectorAll('input,select'),function(x){ x.disabled = global; });
	}
	bascule.addEventListener('change',majMode);
	majMode();
})();
</script>
<?php endif; ?>
</div></div>
