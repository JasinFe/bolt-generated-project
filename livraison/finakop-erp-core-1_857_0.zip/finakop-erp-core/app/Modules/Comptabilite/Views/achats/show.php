<?php /** @var array $f @var array|null $frn @var array|null $ecriture @var array|null $flash @var string $tab @var array $lignes @var array $pieces */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); $annulee='annulee'===$f['statut']; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Facture fournisseur <?= e($f['numero']) ?> <?php if($annulee):?><span class="modbadge b-off">Annulée</span><?php endif;?></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/achats/'.$f['id'].'/imprimer') ) ?>" target="_blank">🖨️ Imprimer / PDF</a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/achats') ) ?>">← Achats</a></div>
	<div class="card-body">
		<div class="meta">
			<div><span class="stat-label">Fournisseur</span><strong><?= e($f['fournisseur_nom']) ?></strong></div>
			<div><span class="stat-label">Date · échéance</span><strong><?= e( date('d/m/Y',strtotime($f['date_facture'])) ) ?><?= $f['date_echeance']?' · '.e(date('d/m/Y',strtotime($f['date_echeance']))):'' ?></strong></div>
			<div><span class="stat-label">Référence</span><strong><?= e($f['reference'] ?: '—') ?></strong></div>
			<div><span class="stat-label">Compte de charge</span><strong><span class="code"><?= e($f['compte_charge']) ?></span></strong></div>
			<?php
			/*
			 * L'IMPUTATION ANALYTIQUE SE RELIT SUR LA PIÈCE (1.739.0).
			 * Elle vivait sur les lignes d'écriture, où personne ne va la
			 * chercher. Affichée seulement quand elle existe : une mention
			 * « — » sur toutes les factures d'un dossier qui n'emploie pas
			 * l'analytique est du bruit.
			 */
			$fAxe = ! empty( $f['axe_id'] ) && class_exists( 'FKC_Axe' ) ? FKC_Axe::find( (int) $f['axe_id'] ) : null;
			$fVal = ! empty( $f['valeur_id'] ) && class_exists( 'FKC_Valeur' ) ? FKC_Valeur::find( (int) $f['valeur_id'] ) : null;
			if ( $fAxe && $fVal ) : ?>
				<div><span class="stat-label">Imputation analytique</span>
					<strong><?= e( $fAxe['code'] ) ?> · <?= e( $fVal['libelle'] ) ?></strong></div>
			<?php endif; ?>
		</div>
		<?php
		/*
		 * LE DÉTAIL, QUAND LA FACTURE EN A (1.737.0). Les pièces enregistrées
		 * avant cette version — et les imports FNE — n'ont qu'un total : on ne
		 * leur invente pas une ligne, on affiche ce qui existe.
		 */
		$lignes = $lignes ?? array();
		if ( $lignes ) : ?>
		<table class="table bordered" style="margin-bottom:14px">
			<thead><tr><th>Désignation</th><th class="num">Qté</th><th class="num">P.U. HT</th><th>Compte</th><th class="num">Montant HT</th></tr></thead>
			<tbody>
			<?php foreach ( $lignes as $l ) : ?>
				<tr>
					<td><?= e( (string) $l['designation'] ) ?></td>
					<td class="num"><?= e( rtrim( rtrim( number_format( (float) $l['quantite'], 2, ',', ' ' ), '0' ), ',' ) ) ?></td>
					<td class="num"><?= e( fkc_money( $l['pu_ht'] ) ) ?></td>
					<td class="code"><?= e( (string) $l['compte_charge'] ) ?></td>
					<td class="num"><?= e( fkc_money( $l['montant_ht'] ) ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
		<table class="table bordered" style="max-width:420px">
			<tr><td>Montant HT</td><td class="num"><?= e( fkc_money($f['montant_ht']) ) ?></td></tr>
			<tr><td>TVA (<?= e($f['taux_tva']) ?> %)</td><td class="num"><?= e( fkc_money($f['montant_tva']) ) ?></td></tr>
			<tr class="total"><td>TTC</td><td class="num"><?= e( fkc_money($f['montant_ttc']) ) ?> F</td></tr>
		</table>
		<div style="margin-top:14px;display:flex;gap:8px">
			<?php if($frn && !$annulee):?><a class="btn btn-primary btn-sm" href="<?= e( url('comptabilite/fournisseurs/'.$frn['id'].'/payer') ) ?>">Payer ce fournisseur</a><?php endif;?>
			<?php
			/*
			 * CORRIGER reste offert sur une facture ANNULÉE, et ce n'est pas un
			 * oubli : si la ressaisie échoue après l'extourne, l'ancienne est
			 * déjà annulée et c'est d'elle qu'il faut repartir — ses lignes
			 * sont conservées. Le libellé change pour ne pas laisser croire
			 * qu'on va annuler une seconde fois.
			 */
			?>
			<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/achats/'.$f['id'].'/corriger') ) ?>">✏️ <?= $annulee ? 'Ressaisir à partir de cette facture' : 'Corriger' ?></a>
			<?php if(!$annulee):?><form method="post" action="<?= e( url('comptabilite/achats/'.$f['id'].'/annuler') ) ?>" onsubmit="return confirm('Annuler cette facture ? Une écriture de contre-passation sera générée.')" style="margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" style="border-color:var(--danger);color:var(--danger)">Annuler la facture</button></form><?php endif;?>
			<?php
			/*
			 * LA SUPPRESSION N'APPARAÎT QU'UNE FOIS LA FACTURE ANNULÉE.
			 *
			 * À ce stade elle est neutre : sa contre-passation est passée, les
			 * deux écritures s'annulent au centime, et les réceptions ont été
			 * rendues à l'état « à facturer ». Elle n'encombre plus que la
			 * liste. Le bouton n'existe pas avant, parce qu'il offrirait alors
			 * un moyen d'effacer une dette vivante.
			 */
			if($annulee):?>
			<form method="post" action="<?= e( url('comptabilite/achats/'.$f['id'].'/supprimer') ) ?>" onsubmit="return confirm('Supprimer définitivement cette facture annulée ?\n\nLes écritures de comptabilisation et de contre-passation RESTENT au journal — elles s\'annulent, et le journal doit rester ininterrompu.\n\nLe document, son détail et ses pièces jointes seront effacés.')" style="margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" style="border-color:var(--danger);color:var(--danger)">🗑 Supprimer la facture</button></form>
			<?php endif;?>
		</div>
	</div>
</div>
<?php FKC_View::partial( 'comptabilite::_pieces', array(
	'pieces'       => $pieces ?? array(),
	'piecesUpload' => 'comptabilite/achats/' . (int) $f['id'] . '/pieces',
	'piecesBase'   => 'comptabilite/achats/piece',
) ); ?>
<?php if ( ! empty( $versions ) ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Historique des corrections</h2></div>
	<table class="table"><thead><tr><th>Version</th><th>Corrigée le</th><th>Date de facture</th><th class="num">HT</th><th class="num">TTC</th><th>Écriture d'origine</th></tr></thead><tbody>
	<?php foreach ( $versions as $v ) : $av = (array) ( $v['donnees']['facture'] ?? array() ); ?>
		<tr><td>v<?= (int) $v['version'] ?></td><td class="muted"><?= e( (string) $v['cree_at'] ) ?></td><td><?= ! empty( $av['date_facture'] ) ? e( date( 'd/m/Y', strtotime( (string) $av['date_facture'] ) ) ) : '' ?></td>
		<td class="num"><?= e( fkc_money( (float) ( $av['montant_ht'] ?? 0 ) ) ) ?></td><td class="num"><?= e( fkc_money( (float) ( $av['montant_ttc'] ?? 0 ) ) ) ?></td>
		<td class="muted"><?= $v['ecriture_remplacee'] ? 'n°' . (int) $v['ecriture_remplacee'] . ( $v['contrepassation_id'] ? ', contre-passée par n°' . (int) $v['contrepassation_id'] : ', contre-passée' ) : 'au brouillard, retirée' ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
</div>
<?php endif; ?>
<?php if ( $ecriture ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Écriture comptable (<?= e($ecriture['journal_code']) ?>)</h2></div>
	<table class="table"><thead><tr><th>Compte</th><th>Libellé</th><th class="num">Débit</th><th class="num">Crédit</th></tr></thead><tbody>
	<?php foreach ( $ecriture['lignes'] as $l ) : ?>
		<tr><td><span class="code"><?= e($l['compte_numero']) ?></span> <?= e($l['compte_libelle']) ?></td><td class="muted"><?= e($l['libelle']) ?></td>
		<td class="num"><?= $l['debit']>0?e(fkc_money($l['debit'])):'' ?></td><td class="num"><?= $l['credit']>0?e(fkc_money($l['credit'])):'' ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
</div>
<?php endif; ?>
