<?php /** @var array $fournisseurs @var array $taux @var bool $configured @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<?php if ( ! $configured ) : ?>
	<div class="alert alert-warn">La FNE n'est pas configurée. <a href="<?= e( url( 'facturation/fne' ) ) ?>">Configurer la FNE</a> pour relier votre compte.</div>
<?php endif; ?>
<div class="card">
	<div class="card-head"><h2>Importer une facture fournisseur reçue (FNE)</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">Les factures normalisées que vos fournisseurs ont émises à votre attention apparaissent dans votre compte FNE. Saisissez la référence FNE de la facture reçue pour l'enregistrer en comptabilité fournisseur (compte 401). La synchronisation automatique depuis le compte FNE sera activée dès que l'API de réception FNE sera disponible.</p>
		<form method="post" action="<?= e( url( 'comptabilite/achats/import-fne' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid">
				<label class="fld"><span>Référence FNE de la facture reçue *</span>
					<input type="text" name="reference" placeholder="Ex : FNE-2026-XXXXXX" required></label>
				<label class="fld"><span>Fournisseur (référentiel)</span>
					<select name="fournisseur_id">
						<option value="">— Sélectionner —</option>
						<?php foreach ( $fournisseurs as $f ) : ?><option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option><?php endforeach; ?>
					</select></label>
				<label class="fld"><span>… ou fournisseur libre</span>
					<input type="text" name="fournisseur_nom" placeholder="Nom du fournisseur"></label>
				<label class="fld"><span>Date de la facture</span>
					<input type="date" name="date_facture" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld"><span>Compte de charge</span>
					<input type="text" name="compte_charge" placeholder="Ex : 601000"></label>
				<label class="fld"><span>Montant HT</span>
					<input type="number" name="montant_ht" min="0" value="0" required></label>
				<label class="fld"><span>Taux TVA (%)</span>
					<select name="taux_tva"><?php foreach ( $taux as $t ) : ?><option value="<?= (int) $t ?>"><?= (int) $t ?> %</option><?php endforeach; ?></select></label>
			</div>
			<div class="actions" style="margin-top:8px">
				<button class="btn btn-primary" type="submit">Importer la facture</button>
				<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/achats' ) ) ?>">Voir les factures fournisseurs</a>
			</div>
		</form>
	</div>
</div>
