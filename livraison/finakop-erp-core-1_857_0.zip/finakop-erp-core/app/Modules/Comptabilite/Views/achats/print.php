<?php /** @var array $f @var array|null $frn @var array|null $charge @var array $lignes */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$soc  = FKC_Tenant::current();
$logo = ( $soc && FKC_Societe::hasLogo( $soc ) ) ? FKC_Societe::logoUrl( $soc ) : null;
$em_nom   = trim( (string) ( $soc['raison_sociale'] ?? '' ) ) ?: 'Votre société';
$em_forme = trim( (string) ( $soc['forme_juridique'] ?? '' ) );
$em_nom_aff = $em_nom . ( ( $em_forme && stripos( $em_nom, $em_forme ) === false && strlen( $em_forme ) <= 10 ) ? ' ' . strtoupper( $em_forme ) : '' );
$em_ncc   = trim( (string) ( $soc['ncc'] ?? '' ) );
$em_rccm  = trim( (string) ( $soc['rccm'] ?? '' ) );
$em_adr   = trim( (string) ( $soc['adresse'] ?? '' ) );
$em_ville = trim( (string) ( $soc['ville'] ?? '' ) );
$em_tel   = trim( (string) ( $soc['telephone'] ?? '' ) );
$cur      = 'XOF' === ( $soc['devise'] ?? 'XOF' ) ? 'F CFA' : ( $soc['devise'] ?? 'XOF' );
$annulee  = ( 'annulee' === $f['statut'] );
$lignes   = $lignes ?? array();
/*
 * SANS DÉTAIL, ON RETOMBE SUR LE COMPTE DE CHARGE. C'est le cas des factures
 * enregistrées avant 1.737.0, des imports FNE et des reprises d'historique :
 * elles n'ont qu'un total, et la pièce doit rester imprimable telle quelle.
 */
$desig    = ( $charge ? $charge['numero'] . ' — ' . $charge['libelle'] : 'Achat' ) . ( ! empty( $f['reference'] ) ? ' (réf. ' . $f['reference'] . ')' : '' );
?><!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Facture fournisseur <?= e( $f['numero'] ) ?></title>
<style>
  :root{--navy:#16264A;--gold:#C9A227;--gold-d:#A07E12;--ink:#1c2433;--muted:#6b7589;--line:#e6e9f0;--soft:#f6f8fc;}
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:"Segoe UI",system-ui,Arial,sans-serif;background:#54607a;color:var(--ink);padding:24px 16px 60px;font-size:13px}
  .bar{max-width:794px;margin:0 auto 16px;display:flex;gap:10px;justify-content:flex-end}
  .bar button,.bar a{padding:11px 20px;border-radius:9px;border:none;font-weight:700;cursor:pointer;font-size:13px;text-decoration:none}
  .bar .print{background:var(--gold);color:#241500}.bar .back{background:var(--navy);color:#fff}
  .sheet{background:#fff;max-width:794px;margin:0 auto;padding:40px 44px;box-shadow:0 12px 44px rgba(0,0,0,.32);border-radius:5px}
  .head{display:flex;justify-content:space-between;align-items:flex-start;gap:28px;padding-bottom:16px}
  .em{display:flex;gap:16px;align-items:flex-start}
  .em-logo{width:78px;height:78px;border-radius:12px;border:1px solid var(--line);object-fit:contain;padding:4px;background:#fff}
  .em-id h1{font-family:Georgia,serif;font-size:19px;color:var(--navy);font-weight:800}
  .em-id p{color:var(--muted);font-size:11.5px;margin-top:4px;line-height:1.7}
  .badges{margin-top:8px;display:flex;gap:8px;flex-wrap:wrap}
  .badge{font-family:ui-monospace,monospace;font-size:10.5px;color:var(--navy);background:var(--soft);border:1px solid var(--line);border-radius:6px;padding:3px 9px}
  .doc{text-align:right}.doc .ttl{font-family:Georgia,serif;font-size:24px;font-weight:800;color:var(--navy)}
  .doc .num{font-family:ui-monospace,monospace;font-size:16px;color:var(--gold-d);font-weight:700;margin-top:6px}
  .doc .dt{color:var(--muted);font-size:11.5px;margin-top:8px;line-height:1.6}
  .rule{height:3px;background:linear-gradient(90deg,var(--gold),var(--navy));border-radius:2px;margin:4px 0 20px}
  .parties{display:flex;justify-content:space-between;gap:24px;margin-bottom:20px}
  .to{flex:1;border-left:3px solid var(--gold);padding:2px 0 2px 14px}
  .to .t{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);font-weight:700;margin-bottom:5px}
  .to .nom{font-size:16px;font-weight:800;color:var(--navy)}
  .to .v{font-size:12px;line-height:1.7;color:#3a4660;margin-top:3px}
  table{width:100%;border-collapse:collapse;margin-bottom:16px}
  thead th{background:var(--navy);color:#fff;text-align:left;padding:11px 13px;font-size:10.5px;text-transform:uppercase;letter-spacing:.5px}
  th.r,td.r{text-align:right}th.c,td.c{text-align:center}
  tbody td{padding:11px 13px;border-bottom:1px solid var(--line);font-size:12.5px}
  .bas{display:flex;justify-content:space-between;gap:24px;align-items:flex-start}
  .pay{flex:1;max-width:340px}
  .pay .blk{background:var(--soft);border:1px solid var(--line);border-radius:10px;padding:12px 14px;font-size:11.5px;color:#3a4660;line-height:1.6}
  .pay .lbl{font-size:10px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);font-weight:700;margin-bottom:3px}
  .tot{width:300px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tot .row{display:flex;justify-content:space-between;padding:10px 16px;font-size:13px;border-bottom:1px solid var(--line)}
  .tot .row span:first-child{color:var(--muted)}
  .tot .ttc{background:var(--navy);color:#fff;padding:14px 16px}
  .tot .ttc .lab{font-size:11px;letter-spacing:1px;text-transform:uppercase;opacity:.85}
  .tot .ttc .amt{font-size:20px;font-weight:800;color:var(--gold);font-family:Georgia,serif}
  .annul{margin-top:16px;padding:10px;border:2px solid #c0392b;color:#c0392b;text-align:center;font-weight:800;border-radius:8px;letter-spacing:2px}
  .foot{margin-top:24px;border-top:1px solid var(--line);padding-top:14px;color:var(--muted);font-size:10.5px;text-align:center;line-height:1.7}
  @media print{ @page{size:A4;margin:12mm} body{background:#fff;padding:0} .sheet{box-shadow:none;max-width:none;margin:0;padding:0} .bar{display:none}
    thead th,.tot .ttc{-webkit-print-color-adjust:exact;print-color-adjust:exact} }
</style></head><body>
<div class="bar">
  <a class="back" href="<?= e( url( 'comptabilite/achats/' . $f['id'] ) ) ?>">← Retour</a>
  <button class="print" onclick="window.print()">🖨️ Imprimer / Enregistrer en PDF</button>
</div>
<div class="sheet">
  <div class="head">
    <div class="em">
      <?php if ( $logo ) : ?><img class="em-logo" src="<?= e( $logo ) ?>" alt=""><?php endif; ?>
      <div class="em-id">
        <h1><?= e( $em_nom_aff ) ?></h1>
        <p><?php if ( $em_adr ) : ?><?= e( $em_adr ) ?><br><?php endif; ?><?php if ( $em_ville ) : ?><?= e( $em_ville ) ?><br><?php endif; ?><?php if ( $em_tel ) : ?>Tél : <?= e( $em_tel ) ?><?php endif; ?></p>
        <div class="badges"><?php if ( $em_ncc ) : ?><span class="badge">NCC : <?= e( $em_ncc ) ?></span><?php endif; ?><?php if ( $em_rccm ) : ?><span class="badge">RCCM : <?= e( $em_rccm ) ?></span><?php endif; ?></div>
      </div>
    </div>
    <div class="doc">
      <div class="ttl">FACTURE FOURNISSEUR</div>
      <div class="num"><?= e( $f['numero'] ) ?></div>
      <div class="dt">Date : <?= e( date( 'd/m/Y', strtotime( $f['date_facture'] ) ) ) ?><?php if ( ! empty( $f['date_echeance'] ) ) : ?><br>Échéance : <?= e( date( 'd/m/Y', strtotime( $f['date_echeance'] ) ) ) ?><?php endif; ?><?php if ( ! empty( $f['reference'] ) ) : ?><br>Réf. fournisseur : <?= e( $f['reference'] ) ?><?php endif; ?></div>
    </div>
  </div>
  <div class="rule"></div>
  <div class="parties">
    <div class="to">
      <div class="t">Fournisseur</div>
      <div class="nom"><?= e( $f['fournisseur_nom'] ?: ( $frn['nom'] ?? '—' ) ) ?></div>
      <div class="v">
        <?php if ( $frn ) : ?>
          <?php if ( ! empty( $frn['ncc'] ) ) : ?>NCC : <?= e( $frn['ncc'] ) ?><br><?php endif; ?>
          <?php if ( ! empty( $frn['code'] ) ) : ?>N° : <?= e( $frn['code'] ) ?><br><?php endif; ?>
          <?php if ( ! empty( $frn['telephone'] ) ) : ?><?= e( $frn['telephone'] ) ?><br><?php endif; ?>
          <?php $fv = trim( implode( ', ', array_filter( array( $frn['adresse'] ?? '', $frn['ville'] ?? '' ) ) ) ); if ( $fv ) : ?><?= e( $fv ) ?><?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
    <?php
    /*
     * LE BLOC « STATUT » A ÉTÉ RETIRÉ DE LA PIÈCE (1.738.0).
     *
     * Il affichait « À payer » ou « Annulée ». C'est un état INTERNE de suivi,
     * pas une mention de la facture : le fournisseur a émis son document, et
     * ce que nous en faisons — payé, en attente, annulé chez nous — ne se
     * porte pas sur une pièce que l'on imprime ou que l'on transmet. Il
     * changeait d'ailleurs d'un jour à l'autre, ce qui donnait deux tirages
     * différents d'un même document.
     *
     * L'annulation, elle, reste signalée : le bandeau « FACTURE ANNULÉE —
     * CONTRE-PASSÉE » figure plus bas, et il ne dit pas la même chose. Une
     * pièce contre-passée qui circulerait sans le dire serait trompeuse.
     */
    ?>
  </div>
  <table>
    <thead><tr><th>Désignation</th><th class="c">Qté</th><th class="r">P.U. HT</th><th class="r">Montant HT</th><th class="c">TVA</th><th class="r">Montant TTC</th></tr></thead>
    <tbody>
    <?php if ( $lignes ) : ?>
      <?php foreach ( $lignes as $l ) :
        $lTva = round( (float) $l['montant_ht'] * (float) $f['taux_tva'] / 100, 2 ); ?>
        <tr>
          <td><?= e( (string) $l['designation'] ) ?></td>
          <td class="c"><?= e( rtrim( rtrim( number_format( (float) $l['quantite'], 2, ',', ' ' ), '0' ), ',' ) ) ?></td>
          <td class="r"><?= e( fkc_money( $l['pu_ht'] ) ) ?></td>
          <td class="r"><?= e( fkc_money( $l['montant_ht'] ) ) ?></td>
          <td class="c"><?= (int) $f['taux_tva'] ?> %</td>
          <td class="r"><?= e( fkc_money( (float) $l['montant_ht'] + $lTva ) ) ?></td>
        </tr>
      <?php endforeach; ?>
    <?php else : ?>
      <tr>
        <td><?= e( $desig ) ?></td><td class="c">1</td>
        <td class="r"><?= e( fkc_money( $f['montant_ht'] ) ) ?></td>
        <td class="r"><?= e( fkc_money( $f['montant_ht'] ) ) ?></td>
        <td class="c"><?= (int) $f['taux_tva'] ?> %</td>
        <td class="r"><?= e( fkc_money( $f['montant_ttc'] ) ) ?></td>
      </tr>
    <?php endif; ?>
    </tbody>
  </table>
  <div class="bas">
    <?php
    /*
     * L'IMPUTATION COMPTABLE A ÉTÉ RETIRÉE DE LA PIÈCE (1.737.0).
     *
     * Le bas de page affichait le compte de charge, le compte de TVA
     * déductible et le compte fournisseur. C'est une information de TENUE, pas
     * de document : elle ne concerne ni le fournisseur, ni un tiers à qui l'on
     * transmet la pièce, et elle exposait le plan comptable de l'entreprise à
     * chaque impression ou envoi.
     *
     * Elle n'est pas perdue pour autant — l'écriture reste consultable depuis
     * l'écran de la facture, qui est l'endroit où on la cherche.
     */
    ?>
    <div class="pay"></div>
    <div class="tot">
      <div class="row"><span>Sous-total HT</span><span><?= e( fkc_money( $f['montant_ht'] ) ) ?> <?= e( $cur ) ?></span></div>
      <div class="row"><span>TVA (<?= (int) $f['taux_tva'] ?> %)</span><span><?= e( fkc_money( $f['montant_tva'] ) ) ?> <?= e( $cur ) ?></span></div>
      <div class="ttc"><span class="lab">Net à payer</span><br><span class="amt"><?= e( fkc_money( $f['montant_ttc'] ) ) ?> <?= e( $cur ) ?></span></div>
    </div>
  </div>
  <?php if ( $annulee ) : ?><div class="annul">FACTURE ANNULÉE — CONTRE-PASSÉE</div><?php endif; ?>
  <div class="foot">Pièce d'achat enregistrée — <?= e( $em_nom_aff ) ?><?php if ( $em_ncc ) : ?> · NCC <?= e( $em_ncc ) ?><?php endif; ?><br>Document émis via FinaKop ERP Core</div>
</div>
</body></html>
