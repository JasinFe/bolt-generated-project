<?php
/**
 * Demandes d'achat — le maillon amont de la chaîne d'approvisionnement.
 *
 * @var array       $demandes @var string|null $statut @var array $compteurs
 * @var array       $statuts  @var array       $fournisseurs @var mixed $flash
 * @var array|null  $part_directe
 * @var string      $tab
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$badge = array(
	'a_valider' => 'b-warn', 'validee' => 'b-on', 'commandee' => 'b-on',
	'recue'     => 'b-on',   'refusee' => 'b-off',
);
$origines = array(
	'manuelle' => 'Saisie manuelle', 'seuil' => 'Sous le seuil',
	'rupture'  => 'Rupture de stock', 'prevision' => 'Prévision', 'scan' => 'Scan terrain',
	'directe'  => 'Reçue au comptoir',
);
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="dash-head">
	<h1 style="font-size:20px">📝 Demandes d'achat</h1>
	<form method="post" action="<?= e( url( 'comptabilite/achats/demandes/evaluer' ) ) ?>"
		onsubmit="return confirm('Créer les demandes pour tous les articles sous leur seuil ?')">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-ghost btn-sm" type="submit">🔄 Réapprovisionner</button>
	</form>
</div>

<p class="help">
	Un pack métier exprime un besoin, le service achats décide, l'inventaire reçoit et valorise.
	Les demandes marquées <em>Sous le seuil</em> ou <em>Rupture</em> sont créées automatiquement
	par le moteur de règles.
</p>

<?php if ( $part_directe && $part_directe['pct'] >= 50 ) : ?>
	<div class="alert alert-warn">
		<strong><?= (int) $part_directe['pct'] ?> % des approvisionnements</strong>
		(<?= (int) $part_directe['nb'] ?> sur <?= (int) $part_directe['total'] ?>) sont reçus au comptoir,
		sans demande préalable. C'est légitime pour une livraison imprévue, mais si cela devient la règle,
		le circuit d'achat n'est plus suivi.
	</div>
<?php endif; ?>

<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
	<?php foreach ( $statuts as $code => $lbl ) : $n = (int) ( $compteurs[ $code ] ?? 0 ); ?>
		<a class="btn btn-sm <?= $statut === $code ? 'btn-primary' : 'btn-ghost' ?>"
			href="<?= e( url( 'comptabilite/achats/demandes?statut=' . $code ) ) ?>">
			<?= e( $lbl ) ?><?= $n ? ' (' . $n . ')' : '' ?>
		</a>
	<?php endforeach; ?>
	<a class="btn btn-sm <?= null === $statut ? 'btn-primary' : 'btn-ghost' ?>"
		href="<?= e( url( 'comptabilite/achats/demandes?statut=toutes' ) ) ?>">Toutes</a>
</div>

<div class="card">
	<div class="card-body">
		<?php if ( ! $demandes ) : ?>
			<p class="muted">Aucune demande dans cette vue.</p>
		<?php else : ?>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr>
					<th>N°</th><th>Article</th><th class="num">Qté</th><th>Origine</th>
					<th>Demandeur</th><th>Statut</th><th></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $demandes as $d ) : ?>
					<tr>
						<td><strong><?= e( $d['numero'] ) ?></strong>
							<?php FKC_View::partial( '_connect_bouton', array( 'cx_type' => 'demande_achat', 'cx_id' => (int) $d['id'] ) ); ?><br>
							<span class="muted" style="font-size:11px"><?= e( $d['created_at'] ) ?></span></td>
						<td><?= e( $d['designation'] ) ?>
							<?php if ( $d['motif'] ) : ?><br><span class="muted" style="font-size:11.5px"><?= e( $d['motif'] ) ?></span><?php endif; ?>
						</td>
						<td class="num"><?= e( rtrim( rtrim( number_format( (float) $d['quantite'], 3, ',', ' ' ), '0' ), ',' ) ) ?>
							<?= e( $d['unite'] ) ?></td>
						<td><span class="muted"><?= e( $origines[ $d['origine'] ] ?? $d['origine'] ) ?></span></td>
						<td><?= e( $d['pack'] ?: '—' ) ?></td>
						<td><span class="modbadge <?= e( $badge[ $d['statut'] ] ?? 'b-off' ) ?>"><?= e( $statuts[ $d['statut'] ] ?? $d['statut'] ) ?></span></td>
						<td style="min-width:230px">
							<?php if ( 'a_valider' === $d['statut'] ) : ?>
								<form method="post" action="<?= e( url( 'comptabilite/achats/demandes/' . (int) $d['id'] . '/decider' ) ) ?>"
									style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
									<?= FKC_Csrf::field() ?>
									<input class="fld" type="text" name="note" placeholder="Motif (obligatoire pour refuser)" style="flex:1;min-width:150px">
									<button class="btn btn-primary btn-sm" name="decision" value="valider" type="submit">Valider</button>
									<button class="btn btn-ghost btn-sm" name="decision" value="refuser" type="submit">Refuser</button>
								</form>
							<?php elseif ( 'validee' === $d['statut'] ) : ?>
								<form method="post" action="<?= e( url( 'comptabilite/achats/demandes/' . (int) $d['id'] . '/commander' ) ) ?>"
									style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
									<?= FKC_Csrf::field() ?>
									<select class="fld" name="fournisseur_id" style="min-width:130px">
										<option value="">Fournisseur…</option>
										<?php foreach ( $fournisseurs as $fo ) : ?>
											<option value="<?= (int) $fo['id'] ?>" <?= (int) $d['fournisseur_id'] === (int) $fo['id'] ? 'selected' : '' ?>><?= e( $fo['nom'] ) ?></option>
										<?php endforeach; ?>
									</select>
									<button class="btn btn-primary btn-sm" type="submit">Commander</button>
								</form>
							<?php elseif ( $d['note_validation'] ) : ?>
								<span class="muted" style="font-size:12px"><?= e( $d['note_validation'] ) ?></span>
							<?php else : ?>
								<span class="muted">—</span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif; ?>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Nouvelle demande</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/achats/demandes' ) ) ?>" class="form-rows">
			<?= FKC_Csrf::field() ?>
			<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
				<label style="flex:2;min-width:200px">Désignation
					<input class="fld" type="text" name="designation" required></label>
				<label style="width:110px">Quantité
					<input class="fld" type="number" name="quantite" step="0.001" min="0" required></label>
				<label style="width:90px">Unité
					<input class="fld" type="text" name="unite" placeholder="U"></label>
				<label style="width:130px">Prix estimé
					<input class="fld" type="number" name="pu_estime" step="0.01" min="0"></label>
				<label style="flex:1;min-width:150px">Fournisseur pressenti
					<select class="fld" name="fournisseur_id">
						<option value="">—</option>
						<?php foreach ( $fournisseurs as $fo ) : ?>
							<option value="<?= (int) $fo['id'] ?>"><?= e( $fo['nom'] ) ?></option>
						<?php endforeach; ?>
					</select></label>
			</div>
			<label>Motif du besoin
				<input class="fld" type="text" name="motif" placeholder="Chantier, réassort, remplacement…"></label>
			<button class="btn btn-primary" type="submit">Enregistrer la demande</button>
		</form>
	</div>
</div>
