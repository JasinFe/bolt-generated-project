<?php /** @var array $factures @var float $totHt @var float $totTtc @var array|null $flash @var string $tab @var array $receptions @var array $suspens @var array $orphelines @var array $fournisseurs @var array $pj @var array $etats @var array $nbEtat @var string $filtreCompta */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$pj = $pj ?? array();
$etats = $etats ?? array(); $nbEtat = $nbEtat ?? FKC_EtatCompta::compter( array() ); $filtreCompta = $filtreCompta ?? '';
$st = array( 'a_payer'=>array('À payer','b-warn'), 'payee'=>array('Payée','b-on'), 'annulee'=>array('Annulée','b-off'), 'partielle'=>array('Partiellement payée','b-warn') );
$paiements = $paiements ?? array(); ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<div><span class="stat-label">Achats (hors annulés)</span> <strong style="font-size:16px">HT <?= e( fkc_money($totHt) ) ?> · TTC <?= e( fkc_money($totTtc) ) ?> F</strong></div>
	<?php
	/*
	 * Accès aux demandes depuis l'écran des factures : c'est le même parcours
	 * d'achat, et l'acheteur qui saisit une facture est celui qui décide des
	 * demandes. Un écran qu'aucun lien ne dessert n'existe pas.
	 */
	?>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats/demandes' ) ) ?>">📝 Demandes d'achat<?php
		$nAtt = class_exists( 'FKC_SupplyChain' ) ? (int) ( FKC_SupplyChain::compteurs()['a_valider'] ?? 0 ) : 0;
		echo $nAtt ? ' (' . $nAtt . ')' : '';
	?></a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats/receptions' ) ) ?>">📦 Réceptions<?php
		$nOrph = class_exists( 'FKC_AchatReception' ) ? (int) FKC_AchatReception::suspens()['nombre'] : 0;
		echo $nOrph ? ' ⚠ ' . $nOrph : '';
	?></a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats/avoirs' ) ) ?>">↩️ Avoirs</a>
	<a class="btn btn-primary btn-sm" href="<?= e( url('comptabilite/achats/nouvelle') ) ?>">+ Nouvelle facture d'achat</a>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : n°, fournisseur, date, statut…' ) ); ?>
<?php
/* ── Réceptions reçues, pas encore facturées ──────────────────────────────
   Une marchandise reçue engage l'entreprise avant que la facture arrive : la
   dette figure au bilan en 408 « factures non parvenues ». Elle n'est pas
   payable en l'état — un règlement ne s'impute que sur une dette facturée —
   mais elle doit être visible, sans quoi on découvre les factures en retard.

   Les réceptions SANS FOURNISSEUR sont le cas le plus gênant : la dette existe
   et personne n'est en face. Elles étaient purement et simplement absentes du
   registre jusqu'ici. */
$receptions = $receptions ?? array();
$suspens    = $suspens ?? array( 'nombre' => 0, 'montant' => 0 );
$orphelines = $orphelines ?? array();
$fournisseurs = $fournisseurs ?? array();
$totAttente = 0.0;
foreach ( $receptions as $r ) { $totAttente += (float) $r['montant_ht'] - (float) ( $r['montant_facture'] ?? 0 ); }
?>
<?php if ( $suspens['nombre'] > 0 ) : ?>
<div class="card maint-one">
	<div class="card-head"><h2>⚠ Réceptions sans fournisseur identifié</h2>
		<span class="muted" style="margin-left:auto"><?= (int) $suspens['nombre'] ?> · <?= e( fkc_money( $suspens['montant'] ) ) ?> F</span>
	</div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Ces marchandises sont entrées en stock et leur dette figure au bilan, mais aucun fournisseur ne leur est
			rattaché : elles ne peuvent être <strong>ni facturées, ni réglées</strong>. Attribuez le fournisseur pour
			les rendre payables — le tiers est alors reporté sur l'écriture comptable.
		</p>
		<table class="table">
			<thead><tr><th>Date</th><th>Pièce</th><th>Libellé</th><th>Origine</th><th class="num">Montant HT</th><th>Fournisseur</th></tr></thead>
			<tbody>
			<?php foreach ( $orphelines as $o ) : ?>
				<tr>
					<td><?= e( date( 'd/m/Y', strtotime( $o['date_reception'] ) ) ) ?></td>
					<td class="code"><?= e( $o['piece'] ?: '—' ) ?></td>
					<td><?= e( $o['libelle'] ?: '—' ) ?></td>
					<td class="muted"><?= e( $o['pack'] ?: '—' ) ?></td>
					<td class="num"><?= e( fkc_money( $o['montant_ht'] ) ) ?></td>
					<td>
						<form method="post" action="<?= e( url( 'comptabilite/achats/reception-attribuer' ) ) ?>" style="display:flex;gap:6px;align-items:center">
							<?= FKC_Csrf::field() ?>
							<input type="hidden" name="reception_id" value="<?= (int) $o['id'] ?>">
							<select name="fournisseur_id" required style="min-width:150px">
								<option value="">Choisir…</option>
								<?php foreach ( $fournisseurs as $f ) : ?>
									<option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option>
								<?php endforeach; ?>
							</select>
							<button class="btn btn-primary btn-sm">Attribuer</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endif; ?>

<?php if ( $receptions ) : ?>
<div class="card">
	<div class="card-head"><h2>📦 Reçu, en attente de facture</h2>
		<span class="muted" style="margin-left:auto"><?= count( $receptions ) ?> réception(s) · <?= e( fkc_money( $totAttente ) ) ?> F</span>
	</div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Compte 408 « fournisseurs, factures non parvenues ». Ces montants deviennent payables — et leur TVA
			déductible — à la saisie de la facture, où ils vous sont proposés au rattachement.
		</p>
		<table class="table">
			<thead><tr><th>Date</th><th>Fournisseur</th><th>Pièce</th><th>Libellé</th><th class="num">Reste à facturer</th></tr></thead>
			<tbody>
			<?php foreach ( array_slice( $receptions, 0, 25 ) as $r ) :
				$reste = (float) $r['montant_ht'] - (float) ( $r['montant_facture'] ?? 0 ); ?>
				<tr>
					<td><?= e( date( 'd/m/Y', strtotime( $r['date_reception'] ) ) ) ?></td>
					<td><?= $r['fournisseur_nom'] ? e( $r['fournisseur_nom'] ) : '<span style="color:#b32d2e">à identifier</span>' ?></td>
					<td class="code"><?= e( $r['piece'] ?: '—' ) ?></td>
					<td><?= e( $r['libelle'] ?: '—' ) ?></td>
					<td class="num"><?= e( fkc_money( $reste ) ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( count( $receptions ) > 25 ) : ?><p class="help"><?= count( $receptions ) - 25 ?> autre(s) réception(s) non affichée(s).</p><?php endif; ?>
		<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/achats/nouvelle' ) ) ?>">Saisir la facture correspondante →</a>
	</div>
</div>
<?php endif; ?>

<?php FKC_View::partial( '_etat_compta_compteurs', array( 'nb' => $nbEtat, 'base' => 'comptabilite/achats', 'actif' => $filtreCompta ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>N°</th><th>Fournisseur</th><th>Date</th><th>Réf.</th><th class="num">HT</th><th class="num">TVA</th><th class="num">TTC</th><th class="num">📎</th><th>Statut</th><th>Comptabilité</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $factures ) : ?><tr><td colspan="11" class="empty"><?= $filtreCompta ? 'Aucune facture fournisseur dans cet état.' : 'Aucune facture fournisseur.' ?></td></tr>
	<?php else : foreach ( $factures as $f ) : $b=$st[$f['statut']]??array($f['statut'],'b-off');
		/* 1.745.0 — le statut de paiement est CALCULÉ : « À payer » ne passait
		   jamais « Payée », et un règlement annulé doit rouvrir la facture. */
		$pay = $paiements[ (int) $f['id'] ] ?? null;
		if ( 'annulee' !== $f['statut'] && $pay && 'sans_objet' !== $pay['etat'] ) { $b = $st[ $pay['etat'] ]; }
		$ec = $etats[ (int) $f['id'] ] ?? null;
		$ecCls = array( 'comptabilisee' => 'compta-ok', 'attente' => 'compta-attente', 'a_comptabiliser' => 'compta-a-faire' )[ $ec['etat'] ?? '' ] ?? '';
		if ( 'annulee' === $f['statut'] ) { $ecCls = ''; } ?>
		<tr class="<?= e( $ecCls ) ?>" style="<?= 'annulee'===$f['statut']?'opacity:.55':'' ?>">
		<td><span class="code"><?= e($f['numero']) ?></span></td><td><?= e($f['fournisseur_nom']) ?></td>
		<td class="num"><?= e( date('d/m/Y',strtotime($f['date_facture'])) ) ?></td><td class="muted"><?= e($f['reference'] ?: '—') ?></td>
		<td class="num"><?= e( fkc_money($f['montant_ht']) ) ?></td><td class="num muted"><?= e( fkc_money($f['montant_tva']) ) ?></td>
		<td class="num"><strong><?= e( fkc_money($f['montant_ttc']) ) ?></strong></td>
		<?php
		/*
		 * LE JUSTIFICATIF SE VOIT DEPUIS LA LISTE (1.738.0). Une facture
		 * d'achat sans pièce est le premier point qu'un contrôle relève : le
		 * signaler ici évite d'ouvrir les fiches une par une pour le découvrir.
		 * On ne le signale pas sur une facture annulée — elle n'a plus à être
		 * justifiée.
		 */
		$nbPj = (int) ( $pj[ (int) $f['id'] ] ?? 0 );
		?>
		<td class="num"><?php if ( $nbPj > 0 ) : ?><span title="<?= (int) $nbPj ?> pièce(s) jointe(s)">📎 <?= (int) $nbPj ?></span>
			<?php elseif ( 'annulee' !== $f['statut'] ) : ?><span class="muted" title="Aucun justificatif joint">—</span>
			<?php else : ?><span class="muted">—</span><?php endif; ?></td>
		<td><span class="modbadge <?= $b[1] ?>" data-etat-paiement="<?= e( $pay['etat'] ?? $f['statut'] ) ?>"><?= e($b[0]) ?></span><?php if ( $pay && 'partielle' === $pay['etat'] ) : ?><br><small class="muted">reste <?= e( fkc_money( $pay['reste'] ) ) ?></small><?php endif; ?></td>
		<td><?php FKC_View::partial( '_etat_compta', array( 'ec' => $ec, 'annulee' => 'annulee' === $f['statut'] ) ); ?></td>
		<td class="right"><?php FKC_View::partial( '_connect_bouton', array( 'cx_type' => 'facture_fournisseur', 'cx_id' => (int) $f['id'] ) ); ?>
			<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/achats/'.$f['id']) ) ?>">Voir</a>
			<?php if ( 'annulee' !== $f['statut'] ) : ?>
			<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/achats/'.$f['id'].'/corriger') ) ?>" title="Corriger : extourne puis ressaisie">✏️</a>
			<?php endif; ?>
			<?php
			/*
			 * Suppression offerte DEPUIS LA LISTE, et seulement sur une facture
			 * annulée : c'est là qu'on constate l'encombrement, et l'obliger à
			 * ouvrir la fiche pour un document déjà neutre n'apporte rien.
			 */
			if ( 'annulee' === $f['statut'] ) : ?>
			<form method="post" action="<?= e( url('comptabilite/achats/'.$f['id'].'/supprimer') ) ?>" style="display:inline"
				onsubmit="return confirm('Supprimer définitivement la facture <?= e($f['numero']) ?> ?\n\nLes écritures de comptabilisation et de contre-passation RESTENT au journal — elles s\'annulent, et le journal doit rester ininterrompu.')">
				<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" title="Supprimer cette facture annulée">🗑</button>
			</form>
			<?php endif; ?>
		</td></tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
