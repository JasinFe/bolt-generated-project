<?php
/**
 * ASSISTANT DE CLÔTURE.
 *
 * Trois blocs, dans l'ordre où on s'en sert : l'avancement (où j'en suis), la
 * checklist (ce qui me bloque), les actions (ce que je peux faire maintenant).
 *
 * La progression est en HAUT et à l'HORIZONTALE : sept étapes empilées
 * verticalement poussent les actions hors de l'écran sur une tablette, et
 * c'est sur tablette que se fait une bonne part du travail de terrain.
 *
 * @var int $annee @var array $annees @var string $libelle @var array $processus @var string $inventaire
 * @var array $categories @var array $synthese @var array|null $cloture
 * @var array|null $affectation @var bool $an_existent @var bool $admin @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$coul = array(
	'faite'    => '#3ddc84',
	'en_cours' => '#ffb020',
	'a_faire'  => '#8a93a6',
	'bloquee'  => '#4a5164',
);
$niveaux = array(
	'absolu'        => array( 'Absolu',        '#ff4d4d' ),
	'bloquant'      => array( 'Bloquant',      '#ff6b6b' ),
	'avertissement' => array( 'Avertissement', '#ffb020' ),
	'information'   => array( 'Information',   '#6aa9ff' ),
);
$prog = (int) $processus['progression'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.clot-steps{display:flex;gap:8px;overflow-x:auto;padding:4px 0 10px}
.clot-step{flex:1 0 150px;min-width:150px;border-radius:10px;padding:10px 12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07)}
.clot-step b{display:block;font-size:13px;margin-bottom:3px}
.clot-step .st{font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;font-weight:700}
.clot-step .mq{font-size:11.5px;color:#9aa3b5;margin-top:5px;line-height:1.35}
.clot-bar{height:6px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;margin:2px 0 14px}
.clot-bar i{display:block;height:100%;background:#3ddc84}
.clot-actions{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end}
.clot-cat{border-top:1px solid rgba(255,255,255,.07)}
.clot-ctl{display:flex;gap:12px;align-items:flex-start;padding:10px 0}
.clot-dot{flex:0 0 12px;height:12px;border-radius:99px;margin-top:5px}
.clot-det{font-size:12px;color:#9aa3b5;margin-top:4px;line-height:1.45}
.clot-just{margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.clot-just input[type=text]{flex:1 1 260px;min-width:180px}
@media(max-width:640px){.clot-step{flex:1 0 82%;min-width:82%}}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Clôture de l\'exercice ' . $libelle, 'route' => 'comptabilite/cloture', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Journal', 'comptabilite/cloture/journal?annee=' . (int) $annee ), array( '🖨 Dossier de clôture', 'comptabilite/cloture/imprimer?annee=' . (int) $annee . '&rapport=dossier', 'blank' => true, 'title' => 'État de clôture, anomalies, à-nouveaux, rapprochement N/N+1, fiscalité' ) ) ) ); ?>
<div class="card-body">

	<div class="clot-bar"><i style="width:<?= $prog ?>%"></i></div>
	<p class="muted" style="margin:0 0 8px;font-size:12.5px">
		<strong><?= (int) $processus['faites'] ?> / <?= (int) $processus['total'] ?></strong> étapes achevées.
		Chaque étape est <em>lue dans les écritures</em>, pas déclarée : seules « Préparation » et
		« Régularisations », qui n'ont pas de trace comptable propre, se confirment à la main.
	</p>

	<?php if ( ! empty( $inventaire ) ) : ?>
		<p style="margin:0 0 10px;font-size:13px">
			<?= e( (string) $inventaire ) ?>
			<a href="<?= e( url( 'comptabilite/cloture/inventaire?annee=' . (int) $annee ) ) ?>">Voir les travaux d'inventaire</a>
		</p>
	<?php endif; ?>

	<?php if ( ! empty( $fiscal ) ) : ?>
		<p style="margin:0 0 10px;font-size:13px">
			<?= e( (string) $fiscal ) ?>
			<a href="<?= e( url( 'comptabilite/cloture/fiscal?annee=' . (int) $annee ) ) ?>">Voir le tableau de passage fiscal</a>
		</p>
	<?php endif; ?>

	<div class="clot-steps">
	<?php foreach ( $processus['etapes'] as $e ) :
		$c = $coul[ $e['statut'] ] ?? '#8a93a6'; ?>
		<div class="clot-step" style="border-color:<?= $c ?>33">
			<span class="st" style="color:<?= $c ?>">
				<?= (int) $e['ordre'] ?>. <?= 'faite' === $e['statut'] ? 'Fait' : ( 'bloquee' === $e['statut'] ? 'En attente' : ( 'en_cours' === $e['statut'] ? 'En cours' : 'À faire' ) ) ?>
			</span>
			<b><?= e( $e['libelle'] ) ?></b>
			<div class="mq"><?= e( '' !== $e['manque'] ? $e['manque'] : $e['objet'] ) ?></div>
			<?php if ( ! $e['auto'] && 'bloquee' !== $e['statut'] ) : ?>
				<form method="post" action="<?= e( url( 'comptabilite/cloture/etape' ) ) ?>" style="margin-top:8px">
					<?= FKC_Csrf::field() ?>
					<input type="hidden" name="annee" value="<?= (int) $annee ?>">
					<input type="hidden" name="etape" value="<?= e( $e['code'] ) ?>">
					<input type="hidden" name="valide" value="<?= 'faite' === $e['statut'] ? '0' : '1' ?>">
					<button class="btn btn-ghost btn-sm" type="submit"><?= 'faite' === $e['statut'] ? 'Retirer' : 'Confirmer' ?></button>
				</form>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
	</div>
</div></div>

<?php /* ── Actions disponibles ─────────────────────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Actions</h2></div><div class="card-body">
	<div class="clot-actions">

		<?php if ( ! $cloture ) : ?>
			<form method="post" action="<?= e( url( 'comptabilite/cloture/resultat' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<input type="hidden" name="annee" value="<?= (int) $annee ?>">
				<button class="btn btn-ghost" type="submit">Déterminer le résultat</button>
			</form>

			<form method="post" action="<?= e( url( 'comptabilite/cloture/cloturer' ) ) ?>"
				onsubmit="return confirm('Clôturer et verrouiller l\'exercice <?= (int) $annee ?> ? Plus aucune écriture ne pourra y être saisie.')">
				<?= FKC_Csrf::field() ?>
				<input type="hidden" name="annee" value="<?= (int) $annee ?>">
				<input type="hidden" name="type" value="annuelle">
				<button class="btn btn-primary" type="submit" <?= (int) $synthese['bloquants'] > 0 ? 'disabled' : '' ?>>
					Clôturer l'exercice <?= (int) $annee ?>
				</button>
			</form>
			<?php if ( (int) $synthese['bloquants'] > 0 ) : ?>
				<span class="muted" style="font-size:12.5px;color:#ff6b6b">
					<?= (int) $synthese['bloquants'] ?> contrôle(s) bloquant(s) : la clôture est refusée tant qu'ils
					ne sont pas corrigés ou levés par dérogation motivée.
				</span>
			<?php endif; ?>

		<?php else : ?>
			<div style="flex:1 1 100%">
				<p style="margin:0 0 6px"><strong style="color:#3ddc84">Exercice clôturé</strong>
					le <?= e( date( 'd/m/Y', strtotime( (string) $cloture['date_cloture'] ) ) ) ?>
					<?= ! empty( $cloture['cloture_nom'] ) ? 'par ' . e( (string) $cloture['cloture_nom'] ) : '' ?>
					— résultat net <strong><?= e( fkc_money( $cloture['resultat'] ) ) ?> F CFA</strong>
					(<?= (float) $cloture['resultat'] >= 0 ? 'bénéfice' : 'perte' ?>).
					<?php if ( ! empty( $cloture['definitive'] ) ) : ?>
						<span style="color:#ff6b6b;font-weight:700">· DÉFINITIVE</span>
					<?php endif; ?>
				</p>
			</div>

			<a class="btn btn-primary" href="<?= e( url( 'comptabilite/cloture/affectation?annee=' . (int) $annee ) ) ?>">
				<?= $affectation ? 'Voir l\'affectation' : 'Affecter le résultat' ?>
			</a>
			<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/cloture/anouveaux?ouvrir=' . ( (int) $annee + 1 ) ) ) ?>">
				<?= $an_existent ? 'À-nouveaux ' . ( (int) $annee + 1 ) : 'Ouvrir ' . ( (int) $annee + 1 ) ?>
			</a>

			<?php if ( $admin && empty( $cloture['definitive'] ) ) : ?>
				<form method="post" action="<?= e( url( 'comptabilite/cloture/' . (int) $cloture['id'] . '/rouvrir' ) ) ?>"
					style="flex:1 1 100%;display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:6px"
					onsubmit="return confirm('Rouvrir la clôture annuelle <?= (int) $annee ?> ? L\'écriture de détermination du résultat sera retirée, et la réouverture consignée au journal.')">
					<?= FKC_Csrf::field() ?>
					<input type="text" name="motif" required minlength="20" style="flex:1 1 320px"
						placeholder="Motif de la réouverture (obligatoire, ≥ 20 caractères) — il sera lu lors d'un contrôle fiscal">
					<button class="btn btn-ghost btn-sm" type="submit">Rouvrir</button>
				</form>

				<form method="post" action="<?= e( url( 'comptabilite/cloture/' . (int) $cloture['id'] . '/verrouiller' ) ) ?>"
					style="flex:1 1 100%;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
					<?= FKC_Csrf::field() ?>
					<input type="text" name="confirm" required style="flex:0 1 160px" placeholder="Saisir DEFINITIF">
					<input type="text" name="note" style="flex:1 1 260px" placeholder="Note (dépôt DGI, approbation AGO…)">
					<button class="btn btn-ghost btn-sm" type="submit">Verrouiller définitivement</button>
				</form>
				<p class="muted" style="flex:1 1 100%;font-size:12px;margin:0">
					Le verrou définitif s'applique <em>après</em> l'approbation des comptes et le dépôt de la liasse :
					il rend la réouverture impossible, pour tout le monde et sans exception. Tant qu'il n'est pas posé,
					un retraitement demandé par l'expert-comptable reste possible — c'est pourquoi les deux gestes
					sont séparés.
				</p>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</div></div>

<?php /* ── Checklist ───────────────────────────────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Contrôles de clôture',
	'info' => (int) $synthese['total'] . ' contrôles · <span style="color:' . ( (int) $synthese['bloquants'] ? '#ff6b6b' : '#3ddc84' ) . '">' . (int) $synthese['bloquants'] . ' bloquant(s)</span> · '
		. (int) $synthese['avertissements'] . ' avertissement(s)' . ( (int) $synthese['derogations'] ? ' · ' . (int) $synthese['derogations'] . ' dérogation(s)' : '' )
		. ( (int) $synthese['pannes'] ? ' · ' . (int) $synthese['pannes'] . ' non évaluable(s)' : '' ) ) ); ?>
<div class="card-body">

<?php foreach ( $categories as $cat ) : ?>
	<div class="clot-cat" style="padding-top:10px;margin-top:10px">
	<h3 style="font-size:13px;text-transform:uppercase;letter-spacing:.5px;color:#9aa3b5;margin:0 0 4px">
		<?= e( $cat['libelle'] ) ?>
		<?php if ( $cat['bloquants'] ) : ?><span style="color:#ff6b6b">· <?= (int) $cat['bloquants'] ?> bloquant(s)</span><?php endif; ?>
	</h3>

	<?php foreach ( $cat['controles'] as $c ) :
		list( $nivLbl, $nivCol ) = $niveaux[ $c['niveau'] ] ?? array( $c['niveau'], '#8a93a6' );
		$dot = $c['anomalie'] ? ( $c['bloque'] ? $nivCol : ( $c['couvert'] ? '#6aa9ff' : '#ffb020' ) ) : '#3ddc84';
		if ( 'information' === $c['niveau'] ) { $dot = '#6aa9ff'; } ?>
		<div class="clot-ctl">
			<span class="clot-dot" style="background:<?= $dot ?>"></span>
			<div style="flex:1">
				<div style="display:flex;gap:8px;align-items:baseline;flex-wrap:wrap">
					<strong style="font-size:13.5px"><?= e( $c['libelle'] ) ?></strong>
					<span style="font-size:11px;color:<?= $nivCol ?>;text-transform:uppercase;letter-spacing:.4px"><?= e( $nivLbl ) ?></span>
					<?php if ( $c['anomalie'] && 'information' !== $c['niveau'] ) : ?>
						<span style="font-weight:700;color:<?= $dot ?>"><?= (int) $c['nb'] ?></span>
					<?php endif; ?>
					<?php if ( $c['couvert'] ) : ?>
						<span style="font-size:11px;color:#6aa9ff">· <?= 'derogation' === (string) $c['justification']['nature'] ? 'dérogation' : 'justifié' ?>
							par <?= e( (string) $c['justification']['par_nom'] ) ?></span>
					<?php endif; ?>
				</div>
				<div class="clot-det"><?= e( $c['note'] ) ?></div>
				<?php if ( $c['detail'] ) : ?>
					<div class="clot-det" style="color:#c3cadb">
						<?php foreach ( array_slice( $c['detail'], 0, 8 ) as $d ) : ?>
							<div>— <?= e( (string) $d ) ?></div>
						<?php endforeach; ?>
						<?php if ( count( $c['detail'] ) > 8 ) : ?><div class="muted">… et <?= count( $c['detail'] ) - 8 ?> autre(s)</div><?php endif; ?>
					</div>
				<?php endif; ?>
				<?php if ( $c['couvert'] ) : ?>
					<div class="clot-det" style="color:#6aa9ff">Motif : <?= e( (string) $c['justification']['motif'] ) ?></div>
				<?php endif; ?>

				<?php if ( $c['anomalie'] && 'absolu' !== $c['niveau'] && 'information' !== $c['niveau'] ) : ?>
					<div class="clot-just">
						<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $c['ou'] ) ) ?>">Corriger</a>
						<?php if ( $c['couvert'] ) : ?>
							<form method="post" action="<?= e( url( 'comptabilite/cloture/justification/retirer' ) ) ?>" style="margin:0">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="annee" value="<?= (int) $annee ?>">
								<input type="hidden" name="controle" value="<?= e( $c['code'] ) ?>">
								<button class="btn btn-ghost btn-sm" type="submit">Retirer la justification</button>
							</form>
						<?php elseif ( 'bloquant' !== $c['niveau'] || $admin ) : ?>
							<form method="post" action="<?= e( url( 'comptabilite/cloture/justifier' ) ) ?>" style="display:flex;gap:6px;flex:1 1 300px;margin:0">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="annee" value="<?= (int) $annee ?>">
								<input type="hidden" name="controle" value="<?= e( $c['code'] ) ?>">
								<input type="text" name="motif" required
									minlength="<?= 'bloquant' === $c['niveau'] ? 20 : 5 ?>"
									placeholder="<?= 'bloquant' === $c['niveau']
										? 'Dérogation : pourquoi ce contrôle ne s\'applique pas à ce dossier (≥ 20 car.)'
										: 'Justification (≥ 5 car.)' ?>">
								<button class="btn btn-ghost btn-sm" type="submit"><?= 'bloquant' === $c['niveau'] ? 'Déroger' : 'Justifier' ?></button>
							</form>
						<?php else : ?>
							<span class="muted" style="font-size:12px">Seul un administrateur peut lever un contrôle bloquant.</span>
						<?php endif; ?>
					</div>
				<?php elseif ( $c['anomalie'] && 'absolu' === $c['niveau'] ) : ?>
					<div class="clot-just">
						<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $c['ou'] ) ) ?>">Corriger</a>
						<span class="muted" style="font-size:12px;color:#ff4d4d">
							Ce contrôle ne se justifie pas : il constate une impossibilité comptable, pas un choix de gestion.
						</span>
					</div>
				<?php endif; ?>
			</div>
		</div>
	<?php endforeach; ?>
	</div>
<?php endforeach; ?>
</div></div>
