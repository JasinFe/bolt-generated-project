<?php
/**
 * DU RÉSULTAT COMPTABLE AU RÉSULTAT FISCAL.
 *
 * L'écran est une CASCADE, et l'ordre des lignes est l'essentiel : résultat
 * comptable, réintégrations, déductions, résultat fiscal, déficits imputés,
 * base imposable, impôt. Chaque ligne se déduit de la précédente, et c'est
 * exactement la présentation que la DGI attend. Un tableau où l'on devrait
 * chercher d'où vient un nombre ne se défend pas devant un vérificateur.
 *
 * @var int $annee @var array $annees @var array $fisc @var array $natures
 * @var array $conf @var array|null $cloture @var bool $admin @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$imp  = $fisc['impot'];
$def  = $fisc['deficits'];
$fige = (bool) $fisc['fige'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.fx-cas{width:100%;border-collapse:collapse;font-size:14px}
.fx-cas td{padding:9px 10px;border-bottom:1px solid rgba(255,255,255,.06)}
.fx-cas td.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.fx-cas tr.tot td{font-weight:700;border-top:2px solid rgba(255,255,255,.18);border-bottom:none;background:rgba(255,255,255,.03)}
.fx-cas tr.fin td{font-weight:800;font-size:16px;background:rgba(61,220,132,.08)}
.fx-sub td{color:#9aa3b5;font-size:12.5px;padding-left:26px}
.fx-note{font-size:12.5px;color:#9aa3b5;line-height:1.55}
.fx-prop{border:1px solid rgba(255,176,32,.35);border-radius:10px;padding:10px 12px;margin-bottom:8px;background:rgba(255,176,32,.06)}
@media(max-width:700px){.fx-cas td{padding:7px 6px;font-size:13px}}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Résultat fiscal — ' . (int) $annee, 'route' => 'comptabilite/cloture/fiscal', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Assistant de clôture', 'comptabilite/cloture?annee=' . (int) $annee ), array( 'Acomptes d\'IS', 'comptabilite/cloture/acomptes?annee=' . (int) $annee ), array( 'Rapprochement TVA', 'comptabilite/cloture/tva?annee=' . (int) $annee ), array( '🖨 Fiscalité de clôture', 'comptabilite/cloture/imprimer?annee=' . (int) $annee . '&rapport=fiscal', 'blank' => true ) ) ) ); ?>
<div class="card-body">
	<p class="fx-note" style="margin:0">
		Le résultat comptable et le résultat fiscal sont <strong>deux nombres différents</strong>. Le premier
		est celui du compte de résultat ; le second est celui que la DGI impose, après réintégration des charges
		non déductibles et déduction des produits non imposables. L'impôt s'assoit sur le second, diminué des
		déficits antérieurs encore reportables.
	</p>
	<?php if ( ! $imp['applicable'] ) : ?>
		<p style="margin:10px 0 0;color:#ffb020"><strong>Régime <?= e( (string) $imp['regime'] ) ?></strong> —
			<?= e( (string) $imp['label'] ) ?></p>
	<?php endif; ?>
	<?php if ( $fige ) : ?>
		<p style="margin:10px 0 0;color:#3ddc84"><strong>Résultat fiscal arrêté.</strong> Le tableau ne bouge plus :
			les déficits reportés sur les exercices suivants s'y adossent.</p>
	<?php endif; ?>
</div></div>

<?php /* ── LA CASCADE ─────────────────────────────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Tableau de passage</h3></div>
<div class="card-body" style="padding-top:4px">
<table class="fx-cas">
	<tr>
		<td>Résultat comptable avant impôt</td>
		<td class="n"><?= fkc_money( $fisc['resultat_comptable'] ) ?></td>
	</tr>
	<tr class="fx-sub"><td colspan="2">
		Produits <?= fkc_money( $fisc['detail_comptable']['produits'] ?? 0 ) ?> − charges
		<?= fkc_money( $fisc['detail_comptable']['charges'] ?? 0 ) ?>, hors activités ordinaires comprises.
		Le compte 89 en est exclu : l'impôt ne se calcule pas sur lui-même.
	</td></tr>

	<tr><td>+ Réintégrations</td><td class="n"><?= fkc_money( $fisc['reintegrations'] ) ?></td></tr>
	<?php foreach ( $fisc['lignes'] as $l ) : if ( 'reintegration' !== $l['sens'] ) { continue; } ?>
		<tr class="fx-sub"><td>
			<?= e( (string) $l['libelle'] ) ?>
			<?php if ( 'auto' === $l['origine'] ) : ?><span style="color:#6aa9ff"> · proposé</span><?php endif; ?>
			<?php if ( ! $fige ) : ?>
				<form method="post" action="<?= e( url( 'comptabilite/cloture/fiscal/' . (int) $l['id'] . '/retirer' ) ) ?>" style="display:inline;margin-left:6px">
					<input type="hidden" name="annee" value="<?= (int) $annee ?>">
					<button class="btn btn-ghost btn-sm" style="padding:1px 7px;font-size:11px">retirer</button>
				</form>
			<?php endif; ?>
		</td><td class="n"><?= fkc_money( (float) $l['montant'] ) ?></td></tr>
	<?php endforeach; ?>

	<tr><td>− Déductions</td><td class="n"><?= fkc_money( $fisc['deductions'] ) ?></td></tr>
	<?php foreach ( $fisc['lignes'] as $l ) : if ( 'deduction' !== $l['sens'] ) { continue; } ?>
		<tr class="fx-sub"><td>
			<?= e( (string) $l['libelle'] ) ?>
			<?php if ( ! $fige ) : ?>
				<form method="post" action="<?= e( url( 'comptabilite/cloture/fiscal/' . (int) $l['id'] . '/retirer' ) ) ?>" style="display:inline;margin-left:6px">
					<input type="hidden" name="annee" value="<?= (int) $annee ?>">
					<button class="btn btn-ghost btn-sm" style="padding:1px 7px;font-size:11px">retirer</button>
				</form>
			<?php endif; ?>
		</td><td class="n"><?= fkc_money( (float) $l['montant'] ) ?></td></tr>
	<?php endforeach; ?>

	<tr class="tot"><td>= Résultat fiscal</td><td class="n"><?= fkc_money( $fisc['resultat_fiscal'] ) ?></td></tr>

	<?php if ( $fisc['deficit_genere'] > 0 ) : ?>
		<tr class="fx-sub"><td colspan="2" style="color:#ffb020">
			Exercice déficitaire. Ce déficit ne sera reportable sur les <?= (int) FKC_ResultatFiscal::REPORT_ANS ?>
			exercices suivants que si le résultat fiscal est <strong>arrêté</strong> ci-dessous.
		</td></tr>
	<?php endif; ?>

	<tr><td>− Déficits antérieurs imputés</td><td class="n"><?= fkc_money( $fisc['deficits_imputes'] ) ?></td></tr>
	<?php foreach ( $def['lignes'] as $x ) : ?>
		<tr class="fx-sub"><td>Déficit <?= (int) $x['exercice'] ?> — reportable jusqu'à <?= (int) $x['expire_en'] ?></td>
			<td class="n"><?= fkc_money( $x['montant'] ) ?></td></tr>
	<?php endforeach; ?>

	<tr class="fin"><td>= Base imposable</td><td class="n"><?= fkc_money( $fisc['base_imposable'] ) ?></td></tr>

	<?php if ( $imp['applicable'] ) : ?>
		<tr><td>Impôt BIC / IS (<?= e( (string) ( $imp['taux'] ?? '' ) ) ?> %)</td><td class="n"><?= fkc_money( $imp['bic_normal'] ) ?></td></tr>
		<tr><td>Impôt minimum forfaitaire</td><td class="n"><?= fkc_money( $imp['imf'] ) ?></td></tr>
		<tr class="fin"><td>Impôt dû — <?= e( (string) $imp['label'] ) ?></td><td class="n"><?= fkc_money( $imp['du'] ) ?></td></tr>
	<?php endif; ?>
</table>

<?php if ( $imp['applicable'] && $imp['imf'] > $imp['bic_normal'] ) : ?>
	<p class="fx-note" style="margin:12px 0 0">
		L'impôt minimum forfaitaire l'emporte : en Côte d'Ivoire, un exercice déficitaire n'exonère pas d'impôt,
		il fait tomber sur l'IMF, assis sur le chiffre d'affaires. Les retraitements fiscaux ne le déplacent pas
		d'un franc — c'est précisément ce qui en fait un minimum.
	</p>
<?php endif; ?>
</div></div>

<?php /* ── CONFRONTATION AVEC LA COMPTABILITÉ ─────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Impôt calculé et impôt comptabilisé</h3></div>
<div class="card-body">
	<p style="margin:0;<?= abs( (float) $conf['ecart'] ) >= 1 ? 'color:#ffb020' : 'color:#3ddc84' ?>">
		<strong><?= e( (string) $conf['message'] ) ?></strong>
	</p>
	<p class="fx-note" style="margin:8px 0 0">
		Tant que l'impôt n'est pas porté en classe 89, le résultat net inscrit au bilan est surévalué d'autant —
		et l'affectation du résultat portera sur ce nombre. L'écart peut être régulier : acomptes déjà versés,
		crédits d'impôt, retenues subies. Il doit alors être justifié, pas ignoré.
	</p>
</div></div>

<?php /* ── PROPOSITIONS ───────────────────────────────────────────────── */ ?>
<?php if ( $fisc['propositions'] && ! $fige ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Ce que le grand livre désigne</h3></div>
<div class="card-body">
	<p class="fx-note" style="margin:0 0 10px">
		Ces éléments sont <strong>proposés</strong>, jamais appliqués d'office : FinaKop connaît le grand livre,
		pas les agréments, exonérations et conventions du dossier. Accepter reste un geste humain, et il est daté.
	</p>
	<?php foreach ( $fisc['propositions'] as $p ) : ?>
		<div class="fx-prop">
			<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:baseline">
				<strong><?= e( $p['libelle'] ) ?></strong>
				<span style="font-variant-numeric:tabular-nums;font-weight:700"><?= fkc_money( $p['montant'] ) ?> F CFA</span>
			</div>
			<p class="fx-note" style="margin:5px 0 8px"><?= e( $p['note'] ) ?></p>
			<form method="post" action="<?= e( url( 'comptabilite/cloture/fiscal/accepter' ) ) ?>" style="margin:0">
				<input type="hidden" name="annee" value="<?= (int) $annee ?>">
				<input type="hidden" name="source_type" value="<?= e( (string) $p['source_type'] ) ?>">
				<input type="hidden" name="source_id" value="<?= (int) $p['source_id'] ?>">
				<button class="btn btn-sm">Réintégrer</button>
			</form>
		</div>
	<?php endforeach; ?>
</div></div>
<?php endif; ?>

<?php /* ── SAISIE ─────────────────────────────────────────────────────── */ ?>
<?php if ( ! $fige ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Ajouter un retraitement</h3></div>
<div class="card-body">
	<form method="post" action="<?= e( url( 'comptabilite/cloture/fiscal/ajouter' ) ) ?>">
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">
		<div class="grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px">
			<label>Nature
				<select name="nature" id="fx-nat" required>
					<optgroup label="Réintégrations (augmentent la base)">
						<?php foreach ( $natures as $code => $n ) : if ( 'reintegration' !== $n['sens'] ) { continue; } ?>
							<option value="<?= e( $code ) ?>" data-note="<?= e( $n['note'] ) ?>"><?= e( $n['libelle'] ) ?></option>
						<?php endforeach; ?>
					</optgroup>
					<optgroup label="Déductions (diminuent la base)">
						<?php foreach ( $natures as $code => $n ) : if ( 'deduction' !== $n['sens'] ) { continue; } ?>
							<option value="<?= e( $code ) ?>" data-note="<?= e( $n['note'] ) ?>"><?= e( $n['libelle'] ) ?></option>
						<?php endforeach; ?>
					</optgroup>
				</select>
			</label>
			<label>Montant (F CFA)<input type="text" name="montant" inputmode="decimal" required></label>
			<label>Libellé<input type="text" name="libelle" placeholder="Laissé vide : le nom de la nature"></label>
		</div>
		<label style="display:block;margin-top:10px">Justification
			<textarea name="justification" rows="2" placeholder="Obligatoire pour toute déduction et pour les natures d'appréciation."></textarea>
		</label>
		<p class="fx-note" id="fx-note" style="margin:6px 0 10px"></p>
		<button class="btn">Ajouter au tableau de passage</button>
		<p class="fx-note" style="margin:8px 0 0">
			Le montant est toujours <strong>positif</strong> : le sens vient de la nature, jamais du signe.
			Une déduction saisie en négatif s'additionnerait aux réintégrations.
		</p>
	</form>
</div></div>
<script>
(function(){
	var s=document.getElementById('fx-nat'), n=document.getElementById('fx-note');
	if(!s||!n){return;}
	function maj(){ var o=s.options[s.selectedIndex]; n.textContent=o?(o.getAttribute('data-note')||''):''; }
	s.addEventListener('change',maj); maj();
})();
</script>
<?php endif; ?>

<?php /* ── ARRÊTÉ ─────────────────────────────────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Arrêté du résultat fiscal</h3></div>
<div class="card-body">
	<?php if ( ! $fige ) : ?>
		<p class="fx-note" style="margin:0 0 10px">
			Arrêter fige le tableau et rend le déficit éventuel <strong>reportable</strong> sur les
			<?= (int) FKC_ResultatFiscal::REPORT_ANS ?> exercices suivants. Sans arrêté, le report n'a rien à lire :
			un déficit recalculé chaque année sur une comptabilité qui a pu être rouverte ne serait pas opposable.
		</p>
		<?php foreach ( $def['non_figes'] as $x ) : ?>
			<p style="margin:0 0 6px;color:#ffb020">⚠ L'exercice <?= (int) $x['exercice'] ?> est déficitaire de
				<?= fkc_money( $x['montant'] ) ?> F CFA et n'a jamais été arrêté : ce déficit n'est imputable nulle part.</p>
		<?php endforeach; ?>
		<?php foreach ( $def['expires'] as $x ) : ?>
			<p style="margin:0 0 6px;color:#ff6b6b">Le déficit <?= (int) $x['exercice'] ?> de <?= fkc_money( $x['montant'] ) ?>
				F CFA est <strong>expiré</strong> : plus de <?= (int) FKC_ResultatFiscal::REPORT_ANS ?> exercices.</p>
		<?php endforeach; ?>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/fiscal/figer' ) ) ?>">
			<input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<button class="btn">Arrêter le résultat fiscal de <?= (int) $annee ?></button>
		</form>
	<?php elseif ( $admin ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/fiscal/defiger' ) ) ?>">
			<input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<label style="display:block">Motif (20 caractères au moins)
				<textarea name="motif" rows="2" required></textarea>
			</label>
			<p class="fx-note" style="margin:6px 0 10px">
				Défiger remet en cause les déficits déjà imputés par les exercices suivants. L'opération est tracée
				au journal de clôture.
			</p>
			<button class="btn btn-danger">Annuler l'arrêté fiscal</button>
		</form>
	<?php else : ?>
		<p class="fx-note" style="margin:0">Le résultat fiscal est arrêté. Seul un administrateur peut revenir dessus.</p>
	<?php endif; ?>
</div></div>
