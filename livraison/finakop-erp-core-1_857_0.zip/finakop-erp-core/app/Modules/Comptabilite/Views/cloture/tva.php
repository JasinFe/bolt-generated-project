<?php
/**
 * RAPPROCHEMENT TVA — grand livre contre déclarations déposées (1.784.0).
 *
 * Mois par mois : la TVA collectée que porte le grand livre (hors OD de
 * déclaration) et celle que la déclaration a soldée. Un écart nomme les
 * écritures saisies après le dépôt.
 *
 * @var int $annee @var array $annees @var array $rap @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$lib = array( 'declaree' => 'Concordant', 'ecart' => 'Écart', 'non_declaree' => 'Non déclarée', 'a_declarer' => 'À déclarer', 'non_comptabilisee' => 'Déclaration non comptabilisée', 'sans_tva' => 'Sans TVA' );
$col = array( 'declaree' => '#3ddc84', 'ecart' => '#ff6b6b', 'non_declaree' => '#ff6b6b', 'a_declarer' => '#9aa3b5', 'non_comptabilisee' => '#ffb020', 'sans_tva' => '#9aa3b5' );
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div><?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Rapprochement TVA — ' . (int) $annee, 'route' => 'comptabilite/cloture/tva', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Déclarations', 'fiscalite/declarations' ), array( 'Assistant de clôture', 'comptabilite/cloture?annee=' . (int) $annee ) ) ) ); ?>
<div class="card-body">
	<p style="margin:0 0 6px;color:<?= $rap['nb_anomalies'] ? '#ff6b6b' : '#3ddc84' ?>"><strong><?= e( $rap['message'] ) ?></strong></p>
	<p class="muted" style="margin:0;font-size:12.5px">« Déclarée » est ce que l'écriture de la déclaration a soldé sur les comptes de TVA collectée ; « grand livre », le crédit net de ces comptes sur le mois, hors écritures de déclaration.
	Un écart positif est une TVA facturée jamais déclarée — déclaration rectificative à déposer.</p>
</div></div>

<?php if ( $rap['applicable'] && $rap['mois'] ) : ?>
<div class="card card-flush" style="margin-top:12px">
<table class="table"><thead><tr><th>Mois</th><th class="right">Grand livre</th><th class="right">Déclarée</th><th class="right">Écart</th><th>Situation</th><th>Cause</th></tr></thead><tbody>
<?php foreach ( $rap['mois'] as $m ) : ?>
	<tr>
		<td class="mono"><?= e( $m['periode'] ) ?></td>
		<td class="right mono"><?= e( fkc_money( $m['gl'] ) ) ?></td>
		<td class="right mono"><?= e( fkc_money( $m['declare'] ) ) ?></td>
		<td class="right mono" style="<?= abs( $m['ecart'] ) >= 1 ? 'color:#ff6b6b' : '' ?>"><?= e( fkc_money( $m['ecart'] ) ) ?></td>
		<td style="color:<?= e( $col[ $m['statut'] ] ?? '#9aa3b5' ) ?>"><?= e( $lib[ $m['statut'] ] ?? $m['statut'] ) ?></td>
		<td style="font-size:12px"><?= e( implode( ' ', $m['causes'] ) ) ?>
			<?php foreach ( array_slice( $m['ecritures'], 0, 5 ) as $x ) : ?><div class="muted">n° <?= (int) $x['id'] ?> du <?= e( date( 'd/m/Y', strtotime( $x['date_ecriture'] ) ) ) ?> — <?= e( $x['libelle'] ) ?> (<?= e( fkc_money( $x['tva'] ) ) ?>)</div><?php endforeach; ?>
		</td>
	</tr>
<?php endforeach; ?>
<tr style="font-weight:700"><td>Total</td><td class="right mono"><?= e( fkc_money( $rap['total_gl'] ) ) ?></td><td class="right mono"><?= e( fkc_money( $rap['total_declare'] ) ) ?></td><td class="right mono"><?= e( fkc_money( $rap['total_ecart'] ) ) ?></td><td colspan="2"></td></tr>
</tbody></table></div>
<?php endif; ?>
