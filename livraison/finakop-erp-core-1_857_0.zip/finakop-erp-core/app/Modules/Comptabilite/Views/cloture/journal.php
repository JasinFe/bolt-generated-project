<?php
/**
 * JOURNAL DE CLÔTURE.
 *
 * C'est la pièce qu'un contrôle fiscal ou un commissaire aux comptes demande
 * en premier : non pas l'état final des comptes, mais la SUITE DES GESTES qui
 * y a mené. Les réouvertures sont mises en tête, parce que ce sont elles que
 * l'on cherche — et parce qu'un exercice jamais rouvert se démontre par une
 * liste vide.
 *
 * @var int $annee @var array $annees @var array $lignes @var array $operations @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$coulIssue = array( 'ok' => '#3ddc84', 'avertissement' => '#ffb020', 'refus' => '#ff6b6b', 'derogation' => '#6aa9ff' );
$reouv = array_values( array_filter( $lignes, function ( $l ) { return 'reouverture' === (string) $l['operation']; } ) );
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Journal de clôture ' . (int) $annee, 'route' => 'comptabilite/cloture/journal', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Assistant', 'comptabilite/cloture?annee=' . (int) $annee ) ) ) ); ?>
<div class="card-body">
	<p class="muted" style="margin:0;font-size:12.5px">
		Ce journal est en <strong>ajout seul</strong> : on y ajoute, on n'y retire jamais. Une opération
		annulée produit une seconde ligne qui dit l'annulation, pas la disparition de la première —
		un journal que l'on peut nettoyer ne prouve rien.
	</p>
	<p style="margin:8px 0 0">
		<?php if ( ! $reouv ) : ?>
			<strong style="color:#3ddc84">Aucune réouverture</strong> sur cet exercice.
		<?php else : ?>
			<strong style="color:#ffb020"><?= count( $reouv ) ?> réouverture(s)</strong> sur cet exercice —
			chacune porte son motif ci-dessous.
		<?php endif; ?>
	</p>
</div></div>

<div class="card card-flush" style="margin-top:12px">
	<table class="table">
		<thead><tr><th style="width:130px">Date</th><th style="width:150px">Opération</th><th>Détail</th><th style="width:140px">Par</th></tr></thead>
		<tbody>
		<?php if ( ! $lignes ) : ?>
			<tr><td colspan="4" class="muted" style="text-align:center;padding:22px">
				Aucune opération consignée pour cet exercice. Le journal se remplit au premier geste de clôture.
			</td></tr>
		<?php else : foreach ( $lignes as $l ) :
			$col = $coulIssue[ (string) $l['issue'] ] ?? '#8a93a6'; ?>
			<tr>
				<td class="muted" style="font-size:12px"><?= e( date( 'd/m/Y H:i', strtotime( (string) $l['date_op'] ) ) ) ?></td>
				<td><span style="color:<?= $col ?>;font-size:12px;font-weight:600">
					<?= e( $operations[ (string) $l['operation'] ] ?? (string) $l['operation'] ) ?></span></td>
				<td>
					<div style="font-size:13px"><?= e( (string) $l['libelle'] ) ?></div>
					<?php if ( '' !== (string) $l['motif'] ) : ?>
						<div style="font-size:12px;color:#ffb020;margin-top:3px">Motif : <?= e( (string) $l['motif'] ) ?></div>
					<?php endif; ?>
					<?php if ( ! empty( $l['reference'] ) || ! empty( $l['ecriture_id'] ) || null !== $l['montant'] ) : ?>
						<div class="muted" style="font-size:11.5px;margin-top:3px">
							<?= ! empty( $l['reference'] ) ? 'Réf. ' . e( (string) $l['reference'] ) . ' · ' : '' ?>
							<?= ! empty( $l['ecriture_id'] ) ? 'Écriture #' . (int) $l['ecriture_id'] . ' · ' : '' ?>
							<?= null !== $l['montant'] ? e( fkc_money( $l['montant'] ) ) . ' F CFA' : '' ?>
						</div>
					<?php endif; ?>
				</td>
				<td class="muted" style="font-size:12px">
					<?= e( '' !== (string) $l['acteur_nom'] ? (string) $l['acteur_nom'] : 'système' ) ?>
					<?php if ( ! empty( $l['ip'] ) ) : ?><br><span style="font-size:11px"><?= e( (string) $l['ip'] ) ?></span><?php endif; ?>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
