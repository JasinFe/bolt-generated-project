<?php
/**
 * AFFECTATION DU RÉSULTAT.
 *
 * L'écran tient en une idée : un montant à répartir, un reste à zéro. Le
 * total restant est calculé au fil de la saisie, parce que c'est la seule
 * chose que l'utilisateur surveille — et parce que découvrir au moment de
 * valider qu'il manque 1 200 F oblige à tout recompter.
 *
 * @var int $annee @var array $annees @var array $aff @var bool $admin @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$deja  = $aff['deja'];
$sens  = (string) $aff['sens'];
$mt    = (float) $aff['montant'];
$rl    = $aff['reserve_legale'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.aff-grid{display:grid;grid-template-columns:2fr 1fr 2fr auto;gap:8px;align-items:end;margin-bottom:8px}
.aff-tot{display:flex;gap:18px;flex-wrap:wrap;align-items:baseline;padding:10px 0;border-top:1px solid rgba(255,255,255,.08)}
.aff-tot b{font-size:17px}
@media(max-width:720px){.aff-grid{grid-template-columns:1fr 1fr;}.aff-grid .aff-lib{grid-column:1/-1}}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Affectation du résultat ' . (int) $annee, 'route' => 'comptabilite/cloture/affectation', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Assistant', 'comptabilite/cloture?annee=' . (int) $annee ) ) ) ); ?>
<div class="card-body">
	<p class="muted" style="margin-top:0;font-size:12.5px">
		Déterminer le résultat et l'affecter sont <strong>deux gestes distincts</strong>. Le premier est un calcul,
		fait à la clôture ; le second est une <strong>décision d'assemblée générale</strong>, prise après elle —
		dans les six mois, en droit OHADA — et constatée au vu du procès-verbal. C'est pourquoi la référence du
		PV est exigée : elle est la pièce justificative de l'écriture.
	</p>

	<?php if ( ! $aff['clos'] ) : ?>
		<div class="alert alert-err" style="margin-bottom:0">
			L'exercice <?= (int) $annee ?> n'est pas clôturé : son résultat peut encore changer.
			Affecter maintenant reviendrait à répartir un montant qui n'est pas arrêté.
			<a href="<?= e( url( 'comptabilite/cloture?annee=' . (int) $annee ) ) ?>">Clôturer d'abord</a>.
		</div>
	<?php elseif ( abs( (float) $aff['resultat'] ) < 0.005 ) : ?>
		<div class="alert alert-ok" style="margin-bottom:0">
			Le résultat de l'exercice <?= (int) $annee ?> est nul : il n'y a rien à affecter.
		</div>
	<?php else : ?>
		<p style="margin:0">
			Résultat net <?= 'benefice' === $sens ? '<strong style="color:#3ddc84">bénéficiaire</strong>' : '<strong style="color:#ff6b6b">déficitaire</strong>' ?> :
			<strong style="font-size:18px"><?= e( fkc_money( $mt ) ) ?> F CFA</strong>,
			porté au compte <?= e( (string) $aff['compte_source'] ) ?>.
		</p>
	<?php endif; ?>
</div></div>

<?php if ( $deja ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Décision enregistrée</h2></div><div class="card-body">
	<p style="margin-top:0">
		Procès-verbal <strong><?= e( (string) $deja['reference_pv'] ) ?></strong>,
		décision du <?= e( date( 'd/m/Y', strtotime( (string) $deja['date_decision'] ) ) ) ?>,
		enregistrée par <?= e( (string) $deja['cree_nom'] ) ?>
		le <?= e( date( 'd/m/Y', strtotime( (string) $deja['cree_le'] ) ) ) ?>.
	</p>
	<table class="table">
		<thead><tr><th>Compte</th><th>Destination</th><th class="right">Montant</th></tr></thead>
		<tbody>
		<?php $t = 0.0; foreach ( (array) $deja['lignes'] as $l ) : $t += (float) $l['montant']; ?>
			<tr>
				<td class="mono"><?= e( (string) $l['compte_numero'] ) ?></td>
				<td><?= e( (string) $l['libelle'] ) ?></td>
				<td class="right mono"><?= e( fkc_money( $l['montant'] ) ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr><th colspan="2">Total réparti</th><th class="right mono"><?= e( fkc_money( $t ) ) ?> F CFA</th></tr></tfoot>
	</table>
	<?php if ( ! empty( $deja['note'] ) ) : ?><p class="muted" style="font-size:12.5px">Note : <?= e( (string) $deja['note'] ) ?></p><?php endif; ?>

	<?php if ( $admin ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/affectation/annuler' ) ) ?>"
			style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:10px"
			onsubmit="return confirm('Annuler l\'affectation ? L\'écriture sera contre-passée et le résultat reviendra en instance.')">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<input type="text" name="motif" required minlength="15" style="flex:1 1 320px"
				placeholder="Motif de l'annulation (obligatoire, ≥ 15 caractères)">
			<button class="btn btn-ghost btn-sm" type="submit">Annuler l'affectation</button>
		</form>
	<?php endif; ?>
</div></div>

<?php elseif ( $aff['clos'] && abs( (float) $aff['resultat'] ) >= 0.005 ) : ?>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Répartition</h2></div><div class="card-body">

	<?php if ( 'benefice' === $sens && ! empty( $rl['applicable'] ) ) : ?>
		<p class="muted" style="margin-top:0;font-size:12.5px">
			<strong>Réserve légale.</strong> Capital <?= e( fkc_money( $rl['capital'] ) ) ?> F CFA,
			réserve constituée <?= e( fkc_money( $rl['reserve'] ) ) ?> F CFA, plafond légal (20 % du capital)
			<?= e( fkc_money( $rl['plafond'] ) ) ?> F CFA.
			<?php if ( $rl['suggestion'] > 0 ) : ?>
				Dotation suggérée : <strong><?= e( fkc_money( $rl['suggestion'] ) ) ?> F CFA</strong>
				(10 % du bénéfice, dans la limite de ce qui reste à doter).
			<?php else : ?>
				Le plafond est atteint : aucune dotation n'est requise.
			<?php endif; ?>
			Cette dotation est une <em>suggestion</em> : l'obligation dépend de la forme sociale, que FinaKop ne
			connaît pas toujours.
		</p>
	<?php endif; ?>

	<form method="post" action="<?= e( url( 'comptabilite/cloture/affectation' ) ) ?>" id="affForm">
		<?= FKC_Csrf::field() ?>
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">

		<div class="form-grid" style="grid-template-columns:1fr 1fr 2fr;margin-bottom:12px">
			<label class="fld"><span>Date de la décision</span>
				<input type="date" name="date_decision" value="<?= e( (string) $aff['date_defaut'] ) ?>" required></label>
			<label class="fld"><span>Référence du procès-verbal</span>
				<input type="text" name="reference_pv" required placeholder="AGO-2026-01" maxlength="120"></label>
			<label class="fld"><span>Note (facultatif)</span>
				<input type="text" name="note" placeholder="Précisions sur la décision"></label>
		</div>

		<div id="affLignes">
		<?php for ( $i = 0; $i < 6; $i++ ) : ?>
			<div class="aff-grid">
				<label class="fld"><span<?= $i ? ' style="visibility:hidden"' : '' ?>>Destination</span>
					<select name="compte[]" class="aff-cpt">
						<option value="">—</option>
						<?php foreach ( $aff['destinations'] as $num => $d ) : ?>
							<option value="<?= e( (string) $num ) ?>" title="<?= e( (string) $d['note'] ) ?>">
								<?= e( (string) $num ) ?> · <?= e( (string) $d['label'] ) ?>
							</option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="fld"><span<?= $i ? ' style="visibility:hidden"' : '' ?>>Montant</span>
					<input type="number" step="0.01" min="0" name="montant[]" class="aff-mt"
						value="<?= ( 0 === $i && 'benefice' === $sens && ! empty( $rl['suggestion'] ) ) ? e( (string) $rl['suggestion'] ) : '' ?>"></label>
				<label class="fld aff-lib"><span<?= $i ? ' style="visibility:hidden"' : '' ?>>Libellé (facultatif)</span>
					<input type="text" name="libelle[]" maxlength="200"></label>
				<span></span>
			</div>
		<?php endfor; ?>
		</div>

		<div class="aff-tot">
			<span>À affecter <b><?= e( fkc_money( $mt ) ) ?></b> F CFA</span>
			<span>Réparti <b id="affReparti">0</b> F CFA</span>
			<span>Reste <b id="affReste" style="color:#ffb020"><?= e( fkc_money( $mt ) ) ?></b> F CFA</span>
		</div>

		<p class="muted" style="font-size:12.5px">
			La répartition doit boucler <strong>au franc près</strong>. FinaKop n'ajuste pas de lui-même :
			un reliquat non attribué est un montant dont personne n'a décidé du sort, et le loger
			automatiquement en report à nouveau — ce que faisait l'ancienne génération d'à-nouveaux —
			revient à affecter à la place de l'assemblée.
		</p>

		<div class="actions"><button class="btn btn-primary" type="submit">Enregistrer l'affectation</button></div>
	</form>
</div></div>

<script>
(function () {
	var cible = <?= json_encode( round( $mt, 2 ) ) ?>;
	function fmt(n){ return n.toLocaleString('fr-FR', {minimumFractionDigits:0, maximumFractionDigits:2}); }
	function calc() {
		var t = 0;
		document.querySelectorAll('#affLignes .aff-mt').forEach(function(i){ t += parseFloat(i.value || 0) || 0; });
		var reste = Math.round((cible - t) * 100) / 100;
		document.getElementById('affReparti').textContent = fmt(t);
		var r = document.getElementById('affReste');
		r.textContent = fmt(reste);
		r.style.color = Math.abs(reste) < 0.005 ? '#3ddc84' : (reste < 0 ? '#ff6b6b' : '#ffb020');
	}
	document.getElementById('affLignes').addEventListener('input', calc);
	calc();
})();
</script>
<?php endif; ?>
