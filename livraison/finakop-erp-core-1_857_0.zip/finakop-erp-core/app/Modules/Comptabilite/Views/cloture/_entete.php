<?php
/**
 * EN-TÊTE COMMUN DES ÉCRANS « ARRÊTÉ DES COMPTES » (1.791.0).
 *
 * Titre, sélecteur d'exercice et raccourcis sur UNE SEULE LIGNE. Chaque écran
 * posait jusqu'ici son propre en-tête en `flex-wrap:wrap` : dès que les
 * raccourcis dépassaient la largeur, le formulaire passait sous le titre et
 * ses boutons se chevauchaient ou sortaient du cadre. Désormais :
 *   — le titre prend la place disponible et s'abrège (…) plutôt que de pousser
 *     les boutons à la ligne ; son texte complet reste en info-bulle ;
 *   — les raccourcis restent alignés à droite, sans retour à la ligne ; si la
 *     fenêtre est trop étroite, la barre défile horizontalement : tout reste
 *     atteignable, rien ne se superpose ;
 *   — sous 640 px (téléphone), la barre passe sous le titre, sur sa propre ligne.
 *
 * @var string $titre    Titre de l'écran.
 * @var string $route    Action du formulaire (changement d'exercice), '' sans sélecteur.
 * @var int    $annee    Exercice affiché.
 * @var array  $annees   Exercices proposés.
 * @var string $param    Nom du paramètre GET (défaut « annee »).
 * @var string $prefixe  Préfixe des options (« Ouvrir »…).
 * @var array  $caches   Champs cachés à reporter (nom => valeur).
 * @var array  $liens    Raccourcis : array( libellé, url [, 'blank' => bool, 'title' => '' ] ).
 * @var string $info     Texte court aligné à droite (compteurs), à la place du formulaire.
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$route   = (string) ( $route ?? '' );
$param   = (string) ( $param ?? 'annee' );
$prefixe = (string) ( $prefixe ?? '' );
$caches  = (array) ( $caches ?? array() );
$liens   = (array) ( $liens ?? array() );
$annees  = (array) ( $annees ?? array() );
$info    = (string) ( $info ?? '' );
if ( empty( $GLOBALS['__fkc_clot_entete_css'] ) ) :
	$GLOBALS['__fkc_clot_entete_css'] = true; ?>
<style>
.card-head.clot-entete{flex-wrap:nowrap;gap:12px;align-items:center}
.clot-entete .clot-titre{margin:0;flex:1 1 auto;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.clot-entete .clot-outils{display:flex;flex:0 1 auto;align-items:center;gap:6px;margin:0;flex-wrap:nowrap;
	overflow-x:auto;max-width:72%;scrollbar-width:thin;padding:2px 0}
.clot-entete .clot-outils > *{flex:0 0 auto;white-space:nowrap}
.clot-entete .clot-outils select{max-width:150px}
.clot-entete .clot-info{flex:0 1 auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12.5px}
@media (max-width:640px){
	.card-head.clot-entete{flex-wrap:wrap}
	.clot-entete .clot-titre{flex-basis:100%}
	.clot-entete .clot-outils{max-width:100%}
}
</style>
<?php endif; ?>
<div class="card-head clot-entete">
	<h2 class="clot-titre" title="<?= e( $titre ) ?>"><?= e( $titre ) ?></h2>
	<?php if ( '' !== $info ) : ?>
		<span class="muted clot-info" title="<?= e( strip_tags( $info ) ) ?>"><?= $info ?></span>
	<?php endif; ?>
	<?php if ( '' !== $route || $liens ) : ?>
	<form class="clot-outils" method="get" action="<?= e( url( '' !== $route ? $route : 'comptabilite/cloture' ) ) ?>">
		<?php if ( '' !== $route && $annees ) : ?>
			<select name="<?= e( $param ) ?>" onchange="this.form.submit()" aria-label="Exercice">
				<?php foreach ( $annees as $a ) : ?>
					<option value="<?= (int) $a ?>" <?= (int) $a === (int) $annee ? 'selected' : '' ?>><?= e( trim( $prefixe . ' ' . (int) $a ) ) ?></option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>
		<?php foreach ( $caches as $n => $v ) : ?><input type="hidden" name="<?= e( (string) $n ) ?>" value="<?= e( (string) $v ) ?>"><?php endforeach; ?>
		<?php foreach ( $liens as $l ) : ?>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $l[1] ) ) ?>"<?= ! empty( $l['blank'] ) ? ' target="_blank" rel="noopener"' : '' ?><?= ! empty( $l['title'] ) ? ' title="' . e( $l['title'] ) . '"' : '' ?>><?= e( (string) $l[0] ) ?></a>
		<?php endforeach; ?>
	</form>
	<?php endif; ?>
</div>
