<?php
/**
 * RATTACHEMENT DES CHARGES ET DES PRODUITS.
 *
 * Trois blocs : ce que le dossier suggère (et que personne ne regarde), la
 * saisie assistée avec son calculateur de prorata, puis l'état des
 * rattachements et de leurs extournes.
 *
 * Le calculateur de prorata est en haut de la saisie et non en annexe : c'est
 * lui le travail. « Assurance annuelle payée le 1er octobre, 1 200 000 F —
 * combien relève de l'exercice clos au 31 décembre ? » se calcule de tête à la
 * va-vite, et se trompe une fois sur trois.
 *
 * @var int $annee @var array $annees @var array $natures @var array $lignes
 * @var array $totaux @var array $suggestions @var array $a_extourner
 * @var array|null $cloture @var string $fin @var string $debut_suivant
 * @var bool $admin @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$statuts = array(
	'saisie'    => array( 'À comptabiliser', '#ffb020' ),
	'passee'    => array( 'Comptabilisée',   '#3ddc84' ),
	'extournee' => array( 'Extournée',       '#6aa9ff' ),
	'annulee'   => array( 'Annulée',         '#8a93a6' ),
);
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.rg-nat{display:flex;gap:8px;overflow-x:auto;padding:2px 0 10px}
.rg-nat label{flex:1 0 165px;min-width:165px;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:9px 11px;cursor:pointer;background:rgba(255,255,255,.02)}
.rg-nat input{display:none}
.rg-nat b{display:block;font-size:13px}
.rg-nat span{font-size:11.5px;color:#9aa3b5;line-height:1.35;display:block;margin-top:3px}
.rg-nat input:checked + b{color:#3ddc84}
.rg-sel{border-color:#3ddc84 !important;background:rgba(61,220,132,.06) !important}
.rg-pro{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;align-items:end}
.rg-out{font-size:12.5px;color:#9aa3b5;line-height:1.5;margin:6px 0 0}
.rg-sug{display:flex;gap:12px;align-items:flex-start;padding:10px 0;border-top:1px solid rgba(255,255,255,.07)}
@media(max-width:760px){.rg-pro{grid-template-columns:1fr 1fr}}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Rattachement des charges et des produits — ' . (int) $annee, 'route' => 'comptabilite/regularisations', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Assistant de clôture', 'comptabilite/cloture?annee=' . (int) $annee ) ) ) ); ?>
<div class="card-body">
	<p class="muted" style="margin-top:0;font-size:12.5px">
		Un exercice ne porte pas ce qui a été <em>facturé</em> : il porte ce qui a été <strong>consommé</strong> et ce
		qui a été <strong>gagné</strong>. Ces écritures, datées du <?= e( date( 'd/m/Y', strtotime( $fin ) ) ) ?>,
		corrigent les décalages de date — et sont <strong>extournées automatiquement</strong> au
		<?= e( date( 'd/m/Y', strtotime( $debut_suivant ) ) ) ?>, à l'ouverture de l'exercice suivant.
		Sans cette extourne, la charge serait comptée deux fois : une fois par le rattachement, une fois par la
		facture réelle.
	</p>
	<?php if ( $cloture ) : ?>
		<div class="alert alert-err" style="margin-bottom:0">
			L'exercice <?= (int) $annee ?> est clôturé : aucun rattachement ne peut plus y être ajouté.
			Le résultat est arrêté — c'est le sens du verrou.
		</div>
	<?php endif; ?>
</div></div>

<?php /* ── Suggestions ─────────────────────────────────────────────────── */ ?>
<?php if ( $suggestions ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Ce que le dossier sait déjà</h2></div><div class="card-body">
	<p class="muted" style="margin-top:0;font-size:12.5px">
		Chaque suggestion est un <strong>écart</strong>, jamais un total : on confronte ce que le registre des
		réceptions ou la chaîne documentaire porte, au solde réel des comptes 408 et 418. Si votre pack métier
		comptabilise déjà ses réceptions, l'écart vaut zéro et rien n'est proposé — c'est voulu, et c'est ce qui
		rend la suggestion digne de confiance.
	</p>
	<?php foreach ( $suggestions as $s ) : ?>
		<div class="rg-sug">
			<span style="flex:0 0 10px;height:10px;border-radius:99px;margin-top:5px;background:<?= ! empty( $s['a_faire'] ) ? '#ffb020' : '#3ddc84' ?>"></span>
			<div style="flex:1">
				<strong style="font-size:13.5px"><?= e( $s['nature'] ) ?> · <?= e( $s['libelle'] ) ?></strong>
				<span class="muted" style="font-size:12px"> — <?= e( $s['source'] ) ?></span>
				<div style="font-size:12px;color:#9aa3b5;line-height:1.45;margin-top:3px"><?= e( $s['note'] ) ?></div>
			</div>
			<?php if ( ! empty( $s['a_faire'] ) && ! $cloture ) : ?>
				<button type="button" class="btn btn-ghost btn-sm"
					onclick="rgPrefill('<?= e( $s['nature'] ) ?>', <?= json_encode( (float) $s['montant'] ) ?>, <?= json_encode( (string) $s['libelle'] ) ?>, '<?= e( (string) $s['compte_bilan'] ) ?>')">
					Préparer <?= e( fkc_money( $s['montant'] ) ) ?> F
				</button>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div></div>
<?php endif; ?>

<?php /* ── Saisie ──────────────────────────────────────────────────────── */ ?>
<?php if ( ! $cloture ) : ?>
<div class="card" style="margin-top:12px" id="rgForm"><div class="card-head"><h2>Nouveau rattachement</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'comptabilite/regularisations/creer' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">

		<div class="rg-nat">
		<?php $i = 0; foreach ( $natures as $code => $n ) : $i++; ?>
			<label id="rgnat-<?= e( $code ) ?>" class="rg-natlbl<?= 1 === $i ? ' rg-sel' : '' ?>"
				onclick="rgNature('<?= e( $code ) ?>')">
				<input type="radio" name="nature" value="<?= e( $code ) ?>" <?= 1 === $i ? 'checked' : '' ?>>
				<b><?= e( $code ) ?> · <?= e( $n['label'] ) ?></b>
				<span><?= e( $n['objet'] ) ?></span>
			</label>
		<?php endforeach; ?>
		</div>
		<p class="rg-out" id="rgExemple"></p>
		<p class="rg-out" id="rgTvaNote" style="color:#ffb020"></p>

		<div class="form-grid" style="grid-template-columns:2fr 1fr 1fr 1fr;margin-top:10px">
			<label class="fld"><span>Libellé — ce que l'écriture rattache</span>
				<input type="text" name="libelle" id="rgLibelle" required minlength="3" maxlength="300"
					placeholder="Électricité de décembre, facture non reçue"></label>
			<label class="fld"><span>Tiers (facultatif)</span>
				<input type="text" name="tiers" maxlength="200" placeholder="CIE"></label>
			<label class="fld"><span>Compte <span id="rgClasse">6xx</span></span>
				<input type="text" name="compte_gestion" id="rgCptGestion" required placeholder="605000"></label>
			<label class="fld"><span>Compte de bilan</span>
				<input type="text" name="compte_bilan" id="rgCptBilan" required></label>
		</div>

		<fieldset style="border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px;margin:12px 0">
			<legend style="font-size:12px;color:#9aa3b5;padding:0 6px">Calculateur — prorata temporis</legend>
			<div class="rg-pro">
				<label class="fld"><span>Montant total de la période</span>
					<input type="number" step="0.01" min="0" id="rgBase" name="base_prorata" placeholder="1200000"></label>
				<label class="fld"><span>Période couverte — du</span>
					<input type="date" id="rgDeb" name="periode_debut"></label>
				<label class="fld"><span>au</span>
					<input type="date" id="rgFin" name="periode_fin"></label>
				<button type="button" class="btn btn-ghost btn-sm" onclick="rgProrata()">Calculer</button>
			</div>
			<p class="rg-out" id="rgProOut">
				Facultatif. Renseignez la période couverte par la facture : le calculateur répartit le montant au
				jour près, bornes incluses, et reporte la part qui revient au rattachement dans le montant ci-dessous.
			</p>
		</fieldset>

		<div class="form-grid" style="grid-template-columns:1fr 1fr 2fr">
			<label class="fld"><span>Montant hors taxes à rattacher</span>
				<input type="number" step="0.01" min="0" name="montant_ht" id="rgHt" required></label>
			<label class="fld"><span>TVA <span id="rgTvaCpt" class="muted"></span></span>
				<input type="number" step="0.01" min="0" name="montant_tva" id="rgTva" value="0"></label>
			<label class="fld"><span>Justificatif (référence de la pièce)</span>
				<input type="text" name="justificatif" maxlength="200" placeholder="Relevé CIE n° …, contrat, bon de livraison"></label>
		</div>

		<div class="actions" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
			<button class="btn btn-primary" type="submit" name="passer" value="1">Enregistrer et comptabiliser</button>
			<button class="btn btn-ghost" type="submit">Enregistrer seulement</button>
			<span class="muted" style="font-size:12px">L'écriture sera datée du <?= e( date( 'd/m/Y', strtotime( $fin ) ) ) ?>.</span>
		</div>
	</form>
</div></div>
<?php endif; ?>

<?php /* ── État ────────────────────────────────────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
	<h2 style="margin:0">Rattachements de l'exercice</h2>
	<span class="muted" style="font-size:12.5px">
		<?= (int) $totaux['saisies'] ?> à comptabiliser · <?= (int) $totaux['passees'] ?> comptabilisé(s) ·
		<?= (int) $totaux['extournees'] ?> extourné(s) ·
		charges <?= e( fkc_money( $totaux['total_charges'] ) ) ?> F · produits <?= e( fkc_money( $totaux['total_produits'] ) ) ?> F
	</span>
</div>

<?php if ( (int) $totaux['saisies'] > 0 && ! $cloture ) : ?>
<div class="card-body" style="padding-bottom:0">
	<form method="post" action="<?= e( url( 'comptabilite/regularisations/passer-tout' ) ) ?>" style="margin:0">
		<?= FKC_Csrf::field() ?>
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">
		<button class="btn btn-primary btn-sm" type="submit">Comptabiliser les <?= (int) $totaux['saisies'] ?> rattachement(s) en attente</button>
	</form>
</div>
<?php endif; ?>

	<table class="table">
		<thead><tr><th style="width:56px">Nature</th><th>Libellé</th><th>Tiers</th><th>Comptes</th>
			<th class="right">HT</th><th class="right">TVA</th><th>État</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $lignes ) : ?>
			<tr><td colspan="8" class="muted" style="text-align:center;padding:22px">
				Aucun rattachement sur cet exercice. Sur un dossier actif, c'est rare : une facture d'électricité,
				une assurance payée d'avance ou des congés acquis suffisent à en justifier un.
			</td></tr>
		<?php else : foreach ( $lignes as $l ) :
			list( $stLbl, $stCol ) = $statuts[ (string) $l['statut'] ] ?? array( $l['statut'], '#8a93a6' ); ?>
			<tr>
				<td><strong><?= e( (string) $l['nature'] ) ?></strong></td>
				<td>
					<?= e( (string) $l['libelle'] ) ?>
					<?php if ( ! empty( $l['periode_debut'] ) ) : ?>
						<div class="muted" style="font-size:11.5px">
							Période <?= e( date( 'd/m/Y', strtotime( (string) $l['periode_debut'] ) ) ) ?>
							→ <?= e( date( 'd/m/Y', strtotime( (string) $l['periode_fin'] ) ) ) ?>
							<?= $l['base_prorata'] ? ' sur ' . e( fkc_money( $l['base_prorata'] ) ) . ' F' : '' ?>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $l['justificatif'] ) ) : ?>
						<div class="muted" style="font-size:11.5px">Pièce : <?= e( (string) $l['justificatif'] ) ?></div>
					<?php endif; ?>
				</td>
				<td class="muted"><?= e( (string) $l['tiers'] ) ?: '—' ?></td>
				<td class="mono" style="font-size:12px"><?= e( (string) $l['compte_gestion'] ) ?> / <?= e( (string) $l['compte_bilan'] ) ?></td>
				<td class="right mono"><?= e( fkc_money( $l['montant_ht'] ) ) ?></td>
				<td class="right mono"><?= (float) $l['montant_tva'] > 0 ? e( fkc_money( $l['montant_tva'] ) ) : '—' ?></td>
				<td><span style="color:<?= $stCol ?>;font-size:12px;font-weight:600"><?= e( $stLbl ) ?></span>
					<?php if ( ! empty( $l['ecriture_id'] ) ) : ?><div class="muted" style="font-size:11px">#<?= (int) $l['ecriture_id'] ?><?= ! empty( $l['ecriture_extourne_id'] ) ? ' → #' . (int) $l['ecriture_extourne_id'] : '' ?></div><?php endif; ?>
				</td>
				<td class="right">
					<?php if ( 'saisie' === (string) $l['statut'] && ! $cloture ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/regularisations/' . (int) $l['id'] . '/passer' ) ) ?>" style="margin:0 0 4px">
							<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Comptabiliser</button>
						</form>
					<?php endif; ?>
					<?php if ( in_array( (string) $l['statut'], array( 'saisie', 'passee' ), true ) && ! $cloture ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/regularisations/' . (int) $l['id'] . '/annuler' ) ) ?>"
							style="display:flex;gap:4px;justify-content:flex-end;margin:0"
							onsubmit="return confirm('Annuler ce rattachement ?')">
							<?= FKC_Csrf::field() ?>
							<?php if ( 'passee' === (string) $l['statut'] ) : ?>
								<input type="text" name="motif" required minlength="10" style="max-width:150px" placeholder="Motif">
							<?php endif; ?>
							<button class="btn btn-ghost btn-sm" type="submit">Annuler</button>
						</form>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>

<?php /* ── Extournes en attente ────────────────────────────────────────── */ ?>
<?php if ( $a_extourner ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Extournes en attente</h2></div><div class="card-body">
	<p style="margin-top:0;color:#ffb020">
		<strong><?= count( $a_extourner ) ?> rattachement(s)</strong> de <?= (int) $annee ?> n'ont pas été contre-passés
		à l'ouverture de <?= (int) $annee + 1 ?>. Tant qu'ils ne le sont pas, leurs charges et leurs produits seront
		comptés <strong>deux fois</strong> sur <?= (int) $annee + 1 ?> — une fois par le rattachement, une fois par la
		facture réelle. Le résultat de l'exercice suivant est faux du montant entier, et le bilan reste équilibré.
	</p>
	<form method="post" action="<?= e( url( 'comptabilite/regularisations/extourner' ) ) ?>" style="margin:0">
		<?= FKC_Csrf::field() ?>
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">
		<button class="btn btn-primary btn-sm" type="submit">
			Extourner au <?= e( date( 'd/m/Y', strtotime( $debut_suivant ) ) ) ?>
		</button>
	</form>
</div></div>
<?php endif; ?>

<script>
var RG_NAT = <?= json_encode( $natures, JSON_UNESCAPED_UNICODE ) ?>;
var RG_CLOTURE = <?= json_encode( (string) $fin ) ?>;

function rgNature(code) {
	document.querySelectorAll('.rg-natlbl').forEach(function (l) { l.classList.remove('rg-sel'); });
	var el = document.getElementById('rgnat-' + code);
	if (el) { el.classList.add('rg-sel'); el.querySelector('input').checked = true; }
	var n = RG_NAT[code]; if (!n) { return; }
	document.getElementById('rgExemple').textContent = 'Exemples — ' + n.exemple;
	document.getElementById('rgClasse').textContent = (n.classe_gestion === 6 ? '6xx (charge)' : '7xx (produit)');
	document.getElementById('rgCptBilan').value = n.bilan_defaut;
	var tva = document.getElementById('rgTva');
	var sansTva = !n.tva_compte;
	tva.disabled = sansTva;
	if (sansTva) { tva.value = 0; }
	document.getElementById('rgTvaCpt').textContent = n.tva_compte ? '(' + n.tva_compte + ')' : '(sans objet)';
	document.getElementById('rgTvaNote').textContent = n.tva_note || '';
}

function rgPrefill(nature, montant, libelle, bilan) {
	rgNature(nature);
	document.getElementById('rgLibelle').value = libelle;
	document.getElementById('rgHt').value = montant;
	if (bilan) { document.getElementById('rgCptBilan').value = bilan; }
	document.getElementById('rgForm').scrollIntoView({ behavior: 'smooth' });
}

/*
 * Le prorata est calculé ici pour être IMMÉDIAT — on le refait deux ou trois
 * fois en ajustant les dates. Le serveur recalcule et conserve la période :
 * un contrôle fiscal demande le calcul, pas seulement le montant.
 */
function rgProrata() {
	var base = parseFloat(document.getElementById('rgBase').value || 0) || 0;
	var d = document.getElementById('rgDeb').value, f = document.getElementById('rgFin').value;
	var out = document.getElementById('rgProOut');
	if (!base || !d || !f) { out.textContent = 'Renseignez le montant total, le début et la fin de la période couverte.'; return; }
	var td = Date.parse(d), tf = Date.parse(f), tc = Date.parse(RG_CLOTURE);
	if (isNaN(td) || isNaN(tf) || tf < td) { out.textContent = 'Période incohérente.'; return; }
	var J = 86400000;
	var total = Math.round((tf - td) / J) + 1;
	var dansEx = tc < td ? 0 : (tc >= tf ? total : Math.round((tc - td) / J) + 1);
	var reporte = total - dansEx;
	var partEx = Math.round(base * dansEx / total * 100) / 100;
	var partRep = Math.round((base - partEx) * 100) / 100;
	var nat = document.querySelector('input[name=nature]:checked');
	var code = nat ? nat.value : 'CCA';
	// CCA et PCA rattachent la part REPORTÉE ; les autres natures rattachent
	// la part de l'exercice. Reporter le mauvais montant est l'erreur que ce
	// calculateur existe pour empêcher — on remplit donc le bon champ.
	var aRattacher = (code === 'CCA' || code === 'PCA') ? partRep : partEx;
	document.getElementById('rgHt').value = aRattacher;
	out.innerHTML = total + ' jour(s) couverts · <strong>' + dansEx + '</strong> dans l\'exercice ('
		+ partEx.toLocaleString('fr-FR') + ' F) · <strong>' + reporte + '</strong> reportés ('
		+ partRep.toLocaleString('fr-FR') + ' F). Montant repris ci-dessous : <strong>'
		+ aRattacher.toLocaleString('fr-FR') + ' F</strong> ('
		+ ((code === 'CCA' || code === 'PCA') ? 'la part qui relève de l\'exercice suivant' : 'la part qui relève de cet exercice') + ').';
}

var rgPremier = document.querySelector('input[name=nature]');
if (rgPremier) { rgNature(rgPremier.value); }
</script>
