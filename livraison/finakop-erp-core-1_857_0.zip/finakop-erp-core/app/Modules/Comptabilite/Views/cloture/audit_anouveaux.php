<?php
/**
 * AUDIT DES À-NOUVEAUX (1.798.0).
 *
 * Disposition horizontale : une bande de statut par exercice, puis, pour
 * l'exercice choisi, quatre cartes côte à côte (statut, sources, référence,
 * rapprochements) qui se replient en colonne sur téléphone ; enfin le détail
 * ligne à ligne, qui défile dans son propre cadre.
 *
 * @var int $annee @var array $annees @var array $diag @var array $synthese
 * @var bool $admin @var mixed $flash @var string $tab
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$statuts = array(
	'officiel'     => array( 'À-nouveaux officiel', 'b-on', '#2e9e5b' ),
	'anomalie'     => array( 'À-nouveaux avec anomalie', 'b-err', '#d9822b' ),
	'ambigu'       => array( 'Ouverture ambiguë — non fiable', 'b-err', '#d64545' ),
	'calcule'      => array( 'Solde d\'ouverture calculé', 'b-err', '#d9822b' ),
	'initial'      => array( 'Premier exercice', '', '#8a8f98' ),
	'autre_source' => array( 'Ouverture par une autre source', '', '#3d7fd9' ),
);
$st = $statuts[ $diag['statut'] ] ?? array( $diag['statut'], '', '#8a8f98' );
$niv = array( 'critique' => '#d64545', 'haute' => '#d9822b', 'moyenne' => '#c9a227' );
$rap = $diag['rapprochement']; $eff = $diag['effectif']; $ptr = $diag['pointeur']; $tr = $diag['trace'];
$lignes = (array) $diag['lignes'];
$dec = (array) $diag['decomposition'];
$dcs = function ( $v ) { return null === $v ? '—' : fkc_money( abs( (float) $v ) ) . ( abs( (float) $v ) < 0.005 ? '' : ( $v < 0 ? ' C' : ' D' ) ); };
$td = 0.0; $tc = 0.0; foreach ( $lignes as $l ) { $td += $l['debit']; $tc += $l['credit']; }
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.aan-bande{display:flex;gap:8px;overflow-x:auto;padding:2px 0 10px;scrollbar-width:thin}
.aan-ex{flex:0 0 auto;min-width:132px;padding:9px 12px;border:1px solid var(--line);border-radius:10px;text-decoration:none;color:inherit;display:flex;flex-direction:column;gap:3px}
.aan-ex.on{border-color:var(--orange);box-shadow:0 0 0 1px var(--orange) inset}
.aan-ex b{font-size:16px}
.aan-grille{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:14px}
@media (max-width:1100px){.aan-grille{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:640px){.aan-grille{grid-template-columns:1fr}}
.aan-carte{border:1px solid var(--line);border-radius:12px;padding:12px 14px;min-width:0}
.aan-carte h3{margin:0 0 8px;font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}
.aan-gros{font-size:18px;font-weight:700;display:flex;align-items:center;gap:8px}
.aan-pt{width:11px;height:11px;border-radius:99px;flex:0 0 11px}
.aan-anom{display:flex;gap:10px;align-items:flex-start;padding:7px 0;border-top:1px solid var(--line)}
.aan-anom:first-child{border-top:0}
.aan-src{display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-top:1px solid var(--line);font-size:12.5px}
.aan-src:first-of-type{border-top:0}
.aan-scroll{overflow-x:auto}
.aan-scroll table{min-width:860px}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array(
	'titre' => 'Audit des À-nouveaux — exercice ' . (int) $annee, 'route' => 'comptabilite/cloture/audit-anouveaux',
	'annee' => (int) $annee, 'annees' => $annees,
	'liens' => array(
		array( 'À-nouveaux & ouverture', 'comptabilite/cloture/anouveaux?ouvrir=' . (int) $annee ),
		array( 'Grand Livre', 'comptabilite/grand-livre?du=' . $diag['debut'] ),
		array( 'Balance', 'comptabilite/balance?du=' . $diag['debut'] ),
	),
) ); ?>
<div class="card-body">
	<p class="muted" style="margin-top:0;font-size:12.5px">
		<strong>Les À-nouveaux servent à ouvrir l'exercice ; le Report à nouveau sert à reporter un résultat antérieur.</strong>
		Un exercice s'ouvre par <em>une</em> source, qui reprend exactement la clôture précédente, et que l'exercice référence.
		Grand Livre, Balance et Bilan lisent tous ce même solde d'ouverture.
	</p>

	<?php if ( empty( $diag['fiable'] ) ) : ?>
		<div role="alert" style="margin:0 0 12px;padding:12px 16px;border-radius:10px;border:2px solid #d64545;background:rgba(214,69,69,.09)">
			<strong style="color:#d64545">🔴 <?= 'ambigu' === $diag['etat'] ? 'OUVERTURE ANORMALE — PLUSIEURS SOURCES D\'OUVERTURE DÉTECTÉES' : 'OUVERTURE NON FIABLE' ?></strong>
			<p style="margin:6px 0 0">Les soldes d'ouverture de <?= (int) $annee ?> ne sont pas considérés comme fiables. <?= e( implode( ' ', (array) $diag['raisons'] ) ) ?>
				Le Grand Livre, la Balance et le Bilan l'affichent ; la clôture de <?= (int) $annee ?> et l'ouverture de <?= (int) $annee + 1 ?> sont refusées tant qu'elle n'est pas réparée.</p>
		</div>
	<?php endif; ?>

	<?php if ( $synthese ) : ?>
	<div class="aan-bande">
		<?php foreach ( $synthese as $x ) : $s2 = $statuts[ $x['statut'] ] ?? array( $x['statut'], '', '#8a8f98' ); ?>
			<a class="aan-ex<?= (int) $x['annee'] === (int) $annee ? ' on' : '' ?>" href="<?= e( url( 'comptabilite/cloture/audit-anouveaux?annee=' . (int) $x['annee'] ) ) ?>">
				<b><?= (int) $x['annee'] ?></b>
				<span style="display:flex;align-items:center;gap:6px;font-size:12px"><span class="aan-pt" style="background:<?= e( $s2[2] ) ?>"></span><?= e( $s2[0] ) ?></span>
				<span class="muted" style="font-size:11.5px"><?= (int) $x['nb_sources'] ?> source(s) · <?= (int) $x['anomalies'] ?> anomalie(s)</span>
			</a>
		<?php endforeach; ?>
	</div>
	<?php endif; ?>

	<div class="aan-grille">
		<div class="aan-carte">
			<h3>Statut</h3>
			<div class="aan-gros"><span class="aan-pt" style="background:<?= e( $st[2] ) ?>"></span><?= e( $st[0] ) ?></div>
			<p class="muted" style="margin:6px 0 0;font-size:12px">Ouverture au <?= e( date( 'd/m/Y', strtotime( $diag['debut'] ) ) ) ?>
				<?= $diag['an_officiel'] ? ' — écriture #' . (int) $diag['an_officiel'] : '' ?></p>
			<?php if ( $tr && ! empty( $tr['an_genere_le'] ) ) : ?>
				<p class="muted" style="margin:6px 0 0;font-size:12px">Générés le <?= e( date( 'd/m/Y H:i', strtotime( (string) $tr['an_genere_le'] ) ) ) ?>
					depuis la clôture <?= (int) $tr['an_source_exercice'] ?> (<?= e( fkc_money( (float) $tr['an_total'] ) ) ?> F)
					— empreinte <?= true === $diag['empreinte_a_jour'] ? '<span class="modbadge b-on">à jour</span>' : '<span class="modbadge b-err">clôture modifiée depuis</span>' ?></p>
			<?php endif; ?>
		</div>

		<div class="aan-carte">
			<h3>Sources d'ouverture (<?= count( $diag['sources'] ) ?>)</h3>
			<?php if ( ! $diag['sources'] ) : ?>
				<p class="muted" style="margin:0;font-size:12.5px"><?= 'calcule' === $diag['statut'] ? 'Aucune écriture d\'ouverture : les états utilisent un solde calculé depuis la clôture ' . ( (int) $annee - 1 ) . '.' : 'Aucune source, aucun passé : rien à reprendre.' ?></p>
			<?php else : foreach ( $diag['sources'] as $s ) : ?>
				<div class="aan-src">
					<span><strong>#<?= (int) $s['id'] ?></strong> <?= e( $s['libelle_type'] ) ?><br><span class="muted"><?= e( date( 'd/m/Y', strtotime( $s['date'] ) ) . ' · ' . $s['journal'] . ( $s['reference'] ? ' · ' . $s['reference'] : ( $s['piece'] ? ' · ' . $s['piece'] : '' ) ) ) ?></span>
						<br><span class="muted" style="font-size:11.5px">Reconnue : <strong><?= e( FKC_SoldeOuverture::libelleDetection( $s['detection'] ) ) ?></strong> — <?= e( $s['preuve'] ) ?></span></span>
					<span class="num" style="white-space:nowrap"><?= e( fkc_money( $s['montant'] ) ) ?></span>
				</div>
				<?php if ( $admin && in_array( $s['detection'], array( 'montants', 'libelle', 'qualifiee' ), true ) ) : ?>
					<form method="post" action="<?= e( url( 'comptabilite/cloture/audit-anouveaux/qualifier' ) ) ?>" style="display:flex;gap:6px;margin:0 0 6px">
						<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= (int) $annee ?>"><input type="hidden" name="ecriture_id" value="<?= (int) $s['id'] ?>">
						<input type="hidden" name="qualification" value="exclue">
						<input name="motif" placeholder="Motif : pourquoi ce n'est pas une ouverture" style="flex:1;min-width:0">
						<button class="btn btn-ghost btn-sm" type="submit">Écarter</button>
					</form>
				<?php endif; ?>
			<?php endforeach; endif; ?>
		</div>

		<div class="aan-carte">
			<h3>Référence de l'exercice</h3>
			<div class="aan-gros" style="font-size:15px"><span class="aan-pt" style="background:<?= in_array( $ptr['etat'], array( 'ok', 'aucun' ), true ) ? '#2e9e5b' : '#d9822b' ?>"></span><code>an_ecriture_id</code> = <?= $ptr['pointeur'] ? '#' . (int) $ptr['pointeur'] : '—' ?></div>
			<p class="muted" style="margin:6px 0 0;font-size:12px"><?= e( $ptr['message'] ) ?></p>
			<?php if ( $admin && in_array( $ptr['etat'], array( 'orphelin', 'divergent', 'non_reference' ), true ) && $ptr['exercice_enregistre'] ) : ?>
				<form method="post" action="<?= e( url( 'comptabilite/cloture/audit-anouveaux/resynchroniser' ) ) ?>" style="margin:8px 0 0">
					<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= (int) $annee ?>">
					<button class="btn btn-ghost btn-sm" type="submit" title="Ne touche à aucune écriture : seule la référence est recalée">Resynchroniser la référence</button>
				</form>
			<?php endif; ?>
		</div>

		<div class="aan-carte">
			<h3>Clôture <?= (int) $annee - 1 ?> = Ouverture <?= (int) $annee ?></h3>
			<div class="aan-src"><span>À-nouveaux seul</span><span><?= null === $rap ? '<span class="muted">—</span>' : ( ! empty( $rap['concordant'] ) ? '<span class="modbadge b-on">concordant</span>' : '<span class="modbadge b-err">' . count( (array) $rap['ecarts'] ) . ' écart(s)</span>' ) ?></span></div>
			<div class="aan-src"><span>Ouverture effective<br><span class="muted">toutes sources</span></span><span><?= $eff['calcule'] ? '<span class="modbadge">calculée</span>' : ( $eff['concordant'] ? '<span class="modbadge b-on">concordante</span>' : '<span class="modbadge b-err">' . count( $eff['ecarts'] ) . ' écart(s)</span>' ) ?></span></div>
			<?php $t = $dec['totaux']; if ( ! empty( $dec['attendu_defini'] ) ) : ?>
				<div class="aan-src"><span>Clôture <?= (int) $annee - 1 ?> (attendu)</span><span class="num"><?= e( fkc_money( $t['attendu'] ) ) ?></span></div>
				<div class="aan-src"><span><?= $dec['report_calcule'] ? 'Report calculé' : 'À-nouveaux officiel' ?></span><span class="num"><?= e( fkc_money( $t['officiel'] ) ) ?></span></div>
				<?php foreach ( $diag['sources'] as $s ) : if ( ! empty( $s['officielle'] ) ) { continue; } ?>
					<div class="aan-src"><span><?= e( $s['libelle_type'] ) ?> #<?= (int) $s['id'] ?></span><span class="num"><?= e( fkc_money( $t['sources'][ $s['id'] ] ?? 0 ) ) ?></span></div>
				<?php endforeach; ?>
				<div class="aan-src"><span><strong>Ouverture effective</strong></span><span class="num"><strong><?= e( fkc_money( $t['effectif'] ) ) ?></strong></span></div>
				<div class="aan-src"><span><strong>Écart</strong></span><span class="num" style="<?= abs( $t['ecart'] ) > 1 ? 'color:#d64545' : '' ?>"><strong><?= ( $t['ecart'] > 0 ? '+' : ( $t['ecart'] < 0 ? '−' : '' ) ) . e( fkc_money( abs( $t['ecart'] ) ) ) ?></strong></span></div>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( $diag['anomalies'] ) : ?>
	<div class="aan-carte" style="margin-bottom:14px">
		<h3>Anomalies</h3>
		<?php foreach ( $diag['anomalies'] as $a ) : ?>
			<div class="aan-anom"><span class="aan-pt" style="margin-top:4px;background:<?= e( $niv[ $a['niveau'] ] ?? '#8a8f98' ) ?>"></span>
				<span><strong style="text-transform:capitalize"><?= e( $a['niveau'] ) ?></strong> — <?= e( $a['texte'] ) ?></span></div>
		<?php endforeach; ?>
	</div>
	<?php endif; ?>

	<?php if ( ! empty( $diag['reparation'] ) ) : ?>
	<div class="aan-carte" style="margin-bottom:14px;border-color:#d64545">
		<h3>Réparation guidée</h3>
		<p class="muted" style="margin:0 0 8px;font-size:12.5px">Choisissez l'origine à <strong>conserver</strong> : les autres sources seront contre-passées
			(même date, même journal, même numéro, type « annulation »), dans une seule transaction. Rien n'est supprimé ; l'opération est refusée si
			l'ouverture qui en résulte ne reprend pas exactement la clôture <?= (int) $annee - 1 ?>, et consignée au journal de clôture.</p>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/audit-anouveaux/reparer' ) ) ?>">
			<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<?php $premier = true; foreach ( $diag['reparation'] as $o ) : ?>
				<label style="display:flex;gap:10px;align-items:flex-start;padding:7px 0;border-top:1px solid var(--line);<?= $o['valable'] ? '' : 'opacity:.6' ?>">
					<input type="radio" name="conserver" value="<?= (int) $o['conserver'] ?>" style="width:auto;margin-top:3px" <?= $o['valable'] ? '' : 'disabled' ?> <?= ( $o['valable'] && $premier ) ? 'checked' : '' ?>>
					<span><strong>Conserver <?= e( $o['libelle'] ) ?></strong><?= ( $o['valable'] && $premier ) ? ' <span class="modbadge b-on">recommandé</span>' : '' ?><br>
						<span class="muted" style="font-size:12px"><?= $o['contrepasser'] ? 'Contre-passer #' . e( implode( ', #', $o['contrepasser'] ) ) : 'Aucune contre-passation' ?>
						· ouverture résultante <?= e( fkc_money( $o['effectif'] ) ) ?>
						<?= $o['valable'] ? '· <span style="color:#2e9e5b">reprend la clôture ' . ( (int) $annee - 1 ) . '</span>' : '· <span style="color:#d64545">' . e( $o['raison'] ) . '</span>' ?></span></span>
				</label>
			<?php if ( $o['valable'] ) { $premier = false; } endforeach; ?>
			<?php if ( $admin ) : ?>
				<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
					<input name="motif" placeholder="Motif de la réparation (vingt caractères au moins)" style="flex:1;min-width:220px">
					<button class="btn btn-primary" type="submit" <?= $premier ? 'disabled' : '' ?>>Réparer l'ouverture <?= (int) $annee ?></button>
				</div>
			<?php else : ?><p class="muted" style="margin:8px 0 0;font-size:12px">Réservé à l'administrateur du dossier.</p><?php endif; ?>
		</form>
	</div>
	<?php endif; ?>

	<?php if ( ! empty( $dec['comptes'] ) && ( ! empty( $diag['sources'] ) || ! empty( $dec['report_calcule'] ) ) ) : ?>
	<div class="aan-carte" style="margin-bottom:14px"><h3>Solde attendu / officiel / effectif, compte par compte</h3>
		<div class="aan-scroll"><table class="table" style="min-width:640px">
			<thead><tr><th>Compte</th><th>Intitulé</th><th class="num">Attendu<br><span class="muted">clôture <?= (int) $annee - 1 ?></span></th>
				<th class="num">Officiel<br><span class="muted"><?= $dec['report_calcule'] ? 'report calculé' : 'À-nouveaux' ?></span></th>
				<?php foreach ( $diag['sources'] as $s ) : if ( ! empty( $s['officielle'] ) ) { continue; } ?><th class="num"><?= e( $s['libelle_type'] ) ?><br><span class="muted">#<?= (int) $s['id'] ?></span></th><?php endforeach; ?>
				<th class="num">Effectif</th><th class="num">Écart</th></tr></thead>
			<tbody><?php foreach ( array_slice( $dec['comptes'], 0, 120 ) as $c ) : $bad = null !== $c['ecart'] && abs( $c['ecart'] ) > 1; ?>
				<tr<?= $bad ? ' style="background:rgba(214,69,69,.06)"' : '' ?>><td><span class="code"><?= e( $c['numero'] ) ?></span></td><td><?= e( $c['libelle'] ) ?></td>
					<td class="num"><?= e( $dec['attendu_defini'] ? $dcs( $c['attendu'] ) : '—' ) ?></td>
					<td class="num"><?= e( $dcs( $c['officiel'] ) ) ?></td>
					<?php foreach ( $diag['sources'] as $s ) : if ( ! empty( $s['officielle'] ) ) { continue; } ?><td class="num"><?= isset( $c['sources'][ $s['id'] ] ) ? e( $dcs( $c['sources'][ $s['id'] ] ) ) : '' ?></td><?php endforeach; ?>
					<td class="num"><strong><?= e( $dcs( $c['effectif'] ) ) ?></strong></td>
					<td class="num" style="<?= $bad ? 'color:#d64545' : '' ?>"><?= null === $c['ecart'] ? '—' : e( ( $c['ecart'] > 0 ? '+' : ( $c['ecart'] < 0 ? '−' : '' ) ) . fkc_money( abs( $c['ecart'] ) ) ) ?></td></tr>
			<?php endforeach; ?></tbody>
		</table></div>
	</div>
	<?php endif; ?>

	<?php if ( $admin ) : ?>
	<div class="aan-carte" style="margin-bottom:14px"><h3>Qualifier une écriture comme source d'ouverture</h3>
		<p class="muted" style="margin:0 0 8px;font-size:12.5px">Pour une OD qui reprend des soldes sans que son libellé ni ses montants le montrent. La décision est conservée avec son motif et son auteur.</p>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/audit-anouveaux/qualifier' ) ) ?>" style="display:flex;gap:8px;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= (int) $annee ?>"><input type="hidden" name="qualification" value="source">
			<input name="ecriture_id" inputmode="numeric" placeholder="N° interne de l'écriture" style="width:190px">
			<input name="motif" placeholder="Motif" style="flex:1;min-width:200px">
			<button class="btn btn-ghost btn-sm" type="submit">Qualifier source d'ouverture</button>
		</form>
	</div>
	<?php endif; ?>

	<?php $ec = array_merge( $rap && empty( $rap['concordant'] ) ? (array) $rap['ecarts'] : array(), ! $eff['concordant'] ? $eff['ecarts'] : array() ); ?>
	<?php if ( $ec ) : ?>
	<div class="aan-carte" style="margin-bottom:14px"><h3>Comptes en écart</h3>
		<div class="aan-scroll"><table class="table" style="min-width:560px">
			<thead><tr><th>Compte</th><th>Intitulé</th><th class="num">Clôture <?= (int) $annee - 1 ?></th><th class="num">Ouverture <?= (int) $annee ?></th><th class="num">Écart</th></tr></thead>
			<tbody><?php foreach ( array_slice( $ec, 0, 60 ) as $l ) : ?>
				<tr><td><span class="code"><?= e( $l['numero'] ) ?></span></td><td><?= e( $l['libelle'] ) ?></td>
					<td class="num"><?= e( fkc_money( $l['cloture'] ) ) ?></td><td class="num"><?= e( fkc_money( $l['ouverture'] ) ) ?></td>
					<td class="num" style="color:var(--orange)"><?= e( fkc_money( $l['ecart'] ) ) ?></td></tr>
			<?php endforeach; ?></tbody>
		</table></div>
	</div>
	<?php endif; ?>

	<div class="aan-carte"><h3>Détail des lignes d'ouverture (<?= count( $lignes ) ?>)</h3>
		<?php if ( ! $lignes ) : ?>
			<p class="muted" style="margin:0">Aucune écriture d'ouverture pour <?= (int) $annee ?>.</p>
		<?php else : ?>
		<div class="aan-scroll"><table class="table">
			<thead><tr><th>Compte</th><th>Intitulé</th><th class="num">Débit</th><th class="num">Crédit</th><th>Journal</th><th>Référence</th><th>Exercice</th><th>Origine</th><th>Tiers / devise</th></tr></thead>
			<tbody><?php foreach ( array_slice( $lignes, 0, 400 ) as $l ) : ?>
				<tr<?= empty( $l['officielle'] ) && empty( $diag['fiable'] ) ? ' style="background:rgba(214,69,69,.06)"' : '' ?>>
					<td><span class="code"><?= e( $l['numero'] ) ?></span></td><td><?= e( $l['compte'] ) ?></td>
					<td class="num"><?= $l['debit'] ? e( fkc_money( $l['debit'] ) ) : '' ?></td>
					<td class="num"><?= $l['credit'] ? e( fkc_money( $l['credit'] ) ) : '' ?></td>
					<td><span class="code"><?= e( $l['journal'] ) ?></span></td>
					<td class="muted"><?= e( ( $l['reference'] ?: '—' ) . ' (#' . (int) $l['ecriture_id'] . ')' ) ?></td>
					<td><?= (int) $l['exercice'] ?></td><td><?= e( $l['origine'] ) ?></td>
					<td class="muted"><?= e( trim( $l['tiers'] . ' ' . $l['devise'] ) ) ?></td>
				</tr>
			<?php endforeach; ?></tbody>
			<tfoot><tr class="total"><td colspan="2">Totaux</td><td class="num"><?= e( fkc_money( $td ) ) ?></td><td class="num"><?= e( fkc_money( $tc ) ) ?></td><td colspan="5"></td></tr></tfoot>
		</table></div>
		<?php if ( count( $lignes ) > 400 ) : ?><p class="muted" style="font-size:12px">400 premières lignes affichées sur <?= count( $lignes ) ?>.</p><?php endif; ?>
		<?php endif; ?>
	</div>
</div></div>
