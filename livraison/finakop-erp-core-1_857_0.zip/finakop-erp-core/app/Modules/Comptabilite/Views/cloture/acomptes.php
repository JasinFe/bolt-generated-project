<?php
/**
 * REGISTRE DES ACOMPTES D'IMPÔT SUR LE RÉSULTAT (1.784.0).
 *
 * @var int $annee @var array $annees @var array $liste @var array $totaux @var array $base
 * @var array $dates @var array $statuts @var array $tresos @var array|null $impot @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div><?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Acomptes d\'impôt sur le résultat — ' . (int) $annee, 'route' => 'comptabilite/cloture/acomptes', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Résultat fiscal', 'comptabilite/cloture/fiscal?annee=' . (int) $annee ) ) ) ); ?>
<div class="card-body">
	<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px">
		<div><div class="muted" style="font-size:12px">Prévus</div><strong><?= e( fkc_money( $totaux['prevu'] ) ) ?> F</strong></div>
		<div><div class="muted" style="font-size:12px">Versés</div><strong><?= e( fkc_money( $totaux['paye'] ) ) ?> F</strong></div>
		<div><div class="muted" style="font-size:12px">Imputés sur la dette</div><strong><?= e( fkc_money( $totaux['impute'] ) ) ?> F</strong></div>
		<?php if ( $impot ) : ?><div><div class="muted" style="font-size:12px">Impôt dû <?= (int) $annee ?> − acomptes versés</div><strong><?= e( fkc_money( (float) $impot['du'] - $totaux['paye'] ) ) ?> F</strong></div><?php endif; ?>
	</div>
	<p class="muted" style="margin:10px 0 0;font-size:12.5px">Le versement passe D 449200 « État, acomptes d'impôt sur le résultat » / C trésorerie — jamais en charge. À la clôture, l'imputation solde le 449 contre la dette d'impôt (441) ; le reste à payer de la déclaration IS déduit les acomptes versés.
	L'échéancier proposé (<?= e( implode( ', ', $dates ) ) ?>) et sa base se vérifient avec le conseil fiscal : ils dépendent du régime et de la loi de finances.</p>
</div></div>

<?php if ( ! $liste ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Générer l'échéancier</h3></div><div class="card-body">
	<form method="post" action="<?= e( url( 'comptabilite/cloture/acomptes/planifier' ) ) ?>" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin:0">
		<?= FKC_Csrf::field() ?><input type="hidden" name="annee" value="<?= (int) $annee ?>">
		<label style="display:flex;flex-direction:column;font-size:12px">Base (impôt de référence)<input type="text" name="base" value="<?= $base['montant'] > 0 ? e( (string) $base['montant'] ) : '' ?>" placeholder="montant"></label>
		<button class="btn btn-sm">Générer <?= count( $dates ) ?> acompte(s)</button>
		<?php if ( $base['source'] ) : ?><span class="muted" style="font-size:12px">Proposé : <?= e( $base['source'] ) ?></span><?php endif; ?>
	</form>
</div></div>
<?php endif; ?>

<div class="card card-flush" style="margin-top:12px">
<table class="table"><thead><tr><th>N°</th><th>Échéance</th><th class="right">Montant</th><th>Statut</th><th>Versement</th><th></th></tr></thead><tbody>
<?php foreach ( $liste as $a ) : $retard = 'prevu' === $a['statut'] && $a['echeance'] < date( 'Y-m-d' ); ?>
	<tr>
		<td><?= (int) $a['rang'] ?></td>
		<td style="<?= $retard ? 'color:#ff6b6b' : '' ?>"><?= e( date( 'd/m/Y', strtotime( $a['echeance'] ) ) ) ?><?= $retard ? ' — échu' : '' ?></td>
		<td class="right mono"><?= e( fkc_money( $a['montant'] ) ) ?></td>
		<td><?= e( $statuts[ $a['statut'] ] ?? $a['statut'] ) ?></td>
		<td style="font-size:12px"><?= $a['date_paiement'] ? e( date( 'd/m/Y', strtotime( $a['date_paiement'] ) ) ) . ( $a['ecriture_id'] ? ' — écriture n° ' . (int) $a['ecriture_id'] : '' ) : '' ?></td>
		<td style="white-space:nowrap">
		<?php if ( 'prevu' === $a['statut'] ) : ?>
			<form method="post" action="<?= e( url( 'comptabilite/cloture/acomptes/' . (int) $a['id'] . '/payer' ) ) ?>" style="display:inline-flex;gap:4px;margin:0"><?= FKC_Csrf::field() ?>
				<select name="tresorerie_id"><?php foreach ( $tresos as $t ) : ?><option value="<?= (int) $t['id'] ?>"><?= e( $t['libelle'] ) ?></option><?php endforeach; ?></select>
				<input type="date" name="date" value="<?= e( min( date( 'Y-m-d' ), $a['echeance'] ) ) ?>">
				<button class="btn btn-sm">Verser</button>
			</form>
			<form method="post" action="<?= e( url( 'comptabilite/cloture/acomptes/' . (int) $a['id'] . '/annuler' ) ) ?>" style="display:inline;margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Annuler</button></form>
		<?php endif; ?>
		</td>
	</tr>
<?php endforeach; ?>
<?php if ( ! $liste ) : ?><tr><td colspan="6" class="muted" style="text-align:center;padding:18px">Aucun acompte pour <?= (int) $annee ?>.</td></tr><?php endif; ?>
</tbody></table></div>

<div class="card" style="margin-top:12px"><div class="card-body" style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-end">
	<form method="post" action="<?= e( url( 'comptabilite/cloture/acomptes/creer' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;margin:0"><?= FKC_Csrf::field() ?>
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">
		<label style="display:flex;flex-direction:column;font-size:12px">Échéance<input type="date" name="echeance"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Montant<input type="text" name="montant"></label>
		<button class="btn btn-ghost btn-sm">Ajouter un acompte</button>
	</form>
	<?php if ( $totaux['non_impute'] > 0 ) : ?>
	<form method="post" action="<?= e( url( 'comptabilite/cloture/acomptes/imputer' ) ) ?>" style="margin:0" onsubmit="return confirm('Imputer <?= e( fkc_money( $totaux['non_impute'] ) ) ?> F d\'acomptes sur la dette d\'impôt au dernier jour de l\'exercice ?')"><?= FKC_Csrf::field() ?>
		<input type="hidden" name="annee" value="<?= (int) $annee ?>">
		<button class="btn btn-sm">Imputer <?= e( fkc_money( $totaux['non_impute'] ) ) ?> F sur la dette d'impôt</button>
	</form>
	<?php endif; ?>
</div></div>
