<?php
/**
 * LES TRAVAUX D'INVENTAIRE.
 *
 * L'écran répond à « qu'est-ce qu'il me reste à faire avant de pouvoir
 * arrêter ? », par domaine de travail — là où la checklist de clôture répond à
 * « qu'est-ce qui me bloque ? », par gravité. Deux lectures des mêmes faits,
 * et deux moments différents du travail.
 *
 * Chaque domaine porte son OBJET : la phrase qu'on relit quand on ne sait plus
 * pourquoi on fait ce travail. Elle n'est pas décorative — l'inventaire est le
 * seul moment de l'année où l'on fait ces gestes, et personne ne s'en souvient
 * d'un exercice à l'autre.
 *
 * @var int $annee @var array $annees @var array $etat @var array|null $cloture
 * @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$coul = array( 'fait' => '#3ddc84', 'attention' => '#ffb020', 'a_faire' => '#ff6b6b' );
$lbl  = array( 'fait' => 'Rien à signaler', 'attention' => 'À examiner', 'a_faire' => 'Bloque la clôture' );
$prog = (int) $etat['progression'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.inv-bar{height:6px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;margin:2px 0 14px}
.inv-bar i{display:block;height:100%;background:#3ddc84}
.inv-dom{border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px 14px;margin-bottom:10px;background:rgba(255,255,255,.02)}
.inv-head{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}
.inv-obj{font-size:12.5px;color:#9aa3b5;line-height:1.5;margin:5px 0 0}
.inv-ctl{display:flex;gap:10px;align-items:flex-start;padding:8px 0 0;margin-top:8px;border-top:1px solid rgba(255,255,255,.06)}
.inv-dot{flex:0 0 9px;height:9px;border-radius:99px;margin-top:5px}
.inv-det{font-size:12px;color:#c3cadb;line-height:1.45;margin-top:3px}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Travaux d\'inventaire — ' . (int) $annee, 'route' => 'comptabilite/cloture/inventaire', 'annee' => (int) $annee, 'annees' => $annees,  'liens' => array( array( 'Assistant de clôture', 'comptabilite/cloture?annee=' . (int) $annee ), array( 'Rattachements', 'comptabilite/regularisations?annee=' . (int) $annee ) ) ) ); ?>
<div class="card-body">
	<div class="inv-bar"><i style="width:<?= $prog ?>%"></i></div>
	<p style="margin:0 0 6px">
		<strong><?= (int) $etat['acheves'] ?> / <?= (int) $etat['total'] ?></strong> domaines sans rien à signaler
		<?php if ( (int) $etat['bloquants'] ) : ?>
			· <span style="color:#ff6b6b;font-weight:700"><?= (int) $etat['bloquants'] ?> point(s) bloquant(s)</span>
		<?php endif; ?>
		<?php if ( (int) $etat['anomalies'] ) : ?>
			· <span style="color:#ffb020"><?= (int) $etat['anomalies'] ?> point(s) à traiter</span>
		<?php endif; ?>
	</p>
	<p class="muted" style="margin:0;font-size:12.5px">
		L'inventaire est le gros du travail d'arrêté des comptes, et il se fait sur sept écrans différents.
		Celui-ci ne les remplace pas : il dit <strong>où aller travailler</strong>, et pourquoi. Les mesures
		viennent des mêmes contrôles que la checklist de clôture — qui, elle, est classée par gravité et répond
		à une autre question : « qu'est-ce qui me bloque ? ».
	</p>
	<?php if ( $cloture ) : ?>
		<p style="margin:8px 0 0;color:#3ddc84"><strong>Exercice clôturé</strong> le
			<?= e( date( 'd/m/Y', strtotime( (string) $cloture['date_cloture'] ) ) ) ?> : ces travaux sont arrêtés.</p>
	<?php endif; ?>
</div></div>

<?php if ( ! $etat['domaines'] ) : ?>
<div class="card" style="margin-top:12px"><div class="card-body">
	<p class="muted" style="margin:0">Aucun domaine d'inventaire ne concerne ce dossier — les modules correspondants
	ne sont pas installés. Un domaine dont le module manque n'apparaît pas : afficher « Stocks : rien à faire »
	dans un cabinet de conseil rassurerait sur une question qui ne se pose pas.</p>
</div></div>
<?php endif; ?>

<?php foreach ( $etat['domaines'] as $d ) :
	$c = $coul[ $d['statut'] ] ?? '#8a93a6'; ?>
	<div class="inv-dom" style="border-color:<?= $c ?>33">
		<div class="inv-head">
			<span style="flex:0 0 10px;height:10px;border-radius:99px;background:<?= $c ?>;margin-top:5px"></span>
			<strong style="font-size:14.5px;flex:1"><?= e( $d['libelle'] ) ?></strong>
			<span style="font-size:11.5px;text-transform:uppercase;letter-spacing:.4px;color:<?= $c ?>;font-weight:700">
				<?= e( $lbl[ $d['statut'] ] ?? $d['statut'] ) ?>
			</span>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $d['ou'] ) ) ?>">Ouvrir</a>
		</div>
		<p class="inv-obj"><?= e( $d['objet'] ) ?></p>

		<?php foreach ( $d['controles'] as $ct ) :
			$info = 'information' === $ct['niveau'];
			$dot  = $info ? '#6aa9ff' : ( $ct['bloque'] ? '#ff6b6b' : ( $ct['anomalie'] ? ( $ct['couvert'] ? '#6aa9ff' : '#ffb020' ) : '#3ddc84' ) ); ?>
			<div class="inv-ctl">
				<span class="inv-dot" style="background:<?= $dot ?>"></span>
				<div style="flex:1">
					<span style="font-size:13px"><?= e( $ct['libelle'] ) ?></span>
					<?php if ( ! $info && $ct['anomalie'] ) : ?>
						<strong style="color:<?= $dot ?>"> · <?= (int) $ct['nb'] ?></strong>
					<?php elseif ( ! $info ) : ?>
						<span style="color:#3ddc84"> · ✓</span>
					<?php endif; ?>
					<?php if ( $ct['couvert'] ) : ?>
						<span style="font-size:11px;color:#6aa9ff"> · justifié</span>
					<?php endif; ?>
					<?php foreach ( array_slice( (array) $ct['detail'], 0, 4 ) as $x ) : ?>
						<div class="inv-det">— <?= e( (string) $x ) ?></div>
					<?php endforeach; ?>
					<?php if ( count( (array) $ct['detail'] ) > 4 ) : ?>
						<div class="inv-det muted">… et <?= count( (array) $ct['detail'] ) - 4 ?> autre(s)</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
<?php endforeach; ?>
