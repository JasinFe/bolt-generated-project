<?php
/**
 * À-NOUVEAUX ET OUVERTURE DE L'EXERCICE.
 *
 * L'écran montre les à-nouveaux AVANT de les écrire. C'est tout l'intérêt :
 * l'ancienne version les générait dans la foulée de l'ouverture, et on ne
 * découvrait le déséquilibre — équilibré de force sur 121/129 — que plus
 * tard, au bilan, sous l'apparence d'un report à nouveau légitime.
 *
 * @var int $annee @var array $annees @var array $vue @var array $existent
 * @var bool $ouvert @var array $controles @var array $synthese @var bool $collectif
 * @var array|null $rapprochement @var bool $admin @var mixed $flash @var array|null $explication
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$lignes = (array) $vue['lignes'];
$max    = 250; // au-delà, on résume : une table de 4 000 lignes ne se lit pas.
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<style>
.an-kpi{display:flex;gap:20px;flex-wrap:wrap;align-items:baseline;margin:0 0 6px}
.an-kpi b{font-size:17px}
.an-ctl{display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-top:1px solid rgba(255,255,255,.06)}
.an-dot{flex:0 0 10px;height:10px;border-radius:99px;margin-top:5px}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'À-nouveaux de l\'exercice ' . (int) $annee, 'route' => 'comptabilite/cloture/anouveaux', 'annee' => (int) $annee, 'annees' => $annees, 'param' => 'ouvrir', 'prefixe' => 'Ouvrir', 'caches' => $collectif ? array( 'collectif' => 1 ) : array(), 'liens' => array( array( 'Assistant', 'comptabilite/cloture?annee=' . ( (int) $annee - 1 ) ) ) ) ); ?>
<div class="card-body">
	<p class="muted" style="margin-top:0;font-size:12.5px">
		Report des soldes de bilan (classes 1 à 5) arrêtés au
		<strong><?= e( date( 'd/m/Y', strtotime( (string) $vue['fin_precedente'] ) ) ) ?></strong>,
		reportés au <strong><?= e( date( 'd/m/Y', strtotime( (string) $vue['debut'] ) ) ) ?></strong>.
		Les comptes de gestion (classes 6, 7 et 8) sont exclus : ils ont été soldés par la détermination
		du résultat, et les reporter les ferait vivre deux exercices.
	</p>

	<?php if ( $existent ) : ?>
		<div class="alert alert-err">
			<strong>À-nouveaux déjà générés</strong> pour <?= (int) $annee ?>
			(écriture #<?= e( implode( ', #', array_map( 'intval', $existent ) ) ) ?>).
			Une seconde génération doublerait tous les soldes d'ouverture — capital, immobilisations,
			dettes, trésorerie — sur un bilan qui resterait équilibré, donc sans qu'aucun contrôle ne
			s'en aperçoive.
		</div>
	<?php elseif ( ! $vue['ok'] ) : ?>
		<div class="alert alert-err"><?= e( (string) $vue['message'] ) ?></div>
	<?php elseif ( ! $lignes ) : ?>
		<div class="alert alert-ok"><?= e( (string) $vue['message'] ) ?></div>
	<?php else : ?>
		<div class="an-kpi">
			<span>Total débit <b><?= e( fkc_money( $vue['total_debit'] ) ) ?></b> F CFA</span>
			<span>Total crédit <b><?= e( fkc_money( $vue['total_credit'] ) ) ?></b> F CFA</span>
			<span>Écart <b style="color:<?= $vue['equilibre'] ? '#3ddc84' : '#ff6b6b' ?>"><?= e( fkc_money( $vue['ecart'] ) ) ?></b></span>
			<span class="muted"><?= count( $lignes ) ?> ligne(s) · <?= (int) $vue['nb_comptes'] ?> compte(s)
				<?= (int) $vue['nb_auxiliaires'] ? ' · ' . (int) $vue['nb_auxiliaires'] . ' position(s) auxiliaire(s)' : '' ?></span>
		</div>
	<?php endif; ?>
</div></div>

<?php /* ── Contrôles d'ouverture ───────────────────────────────────────── */ ?>
<?php if ( $controles ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Contrôles avant ouverture</h2></div><div class="card-body">
<?php foreach ( $controles as $cat ) : foreach ( $cat['controles'] as $c ) :
	$dot = $c['anomalie'] ? ( $c['bloque'] ? '#ff6b6b' : '#ffb020' ) : '#3ddc84'; ?>
	<div class="an-ctl">
		<span class="an-dot" style="background:<?= $dot ?>"></span>
		<div style="flex:1">
			<strong style="font-size:13.5px"><?= e( $c['libelle'] ) ?></strong>
			<div style="font-size:12px;color:#9aa3b5;line-height:1.45"><?= e( $c['note'] ) ?></div>
			<?php foreach ( array_slice( (array) $c['detail'], 0, 5 ) as $d ) : ?>
				<div style="font-size:12px;color:#c3cadb">— <?= e( (string) $d ) ?></div>
			<?php endforeach; ?>
		</div>
		<?php if ( $c['anomalie'] ) : ?>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $c['ou'] ) ) ?>">Voir</a>
		<?php endif; ?>
	</div>
<?php endforeach; endforeach; ?>
</div></div>
<?php endif; ?>

<?php /* ── Actions ─────────────────────────────────────────────────────── */ ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Actions</h2></div><div class="card-body">
	<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">

	<?php if ( ! $ouvert ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/ouvrir' ) ) ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<input type="hidden" name="report_an" value="1">
			<?php if ( $collectif ) : ?><input type="hidden" name="collectif" value="1"><?php endif; ?>
			<button class="btn btn-primary" type="submit" <?= ( $vue['ok'] && ! $existent && 0 === (int) $synthese['bloquants'] ) ? '' : 'disabled' ?>>
				Ouvrir l'exercice <?= (int) $annee ?> avec ses à-nouveaux
			</button>
		</form>
	<?php elseif ( ! $existent && $vue['ok'] && $lignes ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/anouveaux/generer' ) ) ?>" style="display:flex;gap:8px;align-items:center;margin:0">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<?php if ( $collectif ) : ?><input type="hidden" name="collectif" value="1"><?php endif; ?>
			<button class="btn btn-primary" type="submit" <?= 0 === (int) $synthese['bloquants'] ? '' : 'disabled' ?>>
				Générer les à-nouveaux
			</button>
		</form>
	<?php endif; ?>

	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/cloture/anouveaux?ouvrir=' . (int) $annee . ( $collectif ? '' : '&collectif=1' ) ) ) ?>">
		<?= $collectif ? 'Repasser au détail par tiers' : 'Prévisualiser en collectif (sans détail tiers)' ?>
	</a>

	<?php if ( $existent && $admin ) : ?>
		<form method="post" action="<?= e( url( 'comptabilite/cloture/anouveaux/annuler' ) ) ?>"
			style="display:flex;gap:6px;flex:1 1 100%;flex-wrap:wrap;align-items:center;margin-top:6px"
			onsubmit="return confirm('Supprimer les à-nouveaux de <?= (int) $annee ?> ?')">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="annee" value="<?= (int) $annee ?>">
			<input type="text" name="motif" required minlength="10" style="flex:1 1 320px"
				placeholder="Motif de l'annulation (obligatoire, ≥ 10 caractères)">
			<button class="btn btn-ghost btn-sm" type="submit">Supprimer les à-nouveaux</button>
		</form>
	<?php endif; ?>
	</div>

	<p class="muted" style="font-size:12.5px;margin-bottom:0">
		Le <strong>détail par tiers</strong> conserve le solde de chaque client et de chaque fournisseur à
		l'ouverture : sans lui, le grand livre auxiliaire repart à zéro au premier jour, un règlement de
		janvier ne peut plus se lettrer sur une facture de décembre, et la balance âgée perd toute son
		antériorité. Le mode collectif n'existe que pour les dossiers à plusieurs milliers de tiers qui
		l'assument.
	</p>
</div></div>

<?php /* ── Rapprochement N / N+1 ───────────────────────────────────────── */ ?>
<?php if ( $rapprochement ) : ?>
<div class="card" style="margin-top:12px"><?php FKC_View::partial( 'comptabilite::cloture._entete', array( 'titre' => 'Rapprochement ' . ( (int) $annee - 1 ) . ' / ' . (int) $annee,
	'liens' => array( array( '🖨 Rapprochement', 'comptabilite/cloture/imprimer?annee=' . ( (int) $annee - 1 ) . '&rapport=rapprochement', 'blank' => true ),
		array( '🖨 État des à-nouveaux', 'comptabilite/cloture/imprimer?annee=' . ( (int) $annee - 1 ) . '&rapport=anouveaux', 'blank' => true ) ) ) ); ?>
<div class="card-body">
	<p style="margin-top:0;color:<?= $rapprochement['concordant'] ? '#3ddc84' : '#ff6b6b' ?>">
		<strong><?= e( (string) $rapprochement['message'] ) ?></strong>
	</p>
	<?php
	/* Cause de chaque écart (phase 5) : l'écran dit POURQUOI, pas seulement COMBIEN. */
	$causes = array();
	foreach ( (array) ( $explication['lignes'] ?? array() ) as $cx ) { $causes[ (string) $cx['numero'] ] = $cx; }
	?>
	<?php if ( $rapprochement['ecarts'] ) : ?>
		<table class="table">
			<thead><tr><th>Compte</th><th>Libellé</th><th class="right">Clôture <?= (int) $annee - 1 ?></th><th class="right">Ouverture <?= (int) $annee ?></th><th class="right">Écart</th><th>Cause</th></tr></thead>
			<tbody>
			<?php foreach ( array_slice( $rapprochement['ecarts'], 0, 100 ) as $l ) : ?>
				<tr>
					<td class="mono"><?= e( (string) $l['numero'] ) ?></td>
					<td><?= e( (string) $l['libelle'] ) ?></td>
					<td class="right mono"><?= e( fkc_money( $l['cloture'] ) ) ?></td>
					<td class="right mono"><?= e( fkc_money( $l['ouverture'] ) ) ?></td>
					<td class="right mono" style="color:#ff6b6b"><?= e( fkc_money( $l['ecart'] ) ) ?></td>
					<td style="font-size:12px"><?php $cz = $causes[ (string) $l['numero'] ] ?? null; echo $cz ? e( implode( ' ', $cz['causes'] ) ) . '<div class="muted">→ ' . e( $cz['geste'] ) . '</div>' : ''; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
	<?php if ( $rapprochement['affectation'] ) : ?>
		<p class="muted" style="font-size:12.5px">
			<?= count( $rapprochement['affectation'] ) ?> compte(s) ont bougé entre la clôture et l'ouverture
			du fait de l'<strong>affectation du résultat</strong> : réserves, report à nouveau, dividendes.
			Ces mouvements sont réguliers et ne sont pas comptés comme écarts —
			<?= e( implode( ', ', array_map( function ( $l ) { return (string) $l['numero']; }, array_slice( $rapprochement['affectation'], 0, 8 ) ) ) ) ?>.
		</p>
	<?php endif; ?>
</div></div>
<?php endif; ?>

<?php /* ── Prévisualisation ────────────────────────────────────────────── */ ?>
<?php if ( $lignes ) : ?>
<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h2>Prévisualisation</h2></div>
	<table class="table">
		<thead><tr><th>Compte</th><th>Libellé</th><th>Tiers</th><th>Devise</th><th class="right">Débit</th><th class="right">Crédit</th></tr></thead>
		<tbody>
		<?php foreach ( array_slice( $lignes, 0, $max ) as $l ) : ?>
			<tr>
				<td class="mono"><?= e( (string) $l['numero'] ) ?></td>
				<td><?= e( (string) $l['compte'] ) ?></td>
				<td class="muted"><?= $l['tiers_id'] ? e( (string) $l['tiers_type'] . ' #' . (int) $l['tiers_id'] ) : '—' ?></td>
				<td class="muted"><?= $l['devise'] ? e( (string) $l['devise'] . ' ' . fkc_money( $l['montant_devise'], 2 ) ) : '—' ?></td>
				<td class="right mono"><?= $l['debit'] > 0 ? e( fkc_money( $l['debit'] ) ) : '' ?></td>
				<td class="right mono"><?= $l['credit'] > 0 ? e( fkc_money( $l['credit'] ) ) : '' ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr>
			<th colspan="4"><?= count( $lignes ) > $max ? 'Total (toutes lignes, ' . count( $lignes ) . ' — ' . $max . ' affichées)' : 'Total' ?></th>
			<th class="right mono"><?= e( fkc_money( $vue['total_debit'] ) ) ?></th>
			<th class="right mono"><?= e( fkc_money( $vue['total_credit'] ) ) ?></th>
		</tr></tfoot>
	</table>
</div>
<?php endif; ?>
