<?php
/**
 * FEUILLE D'IMPRESSION DE LA CLÔTURE — six documents, une seule feuille.
 *
 * Chaque section se lit seule (un rapport d'anomalies transmis au
 * commissaire aux comptes) et toutes s'enchaînent en un dossier, une
 * section par page. Un exercice non clôturé porte « PROVISOIRE » en
 * filigrane sur CHAQUE page : un document provisoire qui traîne six mois
 * sur un bureau finit à côté du définitif.
 *
 * @var array $rapport  sortie de FKC_ClotureRapport::assembler()
 * @var array $types    FKC_ClotureRapport::types()
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$R  = $rapport;
$H  = $R['entete'];
$an = (int) $R['annee'];
$S  = $R['sections'];
$m  = function ( $v ) { return null === $v ? '' : number_format( (float) $v, 0, ',', ' ' ); };
$niveaux = array( 'absolu' => 'Absolu', 'bloquant' => 'Bloquant', 'avertissement' => 'Avertissement', 'information' => 'Information' );
$statutsEtape = array( 'faite' => 'Faite', 'en_cours' => 'En cours', 'a_faire' => 'À faire', 'bloquee' => 'Bloquée' );
$titres = array( 'etat' => 'État de clôture', 'anomalies' => 'Rapport d\'anomalies', 'anouveaux' => 'État des à-nouveaux ' . ( $an + 1 ),
	'rapprochement' => 'Rapprochement ' . $an . ' / ' . ( $an + 1 ), 'fiscal' => 'Du résultat comptable au résultat fiscal', 'journal' => 'Journal de clôture' );
?><!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">
<title><?= e( $R['titre'] ) ?> <?= $an ?> — <?= e( $H['societe'] ) ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;color:#111;background:#f3f4f6;padding:18px;font-size:11.5px;line-height:1.4}
.sheet{background:#fff;max-width:900px;margin:0 auto 18px;padding:24px 30px;box-shadow:0 1px 6px rgba(0,0,0,.12);position:relative;z-index:1}
.hd{display:flex;justify-content:space-between;gap:16px;border-bottom:2px solid #16352B;padding-bottom:9px;margin-bottom:12px}
.hd h1{font-size:16px;color:#16352B}.hd .sub{font-size:10.5px;color:#555;margin-top:3px}
.hd .right{text-align:right;font-size:10.5px;color:#555}
h2{font-size:13px;color:#16352B;margin:0 0 8px;padding-bottom:4px;border-bottom:1px solid #d6dcd6}
h3{font-size:11.5px;background:#16352B;color:#fff;padding:5px 9px;margin:14px 0 0;border-radius:2px}
table{width:100%;border-collapse:collapse;margin-top:2px}
th,td{border:1px solid #cfd4cf;padding:3px 7px;text-align:left;vertical-align:top}
th{background:#eef2ee;font-size:9.5px;text-transform:uppercase;letter-spacing:.3px}
td.num,th.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.tot{background:#f0f3f0;font-weight:700}
.muted{color:#666}.small{font-size:10px}
.ok{color:#1e7a4a;font-weight:700}.ko{color:#b0342a;font-weight:700}.warn{color:#9a6400;font-weight:700}
.box{border:1px solid #cfd4cf;padding:8px 11px;margin:8px 0;border-radius:3px}
.box.alerte{border-color:#b0342a;background:#fdf2f0}
.box.bon{border-color:#1e7a4a;background:#f1faf4}
ul.causes{margin:3px 0 0 16px}
.sign{display:flex;gap:18px;margin-top:22px}.sign div{flex:1;border-top:1px solid #555;padding-top:4px;font-size:10px;color:#444;min-height:60px}
.filigrane{position:fixed;top:44%;left:0;right:0;text-align:center;font-size:72px;font-weight:900;letter-spacing:8px;
	color:rgba(176,52,42,.10);transform:rotate(-24deg);z-index:0;pointer-events:none}
.toolbar{max-width:900px;margin:0 auto 14px;display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}
.toolbar a,.toolbar button{background:#fff;color:#16352B;border:1px solid #16352B;padding:6px 11px;border-radius:5px;font-size:12px;text-decoration:none;cursor:pointer}
.toolbar button{background:#16352B;color:#fff}
.foot{margin-top:14px;font-size:9.5px;color:#777;text-align:center}
@media print{body{background:#fff;padding:0}.toolbar{display:none}.sheet{box-shadow:none;margin:0;max-width:none;padding:0 4mm;page-break-after:always}.sheet:last-of-type{page-break-after:auto}}
</style></head><body>
<div class="toolbar">
	<?php foreach ( $types as $k => $lib ) : ?>
		<a href="<?= e( url( 'comptabilite/cloture/imprimer?annee=' . $an . '&rapport=' . $k ) ) ?>"<?= $k === $R['type'] ? ' style="font-weight:700"' : '' ?>><?= e( $lib ) ?></a>
	<?php endforeach; ?>
	<button onclick="window.print()">🖨 Imprimer / PDF</button>
</div>
<?php if ( '' !== $H['mention'] ) : ?><div class="filigrane"><?= e( $H['mention'] ) ?></div><?php endif; ?>

<?php foreach ( $S as $code => $sec ) : ?>
<div class="sheet">
	<div class="hd">
		<div><h1><?= e( $H['societe'] ) ?></h1>
			<div class="sub"><?= $H['ncc'] ? 'NCC : ' . e( $H['ncc'] ) . ' · ' : '' ?><?= $H['ntd'] ? 'NTD : ' . e( $H['ntd'] ) . ' · ' : '' ?><?= e( $titres[ $code ] ?? $R['titre'] ) ?></div></div>
		<div class="right">Exercice <?= e( $H['libelle'] ) ?><br>du <?= e( date( 'd/m/Y', strtotime( $H['du'] ) ) ) ?> au <?= e( date( 'd/m/Y', strtotime( $H['au'] ) ) ) ?><br>
			<strong class="<?= $H['clos'] ? 'ok' : 'ko' ?>"><?= e( $H['statut'] ) ?></strong></div>
	</div>

	<?php if ( ! empty( $sec['erreur'] ) ) : ?>
		<div class="box alerte"><?= e( $sec['erreur'] ) ?></div>

	<?php elseif ( 'etat' === $code ) : $p = $sec['processus']; $sy = $sec['synthese']; ?>
		<h2>État de clôture — avancement <?= (int) $p['progression'] ?> % (<?= (int) $p['faites'] ?>/<?= (int) $p['total'] ?> étapes)</h2>
		<table><thead><tr><th style="width:26px">#</th><th>Étape</th><th style="width:80px">Statut</th><th>Constat / validation</th></tr></thead><tbody>
		<?php foreach ( $p['etapes'] as $e ) : ?>
			<tr><td><?= (int) $e['ordre'] ?></td><td><strong><?= e( $e['libelle'] ) ?></strong></td>
			<td class="<?= 'faite' === $e['statut'] ? 'ok' : ( 'bloquee' === $e['statut'] ? 'ko' : 'warn' ) ?>"><?= e( $statutsEtape[ $e['statut'] ] ?? $e['statut'] ) ?></td>
			<td class="small"><?= e( trim( $e['valide_texte'] . ( $e['manque'] ? ' ' . $e['manque'] : '' ) ) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>

		<h3>Contrôles de clôture</h3>
		<table><tbody>
			<tr><td>Contrôles évalués</td><td class="num"><?= (int) $sy['total'] ?></td><td>Anomalies constatées</td><td class="num"><?= (int) $sy['anomalies'] ?></td></tr>
			<tr><td>Bloquants non levés</td><td class="num <?= $sy['bloquants'] ? 'ko' : 'ok' ?>"><?= (int) $sy['bloquants'] ?></td><td>Dérogations accordées</td><td class="num"><?= (int) $sy['derogations'] ?></td></tr>
			<tr><td>Avertissements</td><td class="num"><?= (int) $sy['avertissements'] ?></td><td>dont justifiés</td><td class="num"><?= (int) $sy['avertissements_justifies'] ?></td></tr>
		</tbody></table>
		<?php if ( $sy['libelles_bloquants'] ) : ?><div class="box alerte"><strong>La clôture est refusée par :</strong><ul class="causes"><?php foreach ( $sy['libelles_bloquants'] as $l ) : ?><li><?= e( $l ) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

		<h3>Résultat de l'exercice</h3>
		<table><tbody>
			<tr><td>Solde des comptes de gestion (produits − charges)</td><td class="num"><?= $m( $sec['solde_gestion'] ) ?></td></tr>
			<tr class="tot"><td>Résultat net <?= $sec['determine'] ? 'déterminé (13x)' : '— non encore déterminé' ?></td><td class="num"><?= $m( $sec['resultat_net'] ) ?></td></tr>
		</tbody></table>
		<?php if ( $sec['fiscal'] ) : $t = $sec['fiscal']; ?>
			<table style="margin-top:6px"><tbody>
				<tr><td>Résultat fiscal (après <?= $m( $t['reintegrations'] ) ?> de réintégrations et <?= $m( $t['deductions'] ) ?> de déductions)</td><td class="num"><?= $m( $t['resultat_fiscal'] ) ?></td></tr>
				<tr><td>Base imposable après imputation des déficits</td><td class="num"><?= $m( $t['base_imposable'] ) ?></td></tr>
				<tr class="tot"><td>Impôt dû <?= $t['impot']['label'] ? '(' . e( $t['impot']['label'] ) . ')' : '' ?></td><td class="num"><?= $m( $t['impot']['du'] ) ?></td></tr>
			</tbody></table>
		<?php endif; ?>

		<h3>Affectation du résultat</h3>
		<?php if ( $sec['affectation'] ) : $a = $sec['affectation']; ?>
			<p style="margin:5px 0">Décision du <?= e( date( 'd/m/Y', strtotime( $a['date_decision'] ) ) ) ?><?= $a['reference_pv'] ? ' — PV ' . e( $a['reference_pv'] ) : '' ?>, sur un <?= 'perte' === $a['sens'] ? 'déficit' : 'bénéfice' ?> de <?= $m( $a['resultat_net'] ) ?> F CFA.</p>
			<table><thead><tr><th>Compte</th><th>Affectation</th><th class="num">Montant</th></tr></thead><tbody>
			<?php foreach ( $a['lignes'] as $l ) : ?><tr><td><?= e( $l['compte_numero'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="num"><?= $m( $l['montant'] ) ?></td></tr><?php endforeach; ?>
			</tbody></table>
		<?php else : ?><p class="muted" style="margin-top:5px">Aucune affectation enregistrée : elle suit la décision de l'assemblée qui approuve les comptes.</p><?php endif; ?>

		<?php if ( $sec['inventaire'] && $sec['inventaire']['domaines'] ) : ?>
			<h3>Travaux d'inventaire</h3>
			<table><thead><tr><th>Domaine</th><th style="width:90px">Statut</th><th class="num">Anomalies</th><th class="num">Bloquants</th></tr></thead><tbody>
			<?php foreach ( $sec['inventaire']['domaines'] as $d ) : ?>
				<tr><td><?= e( $d['libelle'] ) ?></td><td class="<?= $d['bloquants'] ? 'ko' : ( $d['anomalies'] ? 'warn' : 'ok' ) ?>"><?= $d['bloquants'] ? 'À faire' : ( $d['anomalies'] ? 'Attention' : 'Fait' ) ?></td>
				<td class="num"><?= (int) $d['anomalies'] ?></td><td class="num"><?= (int) $d['bloquants'] ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>

		<?php if ( $sec['regularisations'] && ( $sec['regularisations']['passees'] + $sec['regularisations']['saisies'] + $sec['regularisations']['extournees'] ) ) : $rg = $sec['regularisations']; ?>
			<h3>Rattachements de fin d'exercice</h3>
			<table><thead><tr><th>Nature</th><th class="num">Nombre</th><th class="num">Montant HT</th></tr></thead><tbody>
			<?php foreach ( $rg['par_nature'] as $n ) : if ( ! $n['nb'] ) { continue; } ?><tr><td><?= e( $n['label'] ) ?></td><td class="num"><?= (int) $n['nb'] ?></td><td class="num"><?= $m( $n['montant'] ) ?></td></tr><?php endforeach; ?>
			<tr class="tot"><td>Passés / saisis non passés / extournés</td><td class="num" colspan="2"><?= (int) $rg['passees'] ?> / <?= (int) $rg['saisies'] ?> / <?= (int) $rg['extournees'] ?></td></tr>
			</tbody></table>
		<?php endif; ?>

		<?php if ( $sec['suggestions'] ) : ?>
			<h3>Régularisations suggérées et non traitées</h3>
			<table><thead><tr><th>Origine</th><th>Suggestion</th><th class="num">Montant</th></tr></thead><tbody>
			<?php foreach ( $sec['suggestions'] as $s ) : ?><tr><td><?= e( $s['nature'] ) ?></td><td><strong><?= e( $s['libelle'] ) ?></strong><div class="small muted"><?= e( $s['note'] ) ?></div></td><td class="num"><?= $m( $s['montant'] ) ?></td></tr><?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>

		<h3>Ouverture de l'exercice <?= $an + 1 ?></h3>
		<p style="margin-top:5px"><?= $sec['anouveaux'] ? '<span class="' . ( $sec['anouveaux']['concordant'] ? 'ok' : 'ko' ) . '">' . e( $sec['anouveaux']['message'] ) . '</span>' : '<span class="muted">À-nouveaux non encore générés.</span>' ?></p>

		<div class="sign"><div>Établi par</div><div>Vérifié par (expert-comptable)</div><div>Approuvé par (dirigeant)</div></div>

	<?php elseif ( 'anomalies' === $code ) : $c = $sec['compte']; ?>
		<h2>Rapport d'anomalies — <?= count( $sec['lignes'] ) ?> constat(s)</h2>
		<p>Bloquants non levés : <strong class="<?= $c['bloquant'] ? 'ko' : 'ok' ?>"><?= (int) $c['bloquant'] ?></strong> ·
			Justifiés ou dérogés : <strong><?= (int) $c['couverts'] ?></strong> · Sans justification : <strong class="<?= $c['non_couverts'] ? 'warn' : 'ok' ?>"><?= (int) $c['non_couverts'] ?></strong></p>
		<?php if ( ! $sec['lignes'] ) : ?><div class="box bon">Aucune anomalie : tous les contrôles de clôture de <?= $an ?> et d'ouverture de <?= $an + 1 ?> sont conformes.</div><?php endif; ?>
		<?php foreach ( $sec['lignes'] as $l ) : ?>
			<div class="box <?= $l['bloque'] ? 'alerte' : '' ?>">
				<div style="display:flex;justify-content:space-between;gap:10px"><strong><?= e( $l['libelle'] ) ?></strong>
					<span class="<?= $l['bloque'] ? 'ko' : ( $l['couvert'] ? 'ok' : 'warn' ) ?>"><?= e( $niveaux[ $l['niveau'] ] ?? $l['niveau'] ) ?> · <?= e( $l['categorie_libelle'] ) ?> · <?= e( $l['phase_libelle'] ) ?></span></div>
				<div class="small muted"><?= e( $l['note'] ) ?></div>
				<div style="margin-top:3px">Constat : <?= (int) $l['nb'] ?> élément(s)<?= null !== $l['montant'] ? ' — ' . $m( $l['montant'] ) . ' F CFA' : '' ?><?= $l['panne'] ? ' <span class="ko">(contrôle non évaluable)</span>' : '' ?></div>
				<?php if ( $l['detail'] ) : ?><ul class="causes small"><?php foreach ( array_slice( $l['detail'], 0, 12 ) as $d ) : ?><li><?= e( is_scalar( $d ) ? (string) $d : json_encode( $d, JSON_UNESCAPED_UNICODE ) ) ?></li><?php endforeach; ?><?= count( $l['detail'] ) > 12 ? '<li>… ' . ( count( $l['detail'] ) - 12 ) . ' autre(s)</li>' : '' ?></ul><?php endif; ?>
				<?php $j = $l['justification']; if ( $j ) : ?>
					<div style="margin-top:4px" class="<?= $l['couvert'] ? '' : 'ko' ?>"><strong><?= 'derogation' === $j['nature'] ? 'Dérogation' : 'Justification' ?></strong>
						de <?= e( $j['par_nom'] ?: '—' ) ?> le <?= e( date( 'd/m/Y H:i', strtotime( (string) $j['le'] ) ) ) ?> : « <?= e( $j['motif'] ) ?> »
						<?= $l['couvert'] ? '' : ' — PÉRIMÉE : le constat a changé depuis.' ?></div>
				<?php elseif ( 'information' !== $l['niveau'] ) : ?><div class="warn small" style="margin-top:3px">Sans justification.</div><?php endif; ?>
			</div>
		<?php endforeach; ?>

	<?php elseif ( 'anouveaux' === $code ) : ?>
		<h2>État des à-nouveaux — ouverture de l'exercice <?= (int) $sec['aOuvrir'] ?></h2>
		<?php if ( ! $sec['genere'] ) : ?><div class="box alerte"><strong>PROJET — non généré.</strong> Soldes qui seraient repris si les à-nouveaux étaient générés aujourd'hui.<?= $sec['message'] ? ' ' . e( $sec['message'] ) : '' ?></div>
		<?php else : ?><p class="small muted">Écriture(s) : <?php foreach ( $sec['ecritures'] as $e ) { echo 'n° ' . (int) $e['id'] . ' du ' . e( date( 'd/m/Y', strtotime( $e['date_ecriture'] ) ) ) . ' ; '; } ?></p><?php endif; ?>
		<table><thead><tr><th style="width:70px">Compte</th><th>Intitulé</th><th>Tiers</th><th class="num">Débit</th><th class="num">Crédit</th></tr></thead><tbody>
		<?php foreach ( $sec['lignes'] as $l ) : ?>
			<tr><td><?= e( $l['numero'] ) ?></td><td><?= e( $l['compte_libelle'] ) ?></td><td class="small"><?= ! empty( $l['tiers_id'] ) ? e( ( $l['tiers_type'] ?: 'tiers' ) . ' #' . (int) $l['tiers_id'] ) : '' ?></td>
			<td class="num"><?= $l['debit'] ? $m( $l['debit'] ) : '' ?></td><td class="num"><?= $l['credit'] ? $m( $l['credit'] ) : '' ?></td></tr>
		<?php endforeach; ?>
		<tr class="tot"><td colspan="3">Totaux — <?= $sec['equilibre'] ? '<span class="ok">équilibrés</span>' : '<span class="ko">DÉSÉQUILIBRÉS</span>' ?></td><td class="num"><?= $m( $sec['total_debit'] ) ?></td><td class="num"><?= $m( $sec['total_credit'] ) ?></td></tr>
		</tbody></table>

	<?php elseif ( 'rapprochement' === $code ) : $rp = $sec['rapprochement']; ?>
		<h2>Rapprochement des soldes de clôture <?= $an ?> et d'ouverture <?= $an + 1 ?></h2>
		<?php if ( ! $sec['genere'] ) : ?><div class="box"><?= e( $sec['synthese'] ) ?></div>
		<?php else : ?>
			<div class="box <?= $sec['lignes'] ? 'alerte' : 'bon' ?>"><strong><?= e( $sec['synthese'] ) ?></strong>
				<div class="small muted">Comparaison compte par compte des classes 1 à 5 : solde de l'exercice <?= $an ?> pris sur sa période, contre l'écriture d'à-nouveaux de <?= $an + 1 ?>. Une liste d'écarts vide est la preuve de continuité du bilan.</div></div>
			<?php if ( $sec['lignes'] ) : ?>
				<table><thead><tr><th>Compte</th><th class="num">Clôture <?= $an ?></th><th class="num">Ouverture <?= $an + 1 ?></th><th class="num">Écart</th><th>Cause identifiée et geste</th></tr></thead><tbody>
				<?php foreach ( $sec['lignes'] as $l ) : ?>
					<tr><td><strong><?= e( $l['numero'] ) ?></strong><div class="small"><?= e( $l['libelle'] ) ?></div></td>
					<td class="num"><?= $m( $l['cloture'] ) ?></td><td class="num"><?= $m( $l['ouverture'] ) ?></td><td class="num ko"><?= $m( $l['ecart'] ) ?></td>
					<td class="small"><ul class="causes"><?php foreach ( $l['causes'] as $c ) : ?><li><?= e( $c ) ?></li><?php endforeach; ?></ul><div style="margin-top:3px"><strong>→</strong> <?= e( $l['geste'] ) ?></div></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			<?php endif; ?>
			<?php if ( ! empty( $rp['affectation'] ) ) : ?>
				<h3>Mouvements réguliers dus à l'affectation du résultat</h3>
				<table><thead><tr><th>Compte</th><th class="num">Clôture</th><th class="num">Ouverture</th><th class="num">Écart</th></tr></thead><tbody>
				<?php foreach ( $rp['affectation'] as $l ) : ?><tr><td><?= e( $l['numero'] . ' ' . $l['libelle'] ) ?></td><td class="num"><?= $m( $l['cloture'] ) ?></td><td class="num"><?= $m( $l['ouverture'] ) ?></td><td class="num"><?= $m( $l['ecart'] ) ?></td></tr><?php endforeach; ?>
				</tbody></table>
			<?php endif; ?>
			<p class="small muted" style="margin-top:6px"><?= (int) ( $rp['nb_comptes'] ?? 0 ) ?> compte(s) comparé(s).</p>
		<?php endif; ?>

	<?php elseif ( 'fiscal' === $code ) : $t = $sec['tableau']; $imp = $sec['impot']; ?>
		<h2>Tableau de passage — résultat comptable → résultat fiscal</h2>
		<?php if ( ! $sec['termine'] ) : ?><div class="box alerte">L'exercice n'est pas terminé : le tableau de passage ne vaut que pour un exercice entier.</div><?php endif; ?>
		<table><tbody>
			<tr class="tot"><td>Résultat comptable</td><td class="num"><?= $m( $t['resultat_comptable'] ) ?></td></tr>
			<?php foreach ( $t['lignes'] as $l ) : ?>
				<tr><td style="padding-left:18px"><?= 'deduction' === $l['sens'] ? '− ' : '+ ' ?><?= e( $l['libelle'] ?: ( $sec['natures'][ $l['nature'] ]['libelle'] ?? $l['nature'] ) ) ?>
					<?php if ( ! empty( $l['justification'] ) ) : ?><div class="small muted"><?= e( $l['justification'] ) ?></div><?php endif; ?></td>
				<td class="num"><?= ( 'deduction' === $l['sens'] ? '−' : '' ) . $m( $l['montant'] ) ?></td></tr>
			<?php endforeach; ?>
			<tr><td>Total des réintégrations</td><td class="num"><?= $m( $t['reintegrations'] ) ?></td></tr>
			<tr><td>Total des déductions</td><td class="num">−<?= $m( $t['deductions'] ) ?></td></tr>
			<tr class="tot"><td>Résultat fiscal</td><td class="num"><?= $m( $t['resultat_fiscal'] ) ?></td></tr>
			<tr><td>Déficits antérieurs imputés (reportables : <?= $m( $t['deficits']['total'] ?? 0 ) ?>)</td><td class="num">−<?= $m( $t['deficits_imputes'] ) ?></td></tr>
			<tr class="tot"><td>Base imposable</td><td class="num"><?= $m( $t['base_imposable'] ) ?></td></tr>
			<?php if ( $t['deficit_genere'] ) : ?><tr><td>Déficit de l'exercice, reportable</td><td class="num"><?= $m( $t['deficit_genere'] ) ?></td></tr><?php endif; ?>
			<tr><td>BIC / IS au taux normal</td><td class="num"><?= $m( $t['impot']['bic_normal'] ) ?></td></tr>
			<tr><td>Impôt minimum forfaitaire</td><td class="num"><?= $m( $t['impot']['imf'] ) ?></td></tr>
			<tr class="tot"><td>Impôt dû <?= $t['impot']['label'] ? '(' . e( $t['impot']['label'] ) . ')' : '' ?></td><td class="num"><?= $m( $t['impot']['du'] ) ?></td></tr>
		</tbody></table>
		<p class="small <?= $t['fige'] ? 'ok' : 'warn' ?>" style="margin-top:4px"><?= $t['fige'] ? 'Résultat fiscal arrêté : ses déficits sont opposables.' : 'Résultat fiscal NON arrêté : un déficit de cet exercice ne serait pas reportable.' ?></p>

		<?php if ( $imp['applicable'] ) : $cf = $imp['confrontation']; ?>
			<h3>Impôt calculé et impôt comptabilisé</h3>
			<table><tbody>
				<tr><td>Impôt calculé</td><td class="num"><?= $m( $cf['calcule'] ) ?></td></tr>
				<tr><td>Impôt comptabilisé (classe 89)</td><td class="num"><?= $m( $cf['comptabilise'] ) ?></td></tr>
				<tr class="tot"><td>Écart</td><td class="num <?= abs( $cf['ecart'] ) >= 1 ? 'ko' : 'ok' ?>"><?= $m( $cf['ecart'] ) ?></td></tr>
			</tbody></table>
			<?php if ( $imp['causes'] ) : ?><div class="box alerte"><strong><?= e( $cf['message'] ) ?></strong><ul class="causes"><?php foreach ( $imp['causes'] as $c ) : ?><li><?= e( $c ) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
			<?php if ( $imp['ecritures'] ) : ?><table style="margin-top:4px"><thead><tr><th>Écriture</th><th>Libellé</th><th>Compte</th><th class="num">Montant</th></tr></thead><tbody>
				<?php foreach ( $imp['ecritures'] as $e ) : ?><tr><td>n° <?= (int) $e['id'] ?> du <?= e( date( 'd/m/Y', strtotime( $e['date_ecriture'] ) ) ) ?></td><td><?= e( $e['libelle'] ) ?></td><td><?= e( $e['numero'] ) ?></td><td class="num"><?= $m( $e['montant'] ) ?></td></tr><?php endforeach; ?>
			</tbody></table><?php endif; ?>
		<?php endif; ?>

		<?php if ( ! empty( $sec['acomptes'] ) && $sec['acomptes']['liste'] ) : $ac = $sec['acomptes']; ?>
			<h3>Acomptes d'impôt sur le résultat</h3>
			<table><thead><tr><th>N°</th><th>Échéance</th><th class="num">Montant</th><th>Statut</th><th>Versé le</th></tr></thead><tbody>
			<?php foreach ( $ac['liste'] as $a ) : ?><tr><td><?= (int) $a['rang'] ?></td><td><?= e( date( 'd/m/Y', strtotime( $a['echeance'] ) ) ) ?></td><td class="num"><?= $m( $a['montant'] ) ?></td><td><?= e( $ac['statuts'][ $a['statut'] ] ?? $a['statut'] ) ?></td><td><?= $a['date_paiement'] ? e( date( 'd/m/Y', strtotime( $a['date_paiement'] ) ) ) : '' ?></td></tr><?php endforeach; ?>
			<tr class="tot"><td colspan="2">Versés / imputés sur la dette</td><td class="num"><?= $m( $ac['totaux']['paye'] ) ?></td><td colspan="2"><?= $m( $ac['totaux']['impute'] ) ?> imputés</td></tr>
			</tbody></table>
		<?php endif; ?>

		<?php if ( ! empty( $sec['tva'] ) && $sec['tva']['applicable'] && $sec['tva']['mois'] ) : $tv = $sec['tva']; ?>
			<h3>TVA collectée : grand livre et déclarations</h3>
			<div class="box <?= $tv['nb_anomalies'] ? 'alerte' : 'bon' ?>"><strong><?= e( $tv['message'] ) ?></strong></div>
			<table><thead><tr><th>Mois</th><th class="num">Grand livre</th><th class="num">Déclarée</th><th class="num">Écart</th><th>Cause</th></tr></thead><tbody>
			<?php foreach ( $tv['mois'] as $x ) : ?><tr><td><?= e( $x['periode'] ) ?></td><td class="num"><?= $m( $x['gl'] ) ?></td><td class="num"><?= $m( $x['declare'] ) ?></td><td class="num <?= $x['anomalie'] ? 'ko' : '' ?>"><?= $m( $x['ecart'] ) ?></td><td class="small"><?= e( implode( ' ', $x['causes'] ) ) ?></td></tr><?php endforeach; ?>
			<tr class="tot"><td>Total</td><td class="num"><?= $m( $tv['total_gl'] ) ?></td><td class="num"><?= $m( $tv['total_declare'] ) ?></td><td class="num"><?= $m( $tv['total_ecart'] ) ?></td><td></td></tr>
			</tbody></table>
		<?php endif; ?>

		<?php if ( ! empty( $sec['releve'] ) && $sec['releve']['lignes'] ) : $rv = $sec['releve']; ?>
			<h3>Relevé des provisions pour dépréciation de créances (pièce annexe)</h3>
			<table><thead><tr><th>Client</th><th>Nature</th><th class="num">Créance HT</th><th class="num">Taux</th><th class="num">Dotation</th><th class="num">Réintégrée</th><th class="num">Reprise</th><th class="num">Justif.</th></tr></thead><tbody>
			<?php foreach ( $rv['lignes'] as $l ) : ?>
				<tr><td><?= e( (string) $l['client'] ) ?></td><td><?= e( (string) $l['nature'] ) ?></td><td class="num"><?= $m( $l['montant_ht'] ) ?></td><td class="num"><?= e( (string) $l['taux'] ) ?> %</td>
				<td class="num"><?= $m( $l['dotation'] ) ?></td><td class="num"><?= $m( $l['reintegration'] ) ?></td><td class="num"><?= $m( $l['reprise'] ) ?></td><td class="num <?= $l['justificatifs'] ? '' : 'ko' ?>"><?= (int) $l['justificatifs'] ?></td></tr>
			<?php endforeach; ?>
			<tr class="tot"><td colspan="4">Totaux — déductible <?= $m( $rv['total_deductible'] ) ?></td><td class="num"><?= $m( $rv['total_dotation'] ) ?></td><td class="num"><?= $m( $rv['total_reintegration'] ) ?></td><td class="num"><?= $m( $rv['total_reprise'] ) ?></td><td class="num"><?= (int) $rv['sans_justificatif'] ?> sans</td></tr>
			</tbody></table>
		<?php endif; ?>

	<?php elseif ( 'journal' === $code ) : ?>
		<h2>Journal de clôture — registre des gestes</h2>
		<table><thead><tr><th style="width:105px">Date</th><th>Opération</th><th>Issue</th><th>Libellé et motif</th><th>Par</th></tr></thead><tbody>
		<?php foreach ( $sec['lignes'] as $j ) : ?>
			<tr><td class="small"><?= e( date( 'd/m/Y H:i', strtotime( (string) $j['date_op'] ) ) ) ?></td><td><?= e( $sec['operations'][ $j['operation'] ] ?? $j['operation'] ) ?></td>
			<td class="<?= 'refus' === $j['issue'] ? 'ko' : ( 'ok' === $j['issue'] ? 'ok' : 'warn' ) ?>"><?= e( $j['issue'] ) ?></td>
			<td class="small"><?= e( $j['libelle'] ) ?><?= ! empty( $j['motif'] ) ? '<div><em>Motif : ' . e( $j['motif'] ) . '</em></div>' : '' ?></td><td class="small"><?= e( (string) $j['acteur_nom'] ) ?></td></tr>
		<?php endforeach; ?>
		<?php if ( ! $sec['lignes'] ) : ?><tr><td colspan="5" class="muted">Aucune opération consignée pour cet exercice.</td></tr><?php endif; ?>
		</tbody></table>
	<?php endif; ?>

	<div class="foot">FinaKop ERP — <?= e( $titres[ $code ] ?? $R['titre'] ) ?> — édité le <?= e( $H['edite_le'] ) ?><?= $H['edite_par'] ? ' par ' . e( $H['edite_par'] ) : '' ?><?= '' !== $H['mention'] ? ' — DOCUMENT ' . e( $H['mention'] ) : '' ?> — montants en F CFA</div>
</div>
<?php endforeach; ?>
</body></html>
