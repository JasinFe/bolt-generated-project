<?php /** @var array $colonnes @var array $modele @var bool $brouillardOn @var array|null $resultat @var array $errors @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$errors = $errors ?? array(); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( is_array( $flash ) ? ( $flash['msg'] ?? '' ) : $flash ) ?></div><?php endif; ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>

<?php if ( $resultat ) : ?>
	<div class="alert alert-<?= $resultat['ok'] > 0 && 0 === $resultat['ignores'] ? 'ok' : ( 0 === $resultat['ok'] ? 'err' : 'warn' ) ?>">
		<strong><?= (int) $resultat['ok'] ?></strong> écriture(s) importée(s) sur <?= (int) $resultat['total'] ?><?= $resultat['ignores'] ? ' · ' . (int) $resultat['ignores'] . ' rejetée(s)' : '' ?>.
	</div>
	<?php if ( ! empty( $resultat['messages'] ) ) : ?>
	<div class="card"><div class="card-head"><h2>Détail de l'import</h2>
		<?php if ( ! empty( $resultat['numeros'] ) ) : ?>
			<span class="muted" style="margin-left:auto">numéros attribués : <?= e( implode( ', ', array_slice( $resultat['numeros'], 0, 6 ) ) ) ?><?= count( $resultat['numeros'] ) > 6 ? '…' : '' ?></span>
		<?php endif; ?>
	</div><div class="card-body">
		<ul style="margin:0;padding-left:18px">
			<?php foreach ( $resultat['messages'] as $m ) : ?><li class="muted" style="margin:4px 0"><?= e( $m ) ?></li><?php endforeach; ?>
		</ul>
	</div></div>
	<?php endif; ?>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Importer des écritures</h2>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/ecritures/import/modele' ) ) ?>">⬇ Télécharger le modèle (CSV)</a>
	</div>
	<div class="card-body">
		<div class="alert alert-info" style="margin-top:0">
			<strong>Deux numérotations à ne pas confondre.</strong>
			La colonne <strong>piece</strong> est la référence de votre <em>justificatif</em> — numéro de facture
			fournisseur, de reçu, de bordereau : c'est vous qui la saisissez, elle vient de l'extérieur.
			Le <strong>numéro d'écriture</strong> (<code>AAnnnnnn</code>, ex. <code>26000001</code>) est attribué par
			l'application, séquentiellement, <strong>par journal et par exercice</strong> :
			<code>AC-26000001</code> et <code>OD-26000001</code> coexistent, chaque journal ayant sa propre suite.
			Il n'est ni demandé dans le fichier, ni modifiable — la suite doit rester continue.
			<br>Les écritures sont numérotées <strong>dans l'ordre des dates</strong>, quel que soit l'ordre des lignes
			de votre fichier.
		</div>
		<p class="help" style="margin-top:0">Renseignez le modèle CSV, puis déposez-le ici. <strong>Une ligne du fichier = une ligne d'écriture</strong>. Regroupement en une même écriture : les lignes partageant la même <em>date + journal + pièce</em> ; <strong>ou</strong>, si la pièce est laissée vide, la même <em>date + journal + libellé</em> — le numéro de pièce est alors <strong>généré automatiquement</strong> par journal, dans l'ordre chronologique (ex. <em>OD-2026-001</em>). Chaque écriture doit être <strong>équilibrée</strong> (total débit = total crédit) et les comptes doivent exister dans le plan comptable.</p>
		<p class="help">Format des dates : <code>AAAA-MM-JJ</code> (recommandé), mais <code>JJ/MM/AAAA</code>, <code>JJ-MM-AAAA</code> et <code>JJ.MM.AAAA</code> sont acceptés — Excel réécrit les dates au format local dès la première ouverture du modèle, et le fichier reste importable. Une date ambiguë comme <code>03/04/2025</code> est lue <strong>jour/mois</strong> : 3 avril.</p>
		<form method="post" action="<?= e( url( 'comptabilite/ecritures/import' ) ) ?>" enctype="multipart/form-data" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0"><span>Fichier CSV</span>
				<input type="file" name="fichier" accept=".csv,text/csv,text/plain" required></label>
			<label class="fld-check" style="margin:0">
				<input type="checkbox" name="brouillard" value="1" <?= $brouillardOn ? 'checked' : '' ?>>
				<span>Déposer au brouillard (vérification avant comptabilisation)</span></label>
			<button class="btn btn-primary" type="submit">Importer</button>
		</form>
	</div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Format attendu</h2></div>
	<table class="table">
		<thead><tr><?php foreach ( $colonnes as $c ) : ?><th><?= e( $c ) ?></th><?php endforeach; ?></tr></thead>
		<tbody>
		<?php foreach ( array_slice( $modele, 1 ) as $row ) : ?>
			<tr><?php foreach ( $row as $cell ) : ?><td class="code"><?= e( $cell ) ?></td><?php endforeach; ?></tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
<p class="help">Colonnes : <strong>date</strong> (AAAA-MM-JJ), <strong>journal</strong> (code : AC, VE, BQ, CA, OD, AN…), <strong>piece</strong> (référence de votre justificatif ; regroupe les lignes d'une même écriture ; laissez vide pour un regroupement par libellé et une référence générée), <strong>libelle</strong> (de l'écriture), <strong>compte</strong> (n° du plan, ex. 601000), <strong>libelle_ligne</strong> (facultatif), <strong>debit</strong>, <strong>credit</strong>, <strong>axe</strong> et <strong>valeur</strong> (imputation analytique facultative, par leurs <em>codes</em> — ex. axe « PROJ », valeur « ALBUM-X » ; renseignez les deux ou laissez vides). Séparateur « ; ». <strong>N'ajoutez pas de colonne « numéro »</strong> : le numéro d'écriture est attribué par l'application à la comptabilisation.</p>
