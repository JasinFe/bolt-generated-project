<?php /** @var array $ecriture @var string $tab @var array $analyse @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$e = $ecriture; $td=0;$tc=0; foreach($e['lignes'] as $l){$td+=(float)$l['debit'];$tc+=(float)$l['credit'];}
$an = isset( $analyse ) && is_array( $analyse ) ? $analyse : null;
$estAnnulation = class_exists( 'FKC_EcritureNumero' )
	&& FKC_EcritureNumero::TYPE_ANNULATION === (string) ( $e['type_ecriture'] ?? 'normale' ); ?>
<?php if ( ! empty( $flash ) ) :
	$fType = is_array( $flash ) ? ( $flash['type'] ?? 'ok' ) : 'ok';
	$fMsg  = is_array( $flash ) ? ( $flash['msg'] ?? '' ) : (string) $flash; ?>
	<div class="alert alert-<?= 'err' === $fType ? 'err' : 'ok' ?>"><?= e( $fMsg ) ?></div>
<?php endif; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<div class="card" style="max-width:860px">
	<div class="card-head">
		<h2><?php if ( ! empty( $e['numero'] ) ) : ?>
			Écriture <span class="code"><?= e( $e['journal_code'] ) ?>-<?= e( $e['numero'] ) ?></span>
		<?php else : ?>
			Écriture n°<?= (int) $e['id'] ?> · <span class="code"><?= e( $e['journal_code'] ) ?></span>
		<?php endif; ?></h2>
		<div style="display:flex;gap:8px">
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/ecritures/' . (int) $e['id'] . '/trace' ) ) ?>">Provenance</a>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/ecritures' ) ) ?>">← Retour</a>
		</div>
	</div>
	<div class="card-body">
		<div class="meta">
			<div><span class="stat-label">N° d'écriture</span><strong><?= ! empty( $e['numero'] ) ? e( $e['journal_code'] . '-' . $e['numero'] ) : '<span class="muted">non numérotée</span>' ?></strong></div>
			<div><span class="stat-label">Date</span><strong><?= e( date( 'd/m/Y', strtotime( $e['date_ecriture'] ) ) ) ?></strong></div>
			<div><span class="stat-label">Journal</span><strong><?= e( $e['journal_libelle'] ) ?></strong></div>
			<div><span class="stat-label">Pièce</span><strong><?= e( $e['piece'] ?: '—' ) ?></strong></div>
			<div><span class="stat-label">Référence</span><strong><?= e( $e['reference'] ?: '—' ) ?></strong></div>
		</div>
		<p><strong>Libellé :</strong> <?= e( $e['libelle'] ) ?></p>
		<table class="table bordered">
			<thead><tr><th>Compte</th><th>Intitulé</th><th>Libellé ligne</th><th class="num">Débit</th><th class="num">Crédit</th></tr></thead>
			<tbody>
			<?php foreach ( $e['lignes'] as $l ) : ?>
				<tr>
					<td><span class="code"><?= e( $l['compte_numero'] ) ?></span></td>
					<td class="muted"><?= e( $l['compte_libelle'] ) ?></td>
					<td><?= e( $l['libelle'] ) ?></td>
					<td class="num"><?= (float) $l['debit'] ? e( fkc_money( $l['debit'] ) ) : '' ?></td>
					<td class="num"><?= (float) $l['credit'] ? e( fkc_money( $l['credit'] ) ) : '' ?></td>
				</tr>
			<?php endforeach; ?>
			<tr class="total"><td colspan="3" class="right">Totaux</td><td class="num"><?= e( fkc_money( $td ) ) ?></td><td class="num"><?= e( fkc_money( $tc ) ) ?></td></tr>
			</tbody>
		</table>
	</div>
</div>

<?php FKC_View::partial( 'comptabilite::_pieces', array(
	'pieces'       => $pieces ?? array(),
	'piecesUpload' => 'comptabilite/ecritures/' . (int) $e['id'] . '/pieces',
	'piecesBase'   => 'comptabilite/ecritures/piece',
) ); ?>

<?php
/* ── Annuler cette écriture ───────────────────────────────────────────────
   L'annulation n'était accessible que depuis Paramètres → Maintenance : pour
   annuler l'écriture qu'on avait sous les yeux, il fallait quitter la
   comptabilité, retrouver un écran d'administration et l'y rechercher.

   La contre-passation reprend le NUMÉRO de l'écriture annulée : ce n'est pas
   une opération nouvelle, c'est l'annulation de celle-là. Le journal montre
   donc deux fois le même numéro, une fois à l'endroit et une fois à l'envers. */
?>
<?php if ( $an ) : ?>
<div class="card">
	<div class="card-head"><h2><?= $estAnnulation ? '↩ Écriture d\'annulation' : '🚫 Annuler cette écriture' ?></h2></div>
	<div class="card-body">

		<?php if ( $estAnnulation ) : ?>
			<p class="help" style="margin-top:0">
				Cette écriture <strong>annule</strong> l'écriture <span class="code"><?= e( $e['journal_code'] . '-' . $e['numero'] ) ?></span>
				dont elle porte le numéro. Si elle a été passée par erreur, vous pouvez revenir en arrière :
				elle sera supprimée et l'écriture d'origine redeviendra en vigueur, avec ses pièces rebranchées.
			</p>
			<form method="post" action="<?= e( url( 'comptabilite/ecritures/' . (int) $e['id'] . '/reactiver' ) ) ?>"
				onsubmit="return confirm('Revenir sur cette annulation ?\n\nL\'écriture d\'origine redeviendra en vigueur.')">
				<?= FKC_Csrf::field() ?>
				<button class="btn btn-primary btn-sm">↩ Revenir sur cette annulation</button>
			</form>

		<?php elseif ( null !== $an['deja_annulee'] ) : ?>
			<div class="alert alert-warn" style="margin-top:0">
				Cette écriture a déjà été annulée par une contre-passation (écriture n°<?= (int) $an['deja_annulee'] ?>,
				même numéro <span class="code"><?= e( $e['numero'] ?: '—' ) ?></span>). Elle ne peut pas l'être deux fois.
			</div>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/ecritures/' . (int) $an['deja_annulee'] ) ) ?>">Voir l'annulation →</a>

		<?php else : ?>
			<p class="help" style="margin-top:0">
				Une écriture comptabilisée ne se modifie pas : l'article 20 de l'Acte uniforme l'interdit.
				Elle s'annule par <strong>contre-passation</strong> — une écriture inverse, portant le
				<strong>même numéro</strong>, qui neutralise ses effets sans effacer sa trace.
			</p>

			<?php if ( ! empty( $an['dependances'] ) ) : ?>
				<div class="alert alert-warn">
					<strong>Ce que l'annulation va délier :</strong>
					<ul style="margin:6px 0 0;padding-left:18px">
					<?php foreach ( $an['dependances'] as $d ) : ?>
						<li><?= (int) $d['nombre'] ?> <?= e( $d['libelle'] ) ?><?= 'supprimer' === ( $d['action'] ?? '' ) ? ' — <em>retirée·s</em>' : ' — remise·s à comptabiliser' ?></li>
					<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( empty( $an['contrepassable'] ) ) : ?>
				<div class="alert alert-err">
					Contre-passation impossible.
					<?php if ( ! empty( $an['verrou'] ) ) : ?>
						Cette écriture matérialise une clôture de période : la contre-passer reviendrait à rouvrir
						la période sans le dire. Utilisez la réouverture de clôture.
					<?php endif; ?>
				</div>
			<?php else : ?>
				<form method="post" action="<?= e( url( 'comptabilite/ecritures/' . (int) $e['id'] . '/contrepasser' ) ) ?>"
					style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap"
					onsubmit="return confirm('Annuler cette écriture par contre-passation ?\n\nUne écriture inverse portant le même numéro sera enregistrée.')">
					<?= FKC_Csrf::field() ?>
					<label class="fld"><span>Date de la contre-passation</span>
						<input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>">
					</label>
					<button class="btn btn-primary btn-sm">Annuler par contre-passation</button>
				</form>
				<p class="help" style="margin-top:8px">
					La date doit tomber dans une période ouverte. Si le mois en cours est clôturé, choisissez-en une autre.
				</p>
			<?php endif; ?>

			<?php if ( ! empty( $an['supprimable'] ) ) : ?>
				<div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--line)">
					<p class="help" style="margin-top:0">
						Cette écriture n'est référencée par aucune pièce et n'a pas encore servi. Elle peut être
						<strong>supprimée définitivement</strong> — sans trace, contrairement à la contre-passation.
						À réserver à une saisie manifestement erronée, du même jour.
					</p>
					<form method="post" action="<?= e( url( 'comptabilite/ecritures/' . (int) $e['id'] . '/supprimer' ) ) ?>"
						onsubmit="return confirm('Supprimer DÉFINITIVEMENT cette écriture ?\n\nAucune trace ne sera conservée. La contre-passation est préférable dès que l\'écriture a été communiquée.')">
						<?= FKC_Csrf::field() ?>
						<button class="btn btn-ghost btn-sm" style="color:#b32d2e">Supprimer définitivement</button>
					</form>
				</div>
			<?php elseif ( ! empty( $an['raisons'] ) ) : ?>
				<p class="help" style="margin-top:12px">
					Suppression définitive impossible : <?= e( implode( ' ', $an['raisons'] ) ) ?>
					La contre-passation, elle, reste possible.
				</p>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>
