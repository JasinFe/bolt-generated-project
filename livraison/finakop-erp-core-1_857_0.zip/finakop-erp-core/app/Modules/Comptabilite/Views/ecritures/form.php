<?php /** @var array $journaux @var array $comptes @var array $errors @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $err ) : ?><div class="alert alert-err"><?= e( $err ) ?></div><?php endforeach; ?>
<?php if ( ! empty( $pastExercice ) ) : ?><div class="alert alert-warn">Saisie sur l'exercice <strong><?= e( $exercice ) ?></strong> (exercice passé). La date est pré-remplie ; modifiez-la au besoin. Si la période est clôturée, rouvrez-la d'abord depuis la Centralisation (GL).</div><?php endif; ?>

<?php
/*
 * DIVISION *ET* AXES, PAS L'UN OU L'AUTRE (1.762.0).
 *
 * `$hasDiv` valait `! $hasAxes && …` : dès qu'un seul axe analytique existait,
 * la colonne Division disparaissait de la saisie. Or les deux ne sont pas
 * concurrents — la division est la structure permanente (studio, label,
 * distribution), les axes portent les analyses transverses (projet, artiste,
 * campagne). Le moteur enregistre les trois depuis toujours, et le reste de
 * l'ERP les impute côte à côte ; seule la saisie manuelle imposait de choisir,
 * ce qui obligeait à repasser par une modification pour ventiler une écriture
 * saisie à la main.
 *
 * Chaque bloc s'affiche maintenant dès qu'il a de quoi être rempli.
 */
$hasAxes = ! empty( $showAxes ) && ! empty( $axes );
$hasDiv  = ! empty( $showDivision ) && ! empty( $divisions );
$colsAna = ( $hasDiv ? 1 : 0 ) + ( $hasAxes ? 2 : 0 );
$lead = 2 + $colsAna;   // colonnes avant « Débit »
$span = 5 + $colsAna;   // largeur totale du pied de tableau
?>
<form method="post" action="<?= e( url( 'comptabilite/ecritures' ) ) ?>" id="ecriture-form" enctype="multipart/form-data">
	<?= FKC_Csrf::field() ?>
	<div class="card">
		<div class="card-head"><h2>En-tête de l'écriture</h2></div>
		<div class="card-body">
			<div class="form-grid">
				<label class="fld"><span>Journal</span>
					<select name="journal_id" required>
						<option value="">— choisir —</option>
						<?php foreach ( $journaux as $j ) : ?>
							<option value="<?= (int) $j['id'] ?>"><?= e( $j['code'] . ' · ' . $j['libelle'] ) ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="fld"><span>Date</span><input type="date" name="date_ecriture" value="<?= e( $defaultDate ?? date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>N° de pièce</span><input type="text" name="piece" placeholder="FA-001"></label>
				<label class="fld"><span>Référence</span><input type="text" name="reference" placeholder="optionnel"></label>
			</div>
			<label class="fld"><span>Libellé de l'écriture</span>
				<input type="text" name="libelle" placeholder="Ex : Vente de marchandises au client X" required></label>
		</div>
	</div>

	<div class="card card-flush">
		<div class="card-head"><h2>Lignes (partie double)</h2>
			<button type="button" class="btn btn-ghost btn-sm" id="add-line">+ Ajouter une ligne</button></div>
		<table class="table" id="lines">
			<thead><tr><th style="width:30%">Compte</th><th>Libellé</th>
				<?php if ( $hasDiv ) : ?><th style="width:160px">Division</th><?php endif; ?>
				<?php if ( $hasAxes ) : ?><th style="width:150px">Axe</th><th style="width:170px">Valeur analytique</th><?php endif; ?>
				<th class="num" style="width:140px">Débit</th>
				<th class="num" style="width:140px">Crédit</th><th style="width:40px"></th></tr></thead>
			<tbody id="lines-body"></tbody>
			<tfoot>
				<tr class="total"><td colspan="<?= $lead ?>" class="right">Totaux</td>
					<td class="num" id="tot-debit">0</td><td class="num" id="tot-credit">0</td><td></td></tr>
				<tr><td colspan="<?= $span ?>" class="balance-state" id="balance-state"></td></tr>
			</tfoot>
		</table>
	</div>

	<?php
	/*
	 * PIÈCES JUSTIFICATIVES (revu en 1.769.0).
	 *
	 * Le champ s'appelait `piece[]`, du nom exact du champ texte « N° de
	 * pièce » : le corps multipart portait donc deux fois le même nom, une
	 * fois en scalaire et une fois en tableau. La validation stricte du
	 * multipart d'un pare-feu applicatif (ModSecurity, Imunify360) refuse ce
	 * corps, et l'hébergeur répond 403 AVANT PHP — écran noir, saisie perdue,
	 * aucune explication. Le champ s'appelle désormais `pieces[]`.
	 *
	 * Le poids accepté est annoncé, et vérifié AVANT l'envoi : dépasser le
	 * plafond du serveur donne le même 403 muet, alors qu'un message rendu
	 * ici laisse la saisie intacte.
	 */
	$plafond = (int) ( $plafondPieces ?? 8388608 );
	?>
	<label class="fld" style="margin-top:8px">
		<span>Pièces justificatives <span class="muted">(facultatif — PDF ou images, plusieurs possibles, <?= e( round( $plafond / 1048576, 1 ) ) ?> Mo au total)</span></span>
		<input type="file" id="ecr-pieces" name="pieces[]" accept=".pdf,.jpg,.jpeg,.png,.webp,.gif" multiple data-max="<?= (int) $plafond ?>">
		<small class="help" id="ecr-pieces-msg" style="display:none"></small>
		<small class="help">Si l'envoi d'une pièce est refusé par l'hébergeur, enregistrez l'écriture sans elle : vous pourrez la joindre depuis la fiche de l'écriture, sans ressaisir quoi que ce soit.</small>
	</label>
	<script>
	(function () {
		var champ = document.getElementById('ecr-pieces');
		var form = document.getElementById('ecriture-form');
		var msg = document.getElementById('ecr-pieces-msg');
		if (!champ || !form) { return; }
		var max = parseInt(champ.getAttribute('data-max'), 10) || 0;
		function mo(o) { return (o / 1048576).toFixed(1).replace('.', ','); }
		function trop() {
			var total = 0, i;
			for (i = 0; i < champ.files.length; i++) { total += champ.files[i].size; }
			return (max > 0 && total > max) ? total : 0;
		}
		function verifier() {
			var t = trop();
            if (!t) { msg.style.display = 'none'; msg.textContent = ''; return true; }
			msg.style.display = 'block';
			msg.style.color = 'var(--danger)';
			msg.textContent = 'Pièces trop lourdes : ' + mo(t) + ' Mo pour ' + mo(max) + ' Mo autorisés. '
				+ 'Retirez-en ou allégez-les — le serveur refuserait l\'envoi sans message, et votre saisie serait perdue.';
			return false;
		}
		champ.addEventListener('change', verifier);
		form.addEventListener('submit', function (ev) {
			if (!verifier()) { ev.preventDefault(); champ.focus(); }
		});
	})();
	</script>

	<div class="actions">
		<button class="btn btn-primary" type="submit" id="submit-btn">Enregistrer l'écriture</button>
		<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/ecritures' ) ) ?>">Annuler</a>
		<?php if ( empty( $brouillardOn ) ) : ?>
		<label class="fld-check" style="margin:0 0 0 auto">
			<input type="checkbox" name="brouillard" value="1">
			<span class="muted">Vérifier avant comptabilisation (brouillard)</span>
		</label>
		<?php else : ?>
		<span class="muted" style="margin-left:auto">Vérification active : l'écriture ira au brouillard.</span>
		<?php endif; ?>
	</div>
</form>

<script>
window.FKC_COMPTES = <?= json_encode( array_map( function ( $c ) {
	return array( 'id' => (int) $c['id'], 't' => $c['numero'] . ' · ' . $c['libelle'] );
}, $comptes ), JSON_UNESCAPED_UNICODE ) ?>;
window.FKC_SHOW_DIVISION = <?= $hasDiv ? 'true' : 'false' ?>;
window.FKC_DIVISIONS = <?= json_encode( array_map( function ( $d ) {
	return array( 'id' => (int) $d['id'], 't' => $d['libelle'] );
}, $divisions ?? array() ), JSON_UNESCAPED_UNICODE ) ?>;
window.FKC_SHOW_AXES = <?= $hasAxes ? 'true' : 'false' ?>;
window.FKC_AXES = <?= json_encode( array_map( function ( $a ) {
	return array( 'id' => (int) $a['id'], 't' => $a['code'] . ' · ' . $a['libelle'] );
}, $axes ?? array() ), JSON_UNESCAPED_UNICODE ) ?>;
window.FKC_VALEURS = <?= json_encode( $valeursMap ?? array(), JSON_UNESCAPED_UNICODE ) ?>;
</script>
