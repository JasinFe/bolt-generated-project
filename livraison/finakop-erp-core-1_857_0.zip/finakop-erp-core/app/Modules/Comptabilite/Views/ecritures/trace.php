<?php
/**
 * Provenance d'une écriture — la chaîne, du grand livre jusqu'à sa cause.
 *
 * Chaque maillon porte son état : connu ou manquant. Un écran de traçabilité
 * qui comble ses trous par déduction ne trace plus rien — il présente une
 * hypothèse avec l'apparence d'une preuve.
 *
 * @var array $trace @var array $ecriture @var string $tab
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$t = $trace; $e = $ecriture;
$num = ! empty( $e['numero'] ) ? $e['journal_code'] . '-' . $e['numero'] : 'n°' . (int) $e['id'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<div class="card" style="max-width:860px">
	<div class="card-head">
		<h2>Pourquoi cette écriture existe-t-elle ?</h2>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/ecritures/' . (int) $e['id'] ) ) ?>">← L'écriture</a>
	</div>
	<div class="card-body">

		<?php if ( ! $t['connue'] ) : ?>
			<div class="alert alert-warn">
				Cette écriture ne porte aucune provenance. Elle a été saisie directement,
				ou passée avant que le registre n'existe. Rien n'est reconstitué ici :
				une origine déduite du journal ou du libellé serait une supposition
				présentée comme un fait.
			</div>
		<?php endif; ?>

		<ol class="trace-chaine" style="list-style:none;padding:0;margin:0">
			<?php foreach ( $t['etapes'] as $i => $et ) : ?>
				<li style="display:flex;gap:14px;padding:10px 0;border-bottom:1px solid rgba(0,0,0,.06)">
					<div style="min-width:150px">
						<span class="stat-label"><?= e( $et['titre'] ) ?></span>
					</div>
					<div style="flex:1">
						<?php if ( $et['connu'] && '' !== trim( (string) $et['valeur'] ) ) : ?>
							<strong><?= e( $et['valeur'] ) ?></strong>
						<?php else : ?>
							<span class="muted">— non renseigné</span>
						<?php endif; ?>
						<?php if ( ! empty( $et['note'] ) ) : ?>
							<div class="muted" style="font-size:.9em;margin-top:2px"><?= e( $et['note'] ) ?></div>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</div>

<?php if ( ! empty( $t['regle'] ) ) : $r = $t['regle']; ?>
<div class="card" style="max-width:860px;margin-top:16px">
	<div class="card-head"><h2>La règle appliquée</h2></div>
	<div class="card-body">
		<p class="muted">
			Lue dans le moteur d'événements, et non dans la bibliothèque centrale :
			c'est celle qui a réellement produit les lignes ci-dessus.
		</p>
		<?php if ( '' !== $r['derogation'] ) : ?>
			<div class="alert alert-warn">
				<strong>Dérogation déclarée.</strong> <?= e( $r['derogation'] ) ?>
			</div>
		<?php endif; ?>
		<table class="table bordered">
			<thead><tr><th>Compte</th><th>Intitulé</th><th>Sens</th><th>Base</th><th>Condition</th></tr></thead>
			<tbody>
			<?php foreach ( $r['lignes'] as $l ) : ?>
				<tr>
					<td>
						<?php if ( ! empty( $l['role'] ) ) : ?>
							<strong><?= e( class_exists( 'FKC_Resolveur' ) ? FKC_Resolveur::label( $l['role'] ) : $l['role'] ) ?></strong>
							<div class="muted" style="font-size:.85em">à défaut <span class="code"><?= e( $l['compte'] ) ?></span></div>
						<?php else : ?>
							<span class="code"><?= e( $l['compte'] ) ?></span>
						<?php endif; ?>
					</td>
					<td class="muted"><?= e( $l['libelle'] ) ?></td>
					<td><?= 'D' === $l['sens'] ? 'Débit' : 'Crédit' ?></td>
					<td><span class="code"><?= e( $l['montant'] ) ?></span></td>
					<td class="muted"><?= '' !== $l['condition'] ? e( $l['condition'] ) : '—' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endif; ?>
