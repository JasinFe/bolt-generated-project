<?php /** @var array $ecritures @var string|null $annee @var array $annees @var string|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) :
	/* Le flash porte désormais un niveau : un refus d'annulation ne doit pas
	   s'afficher en vert comme une réussite. L'ancienne forme (chaîne nue) reste
	   tolérée pour une session ouverte pendant la mise à jour. */
	$fType = is_array( $flash ) ? ( $flash['type'] ?? 'ok' ) : 'ok';
	$fMsg  = is_array( $flash ) ? ( $flash['msg'] ?? '' ) : (string) $flash; ?>
	<div class="alert alert-<?= 'err' === $fType ? 'err' : 'ok' ?>"><?= e( $fMsg ) ?></div>
<?php endif; ?>
<div class="bar">
	<form method="get" action="<?= e( url( 'comptabilite/ecritures' ) ) ?>" style="display:flex;gap:8px;align-items:center;margin:0">
		<span class="muted">Journal des écritures · Exercice</span>
		<select name="annee" onchange="this.form.submit()">
			<option value="">Tous</option>
			<?php foreach ( ( $annees ?? array() ) as $yy ) : ?><option value="<?= e( $yy ) ?>" <?= (string) ( $annee ?? '' ) === (string) $yy ? 'selected' : '' ?>><?= e( $yy ) ?></option><?php endforeach; ?>
		</select>
	</form>
	<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/ecritures/import' ) ) ?>">⬇ Importer (modèle CSV)</a>
	<a class="btn btn-primary" href="<?= e( url( 'comptabilite/ecritures/nouvelle' . ( ! empty( $annee ) ? '?annee=' . $annee : '' ) ) ) ?>">+ Nouvelle écriture</a>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : date, n° de pièce, libellé, montant…' ) ); ?>
<div class="card card-flush">
	<table class="table">
		<thead><tr><th>N°</th><th>Date</th><th>Jnl</th><th>Pièce</th><th>Libellé</th>
			<th class="num">Débit</th><th class="num">Crédit</th><th></th></tr></thead>
		<tbody>
		<?php if ( empty( $ecritures ) ) : ?>
			<tr><td colspan="8" class="empty">Aucune écriture. Commencez par en saisir une.</td></tr>
		<?php else : foreach ( $ecritures as $ec ) : ?>
			<tr>
				<?php /* Numéro comptable : propre au journal et à l'exercice. L'id
				   technique n'est plus affiché — il était partagé entre tous les
				   journaux et toutes les années, donc inutilisable comme référence. */ ?>
				<?php
				/* Une annulation porte le même numéro que l'écriture annulée : sans
				   marque, la liste afficherait deux fois le même numéro sans qu'on
				   sache laquelle est laquelle. */
				$estAnn = 'annulation' === (string) ( $ec['type_ecriture'] ?? 'normale' );
				?>
				<td class="code">
					<?= $ec['numero'] ? e( $ec['numero'] ) : '<span class="muted" title="Écriture antérieure à la numérotation : lancez la reprise dans Paramètres → Maintenance">—</span>' ?>
					<?php if ( $estAnn ) : ?><span class="muted" title="Écriture d'annulation (contre-passation)">↩</span><?php endif; ?>
				</td>
				<td class="num"><?= e( date( 'd/m/Y', strtotime( $ec['date_ecriture'] ) ) ) ?></td>
				<td><span class="code"><?= e( $ec['journal_code'] ) ?></span></td>
				<td class="muted"><?= e( $ec['piece'] ?: '—' ) ?></td>
				<td><?= e( $ec['libelle'] ) ?><?php if ( ! empty( $pieces[ $ec['id'] ] ) ) : ?> <span class="pj-flag" title="<?= (int) $pieces[ $ec['id'] ] ?> pièce(s) jointe(s)">📎<?= (int) $pieces[ $ec['id'] ] > 1 ? '<sup>' . (int) $pieces[ $ec['id'] ] . '</sup>' : '' ?></span><?php endif; ?></td>
				<td class="num"><?= e( fkc_money( $ec['total_debit'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $ec['total_credit'] ) ) ?></td>
				<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/ecritures/' . $ec['id'] ) ) ?>">Voir</a></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
