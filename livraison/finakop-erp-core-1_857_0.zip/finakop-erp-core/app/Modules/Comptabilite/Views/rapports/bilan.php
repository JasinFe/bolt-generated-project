<?php /** @var array $bilan @var string|null $du @var string|null $au @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$A = $bilan['actif']; $P = $bilan['passif'];
$section = function ( $titre, $rows, $total ) {
	echo '<tr class="bilan-sec"><td colspan="2">' . e( $titre ) . '</td><td class="num">' . e( fkc_money( $total ) ) . '</td></tr>';
	foreach ( $rows as $r ) {
		echo '<tr><td style="padding-left:24px"><span class="code">' . e( $r['numero'] ) . '</span></td><td>' . e( $r['libelle'] ) . '</td><td class="num muted">' . e( fkc_money( $r['montant'] ) ) . '</td></tr>';
	}
}; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<div class="card">
	<div class="card-head"><h2>Bilan <span class="muted" style="font-weight:500;font-size:12px">— SYSCOHADA</span></h2>
		<form method="get" action="<?= e( url( 'comptabilite/bilan' ) ) ?>" class="inline">
			<input type="date" name="du" value="<?= e( $du ) ?>"><input type="date" name="au" value="<?= e( $au ) ?>">
			<button class="btn btn-ghost btn-sm" type="submit">Filtrer</button>
		</form>
	</div>
	<div class="card-body" style="padding:0">
		<?php if ( isset( $bilan['ouverture'] ) && empty( $bilan['ouverture']['fiable'] ) ) : $o = $bilan['ouverture']; ?>
			<div class="alert alert-err" role="alert" style="margin:16px 20px 0">
				🔴 <strong>Ouverture <?= (int) $o['exercice'] ?> non fiable — ce bilan, même équilibré, ne peut pas être tenu pour juste.</strong>
				<?= e( implode( ' ', (array) $o['raisons'] ) ) ?>
				<?php foreach ( (array) $o['sources'] as $s ) : ?> · <a href="<?= e( url( 'comptabilite/ecritures/' . (int) $s['id'] ) ) ?>"><?= e( $s['libelle_type'] ) ?> #<?= (int) $s['id'] ?></a><?php endforeach; ?>
				· <a href="<?= e( url( 'comptabilite/cloture/audit-anouveaux?annee=' . (int) $o['exercice'] ) ) ?>">Audit des À-nouveaux</a>
			</div>
		<?php endif; ?>
		<?php if ( $bilan['equilibre'] ) : ?>
			<div class="alert alert-ok" style="margin:16px 20px">✓ Bilan équilibré — Actif = Passif = <?= e( fkc_money( $A['total'] ) ) ?> FCFA</div>
		<?php else : ?>
			<div class="alert alert-warn" style="margin:16px 20px">⚠️ Écart de <?= e( fkc_money( $bilan['ecart'] ) ) ?> FCFA (Actif <?= e( fkc_money( $A['total'] ) ) ?> / Passif <?= e( fkc_money( $P['total'] ) ) ?>). Vérifiez les écritures non équilibrées ou les comptes hors classes 1–7.</div>
		<?php endif; ?>
	</div>
</div>

<div class="fac-layout" style="grid-template-columns:1fr 1fr">
	<!-- ACTIF -->
	<div class="card card-flush" style="margin:0">
		<div class="card-head"><h2>ACTIF</h2><strong class="num"><?= e( fkc_money( $A['total'] ) ) ?></strong></div>
		<table class="table bilan">
			<tbody>
			<?php $section( 'Actif immobilisé', $A['immobilise'], $A['t_immobilise'] ); ?>
			<?php $section( 'Actif circulant', $A['circulant'], $A['t_circulant'] ); ?>
			<?php $section( 'Trésorerie — Actif', $A['tresorerie'], $A['t_tresorerie'] ); ?>
			</tbody>
			<tfoot><tr class="total"><td colspan="2" class="right">TOTAL ACTIF</td><td class="num"><?= e( fkc_money( $A['total'] ) ) ?></td></tr></tfoot>
		</table>
	</div>
	<!-- PASSIF -->
	<div class="card card-flush" style="margin:0">
		<div class="card-head"><h2>PASSIF</h2><strong class="num"><?= e( fkc_money( $P['total'] ) ) ?></strong></div>
		<table class="table bilan">
			<tbody>
			<tr class="bilan-sec"><td colspan="2">Capitaux propres</td><td class="num"><?= e( fkc_money( $P['t_capitaux'] + $P['resultat'] ) ) ?></td></tr>
			<?php foreach ( $P['capitaux'] as $r ) : ?>
				<tr><td style="padding-left:24px"><span class="code"><?= e( $r['numero'] ) ?></span></td><td><?= e( $r['libelle'] ) ?></td><td class="num muted"><?= e( fkc_money( $r['montant'] ) ) ?></td></tr>
			<?php endforeach; ?>
				<tr><td style="padding-left:24px"><span class="code">120</span></td><td>Résultat net de l'exercice</td><td class="num" style="color:<?= $P['resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= e( fkc_money( $P['resultat'] ) ) ?></td></tr>
			<?php $section( 'Dettes financières', $P['dettes_fin'], $P['t_dettes_fin'] ); ?>
			<?php $section( 'Passif circulant', $P['circulant'], $P['t_circulant'] ); ?>
			<?php $section( 'Trésorerie — Passif', $P['tresorerie'], $P['t_tresorerie'] ); ?>
			</tbody>
			<tfoot><tr class="total"><td colspan="2" class="right">TOTAL PASSIF</td><td class="num"><?= e( fkc_money( $P['total'] ) ) ?></td></tr></tfoot>
		</table>
	</div>
</div>
<style>.bilan-sec td{background:var(--bg2);font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:var(--text)}</style>
