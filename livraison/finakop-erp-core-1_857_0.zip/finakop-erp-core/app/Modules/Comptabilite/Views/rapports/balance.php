<?php /** @var array $lignes @var array $tot @var string|null $du @var string|null $au @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php FKC_View::partial( 'comptabilite::_etat_entete', array( 'etat' => 'Balance générale', 'periode' => ( $du || $au ) ? ( 'Du ' . ( $du ? date('d/m/Y', strtotime($du)) : '…' ) . ' au ' . ( $au ? date('d/m/Y', strtotime($au)) : '…' ) ) : 'Toutes périodes' ) ); ?>
<div class="card card-flush">
	<div class="card-head"><h2>Balance générale</h2>
		<form method="get" action="<?= e( url( 'comptabilite/balance' ) ) ?>" class="inline">
			<input type="date" name="du" value="<?= e( $du ) ?>">
			<input type="date" name="au" value="<?= e( $au ) ?>">
			<button class="btn btn-ghost btn-sm" type="submit">Filtrer</button>
		</form>
	</div>
	<div style="padding:12px 18px 0"><?php FKC_View::partial( 'comptabilite::_bandeau_ouverture', array( 'ctx' => $contexte ?? null ) ); ?></div>
	<p class="help" style="padding:0 18px">Colonnes d'ouverture : le solde d'ouverture du gestionnaire des À-nouveaux — l'écriture d'À-nouveaux quand la période ouvre l'exercice, jamais comptée une seconde fois en mouvement. Puis mouvements de la période et soldes de clôture : ce sont les chiffres du Grand Livre et du Bilan.</p>
	<table class="table">
		<thead><tr><th style="width:96px">Compte</th><th>Intitulé</th>
			<th class="num">Ouv. Débit</th><th class="num">Ouv. Crédit</th>
			<th class="num">Mvt Débit</th><th class="num">Mvt Crédit</th>
			<th class="num">Solde Débiteur</th><th class="num">Solde Créditeur</th></tr></thead>
		<tbody>
		<?php if ( empty( $lignes ) ) : ?>
			<tr><td colspan="8" class="empty">Aucun mouvement sur la période.</td></tr>
		<?php else : foreach ( $lignes as $l ) : ?>
			<tr<?= ! empty( $l['ouverture_non_fiable'] ) ? ' style="background:rgba(214,69,69,.07)"' : '' ?>>
				<td><span class="code"><?= e( $l['numero'] ) ?></span></td>
				<td><?= e( $l['libelle'] ) ?><?php if ( ! empty( $l['ouverture_non_fiable'] ) ) : ?>
					<br><span style="color:#d64545;font-size:11.5px">🔴 Ouverture non fiable — attendu <?= e( fkc_money( abs( (float) $l['ouverture_attendue'] ) ) ) ?>,
					effectif <?= e( fkc_money( abs( (float) $l['ouverture_effective'] ) ) ) ?>, écart <?= e( ( $l['ouverture_ecart'] >= 0 ? '+' : '−' ) . fkc_money( abs( (float) $l['ouverture_ecart'] ) ) ) ?></span><?php endif; ?></td>
				<td class="num muted"><?= (float) $l['ouv_debit'] ? e( fkc_money( $l['ouv_debit'] ) ) : '' ?></td>
				<td class="num muted"><?= (float) $l['ouv_credit'] ? e( fkc_money( $l['ouv_credit'] ) ) : '' ?></td>
				<td class="num"><?= e( fkc_money( $l['debit'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $l['credit'] ) ) ?></td>
				<td class="num"><?= (float) $l['solde_debiteur'] ? e( fkc_money( $l['solde_debiteur'] ) ) : '' ?></td>
				<td class="num"><?= (float) $l['solde_crediteur'] ? e( fkc_money( $l['solde_crediteur'] ) ) : '' ?></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( ! empty( $lignes ) ) : ?>
		<tfoot><tr class="total"><td colspan="2" class="right">TOTAUX</td>
			<td class="num"><?= e( fkc_money( $tot['ouv_debit'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $tot['ouv_credit'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $tot['debit'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $tot['credit'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $tot['sd'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $tot['sc'] ) ) ?></td></tr></tfoot>
		<?php endif; ?>
	</table>
</div>
