<?php /** @var array $cr @var string|null $du @var string|null $au @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$a = $cr['agg']; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<div class="card">
	<div class="card-head"><h2>Compte de résultat <span class="muted" style="font-weight:500;font-size:12px">— SYSCOHADA</span></h2>
		<form method="get" action="<?= e( url( 'comptabilite/compte-resultat' ) ) ?>" class="inline">
			<input type="date" name="du" value="<?= e( $du ) ?>"><input type="date" name="au" value="<?= e( $au ) ?>">
			<button class="btn btn-ghost btn-sm" type="submit">Filtrer</button>
		</form>
	</div>
	<div class="card-body">
		<div class="stats" style="margin:0 0 6px">
			<div class="stat"><span class="stat-label">Chiffre d'affaires</span><span class="stat-value" style="font-size:20px"><?= e( fkc_money( $a['ca'] ) ) ?></span></div>
			<div class="stat"><span class="stat-label">Résultat d'exploitation</span><span class="stat-value" style="font-size:20px"><?= e( fkc_money( $a['res_expl'] ) ) ?></span></div>
			<div class="stat"><span class="stat-label">Résultat financier</span><span class="stat-value" style="font-size:20px"><?= e( fkc_money( $a['res_fin'] ) ) ?></span></div>
			<div class="stat stat-accent"><span class="stat-label">Résultat net</span><span class="stat-value" style="font-size:20px;color:<?= $cr['resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= e( fkc_money( $cr['resultat'] ) ) ?></span></div>
		</div>
	</div>
</div>

<div class="fac-layout" style="grid-template-columns:1fr 1fr">
	<div class="card card-flush" style="margin:0">
		<div class="card-head"><h2>Charges</h2></div>
		<table class="table">
			<tbody>
			<?php foreach ( $cr['charges'] as $r ) : ?>
				<tr><td><span class="code"><?= e( $r['numero'] ) ?></span></td><td><?= e( $r['libelle'] ) ?></td><td class="num"><?= e( fkc_money( $r['montant'] ) ) ?></td></tr>
			<?php endforeach; ?>
			<?php if ( empty( $cr['charges'] ) ) : ?><tr><td colspan="3" class="empty">Aucune charge.</td></tr><?php endif; ?>
			</tbody>
			<tfoot><tr class="total"><td colspan="2" class="right">Total charges</td><td class="num"><?= e( fkc_money( $cr['total_charges'] ) ) ?></td></tr></tfoot>
		</table>
	</div>
	<div class="card card-flush" style="margin:0">
		<div class="card-head"><h2>Produits</h2></div>
		<table class="table">
			<tbody>
			<?php foreach ( $cr['produits'] as $r ) : ?>
				<tr><td><span class="code"><?= e( $r['numero'] ) ?></span></td><td><?= e( $r['libelle'] ) ?></td><td class="num"><?= e( fkc_money( $r['montant'] ) ) ?></td></tr>
			<?php endforeach; ?>
			<?php if ( empty( $cr['produits'] ) ) : ?><tr><td colspan="3" class="empty">Aucun produit.</td></tr><?php endif; ?>
			</tbody>
			<tfoot><tr class="total"><td colspan="2" class="right">Total produits</td><td class="num"><?= e( fkc_money( $cr['total_produits'] ) ) ?></td></tr></tfoot>
		</table>
	</div>
</div>
<div class="card" style="margin-top:20px">
	<div class="card-body" style="display:flex;justify-content:space-between;align-items:center">
		<strong style="font-family:Syne,sans-serif;font-size:16px">Résultat net de l'exercice</strong>
		<strong style="font-family:Syne,sans-serif;font-size:22px;color:<?= $cr['resultat'] >= 0 ? 'var(--ok)' : 'var(--danger)' ?>"><?= e( fkc_money( $cr['resultat'] ) ) ?> FCFA</strong>
	</div>
</div>
