<?php /** @var array $comptes @var array $totaux @var int $nb @var array $liste @var array $journaux @var array $f @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) );
$duEff = $duEff ?? ( $f['du'] ?: date( 'Y-m-d' ) );
$periode = ( $f['du'] || $f['au'] ) ? ( 'Du ' . ( $f['du'] ? date( 'd/m/Y', strtotime( $f['du'] ) ) : '…' ) . ' au ' . ( $f['au'] ? date( 'd/m/Y', strtotime( $f['au'] ) ) : '…' ) ) : 'Toutes périodes';
FKC_View::partial( 'comptabilite::_etat_entete', array( 'etat' => 'Grand livre général', 'periode' => $periode ) );
$qs = http_build_query( array_filter( array(
	'du' => $f['du'], 'au' => $f['au'], 'compte_de' => $f['compte_de'], 'compte_a' => $f['compte_a'],
	'journal' => $f['journal'], 'compte_id' => $f['compte_id'], 'q' => $f['q'], 'all' => $f['non_zero'] ? null : '1',
	'prefixes' => ! empty( $f['prefixes'] ) ? implode( ',', $f['prefixes'] ) : null, 'gestion' => ! empty( $f['gestion'] ) ? '1' : null,
) ) );
$equ = abs( $totaux['debit'] - $totaux['credit'] ) < 0.005;
$dc = function ( $v ) { return fkc_money( abs( $v ) ) . ' ' . ( $v < 0 ? 'C' : 'D' ); };
?>
<style>
@media print{ .fkc-noprint,.modbar,.fkc-side,#fkcSide{display:none!important} .gl-acc{break-inside:avoid} body{background:#fff} }
.gl-acc{margin-bottom:16px}
.gl-acc .card-head{background:linear-gradient(90deg,rgba(201,162,39,.08),transparent)}
.gl-ouv td{font-style:italic;color:var(--muted)}
.gl-calc td{color:var(--orange)}
.gl-an td{background:rgba(201,162,39,.07);font-weight:600}
.gl-nf td{background:rgba(214,69,69,.09);color:#d64545;font-size:12.5px}
.gl-src-nf td{background:rgba(214,69,69,.05)}
.gl-tot td{font-weight:700;border-top:2px solid var(--line)}
.gl-letter{font-family:ui-monospace,monospace;font-size:11px;color:var(--orange)}
</style>

<?php if ( ! empty( $f['prefixes'] ) ) : ?>
<div class="alert alert-ok fkc-noprint" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
	<span>Détail d'un poste : comptes <strong><?= e( implode( '*, ', $f['prefixes'] ) ) ?>*</strong><?= ! empty( $f['gestion'] ) ? ', hors écriture de détermination du résultat' : '' ?>.</span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/grand-livre?' . http_build_query( array_filter( array( 'du' => $f['du'], 'au' => $f['au'] ) ) ) ) ) ?>">Retirer ce filtre</a>
</div>
<?php endif; ?>
<form method="get" action="<?= e( url( 'comptabilite/grand-livre' ) ) ?>" class="card fkc-noprint" style="margin-bottom:14px"><div class="card-body">
	<?php if ( ! empty( $f['prefixes'] ) ) : ?><input type="hidden" name="prefixes" value="<?= e( implode( ',', $f['prefixes'] ) ) ?>"><?php endif; ?>
	<?php if ( ! empty( $f['gestion'] ) ) : ?><input type="hidden" name="gestion" value="1"><?php endif; ?>
	<div class="form-grid" style="grid-template-columns:repeat(6,1fr) auto;align-items:end;gap:10px">
		<label class="fld"><span>Du</span><input type="date" name="du" value="<?= e( $f['du'] ) ?>"></label>
		<label class="fld"><span>Au</span><input type="date" name="au" value="<?= e( $f['au'] ) ?>"></label>
		<label class="fld"><span>Compte de</span><input name="compte_de" value="<?= e( $f['compte_de'] ) ?>" placeholder="ex. 401" inputmode="numeric"></label>
		<label class="fld"><span>Compte à</span><input name="compte_a" value="<?= e( $f['compte_a'] ) ?>" placeholder="ex. 499" inputmode="numeric"></label>
		<label class="fld"><span>Journal</span>
			<select name="journal"><option value="">— Tous —</option>
				<?php foreach ( $journaux as $j ) : ?><option value="<?= e( $j['code'] ) ?>" <?= ( $f['journal'] === $j['code'] ) ? 'selected' : '' ?>><?= e( $j['code'] . ' · ' . ( $j['libelle'] ?? '' ) ) ?></option><?php endforeach; ?>
			</select>
		</label>
		<label class="fld"><span>Recherche (pièce / libellé)</span><input name="q" value="<?= e( $f['q'] ) ?>" placeholder="ex. FAC-2026"></label>
		<div style="display:flex;gap:6px"><button class="btn btn-primary" type="submit">Afficher</button><a class="btn btn-ghost" href="<?= e( url( 'comptabilite/grand-livre' ) ) ?>">Réinit.</a></div>
	</div>
	<div style="display:flex;gap:18px;align-items:center;margin-top:10px;flex-wrap:wrap">
		<label class="fld" style="min-width:280px"><span>Compte précis (optionnel)</span>
			<select name="compte_id"><option value="">— Tous les comptes —</option>
				<?php foreach ( $liste as $c ) : ?><option value="<?= (int) $c['id'] ?>" <?= ( (int)($f['compte_id']??0) === (int)$c['id'] ) ? 'selected' : '' ?>><?= e( $c['numero'] . ' · ' . $c['libelle'] ) ?></option><?php endforeach; ?>
			</select>
		</label>
		<label class="chk" style="display:flex;align-items:center;gap:6px"><input type="checkbox" name="all" value="1" <?= $f['non_zero'] ? '' : 'checked' ?> style="width:auto"> Afficher aussi les comptes soldés / sans mouvement</label>
	</div>
</div></form>

<div class="bar fkc-noprint">
	<span class="muted"><?= (int) $nb ?> compte(s) · Total débit <strong><?= e( fkc_money( $totaux['debit'] ) ) ?></strong> · Total crédit <strong><?= e( fkc_money( $totaux['credit'] ) ) ?></strong> <?= $equ ? '<span class="modbadge b-on">équilibré</span>' : '<span class="modbadge b-err">déséquilibre</span>' ?></span>
	<span style="display:flex;gap:8px">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/grand-livre/export' . ( $qs ? '?' . $qs : '' ) ) ) ?>">⬇ CSV</a>
		<button class="btn btn-ghost btn-sm" type="button" onclick="window.print()">🖨️ Imprimer</button>
	</span>
</div>

<?php FKC_View::partial( 'comptabilite::_bandeau_ouverture', array( 'ctx' => $contexte ?? null ) ); ?>

<?php if ( ! $comptes ) : ?>
	<div class="card"><div class="card-body empty">Aucun mouvement pour ces critères.</div></div>
<?php else : foreach ( $comptes as $a ) : ?>
	<div class="card card-flush gl-acc">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
			<h2><span class="code"><?= e( $a['numero'] ) ?></span> · <?= e( $a['libelle'] ) ?></h2>
			<span class="muted">Solde : <strong><?= e( $dc( $a['solde'] ) ) ?></strong></span>
		</div>
		<table class="table">
			<thead><tr><th style="width:95px">Date</th><th style="width:48px">Jnl</th><th style="width:130px">Pièce</th><th>Libellé</th><th class="num">Débit</th><th class="num">Crédit</th><th class="num">Solde</th><th style="width:40px">Let.</th></tr></thead>
			<tbody>
				<?php if ( ! empty( $a['ouverture_non_fiable'] ) ) : $nf = $a['ouverture_non_fiable']; ?>
					<tr class="gl-nf"><td colspan="8">🔴 <strong>Solde d'ouverture non fiable</strong> —
						attendu (clôture <?= (int) ( $contexte['exercice'] ?? 0 ) - 1 ?>) <strong><?= e( $dc( $nf['attendu'] ) ) ?></strong> ·
						effectif (toutes sources) <strong><?= e( $dc( $nf['effectif'] ) ) ?></strong> ·
						écart <strong><?= e( ( $nf['ecart'] >= 0 ? '+' : '−' ) . fkc_money( abs( $nf['ecart'] ) ) ) ?></strong></td></tr>
				<?php endif; ?>
				<?php if ( abs( (float) $a['ouverture'] ) >= 0.005 ) : ?>
					<tr class="gl-ouv<?= ! empty( $a['ouverture_calculee'] ) ? ' gl-calc' : '' ?>"><td><?= e( date( 'd/m/Y', strtotime( $duEff ) ) ) ?></td><td></td><td>—</td><td><?= e( $a['libelle_ouverture'] ?? 'Solde d\'ouverture' ) ?><?= ! empty( $a['ouverture_calculee'] ) ? ' <span class="modbadge b-err">calculé</span>' : '' ?></td>
						<td class="num"><?= $a['ouverture'] > 0 ? e( fkc_money( $a['ouverture'] ) ) : '' ?></td>
						<td class="num"><?= $a['ouverture'] < 0 ? e( fkc_money( -$a['ouverture'] ) ) : '' ?></td>
						<td class="num"><?= e( $dc( $a['ouverture'] ) ) ?></td><td></td></tr>
				<?php endif; ?>
				<?php foreach ( $a['mouvements'] as $m ) : ?>
					<tr<?= ! empty( $m['ouverture_reelle'] ) ? ' class="gl-an" title="Écriture d\'À-nouveaux : mouvement d\'ouverture réel"'
						: ( ( ! empty( $m['source_ouverture'] ) && empty( $contexte['fiable'] ) ) ? ' class="gl-src-nf" title="Source d\'ouverture — ouverture non fiable"' : '' ) ?>>
						<td><?= e( date( 'd/m/Y', strtotime( $m['date'] ) ) ) ?></td>
						<td><span class="code"><?= e( $m['journal'] ) ?></span></td>
						<td class="muted"><?= e( $m['piece'] ?: '—' ) ?></td>
						<td><?= e( $m['libelle'] ) ?><?php if ( ! empty( $m['source_ouverture'] ) && empty( $contexte['fiable'] ) ) : ?> <span class="modbadge b-err"><?= e( $m['source_ouverture'] ) ?> #<?= (int) $m['ecriture_id'] ?></span><?php endif; ?></td>
						<td class="num"><?= $m['debit'] ? e( fkc_money( $m['debit'] ) ) : '' ?></td>
						<td class="num"><?= $m['credit'] ? e( fkc_money( $m['credit'] ) ) : '' ?></td>
						<td class="num"><?= e( $dc( $m['solde'] ) ) ?></td>
						<td><?php if ( ! empty( $m['lettre'] ) ) : ?><span class="gl-letter"><?= e( $m['lettre'] ) ?></span><?php endif; ?></td>
					</tr>
				<?php endforeach; ?>
				<?php if ( ! $a['mouvements'] ) : ?><tr><td colspan="8" class="empty" style="padding:8px">Aucun mouvement sur la période (solde d'ouverture ci-dessus).</td></tr><?php endif; ?>
			</tbody>
			<tfoot>
				<tr class="gl-tot"><td colspan="4" class="right">Total compte <?= e( $a['numero'] ) ?></td>
					<td class="num"><?= e( fkc_money( $a['td'] ) ) ?></td>
					<td class="num"><?= e( fkc_money( $a['tc'] ) ) ?></td>
					<td class="num" style="color:var(--orange)"><?= e( $dc( $a['solde'] ) ) ?></td><td></td></tr>
			</tfoot>
		</table>
	</div>
<?php endforeach; endif; ?>

<?php if ( $comptes ) : ?>
<div class="card"><div class="card-body" style="display:flex;justify-content:space-between;align-items:center">
	<strong>TOTAL GÉNÉRAL</strong>
	<span>Débit <strong><?= e( fkc_money( $totaux['debit'] ) ) ?></strong> · Crédit <strong><?= e( fkc_money( $totaux['credit'] ) ) ?></strong> <?= $equ ? '<span class="modbadge b-on">équilibré</span>' : '<span class="modbadge b-err">écart ' . e( fkc_money( $totaux['debit'] - $totaux['credit'] ) ) . '</span>' ?></span>
</div></div>
<?php endif; ?>
