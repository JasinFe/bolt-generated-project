<?php
/**
 * BANDEAU DE CONTRÔLE DE LA LIASSE.
 *
 * Les états financiers ne disaient rien de ce sur quoi ils reposaient. Ce
 * bandeau répond aux trois questions qu'un comptable se pose avant de
 * déposer : est-ce que tout est comptabilisé, est-ce que l'exercice est
 * ouvert et clôturé, est-ce que les états se tiennent entre eux.
 *
 * Il n'empêche rien : il informe. Un dossier peut avoir de bonnes raisons
 * d'éditer une liasse provisoire.
 *
 * @var array $controle  Sortie de FKC_EtatsDgi::controle()
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
if ( empty( $controle ) || ! is_array( $controle ) ) { return; }
$anos = (array) ( $controle['anomalies'] ?? array() );
$bloquants = array_values( array_filter( $anos, function ( $a ) { return 'incoherence' === $a['niveau']; } ) );
$autres    = array_values( array_filter( $anos, function ( $a ) { return 'incoherence' !== $a['niveau']; } ) );
?>
<div class="ec-wrap <?= $bloquants ? 'ko' : ( $autres ? 'warn' : 'ok' ) ?>">
	<div class="ec-hd">
		<span class="ec-pic"><?= $bloquants ? '⚠' : ( $autres ? 'ⓘ' : '✓' ) ?></span>
		<span class="ec-ttl">
			<?php if ( $bloquants ) : ?>
				Ces états ne se tiennent pas — édition refusée
			<?php elseif ( $autres ) : ?>
				Liasse provisoire — cohérente, mais pas encore déposable
			<?php else : ?>
				Liasse cohérente et complète
			<?php endif; ?>
		</span>
		<span class="ec-sub">Exercice <?= e( $controle['libelle'] ) ?> · résultat net
			<strong><?= e( fkc_money( $controle['resultat_gl'] ) ) ?> F CFA</strong></span>
	</div>
	<?php if ( $anos ) : ?>
		<ul class="ec-list">
			<?php foreach ( array_merge( $bloquants, $autres ) as $a ) : ?>
				<li class="lvl-<?= e( $a['niveau'] ) ?>"><?= e( $a['texte'] ) ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php if ( $bloquants ) : ?>
		<div class="ec-nv" style="color:var(--danger)">L'export CSV et l'impression sont refusés tant que l'écart n'est pas expliqué.</div>
	<?php elseif ( $autres ) : ?>
		<div class="ec-nv">Les documents édités porteront la mention <strong>PROVISOIRE</strong>.</div>
	<?php endif; ?>
	<?php if ( ! empty( $controle['non_ventiles'] ) ) : ?>
		<div class="ec-nv">
			<strong>Comptes rangés dans une ligne de repli :</strong>
			<?php $bits = array(); foreach ( $controle['non_ventiles'] as $c ) {
				$bits[] = $c['numero'] . ( $c['libelle'] ? ' — ' . $c['libelle'] : '' ) . ( ! empty( $c['ligne'] ) ? ' → ' . $c['ligne'] : '' ) . ' (' . fkc_money( $c['solde'] ) . ')';
			} ?>
			<?= e( implode( ' · ', $bits ) ) ?>
		</div>
	<?php endif; ?>
</div>
<style>
.ec-wrap{border:1px solid var(--line);border-left-width:3px;border-radius:12px;padding:12px 16px;margin-bottom:16px;background:var(--panel)}
.ec-wrap.ok{border-left-color:var(--ok)}
.ec-wrap.warn{border-left-color:var(--orange)}
.ec-wrap.ko{border-left-color:var(--danger)}
.ec-hd{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.ec-pic{font-size:15px}
.ec-ttl{font-family:Syne,sans-serif;font-weight:800;font-size:14px}
.ec-wrap.ok .ec-ttl{color:var(--ok)}
.ec-wrap.warn .ec-ttl{color:var(--orange)}
.ec-wrap.ko .ec-ttl{color:var(--danger)}
.ec-sub{color:var(--muted);font-size:12.5px;margin-left:auto}
.ec-sub strong{color:var(--text)}
.ec-list{margin:9px 0 0;padding-left:20px;font-size:13px;line-height:1.65}
.ec-list li.lvl-incoherence{color:var(--danger)}
.ec-list li.lvl-reserve{color:var(--orange)}
.ec-list li.lvl-information{color:var(--muted)}
.ec-nv{margin-top:9px;font-size:12px;color:var(--muted);font-family:var(--mono)}
@media(max-width:700px){.ec-sub{margin-left:0;width:100%}}
</style>
