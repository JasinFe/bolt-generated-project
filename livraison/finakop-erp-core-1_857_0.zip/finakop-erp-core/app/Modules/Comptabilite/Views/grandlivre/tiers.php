<?php /** @var string $type @var array $lignes @var float $sini @var array $totaux @var array $tiers @var array $opts @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'comptabilite::_subnav' );
$isF   = ( 'fournisseur' === $type );
$base  = $isF ? 'comptabilite/grand-livre-fournisseurs' : 'comptabilite/grand-livre-clients';
$tlabel= $isF ? 'Fournisseur' : 'Client';
$qs    = http_build_query( array_filter( array(
	'tiers_id' => $opts['tiers_id'], 'from' => $opts['from'], 'to' => $opts['to'],
	'lettrage' => 'all' === $opts['lettrage'] ? null : $opts['lettrage'], 'q' => $opts['q'],
) ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<form method="get" action="<?= e( url( $base ) ) ?>" class="card" style="margin-bottom:14px">
	<div class="card-body">
		<div class="form-grid" style="grid-template-columns:2fr 1fr 1fr 1fr 1.4fr auto;align-items:end;gap:12px">
			<label class="fld"><span><?= e( $tlabel ) ?></span>
				<select name="tiers_id">
					<option value="">— Tous —</option>
					<?php foreach ( $tiers as $t ) : ?><option value="<?= (int) $t['id'] ?>" <?= ( (int) $opts['tiers_id'] === (int) $t['id'] ) ? 'selected' : '' ?>><?= e( ( $t['code'] ? $t['code'] . ' · ' : '' ) . $t['nom'] ) ?></option><?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Du</span><input type="date" name="from" value="<?= e( $opts['from'] ) ?>"></label>
			<label class="fld"><span>Au</span><input type="date" name="to" value="<?= e( $opts['to'] ) ?>"></label>
			<label class="fld"><span>Lettrage</span>
				<select name="lettrage">
					<option value="all" <?= 'all'===$opts['lettrage']?'selected':'' ?>>Tout</option>
					<option value="nonlettre" <?= 'nonlettre'===$opts['lettrage']?'selected':'' ?>>Non lettré</option>
					<option value="lettre" <?= 'lettre'===$opts['lettrage']?'selected':'' ?>>Lettré</option>
				</select>
			</label>
			<label class="fld"><span>Recherche (pièce / libellé)</span><input name="q" value="<?= e( $opts['q'] ) ?>" placeholder="ex. FAC-2026 ou nom"></label>
			<div style="display:flex;gap:8px">
				<button class="btn btn-primary" type="submit">Filtrer</button>
				<a class="btn btn-ghost" href="<?= e( url( $base ) ) ?>">Réinit.</a>
			</div>
		</div>
	</div>
</form>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
		<h2><?= $isF ? '🚚 Grand livre Fournisseurs (40x)' : '👤 Grand livre Clients (41x)' ?></h2>
		<div style="display:flex;gap:8px;align-items:center">
			<?php if ( ! empty( $opts['tiers_id'] ) ) : ?>
			<form method="post" action="<?= e( url( $base . '/auto' ) ) ?>" style="margin:0">
				<?= FKC_Csrf::field() ?><input type="hidden" name="tiers_id" value="<?= (int) $opts['tiers_id'] ?>"><input type="hidden" name="_filters" value="<?= e( $qs ) ?>">
				<button class="btn btn-ghost btn-sm" type="submit" title="Lettrer automatiquement si le solde du tiers est nul">⚡ Lettrage auto (solde nul)</button>
			</form>
			<?php endif; ?>
		</div>
	</div>

	<form method="post" action="<?= e( url( $base . '/lettrer' ) ) ?>" id="glform">
		<?= FKC_Csrf::field() ?><input type="hidden" name="_filters" value="<?= e( $qs ) ?>">
		<table class="table">
			<thead><tr>
				<th style="width:30px"></th>
				<th style="width:90px">Date</th><th>Pièce</th><th style="width:50px">Jrnl</th>
				<th>Libellé</th><?php if ( empty( $opts['tiers_id'] ) ) : ?><th><?= e( $tlabel ) ?></th><?php endif; ?>
				<th class="num">Débit</th><th class="num">Crédit</th><th class="num">Solde</th><th style="width:50px">Let.</th>
			</tr></thead>
			<tbody>
				<tr class="report"><td colspan="<?= empty( $opts['tiers_id'] ) ? 8 : 7 ?>" class="right"><em><?php
					// Terminologie (1.798.0) : « Report à nouveau » désigne l'affectation du résultat, jamais un solde d'ouverture.
					if ( ! empty( $opts['from'] ) && class_exists( 'FKC_SoldeOuverture' ) ) {
						$exo = FKC_SoldeOuverture::exerciceDe( $opts['from'] );
						echo e( $opts['from'] === FKC_SoldeOuverture::debutDe( $exo ) ? 'Solde d\'ouverture' : FKC_SoldeOuverture::libelleOuverture( 'report', $opts['from'], $exo ) );
					} else { echo 'Solde d\'ouverture'; }
				?></em></td><td class="num"><strong><?= e( fkc_money( $sini ) ) ?></strong></td><td></td></tr>
				<?php if ( ! $lignes ) : ?>
					<tr><td colspan="<?= empty( $opts['tiers_id'] ) ? 10 : 9 ?>" class="empty">Aucun mouvement pour ces critères.</td></tr>
				<?php else : foreach ( $lignes as $l ) :
					$let = trim( (string) $l['lettre'] ); ?>
					<tr class="<?= $let ? 'lettre-on' : '' ?>">
						<td><?php if ( ! $let ) : ?><input type="checkbox" name="ids[]" value="<?= (int) $l['ligne_id'] ?>" class="gl-chk" data-debit="<?= (float) $l['debit'] ?>" data-credit="<?= (float) $l['credit'] ?>"><?php else : ?><input type="checkbox" class="gl-chk-let" value="<?= (int) $l['ligne_id'] ?>"><?php endif; ?></td>
						<td><?= e( date( 'd/m/Y', strtotime( $l['date'] ) ) ) ?></td>
						<td><span class="code"><?= e( $l['piece'] ?: '—' ) ?></span></td>
						<td><span class="modbadge"><?= e( $l['journal'] ) ?></span></td>
						<td><?= e( $l['libelle'] ) ?></td>
						<?php if ( empty( $opts['tiers_id'] ) ) : ?><td><?= e( $l['tiers_nom'] ) ?></td><?php endif; ?>
						<td class="num"><?= $l['debit'] > 0 ? e( fkc_money( $l['debit'] ) ) : '' ?></td>
						<td class="num"><?= $l['credit'] > 0 ? e( fkc_money( $l['credit'] ) ) : '' ?></td>
						<td class="num"><?= e( fkc_money( $l['solde'] ) ) ?></td>
						<td><?php if ( $let ) : ?><span class="modbadge b-on"><?= e( $let ) ?></span><?php endif; ?></td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
			<tfoot>
				<tr class="total"><td colspan="<?= empty( $opts['tiers_id'] ) ? 6 : 5 ?>" class="right">Totaux période</td>
					<td class="num"><strong><?= e( fkc_money( $totaux['debit'] ) ) ?></strong></td>
					<td class="num"><strong><?= e( fkc_money( $totaux['credit'] ) ) ?></strong></td>
					<td class="num"><strong style="color:var(--orange)"><?= e( fkc_money( $totaux['solde'] ) ) ?></strong></td><td></td></tr>
			</tfoot>
		</table>

		<div class="gl-actions" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;padding:12px 16px;border-top:1px solid var(--line)">
			<span id="gl-selinfo" class="muted">0 ligne sélectionnée · solde 0</span>
			<label class="chk" style="display:flex;align-items:center;gap:6px"><input type="checkbox" name="force" value="1" style="width:auto"> Lettrage partiel (forcer)</label>
			<button class="btn btn-primary btn-sm" type="submit">🔗 Lettrer la sélection</button>
			<button class="btn btn-ghost btn-sm" type="submit" formaction="<?= e( url( $base . '/delettrer' ) ) ?>" id="gl-delet">✂️ Délettrer la sélection</button>
		</div>
	</form>
</div>
<p class="help">Le lettrage rapproche des factures avec leurs règlements et avoirs (un même code-lettre). Une sélection équilibrée (débit = crédit) est lettrée définitivement ; cochez « Lettrage partiel » pour forcer un solde résiduel. Les avoirs apparaissent ici au crédit du compte client et réduisent le solde.</p>
<script>
(function(){
	var form=document.getElementById('glform'); if(!form)return;
	var info=document.getElementById('gl-selinfo');
	function fmt(n){return n.toLocaleString('fr-FR');}
	function refresh(){
		var n=0,d=0,c=0;
		form.querySelectorAll('.gl-chk:checked').forEach(function(b){n++;d+=parseFloat(b.dataset.debit||0);c+=parseFloat(b.dataset.credit||0);});
		var solde=Math.round(d-c);
		info.textContent=n+' ligne'+(n>1?'s':'')+' sélectionnée'+(n>1?'s':'')+' · solde '+fmt(solde);
		info.style.color = (n>0 && solde===0)?'var(--ok,#16a34a)':'';
	}
	form.addEventListener('change',function(e){ if(e.target.classList.contains('gl-chk'))refresh(); });
	// Délettrage : utiliser les cases des lignes déjà lettrées.
	document.getElementById('gl-delet').addEventListener('click',function(){
		form.querySelectorAll('.gl-chk-let:checked').forEach(function(b){
			var h=document.createElement('input');h.type='hidden';h.name='ids[]';h.value=b.value;form.appendChild(h);
		});
	});
	refresh();
})();
</script>
