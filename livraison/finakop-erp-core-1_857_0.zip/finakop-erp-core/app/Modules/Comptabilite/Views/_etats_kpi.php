<?php
/**
 * BANDE D'INDICATEURS DES ÉTATS FINANCIERS (1.853.0).
 *
 * Quatre chiffres qu'un dirigeant cherche avant de lire une liasse, avec
 * leur évolution sur N-1. Ils viennent de FKC_EtatsDgi::synthese(), qui les
 * lit sur les états eux-mêmes : un indicateur ne peut pas contredire le
 * tableau affiché dessous.
 *
 * @var array  $synthese Sortie de FKC_EtatsDgi::synthese()
 * @var string $systeme  'smt' | 'sn'
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
if ( empty( $synthese ) || ! is_array( $synthese ) ) { return; }
$sys = ( 'sn' === ( $systeme ?? 'smt' ) ) ? 'sn' : 'smt';
$tuiles = array(
	array( 'ca', 'sn' === $sys ? "Chiffre d'affaires" : 'Recettes sur produits', 'kpi-ca', 'sn' === $sys ? 'XB' : 'KX' ),
	array( 'resultat', 'Résultat net', (float) $synthese['resultat']['n'] >= 0 ? 'kpi-pos' : 'kpi-neg', 'sn' === $sys ? 'XI' : 'H' ),
	array( 'tresorerie', 'Trésorerie nette', (float) $synthese['tresorerie']['n'] >= 0 ? 'kpi-treso' : 'kpi-neg', 'sn' === $sys ? 'BT − DT' : 'GD + GF' ),
	array( 'total', 'Total du bilan', 'kpi-bilan', 'sn' === $sys ? 'BZ' : 'GZ' ),
);
?>
<div class="ef-kpis" role="list">
	<?php foreach ( $tuiles as $t ) : $k = $synthese[ $t[0] ]; $var = $k['var']; ?>
		<div class="ef-kpi <?= e( $t[2] ) ?>" role="listitem">
			<span class="ef-kpi-lbl"><?= e( $t[1] ) ?> <em><?= e( $t[3] ) ?></em></span>
			<span class="ef-kpi-val"><?= e( fkc_money( $k['n'] ) ) ?> <small>F CFA</small></span>
			<span class="ef-kpi-foot">
				<?php if ( null !== $var ) : ?>
					<span class="ef-trend <?= $var >= 0 ? 'up' : 'down' ?>"><?= $var >= 0 ? '▲' : '▼' ?> <?= e( number_format( abs( $var ), 1, ',', ' ' ) ) ?> %</span>
				<?php endif; ?>
				<span class="muted">N-1 : <?= e( fkc_money( $k['n1'] ) ) ?></span>
				<?php if ( 'resultat' === $t[0] && null !== ( $synthese['marge']['n'] ?? null ) ) : ?>
					<span class="muted">· marge nette <?= e( number_format( (float) $synthese['marge']['n'], 1, ',', ' ' ) ) ?> %</span>
				<?php endif; ?>
			</span>
		</div>
	<?php endforeach; ?>
</div>
