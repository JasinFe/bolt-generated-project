<?php /** @var array $clients @var float $total @var int $nb @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card">
	<div class="card-body" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
		<div><span class="muted">Total créances clients (factures certifiées non encaissées)</span>
			<div style="font-size:1.8em;font-weight:700;color:var(--orange)"><?= e( fkc_money( $total ) ) ?> FCFA</div></div>
		<div class="muted"><?= (int) $nb ?> client(s) débiteur(s)</div>
	</div>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Client</th><th class="num">Facturé</th><th class="num">Encaissé</th><th class="num">Solde dû</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $clients ) : ?><tr><td colspan="5" class="empty">Aucune créance client en cours.</td></tr>
	<?php else : foreach ( $clients as $c ) : $s = $c['solde_info']; ?>
		<tr>
			<td><strong><?= e( $c['nom'] ) ?></strong></td>
			<td class="num"><?= e( fkc_money( $s['facture'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $s['encaisse'] ) ) ?></td>
			<td class="num" style="color:var(--orange)"><?= e( fkc_money( $s['solde'] ) ) ?></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/clients/' . (int) $c['id'] . '/encaisser' ) ) ?>">Encaisser</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $clients ) : ?><tfoot><tr class="total"><td class="right">Total</td><td></td><td></td><td class="num"><?= e( fkc_money( $total ) ) ?></td><td></td></tr></tfoot><?php endif; ?>
</table></div>
