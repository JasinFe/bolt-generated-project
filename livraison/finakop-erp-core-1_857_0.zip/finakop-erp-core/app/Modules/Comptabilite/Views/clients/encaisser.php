<?php
/**
 * Encaissement d'un client — LA RÉPARTITION PAR FACTURE EST ICI.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * L'ÉCRAN NE POSAIT QU'UNE QUESTION, ET CE N'ÉTAIT PAS LA BONNE
 *
 * « Solde dû : 365 000 F. Montant encaissé : ___ ». L'utilisateur savait
 * combien il recevait, jamais sur quoi. Le poste client se soldait ensuite
 * par un lettrage au plus ancien — ce qui est faux dès que le client choisit
 * ce qu'il règle, et c'est le cas ordinaire.
 *
 * Les factures ouvertes sont donc listées, avec leur reste dû et leur
 * ancienneté, et chacune porte son montant affecté. Le total se recalcule à
 * la saisie. Rien n'oblige à répartir : laisser les lignes vides encaisse au
 * compte du client comme avant, et le FIFO s'applique. On ajoute une
 * possibilité, on n'en retire aucune.
 *
 * @var array  $client
 * @var array  $poste     Sortie de FKC_Imputation::postesClient().
 * @var int    $cible     Facture pré-sélectionnée (0 = aucune).
 * @var float  $montant   Montant proposé.
 * @var bool   $imputable La base sait-elle enregistrer l'imputation ?
 * @var array  $comptes
 * @var array  $modes
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ouvertes = $poste['ouvertes'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<div><span class="stat-label">Encaissement</span> <strong style="font-size:18px;font-family:Syne,sans-serif"><?= e( $client['nom'] ) ?></strong></div>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/clients' ) ) ?>">← Retour</a>
</div>

<form method="post" action="<?= e( url( 'comptabilite/clients/' . (int) $client['id'] . '/encaisser' ) ) ?>" id="encForm" enctype="multipart/form-data">
	<?= FKC_Csrf::field() ?>

	<div class="card">
		<div class="card-body" style="display:flex;gap:24px;flex-wrap:wrap">
			<div><span class="muted">Facturé</span><div style="font-size:1.2em"><?= e( fkc_money( $poste['facture'] ) ) ?> F</div></div>
			<div><span class="muted">Encaissé</span><div style="font-size:1.2em"><?= e( fkc_money( $poste['encaisse'] ) ) ?> F</div></div>
			<div><span class="muted">Reste dû</span><div style="font-size:1.2em;color:var(--orange)"><strong><?= e( fkc_money( $poste['du'] ) ) ?> F</strong></div></div>
			<div><span class="muted">Factures ouvertes</span><div style="font-size:1.2em"><?= (int) $poste['nb_ouvertes'] ?></div></div>
			<?php if ( $poste['credit'] > 0.5 ) : ?>
			<div><span class="muted">Crédit non affecté</span><div style="font-size:1.2em;color:var(--ok)"><?= e( fkc_money( $poste['credit'] ) ) ?> F</div></div>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( ! $imputable ) : ?>
		<div class="alert alert-err">Cette base n'a pas encore reçu la table d'imputation : l'encaissement sera lettré automatiquement au plus ancien. Rechargez une page après la mise à jour pour l'activer.</div>
	<?php endif; ?>

	<div class="card card-flush">
		<div class="card-head">
			<h2>Factures à encaisser</h2>
			<?php if ( $ouvertes ) : ?>
			<div style="display:flex;gap:8px">
				<button class="btn btn-ghost btn-sm" type="button" onclick="fkcEncRepartir()">Répartir au plus ancien</button>
				<button class="btn btn-ghost btn-sm" type="button" onclick="fkcEncVider()">Tout effacer</button>
			</div>
			<?php endif; ?>
		</div>
		<table class="table">
			<thead><tr><th>Facture</th><th>Date</th><th>Échéance</th><th>Ancienneté</th><th class="num">TTC</th><th class="num">Déjà réglé</th><th class="num">Reste dû</th><th class="num">À encaisser</th></tr></thead>
			<tbody>
			<?php if ( ! $ouvertes ) : ?>
				<tr><td colspan="8" class="empty">Aucune facture ouverte pour ce client. Un encaissement saisi ici sera porté à son crédit (acompte).</td></tr>
			<?php else : foreach ( $ouvertes as $p ) :
				$pre = ( 0 === (int) $cible || (int) $p['id'] === (int) $cible ) ? round( (float) $p['reste'] ) : ''; ?>
				<tr>
					<td><strong><?= e( $p['numero'] ) ?></strong></td>
					<td><?= e( date( 'd/m/Y', strtotime( $p['date_facture'] ) ) ) ?></td>
					<td><?= e( date( 'd/m/Y', strtotime( $p['echeance'] ) ) ) ?></td>
					<td><?php if ( $p['jours'] > 0 ) : ?><span style="color:<?= $p['jours'] > 60 ? 'var(--danger)' : 'var(--orange)' ?>"><?= (int) $p['jours'] ?> j</span><?php else : ?><span class="muted">Non échu</span><?php endif; ?></td>
					<td class="num"><?= e( fkc_money( $p['ttc'] ) ) ?></td>
					<td class="num"><?= $p['regle'] > 0.5 ? e( fkc_money( $p['regle'] ) ) : '—' ?></td>
					<td class="num" style="color:var(--orange)"><?= e( fkc_money( $p['reste'] ) ) ?></td>
					<td class="num">
						<input class="num fkc-imput" name="imput[<?= (int) $p['id'] ?>]" inputmode="decimal"
							data-reste="<?= e( round( (float) $p['reste'] ) ) ?>" value="<?= e( $pre ) ?>"
							style="width:130px;text-align:right" autocomplete="off">
					</td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
			<?php if ( $ouvertes ) : ?><tfoot><tr class="total">
				<td class="right" colspan="6">Total réparti</td>
				<td class="num"><?= e( fkc_money( $poste['du'] ) ) ?></td>
				<td class="num"><strong id="fkcEncTotal">—</strong></td>
			</tr></tfoot><?php endif; ?>
		</table>
	</div>

	<div class="card">
		<div class="card-head"><h2>Règlement</h2></div>
		<div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Montant encaissé</span>
					<input class="num" id="fkcEncMontant" name="montant" inputmode="decimal" required value="<?= e( $montant > 0 ? round( (float) $montant ) : '' ) ?>"></label>
				<label class="fld"><span>Compte de trésorerie</span>
					<select name="tresorerie_id" required><?php foreach ( $comptes as $c ) : ?><option value="<?= (int) $c['id'] ?>"><?= e( $c['libelle'] ) ?></option><?php endforeach; ?></select></label>
			</div>
			<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
				<label class="fld"><span>Date</span><input type="date" name="date_reglement" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld"><span>Mode</span><select name="mode"><?php foreach ( $modes as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Référence</span><input name="reference" autocomplete="off"></label>
			</div>
			<p class="help" id="fkcEncEcart" style="margin-top:8px"></p>
			<?php /* Justificatif de l'encaissement : avis de virement, reçu Mobile Money, bordereau de remise. */ ?>
			<?php $extGed = class_exists( 'FKC_GedDocument' ) ? array_keys( FKC_GedDocument::types() ) : array(); ?>
			<?php if ( $extGed ) : ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Justificatif <span class="muted">(avis de virement, reçu…)</span></span>
					<input type="file" name="piece" accept="<?= e( '.' . implode( ',.', $extGed ) ) ?>"></label>
				<label class="fld"><span>Intitulé de la pièce <span class="muted">(facultatif)</span></span>
					<input name="piece_titre" autocomplete="off"></label>
			</div>
			<?php endif; ?>

			<div class="actions">
				<button class="btn btn-primary" type="submit">Encaisser</button>
				<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/clients' ) ) ?>">Annuler</a>
			</div>
			<p class="help" style="margin-top:8px">Écriture générée : trésorerie (débit) / compte du client (crédit). Les factures renseignées ci-dessus sont lettrées nommément ; le reliquat éventuel est porté au crédit du client.</p>
		</div>
	</div>
</form>

<?php
/* Règlements déjà enregistrés, et le geste pour en annuler un (1.745.0). */
FKC_View::partial( '_reglements_tiers', array( 'reglements' => $reglements ?? array(),
	'retour' => 'comptabilite/clients/' . (int) $client['id'] . '/encaisser', 'titre' => 'Encaissements enregistrés' ) );
?>
<script>
/*
 * Aide à la saisie, jamais une contrainte : le serveur revalide tout, et
 * l'écran reste utilisable sans JavaScript (les champs sont des champs, le
 * formulaire part quand même).
 */
(function () {
	var form = document.getElementById('encForm');
	if (!form) { return; }
	var champs  = Array.prototype.slice.call(form.querySelectorAll('.fkc-imput'));
	var total   = document.getElementById('fkcEncTotal');
	var montant = document.getElementById('fkcEncMontant');
	var ecart   = document.getElementById('fkcEncEcart');

	function lire(v) {
		v = String(v || '').replace(/[\s\u00a0\u202f']/g, '').replace(',', '.');
		var n = parseFloat(v);
		return isNaN(n) ? 0 : n;
	}
	function fmt(n) { return Math.round(n).toLocaleString('fr-FR').replace(/\u202f/g, ' '); }

	function recalculer(majMontant) {
		var s = 0;
		champs.forEach(function (c) { s += lire(c.value); });
		if (total) { total.textContent = s > 0 ? fmt(s) : '—'; }
		if (majMontant && s > 0) { montant.value = Math.round(s); }
		var m = lire(montant.value), d = m - s;
		if (!ecart) { return; }
		if (s > 0 && d > 0.5) {
			ecart.textContent = 'Reliquat de ' + fmt(d) + ' F : il sera porté au crédit du client (acompte).';
			ecart.style.color = 'var(--orange)';
		} else if (s > 0 && d < -0.5) {
			ecart.textContent = 'La répartition dépasse le montant encaissé de ' + fmt(-d) + ' F — l\u2019enregistrement sera refusé.';
			ecart.style.color = 'var(--danger)';
		} else {
			ecart.textContent = s > 0 ? 'Répartition équilibrée avec le montant encaissé.' : 'Aucune facture désignée : le règlement sera lettré au plus ancien.';
			ecart.style.color = '';
		}
	}

	champs.forEach(function (c) { c.addEventListener('input', function () { recalculer(true); }); });
	montant.addEventListener('input', function () { recalculer(false); });

	window.fkcEncRepartir = function () {
		var reste = lire(montant.value);
		champs.forEach(function (c) {
			var du = lire(c.dataset.reste);
			var p  = Math.min(reste, du);
			c.value = p > 0 ? Math.round(p) : '';
			reste -= p > 0 ? p : 0;
		});
		recalculer(false);
	};
	window.fkcEncVider = function () {
		champs.forEach(function (c) { c.value = ''; });
		recalculer(false);
	};
	recalculer(false);
})();
</script>
