<?php
/**
 * Postes clients — LA LISTE EST PAR FACTURE, PAS PAR CLIENT.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * DEUX CORRECTIFS DANS CE FICHIER (1.731.0)
 *
 * 1. LE `</div>` MANQUANT. Le bloc « Nouveau client » ouvrait un `card` en
 *    `display:none` et ne le refermait jamais. Tout ce qui suivait — la barre
 *    de recherche ET le tableau entier — se retrouvait imbriqué dedans, donc
 *    invisible. L'écran d'encaissement paraissait vide, et n'affichait ses
 *    lignes qu'après un clic sur « + Nouveau client », qui rendait le
 *    conteneur visible par effet de bord. Une balise, un écran inutilisable.
 *
 * 2. LA VUE PAR DÉFAUT. Même réparée, la liste ne montrait que des soldes
 *    globaux par client : impossible de savoir QUELLE facture encaisser. Les
 *    factures ouvertes passent devant, la vue par client reste à un clic.
 *
 * @var array      $postes     Factures ouvertes (poste, ancienneté, reste dû).
 * @var array      $clients    Clients avec encours consolidé.
 * @var string     $vue        'factures' | 'clients'
 * @var float      $totalDu    Encours total.
 * @var int        $nbOuvertes Nombre de factures ouvertes.
 * @var float      $orphelines Créances sans fiche client.
 * @var float      $credits    Crédits non affectés.
 * @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$vueFactures = 'clients' !== $vue;
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<div>
		<span class="stat-label">Total créances clients</span>
		<strong style="font-size:20px;font-family:Syne,sans-serif;color:var(--orange)"><?= e( fkc_money( $totalDu ) ) ?> F</strong>
		<span class="muted" style="margin-left:10px"><?= (int) $nbOuvertes ?> facture<?= $nbOuvertes > 1 ? 's' : '' ?> ouverte<?= $nbOuvertes > 1 ? 's' : '' ?></span>
	</div>
	<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
		<a class="btn btn-sm <?= $vueFactures ? 'btn-primary' : 'btn-ghost' ?>" href="<?= e( url( 'comptabilite/clients' ) ) ?>">Par facture</a>
		<a class="btn btn-sm <?= $vueFactures ? 'btn-ghost' : 'btn-primary' ?>" href="<?= e( url( 'comptabilite/clients?vue=clients' ) ) ?>">Par client</a>
		<button class="btn btn-ghost btn-sm" type="button" onclick="var n=document.getElementById('nc');n.style.display=('none'===n.style.display?'block':'none')">+ Nouveau client</button>
	</div>
</div>

<?php if ( $orphelines > 0.5 ) : ?>
<div class="alert alert-err">Créances sans fiche client rattachée : <strong><?= e( fkc_money( $orphelines ) ) ?> F</strong>. Elles figurent au grand livre mais ne peuvent pas être encaissées depuis cet écran — rattachez la facture à un client.</div>
<?php endif; ?>
<?php if ( $credits > 0.5 ) : ?>
<div class="alert" style="background:var(--bg2);border:1px solid var(--line);color:var(--text)">Encaissements non affectés à une facture : <strong><?= e( fkc_money( $credits ) ) ?> F</strong> (avances reçues, doubles saisies, ventes comptant sans facture).</div>
<?php endif; ?>

<div class="card" id="nc" style="display:none">
	<div class="card-head"><h2>Nouveau client</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'comptabilite/clients' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:2fr 1fr 1fr">
				<label class="fld"><span>Nom / Raison sociale</span><input name="nom" required></label>
				<label class="fld"><span>Type</span><select name="type"><option value="B2C">Particulier</option><option value="B2B">Entreprise</option></select></label>
				<label class="fld"><span>NCC</span><input name="ncc" class="code"></label>
			</div>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Téléphone</span><input name="telephone"></label>
				<label class="fld"><span>Email</span><input name="email" type="email"></label>
			</div>
			<div class="actions"><button class="btn btn-primary btn-sm" type="submit">Créer</button></div>
		</form>
	</div>
</div><?php /* CE `</div>` EST LE CORRECTIF : sans lui, tout le reste de la page était avalé par un conteneur masqué. */ ?>

<?php if ( $vueFactures ) : ?>

	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : facture, client, montant…' ) ); ?>
	<div class="card card-flush"><table class="table">
		<thead><tr>
			<th>Facture</th><th>Client</th><th>Date</th><th>Échéance</th>
			<th class="num">Montant TTC</th><th class="num">Déjà réglé</th><th class="num">Reste dû</th><th>Ancienneté</th><th></th>
		</tr></thead>
		<tbody>
		<?php if ( ! $postes ) : ?>
			<tr><td colspan="9" class="empty">Aucune facture à encaisser — toutes les créances clients sont soldées.</td></tr>
		<?php else : foreach ( $postes as $p ) :
			$regle = max( 0, (float) ( $p['ttc'] ?? 0 ) - (float) $p['montant'] );
			$tard  = (int) $p['jours']; ?>
			<tr>
				<td><strong><?= e( ( ! empty( $p['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $p['source'] ) . ' ' : '' ) . ( '' !== (string) ( $p['numero'] ?? '' ) ? $p['numero'] : ( '#' . (int) $p['facture_id'] ) ) ) ?></strong></td>
				<td><?= e( $p['client_nom'] ) ?><?php if ( ! empty( $p['suspendu'] ) ) : ?> <span class="modbadge b-off" title="<?= e( $p['suspendu'] ) ?>">suspendu</span><?php endif; ?></td>
				<td><?= e( date( 'd/m/Y', strtotime( $p['date_facture'] ) ) ) ?></td>
				<td><?= e( date( 'd/m/Y', strtotime( $p['echeance'] ) ) ) ?></td>
				<td class="num"><?= e( fkc_money( $p['ttc'] ?? $p['montant'] ) ) ?></td>
				<td class="num"><?= $regle > 0.5 ? e( fkc_money( $regle ) ) : '—' ?></td>
				<td class="num" style="color:var(--orange)"><strong><?= e( fkc_money( $p['montant'] ) ) ?></strong></td>
				<td><?php if ( $tard > 0 ) : ?><span style="color:<?= $tard > 60 ? 'var(--danger)' : 'var(--orange)' ?>"><?= (int) $tard ?> j de retard</span><?php else : ?><span class="muted">Non échu</span><?php endif; ?></td>
				<td class="right">
					<?php
					/*
					 * Créance d'une source (cotisation, loyer, scolarité, pièce de
					 * dossier — 1.841.6) : pas de facture à viser. Elle s'encaisse
					 * depuis son module quand il la lettre, sinon sur le compte
					 * du client sans facture désignée.
					 */
					$srcRoute = ! empty( $p['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::routeEncaissement( $p['source'] ) : '';
					if ( ! empty( $p['source'] ) && '' !== $srcRoute ) : ?>
						<a class="btn btn-ghost btn-sm" href="<?= e( url( $srcRoute ) ) ?>" title="S'encaisse depuis son module, qui la lettre à la pièce">Encaisser (<?= e( FKC_RecouvrementSources::court( $p['source'] ) ) ?>)</a>
					<?php elseif ( ! empty( $p['source'] ) && (int) $p['client_id'] > 0 ) : ?>
						<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/clients/' . (int) $p['client_id'] . '/encaisser' ) ) ?>">Encaisser</a>
					<?php elseif ( (int) $p['client_id'] > 0 ) : ?>
						<a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/clients/' . (int) $p['client_id'] . '/encaisser?facture=' . (int) $p['facture_id'] ) ) ?>">Encaisser</a>
					<?php else : ?>
						<span class="muted">Client à rattacher</span>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( $postes ) : ?><tfoot><tr class="total">
			<td class="right" colspan="6">Total à encaisser</td>
			<td class="num"><?= e( fkc_money( $totalDu ) ) ?></td><td></td><td></td>
		</tr></tfoot><?php endif; ?>
	</table></div>

<?php else : ?>

	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : nom, compte, NCC, téléphone…' ) ); ?>
	<div class="card card-flush"><table class="table">
		<thead><tr><th>Client</th><th>Type</th><th class="num">Facturé</th><th class="num">Encaissé</th><th class="num">Factures ouvertes</th><th class="num">Solde dû</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $clients ) : ?><tr><td colspan="7" class="empty">Aucun client.</td></tr>
		<?php else : foreach ( $clients as $c ) : ?>
			<tr>
				<td><strong><?= e( $c['nom'] ) ?></strong></td>
				<td><span class="modbadge <?= 'B2B' === $c['type'] ? 'b-on' : 'b-off' ?>"><?= e( $c['type'] ) ?></span></td>
				<td class="num"><?= e( fkc_money( $c['facture'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $c['encaisse'] ) ) ?></td>
				<td class="num"><?= $c['nb_ouvertes'] > 0 ? (int) $c['nb_ouvertes'] : '—' ?></td>
				<td class="num" style="color:<?= $c['encours'] > 0 ? 'var(--orange)' : 'var(--ok)' ?>"><?= e( fkc_money( $c['encours'] ) ) ?></td>
				<td class="right"><a class="btn <?= $c['encours'] > 0 ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="<?= e( url( 'comptabilite/clients/' . (int) $c['id'] . '/encaisser' ) ) ?>">Encaisser</a></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>

<?php endif; ?>
