<?php
/**
 * Bandeau « Solde d'ouverture » commun au Grand Livre et à la Balance.
 *
 * 1.798.0 — dit d'où vient le solde d'ouverture affiché.
 * 1.799.0 — UNE OUVERTURE NON FIABLE N'EST JAMAIS PRÉSENTÉE COMME NORMALE.
 * Quand plusieurs sources d'ouverture existent, ou que l'ouverture effective
 * ne reprend pas la clôture précédente, ou qu'elle en hérite, le bandeau
 * devient un avertissement rouge : il nomme chaque source (avec son lien),
 * dit ce que l'ouverture devait être, ce qu'elle est, l'écart — et il
 * s'IMPRIME : un Grand Livre sorti sur papier ne doit pas perdre l'alerte.
 *
 * @var array|null $ctx contexte de FKC_SoldeOuverture::ouverture()
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
if ( empty( $ctx ) ) { return; }
$exo = (int) $ctx['exercice'];
$lienAudit = url( 'comptabilite/cloture/audit-anouveaux?annee=' . $exo );
$fiable = ! array_key_exists( 'fiable', $ctx ) || ! empty( $ctx['fiable'] );
if ( ! $fiable ) :
	$ambigu = ( 'ambigu' === ( $ctx['etat'] ?? '' ) );
	$t = $ctx['totaux'] ?? null;
	$dc = function ( $v ) { return fkc_money( abs( (float) $v ) ); };
	?>
<div class="fkc-ouv-alerte" role="alert" style="margin:0 0 14px;padding:12px 16px;border-radius:10px;border:2px solid #d64545;background:rgba(214,69,69,.09)">
	<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
		<strong style="color:#d64545;letter-spacing:.02em">🔴 <?= $ambigu ? 'OUVERTURE ANORMALE — PLUSIEURS SOURCES D\'OUVERTURE DÉTECTÉES' : 'OUVERTURE NON FIABLE' ?> (<?= $exo ?>)</strong>
		<a class="btn btn-sm fkc-noprint" style="margin-left:auto;background:#d64545;color:#fff;border-color:#d64545" href="<?= e( $lienAudit ) ?>">Voir l'Audit des À-nouveaux</a>
	</div>
	<p style="margin:8px 0 6px"><strong>Les soldes d'ouverture ne sont pas considérés comme fiables.</strong> <?= e( implode( ' ', (array) ( $ctx['raisons'] ?? array() ) ) ) ?></p>
	<?php if ( ! empty( $ctx['sources'] ) || ! empty( $ctx['report_calcule'] ) ) : ?>
		<ul style="margin:4px 0 6px;padding-left:18px">
			<?php if ( ! empty( $ctx['report_calcule'] ) ) : ?><li>Report calculé de la clôture <?= $exo - 1 ?> (aucun À-nouveaux)</li><?php endif; ?>
			<?php foreach ( (array) $ctx['sources'] as $s ) : ?>
				<li><?= e( $s['libelle_type'] ) ?> : <a href="<?= e( url( 'comptabilite/ecritures/' . (int) $s['id'] ) ) ?>">#<?= (int) $s['id'] ?></a>
					<span class="muted">— <?= e( date( 'd/m/Y', strtotime( $s['date'] ) ) . ' · ' . $s['journal'] . ( $s['reference'] ? ' · ' . $s['reference'] : ( $s['piece'] ? ' · ' . $s['piece'] : '' ) ) . ' · ' . fkc_money( $s['montant'] ) ) ?></span></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php if ( $t && ! empty( $t['attendu'] ) ) : ?>
		<div style="display:flex;flex-wrap:wrap;gap:6px 18px;font-size:12.5px">
			<span>Clôture <?= $exo - 1 ?> (attendu) : <strong><?= e( $dc( $t['attendu'] ) ) ?></strong></span>
			<span>Ouverture effective : <strong><?= e( $dc( $t['effectif'] ) ) ?></strong></span>
			<span style="color:#d64545">Écart : <strong><?= ( $t['ecart'] >= 0 ? '+' : '−' ) . e( $dc( $t['ecart'] ) ) ?></strong></span>
		</div>
	<?php endif; ?>
</div>
<?php return; endif; ?>
<div class="fkc-noprint fkc-ouv-bandeau" style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:0 0 12px;padding:10px 14px;border-radius:10px;border:1px solid var(--line);background:<?= $ctx['alerte'] ? 'rgba(220,120,40,.08)' : 'rgba(40,160,90,.06)' ?>">
	<strong>Solde d'ouverture <?= e( date( 'd/m/Y', strtotime( $ctx['date'] ) ) ) ?></strong>
	<?php if ( 'an' === $ctx['mode'] ) : ?>
		<span class="modbadge b-on">À-nouveaux officiel</span>
		<span class="muted">L'écriture d'À-nouveaux #<?= e( implode( ', #', (array) $ctx['an_ids'] ) ) ?> est le seul mouvement d'ouverture — aucun solde virtuel ne s'y ajoute.</span>
	<?php elseif ( 'autre_source' === $ctx['mode'] ) : ?>
		<span class="modbadge">Source unique</span>
		<span class="muted">L'exercice s'ouvre par une seule écriture, qui n'est pas un À-nouveaux FinaKop<?= ! empty( $ctx['sources'][0] ) ? ' (' . e( $ctx['sources'][0]['libelle_type'] . ' #' . $ctx['sources'][0]['id'] ) . ')' : '' ?>.</span>
	<?php elseif ( 'calcule' === $ctx['mode'] ) : ?>
		<span class="modbadge b-err">Solde calculé</span>
		<span class="muted"><?= e( $ctx['alerte'] ) ?></span>
	<?php elseif ( 'initial' === $ctx['mode'] ) : ?>
		<span class="modbadge">Premier exercice</span>
		<span class="muted">Aucun solde antérieur à reprendre.</span>
	<?php else : ?>
		<span class="modbadge">Solde antérieur</span>
		<span class="muted">Période en cours d'exercice <?= $exo ?> : solde d'ouverture <?= $ctx['an_ids'] ? '(À-nouveaux compris)' : '(calculé, aucun À-nouveaux)' ?> et mouvements antérieurs à la date.</span>
	<?php endif; ?>
	<a class="btn btn-ghost btn-sm" style="margin-left:auto" href="<?= e( $lienAudit ) ?>">Audit des À-nouveaux</a>
</div>
