<?php /** @var array $compte @var array $mouvements @var float $solde @var float $soldePointe @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ecart = $solde - $soldePointe; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Rapprochement — <?= e( $compte['libelle'] ) ?> <span class="muted" style="font-size:12px">(<?= e($compte['compte_numero']) ?>)</span></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/tresorerie') ) ?>">← Trésorerie</a></div>
	<div class="card-body"><div class="stats" style="margin:0">
		<div class="stat"><span class="stat-label">Solde comptable</span><span class="stat-value" style="font-size:20px"><?= e( fkc_money($solde) ) ?></span></div>
		<div class="stat"><span class="stat-label">Solde pointé</span><span class="stat-value" style="font-size:20px"><?= e( fkc_money($soldePointe) ) ?></span></div>
		<div class="stat <?= abs($ecart)<1?'':'stat-accent' ?>"><span class="stat-label">Écart (non pointé)</span><span class="stat-value" style="font-size:20px;color:<?= abs($ecart)<1?'var(--ok)':'var(--orange)' ?>"><?= e( fkc_money($ecart) ) ?></span></div>
	</div></div>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Pointé</th><th>Date</th><th>Libellé</th><th>Réf.</th><th class="num">Montant</th></tr></thead>
	<tbody>
	<?php if ( ! $mouvements ) : ?><tr><td colspan="5" class="empty">Aucun mouvement.</td></tr>
	<?php else : foreach ( $mouvements as $m ) : $in='encaissement'===$m['sens']; $vir='virement'===$m['sens']; $entrant = $vir ? ((int)$m['tresorerie_dest_id']===(int)$compte['id']) : $in; ?>
		<tr style="<?= $m['pointe']?'opacity:.6':'' ?>">
			<td><form method="post" action="<?= e( url('comptabilite/tresorerie/pointe/'.$m['id']) ) ?>" style="margin:0">
				<?= FKC_Csrf::field() ?><input type="hidden" name="tresorerie_id" value="<?= (int)$compte['id'] ?>">
				<button type="submit" class="point-btn <?= $m['pointe']?'on':'' ?>" title="Pointer"><?= $m['pointe']?'✓':'' ?></button></form></td>
			<td class="num"><?= e( date('d/m/Y', strtotime($m['date_reglement'])) ) ?></td>
			<td><?= e( $m['libelle'] ) ?></td><td class="muted"><?= e( $m['reference'] ?: '—' ) ?></td>
			<td class="num" style="color:<?= $entrant?'var(--ok)':'var(--danger)' ?>"><?= $entrant?'+':'−' ?><?= e( fkc_money($m['montant']) ) ?></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
<style>.point-btn{width:26px;height:26px;border-radius:6px;border:1px solid var(--line2);background:var(--bg2);color:var(--ok);cursor:pointer;font-weight:800}.point-btn.on{background:var(--ok-bg);border-color:var(--ok)}</style>
