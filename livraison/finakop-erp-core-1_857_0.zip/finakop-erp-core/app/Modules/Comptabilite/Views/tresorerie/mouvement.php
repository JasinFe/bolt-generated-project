<?php
/**
 * Trésorerie · Mouvement (détail et justificatifs ajoutés en 1.754.0).
 *
 * @var string $sens @var array $comptes @var array $plan @var array $modes @var array $errors
 * @var string $tab @var array|null $copie @var array|null $saisie @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$titre = array( 'encaissement' => 'Encaissement', 'decaissement' => 'Décaissement', 'virement' => 'Virement interne' )[ $sens ];
$vir = 'virement' === $sens;
$copie = $copie ?? null;
$saisie = $saisie ?? null;
/* La saisie refusée prime sur la reprise : c'est la plus récente des deux. */
$v = function ( $cle, $defautCopie = null ) use ( $saisie, $copie ) {
	if ( is_array( $saisie ) && array_key_exists( $cle, $saisie ) ) { return (string) $saisie[ $cle ]; }
	if ( is_array( $copie ) && null !== $defautCopie ) { return (string) $defautCopie; }
	return '';
};
$lignesDetail = array();
if ( is_array( $saisie ) && ! empty( $saisie['detail'] ) && is_array( $saisie['detail'] ) ) {
	foreach ( $saisie['detail'] as $l ) {
		$lignesDetail[] = array( 'designation' => (string) ( $l['designation'] ?? '' ), 'compte_id' => (int) ( $l['compte_id'] ?? 0 ), 'montant' => (string) ( $l['montant'] ?? '' ) );
	}
} elseif ( $copie && ! empty( $copie['detail'] ) ) {
	foreach ( $copie['detail'] as $l ) {
		$lignesDetail[] = array( 'designation' => (string) $l['designation'], 'compte_id' => (int) $l['compte_id'], 'montant' => (string) round( (float) $l['montant'], 2 ) );
	}
}
$nbVides = max( 0, 3 - count( $lignesDetail ) );
for ( $i = 0; $i < $nbVides; $i++ ) { $lignesDetail[] = array( 'designation' => '', 'compte_id' => 0, 'montant' => '' ); }
$optCompte = function ( $sel ) use ( $plan ) {
	$out = '<option value="">— choisir —</option>';
	foreach ( $plan as $c ) {
		$out .= '<option value="' . (int) $c['id'] . '"' . ( (int) $sel === (int) $c['id'] ? ' selected' : '' ) . '>' . e( $c['numero'] . ' ' . $c['libelle'] ) . '</option>';
	}
	return $out;
};
$flashType = ( $flash && 'err' === ( $flash['type'] ?? '' ) ) ? 'err' : 'ok';
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= e( $flashType ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<?php if ( $copie ) : ?>
	<div class="alert alert-warn">Reprise du mouvement du <?= e( date( 'd/m/Y', strtotime( (string) $copie['date_reglement'] ) ) ) ?>
		(<?= e( fkc_money( $copie['montant'] ) ) ?> F<?= $copie['reference'] ? ' · ' . e( $copie['reference'] ) : '' ?>).
		<?= FKC_Reglement::estAnnule( $copie ) ? 'L\'original est annulé' : 'L\'original reste en place' ?> : cette saisie crée un NOUVEAU mouvement.</div>
<?php endif; ?>

<div class="card" style="max-width:920px"><div class="card-head"><h2><?= e( $titre ) ?></h2></div><div class="card-body">
<form method="post" action="<?= e( url( 'comptabilite/tresorerie/mouvement' ) ) ?>" enctype="multipart/form-data" id="mvt-form">
	<?= FKC_Csrf::field() ?><input type="hidden" name="sens" value="<?= e( $sens ) ?>">
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span><?= $vir ? 'Compte source' : 'Compte de trésorerie' ?></span>
			<select name="tresorerie_id" required>
				<?php foreach ( $comptes as $c ) : ?><option value="<?= (int) $c['id'] ?>" <?= (int) $v( 'tresorerie_id', $copie['tresorerie_id'] ?? null ) === (int) $c['id'] ? 'selected' : '' ?>><?= e( $c['libelle'] ) ?> (<?= e( $c['compte_numero'] ) ?>)</option><?php endforeach; ?>
			</select></label>
		<?php if ( $vir ) : ?>
		<label class="fld"><span>Compte destination</span>
			<select name="tresorerie_dest_id" required>
				<?php foreach ( $comptes as $c ) : ?><option value="<?= (int) $c['id'] ?>" <?= (int) $v( 'tresorerie_dest_id', $copie['tresorerie_dest_id'] ?? null ) === (int) $c['id'] ? 'selected' : '' ?>><?= e( $c['libelle'] ) ?> (<?= e( $c['compte_numero'] ) ?>)</option><?php endforeach; ?>
			</select></label>
		<?php else : ?>
		<label class="fld"><span>Contrepartie (compte SYSCOHADA)</span>
			<select name="contrepartie_compte_id" id="mvt-contrepartie" required><?= $optCompte( $v( 'contrepartie_compte_id', $copie['contrepartie_compte_id'] ?? null ) ) ?></select>
			<small class="help">Sert de contrepartie par défaut aux lignes de détail qui n'en précisent pas.</small></label>
		<?php endif; ?>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
		<label class="fld"><span>Montant</span><input class="num" id="mvt-montant" name="montant" value="<?= e( $v( 'montant', isset( $copie['montant'] ) ? round( (float) $copie['montant'], 2 ) : null ) ) ?>" required></label>
		<label class="fld"><span>Date</span><input type="date" name="date_reglement" value="<?= e( $v( 'date_reglement', null ) ?: date( 'Y-m-d' ) ) ?>"></label>
		<label class="fld"><span>Mode</span><select name="mode">
			<?php foreach ( $modes as $k => $m ) : $lbl = is_array( $m ) ? ( $m['label'] ?? $k ) : $m; ?>
				<option value="<?= e( $k ) ?>" <?= $v( 'mode', $copie['mode'] ?? null ) === (string) $k ? 'selected' : '' ?>><?= e( $lbl ) ?></option>
			<?php endforeach; ?>
		</select></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Référence</span><input name="reference" value="<?= e( $v( 'reference', $copie['reference'] ?? null ) ) ?>"></label>
		<label class="fld"><span>Libellé</span><input name="libelle" placeholder="(optionnel)" value="<?= e( $v( 'libelle', $copie['libelle'] ?? null ) ) ?>"></label>
	</div>

	<?php if ( ! $vir ) : ?>
	<?php
	/*
	 * IMPUTATION ANALYTIQUE.
	 *
	 * La division dit « quelle entité de l'entreprise » ; l'axe et la valeur
	 * disent « selon quel autre découpage » (projet, chantier, artiste…). Les
	 * trois sont portés par les lignes de CONTREPARTIE — la charge ou le
	 * produit — jamais par la ligne de trésorerie : une sortie de caisse
	 * n'appartient à aucune division, c'est ce qu'on achète avec qui lui
	 * appartient.
	 */
	$anaCols = ( ! empty( $showDivision ) && ! empty( $divisions ) ? 1 : 0 ) + ( ! empty( $showAxes ) ? 2 : 0 );
	$anaDiv  = (int) ( $copie['division_id'] ?? 0 );
	?>
	<?php if ( $anaCols > 0 ) : ?>
	<h3 class="mvt-h3">Imputation analytique <span class="muted">(facultatif)</span></h3>
	<div class="form-grid" style="grid-template-columns:repeat(<?= (int) max( 1, $anaCols ) ?>,1fr)">
		<?php if ( ! empty( $showDivision ) && ! empty( $divisions ) ) : ?>
			<label class="fld"><span>Division (analytique)</span>
				<select name="division_id">
					<option value="">— non imputé —</option>
					<?php foreach ( $divisions as $dv ) : ?><option value="<?= (int) $dv['id'] ?>" <?= $anaDiv === (int) $dv['id'] ? 'selected' : '' ?>><?= e( $dv['libelle'] ) ?></option><?php endforeach; ?>
				</select>
			</label>
		<?php endif; ?>
		<?php if ( ! empty( $showAxes ) ) : ?>
			<label class="fld"><span>Axe analytique</span>
				<select name="axe_id" id="mvt-axe">
					<option value="">— aucun axe —</option>
					<?php foreach ( $axes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['code'] . ' · ' . $a['libelle'] ) ?></option><?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Valeur analytique</span>
				<select name="valeur_id" id="mvt-valeur"><option value="">— valeur —</option></select>
			</label>
		<?php endif; ?>
	</div>
	<p class="help">Portée par les lignes de contrepartie, pas par la ligne de trésorerie. Une valeur n'est retenue que si un axe l'est : seule, elle ne désignerait rien. Une ligne de détail peut porter sa propre division et l'emporte alors sur celle-ci.</p>
	<?php if ( ! empty( $showAxes ) ) : ?>
	<script>
	(function(){
		/* Même cascade axe → valeur que sur l'écran d'achat et la facture
		   client : un utilisateur ne devrait pas avoir à réapprendre. */
		var valeurs = <?= json_encode( $valeursMap ?? array(), JSON_UNESCAPED_UNICODE ) ?>;
		var axe = document.getElementById('mvt-axe'), val = document.getElementById('mvt-valeur');
		if (!axe || !val) { return; }
		function fill(){
			var list = valeurs[axe.value] || [];
			val.innerHTML = '<option value="">— valeur —</option>' + list.map(function(v){
				return '<option value="'+v.id+'">'+v.t+'</option>';
			}).join('');
		}
		axe.addEventListener('change', fill);
		fill();
	})();
	</script>
	<?php endif; ?>
	<?php endif; ?>

	<?php $anaDivCol = ! empty( $showDivision ) && ! empty( $divisions ); ?>
	<h3 class="mvt-h3">Détail du mouvement <span class="muted">(facultatif)</span></h3>
	<p class="help" style="margin-top:0">Une ligne par nature de recette ou de dépense. Chaque ligne porte sa désignation au grand livre et,
		si besoin, sa propre contrepartie. Le montant du mouvement devient la somme des lignes.</p>
	<table class="table bordered mvt-detail" id="mvt-detail">
		<thead><tr><th style="width:38%">Désignation</th><th>Contrepartie</th><?php if ( $anaDivCol ) : ?><th style="width:170px">Division</th><?php endif; ?><th class="num" style="width:150px">Montant</th><th style="width:40px"></th></tr></thead>
		<tbody>
		<?php foreach ( $lignesDetail as $i => $l ) : ?>
			<tr>
				<td><input name="detail[<?= $i ?>][designation]" value="<?= e( $l['designation'] ) ?>" placeholder="ex. Recette studio du 12"></td>
				<td><select name="detail[<?= $i ?>][compte_id]"><?= $optCompte( $l['compte_id'] ) ?></select></td>
				<?php if ( $anaDivCol ) : ?>
					<?php /* Division propre à la ligne : elle l'emporte sur celle du mouvement. Laissée vide, la ligne suit le mouvement — c'est le cas courant. */ ?>
					<td><select name="detail[<?= $i ?>][division_id]"><option value="">— du mouvement —</option><?php foreach ( $divisions as $dv ) : ?><option value="<?= (int) $dv['id'] ?>" <?= (int) ( $l['division_id'] ?? 0 ) === (int) $dv['id'] ? 'selected' : '' ?>><?= e( $dv['libelle'] ) ?></option><?php endforeach; ?></select></td>
				<?php endif; ?>
				<td><input class="num mvt-ligne-montant" name="detail[<?= $i ?>][montant]" value="<?= e( $l['montant'] ) ?>" inputmode="decimal"></td>
				<td class="num"><button type="button" class="btn btn-ghost btn-sm mvt-suppr" title="Vider la ligne">🗑</button></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr><th colspan="<?= $anaDivCol ? 3 : 2 ?>" class="right">Total du détail</th><th class="num" id="mvt-total">0</th><th></th></tr></tfoot>
	</table>
	<button type="button" class="btn btn-ghost btn-sm" id="mvt-ajouter">+ Ajouter une ligne</button>
	<p class="help" id="mvt-avert" hidden>Le détail est renseigné : le montant du mouvement suit la somme des lignes.</p>

	<h3 class="mvt-h3">Justificatifs <span class="muted">(facultatif)</span></h3>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Fichiers (reçu Wave, avis de virement, bordereau…)</span>
			<input type="file" name="pieces[]" multiple></label>
		<label class="fld"><span>Titre de la pièce</span><input name="piece_titre" placeholder="(repris du mouvement si vide)"></label>
	</div>
	<p class="help">Classés en GED sous « Justificatifs de règlement » et rouvrables depuis le mouvement.</p>
	<?php endif; ?>

	<div class="actions"><button class="btn btn-primary" type="submit">Enregistrer</button><a class="btn btn-ghost" href="<?= e( url( 'comptabilite/tresorerie' ) ) ?>">Annuler</a></div>
	<p class="help" style="margin-top:8px">Une écriture comptable équilibrée sera générée automatiquement (journal <?= $vir ? 'OD' : 'BQ/CA' ?>).</p>
</form>
</div></div>
<?php if ( ! $vir ) : ?>
<script>
(function () {
	var table = document.getElementById('mvt-detail'); if (!table) { return; }
	var corps = table.querySelector('tbody');
	var montant = document.getElementById('mvt-montant');
	var total = document.getElementById('mvt-total');
	var avert = document.getElementById('mvt-avert');
	function lire(v) {
		v = String(v || '').replace(/[\s\u00A0\u202F%]/g, '').replace(/\.(?=\d{3}\b)/g, '').replace(',', '.');
		var n = parseFloat(v); return isNaN(n) ? 0 : n;
	}
	function fmt(n) { return n.toLocaleString('fr-FR', { maximumFractionDigits: 2 }); }
	function maj() {
		var somme = 0, remplies = 0;
		corps.querySelectorAll('.mvt-ligne-montant').forEach(function (i) {
			var n = lire(i.value); if (n > 0) { remplies++; somme += n; }
		});
		total.textContent = fmt(somme);
		if (remplies > 0) {
			montant.value = somme ? String(Math.round(somme * 100) / 100).replace('.', ',') : '';
			montant.readOnly = true; avert.hidden = false;
		} else {
			montant.readOnly = false; avert.hidden = true;
		}
	}
	corps.addEventListener('input', maj);
	corps.addEventListener('click', function (ev) {
		var b = ev.target.closest('.mvt-suppr'); if (!b) { return; }
		var tr = b.closest('tr');
		tr.querySelectorAll('input').forEach(function (i) { i.value = ''; });
		if (corps.rows.length > 1) { tr.remove(); }
		maj();
	});
	document.getElementById('mvt-ajouter').addEventListener('click', function () {
		var tr = corps.rows[corps.rows.length - 1].cloneNode(true);
		var n = corps.rows.length;
		tr.querySelectorAll('input, select').forEach(function (i) {
			i.name = i.name.replace(/detail\[\d+\]/, 'detail[' + n + ']');
			if (i.tagName === 'INPUT') { i.value = ''; } else { i.selectedIndex = 0; }
		});
		corps.appendChild(tr);
	});
	maj();
})();
</script>
<style>
.mvt-h3{font-size:14px;margin:18px 0 6px;font-family:Syne,sans-serif}
.mvt-detail input,.mvt-detail select{width:100%}
.mvt-detail td{padding:4px 6px}
</style>
<?php endif; ?>
