<?php /** @var array $comptes @var array $soldes @var float $total @var array $mouvements @var array $types @var array $modes @var array $derniersReglements @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$icon = array( 'caisse'=>'💵', 'banque'=>'🏦', 'mobile_money'=>'📱' );
$nonDeclares = $nonDeclares ?? array(); ?>
<?php if ( $nonDeclares ) : $sommeND = array_sum( array_map( fn( $c ) => (float) $c['solde'], $nonDeclares ) ); ?>
	<?php /* Le total affiché ne comptait que les comptes déclarés : ce bandeau nomme ce qui manquait au lieu de le taire. */ ?>
	<div class="alert alert-warn" style="margin-bottom:16px">
		⚠️ <strong><?= count( $nonDeclares ) ?> compte(s) de trésorerie mouvementés ne sont pas déclarés</strong>
		(<?= e( fkc_money( $sommeND ) ) ?> au total). Leurs soldes n'entrent ni dans le total ci-dessous, ni dans le cockpit.
		<div style="font-size:13px;margin-top:6px">
			<?php foreach ( array_slice( $nonDeclares, 0, 8 ) as $c ) : ?>
				<div><span class="code"><?= e( $c['numero'] ) ?></span> <?= e( $c['libelle'] ) ?> — <strong><?= e( fkc_money( $c['solde'] ) ) ?></strong></div>
			<?php endforeach; ?>
		</div>
		<form method="post" action="<?= e( url( 'comptabilite/tresorerie/declarer-manquants' ) ) ?>" style="margin-top:8px">
			<?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm">Déclarer ces comptes</button>
		</form>
	</div>
<?php endif; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<div><span class="stat-label">Trésorerie disponible</span> <strong style="font-size:22px;font-family:Syne,sans-serif;color:var(--orange)"><?= e( fkc_money( $total ) ) ?> FCFA</strong></div>
	<div style="display:flex;gap:8px">
		<a class="btn btn-primary btn-sm" href="<?= e( url('comptabilite/tresorerie/mouvement?sens=encaissement') ) ?>">+ Encaissement</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/tresorerie/mouvement?sens=decaissement') ) ?>">− Décaissement</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/tresorerie/mouvement?sens=virement') ) ?>">⇄ Virement</a>
	</div>
</div>

<div class="tres-grid">
	<?php foreach ( $comptes as $c ) : ?>
		<div class="tres-card">
			<div class="tres-top"><span class="tres-ico"><?= $icon[$c['type']] ?? '💼' ?></span>
				<div><strong><?= e( $c['libelle'] ) ?></strong><br><span class="muted" style="font-size:11px"><?= e( $c['compte_numero'] ) ?> · <?= e( $types[$c['type']] ?? $c['type'] ) ?></span></div>
			</div>
			<div class="tres-solde"><?= e( fkc_money( $soldes[$c['id']] ?? 0 ) ) ?> <span style="font-size:12px">F</span></div>
			<a class="tres-link" href="<?= e( url('comptabilite/tresorerie/rapprochement/'.$c['id']) ) ?>">Rapprochement →</a>
		</div>
	<?php endforeach; ?>
</div>

<div class="fac-layout" style="grid-template-columns:2fr 1fr;margin-top:20px">
	<div class="card card-flush" style="margin:0">
		<div class="card-head"><h2>Derniers mouvements</h2></div>
		<?php
		/*
		 * ÉTAT, DÉTAIL, JUSTIFICATIFS ET GESTES (1.754.0).
		 *
		 * Cette table ne montrait que date, libellé, mode et montant, sans
		 * aucune action : un encaissement libre saisi de travers n'avait
		 * AUCUNE issue à l'écran, alors que le moteur sait l'annuler depuis la
		 * 1.745.0. Le geste d'annulation n'existait que pour les règlements de
		 * clients et de fournisseurs, plus bas.
		 */
		$etats = array(
			'comptabilise'  => array( 'Comptabilisé', 'b-on' ),
			'au_journal'    => array( 'Au journal temporaire', 'b-warn' ),
			'sans_ecriture' => array( 'Sans écriture', 'b-off' ),
			'annule'        => array( 'Annulé', 'b-err' ),
		);
		$nbDetail = class_exists( 'FKC_ReglementDetail' )
			? FKC_ReglementDetail::compteParReglement( array_column( $mouvements, 'id' ) ) : array();
		?>
		<table class="table">
			<thead><tr><th>Date</th><th>Libellé</th><th>Mode</th><th class="num">Montant</th><th>État</th><th>Pièces</th><th></th></tr></thead>
			<tbody>
			<?php if ( ! $mouvements ) : ?><tr><td colspan="7" class="empty">Aucun mouvement.</td></tr>
			<?php else : foreach ( $mouvements as $m ) :
				$in = 'encaissement'===$m['sens']; $vir='virement'===$m['sens'];
				$et = FKC_Reglement::etat( $m ); $b = $etats[ $et ]; $ann = 'annule' === $et;
				$sensUrl = 'paiement' === $m['sens'] ? 'decaissement' : (string) $m['sens'];
				$pj = class_exists( 'FKC_GedDocument' ) ? FKC_GedDocument::byLink( 'reglement', (int) $m['id'] ) : array();
				$nd = (int) ( $nbDetail[ (int) $m['id'] ] ?? 0 );
				$det = $nd ? FKC_ReglementDetail::pour( (int) $m['id'] ) : array();
			?>
				<tr style="<?= $ann ? 'opacity:.6' : '' ?>">
					<td class="num"><?= e( date('d/m/Y', strtotime($m['date_reglement'])) ) ?></td>
					<td><?= e( $m['libelle'] ) ?>
						<?php if ( $det ) : ?><br><small class="muted"><?php
							$bouts = array();
							foreach ( $det as $d ) { $bouts[] = $d['designation'] . ' ' . fkc_money( $d['montant'] ); }
							echo e( implode( ' · ', $bouts ) );
						?></small><?php endif; ?>
						<?php if ( $ann && ! empty( $m['annule_motif'] ) ) : ?><br><small class="muted">Annulé : <?= e( (string) $m['annule_motif'] ) ?></small><?php endif; ?>
					</td>
					<td class="muted"><?= e( $m['mode'] ?: '—' ) ?></td>
					<td class="num" style="color:<?= $vir?'var(--muted)':($in?'var(--ok)':'var(--danger)') ?>;<?= $ann ? 'text-decoration:line-through' : '' ?>"><?= $in?'+':($vir?'':'−') ?><?= e( fkc_money($m['montant']) ) ?></td>
					<td><span class="modbadge <?= e( $b[1] ) ?>"><?= e( $b[0] ) ?></span></td>
					<td><?php if ( ! $pj ) : ?><span class="muted">—</span>
						<?php else : foreach ( $pj as $doc ) : ?>
							<a class="btn btn-ghost btn-sm" href="<?= e( url( 'ged/' . (int) $doc['id'] . '/telecharger' ) ) ?>" title="<?= e( $doc['nom_origine'] ?: $doc['titre'] ) ?>">📎</a>
						<?php endforeach; endif; ?></td>
					<td class="right" style="white-space:nowrap">
						<?php if ( $ann ) : ?>
							<form method="post" action="<?= e( url( 'comptabilite/reglements/' . (int) $m['id'] . '/corriger' ) ) ?>" style="display:inline">
								<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" title="Reprendre cette saisie dans un nouveau mouvement">Reprendre</button>
							</form>
						<?php elseif ( ! empty( $m['pointe'] ) ) : ?>
							<span class="muted" title="Pointé au rapprochement bancaire">✓ pointé</span>
						<?php else : ?>
							<form method="post" action="<?= e( url( 'comptabilite/reglements/' . (int) $m['id'] . '/corriger' ) ) ?>" style="display:inline"
								onsubmit="return confirm('Corriger ce mouvement ? Il sera annulé (contre-passation) et la saisie rouverte, préremplie.')">
								<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Corriger</button>
							</form>
							<form method="post" action="<?= e( url( 'comptabilite/reglements/' . (int) $m['id'] . '/annuler' ) ) ?>" style="display:inline"
								onsubmit="return confirm('Annuler ce mouvement ? Une contre-passation sera générée.')">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="retour" value="comptabilite/tresorerie">
								<button class="btn btn-ghost btn-sm" type="submit">Annuler</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
	</div>
	<div class="card" style="margin:0">
		<div class="card-head"><h2>Ajouter un compte</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url('comptabilite/tresorerie/comptes') ) ?>">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Libellé</span><input name="libelle" required placeholder="Banque BICICI"></label>
				<label class="fld"><span>Type</span><select name="type"><?php foreach($types as $k=>$v):?><option value="<?= e($k) ?>"><?= e($v) ?></option><?php endforeach;?></select></label>
				<label class="fld"><span>Opérateur (si mobile money)</span><input name="operateur" placeholder="Wave / Orange / MTN / Moov"></label>
				<label class="fld"><span>Compte SYSCOHADA</span><input name="compte" class="code" value="521" required></label>
				<input type="hidden" name="actif" value="1">
				<button class="btn btn-primary btn-sm" type="submit">Ajouter</button>
			</form>
		</div>
	</div>
</div>
<?php if ( ! empty( $derniersReglements ) ) : foreach ( $derniersReglements as $k => $g ) { $derniersReglements[ $k ]['factures'] = FKC_Reglement::facturesSoldees( (int) $g['id'] ); }
	FKC_View::partial( '_reglements_tiers', array( 'reglements' => $derniersReglements, 'retour' => 'comptabilite/tresorerie',
		'titre' => 'Règlements clients et fournisseurs' ) );
endif; ?>
<style>
.tres-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:14px}
.tres-card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px}
.tres-top{display:flex;gap:10px;align-items:center;margin-bottom:12px}
.tres-ico{font-size:22px}
.tres-solde{font-family:Syne,sans-serif;font-size:24px;font-weight:800;color:var(--text)}
.tres-link{display:inline-block;margin-top:10px;font-size:12px;color:var(--blue);font-weight:600}
</style>
