<?php /** @var array $lignes @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Rapprochement bancaire — comparez le solde comptable au solde pointé (relevé)</span></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Compte de trésorerie</th><th class="num">Solde comptable</th><th class="num">Solde pointé</th><th class="num">Écart</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $lignes ) : ?><tr><td colspan="5" class="empty">Aucun compte de trésorerie configuré.</td></tr>
	<?php else : foreach ( $lignes as $L ) : $c = $L['compte']; $ecart = $L['solde'] - $L['pointe']; ?>
		<tr>
			<td><strong><?= e( $c['libelle'] ) ?></strong> <span class="muted">· <?= e( $c['type'] ) ?></span></td>
			<td class="num"><?= e( fkc_money( $L['solde'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $L['pointe'] ) ) ?></td>
			<?php
			/*
			 * L'ANCIENNETÉ CHANGE LA COULEUR, PAS LE MONTANT (1.676.0).
			 *
			 * Un écart est normal — un chèque met quelques jours. Le colorer
			 * en orange dès le premier franc apprend à ne plus le regarder.
			 * Ce qui doit alerter est la part qui NE BOUGE PLUS : au-delà de
			 * deux mois, le chèque est égaré, sans provision, ou jamais
			 * remis, et le solde comptable annonce un argent qu'on n'a pas.
			 */
			$det = $L['detail'] ?? array();
			$vieux = (int) ( $det['nb_anciens'] ?? 0 );
			$coul = $vieux > 0 ? 'color:var(--danger,#ff6b6b)' : ( abs( $ecart ) < 1 ? 'color:var(--ok)' : 'color:var(--muted)' );
			?>
			<td class="num" style="<?= $coul ?>">
				<?= e( fkc_money( $ecart ) ) ?>
				<?php if ( $vieux > 0 ) : ?>
					<div class="muted" style="font-size:11.5px">dont <?= e( fkc_money( (float) $det['ancien'] ) ) ?>
						sur <?= $vieux ?> mouvement<?= $vieux > 1 ? 's' : '' ?> de plus de 2 mois</div>
				<?php endif; ?>
			</td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/tresorerie/rapprochement/' . (int) $c['id'] ) ) ?>">Pointer</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>

<?php
/*
 * Le détail ne s'affiche QUE s'il y a quelque chose à traiter : un bloc vide
 * sous un tableau déjà lisible n'ajoute rien et fait défiler pour rien.
 */
$dormants = $dormants ?? array();
?>
<?php if ( $dormants ) : ?>
<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Mouvements jamais confirmés par la banque</h2></div>
	<div class="card-body">
		<p class="muted" style="font-size:12.5px;margin-top:0">
			Ces mouvements attendent depuis plus de deux mois. Ce n'est plus un délai
			d'encaissement : le chèque est égaré, sans provision, ou la remise n'a jamais
			été faite. <strong>Le logiciel ne peut pas dire lequel</strong> — il nomme le
			mouvement pour qu'on tranche, parce qu'en attendant, le solde comptable annonce
			un argent que l'entreprise n'a pas et qu'elle engage.
		</p>
		<table class="table">
			<thead><tr><th>Date</th><th>Compte</th><th>Tiers</th><th>Moyen</th><th>Référence</th><th class="num">Montant</th></tr></thead>
			<tbody>
			<?php foreach ( $dormants as $d ) : ?>
				<tr>
					<td><?= e( (string) $d['date_reglement'] ) ?></td>
					<td class="muted"><?= e( (string) ( $d['tresorerie'] ?? '' ) ) ?></td>
					<td><?= e( (string) ( $d['tiers_nom'] ?? '' ) ?: ( $d['libelle'] ?? '' ) ) ?></td>
					<td><?= e( class_exists( 'FKC_Reglement' ) ? FKC_Reglement::labelMode( $d['mode'] ?? '' ) : (string) ( $d['mode'] ?? '' ) ) ?></td>
					<td class="muted" style="font-size:12px"><?= e( (string) ( $d['reference'] ?? '' ) ) ?></td>
					<td class="num"><?= e( fkc_money( (float) $d['montant'] ) ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endif; ?>
