<?php
/**
 * Faits économiques — catalogue et état de la couverture.
 *
 * @var array $catalogue @var array $couverture @var array $incoherences @var string $tab
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$c = $couverture;
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>

<div class="card">
	<div class="card-head"><h2>Faits économiques</h2></div>
	<div class="card-body">
		<p>
			Un fait économique dit <strong>ce qui s'est passé</strong>, avant toute question
			de compte. Une même dîme est un encaissement immédiat si elle est remise en
			espèces, et une créance si elle est promise : c'est le fait qui les distingue,
			pas le numéro de compte.
		</p>
		<p class="muted">
			Cette page ne modifie aucune écriture. Elle mesure combien d'événements
			déclarent aujourd'hui leur fait — la traduction par rôles viendra ensuite,
			et elle a besoin de cette mesure pour être vérifiable.
		</p>

		<div class="meta">
			<div><span class="stat-label">Événements comptables</span><strong><?= (int) $c['total'] ?></strong></div>
			<div><span class="stat-label">Fait déclaré</span><strong><?= (int) $c['declares'] ?></strong></div>
			<div><span class="stat-label">Couverture</span><strong><?= e( number_format( (float) $c['pct'], 1, ',', ' ' ) ) ?> %</strong></div>
			<div><span class="stat-label">Dérogations motivées</span><strong><?= (int) $c['derogations'] ?></strong></div>
		</div>
	</div>
</div>

<?php $og = $origines ?? array(); $sp = $sansPiece ?? array(); ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Pièce d'origine des écritures</h2></div>
	<div class="card-body">
		<p>
			Un contrôleur ouvre le grand livre, tombe sur une ligne et demande ce qu'elle
			raconte. Trente et une tables inscrivent l'écriture qu'elles ont produite ;
			ce rattachement retourne ce lien et le pose sur l'écriture, ainsi que dans la
			<strong>chaîne documentaire</strong>. Rien n'est deviné : une écriture que
			personne ne revendique reste sans origine, et le tableau ci-dessous le dit.
		</p>
		<div class="stats">
			<div><span class="stat-label">Écritures</span><strong><?= (int) ( $og['total'] ?? 0 ) ?></strong></div>
			<div><span class="stat-label">Avec pièce d'origine</span><strong><?= (int) ( $og['avec'] ?? 0 ) ?></strong></div>
			<div><span class="stat-label">Sans</span><strong><?= (int) ( $og['sans'] ?? 0 ) ?></strong></div>
			<div><span class="stat-label">Couverture</span><strong><?= e( number_format( (float) ( $og['taux'] ?? 0 ), 1, ',', ' ' ) ) ?> %</strong></div>
			<div><span class="stat-label">Tables reliées</span><strong><?= (int) ( $og['tables'] ?? 0 ) ?></strong></div>
		</div>
		<form method="post" action="<?= e( url( 'comptabilite/faits-economiques/rattacher-origines' ) ) ?>" style="margin-top:12px">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-primary" type="submit">Rattacher les écritures à leur pièce</button>
			<span class="muted" style="font-size:12px;margin-left:8px">Le balayage tourne aussi tout seul, par petits lots, sans retarder aucune saisie.</span>
		</form>

		<?php if ( ! empty( $og['par_origine'] ) ) : ?>
			<table class="table bordered" style="margin-top:14px">
				<thead><tr><th>Origine</th><th>Écritures</th><th>Avec pièce</th><th>Couverture</th></tr></thead>
				<tbody>
				<?php foreach ( $og['par_origine'] as $o ) :
					$tot = (int) $o['total']; $av = (int) $o['avec'];
					$pct = $tot > 0 ? round( 100 * $av / $tot, 1 ) : 0; ?>
					<tr><td><?= e( $o['origine'] ) ?></td><td><?= $tot ?></td><td><?= $av ?></td>
						<td><?= e( number_format( $pct, 1, ',', ' ' ) ) ?> %</td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $sp ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Écritures qu'aucune pièce ne revendique</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				Ce n'est pas la même chose que « pas encore balayée » : ces écritures ont été
				confrontées à la carte, et rien ne les désigne. Une écriture manuelle est dans
				ce cas et c'est normal ; une écriture émise par un pack ne devrait pas y être.
			</p>
			<table class="table bordered">
				<thead><tr><th>Date</th><th>Pièce</th><th>Libellé</th><th>Source</th><th>Origine</th></tr></thead>
				<tbody>
				<?php foreach ( $sp as $r ) : ?>
					<tr><td><?= e( (string) $r['date_ecriture'] ) ?></td>
						<td><?= e( (string) $r['piece'] ) ?></td>
						<td><?= e( (string) $r['libelle'] ) ?></td>
						<td><span class="code"><?= e( (string) ( $r['source'] ?? '' ) ) ?></span></td>
						<td><?= e( (string) ( $r['origine'] ?? '' ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
</div>

<?php $cd = $chaine ?? array(); $nf = $nonFacturees ?? array(); $nl = $nonLettres ?? array(); $pp = $perdues ?? array(); $so = $sansOp ?? array(); $mx = $mixtes ?? array(); $dp = $depassements ?? array(); $bo = $budgetOrph ?? array(); $mnf = $missionsNF ?? array(); $rf = $refus ?? array(); ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Chaîne documentaire</h2></div>
	<div class="card-body">
		<p>
			Le parcours d'une opération, maillon par maillon : commande → livraison →
			facture → écriture. C'est ce registre qui répond à « pourquoi le stock a-t-il
			diminué ? » et à « quelle livraison explique cette facture ? ».
		</p>
		<div class="stats">
			<div><span class="stat-label">Maillons</span><strong><?= (int) ( $cd['maillons'] ?? 0 ) ?></strong></div>
			<div><span class="stat-label">Types de documents</span><strong><?= (int) ( $cd['types'] ?? 0 ) ?></strong></div>
			<div><span class="stat-label">Relations</span><strong><?= (int) ( $cd['relations'] ?? 0 ) ?></strong></div>
		</div>
		<?php if ( ! empty( $cd['par_relation'] ) ) : ?>
			<table class="table bordered" style="margin-top:12px">
				<thead><tr><th>Amont</th><th>Relation</th><th>Aval</th><th>Maillons</th></tr></thead>
				<tbody>
				<?php foreach ( $cd['par_relation'] as $r ) : ?>
					<tr><td><?= e( FKC_ChaineDoc::TYPES[ $r['amont_type'] ] ?? $r['amont_type'] ) ?></td>
						<td class="muted"><?= e( FKC_ChaineDoc::RELATIONS[ $r['relation'] ] ?? $r['relation'] ) ?></td>
						<td><?= e( FKC_ChaineDoc::TYPES[ $r['aval_type'] ] ?? $r['aval_type'] ) ?></td>
						<td><?= (int) $r['n'] ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="muted" style="font-size:12.5px">Aucun maillon pour l'instant. Ils se posent au fil des
			opérations réalisées après cette mise à jour — livraisons, acomptes, facturations — et
			le rattachement des origines pose ceux qui mènent aux écritures.</p>
		<?php endif; ?>

		<?php if ( $nf ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Marchandise livrée et jamais facturée</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				Ce contrôle vaut <strong>zéro dans un dossier tenu</strong>, et c'est pour cela qu'il
				est ici. « Sorties de stock sans document » aurait été allumé à cent pour cent : une
				vente au comptant sort du stock sans autre pièce que le mouvement lui-même, qui EST
				le document. Un contrôle qui s'allume partout n'apprend qu'à être ignoré.
			</p>
			<table class="table bordered">
				<thead><tr><th>Sortie du</th><th>Commande</th><th>Client</th><th>Article</th><th>Quantité</th></tr></thead>
				<tbody>
				<?php foreach ( $nf as $l ) : ?>
					<tr><td><?= e( substr( (string) $l['created_at'], 0, 10 ) ) ?></td>
						<td><?= e( (string) $l['commande'] ) ?></td>
						<td><?= e( (string) $l['client_nom'] ) ?></td>
						<td><?= e( (string) $l['article'] ) ?></td>
						<td><?= e( fkc_money( (float) $l['qte'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $nl ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Argent encaissé et jamais rattaché à une créance</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				« Paiements sans lettrage » tel quel n'est pas une anomalie : un règlement du jour
				n'a pas vocation à être déjà rapproché, et le compteur s'allumerait dans tout dossier
				vivant. Avec une ancienneté d'un mois, il devient ce qu'il prétend être — de l'argent
				encaissé qu'on n'a jamais su rattacher, ce qui fausse le solde auxiliaire du tiers.
			</p>
			<table class="table bordered">
				<thead><tr><th>Date</th><th>Tiers</th><th>Montant</th><th>Libellé</th></tr></thead>
				<tbody>
				<?php foreach ( $nl as $r ) : ?>
					<tr><td><?= e( (string) $r['date_reglement'] ) ?></td>
						<td><?= e( (string) ( $r['tiers_nom'] ?? '' ) ) ?></td>
						<td><?= e( fkc_money( (float) $r['montant'] ) ) ?></td>
						<td class="muted" style="font-size:12px"><?= e( (string) ( $r['libelle'] ?? '' ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $pp ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Prestations encaissées mais jamais comptabilisées</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				La fermeture d'une note d'hôtel passe son chemin quand une nature n'a pas de schéma
				comptable — c'est le bon choix, une nature défaillante ne doit pas empêcher les autres
				d'être facturées. Mais la note est fermée juste après, et rien ne rouvre une note close :
				ces lignes-là sont du produit encaissé qui n'entrera dans aucun compte de résultat.
				Le compteur vaut zéro dès que chaque nature a son schéma.
			</p>
			<table class="table bordered">
				<thead><tr><th>Soldée le</th><th>Chambre</th><th>Client</th><th>Nature</th><th>Prestation</th><th>Montant</th></tr></thead>
				<tbody>
				<?php foreach ( $pp as $l ) : ?>
					<tr><td><?= e( substr( (string) ( $l['ferme_at'] ?? '' ), 0, 10 ) ) ?></td>
						<td><?= e( (string) ( $l['chambre'] ?? '' ) ) ?></td>
						<td><?= e( (string) ( $l['client'] ?? '' ) ) ?></td>
						<td><span class="code"><?= e( (string) $l['nature'] ) ?></span></td>
						<td><?= e( (string) $l['libelle'] ) ?></td>
						<td><?= e( fkc_money( (float) $l['montant_ttc'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( ! empty( $so['total'] ) ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Encaissements mobiles sans opérateur identifié</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				<strong><?= (int) $so['total'] ?> règlement(s)</strong> pour
				<?= e( fkc_money( (float) $so['montant'] ) ) ?> F portent « Mobile Money » sans dire chez qui.
				Ces lignes ne se rapprochent d'aucun relevé : le jour où un opérateur conteste un montant,
				on sait qu'on a encaissé, pas chez qui. Ce n'est pas une alerte du jour mais un arriéré —
				la saisie est désormais fermée, seul l'historique reste.
				<?php if ( ! empty( $so['recents'] ) ) : ?>
					<br><strong><?= (int) $so['recents'] ?></strong> datent de moins de 45 jours : ceux-là sont
					encore retrouvables chez l'opérateur, les plus anciens ne le sont plus.
				<?php endif; ?>
			</p>
		<?php endif; ?>

		<?php if ( ! empty( $mx['total'] ) ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Tickets réglés de plusieurs façons</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				<strong><?= (int) $mx['total'] ?> ticket(s)</strong> pour
				<?= e( fkc_money( (float) $mx['montant'] ) ) ?> F ont été réglés en plusieurs moyens.
				Une écriture ne porte qu'une ligne de trésorerie : la totalité est donc imputée au compte
				de repli. <strong>Ce n'est pas une erreur de saisie</strong> — le caissier a bien fait son
				travail, c'est le moteur d'écritures qui ne sait pas encore scinder sa ligne. Le chiffre
				dit ce qu'un dossier gagnerait à voir cette scission arriver.
			</p>
			<table class="table bordered">
				<thead><tr><th>Ticket</th><th>Encaissé le</th><th>Moyens</th><th>Montant</th></tr></thead>
				<tbody>
				<?php foreach ( (array) $mx['recents'] as $t ) : ?>
					<tr><td><?= e( (string) $t['numero'] ) ?></td>
						<td><?= e( substr( (string) ( $t['paye_at'] ?? '' ), 0, 10 ) ) ?></td>
						<td class="muted" style="font-size:12px"><?= e( (string) $t['modes'] ) ?></td>
						<td><?= e( fkc_money( (float) $t['total_ttc'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $dp ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Lignes budgétaires dépassées</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				Un dépassement n'est <strong>pas une faute comptable</strong> : c'est une décision de
				gestion. Le camion part quand même, et on rend compte ensuite. FinaKop ne bloque donc
				aucune dépense — il les rend visibles. Ce contrôle n'a de sens que depuis que les
				réceptions alimentent le réalisé : avant, il n'aurait mesuré que la diligence de celui
				qui ressaisissait les chiffres à la main.
			</p>
			<table class="table bordered">
				<thead><tr><th>Objet</th><th>Ligne</th><th>Prévu</th><th>Consommé</th><th>Dépassement</th></tr></thead>
				<tbody>
				<?php foreach ( $dp as $l ) :
					$cons = max( (float) $l['montant_engage'], (float) $l['montant_realise'] ); ?>
					<tr><td class="muted" style="font-size:12px"><?= e( (string) $l['objet_type'] ) ?> #<?= (int) $l['objet_id'] ?></td>
						<td><?= e( (string) $l['libelle'] ) ?></td>
						<td><?= e( fkc_money( (float) $l['montant_prevu'] ) ) ?></td>
						<td><?= e( fkc_money( $cons ) ) ?></td>
						<td><?= e( fkc_money( (float) $l['depassement'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $bo ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Dépenses rattachées à une ligne budgétaire disparue</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				Une ligne budgétaire se retire en douceur, mais les réceptions qui la citaient continuent
				de la citer. Leur montant sort alors du budget sans que rien ne le dise : le consommé
				baisse tout seul, ce qui ressemble à une bonne nouvelle.
			</p>
			<table class="table bordered">
				<thead><tr><th>Date</th><th>Pièce</th><th>Libellé</th><th>Montant</th></tr></thead>
				<tbody>
				<?php foreach ( $bo as $r ) : ?>
					<tr><td><?= e( (string) $r['date_reception'] ) ?></td>
						<td><?= e( (string) ( $r['piece'] ?? '' ) ) ?></td>
						<td><?= e( (string) ( $r['libelle'] ?? '' ) ) ?></td>
						<td><?= e( fkc_money( (float) $r['montant_ht'] ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $mnf ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Missions livrées et jamais facturées</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				<strong>Du chiffre d'affaires qui dort</strong> : le travail est livré, le client ne doit
				rien parce que personne ne le lui a demandé. Les missions antérieures à cette version y
				figurent toutes, et c'est exact — jusqu'ici, aucun moyen de les facturer n'existait.
				Chacune se corrige en un geste depuis sa fiche.
			</p>
			<table class="table bordered">
				<thead><tr><th>Mission</th><th>Client</th><th>Devis</th><th>Acomptes reçus</th><th>Reste à facturer</th></tr></thead>
				<tbody>
				<?php foreach ( $mnf as $m ) : ?>
					<tr><td><?= e( (string) $m['libelle'] ) ?></td>
						<td><?= e( (string) $m['client'] ) ?></td>
						<td><?= e( fkc_money( (float) $m['montant_devis'] ) ) ?></td>
						<td><?= e( fkc_money( (float) ( $m['encaisse'] ?? 0 ) ) ) ?></td>
						<td><?= e( fkc_money( (float) ( $m['solde'] ?? 0 ) ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php if ( $rf ) : ?>
			<h3 style="font-size:14px;margin:16px 0 6px">Comptabilisations refusées</h3>
			<p class="muted" style="font-size:12px;margin-top:0">
				Chaque ligne est une opération enregistrée <strong>dont la contrepartie comptable
				manque</strong> : la vente, la réception ou la paie a bien eu lieu, l'écriture non.
				Le moteur signalait ces refus par sa valeur de retour, que vingt-neuf appelants du
				produit ignorent — ils disparaissaient donc en silence. La cause est presque toujours
				un journal ou un schéma absent, et se corrige une fois pour toutes.
			</p>
			<table class="table bordered">
				<thead><tr><th>Événement</th><th>Motif</th><th>Cas</th><th>Montant</th><th>Dernier</th></tr></thead>
				<tbody>
				<?php foreach ( $rf as $r ) : ?>
					<tr><td><span class="code"><?= e( (string) $r['evenement'] ) ?></span></td>
						<td class="muted" style="font-size:12px"><?= e( (string) $r['motif'] ) ?></td>
						<td><?= (int) $r['n'] ?></td>
						<td><?= e( fkc_money( (float) $r['total'] ) ) ?></td>
						<td class="muted" style="font-size:12px"><?= e( substr( (string) $r['dernier'], 0, 16 ) ) ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
</div>

<?php if ( $incoherences ) : ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>À regarder</h2></div>
	<div class="card-body">
		<p class="muted">
			Le fait déclaré et l'écriture produite ne disent pas la même chose. Rien n'est
			bloqué : ces observations existent pour être arbitrées avant que le moteur ne
			résolve lui-même les comptes.
		</p>
		<table class="table bordered">
			<thead><tr><th>Événement</th><th>Observation</th></tr></thead>
			<tbody>
			<?php foreach ( $incoherences as $evt => $obs ) : foreach ( $obs as $o ) : ?>
				<tr><td><span class="code"><?= e( $evt ) ?></span></td><td><?= e( $o ) ?></td></tr>
			<?php endforeach; endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endif; ?>

<?php $dv = $divergences ?? array(); $dims = $dimensions ?? array(); ?>
<?php if ( $dv ) : ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Divergences avec la bibliothèque centrale</h2></div>
	<div class="card-body">
		<p>
			Deux règles peuvent citer exactement les <strong>mêmes comptes</strong> et
			désaccorder sur tout le reste : le fait qu'elles traduisent, le référentiel
			sous lequel elles le font, le régime fiscal, le journal. Ces écarts-là ne
			produisaient aucun signal, faute d'être déclarés.
		</p>
		<table class="table bordered">
			<thead><tr><th>Événement</th><th>Dimension</th><th>Écart</th></tr></thead>
			<tbody>
			<?php foreach ( $dv as $evt => $lignes ) : foreach ( $lignes as $l ) : ?>
				<tr>
					<td><span class="code"><?= e( $evt ) ?></span></td>
					<td><strong><?= e( $l['label'] ) ?></strong>
						<span class="muted">· <?= e( $l['gravite'] ) ?></span></td>
					<td class="muted"><?= e( $l['detail'] ) ?></td>
				</tr>
			<?php endforeach; endforeach; ?>
			</tbody>
		</table>
		<p class="muted">
			Un désaccord sur le <strong>fait économique</strong> arrête l'examen des six
			autres : si l'une décrit une vente et l'autre un encaissement, comparer leurs
			comptes revient à s'étonner qu'une facture et un reçu ne se ressemblent pas.
		</p>
	</div>
</div>
<?php endif; ?>

<?php
$rc = $reclassement ?? array();
$rcActifs = array_filter( $rc, function ( $a ) { return ! empty( $a['a_reclasser'] ); } );
?>
<?php if ( $rcActifs ) : ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Imputations héritées</h2></div>
	<div class="card-body">
		<p>
			Des soldes sont restés sur des comptes de <strong>regroupement</strong>, qui
			totalisent leurs subdivisions et sur lesquels on n'impute pas. Ils ne bougent
			plus : rien ne les alimente. Un solde figé sur un compte qui n'est plus le bon
			n'est pas une erreur visible — c'est celle qui reste au bilan sans que
			personne ne s'interroge.
		</p>
		<table class="table bordered">
			<thead><tr><th>Compte hérité</th><th>Vers</th><th class="num">Solde</th><th class="num">Lignes</th><th>D'où viennent-ils</th></tr></thead>
			<tbody>
			<?php foreach ( $rcActifs as $src => $a ) : ?>
				<tr>
					<td><span class="code"><?= e( $src ) ?></span><div class="muted" style="font-size:.85em"><?= e( $a['motif'] ) ?></div></td>
					<td><span class="code"><?= e( $a['cible'] ) ?></span> <?= e( $a['cible_libelle'] ) ?></td>
					<td class="num"><?= e( fkc_money( $a['solde'] ) ) ?></td>
					<td class="num"><?= (int) $a['lignes'] ?></td>
					<td class="muted">
						<?php foreach ( array_slice( $a['origines'], 0, 4 ) as $o ) : ?>
							<div><?= e( $o['origine'] ) ?> — <?= (int) $o['lignes'] ?> ligne(s)</div>
						<?php endforeach; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<form method="post" action="<?= e( url( 'comptabilite/faits-economiques/reclasser' ) ) ?>" style="margin-top:12px;display:flex;gap:10px;align-items:flex-end">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Date de l'écriture</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
			<button class="btn" type="submit">Passer l'OD de reclassement</button>
		</form>
		<p class="muted">
			<strong>Aucune écriture passée n'est modifiée.</strong> Corriger directement les
			lignes d'une écriture validée détruirait la valeur probante de la comptabilité :
			un contrôleur comparant deux extractions à quelques mois d'écart trouverait un
			passé qui a changé. Une OD, elle, se date, se motive et se contre-passe.
		</p>
	</div>
</div>
<?php endif; ?>

<?php $pv = $provisions ?? array(); $ec = $ecarts ?? array( 'lignes' => array(), 'nb' => 0, 'ecart_total' => 0, 'tendance' => '' ); ?>
<?php if ( $pv || $ec['nb'] ) : ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Provisions et engagements</h2></div>
	<div class="card-body">
		<p>
			Une provision n'est pas un solde : c'est une <strong>estimation en attente de
			vérification</strong>. Elle s'ouvre, se révise, puis un événement réel arrive
			et l'on découvre de combien on s'était trompé.
		</p>

		<?php if ( $pv ) : ?>
		<h3>Encore ouvertes</h3>
		<table class="table bordered">
			<thead><tr><th>Nature</th><th>Objet</th><th class="num">Solde</th><th class="num">Ancienneté</th></tr></thead>
			<tbody>
			<?php foreach ( $pv as $p ) : ?>
				<tr>
					<td><?= e( $p['label'] ) ?></td>
					<td><?= e( $p['objet'] ?: '—' ) ?><?= $p['tiers'] ? ' <span class="muted">· ' . e( $p['tiers'] ) . '</span>' : '' ?></td>
					<td class="num"><?= e( fkc_money( $p['solde'] ) ) ?></td>
					<td class="num"><?= $p['jours'] > 365 ? '<strong>' . (int) $p['jours'] . ' j</strong>' : (int) $p['jours'] . ' j' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>

		<?php if ( $ec['nb'] ) : ?>
		<h3 style="margin-top:20px">Écarts d'estimation</h3>
		<p class="muted">
			Ce qui avait été provisionné, face à ce qui a réellement été payé. C'est le
			chiffre qu'aucun état ne donnait : une entité qui provisionne systématiquement
			trop le lit dans son résultat sans jamais pouvoir le nommer.
		</p>
		<?php if ( 'sur' === $ec['tendance'] ) : ?>
			<div class="alert alert-warn">Tendance au <strong>sur-provisionnement</strong> : les dénouements coûtent régulièrement moins que prévu.</div>
		<?php elseif ( 'sous' === $ec['tendance'] ) : ?>
			<div class="alert alert-warn">Tendance au <strong>sous-provisionnement</strong> : les dénouements coûtent régulièrement plus que prévu.</div>
		<?php endif; ?>
		<table class="table bordered">
			<thead><tr><th>Objet</th><th class="num">Provisionné</th><th class="num">Réglé</th><th class="num">Écart</th><th>Dénoué le</th></tr></thead>
			<tbody>
			<?php foreach ( $ec['lignes'] as $l ) : ?>
				<tr>
					<td><?= e( $l['label'] ) ?> <span class="muted"><?= e( $l['objet'] ) ?></span></td>
					<td class="num"><?= e( fkc_money( $l['provisionne'] ) ) ?></td>
					<td class="num"><?= e( fkc_money( $l['regle'] ) ) ?></td>
					<td class="num"><?= e( fkc_money( $l['ecart'] ) ) ?></td>
					<td><?= $l['date'] ? e( date( 'd/m/Y', strtotime( $l['date'] ) ) ) : '—' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>

		<p class="muted">
			Comme le registre des sommes détenues, cette vue ne produit aucune écriture et
			ne fait autorité sur rien : en cas d'écart avec le grand livre, c'est le grand
			livre qui a raison.
		</p>
	</div>
</div>
<?php endif; ?>

<?php $sd = $detenues ?? array( 'lignes' => array(), 'a_reverser' => 0, 'a_recuperer' => 0, 'anciennes' => array(), 'seuil_jours' => 90 ); ?>
<?php if ( $sd['lignes'] ) : ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Sommes détenues pour autrui</h2></div>
	<div class="card-body">
		<p>
			De l'argent qui transite sans jamais devenir un produit : débours avancés
			pour un client, primes encaissées pour une compagnie, parts à reverser à un
			artiste. Le solde du compte de tiers l'indiquait en bloc ; il manquait le
			détail par tiers et l'ancienneté.
		</p>
		<div class="meta">
			<div><span class="stat-label">Dû à des tiers</span><strong><?= e( fkc_money( $sd['a_reverser'] ) ) ?></strong></div>
			<div><span class="stat-label">Avancé, à récupérer</span><strong><?= e( fkc_money( $sd['a_recuperer'] ) ) ?></strong></div>
			<div><span class="stat-label">Au-delà de <?= (int) $sd['seuil_jours'] ?> jours</span><strong><?= count( $sd['anciennes'] ) ?></strong></div>
		</div>
		<p class="muted">
			Les deux sens ne se compensent pas : une somme reçue est une dette, une somme
			avancée est une créance. Un net entre les deux masquerait une prime non
			reversée derrière un débours en attente.
		</p>
		<table class="table bordered">
			<thead><tr><th>Nature</th><th>Tiers</th><th class="num">Solde</th><th class="num">Ancienneté</th></tr></thead>
			<tbody>
			<?php foreach ( $sd['lignes'] as $l ) : ?>
				<tr>
					<td><?= e( $l['label'] ) ?></td>
					<td><?= e( $l['tiers'] ?: '—' ) ?></td>
					<td class="num"><?= e( fkc_money( $l['solde'] ) ) ?></td>
					<td class="num"><?= $l['jours'] >= (int) $sd['seuil_jours'] ? '<strong>' . (int) $l['jours'] . ' j</strong>' : (int) $l['jours'] . ' j' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="muted">
			Cette vue n'est pas une seconde comptabilité : elle ne produit aucune écriture
			et ne fait autorité sur rien. En cas d'écart avec le compte de tiers au grand
			livre, c'est le grand livre qui a raison.
		</p>
	</div>
</div>
<?php endif; ?>

<?php $dg = $diagnostic ?? array( 'avec_role' => array(), 'sans_role' => array(), 'regroupement' => array() ); ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Rôles de ligne</h2></div>
	<div class="card-body">
		<p>
			Une ligne qui déclare un <strong>rôle</strong> ne choisit plus son compte :
			elle dit ce qu'elle veut, et le moteur central tranche. Le numéro qu'elle
			porte encore n'est qu'un repli — employé tant que l'émetteur ne fournit
			pas l'information qui permettrait de mieux faire.
		</p>
		<div class="meta">
			<div><span class="stat-label">Lignes avec rôle</span><strong><?= count( $dg['avec_role'] ) ?></strong></div>
			<div><span class="stat-label">Trésorerie sans rôle</span><strong><?= count( $dg['sans_role'] ) ?></strong></div>
			<div><span class="stat-label">Replis à revoir</span><strong><?= count( $dg['regroupement'] ) ?></strong></div>
		</div>
		<table class="table bordered" style="margin-top:12px">
			<thead><tr><th>Rôle</th><th>Résolu par</th><th>Ce qu'il signifie</th></tr></thead>
			<tbody>
			<?php foreach ( ( $roles ?? array() ) as $code => $r ) : ?>
				<tr>
					<td><span class="code"><?= e( $code ) ?></span></td>
					<td class="muted"><?= e( $r['moteur'] ) ?></td>
					<td class="muted"><?= e( $r['note'] ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="muted">
			Un seul rôle pour l'instant, et c'est délibéré : un rôle entre au catalogue
			quand une brique sait y répondre, pas avant.
		</p>
	</div>
</div>

<?php if ( $dg['regroupement'] ) : ?>
<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Replis posés sur un compte de regroupement</h2></div>
	<div class="card-body">
		<p class="muted">
			Ces comptes totalisent leurs subdivisions : on n'y impute pas. Le moteur
			ne les corrige pas de force — il les nomme, pour que la correction soit
			décidée. Dès que l'émetteur fournit son moyen de règlement, le repli
			cesse d'être employé.
		</p>
		<table class="table bordered">
			<thead><tr><th>Événement</th><th>Compte</th><th>Pourquoi</th></tr></thead>
			<tbody>
			<?php foreach ( $dg['regroupement'] as $x ) : ?>
				<tr>
					<td><span class="code"><?= e( $x['evenement'] ) ?></span></td>
					<td><span class="code"><?= e( $x['compte'] ) ?></span></td>
					<td class="muted"><?= e( $x['motif'] ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
<?php endif; ?>

<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Couverture par origine</h2></div>
	<div class="card-body">
		<table class="table bordered">
			<thead><tr><th>Origine</th><th class="num">Événements</th><th class="num">Fait déclaré</th><th class="num">Dérogations</th></tr></thead>
			<tbody>
			<?php foreach ( $c['par_origine'] as $origine => $d ) : ?>
				<tr>
					<td><?= e( $origine ) ?></td>
					<td class="num"><?= (int) $d['total'] ?></td>
					<td class="num"><?= (int) $d['declares'] ?></td>
					<td class="num"><?= $d['derogations'] ? (int) $d['derogations'] : '' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>

<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Événements sans fait déclaré</h2></div>
	<div class="card-body">
		<p class="muted">
			La colonne « proposition » est une <strong>question</strong>, pas une décision.
			Elle est déduite du nom de l'événement — or c'est précisément le nom qui ment
			aujourd'hui dans les cas qui nous intéressent. Rien n'est appliqué sans arbitrage.
		</p>
		<table class="table bordered">
			<thead><tr><th>Événement</th><th>Origine</th><th>Journal</th><th>Proposition à confirmer</th></tr></thead>
			<tbody>
			<?php foreach ( $c['manquants'] as $evt => $m ) : ?>
				<tr>
					<td><span class="code"><?= e( $evt ) ?></span></td>
					<td class="muted"><?= e( $m['origine'] ) ?></td>
					<td><?= e( $m['journal'] ) ?></td>
					<td><?= '' !== $m['proposition'] ? '<span class="code">' . e( $m['proposition'] ) . '</span>' : '<span class="muted">rien de sûr</span>' ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>

<div class="card" style="margin-top:16px">
	<div class="card-head"><h2>Le catalogue</h2></div>
	<div class="card-body">
		<?php foreach ( $catalogue as $famille => $faits ) : ?>
			<h3><?= e( $famille ) ?></h3>
			<table class="table bordered" style="margin-bottom:18px">
				<thead><tr><th>Code</th><th>Fait</th><th>Nature</th><th>Précision</th></tr></thead>
				<tbody>
				<?php foreach ( $faits as $code => $f ) : ?>
					<tr>
						<td><span class="code"><?= e( $code ) ?></span></td>
						<td><strong><?= e( $f['label'] ) ?></strong></td>
						<td class="muted"><?= e( $f['nature'] ) ?></td>
						<td class="muted"><?= e( $f['note'] ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endforeach; ?>
	</div>
</div>
