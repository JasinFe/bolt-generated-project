<?php
/**
 * Paiement d'un fournisseur — LA RÉPARTITION PAR FACTURE EST ICI.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * L'ÉCRAN NE POSAIT QU'UNE QUESTION, ET CE N'ÉTAIT PAS LA BONNE
 *
 * « Total déjà payé : … · Montant payé : ___ ». On savait combien on versait,
 * jamais sur quoi. La dette se soldait ensuite au plus ancien — ce qui est
 * faux dès que l'on choisit ce que l'on règle, et c'est le cas ordinaire à
 * l'achat.
 *
 * Les factures ouvertes sont donc listées, avec leur reste dû et leur
 * ancienneté, et chacune porte son montant affecté. Rien n'oblige à répartir :
 * laisser les lignes vides verse au compte du fournisseur comme avant, et le
 * lettrage au plus ancien s'applique. On ajoute une possibilité, on n'en
 * retire aucune.
 *
 * @var array $frn @var array $poste @var int $cible @var float $montant
 * @var bool  $imputable @var array $comptes @var array $modes @var float $totalPaye
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ouvertes = $poste['ouvertes'];
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<div><span class="stat-label">Paiement</span> <strong style="font-size:18px;font-family:Syne,sans-serif"><?= e( $frn['nom'] ) ?></strong></div>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/fournisseurs' ) ) ?>">← Retour</a>
</div>

<?php /* enctype multipart : sans lui, $_FILES reste vide et la pièce disparaît sans le moindre message d'erreur. */ ?>
<form method="post" action="<?= e( url( 'comptabilite/fournisseurs/' . (int) $frn['id'] . '/payer' ) ) ?>" id="payForm" enctype="multipart/form-data">
	<?= FKC_Csrf::field() ?>

	<div class="card"><div class="card-body" style="display:flex;gap:24px;flex-wrap:wrap">
		<div><span class="muted">Facturé</span><div style="font-size:1.2em"><?= e( fkc_money( $poste['facture'] ) ) ?> F</div></div>
		<div><span class="muted">Payé</span><div style="font-size:1.2em"><?= e( fkc_money( $poste['paye'] ) ) ?> F</div></div>
		<div><span class="muted">Reste dû</span><div style="font-size:1.2em;color:var(--orange)"><strong><?= e( fkc_money( $poste['du'] ) ) ?> F</strong></div></div>
		<div><span class="muted">Factures ouvertes</span><div style="font-size:1.2em"><?= (int) $poste['nb_ouvertes'] ?></div></div>
		<div><span class="muted">Compte fournisseur</span><div style="font-size:1.2em"><span class="code"><?= e( $frn['compte'] ) ?></span></div></div>
		<?php if ( $poste['credit'] > 0.5 ) : ?>
		<div><span class="muted">Versé sans facture</span><div style="font-size:1.2em;color:var(--ok)"><?= e( fkc_money( $poste['credit'] ) ) ?> F</div></div>
		<?php endif; ?>
	</div></div>

	<?php if ( ! $imputable ) : ?>
		<div class="alert alert-err">Cette base n'a pas encore reçu la table d'imputation : le paiement sera lettré automatiquement au plus ancien. Rechargez une page après la mise à jour pour l'activer.</div>
	<?php endif; ?>

	<div class="card card-flush">
		<div class="card-head">
			<h2>Factures à régler</h2>
			<?php if ( $ouvertes ) : ?>
			<div style="display:flex;gap:8px">
				<button class="btn btn-ghost btn-sm" type="button" onclick="fkcPayRepartir()">Répartir au plus ancien</button>
				<button class="btn btn-ghost btn-sm" type="button" onclick="fkcPayVider()">Tout effacer</button>
			</div>
			<?php endif; ?>
		</div>
		<table class="table">
			<thead><tr><th>Facture</th><th>Référence</th><th>Date</th><th>Échéance</th><th>Ancienneté</th><th class="num">TTC</th><th class="num">Déjà payé</th><th class="num">Reste dû</th><th class="num">À payer</th></tr></thead>
			<tbody>
			<?php if ( ! $ouvertes ) : ?>
				<tr><td colspan="9" class="empty">Aucune facture ouverte pour ce fournisseur. Un paiement saisi ici sera porté à son compte (avance).</td></tr>
			<?php else : foreach ( $ouvertes as $p ) :
				$pre = ( 0 === (int) $cible || (int) $p['id'] === (int) $cible ) ? round( (float) $p['reste'] ) : ''; ?>
				<tr>
					<td><strong><?= e( $p['numero'] ) ?></strong></td>
					<td class="code"><?= e( $p['reference'] ?: '—' ) ?></td>
					<td><?= e( date( 'd/m/Y', strtotime( $p['date_facture'] ) ) ) ?></td>
					<td><?= e( date( 'd/m/Y', strtotime( $p['echeance'] ) ) ) ?></td>
					<td><?php if ( $p['jours'] > 0 ) : ?><span style="color:<?= $p['jours'] > 60 ? 'var(--danger)' : 'var(--orange)' ?>"><?= (int) $p['jours'] ?> j</span><?php else : ?><span class="muted">Non échue</span><?php endif; ?></td>
					<td class="num"><?= e( fkc_money( $p['ttc'] ) ) ?></td>
					<td class="num"><?= $p['regle'] > 0.5 ? e( fkc_money( $p['regle'] ) ) : '—' ?></td>
					<td class="num" style="color:var(--orange)"><?= e( fkc_money( $p['reste'] ) ) ?></td>
					<td class="num">
						<input class="num fkc-imput" name="imput[<?= (int) $p['id'] ?>]" inputmode="decimal"
							data-reste="<?= e( round( (float) $p['reste'] ) ) ?>" value="<?= e( $pre ) ?>"
							style="width:130px;text-align:right" autocomplete="off">
					</td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
			<?php if ( $ouvertes ) : ?><tfoot><tr class="total">
				<td class="right" colspan="7">Total réparti</td>
				<td class="num"><?= e( fkc_money( $poste['du'] ) ) ?></td>
				<td class="num"><strong id="fkcPayTotal">—</strong></td>
			</tr></tfoot><?php endif; ?>
		</table>
	</div>

	<div class="card">
		<div class="card-head"><h2>Règlement</h2></div>
		<div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Montant payé</span>
					<input class="num" id="fkcPayMontant" name="montant" inputmode="decimal" required value="<?= e( $montant > 0 ? round( (float) $montant ) : '' ) ?>"></label>
				<label class="fld"><span>Depuis (trésorerie)</span>
					<select name="tresorerie_id" required><?php foreach ( $comptes as $c ) : ?><option value="<?= (int) $c['id'] ?>"><?= e( $c['libelle'] ) ?></option><?php endforeach; ?></select></label>
			</div>
			<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
				<label class="fld"><span>Date</span><input type="date" name="date_reglement" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld"><span>Mode</span><select name="mode"><?php foreach ( $modes as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Référence</span><input name="reference" autocomplete="off"></label>
			</div>
			<?php
			/*
			 * JUSTIFICATIF DU RÈGLEMENT.
			 * Un paiement Mobile Money sans son reçu est invérifiable au
			 * rapprochement comme au contrôle. La pièce se joint ici, au
			 * moment où on l'a sous les yeux — pas dans un second écran où
			 * personne ne retourne.
			 */
			$extGed = class_exists( 'FKC_GedDocument' ) ? array_keys( FKC_GedDocument::types() ) : array();
			?>
			<?php if ( $extGed ) : ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Justificatif <span class="muted">(reçu Wave, avis de virement, bordereau…)</span></span>
					<input type="file" name="piece" accept="<?= e( '.' . implode( ',.', $extGed ) ) ?>"></label>
				<label class="fld"><span>Intitulé de la pièce <span class="muted">(facultatif)</span></span>
					<input name="piece_titre" autocomplete="off" placeholder="Reçu Wave — <?= e( $frn['nom'] ) ?>"></label>
			</div>
			<p class="help" style="margin-top:-4px">La pièce est classée dans la GED sous « Justificatifs de règlement » et rattachée à ce paiement. Formats acceptés : <?= e( strtoupper( implode( ', ', $extGed ) ) ) ?> — 16 Mo maximum.</p>
			<?php endif; ?>
			<p class="help" id="fkcPayEcart" style="margin-top:8px"></p>
			<div class="actions">
				<button class="btn btn-primary" type="submit">Payer</button>
				<a class="btn btn-ghost" href="<?= e( url( 'comptabilite/fournisseurs' ) ) ?>">Annuler</a>
			</div>
			<p class="help" style="margin-top:8px">Écriture générée : <?= e( $frn['compte'] ) ?> Fournisseur (débit) / trésorerie (crédit). Les factures renseignées ci-dessus sont lettrées nommément ; le reliquat éventuel reste au compte du fournisseur.</p>
		</div>
	</div>
</form>

<?php
/* Règlements déjà enregistrés, et le geste pour en annuler un (1.745.0). */
FKC_View::partial( '_reglements_tiers', array( 'reglements' => $reglements ?? array(),
	'retour' => 'comptabilite/fournisseurs/' . (int) $frn['id'] . '/payer', 'titre' => 'Paiements enregistrés' ) );
?>
<script>
/* Aide à la saisie, jamais une contrainte : le serveur revalide tout, et
   l'écran reste utilisable sans JavaScript. */
(function () {
	var form = document.getElementById('payForm');
	if (!form) { return; }
	var champs  = Array.prototype.slice.call(form.querySelectorAll('.fkc-imput'));
	var total   = document.getElementById('fkcPayTotal');
	var montant = document.getElementById('fkcPayMontant');
	var ecart   = document.getElementById('fkcPayEcart');

	function lire(v) {
		v = String(v || '').replace(/[\s\u00a0\u202f']/g, '').replace(',', '.');
		var n = parseFloat(v);
		return isNaN(n) ? 0 : n;
	}
	function fmt(n) { return Math.round(n).toLocaleString('fr-FR').replace(/\u202f/g, ' '); }

	function recalculer(majMontant) {
		var s = 0;
		champs.forEach(function (c) { s += lire(c.value); });
		if (total) { total.textContent = s > 0 ? fmt(s) : '—'; }
		if (majMontant && s > 0) { montant.value = Math.round(s); }
		var m = lire(montant.value), d = m - s;
		if (!ecart) { return; }
		if (s > 0 && d > 0.5) {
			ecart.textContent = 'Reliquat de ' + fmt(d) + ' F : il restera au compte du fournisseur (avance).';
			ecart.style.color = 'var(--orange)';
		} else if (s > 0 && d < -0.5) {
			ecart.textContent = 'La répartition dépasse le montant payé de ' + fmt(-d) + ' F — l\u2019enregistrement sera refusé.';
			ecart.style.color = 'var(--danger)';
		} else {
			ecart.textContent = s > 0 ? 'Répartition équilibrée avec le montant payé.' : 'Aucune facture désignée : le paiement sera lettré au plus ancien.';
			ecart.style.color = '';
		}
	}

	champs.forEach(function (c) { c.addEventListener('input', function () { recalculer(true); }); });
	montant.addEventListener('input', function () { recalculer(false); });

	window.fkcPayRepartir = function () {
		var reste = lire(montant.value);
		champs.forEach(function (c) {
			var du = lire(c.dataset.reste);
			var p  = Math.min(reste, du);
			c.value = p > 0 ? Math.round(p) : '';
			reste -= p > 0 ? p : 0;
		});
		recalculer(false);
	};
	window.fkcPayVider = function () {
		champs.forEach(function (c) { c.value = ''; });
		recalculer(false);
	};
	recalculer(false);
}());
</script>
