<?php /** @var array|null $frn @var array $errors @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); $ed=(bool)$frn; ?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<div class="card" style="max-width:620px"><div class="card-head"><h2><?= $ed?'Modifier le fournisseur':'Nouveau fournisseur' ?></h2></div><div class="card-body">
<form method="post" action="<?= e( $ed?url('comptabilite/fournisseurs/'.$frn['id']):url('comptabilite/fournisseurs') ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-grid" style="grid-template-columns:2fr 1fr">
		<label class="fld"><span>Nom / Raison sociale</span><input name="nom" value="<?= e($ed?$frn['nom']:'') ?>" required></label>
		<label class="fld"><span>Compte SYSCOHADA</span><input class="code" name="compte" value="<?= e($ed?$frn['compte']:'401000') ?>"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>NCC</span><input class="code" name="ncc" value="<?= e($ed?$frn['ncc']:'') ?>"></label>
		<label class="fld"><span>Téléphone</span><input name="telephone" value="<?= e($ed?$frn['telephone']:'') ?>"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Email</span><input type="email" name="email" value="<?= e($ed?$frn['email']:'') ?>"></label>
		<label class="fld"><span>Adresse</span><input name="adresse" value="<?= e($ed?$frn['adresse']:'') ?>"></label>
	</div>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $ed?'Enregistrer':'Créer' ?></button><a class="btn btn-ghost" href="<?= e( url('comptabilite/fournisseurs') ) ?>">Annuler</a></div>
</form></div></div>
