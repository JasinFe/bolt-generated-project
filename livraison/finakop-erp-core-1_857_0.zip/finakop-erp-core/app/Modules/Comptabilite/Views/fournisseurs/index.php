<?php
/**
 * Postes fournisseurs — LA LISTE EST PAR FACTURE, PAS PAR FOURNISSEUR.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CE QUI A CHANGÉ EN 1.737.0, ET POURQUOI
 *
 * L'écran n'affichait qu'un solde global par fournisseur. On voyait « Untel :
 * 1 250 000 F dus » sans savoir laquelle de ses quatre factures payer — et le
 * paiement portait sur le tiers, jamais sur une pièce. La dette se
 * reconstituait ensuite par un lettrage au plus ancien.
 *
 * Ce repli est faux dès qu'on choisit ce qu'on règle, ce qui est le cas à
 * l'achat : on paie la facture de mars parce que la livraison de janvier est
 * contestée, ou parce qu'un escompte court sur celle-là. Le lettrage éteignait
 * janvier, laissait mars ouverte, et la relance du fournisseur portait sur une
 * facture déjà réglée.
 *
 * @var array  $postes      Factures d'achat ouvertes (poste, ancienneté, reste dû).
 * @var array  $fournisseurs
 * @var string $vue         'factures' | 'fournisseurs'
 * @var float  $totalDu @var int $nbOuvertes @var float $credits @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$vueFactures = 'fournisseurs' !== $vue;
?>
<?php FKC_View::partial( 'comptabilite::_subnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="bar">
	<div>
		<span class="stat-label">Total dettes fournisseurs</span>
		<strong style="font-size:20px;font-family:Syne,sans-serif;color:var(--orange)"><?= e( fkc_money( $totalDu ) ) ?> F</strong>
		<span class="muted" style="margin-left:10px"><?= (int) $nbOuvertes ?> facture<?= $nbOuvertes > 1 ? 's' : '' ?> à régler</span>
	</div>
	<div style="display:flex;gap:8px;flex-wrap:wrap">
		<a class="btn btn-sm <?= $vueFactures ? 'btn-primary' : 'btn-ghost' ?>" href="<?= e( url( 'comptabilite/fournisseurs' ) ) ?>">Par facture</a>
		<a class="btn btn-sm <?= $vueFactures ? 'btn-ghost' : 'btn-primary' ?>" href="<?= e( url( 'comptabilite/fournisseurs?vue=fournisseurs' ) ) ?>">Par fournisseur</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats' ) ) ?>">Factures d'achat</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/fournisseurs/nouveau' ) ) ?>">+ Nouveau fournisseur</a>
	</div>
</div>

<?php if ( $credits > 0.5 ) : ?>
<div class="alert" style="background:var(--bg2);border:1px solid var(--line);color:var(--text)">Paiements non affectés à une facture : <strong><?= e( fkc_money( $credits ) ) ?> F</strong> (avances versées, doubles saisies, factures pas encore enregistrées).</div>
<?php endif; ?>

<?php if ( $vueFactures ) : ?>

	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : facture, fournisseur, référence…' ) ); ?>
	<div class="card card-flush"><table class="table">
		<thead><tr>
			<th>Facture</th><th>Fournisseur</th><th>Référence</th><th>Date</th><th>Échéance</th>
			<th class="num">Montant TTC</th><th class="num">Déjà payé</th><th class="num">Reste dû</th><th>Ancienneté</th><th></th>
		</tr></thead>
		<tbody>
		<?php if ( ! $postes ) : ?>
			<tr><td colspan="10" class="empty">Aucune facture à régler — toutes les dettes fournisseurs sont soldées.</td></tr>
		<?php else : foreach ( $postes as $p ) : ?>
			<tr>
				<td><a href="<?= e( url( 'comptabilite/achats/' . (int) $p['id'] ) ) ?>"><strong><?= e( $p['numero'] ) ?></strong></a></td>
				<td><?= e( $p['fournisseur_nom'] ) ?></td>
				<td class="code"><?= e( $p['reference'] ?: '—' ) ?></td>
				<td><?= e( date( 'd/m/Y', strtotime( $p['date_facture'] ) ) ) ?></td>
				<td><?= e( date( 'd/m/Y', strtotime( $p['echeance'] ) ) ) ?></td>
				<td class="num"><?= e( fkc_money( $p['ttc'] ) ) ?></td>
				<td class="num"><?= $p['regle'] > 0.5 ? e( fkc_money( $p['regle'] ) ) : '—' ?></td>
				<td class="num" style="color:var(--orange)"><strong><?= e( fkc_money( $p['reste'] ) ) ?></strong></td>
				<td><?php if ( $p['jours'] > 0 ) : ?><span style="color:<?= $p['jours'] > 60 ? 'var(--danger)' : 'var(--orange)' ?>"><?= (int) $p['jours'] ?> j de retard</span><?php else : ?><span class="muted">Non échue</span><?php endif; ?></td>
				<td class="right"><a class="btn btn-primary btn-sm" href="<?= e( url( 'comptabilite/fournisseurs/' . (int) $p['fournisseur_id'] . '/payer?facture=' . (int) $p['id'] ) ) ?>">Payer</a></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( $postes ) : ?><tfoot><tr class="total">
			<td class="right" colspan="7">Total à régler</td>
			<td class="num"><?= e( fkc_money( $totalDu ) ) ?></td><td></td><td></td>
		</tr></tfoot><?php endif; ?>
	</table></div>

<?php else : ?>

	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : nom, compte, NCC, téléphone…' ) ); ?>
	<div class="card card-flush"><table class="table">
		<thead><tr><th>Fournisseur</th><th>NCC</th><th>Compte</th><th class="num">Facturé</th><th class="num">Payé</th><th class="num">Factures ouvertes</th><th class="num">Solde dû</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $fournisseurs ) : ?><tr><td colspan="8" class="empty">Aucun fournisseur.</td></tr>
		<?php else : foreach ( $fournisseurs as $f ) : ?>
			<tr>
				<td><strong><?= e( $f['nom'] ) ?></strong></td>
				<td><span class="code"><?= e( $f['ncc'] ?: '—' ) ?></span></td>
				<td><span class="code"><?= e( $f['compte'] ) ?></span></td>
				<td class="num"><?= e( fkc_money( $f['total_facture'] ) ) ?></td>
				<td class="num muted"><?= e( fkc_money( $f['total_paye'] ) ) ?></td>
				<td class="num"><?= $f['nb_ouvertes'] > 0 ? (int) $f['nb_ouvertes'] : '—' ?></td>
				<td class="num" style="color:<?= $f['solde'] > 0 ? 'var(--orange)' : 'var(--ok)' ?>"><?= e( fkc_money( $f['solde'] ) ) ?></td>
				<td class="right">
					<a class="btn <?= $f['solde'] > 0 ? 'btn-primary' : 'btn-ghost' ?> btn-sm" href="<?= e( url( 'comptabilite/fournisseurs/' . (int) $f['id'] . '/payer' ) ) ?>">Payer</a>
					<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/fournisseurs/' . (int) $f['id'] . '/modifier' ) ) ?>">Éditer</a>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table></div>

<?php endif; ?>
