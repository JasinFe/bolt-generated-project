<?php /** @var array $fournisseurs @var float $total @var int $nb @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'comptabilite::_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card">
	<div class="card-body" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
		<div><span class="muted">Total dettes fournisseurs (factures d'achat non payées)</span>
			<div style="font-size:1.8em;font-weight:700;color:var(--orange)"><?= e( fkc_money( $total ) ) ?> FCFA</div></div>
		<div class="muted"><?= (int) $nb ?> fournisseur(s) créancier(s)</div>
	</div>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Fournisseur</th><th class="num">Facturé</th><th class="num">Payé</th><th class="num">Solde dû</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $fournisseurs ) : ?><tr><td colspan="5" class="empty">Aucune dette fournisseur en cours.</td></tr>
	<?php else : foreach ( $fournisseurs as $f ) : ?>
		<tr>
			<td><strong><?= e( $f['nom'] ) ?></strong></td>
			<td class="num"><?= e( fkc_money( $f['total_facture'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $f['total_paye'] ) ) ?></td>
			<td class="num" style="color:var(--orange)"><?= e( fkc_money( $f['solde'] ) ) ?></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/fournisseurs/' . (int) $f['id'] . '/payer' ) ) ?>">Payer</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $fournisseurs ) : ?><tfoot><tr class="total"><td class="right">Total</td><td></td><td></td><td class="num"><?= e( fkc_money( $total ) ) ?></td><td></td></tr></tfoot><?php endif; ?>
</table></div>
