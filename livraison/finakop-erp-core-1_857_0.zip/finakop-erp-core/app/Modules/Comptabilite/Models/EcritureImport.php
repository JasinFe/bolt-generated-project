<?php
/**
 * Import d'écritures comptables depuis un fichier CSV suivant un modèle.
 *
 * Une ligne du fichier = une ligne d'écriture. Regroupement en une même écriture :
 *  - si la pièce est renseignée : lignes partageant (date, journal, pièce) ;
 *  - si la pièce est vide : lignes partageant (date, journal, libellé), la référence
 *    de pièce étant alors générée par journal, dans l'ordre chronologique
 *    (JOURNAL-ANNEE-NNN), à la suite des pièces déjà existantes.
 *
 * DEUX NUMÉROTATIONS À NE PAS CONFONDRE
 *
 *  - la PIÈCE (colonne « piece » du fichier) est la référence du justificatif :
 *    numéro de facture fournisseur, de reçu, de bordereau. Elle vient de
 *    l'extérieur, l'utilisateur la saisit ;
 *  - le NUMÉRO D'ÉCRITURE (AAnnnnnn, ex. 26000001) est attribué par
 *    l'application, séquentiellement, par journal et par exercice. Il n'est
 *    NI demandé dans le fichier, NI modifiable : le fournir n'aurait pas de sens
 *    puisque la suite doit rester continue et propre à chaque journal.
 *
 * Chaque écriture doit être équilibrée. Réutilise FKC_Ecriture::enregistrer, donc
 * l'import respecte le brouillard : si celui-ci est actif, les écritures y sont
 * déposées pour vérification et ne consomment aucun numéro tant qu'elles ne sont
 * pas comptabilisées.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EcritureImport {

	/** Colonnes attendues, dans l'ordre. */
	public static function colonnes() {
		return array( 'date', 'journal', 'piece', 'libelle', 'compte', 'libelle_ligne', 'debit', 'credit', 'axe', 'valeur' );
	}

	/**
	 * Lignes du modèle CSV à télécharger (en-tête + exemples).
	 *
	 * Les exemples sont construits à partir de comptes RÉELLEMENT présents dans
	 * le plan de la société, et non de numéros écrits en dur. Le modèle livré
	 * jusqu'ici citait « 6055 », absent du plan SYSCOHADA semé : l'utilisateur
	 * qui téléchargeait le modèle et le renvoyait tel quel — le premier geste
	 * qu'on fait avec un modèle — voyait deux écritures sur trois rejetées.
	 *
	 * L'année des exemples suit l'exercice en cours, pour ne pas suggérer une
	 * date qui tomberait dans une période déjà clôturée.
	 */
	public static function modele() {
		$an = date( 'Y' );
		$c  = self::comptesExemple();
		return array(
			self::colonnes(),
			array( $an . '-01-31', 'OD', '', 'Régularisation diverse', $c['charge_eau'], 'Eau', '50000', '', '', '' ),
			array( $an . '-01-31', 'OD', '', 'Régularisation diverse', $c['banque'], 'Banque', '', '50000', '', '' ),
			array( $an . '-02-05', 'AC', 'FA-0125', 'Achat fournitures', $c['achat'], 'Achats', '120000', '', '', '' ),
			array( $an . '-02-05', 'AC', 'FA-0125', 'Achat fournitures', $c['tva_ded'], 'TVA déductible', '21600', '', '', '' ),
			array( $an . '-02-05', 'AC', 'FA-0125', 'Achat fournitures', $c['fournisseur'], 'Fournisseur', '', '141600', '', '' ),
		);
	}

	/**
	 * Comptes d'exemple pour le modèle, choisis dans le plan de la société.
	 *
	 * Cherche le premier compte existant parmi une liste de candidats classés du
	 * plus précis au plus général, et retombe sur la racine si le plan a été
	 * personnalisé au point de n'en contenir aucun.
	 */
	/** Accès de test aux comptes d'exemple (voir tests/run.php, groupe 24). */
	public static function comptesExempleTest() { return self::comptesExemple(); }

	protected static function comptesExemple() {
		$choisir = function ( array $candidats, $defaut ) {
			foreach ( $candidats as $num ) {
				try {
					$r = FKC_DB::q( 'SELECT numero FROM comptes WHERE numero=? OR numero=? LIMIT 1', array( $num, str_pad( $num, 6, '0' ) ) )->fetch();
					if ( $r ) { return (string) $r['numero']; }
				} catch ( \Throwable $e ) {}
			}
			// Aucun candidat : premier compte de la classe, ou la racine.
			try {
				$r = FKC_DB::q( 'SELECT numero FROM comptes WHERE numero LIKE ? ORDER BY numero LIMIT 1', array( substr( $defaut, 0, 2 ) . '%' ) )->fetch();
				if ( $r ) { return (string) $r['numero']; }
			} catch ( \Throwable $e ) {}
			return $defaut;
		};
		return array(
			'charge_eau'  => $choisir( array( '605100', '605000', '601000' ), '605100' ),
			'banque'      => $choisir( array( '521100', '521000' ), '521100' ),
			'achat'       => $choisir( array( '605200', '605000', '601000' ), '601000' ),
			'tva_ded'     => $choisir( array( '445200', '445100' ), '445200' ),
			'fournisseur' => $choisir( array( '401100', '401000' ), '401100' ),
		);
	}

	/** Carte code d'axe analytique (majuscules) => id. */
	protected static function axes() {
		$m = array();
		if ( class_exists( 'FKC_Axe' ) ) {
			try { foreach ( FKC_Axe::all() as $a ) { $m[ strtoupper( $a['code'] ) ] = (int) $a['id']; } } catch ( \Throwable $e ) {}
		}
		return $m;
	}
	/** Id d'une valeur analytique par (axe, code) ; 0 si absente. */
	protected static function valeurId( $axeId, $code ) {
		$code = strtoupper( trim( (string) $code ) );
		if ( ! $axeId || '' === $code ) { return 0; }
		try {
			$r = FKC_DB::q( 'SELECT id FROM analytique_valeurs WHERE axe_id=? AND UPPER(code)=?', array( (int) $axeId, $code ) )->fetch();
			return $r ? (int) $r['id'] : 0;
		} catch ( \Throwable $e ) { return 0; }
	}

	protected static function num( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return 0.0; }
		return (float) str_replace( array( ' ', "\xc2\xa0", ',' ), array( '', '', '.' ), $v );
	}

	/** Carte code de journal (majuscules) => id. */
	/**
	 * NORMALISE LA DATE D'UNE LIGNE — le défaut qui rendait l'import inutilisable.
	 *
	 * L'import n'acceptait que « AAAA-MM-JJ », à la lettre. Or le geste
	 * naturel est celui-ci : on télécharge le modèle, on l'ouvre dans Excel,
	 * on remplit, on enregistre. Excel en français RÉÉCRIT les dates au
	 * format local à la première ouverture — « 2025-03-15 » revient
	 * « 15/03/2025 » — et le fichier produit par notre propre modèle était
	 * refusé ligne par ligne.
	 *
	 * Le message ne disait pas « format » mais « Date invalide ». Un
	 * utilisateur qui vient d'ouvrir son exercice N-1 en conclut, très
	 * logiquement, que l'application refuse la période. Ce n'était pas la
	 * période : c'était le séparateur.
	 *
	 * L'AMBIGUÏTÉ EST TRANCHÉE PAR LE CALENDRIER, PAS PAR UN RÉGLAGE.
	 * « 03/04/2025 » peut se lire 3 avril (France) ou 4 mars (États-Unis).
	 * On lit JJ/MM en premier — c'est la convention du pays et celle d'Excel
	 * en français. On ne bascule sur MM/JJ que lorsque la lecture française
	 * est IMPOSSIBLE : « 03/15/2025 » n'a pas de quinzième mois. Ainsi la
	 * lecture n'est jamais silencieusement fausse quand les deux sont
	 * possibles : elle suit toujours la même règle, annoncée à l'écran.
	 *
	 * ET LA DATE DOIT EXISTER. L'ancien contrôle était une expression
	 * régulière : « 2025-02-31 » la satisfaisait et partait en base, où il
	 * devenait un 3 mars silencieux ou une ligne perdue entre deux états.
	 * `checkdate()` refuse ce que le calendrier refuse.
	 *
	 * @param string $v Valeur brute de la colonne date.
	 * @return string Date AAAA-MM-JJ, ou '' si elle n'est pas interprétable.
	 */
	public static function normaliserDate( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return ''; }
		$v = str_replace( array( '．', '·' ), '.', $v );

		$valide = function ( $a, $m, $j ) {
			$a = (int) $a; $m = (int) $m; $j = (int) $j;
			if ( $a < 1900 || $a > 2200 ) { return ''; }
			if ( ! checkdate( $m, $j, $a ) ) { return ''; }
			return sprintf( '%04d-%02d-%02d', $a, $m, $j );
		};

		// AAAA-MM-JJ, AAAA/MM/JJ, AAAA.MM.JJ — l'année d'abord ne s'ambiguïse pas.
		if ( preg_match( '~^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$~', $v, $m ) ) {
			return $valide( $m[1], $m[2], $m[3] );
		}

		// JJ/MM/AAAA et ses variantes de séparateur.
		if ( preg_match( '~^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$~', $v, $m ) ) {
			$fr = $valide( $m[3], $m[2], $m[1] );   // lecture française : jour, mois
			if ( '' !== $fr ) { return $fr; }
			return $valide( $m[3], $m[1], $m[2] );  // repli : mois, jour
		}

		/*
		 * AAAAMMJJ sans séparateur — ce que rendent beaucoup d'exports
		 * bancaires et de logiciels de caisse. On ne tente PAS JJMMAAAA :
		 * les deux formes se ressemblent trop pour qu'un choix soit honnête.
		 */
		if ( preg_match( '~^(\d{4})(\d{2})(\d{2})$~', $v, $m ) ) {
			return $valide( $m[1], $m[2], $m[3] );
		}

		/*
		 * NUMÉRO DE SÉRIE EXCEL (jours depuis le 30/12/1899). Un tableur qui
		 * exporte une colonne de dates mal typée rend « 45731 ». La reprise de
		 * balance savait déjà le lire ; l'import d'écritures l'ignorait. Deux
		 * importateurs du même module ne doivent pas comprendre deux langues.
		 * Plage bornée à 2000 → 2100 : au-delà, un nombre à cinq chiffres est
		 * plus probablement un montant qu'une date.
		 */
		if ( preg_match( '~^\d{5}$~', $v ) ) {
			$serie = (int) $v;
			if ( $serie >= 36526 && $serie <= 73415 ) { return date( 'Y-m-d', ( $serie - 25569 ) * 86400 ); }
		}

		return '';
	}

	protected static function journaux() {
		$m = array();
		foreach ( FKC_Journal::all() as $j ) { $m[ strtoupper( $j['code'] ) ] = (int) $j['id']; }
		return $m;
	}

	/** Plus grand numéro de séquence déjà utilisé pour une pièce « JOURNAL-ANNEE-NNN ». */
	protected static function maxPieceSeq( $journal, $year ) {
		$prefix = $journal . '-' . $year . '-';
		$max = 0;
		foreach ( array( 'ecritures', 'ecritures_brouillon' ) as $t ) {
			try {
				foreach ( FKC_DB::q( "SELECT piece FROM {$t} WHERE piece LIKE ?", array( $prefix . '%' ) )->fetchAll() as $r ) {
					$suf = (int) substr( (string) $r['piece'], strlen( $prefix ) );
					if ( $suf > $max ) { $max = $suf; }
				}
			} catch ( \Throwable $e ) {}
		}
		return $max;
	}

	/**
	 * Analyse le contenu CSV brut → groupes d'écritures structurés et validés.
	 * @return array liste de groupes : array( cle, date, journal, piece, libelle, lignes[], debit, credit, equilibre, erreurs[] )
	 */
	public static function analyser( $raw ) {
		$raw = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $raw ); // retire BOM
		$lignesTxt = preg_split( '/\r\n|\r|\n/', $raw );
		$delim = ( substr_count( (string) ( $lignesTxt[0] ?? '' ), ';' ) >= substr_count( (string) ( $lignesTxt[0] ?? '' ), ',' ) ) ? ';' : ',';
		$journaux = self::journaux();
		$axes = self::axes();

		$groupes = array(); $ordre = array(); $i = 0;
		foreach ( $lignesTxt as $row ) {
			$i++;
			if ( '' === trim( $row ) ) { continue; }
			$cells = str_getcsv( $row, $delim );
			$first = strtolower( trim( (string) ( $cells[0] ?? '' ) ) );
			if ( 1 === $i || 'date' === $first ) { continue; } // en-tête

			$dateBrute = trim( (string) ( $cells[0] ?? '' ) );
			$date   = self::normaliserDate( $dateBrute );
			$jcode  = strtoupper( trim( (string) ( $cells[1] ?? '' ) ) );
			$piece  = trim( (string) ( $cells[2] ?? '' ) );
			$lib    = trim( (string) ( $cells[3] ?? '' ) );
			$compte = trim( (string) ( $cells[4] ?? '' ) );
			$libL   = trim( (string) ( $cells[5] ?? '' ) );
			$debit  = self::num( $cells[6] ?? 0 );
			$credit = self::num( $cells[7] ?? 0 );
			$axeCode = strtoupper( trim( (string) ( $cells[8] ?? '' ) ) );
			$valCode = strtoupper( trim( (string) ( $cells[9] ?? '' ) ) );

			/*
			 * LA CLÉ DE REGROUPEMENT EMPLOIE LA DATE NORMALISÉE. Un fichier
			 * dont une moitié vient d'Excel (15/03/2025) et l'autre du modèle
			 * (2025-03-15) décrivait sinon DEUX écritures là où il y en a une,
			 * chacune déséquilibrée — et le rapport d'import accusait
			 * l'utilisateur d'un déséquilibre qu'il n'avait pas commis.
			 */
			$cle = ( '' !== $piece )
				? ( $date . '|' . $jcode . '|P|' . $piece )
				: ( $date . '|' . $jcode . '|L|' . strtolower( $lib ) );
			if ( ! isset( $groupes[ $cle ] ) ) {
				$groupes[ $cle ] = array(
					'cle' => $cle, 'date' => $date, 'date_brute' => $dateBrute, 'journal' => $jcode, 'piece' => $piece,
					'libelle' => $lib, 'lignes' => array(), 'debit' => 0.0, 'credit' => 0.0, 'auto' => false, 'erreurs' => array(),
				);
				$ordre[] = $cle;
			}
			$g =& $groupes[ $cle ];
			if ( '' === $g['libelle'] && '' !== $lib ) { $g['libelle'] = $lib; }

			$cpt = '' !== $compte ? FKC_Compte::byNumero( $compte ) : null;
			if ( ! $cpt ) { $g['erreurs'][] = 'Ligne ' . $i . ' : compte « ' . $compte . ' » introuvable dans le plan comptable.'; }
			if ( $debit <= 0 && $credit <= 0 ) { $g['erreurs'][] = 'Ligne ' . $i . ' : débit ou crédit requis.'; }
			if ( $debit > 0 && $credit > 0 ) { $g['erreurs'][] = 'Ligne ' . $i . ' : une ligne ne peut avoir à la fois un débit et un crédit.'; }

			// Imputation analytique optionnelle (axe + valeur, par leurs codes).
			$axeId = 0; $valId = 0;
			if ( '' !== $axeCode || '' !== $valCode ) {
				if ( '' === $axeCode ) {
					$g['erreurs'][] = 'Ligne ' . $i . ' : axe requis pour la valeur « ' . $valCode . ' ».';
				} elseif ( ! isset( $axes[ $axeCode ] ) ) {
					$g['erreurs'][] = 'Ligne ' . $i . ' : axe analytique « ' . $axeCode . ' » inconnu.';
				} else {
					$axeId = $axes[ $axeCode ];
					if ( '' === $valCode ) {
						$g['erreurs'][] = 'Ligne ' . $i . ' : valeur requise pour l\'axe « ' . $axeCode . ' ».';
					} else {
						$valId = self::valeurId( $axeId, $valCode );
						if ( ! $valId ) { $g['erreurs'][] = 'Ligne ' . $i . ' : valeur « ' . $valCode . ' » inconnue pour l\'axe « ' . $axeCode . ' ».'; }
					}
				}
			}

			$g['lignes'][] = array(
				'ligne' => $i, 'compte' => $compte, 'compte_id' => $cpt ? (int) $cpt['id'] : 0,
				'compte_libelle' => $cpt ? $cpt['libelle'] : '', 'libelle' => $libL ?: $lib,
				'debit' => $debit, 'credit' => $credit,
				'axe' => $axeCode, 'valeur' => $valCode, 'axe_id' => $axeId, 'valeur_id' => $valId,
			);
			$g['debit'] += $debit; $g['credit'] += $credit;
			unset( $g );
		}

		// Numérotation automatique des pièces pour les groupes sans pièce :
		// par journal, dans l'ordre chronologique (ancienneté), à la suite des pièces existantes.
		$autoKeys = array();
		foreach ( $ordre as $cle ) { if ( '' === $groupes[ $cle ]['piece'] ) { $autoKeys[] = $cle; } }
		usort( $autoKeys, function ( $a, $b ) use ( $groupes ) { return strcmp( (string) $groupes[ $a ]['date'], (string) $groupes[ $b ]['date'] ); } );
		$counters = array();
		foreach ( $autoKeys as $cle ) {
			$d = (string) $groupes[ $cle ]['date']; $j = (string) $groupes[ $cle ]['journal'];
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) || ! isset( self::journaux()[ $j ] ) ) { continue; }
			$y = substr( $d, 0, 4 ); $k = $j . '|' . $y;
			if ( ! isset( $counters[ $k ] ) ) { $counters[ $k ] = self::maxPieceSeq( $j, $y ); }
			$counters[ $k ]++;
			$groupes[ $cle ]['piece'] = sprintf( '%s-%s-%03d', $j, $y, $counters[ $k ] );
			$groupes[ $cle ]['auto'] = true;
		}

		$out = array();
		foreach ( $ordre as $cle ) {
			$g = $groupes[ $cle ];
			if ( '' === $g['date'] ) {
				/*
				 * LE MESSAGE CITE CE QU'IL A LU. « Date invalide » tout court
				 * laissait l'utilisateur deviner : il voyait son exercice
				 * ouvert, son fichier rempli, et concluait — raisonnablement —
				 * que l'application refusait la période. Elle refusait un
				 * format.
				 */
				$vue = trim( (string) ( $g['date_brute'] ?? '' ) );
				$g['erreurs'][] = '' === $vue
					? 'Date absente : la première colonne du fichier doit porter la date de l\'écriture.'
					: 'Date « ' . $vue .' » non reconnue. Formats acceptés : AAAA-MM-JJ, JJ/MM/AAAA, JJ-MM-AAAA, JJ.MM.AAAA.';
			}
			if ( '' === $g['journal'] || ! isset( self::journaux()[ $g['journal'] ] ) ) { $g['erreurs'][] = 'Journal « ' . $g['journal'] . ' » inconnu.'; }
			if ( count( $g['lignes'] ) < 2 ) { $g['erreurs'][] = 'Une écriture doit comporter au moins 2 lignes.'; }
			$g['debit'] = round( $g['debit'] ); $g['credit'] = round( $g['credit'] );
			$g['equilibre'] = abs( $g['debit'] - $g['credit'] ) < 1;
			if ( ! $g['equilibre'] ) { $g['erreurs'][] = 'Écriture déséquilibrée (débit ' . fkc_money( $g['debit'] ) . ' ≠ crédit ' . fkc_money( $g['credit'] ) . ').'; }
			$out[] = $g;
		}
		return $out;
	}

	/**
	 * Importe les écritures valides. Les groupes en erreur sont ignorés et rapportés.
	 * @return array array( total, ok, ignores, messages[] )
	 */
	public static function importer( $raw, $brouillard = null ) {
		$groupes = self::analyser( $raw );

		/*
		 * Tri chronologique AVANT import.
		 *
		 * Les numéros d'écriture sont attribués dans l'ordre où les écritures
		 * sont enregistrées. Sans ce tri, un fichier listant mars avant janvier
		 * — cas courant quand on exporte depuis un autre outil — produisait une
		 * suite où l'écriture de mars portait le n°1 et celle de janvier le n°2.
		 * La numérotation contredisait alors la chronologie, ce qu'un contrôleur
		 * relève immédiatement.
		 *
		 * Le tri est stable : à date égale, l'ordre du fichier est conservé, ce
		 * qui rend le résultat prévisible et reproductible.
		 */
		$indexes = array_keys( $groupes );
		usort( $indexes, function ( $x, $y ) use ( $groupes ) {
			$c = strcmp( (string) $groupes[ $x ]['date'], (string) $groupes[ $y ]['date'] );
			return 0 !== $c ? $c : ( $x <=> $y );
		} );
		$tries = array();
		foreach ( $indexes as $i ) { $tries[] = $groupes[ $i ]; }
		$groupes = $tries;
		$jmap = self::journaux();
		$ok = 0; $ignores = 0; $messages = array(); $numeros = array();
		foreach ( $groupes as $g ) {
			$label = ( $g['piece'] ?: $g['libelle'] ?: $g['date'] );
			if ( $g['erreurs'] ) { $ignores++; $messages[] = '✗ ' . $label . ' : ' . implode( ' ', $g['erreurs'] ); continue; }
			$entete = array(
				'journal_id' => $jmap[ $g['journal'] ], 'date_ecriture' => $g['date'],
				'piece' => $g['piece'] ?: null, 'libelle' => $g['libelle'] ?: ( 'Import ' . $g['date'] ),
				'reference' => $g['piece'] ?: null, 'created_by' => FKC_Auth::id(),
			);
			$lignes = array();
			foreach ( $g['lignes'] as $l ) {
				$lignes[] = array( 'compte_id' => $l['compte_id'], 'libelle' => $l['libelle'], 'debit' => $l['debit'], 'credit' => $l['credit'], 'axe_id' => ! empty( $l['axe_id'] ) ? (int) $l['axe_id'] : null, 'valeur_id' => ! empty( $l['valeur_id'] ) ? (int) $l['valeur_id'] : null );
			}
			$opts = array( 'source' => 'import' );
			if ( null !== $brouillard ) { $opts['brouillard'] = (bool) $brouillard; }
			list( $r, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, $opts );
			if ( ! $r ) { $ignores++; $messages[] = '✗ ' . $label . ' : ' . $msg; continue; }
			$ok++;
			/*
			 * Le compte rendu cite le NUMÉRO attribué, pas seulement « importée ».
			 * C'est ce numéro que l'utilisateur retrouvera dans ses états et
			 * qu'il citera en cas de question : le lui donner ici lui évite
			 * d'aller le chercher écriture par écriture.
			 */
			if ( $eid ) {
				$num = '';
				try {
					$num = (string) FKC_DB::q( 'SELECT numero FROM ecritures WHERE id=?', array( (int) $eid ) )->fetchColumn();
				} catch ( \Throwable $e ) {}
				$numeros[] = $num ? ( $g['journal'] . '-' . $num ) : ( '#' . (int) $eid );
				$messages[] = '✓ ' . $label . ' : écriture ' . ( $num ? $g['journal'] . '-' . $num : 'n°' . (int) $eid ) . ' comptabilisée.';
			} else {
				$messages[] = '✓ ' . $label . ' : déposée au brouillard (n°' . (int) $bid . ') — numéro attribué à la comptabilisation.';
			}
		}
		return array(
			'total' => count( $groupes ), 'ok' => $ok, 'ignores' => $ignores,
			'messages' => $messages, 'numeros' => $numeros,
		);
	}
}
