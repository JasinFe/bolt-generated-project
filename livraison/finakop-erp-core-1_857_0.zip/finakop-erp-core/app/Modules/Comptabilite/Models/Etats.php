<?php
/**
 * États financiers SYSCOHADA — Compte de résultat & Bilan.
 * Calculés à partir des soldes des comptes (écriture_lignes), classés par
 * classe/préfixe SYSCOHADA. @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Etats {

	/** Soldes par compte sur la période. solde = débit - crédit. */
	protected static function soldes( $du = null, $au = null ) {
		$where = '1=1'; $args = array();
		if ( $du ) { $where .= ' AND e.date_ecriture>=?'; $args[] = $du; }
		if ( $au ) { $where .= ' AND e.date_ecriture<=?'; $args[] = $au; }
		$rows = FKC_DB::q(
			"SELECT c.numero, c.libelle, c.classe,
				COALESCE(SUM(l.debit),0)  AS debit,
				COALESCE(SUM(l.credit),0) AS credit
			 FROM comptes c
			 JOIN ecriture_lignes l ON l.compte_id=c.id
			 JOIN ecritures e ON e.id=l.ecriture_id
			 WHERE {$where}
			 GROUP BY c.id HAVING debit<>0 OR credit<>0
			 ORDER BY c.numero ASC", $args
		)->fetchAll();
		foreach ( $rows as &$r ) { $r['solde'] = (float) $r['debit'] - (float) $r['credit']; }
		return $rows;
	}

	protected static function pref( $numero, $prefixes ) {
		foreach ( (array) $prefixes as $p ) {
			if ( 0 === strpos( (string) $numero, (string) $p ) ) { return true; }
		}
		return false;
	}

	/** Compte de résultat (charges / produits + soldes intermédiaires). */
	public static function compteResultat( $du = null, $au = null ) {
		$rows = self::soldes( $du, $au );
		$produits = array(); $charges = array();
		foreach ( $rows as $r ) {
			$cl = (int) $r['classe'];
			if ( 7 === $cl || self::pref( $r['numero'], array( '82', '84', '86', '88' ) ) ) {
				$m = -$r['solde']; // produit = crédit - débit
				if ( abs( $m ) >= 0.005 ) { $produits[] = array( 'numero' => $r['numero'], 'libelle' => $r['libelle'], 'montant' => $m ); }
			} elseif ( 6 === $cl || self::pref( $r['numero'], array( '81', '83', '85', '87', '89' ) ) ) {
				$m = $r['solde']; // charge = débit - crédit
				if ( abs( $m ) >= 0.005 ) { $charges[] = array( 'numero' => $r['numero'], 'libelle' => $r['libelle'], 'montant' => $m ); }
			}
		}
		$sum = function ( $list ) { $t = 0; foreach ( $list as $x ) { $t += $x['montant']; } return $t; };
		$tp = $sum( $produits ); $tc = $sum( $charges );

		// Agrégats (soldes intermédiaires de gestion, version synthétique).
		$pp = function ( $list, $prefixes, $excl = array() ) {
			$t = 0; foreach ( $list as $x ) {
				if ( self::pref( $x['numero'], $prefixes ) && ! self::pref( $x['numero'], $excl ) ) { $t += $x['montant']; }
			} return $t;
		};
		/*
		 * LES AGRÉGATS DEVAIENT RETOMBER SUR LE RÉSULTAT (1.564.0).
		 *
		 * L'écran affiche côte à côte un résultat total (produits − charges)
		 * et une cascade d'agrégats censée y aboutir. Le 69 — dotations aux
		 * provisions et dépréciations financières — n'était réclamé par aucun
		 * des deux blocs : ni charge d'exploitation, ni charge financière. Il
		 * sortait donc du total détaillé mais pas de la cascade, qui annonçait
		 * un résultat net plus élevé que le résultat juste au-dessus. Deux
		 * chiffres contradictoires sur le même écran, sans explication.
		 *
		 * Le 69 est financier par nature : il rejoint le résultat financier,
		 * aux côtés du 67. Et parce qu'un oubli de ce genre peut revenir avec
		 * un compte qu'un pack ouvrira demain, l'écart entre la cascade et le
		 * total est désormais calculé et rendu : `agg.ecart` doit être nul.
		 */
		$ca       = $pp( $produits, array( '70' ) );
		$prodExpl = $pp( $produits, array( '70','71','72','73','74','75','78','79' ) );
		$chExpl   = $pp( $charges,  array( '60','61','62','63','64','65','66','68' ) );
		$resExpl  = $prodExpl - $chExpl;
		$resFin   = $pp( $produits, array( '77' ) ) - $pp( $charges, array( '67','69' ) );
		$resHao   = $pp( $produits, array( '82','84','86','88' ) ) - $pp( $charges, array( '81','83','85','87' ) );
		$impot    = $pp( $charges, array( '89' ) );
		$resNet   = $resExpl + $resFin + $resHao - $impot;
		$resultat = $tp - $tc;

		return array(
			'produits' => $produits, 'charges' => $charges,
			'total_produits' => $tp, 'total_charges' => $tc, 'resultat' => $resultat,
			'agg' => array(
				'ca' => $ca, 'res_expl' => $resExpl, 'res_fin' => $resFin,
				'res_hao' => $resHao, 'impot' => $impot, 'res_net' => $resNet,
				// Écart entre la cascade et le résultat détaillé : tout montant
				// non nul désigne un compte qu'aucun agrégat ne réclame.
				'ecart' => round( $resNet - $resultat, 2 ),
			),
		);
	}

	/** Bilan (Actif / Passif), résultat de la période injecté aux capitaux propres. */
	public static function bilan( $du = null, $au = null ) {
		/*
		 * MÊME SOURCE QUE LA BALANCE ET LE GRAND LIVRE (1.798.0).
		 *
		 * Le bilan sommait les mouvements de [du, au] : sans date de début,
		 * tout l'historique — donc chaque À-nouveaux par-dessus les soldes
		 * qu'il reprend ; avec une date de début, rien de ce qui précède. Il
		 * se lit désormais sur les soldes de clôture de la Balance, dont le
		 * solde d'ouverture vient du gestionnaire des À-nouveaux. Le résultat
		 * est celui de l'exercice : les classes 6 à 8 repartent de zéro à son
		 * premier jour.
		 */
		if ( class_exists( 'FKC_SoldeOuverture' ) && class_exists( 'FKC_Rapport' ) ) {
			$auEff = $au ?: date( 'Y-m-d' );
			$duEff = $du ?: FKC_SoldeOuverture::debutDe( FKC_SoldeOuverture::exerciceDe( $auEff ) );
			$rows = array();
			foreach ( FKC_Rapport::balance( $duEff, $auEff ) as $b ) {
				$sol = (float) $b['solde_debiteur'] - (float) $b['solde_crediteur'];
				if ( abs( $sol ) < 0.005 ) { continue; }
				$rows[] = array( 'numero' => $b['numero'], 'libelle' => $b['libelle'], 'classe' => (int) substr( (string) $b['numero'], 0, 1 ), 'solde' => $sol );
			}
		} else {
			$rows = self::soldes( $du, $au );
		}
		/*
		 * Le résultat se déduit des lignes déjà chargées plutôt que d'un second
		 * balayage complet de ecriture_lignes par compteResultat() : c'est le
		 * même chiffre, pour une requête au lieu de deux. Produits et charges
		 * sont les classes 6, 7 et 8 — la classe 8 en fait partie, sans quoi
		 * une cession d'immobilisation déséquilibrerait le bilan.
		 */
		$resultat = 0.0;
		foreach ( $rows as $r ) {
			$c1 = substr( (string) $r['numero'], 0, 1 );
			if ( '6' === $c1 || '7' === $c1 || '8' === $c1 ) { $resultat -= $r['solde']; }
		}

		$actif = array( 'immobilise' => array(), 'circulant' => array(), 'tresorerie' => array() );
		$passif = array( 'capitaux' => array(), 'dettes_fin' => array(), 'circulant' => array(), 'tresorerie' => array() );

		foreach ( $rows as $r ) {
			$cl = (int) $r['classe']; $s = $r['solde']; $num = $r['numero']; $lib = $r['libelle'];
			$add = function ( &$bucket, $montant ) use ( $num, $lib ) {
				if ( abs( $montant ) >= 0.005 ) { $bucket[] = array( 'numero' => $num, 'libelle' => $lib, 'montant' => $montant ); }
			};
			if ( 2 === $cl ) { $add( $actif['immobilise'], $s ); }
			elseif ( 3 === $cl ) { $add( $actif['circulant'], $s ); }
			elseif ( 4 === $cl ) { if ( $s >= 0 ) { $add( $actif['circulant'], $s ); } else { $add( $passif['circulant'], -$s ); } }
			elseif ( 5 === $cl ) { if ( $s >= 0 ) { $add( $actif['tresorerie'], $s ); } else { $add( $passif['tresorerie'], -$s ); } }
			elseif ( 1 === $cl ) {
				if ( self::pref( $num, array( '16','17','18' ) ) ) { $add( $passif['dettes_fin'], -$s ); }
				else { $add( $passif['capitaux'], -$s ); }
			}
		}
		$sum = function ( $list ) { $t = 0; foreach ( $list as $x ) { $t += $x['montant']; } return $t; };

		$tImmo = $sum( $actif['immobilise'] ); $tCircA = $sum( $actif['circulant'] ); $tTreA = $sum( $actif['tresorerie'] );
		$totalActif = $tImmo + $tCircA + $tTreA;
		$tCap = $sum( $passif['capitaux'] ); $tDf = $sum( $passif['dettes_fin'] );
		$tCircP = $sum( $passif['circulant'] ); $tTreP = $sum( $passif['tresorerie'] );
		$totalPassif = $tCap + $resultat + $tDf + $tCircP + $tTreP;

		return array(
			'actif' => array(
				'immobilise' => $actif['immobilise'], 't_immobilise' => $tImmo,
				'circulant' => $actif['circulant'], 't_circulant' => $tCircA,
				'tresorerie' => $actif['tresorerie'], 't_tresorerie' => $tTreA,
				'total' => $totalActif,
			),
			'passif' => array(
				'capitaux' => $passif['capitaux'], 't_capitaux' => $tCap, 'resultat' => $resultat,
				'dettes_fin' => $passif['dettes_fin'], 't_dettes_fin' => $tDf,
				'circulant' => $passif['circulant'], 't_circulant' => $tCircP,
				'tresorerie' => $passif['tresorerie'], 't_tresorerie' => $tTreP,
				'total' => $totalPassif,
			),
			'ecart' => round( $totalActif - $totalPassif, 2 ),
			'equilibre' => abs( $totalActif - $totalPassif ) < 1,
			/*
			 * L'ÉQUILIBRE NE PROUVE RIEN SUR L'OUVERTURE (1.799.0) : un bilan
			 * d'ouverture doublé reste équilibré. Le bilan dit donc aussi si
			 * son solde d'ouverture est fiable, et pourquoi.
			 */
			'ouverture' => self::ouvertureDe( $du, $au ),
		);
	}

	/** Fiabilité de l'ouverture de l'exercice couvert par le bilan. */
	protected static function ouvertureDe( $du, $au ) {
		if ( ! class_exists( 'FKC_SoldeOuverture' ) ) { return array( 'fiable' => true, 'alerte' => '', 'exercice' => null, 'sources' => array() ); }
		$n = FKC_SoldeOuverture::exerciceDe( $au ?: ( $du ?: date( 'Y-m-d' ) ) );
		$f = FKC_SoldeOuverture::fiabilite( $n );
		return array( 'fiable' => $f['fiable'], 'etat' => $f['etat'], 'exercice' => $n, 'raisons' => $f['raisons'],
			'alerte' => $f['fiable'] ? '' : 'OUVERTURE NON FIABLE — ' . implode( ' ', $f['raisons'] ),
			'sources' => FKC_SoldeOuverture::sources( $n ) );
	}
}
