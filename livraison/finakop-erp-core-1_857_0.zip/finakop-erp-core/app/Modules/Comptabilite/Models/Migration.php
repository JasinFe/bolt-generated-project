<?php
/**
 * Migration / reprise de comptabilité — module Comptabilité.
 *
 * Permet à une entreprise venant d'un autre ERP (Odoo, Sage, SAP Business
 * One, Cegid, Dynamics 365, Dolibarr, ERPNext…) de continuer son exercice
 * dans FinaKop. La méthode est universelle : tous ces logiciels exportent une
 * balance et des écritures en CSV. Trois imports :
 *
 *   1. Plan comptable  (numero;libelle) — crée les comptes manquants.
 *   2. Balance de reprise (compte;libelle;debit;credit) — génère UNE écriture
 *      de reprise équilibrée : à-nouveaux (bilan seul, classes 1-5, reprise au
 *      1er jour d'exercice) ou balance complète (classes 6-7 incluses,
 *      reprise en cours d'exercice).
 *   3. Écritures détaillées (date;journal;piece;compte;libelle;debit;credit)
 *      — regroupées par (date, journal, pièce), équilibre contrôlé par pièce.
 *
 * Robustesse : détection du séparateur (; , tab), BOM UTF-8, entêtes tolérants
 * (français/anglais : « Compte/Account », « Débit/Debit »…), montants aux
 * formats « 1 234,56 » ou « 1,234.56 ». Chaque import s'exécute d'abord en
 * APERÇU (rapport d'anomalies, totaux) puis en EXÉCUTION, dans une transaction.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ComptaMigration {

	/* ── Lecture CSV tolérante ───────────────────────────────────────────── */

	/** Parse un contenu CSV : détecte séparateur/BOM, renvoie lignes de cellules. */
	public static function lireCsv( $contenu ) {
		$contenu = (string) $contenu;
		if ( "\xEF\xBB\xBF" === substr( $contenu, 0, 3 ) ) { $contenu = substr( $contenu, 3 ); } // BOM
		if ( ! mb_check_encoding_safe( $contenu ) ) { $contenu = mb_convert_encoding_safe( $contenu ); } // latin1 → UTF-8
		$lignes = preg_split( "/\r\n|\n|\r/", trim( $contenu ) );
		if ( ! $lignes || '' === trim( $lignes[0] ) ) { return array(); }
		// Séparateur : celui qui découpe le plus la 1re ligne.
		$sep = ';'; $max = 0;
		foreach ( array( ';', ',', "\t", '|' ) as $c ) {
			$n = count( str_getcsv( $lignes[0], $c, '"', '\\' ) );
			if ( $n > $max ) { $max = $n; $sep = $c; }
		}
		$out = array();
		foreach ( $lignes as $l ) {
			if ( '' === trim( $l ) ) { continue; }
			$out[] = array_map( 'trim', str_getcsv( $l, $sep, '"', '\\' ) );
		}
		return $out;
	}

	/** Normalise un entête (minuscules, sans accents/espaces). */
	protected static function norm( $s ) {
		$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $s, 'UTF-8' ) : strtolower( (string) $s );
		$s = strtr( $s, array( 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'à' => 'a', 'î' => 'i', 'ô' => 'o', 'û' => 'u', 'ç' => 'c' ) );
		return preg_replace( '/[^a-z0-9]/', '', $s );
	}

	/**
	 * Repère les colonnes par entêtes tolérants (fr/en). $roles : role => alias[].
	 * @return array{mixed, mixed} ( map role=>index | null, ligneDepart )
	 */
	public static function mapperColonnes( array $lignes, array $roles ) {
		if ( ! $lignes ) { return array( array(), 0 ); }
		$entetes = array_map( array( __CLASS__, 'norm' ), $lignes[0] );
		$map = array(); $trouve = 0;
		foreach ( $roles as $role => $alias ) {
			$map[ $role ] = null;
			foreach ( $entetes as $i => $h ) {
				foreach ( $alias as $a ) {
					if ( $h === $a || 0 === strpos( $h, $a ) ) { $map[ $role ] = $i; $trouve++; break 2; }
				}
			}
		}
		// Au moins 2 rôles reconnus → la 1re ligne est un entête ; sinon ordre positionnel.
		if ( $trouve >= 2 ) { return array( $map, 1 ); }
		$i = 0; foreach ( $roles as $role => $alias ) { $map[ $role ] = $i++; }
		return array( $map, 0 );
	}

	/** Convertit « 1 234,56 », « 1,234.56 », « 1,234 », « (500) », « 2 000 FCFA » en float. */
	public static function montant( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return 0.0; }
		$neg = false;
		if ( preg_match( '/^\((.*)\)$/', $v, $m ) ) { $neg = true; $v = $m[1]; }
		// Suppression de la devise seulement en tant que mot (pas de « F » collé aux chiffres).
		$v = preg_replace( '/\b(?:FCFA|XOF|CFA|F)\b/iu', '', $v );
		$v = str_replace( array( ' ', "\xC2\xA0", "\xE2\x80\xAF" ), '', $v ); // espaces, insécable, fine insécable
		$v = trim( $v );
		if ( '' === $v || ! preg_match( '/\d/', $v ) ) { return 0.0; }
		$aVirgule = false !== strpos( $v, ',' );
		$aPoint = false !== strpos( $v, '.' );
		if ( $aVirgule && $aPoint ) {
			// Les deux présents : le dernier symbole est le séparateur décimal, l'autre les milliers.
			$v = strrpos( $v, ',' ) > strrpos( $v, '.' )
				? str_replace( array( '.', ',' ), array( '', '.' ), $v )   // 1.234,56 → 1234.56
				: str_replace( ',', '', $v );                               // 1,234.56 → 1234.56
		} elseif ( $aVirgule ) {
			// Virgule seule : décimale si 1-2 chiffres après le DERNIER séparateur, sinon milliers.
			$apres = strlen( $v ) - strrpos( $v, ',' ) - 1;
			$nbVirg = substr_count( $v, ',' );
			$v = ( 1 === $nbVirg && ( 1 === $apres || 2 === $apres ) )
				? str_replace( ',', '.', $v )   // 12,50 → 12.50
				: str_replace( ',', '', $v );   // 1,234 ou 1,234,567 → milliers
		} elseif ( $aPoint ) {
			// Point seul : décimale si 1-2 chiffres après le DERNIER point ET un seul point ; sinon milliers.
			$apres = strlen( $v ) - strrpos( $v, '.' ) - 1;
			$nbPoint = substr_count( $v, '.' );
			if ( $nbPoint > 1 || ! ( 1 === $apres || 2 === $apres ) ) { $v = str_replace( '.', '', $v ); } // 1.234 ou 1.234.567 → milliers
		}
		$f = (float) $v;
		// Si après nettoyage il reste des lettres collées (« 1F500 »), l'entrée est
		// ambiguë : on ne devine pas, on renvoie 0 (la ligne sera vue comme vide/nulle).
		if ( preg_match( '/[^\d.\-]/', $v ) ) { return 0.0; }
		return $neg ? -$f : $f;
	}

	/** Résout un code journal en id (fallback : journal OD, sinon le premier, sinon création). */
	protected static function journalId( $code ) {
		$code = strtoupper( trim( (string) $code ) ) ?: 'OD';
		$tous = FKC_Journal::all();
		foreach ( $tous as $j ) { if ( strtoupper( (string) $j['code'] ) === $code ) { return (int) $j['id']; } }
		foreach ( $tous as $j ) { if ( 'OD' === strtoupper( (string) $j['code'] ) ) { return (int) $j['id']; } }
		if ( $tous ) { return (int) $tous[0]['id']; }
		FKC_DB::q( "INSERT INTO journaux(code,libelle) VALUES('OD','Opérations diverses')" );
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/** Cumule un solde sur un compte déjà présent (fusion des doublons), sinon l'ajoute. */
	protected static function cumuler( array &$lignes, $cid, $numClean, $solde ) {
		foreach ( $lignes as &$l ) {
			if ( $l['compte_id'] === $cid ) {
				$net = round( ( $l['debit'] - $l['credit'] ) + $solde, 2 );
				$l['debit'] = $net > 0 ? $net : 0;
				$l['credit'] = $net < 0 ? -$net : 0;
				return;
			}
		}
		unset( $l );
		$lignes[] = array( 'compte_id' => $cid, 'libelle' => 'Reprise ' . $numClean, 'debit' => $solde > 0 ? $solde : 0, 'credit' => $solde < 0 ? -$solde : 0 );
	}

	/** Empreinte stable d'une reprise de balance (anti-doublon). */
	protected static function empreinteReprise( $mode, $date, $debut, $totalBilan, $charges, $produits ) {
		return 'MIG:' . substr( md5( $mode . '|' . $date . '|' . $debut . '|' . round( $totalBilan, 2 ) . '|' . round( $charges, 2 ) . '|' . round( $produits, 2 ) ), 0, 20 );
	}

	/** Une écriture de migration portant cette empreinte existe-t-elle déjà ? */
	protected static function repriseExiste( $empreinte ) {
		try {
			return (bool) FKC_DB::q( 'SELECT 1 FROM ecritures WHERE reference=? LIMIT 1', array( $empreinte ) )->fetchColumn();
		} catch ( \Throwable $e ) { return false; }
	}

	/** Trouve ou crée un compte par numéro. @return array( id|null, cree(bool), erreur ) */
	protected static function compteId( $numero, $libelle, $creer, array &$cache ) {
		$numero = preg_replace( '/\D/', '', (string) $numero );
		if ( '' === $numero || strlen( $numero ) < 2 ) { return array( null, false, 'numéro invalide' ); }
		if ( isset( $cache[ $numero ] ) ) { return array( $cache[ $numero ], false, '' ); }
		$c = FKC_Compte::byNumero( $numero );
		if ( $c ) { $cache[ $numero ] = (int) $c['id']; return array( (int) $c['id'], false, '' ); }
		if ( ! $creer ) { return array( null, false, 'compte inconnu' ); }
		FKC_Compte::create( $numero, ( '' !== trim( (string) $libelle ) ? $libelle : 'Compte ' . $numero ) );
		$c = FKC_Compte::byNumero( $numero );
		$cache[ $numero ] = (int) $c['id'];
		return array( (int) $c['id'], true, '' );
	}

	/* ── 1. Plan comptable ───────────────────────────────────────────────── */
	public static function importerPlan( $csv, $executer = false ) {
		$lignes = self::lireCsv( $csv );
		if ( ! $lignes ) { return array( 'ok' => false, 'crees' => 0, 'existants' => 0, 'anomalies' => array( 'Fichier vide ou illisible.' ), 'execute' => false ); }
		list( $map, $dep ) = self::mapperColonnes( $lignes, array(
			'numero' => array( 'numero', 'compte', 'account', 'code', 'ncompte' ),
			'libelle' => array( 'libelle', 'intitule', 'label', 'name', 'designation', 'description' ),
		) );
		if ( ! isset( $map['numero'] ) || null === $map['numero'] ) { return array( 'ok' => false, 'crees' => 0, 'existants' => 0, 'anomalies' => array( 'Colonne « compte » introuvable.' ), 'execute' => false ); }
		$crees = 0; $existants = 0; $anomalies = array(); $cache = array();
		// La reprise d'un plan comptable est tout ou rien : un import interrompu
		// au milieu laisserait une moitié de plan, plus difficile à rattraper qu'un
		// import à refaire. La version précédente validait sans jamais annuler.
		$importer = function () use ( $lignes, $dep, $map, $executer, &$crees, &$existants, &$anomalies ) {
			foreach ( array_slice( $lignes, $dep ) as $i => $l ) {
				$num = preg_replace( '/\D/', '', (string) ( $l[ $map['numero'] ] ?? '' ) );
				if ( '' === $num || strlen( $num ) < 2 ) {
					if ( '' === trim( implode( '', (array) $l ) ) ) { continue; } // ligne vide
					$anomalies[] = 'Ligne ' . ( $i + 1 + $dep ) . ' : numéro de compte invalide.'; continue;
				}
				if ( FKC_Compte::byNumero( $num ) ) { $existants++; continue; }
				$lib = ( null !== $map['libelle'] && isset( $l[ $map['libelle'] ] ) ) ? (string) $l[ $map['libelle'] ] : ( 'Compte ' . $num );
				if ( $executer ) { FKC_Compte::create( $num, '' !== trim( $lib ) ? $lib : ( 'Compte ' . $num ) ); }
				$crees++;
			}
		};
		if ( $executer ) {
			try {
				FKC_Tx::executer( $importer );
			} catch ( Throwable $e ) {
				fkc_log( 'Migration::plan ' . $e->getMessage(), 'ERROR' );
				return array( 'ok' => false, 'crees' => 0, 'existants' => 0, 'anomalies' => array( 'Import interrompu : aucun compte n\'a été créé.' ), 'execute' => true );
			}
		} else {
			$importer();
		}
		return array( 'ok' => empty( $anomalies ) || $crees + $existants > 0, 'crees' => $crees, 'existants' => $existants, 'anomalies' => $anomalies, 'execute' => (bool) $executer );
	}

	/* ── 2. Balance de reprise ───────────────────────────────────────────── */
	/**
	 * $opts : date (Y-m-d), mode 'anouveaux'|'complete', journal (code, défaut OD),
	 *         creer_comptes (bool, défaut true), executer (bool).
	 */
	/**
	 * $opts :
	 *   date            (Y-m-d) date de bascule / reprise.
	 *   mode            'anouveaux' (bilan seul, ouverture d'exercice)
	 *                 | 'complete'  (reprise en cours d'exercice : bilan + gestion).
	 *   debut_exercice  (Y-m-d) 1er jour de l'exercice en cours. Défaut : 1er janvier
	 *                   de l'année de `date`. Sert à dater les à-nouveaux du bilan.
	 *   compte_resultat (numéro) compte recevant le résultat intermédiaire de la
	 *                   période déjà écoulée. Défaut 130000 (SYSCOHADA).
	 *   journal, creer_comptes, executer.
	 *
	 * Cas gérés :
	 *  - Ouverture d'exercice (mode anouveaux) → 1 écriture d'à-nouveaux (classes
	 *    1-5) à la date de reprise ; les classes 6-7 sont écartées.
	 *  - Reprise EN COURS d'exercice (mode complete) → 2 écritures distinctes,
	 *    comptablement justes :
	 *      (1) À-nouveaux du bilan (classes 1-5) datés du début d'exercice ;
	 *      (2) Gestion de la période écoulée (classes 6-7) datée de la reprise,
	 *          la contrepartie étant le résultat intermédiaire porté au compte
	 *          de résultat. Ainsi le compte de résultat FinaKop au 31/12 inclut
	 *          bien le semestre déjà réalisé, et le bilan reste équilibré.
	 */
	public static function importerBalance( $csv, array $opts = array() ) {
		$date = (string) ( $opts['date'] ?? date( 'Y-m-d' ) );
		$mode = 'complete' === ( $opts['mode'] ?? 'anouveaux' ) ? 'complete' : 'anouveaux';
		$creer = ! isset( $opts['creer_comptes'] ) || (bool) $opts['creer_comptes'];
		$executer = ! empty( $opts['executer'] );
		$debutExercice = (string) ( $opts['debut_exercice'] ?? ( substr( $date, 0, 4 ) . '-01-01' ) );
		$compteResultatNum = preg_replace( '/\D/', '', (string) ( $opts['compte_resultat'] ?? '130000' ) ) ?: '130000';
		$lignes = self::lireCsv( $csv );
		if ( ! $lignes ) {
			return array( 'ok' => false, 'anomalies' => array( 'Fichier vide ou illisible.' ) );
		}
		list( $map, $dep ) = self::mapperColonnes( $lignes, array(
			'numero' => array( 'numero', 'compte', 'account', 'code', 'ncompte' ),
			'libelle' => array( 'libelle', 'intitule', 'label', 'name', 'designation' ),
			'debit' => array( 'debit', 'soldedebit', 'dr' ),
			'credit' => array( 'credit', 'soldecredit', 'cr' ),
		) );
		if ( ! isset( $map['numero'], $map['debit'], $map['credit'] ) || null === $map['numero'] || null === $map['debit'] || null === $map['credit'] ) {
			return array( 'ok' => false, 'anomalies' => array( 'Colonnes introuvables : il faut au minimum compte, débit, crédit.' ) );
		}
		// Ventilation des soldes en deux poches : bilan (1-5) et gestion (6-7).
		$bilan = array(); $gestion = array();
		$tdBilan = 0.0; $tcBilan = 0.0; $charges = 0.0; $produits = 0.0;
		$anomalies = array(); $ignorees = 0; $comptesCrees = 0; $cache = array();
		foreach ( array_slice( $lignes, $dep ) as $i => $l ) {
			$num = (string) ( $l[ $map['numero'] ] ?? '' );
			$d = self::montant( $l[ $map['debit'] ] ?? 0 );
			$c = self::montant( $l[ $map['credit'] ] ?? 0 );
			$solde = round( $d - $c, 2 );
			if ( 0.0 === $solde ) { continue; }
			$numClean = preg_replace( '/\D/', '', $num );
			// Numéro de compte invalide : signalé quel que soit le mode, sans fausser l'équilibre.
			if ( '' === $numClean || strlen( $numClean ) < 2 ) {
				$anomalies[] = 'Ligne ' . ( $i + 1 + $dep ) . ' : numéro de compte « ' . $num . ' » invalide (ignoré).';
				continue;
			}
			$classe = (int) $numClean[0];
			$estGestion = $classe >= 6 && $classe <= 7;
			// En mode à-nouveaux, la gestion (6-7) et le résultat (classe 8, ou 12/13 déjà calculé) sont écartés.
			if ( 'anouveaux' === $mode && ( $estGestion || 8 === $classe ) ) { $ignorees++; continue; }
			list( $cid, $cree, $err ) = self::compteId( $num, (string) ( null !== $map['libelle'] ? ( $l[ $map['libelle'] ] ?? '' ) : '' ), $creer && $executer, $cache );
			if ( null === $cid && ! $executer ) {
				if ( ! $creer && 'compte inconnu' === $err ) { $anomalies[] = 'Ligne ' . ( $i + 1 + $dep ) . ' : compte ' . $num . ' inconnu (création désactivée).'; continue; }
				$cid = -1; $cree = true;
			} elseif ( null === $cid ) {
				$anomalies[] = 'Ligne ' . ( $i + 1 + $dep ) . ' : compte ' . $num . ' — ' . $err . '.';
				continue;
			}
			if ( $cree ) { $comptesCrees++; }
			// Fusion des doublons : un même compte présent sur plusieurs lignes est cumulé.
			if ( $estGestion ) {
				self::cumuler( $gestion, $cid, $numClean, $solde );
				if ( 6 === $classe ) { $charges += $solde; } else { $produits += -$solde; } // produit : solde créditeur
			} else {
				self::cumuler( $bilan, $cid, $numClean, $solde );
				$tdBilan += $solde > 0 ? $solde : 0; $tcBilan += $solde < 0 ? -$solde : 0;
			}
		}

		// Résultat intermédiaire de la période écoulée = produits − charges.
		$resultatPeriode = round( $produits - $charges, 2 );

		// ── Contrôles d'équilibre selon le mode ──
		if ( 'anouveaux' === $mode ) {
			$ecart = round( $tdBilan - $tcBilan, 2 );
			if ( 0.0 !== $ecart ) { $anomalies[] = 'Balance déséquilibrée : débit ' . fkc_money( $tdBilan ) . ' ≠ crédit ' . fkc_money( $tcBilan ) . ' (écart ' . fkc_money( $ecart ) . ' F). Vérifiez l\'export source.'; }
			if ( count( $bilan ) < 2 ) { $anomalies[] = 'Moins de deux lignes de solde exploitables.'; }
		} else {
			// En reprise complète, la balance SOURCE doit être équilibrée dans son ensemble.
			$td = $tdBilan; $tc = $tcBilan;
			foreach ( $gestion as $g ) { $td += $g['debit']; $tc += $g['credit']; }
			$ecart = round( $td - $tc, 2 );
			if ( 0.0 !== $ecart ) { $anomalies[] = 'Balance déséquilibrée : débit ' . fkc_money( $td ) . ' ≠ crédit ' . fkc_money( $tc ) . ' (écart ' . fkc_money( $ecart ) . ' F). En reprise en cours d\'exercice, la balance doit inclure tous les comptes (bilan ET gestion).'; }
			if ( ! $gestion ) { $anomalies[] = 'Aucun compte de gestion (classes 6-7) : pour une simple ouverture d\'exercice, utilisez le mode à-nouveaux.'; }
			if ( $date <= $debutExercice ) { $anomalies[] = 'La date de reprise (' . $date . ') doit être postérieure au début d\'exercice (' . $debutExercice . ').'; }
		}

		/*
		 * UNE REPRISE DE BILAN EST UNE SOURCE D'OUVERTURE (1.798.0).
		 *
		 * Posée sur un exercice qui a déjà ses À-nouveaux, ou dont l'exercice
		 * précédent est tenu dans FinaKop, elle reprend des soldes déjà
		 * présents : le bilan d'ouverture double, et reste équilibré. On le
		 * dit dès la prévisualisation, pas après l'import.
		 */
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			$dateAN = 'complete' === $mode ? $debutExercice : $date;
			$exoAN  = FKC_SoldeOuverture::exerciceDe( $dateAN );
			$anExist = FKC_SoldeOuverture::ecrituresAN( $exoAN );
			if ( $anExist ) {
				$anomalies[] = 'L\'exercice ' . $exoAN . ' possède déjà ses À-nouveaux (écriture #' . implode( ', #', $anExist ) . ') : '
					. 'une reprise de bilan doublerait tous les soldes d\'ouverture. Aucune écriture ne sera créée.';
			} elseif ( FKC_SoldeOuverture::soldesCloture( $exoAN - 1 ) ) {
				$anomalies[] = 'L\'exercice ' . ( $exoAN - 1 ) . ' est déjà tenu dans FinaKop : l\'ouverture de ' . $exoAN
					. ' se fait par la génération des À-nouveaux (Clôture & Ouverture des exercices), pas par une reprise de bilan, '
					. 'qui reprendrait une seconde fois des soldes déjà présents.';
			}
		}

		$resultat = array(
			'ok' => empty( $anomalies ), 'mode' => $mode, 'date' => $date, 'debut_exercice' => $debutExercice,
			'nb_bilan' => count( $bilan ), 'nb_gestion' => count( $gestion ), 'ignorees_gestion' => $ignorees,
			'comptes_a_creer' => $comptesCrees, 'total_debit' => $tdBilan, 'total_credit' => $tcBilan,
			'charges_periode' => $charges, 'produits_periode' => $produits, 'resultat_periode' => $resultatPeriode,
			'compte_resultat' => $compteResultatNum, 'anomalies' => $anomalies, 'execute' => false, 'ecritures' => array(),
		);
		if ( ! $executer || ! empty( $anomalies ) ) { return $resultat; }

		// ── Protection anti-doublon : une reprise déjà effectuée (même empreinte)
		//    n'est pas rejouée en silence. L'empreinte combine mode, date et
		//    totaux ; elle est stockée dans la référence de l'écriture d'à-nouveaux.
		$empreinte = self::empreinteReprise( $mode, $date, $debutExercice, $tdBilan, $charges, $produits );
		if ( ! empty( $opts['forcer_doublon'] ) ) {
			// L'utilisateur a explicitement confirmé un ré-import : on continue.
		} elseif ( self::repriseExiste( $empreinte ) ) {
			$resultat['anomalies'][] = 'Cette reprise semble déjà avoir été importée (même date et mêmes montants). Aucune écriture créée. Pour forcer un nouvel import, cochez « Autoriser un ré-import ».';
			$resultat['doublon'] = true; $resultat['ok'] = false;
			return $resultat;
		}

		// ── Exécution ──
		$eids = array();
		try {
			$jid = self::journalId( (string) ( $opts['journal'] ?? 'OD' ) );
			// (1) À-nouveaux du bilan. En reprise en cours d'exercice, ils sont datés
			//     du début d'exercice ; en ouverture, de la date de reprise.
			$dateBilan = 'complete' === $mode ? $debutExercice : $date;
			$lignesBilan = $bilan;
			if ( 'complete' === $mode && 0.0 !== $resultatPeriode ) {
				// Le bilan source inclut déjà le résultat de la période dans ses capitaux
				// propres (ou l'inclura via l'écriture de gestion). Pour équilibrer les
				// à-nouveaux du bilan SEUL, on neutralise provisoirement le résultat au
				// compte de résultat, que l'écriture de gestion viendra solder.
				$rid = self::compteResultat( $compteResultatNum, $creer, $cache );
				if ( null === $rid ) { throw new \RuntimeException( 'Compte de résultat ' . $compteResultatNum . ' introuvable.' ); }
				// resultatPeriode > 0 (bénéfice) : au crédit des à-nouveaux (réserve provisoire).
				$lignesBilan[] = array( 'compte_id' => $rid, 'libelle' => 'Résultat intermédiaire (à solder)', 'debit' => $resultatPeriode < 0 ? -$resultatPeriode : 0, 'credit' => $resultatPeriode > 0 ? $resultatPeriode : 0 );
			}
			if ( count( $lignesBilan ) >= 2 ) {
				$e1 = array( 'date_ecriture' => $dateBilan, 'journal_id' => $jid, 'libelle' => 'À-nouveaux — reprise de bilan (migration)', 'piece' => 'MIGRATION-AN-' . date( 'Ymd' ), 'reference' => $empreinte );
				// Marqueurs STRUCTURÉS (1.799.0) : la reprise se reconnaît à ce
				// qu'elle est, pas à son libellé ni à sa pièce.
				list( $ok, $msg, $eid ) = FKC_Ecriture::enregistrer( $e1, $lignesBilan, array( 'brouillard' => false, 'source' => 'migration',
					'origine' => 'ouverture', 'fait' => 'reprise_bilan' ) );
				if ( ! $ok ) { throw new \RuntimeException( 'À-nouveaux : ' . $msg ); }
				$eids[] = (int) $eid;
			}
			// (2) Gestion de la période (reprise en cours d'exercice uniquement).
			if ( 'complete' === $mode && $gestion ) {
				$lignesGestion = $gestion;
				$rid = self::compteResultat( $compteResultatNum, $creer, $cache );
				if ( null === $rid ) { throw new \RuntimeException( 'Compte de résultat ' . $compteResultatNum . ' introuvable.' ); }
				// Contrepartie = résultat de la période. Charges (débit) et produits (crédit)
				// se soldent par le compte de résultat, qui annule la neutralisation ci-dessus.
				// resultatPeriode > 0 (bénéfice) : charges<produits → il manque du débit → résultat au débit.
				$lignesGestion[] = array( 'compte_id' => $rid, 'libelle' => 'Résultat de la période reprise', 'debit' => $resultatPeriode > 0 ? $resultatPeriode : 0, 'credit' => $resultatPeriode < 0 ? -$resultatPeriode : 0 );
				$e2 = array( 'date_ecriture' => $date, 'journal_id' => $jid, 'libelle' => 'Reprise gestion période (charges & produits) — migration', 'piece' => 'MIGRATION-GES-' . date( 'Ymd' ) );
				list( $ok, $msg, $eid ) = FKC_Ecriture::enregistrer( $e2, $lignesGestion, array( 'brouillard' => false, 'source' => 'migration' ) );
				if ( ! $ok ) { throw new \RuntimeException( 'Gestion : ' . $msg ); }
				$eids[] = (int) $eid;
			}
			if ( ! $eids ) { throw new \RuntimeException( 'Aucune écriture générée.' ); }
			if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'compta_migration_balance', 'Reprise (' . $mode . ') : ' . count( $eids ) . ' écriture(s) ' . implode( ',', $eids ) . ', résultat période ' . fkc_money( $resultatPeriode ) . ' F' ); }
			$resultat['execute'] = true; $resultat['ecritures'] = $eids; $resultat['ecriture_id'] = $eids[0]; $resultat['ok'] = true;
			return $resultat;
		} catch ( \Throwable $e ) {
			if ( $eids ) { self::supprimerEcritures( $eids ); }
			$resultat['anomalies'][] = $e->getMessage() . ' — reprise annulée, rien n\'a été enregistré.'; $resultat['ok'] = false;
			return $resultat;
		}
	}

	/** Résout (ou crée) le compte de résultat pivot pour la reprise. */
	protected static function compteResultat( $numero, $creer, array &$cache ) {
		list( $cid ) = self::compteId( $numero, 'Résultat net de l\'exercice', $creer, $cache );
		return $cid;
	}

	/* ── 3. Écritures détaillées ─────────────────────────────────────────── */
	/** $opts : creer_comptes, journal_defaut (OD), executer. Groupe par (date, journal, pièce). */
	public static function importerEcritures( $csv, array $opts = array() ) {
		$creer = ! isset( $opts['creer_comptes'] ) || (bool) $opts['creer_comptes'];
		$executer = ! empty( $opts['executer'] );
		$lignes = self::lireCsv( $csv );
		if ( ! $lignes ) { return array( 'ok' => false, 'anomalies' => array( 'Fichier vide ou illisible.' ) ); }
		list( $map, $dep ) = self::mapperColonnes( $lignes, array(
			'date' => array( 'date', 'ecrdate', 'postingdate', 'datepiece' ),
			'journal' => array( 'journal', 'jrn', 'code journal', 'codejournal' ),
			'piece' => array( 'piece', 'numeropiece', 'ecrnum', 'ref', 'reference', 'entry', 'move', 'voucher' ),
			'numero' => array( 'numero', 'compte', 'account', 'comptenum', 'code' ),
			'libelle' => array( 'libelle', 'label', 'intitule', 'description', 'ecrlib' ),
			'debit' => array( 'debit', 'dr' ),
			'credit' => array( 'credit', 'cr' ),
		) );
		foreach ( array( 'date', 'numero', 'debit', 'credit' ) as $r ) {
			if ( null === $map[ $r ] ) { return array( 'ok' => false, 'anomalies' => array( 'Colonne « ' . $r . ' » introuvable.' ) ); }
		}
		$groupes = array(); $anomalies = array(); $cache = array(); $comptesCrees = 0; $comptesVus = array();
		foreach ( array_slice( $lignes, $dep ) as $i => $l ) {
			$brut = (string) ( $l[ $map['date'] ] ?? '' );
			$date = self::normaliserDate( $brut );
			if ( ! $date ) {
				// Ligne sans date exploitable : souvent un pied de page (« TOTAL ») → ignorée si tout est vide.
				if ( '' === trim( implode( '', $l ) ) ) { continue; }
				$anomalies[] = 'Ligne ' . ( $i + 1 + $dep ) . ' : date « ' . $brut . ' » illisible.'; continue;
			}
			$d = self::montant( $l[ $map['debit'] ] ?? 0 ); $c = self::montant( $l[ $map['credit'] ] ?? 0 );
			// Une ligne portant débit ET crédit est réduite à son solde net (SYSCOHADA : une ligne = un sens).
			$net = round( $d - $c, 2 );
			if ( 0.0 === $net ) { continue; }
			$numBrut = (string) ( $l[ $map['numero'] ] ?? '' );
			$numClean = preg_replace( '/\D/', '', $numBrut );
			if ( '' === $numClean || strlen( $numClean ) < 2 ) { $anomalies[] = 'Ligne ' . ( $i + 1 + $dep ) . ' : compte « ' . $numBrut . ' » invalide.'; continue; }
			// Dénombrement des comptes à créer (aperçu comme exécution).
			if ( ! isset( $comptesVus[ $numClean ] ) ) {
				$comptesVus[ $numClean ] = true;
				if ( ! FKC_Compte::byNumero( $numClean ) ) { $comptesCrees++; }
			}
			$cle = $date . '|' . ( null !== $map['journal'] ? strtoupper( (string) ( $l[ $map['journal'] ] ?? '' ) ) : '' ) . '|' . ( null !== $map['piece'] ? (string) ( $l[ $map['piece'] ] ?? '' ) : '' );
			$groupes[ $cle ][] = array( 'i' => $i + 1 + $dep, 'numero' => $numBrut, 'libelle' => (string) ( null !== $map['libelle'] ? ( $l[ $map['libelle'] ] ?? '' ) : '' ), 'debit' => $net > 0 ? $net : 0, 'credit' => $net < 0 ? -$net : 0 );
		}
		if ( ! $groupes && ! $anomalies ) { $anomalies[] = 'Aucune écriture exploitable dans le fichier.'; }

		/*
		 * Tri chronologique des groupes avant enregistrement. La clé commence par
		 * la date (« AAAA-MM-JJ|journal|pièce »), donc un tri sur les clés suffit.
		 *
		 * Sans lui, les numéros d'écriture suivaient l'ordre des lignes du
		 * fichier : un export listant mars avant janvier produisait une suite où
		 * l'écriture de mars portait le n°1. La numérotation contredisait la
		 * chronologie, ce qu'un contrôle relève aussitôt.
		 */
		ksort( $groupes, SORT_STRING );

		$importees = 0; $lignesTot = 0; $td = 0.0; $eids = array();
		try {
			foreach ( $groupes as $cle => $ls ) {
				list( $date, $journal, $piece ) = explode( '|', $cle, 3 );
				$sd = 0.0; $sc = 0.0; $ecr = array();
				foreach ( $ls as $l ) {
					list( $cid, $cree, $err ) = self::compteId( $l['numero'], $l['libelle'], $creer && $executer, $cache );
					if ( null === $cid && $executer ) { throw new \RuntimeException( 'Ligne ' . $l['i'] . ' : compte ' . $l['numero'] . ' — ' . $err . '.' ); }
					$ecr[] = array( 'compte_id' => $cid ?? -1, 'libelle' => $l['libelle'], 'debit' => $l['debit'], 'credit' => $l['credit'] );
					$sd += $l['debit']; $sc += $l['credit'];
				}
				if ( ! fkc_equilibre( $sd, $sc ) ) { $anomalies[] = 'Pièce « ' . ( $piece ?: $date ) . ' » déséquilibrée (' . fkc_money( $sd ) . ' / ' . fkc_money( $sc ) . ').'; continue; }
				if ( count( $ecr ) < 2 ) { $anomalies[] = 'Pièce « ' . ( $piece ?: $date ) . ' » : moins de deux lignes.'; continue; }
				if ( $executer ) {
					$entete = array( 'date_ecriture' => $date, 'journal_id' => self::journalId( $journal ?: (string) ( $opts['journal_defaut'] ?? 'OD' ) ), 'libelle' => 'Migration — pièce ' . ( $piece ?: $date ), 'piece' => $piece ?: ( 'MIG-' . $date ) );
					list( $ok, $msg, $eid ) = FKC_Ecriture::enregistrer( $entete, $ecr, array( 'brouillard' => false, 'source' => 'migration' ) );
					if ( ! $ok ) { throw new \RuntimeException( 'Pièce « ' . $piece . ' » : ' . $msg ); }
					$eids[] = (int) $eid;
				}
				$importees++; $lignesTot += count( $ecr ); $td += $sd;
			}
			if ( $executer && $anomalies && $eids ) {
				// Des pièces sont en anomalie : annuler tout le lot (cohérence du transfert).
				self::supprimerEcritures( $eids ); $eids = array();
				return array( 'ok' => false, 'anomalies' => array_merge( $anomalies, array( 'Import annulé : corriger le fichier puis réimporter en une fois.' ) ), 'execute' => false );
			}
			if ( $executer && class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'compta_migration_ecritures', $importees . ' écritures importées (' . $lignesTot . ' lignes)' ); }
		} catch ( \Throwable $e ) {
			if ( $eids ) { self::supprimerEcritures( $eids ); }
			return array( 'ok' => false, 'anomalies' => array_merge( $anomalies, array( $e->getMessage() . ' — import annulé, rien n\'a été enregistré.' ) ), 'execute' => false );
		}
		return array( 'ok' => empty( $anomalies ), 'ecritures' => $importees, 'lignes' => $lignesTot, 'total_debit' => $td, 'comptes_a_creer' => $comptesCrees, 'anomalies' => $anomalies, 'execute' => $executer && empty( $anomalies ) );
	}

	/** Annulation d'un lot importé (rollback manuel : save() est transactionnel à l'unité). */
	protected static function supprimerEcritures( array $ids ) {
		if ( ! $ids ) { return; }
		$in = implode( ',', array_map( 'intval', $ids ) );
		FKC_DB::conn()->exec( "DELETE FROM ecriture_lignes WHERE ecriture_id IN($in)" );
		FKC_DB::conn()->exec( "DELETE FROM ecritures WHERE id IN($in)" );
	}

	/** Dates : Y-m-d, d/m/Y, d-m-Y, Ymd, ou numéro de série Excel (>= 20000). */
	public static function normaliserDate( $v ) {
		/*
		 * UNE SEULE LECTURE DE DATE POUR LE MODULE (1.723.0).
		 *
		 * Cette méthode et celle de l'import d'écritures ont divergé : celle-ci
		 * lisait JJ/MM/AAAA et les numéros de série Excel mais acceptait le
		 * 31 février ; l'autre refusait tout ce qui n'était pas AAAA-MM-JJ. Un
		 * même fichier passait donc par une porte et pas par l'autre, sans que
		 * rien ne l'explique à l'utilisateur.
		 *
		 * La version de FKC_EcritureImport est désormais la seule : elle réunit
		 * ce que chacune savait faire et ajoute le contrôle du calendrier. Le
		 * corps historique reste en repli — ce fichier peut être chargé seul
		 * par un outil de reprise.
		 */
		if ( class_exists( 'FKC_EcritureImport' ) && method_exists( 'FKC_EcritureImport', 'normaliserDate' ) ) {
			return FKC_EcritureImport::normaliserDate( $v );
		}
		$v = trim( (string) $v );
		if ( '' === $v ) { return ''; }
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $v ) ) { return substr( $v, 0, 10 ); }
		if ( preg_match( '#^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$#', $v, $m ) ) { return sprintf( '%04d-%02d-%02d', $m[3], $m[2], $m[1] ); }
		if ( preg_match( '#^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$#', $v, $m ) ) { return sprintf( '%04d-%02d-%02d', $m[1], $m[2], $m[3] ); }
		if ( preg_match( '/^(\d{4})(\d{2})(\d{2})$/', $v, $m ) ) { return $m[1] . '-' . $m[2] . '-' . $m[3]; }
		// Numéro de série Excel (jours depuis le 30/12/1899). Plage raisonnable : 2000-01-01 → 2100.
		if ( preg_match( '/^\d{5}$/', $v ) ) {
			$serie = (int) $v;
			if ( $serie >= 36526 && $serie <= 73415 ) { return date( 'Y-m-d', ( $serie - 25569 ) * 86400 ); }
		}
		return '';
	}
}

if ( ! function_exists( 'mb_check_encoding_safe' ) ) {
	function mb_check_encoding_safe( $s ) { return function_exists( 'mb_check_encoding' ) ? mb_check_encoding( $s, 'UTF-8' ) : ( false !== @iconv( 'UTF-8', 'UTF-8//IGNORE', $s ) && @iconv( 'UTF-8', 'UTF-8//IGNORE', $s ) === $s ); }
	function mb_convert_encoding_safe( $s ) { return function_exists( 'mb_convert_encoding' ) ? mb_convert_encoding( $s, 'UTF-8', 'ISO-8859-1' ) : (string) @iconv( 'ISO-8859-1', 'UTF-8//IGNORE', $s ); }
}
