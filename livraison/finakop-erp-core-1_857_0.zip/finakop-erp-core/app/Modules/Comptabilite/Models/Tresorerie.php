<?php
/** Comptes de trésorerie (caisse, banque, mobile money) + soldes. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Tresorerie {

	public static function comptes( $onlyActif = false ) {
		$w = $onlyActif ? 'WHERE t.actif=1' : '';
		return FKC_DB::q(
			"SELECT t.*, c.numero AS compte_numero, c.libelle AS compte_libelle
			 FROM tresorerie_comptes t JOIN comptes c ON c.id=t.compte_id
			 {$w} ORDER BY t.ordre ASC, t.id ASC"
		)->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q(
			"SELECT t.*, c.numero AS compte_numero, c.libelle AS compte_libelle
			 FROM tresorerie_comptes t JOIN comptes c ON c.id=t.compte_id WHERE t.id=?",
			array( (int) $id )
		)->fetch();
		return $r ?: null;
	}
	public static function create( $d ) {
		$compte = FKC_Compte::byNumero( $d['compte'] );
		if ( ! $compte ) { return 0; }
		FKC_DB::q(
			'INSERT INTO tresorerie_comptes(libelle,type,operateur,compte_id,actif,ordre) VALUES(?,?,?,?,?,?)',
			array( $d['libelle'], $d['type'], $d['operateur'] ?: null, $compte['id'], empty( $d['actif'] ) ? 0 : 1, (int) ( $d['ordre'] ?? 0 ) )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/**
	 * Solde comptable d'un compte de trésorerie (débit − crédit) à une date —
	 * par défaut la clôture de l'exercice en cours.
	 *
	 * DOUBLÉ PAR LES À-NOUVEAUX JUSQU'EN 1.799.0. La somme de toutes les
	 * lignes du compte relisait chaque écriture d'À-nouveaux par-dessus les
	 * soldes qu'elle reprend : 5 M en banque s'affichaient 10 M la deuxième
	 * année d'utilisation. Le solde se lit désormais comme au Grand Livre.
	 */
	public static function solde( $compteId, $date = null ) {
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			if ( ! $date ) {
				$an = class_exists( 'FKC_Exercice' ) ? FKC_Exercice::courant() : (int) date( 'Y' );
				$date = FKC_SoldeOuverture::finDe( $an );
			}
			return FKC_SoldeOuverture::soldeCompteAu( (int) $compteId, $date );
		}
		$r = FKC_DB::q(
			'SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) AS s FROM ecriture_lignes WHERE compte_id=?',
			array( (int) $compteId )
		)->fetch();
		return (float) $r['s'];
	}
	public static function soldes() {
		$out = array();
		foreach ( self::comptes() as $t ) { $out[ $t['id'] ] = self::solde( $t['compte_id'] ); }
		return $out;
	}
	public static function totalDisponible() {
		$t = 0; foreach ( self::soldes() as $s ) { $t += $s; } return $t;
	}
	public static function types() {
		return array( 'caisse' => 'Caisse', 'banque' => 'Banque', 'mobile_money' => 'Mobile Money' );
	}

	/**
	 * Comptes de trésorerie MOUVEMENTÉS mais absents de la déclaration.
	 *
	 * Le cockpit et cet écran ne totalisaient que les comptes déclarés. Un
	 * compte sur lequel on encaisse sans l'avoir déclaré — le cas de tous les
	 * comptes Mobile Money, que l'amorce ne créait pas — était invisible : le
	 * total affiché était partiel, et rien ne le disait.
	 *
	 * Le filtre porte sur 52 à 57. Les 58 (virements internes) et 59
	 * (dépréciations) en sont exclus : ce ne sont pas des disponibilités.
	 *
	 * @return array
	 */
	public static function nonDeclares() {
		// Même lecture que solde() (1.800.0) : à la clôture de l'exercice en cours.
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			try {
				$an = class_exists( 'FKC_Exercice' ) ? FKC_Exercice::courant() : (int) date( 'Y' );
				$declares = array();
				foreach ( FKC_DB::q( 'SELECT compte_id FROM tresorerie_comptes' )->fetchAll() as $r ) { $declares[ (int) $r['compte_id'] ] = true; }
				$out = array();
				foreach ( FKC_SoldeOuverture::soldesAu( FKC_SoldeOuverture::finDe( $an ) ) as $num => $v ) {
					$pref = substr( (string) $num, 0, 2 );
					if ( $pref < '52' || $pref > '57' || abs( $v ) < 0.005 ) { continue; }
					$c = FKC_Compte::byNumero( (string) $num );
					if ( ! $c || isset( $declares[ (int) $c['id'] ] ) ) { continue; }
					$out[] = array( 'id' => (int) $c['id'], 'numero' => (string) $num, 'libelle' => $c['libelle'], 'solde' => (float) $v );
				}
				usort( $out, function ( $a, $b ) { return $b['solde'] <=> $a['solde']; } );
				return $out;
			} catch ( \Throwable $e ) { /* repli ci-dessous */ }
		}
		try {
			return FKC_DB::q(
				"SELECT c.id, c.numero, c.libelle, COALESCE(SUM(el.debit-el.credit),0) solde
				 FROM ecriture_lignes el JOIN comptes c ON c.id=el.compte_id
				 WHERE substr(c.numero,1,2) BETWEEN '52' AND '57'
				   AND c.id NOT IN (SELECT compte_id FROM tresorerie_comptes)
				 GROUP BY c.id HAVING solde <> 0 ORDER BY solde DESC"
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/** Type déduit du numéro de compte : 55 = mobile money, 57 = caisse, sinon banque. */
	public static function typeDuNumero( $numero ) {
		$p = substr( (string) $numero, 0, 2 );
		return '55' === $p ? 'mobile_money' : ( '57' === $p ? 'caisse' : 'banque' );
	}

	/**
	 * Déclare d'un geste tous les comptes de trésorerie mouvementés qui ne le
	 * sont pas encore. Régularise les dossiers ouverts avant la correction de
	 * l'amorce, sans toucher aux comptes déjà déclarés ni à leur ordre.
	 *
	 * @return array{0:int,1:string}
	 */
	public static function declarerManquants() {
		$manquants = self::nonDeclares();
		if ( ! $manquants ) { return array( 0, 'Tous les comptes de trésorerie mouvementés sont déjà déclarés.' ); }
		$ordre = (int) FKC_DB::q( 'SELECT COALESCE(MAX(ordre),0) FROM tresorerie_comptes' )->fetchColumn();
		$n = 0;
		foreach ( $manquants as $c ) {
			$type = self::typeDuNumero( $c['numero'] );
			// L'opérateur n'est renseigné que s'il est lisible dans le
			// libellé : on ne devine pas « Wave » à partir d'un numéro.
			$op = null;
			if ( 'mobile_money' === $type && preg_match( '/—\s*(.+)$/u', (string) $c['libelle'], $m ) ) { $op = trim( $m[1] ); }
			try {
				FKC_DB::q( 'INSERT INTO tresorerie_comptes(libelle,type,operateur,compte_id,actif,ordre) VALUES(?,?,?,?,1,?)',
					array( $c['libelle'] ?: $c['numero'], $type, $op, (int) $c['id'], ++$ordre ) );
				$n++;
			} catch ( \Throwable $e ) {}
		}
		return array( $n, $n . ' compte(s) de trésorerie déclarés — leurs soldes entrent désormais dans le total et dans le cockpit.' );
	}
}
