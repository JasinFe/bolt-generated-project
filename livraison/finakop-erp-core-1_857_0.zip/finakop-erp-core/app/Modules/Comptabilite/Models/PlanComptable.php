<?php
/**
 * Plan comptable par édition — SYSCOHADA révisé.
 * - Pack commun : comptes complémentaires du plan de base, toutes éditions.
 * - Pack Creative Suite : comptes adaptés à l'industrie musicale / label
 *   (masters, royalties, streaming, concerts, studio, droits d'auteur),
 *   numérotés dans le respect du SYSCOHADA révisé.
 * La synchronisation est additive et idempotente : aucun compte existant
 * n'est modifié ni supprimé, seuls les comptes manquants sont insérés.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_PlanComptable {

	/** Libellés des classes SYSCOHADA révisé. */
	public static function classes() {
		return array(
			1 => 'Ressources durables',
			2 => 'Actif immobilisé',
			3 => 'Stocks',
			4 => 'Tiers',
			5 => 'Trésorerie',
			6 => 'Charges des activités ordinaires',
			7 => 'Produits des activités ordinaires',
			8 => 'Autres charges & autres produits',
			9 => 'Engagements & comptabilité analytique',
		);
	}

	/*
	 * packCommun() ET packCreative() ONT ÉTÉ SUPPRIMÉES — 186 comptes.
	 *
	 * CE QU'ELLES FAISAIENT
	 *
	 * Elles injectaient, à la création de chaque dossier, deux jeux de comptes
	 * écrits AVANT que le référentiel SYSCOHADA (FKC_PlanSyscohada) n'existe et
	 * jamais réconciliés avec lui. L'audit a mesuré l'écart :
	 *
	 *   packCommun()   : 99 comptes — 59 EN CONFLIT avec le référentiel
	 *   packCreative() : 87 comptes — 43 EN CONFLIT
	 *
	 * Et pas sur des détails. 443000 était livré « État — TVA à décaisser »
	 * quand le référentiel dit « TVA facturée » ; 444000 « impôt sur les
	 * bénéfices » quand il dit « TVA due ou crédit de TVA » ; 131000
	 * « Subventions d'équipement » quand il dit « Résultat net : bénéfice ».
	 * Un dossier ouvert avec ces libellés produit une liasse fausse, sans que
	 * rien ne le signale : les comptes existent, la balance est équilibrée,
	 * seuls les intitulés — donc les états — mentent.
	 *
	 * packCreative() plaçait en outre les avances et royalties d'artistes en
	 * 4211 et 4212, qui sont « Personnel, avances » et « Personnel, acomptes ».
	 * Les sommes dues à des artistes SOUS CONTRAT — des créanciers, pas des
	 * salariés — gonflaient la masse salariale et les états sociaux CNPS.
	 *
	 * POURQUOI LA SUPPRESSION, ET PAS LA CORRECTION
	 *
	 * FKC_PlanAudit::divergencesConnues() recense déjà quarante de ces erreurs
	 * et sait les corriger dans un dossier existant. Mais tant que ces deux
	 * fonctions tournaient à chaque création de société, l'audit nettoyait
	 * derrière un générateur qui continuait de salir. Corriger les libellés sur
	 * place n'aurait rien réglé non plus : la bibliothèque FKC_PlanMetier porte
	 * déjà les mêmes concepts sous les BONS numéros — location de studio en 622
	 * et non 613, promotion en 627 et non 623, cachets en 422 et non 425. Les
	 * garder aurait maintenu deux vérités concurrentes.
	 *
	 * Le plan se construit désormais en un seul chemin, celui des quatre
	 * niveaux : FKC_GenerateurPlan pose le niveau 1 (référentiel OHADA) puis le
	 * niveau 2 (socle FinaKop + subdivisions du pack actif). sync() ci-dessous
	 * n'est plus qu'un aiguillage vers lui, conservé pour les appelants
	 * existants.
	 */

	/** Édition courante (core|creative), avec repli sûr. */
	public static function edition() {
		try { return class_exists( 'FKC_License' ) ? FKC_License::edition() : 'core'; }
		catch ( \Throwable $e ) { return 'core'; }
	}

	/**
	 * Synchronise le plan comptable de la société — AIGUILLAGE, plus générateur.
	 *
	 * Conservée parce que plusieurs appelants l'invoquent encore (ouverture de
	 * société, export CSV, écran du plan). Elle ne connaît plus aucun compte :
	 * elle passe la main à FKC_GenerateurPlan, qui pose le niveau 1
	 * (référentiel OHADA, immuable) puis le niveau 2 (socle FinaKop et
	 * subdivisions du pack actif), sans toucher aux journaux, axes ni modèles
	 * d'écritures — ce que ces appelants n'attendaient pas d'elle.
	 *
	 * L'ÉDITION DE LICENCE N'INTERVIENT PLUS. Elle décidait auparavant du jeu
	 * de comptes : une société en licence « creative » recevait le plan
	 * musical, quel que soit son métier réel — un hôtel sous licence creative
	 * héritait des comptes de royalties et de masters. C'est le PACK qui décide
	 * du plan ; la licence n'ouvre que des modules. Le paramètre est ignoré et
	 * conservé pour ne pas casser les appels existants.
	 *
	 * @param string|null $edition Ignoré. Conservé pour compatibilité d'appel.
	 * @return int Nombre de comptes ajoutés.
	 */
	public static function sync( $edition = null ) {
		if ( ! class_exists( 'FKC_GenerateurPlan' ) ) { return 0; }
		try {
			$r = FKC_GenerateurPlan::generer( null, array(
				'niveau1' => true, 'metier' => true,
				'journaux' => false, 'taxes' => false, 'axes' => false,
				'ecritures' => false, 'cockpits' => false,
				'workflows' => false, 'documents' => false,
			) );
			return (int) ( $r['etapes']['plan_ohada']['ajoutes'] ?? 0 )
				+ (int) ( $r['etapes']['plan_metier']['ajoutes'] ?? 0 );
		} catch ( \Throwable $e ) { return 0; }
	}

	/** Nature d'un compte pour l'affichage : BILAN (classes 1-5) ou RÉSULTAT (6-8). */
	public static function nature( $numero ) {
		$cl = (int) substr( (string) $numero, 0, 1 );
		return ( $cl >= 1 && $cl <= 5 ) ? 'BILAN' : ( ( $cl >= 6 && $cl <= 8 ) ? 'RÉSULTAT' : 'AUTRE' );
	}
}
