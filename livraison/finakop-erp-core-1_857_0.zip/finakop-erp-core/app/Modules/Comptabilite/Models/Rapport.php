<?php
/** Balance et grand livre. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Rapport {

	/**
	 * Factures clients qui existent EN COMPTABILITÉ (1.853.0) : ni annulées,
	 * ni au brouillon. Un brouillon n'a pas d'écriture (Facture::comptabiliser
	 * le fait passer à « validee ») : le compter faisait diverger la balance
	 * auxiliaire, la balance âgée et le grand livre client du compte 411.
	 */
	const FACTURES_COMPTABILISEES = "(statut IS NULL OR (statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%' AND statut<>'brouillon'))";

	/** Contexte d'ouverture du dernier état produit (mode, alerte) — lu par les vues. */
	protected static $contexte = null;
	public static function contexteOuverture() { return self::$contexte; }

	/**
	 * Balance générale à six colonnes : solde d'ouverture, mouvements, solde de clôture.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * LE SOLDE D'OUVERTURE VIENT DU GESTIONNAIRE DES À-NOUVEAUX (1.798.0)
	 *
	 * L'ancienne colonne « ouverture » sommait TOUT ce qui précédait $du,
	 * à-nouveaux des années antérieures compris, puis la vraie écriture
	 * d'À-nouveaux du 1er jour venait s'ajouter en mouvement : le capital
	 * doublait à chaque ouverture, sur une balance toujours équilibrée.
	 *
	 * La colonne d'ouverture est désormais celle de FKC_SoldeOuverture — la
	 * même que le Grand Livre et le Bilan. Quand $du ouvre un exercice qui a
	 * ses À-nouveaux, ceux-ci sont rangés en OUVERTURE et retirés des
	 * mouvements : ils ne sont comptés qu'une fois, à leur place.
	 * ═══════════════════════════════════════════════════════════════════════
	 */
	public static function balance( $du = null, $au = null ) {
		$duEff = FKC_SoldeOuverture::duEffectif( $du ?: null );
		$auEff = $au ?: '9999-12-31';
		$ctx   = FKC_SoldeOuverture::ouverture( $duEff );
		self::$contexte = $ctx;

		$ouv = $ctx['soldes'];
		foreach ( $ctx['an'] as $cid => $s ) { $ouv[ $cid ] = round( ( $ouv[ $cid ] ?? 0 ) + $s, 2 ); }

		list( $wm, $pm ) = FKC_SoldeOuverture::clauseMouvements( $duEff, $auEff, true );
		$mvt = array();
		foreach ( FKC_DB::q(
			'SELECT l.compte_id cid, COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) c
			 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id JOIN comptes c ON c.id=l.compte_id
			 WHERE ' . $wm . ' GROUP BY l.compte_id', $pm
		)->fetchAll() as $r ) { $mvt[ (int) $r['cid'] ] = array( (float) $r['d'], (float) $r['c'] ); }

		$ids = array_unique( array_merge( array_keys( $ouv ), array_keys( $mvt ) ) );
		if ( ! $ids ) { return array(); }
		$comptes = array();
		foreach ( FKC_DB::q( 'SELECT id,numero,libelle FROM comptes WHERE id IN (' . implode( ',', array_map( 'intval', $ids ) ) . ')' )->fetchAll() as $c ) {
			$comptes[ (int) $c['id'] ] = $c;
		}
		$rows = array();
		foreach ( $ids as $cid ) {
			if ( ! isset( $comptes[ $cid ] ) ) { continue; }
			$o = (float) ( $ouv[ $cid ] ?? 0 ); $d = (float) ( $mvt[ $cid ][0] ?? 0 ); $c = (float) ( $mvt[ $cid ][1] ?? 0 );
			if ( abs( $o ) < 0.005 && abs( $d ) < 0.005 && abs( $c ) < 0.005 ) { continue; }
			$clo = $o + $d - $c;
			$rows[] = array(
				'id' => $cid, 'numero' => $comptes[ $cid ]['numero'], 'libelle' => $comptes[ $cid ]['libelle'],
				'ouverture' => $o, 'debit' => $d, 'credit' => $c,
				'ouv_debit' => $o > 0 ? $o : 0, 'ouv_credit' => $o < 0 ? -$o : 0,
				'solde_debiteur' => $clo > 0 ? $clo : 0, 'solde_crediteur' => $clo < 0 ? -$clo : 0,
				'origine_ouverture' => isset( $ctx['an'][ $cid ] ) ? 'an' : ( isset( $ctx['soldes'][ $cid ] ) ? $ctx['mode'] : '' ),
				/*
				 * UNE OUVERTURE AMBIGUË N'EST JAMAIS PRÉSENTÉE COMME NORMALE (1.799.0).
				 * La ligne porte ce que l'ouverture DEVAIT être (clôture N-1),
				 * ce qu'elle EST (toutes sources), et l'écart : une balance
				 * équilibrée ne suffit pas à dire qu'elle est juste.
				 */
				'ouverture_non_fiable' => isset( $ctx['ecarts_comptes'][ $cid ] ),
				'ouverture_attendue'   => $ctx['ecarts_comptes'][ $cid ]['attendu'] ?? null,
				'ouverture_effective'  => $ctx['ecarts_comptes'][ $cid ]['effectif'] ?? null,
				'ouverture_ecart'      => $ctx['ecarts_comptes'][ $cid ]['ecart'] ?? null,
			);
		}
		usort( $rows, function ( $x, $y ) { return strcmp( (string) $x['numero'], (string) $y['numero'] ); } );
		return $rows;
	}

	/**
	 * Grand livre GÉNÉRAL : tous les comptes mouvementés (ou dans une plage), chacun
	 * avec son solde d'ouverture, ses mouvements (solde progressif) et ses totaux.
	 * $f: du, au, compte_de, compte_a (numéros), journal (code), compte_id, non_zero, q.
	 *
	 * RÈGLE (1.798.0) : si l'exercice a ses À-nouveaux, SEULE l'écriture réelle
	 * d'À-nouveaux apparaît comme mouvement d'ouverture — aucune ligne
	 * virtuelle ne s'y ajoute. S'il n'en a pas, une ligne « Solde d'ouverture
	 * calculé » le dit, avec son alerte. Le libellé « Report à nouveau » est
	 * réservé à l'affectation du résultat (121/129).
	 *
	 * @return array<string,mixed> comptes[], totaux{debit,credit}, nb_comptes, contexte
	 */
	public static function grandLivreGeneral( $f = array() ) {
		$du = FKC_SoldeOuverture::duEffectif( $f['du'] ?? null ); $au = $f['au'] ?? null;
		$journal = ! empty( $f['journal'] ) ? $f['journal'] : null;
		$nonZero = array_key_exists( 'non_zero', $f ) ? (bool) $f['non_zero'] : true;
		$q = ! empty( $f['q'] ) ? $f['q'] : null;

		// Clause de plage de comptes (sur le numéro) + compte précis éventuel.
		$accW = array(); $accP = array();
		if ( ! empty( $f['compte_de'] ) ) { $accW[] = 'c.numero>=?'; $accP[] = $f['compte_de']; }
		if ( ! empty( $f['compte_a'] ) )  { $accW[] = 'c.numero<=?'; $accP[] = $f['compte_a']; }
		if ( ! empty( $f['compte_id'] ) ) { $accW[] = 'c.id=?'; $accP[] = (int) $f['compte_id']; }
		if ( ! empty( $f['prefixes'] ) ) {
			$or = array();
			foreach ( array_slice( (array) $f['prefixes'], 0, 20 ) as $px ) { $or[] = 'c.numero LIKE ?'; $accP[] = $px . '%'; }
			$accW[] = '(' . implode( ' OR ', $or ) . ')';
		}

		// 1) Solde d'ouverture : le gestionnaire des À-nouveaux, et lui seul.
		$ctx = FKC_SoldeOuverture::ouverture( $du, implode( ' AND ', $accW ), $accP );
		self::$contexte = $ctx;
		$ouv = $ctx['soldes'];

		// 2) Mouvements de la période (À-nouveaux du jour compris : c'est le mouvement d'ouverture réel).
		list( $wm, $pm ) = FKC_SoldeOuverture::clauseMouvements( $du, $au, false );
		$w = array( $wm ); $p = $pm;
		if ( $journal ) { $w[] = 'j.code=?'; $p[] = $journal; }
		if ( $q ) { $w[] = '(l.libelle LIKE ? OR e.piece LIKE ? OR e.libelle LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; $p[] = "%$q%"; }
		foreach ( $accW as $x ) { $w[] = $x; } foreach ( $accP as $x ) { $p[] = $x; }
		if ( ! empty( $f['gestion'] ) && class_exists( 'FKC_EtatsDgi' ) ) {
			$w[] = "NOT ( substr(c.numero,1,1) IN ('6','7','8') AND " . FKC_EtatsDgi::sqlEcritureResultat( 'e' ) . ' )';
		}
		$rows = FKC_DB::q(
			'SELECT c.id cid, c.numero, c.libelle clib, e.id eid, e.date_ecriture d, e.piece, j.code jnl,
			        COALESCE(NULLIF(l.libelle,\'\'), e.libelle) lib, e.libelle elib, l.debit, l.credit, l.lettre
			 FROM ecriture_lignes l
			 JOIN ecritures e ON e.id=l.ecriture_id
			 JOIN journaux  j ON j.id=e.journal_id
			 JOIN comptes   c ON c.id=l.compte_id
			 WHERE ' . implode( ' AND ', $w ) . '
			 ORDER BY c.numero ASC, c.id ASC, e.date_ecriture ASC, e.id ASC', $p
		)->fetchAll();

		$anIds = array_flip( array_map( 'intval', (array) $ctx['an_ids'] ) );
		$srcIds = array();
		foreach ( (array) ( $ctx['sources'] ?? array() ) as $x ) { $srcIds[ (int) $x['id'] ] = $x; }
		$acc = array();
		foreach ( $rows as $r ) {
			$cid = (int) $r['cid'];
			if ( ! isset( $acc[ $cid ] ) ) {
				$o = $ouv[ $cid ] ?? 0.0;
				$acc[ $cid ] = array( 'numero' => $r['numero'], 'libelle' => $r['clib'], 'ouverture' => $o, 'cumul' => $o, 'mouvements' => array(), 'td' => 0.0, 'tc' => 0.0 );
			}
			$acc[ $cid ]['cumul'] += (float) $r['debit'] - (float) $r['credit'];
			$acc[ $cid ]['td'] += (float) $r['debit'];
			$acc[ $cid ]['tc'] += (float) $r['credit'];
			$estAN = isset( $anIds[ (int) $r['eid'] ] );
			$acc[ $cid ]['mouvements'][] = array(
				'date' => $r['d'], 'piece' => $r['piece'], 'journal' => $r['jnl'],
				// La ligne d'À-nouveaux porte le nom de son écriture, pas un libellé de ligne générique.
				'libelle' => $estAN ? $r['elib'] : $r['lib'],
				'debit' => (float) $r['debit'], 'credit' => (float) $r['credit'], 'lettre' => $r['lettre'],
				'solde' => round( $acc[ $cid ]['cumul'], 2 ), 'ouverture_reelle' => $estAN && ! empty( $ctx['fiable'] ), 'ecriture_id' => (int) $r['eid'],
				// Toute source d'ouverture est nommée, officielle ou non (1.799.0).
				'source_ouverture' => isset( $srcIds[ (int) $r['eid'] ] ) ? $srcIds[ (int) $r['eid'] ]['libelle_type'] : null,
			);
		}
		// Comptes sans mouvement sur la période mais au solde d'ouverture non nul.
		if ( ! $q ) {
			foreach ( $ouv as $cid => $o ) {
				if ( ! isset( $acc[ $cid ] ) && abs( $o ) >= 0.005 ) {
					$m = FKC_DB::q( 'SELECT numero,libelle FROM comptes WHERE id=?', array( $cid ) )->fetch();
					if ( $m ) { $acc[ $cid ] = array( 'numero' => $m['numero'], 'libelle' => $m['libelle'], 'ouverture' => $o, 'cumul' => $o, 'mouvements' => array(), 'td' => 0.0, 'tc' => 0.0 ); }
				}
			}
		}

		$out = array(); $gd = 0; $gc = 0;
		foreach ( $acc as $cidA => $a ) {
			$a['solde'] = round( $a['ouverture'] + $a['td'] - $a['tc'], 2 );
			$a['libelle_ouverture'] = $ctx['libelle'];
			$a['ouverture_calculee'] = ( 'calcule' === $ctx['mode'] );
			$a['ouverture_non_fiable'] = $ctx['ecarts_comptes'][ $cidA ] ?? null;
			$hasMvt = count( $a['mouvements'] ) > 0;
			$hasBal = abs( $a['solde'] ) >= 0.005 || abs( $a['ouverture'] ) >= 0.005;
			if ( $nonZero && ! $hasMvt && ! $hasBal ) { continue; }
			$a['td'] = round( $a['td'], 2 ); $a['tc'] = round( $a['tc'], 2 );
			$out[] = $a; $gd += $a['td']; $gc += $a['tc'];
		}
		usort( $out, function ( $x, $y ) { return strcmp( (string) $x['numero'], (string) $y['numero'] ); } );
		return array( 'comptes' => $out, 'totaux' => array( 'debit' => round( $gd, 2 ), 'credit' => round( $gc, 2 ) ),
			'nb_comptes' => count( $out ), 'contexte' => $ctx, 'du' => $du );
	}

	/** Solde d'ouverture d'un compte à la date $du (gestionnaire des À-nouveaux). */
	public static function grandLivreOuverture( $compteId, $du = null ) {
		$ctx = FKC_SoldeOuverture::ouverture( FKC_SoldeOuverture::duEffectif( $du ), 'c.id=?', array( (int) $compteId ) );
		self::$contexte = $ctx;
		return (float) ( $ctx['soldes'][ (int) $compteId ] ?? 0.0 );
	}

	public static function grandLivre( $compteId, $du = null, $au = null ) {
		$duEff = FKC_SoldeOuverture::duEffectif( $du );
		list( $wm, $pm ) = FKC_SoldeOuverture::clauseMouvements( $duEff, $au, false );
		$args = array_merge( $pm, array( (int) $compteId ) );
		$rows = FKC_DB::q(
			"SELECT e.date_ecriture,e.piece,e.id AS ecriture_id,j.code AS journal_code,l.libelle,l.debit,l.credit
			 FROM ecriture_lignes l
			 JOIN ecritures e ON e.id=l.ecriture_id
			 JOIN journaux j ON j.id=e.journal_id
			 JOIN comptes c ON c.id=l.compte_id
			 WHERE {$wm} AND l.compte_id=?
			 ORDER BY e.date_ecriture ASC, e.id ASC", $args
		)->fetchAll();
		$cumul = self::grandLivreOuverture( $compteId, $duEff );
		foreach ( $rows as &$r ) { $cumul += (float) $r['debit'] - (float) $r['credit']; $r['solde'] = $cumul; }
		return $rows;
	}

	/**
	 * Balance âgée auxiliaire (clients ou fournisseurs) avec lettrage FIFO.
	 *
	 * L'ARRÊTÉ N'ARRÊTAIT RIEN (1.853.0). La date ne servait qu'à calculer
	 * l'ancienneté : une balance « arrêtée au 31/12 » éditée en mars comptait
	 * les factures et les règlements de janvier à mars — les premières,
	 * d'âge négatif, tombaient en « non échu ». Factures et règlements sont
	 * désormais bornés à la date d'arrêté. Côté clients, l'ancienneté part
	 * de l'ÉCHÉANCE quand elle est renseignée (la colonne « Non échu » était
	 * toujours vide), de la date de facture sinon.
	 */
	protected static function baliseTiers( $type, $asOf ) {
		$asOf = $asOf ?: date( 'Y-m-d' );
		/*
		 * LE LETTRAGE RÉEL, PLUS UN FIFO DE PLUS (1.854.0).
		 *
		 * Cette balance refaisait son propre lettrage « le plus ancien
		 * d'abord », pendant que le recouvrement lisait FKC_Imputation :
		 * imputations nommées à l'encaissement, reçus rattachés à leur
		 * facture, avoirs éteignant leur facture d'origine — et le FIFO
		 * seulement pour le reliquat. Un client qui avait réglé la facture de
		 * mars voyait mars soldée au recouvrement et ouverte, vieillie, dans
		 * l'extraction. Les deux écrans lisent désormais le même moteur, arrêté
		 * à la même date.
		 */
		$res = array();
		$client = ( 'client' === $type );
		$tiers = $client ? FKC_Client::all() : FKC_Fournisseur::all();
		foreach ( $tiers as $t ) {
			$p = $client ? FKC_Imputation::postesClient( (int) $t['id'], $asOf ) : FKC_Imputation::postesFournisseur( (int) $t['id'], $asOf );
			$regle = $client ? (float) $p['encaisse'] : (float) $p['paye'];
			if ( abs( (float) $p['facture'] ) < 0.005 && abs( $regle ) < 0.005 ) { continue; }
			$buckets = array( 'non_echu' => 0.0, 'b30' => 0.0, 'b60' => 0.0, 'b90' => 0.0, 'b90p' => 0.0 );
			$lettre = 0.0; $nomme = 0.0;
			foreach ( $p['factures'] as $f ) {
				$lettre += (float) $f['regle'];
				$nomme  += (float) $f['impute'] + (float) ( $f['avoir'] ?? 0 );
			}
			foreach ( $p['ouvertes'] as $f ) {
				$buckets[ fkc_age_bucket( (int) $f['jours'] ) ] += (float) $f['reste'];
			}
			$res[] = array(
				'id' => (int) $t['id'], 'nom' => $t['nom'],
				'facture' => (float) $p['facture'],
				'lettre'  => round( $lettre, 2 ),
				'impute'  => round( $nomme, 2 ),         // dont éteint par décision nommée ou avoir d'origine
				'solde'   => round( (float) $p['facture'] - $regle, 2 ),
				'credit'  => (float) $p['credit'],       // réglé sans facture en face (avance, acompte)
				'nb_ouvertes' => (int) $p['nb_ouvertes'],
				'buckets' => $buckets,
			);
		}
		usort( $res, function ( $a, $b ) { return $b['solde'] <=> $a['solde']; } );
		return $res;
	}

	public static function balanceAgeeClients( $asOf = null )      { return self::baliseTiers( 'client', $asOf ); }
	public static function balanceAgeeFournisseurs( $asOf = null ) { return self::baliseTiers( 'fournisseur', $asOf ); }

	/* ════════════════════════════════════════════════════════════════════
	 * BALANCE AUXILIAIRE (par tiers) — ouverture / mouvements / solde
	 * Reconstituée à partir des factures (débit client / crédit fournisseur)
	 * et des règlements. Concorde avec le compte collectif 411 / 401.
	 * ════════════════════════════════════════════════════════════════════ */
	protected static function balanceAux( $type, $du = null, $au = null ) {
		$duEff = $du ?: '0000-01-01';
		$auEff = $au ?: '9999-12-31';
		$client = ( 'client' === $type );
		$tiers  = $client ? FKC_Client::all() : FKC_Fournisseur::all();
		$res = array();
		foreach ( $tiers as $t ) {
			$id = (int) $t['id'];
			if ( $client ) {
				$facAv = self::scalar( "SELECT COALESCE(SUM(montant_ttc),0) FROM factures WHERE client_id=? AND " . self::FACTURES_COMPTABILISEES . " AND date_facture<?", array( $id, $duEff ) );
				$facPe = self::scalar( "SELECT COALESCE(SUM(CASE WHEN montant_ttc>0 THEN montant_ttc ELSE 0 END),0) FROM factures WHERE client_id=? AND " . self::FACTURES_COMPTABILISEES . " AND date_facture>=? AND date_facture<=?", array( $id, $duEff, $auEff ) );
				// Les avoirs (montant négatif) sont des CRÉDITS du client, pas des débits en moins.
				$avPe  = -self::scalar( "SELECT COALESCE(SUM(CASE WHEN montant_ttc<0 THEN montant_ttc ELSE 0 END),0) FROM factures WHERE client_id=? AND " . self::FACTURES_COMPTABILISEES . " AND date_facture>=? AND date_facture<=?", array( $id, $duEff, $auEff ) );
				$regAv = self::scalar( "SELECT COALESCE(SUM(montant),0) FROM reglements WHERE COALESCE(statut,'actif')<>'annule' AND sens='encaissement' AND tiers_type='client' AND tiers_id=? AND date_reglement<?", array( $id, $duEff ) );
				$regPe = self::scalar( "SELECT COALESCE(SUM(montant),0) FROM reglements WHERE COALESCE(statut,'actif')<>'annule' AND sens='encaissement' AND tiers_type='client' AND tiers_id=? AND date_reglement>=? AND date_reglement<=?", array( $id, $duEff, $auEff ) );
				$compteCol = '411';
			} else {
				$facAv = self::scalar( "SELECT COALESCE(SUM(montant_ttc),0) FROM factures_fournisseurs WHERE fournisseur_id=? AND statut!='annulee' AND date_facture<?", array( $id, $duEff ) );
				$facPe = self::scalar( "SELECT COALESCE(SUM(montant_ttc),0) FROM factures_fournisseurs WHERE fournisseur_id=? AND statut!='annulee' AND date_facture>=? AND date_facture<=?", array( $id, $duEff, $auEff ) );
				$regAv = self::scalar( "SELECT COALESCE(SUM(montant),0) FROM reglements WHERE COALESCE(statut,'actif')<>'annule' AND sens='paiement' AND tiers_type='fournisseur' AND tiers_id=? AND date_reglement<?", array( $id, $duEff ) );
				$regPe = self::scalar( "SELECT COALESCE(SUM(montant),0) FROM reglements WHERE COALESCE(statut,'actif')<>'annule' AND sens='paiement' AND tiers_type='fournisseur' AND tiers_id=? AND date_reglement>=? AND date_reglement<=?", array( $id, $duEff, $auEff ) );
				$compteCol = $t['compte'] ?? '401';
			}
			if ( $client ) {
				$ouv = $facAv - $regAv;            // solde signé (positif = débiteur)
				$mvtD = $facPe; $mvtC = $regPe + $avPe;
			} else {
				$ouv = -( $facAv - $regAv );        // créditeur => négatif côté débit
				$mvtD = $regPe; $mvtC = $facPe;
			}
			$clo = $ouv + $mvtD - $mvtC;
			if ( abs( $ouv ) < 0.005 && $mvtD < 0.005 && $mvtC < 0.005 ) { continue; }
			$res[] = array(
				'id'              => $id,
				'nom'             => $t['nom'],
				'compte'          => $compteCol,
				'ouv_debit'       => $ouv > 0 ? $ouv : 0,
				'ouv_credit'      => $ouv < 0 ? -$ouv : 0,
				'debit'           => $mvtD,
				'credit'          => $mvtC,
				'solde_debiteur'  => $clo > 0 ? $clo : 0,
				'solde_crediteur' => $clo < 0 ? -$clo : 0,
			);
		}
		usort( $res, function ( $a, $b ) {
			return ( $b['solde_debiteur'] + $b['solde_crediteur'] ) <=> ( $a['solde_debiteur'] + $a['solde_crediteur'] );
		} );
		return $res;
	}
	public static function balanceAuxClients( $du = null, $au = null )      { return self::balanceAux( 'client', $du, $au ); }
	public static function balanceAuxFournisseurs( $du = null, $au = null ) { return self::balanceAux( 'fournisseur', $du, $au ); }

	/* ════════════════════════════════════════════════════════════════════
	 * GRAND LIVRE AUXILIAIRE (détail des mouvements d'un tiers)
	 * ════════════════════════════════════════════════════════════════════ */
	public static function grandLivreTiers( $type, $tiersId, $du = null, $au = null ) {
		$id     = (int) $tiersId;
		$client = ( 'client' === $type );
		$mvts   = array();
		if ( $client ) {
			foreach ( FKC_DB::q( "SELECT date_facture d, numero, montant_ttc m, type t FROM factures WHERE client_id=? AND " . self::FACTURES_COMPTABILISEES . " ORDER BY date_facture ASC, id ASC", array( $id ) )->fetchAll() as $f ) {
				$m = (float) $f['m']; $av = ( 'avoir' === ( $f['t'] ?? '' ) || $m < 0 );
				$mvts[] = $av
					? array( 'date' => $f['d'], 'piece' => $f['numero'], 'journal' => 'VT', 'libelle' => 'Avoir ' . $f['numero'], 'debit' => 0.0, 'credit' => abs( $m ) )
					: array( 'date' => $f['d'], 'piece' => $f['numero'], 'journal' => 'VT', 'libelle' => 'Facture ' . $f['numero'], 'debit' => $m, 'credit' => 0.0 );
			}
			foreach ( FKC_DB::q( "SELECT date_reglement d, reference, libelle, montant m, mode FROM reglements WHERE COALESCE(statut,'actif')<>'annule' AND sens='encaissement' AND tiers_type='client' AND tiers_id=? ORDER BY date_reglement ASC, id ASC", array( $id ) )->fetchAll() as $r ) {
				$mvts[] = array( 'date' => $r['d'], 'piece' => $r['reference'] ?: '', 'journal' => 'TR', 'libelle' => $r['libelle'] ?: ( 'Encaissement ' . ( $r['mode'] ?: '' ) ), 'debit' => 0.0, 'credit' => (float) $r['m'] );
			}
		} else {
			foreach ( FKC_DB::q( "SELECT date_facture d, numero, montant_ttc m FROM factures_fournisseurs WHERE fournisseur_id=? AND statut!='annulee' ORDER BY date_facture ASC, id ASC", array( $id ) )->fetchAll() as $f ) {
				$mvts[] = array( 'date' => $f['d'], 'piece' => $f['numero'] ?: '', 'journal' => 'AC', 'libelle' => 'Facture ' . ( $f['numero'] ?: 'fournisseur' ), 'debit' => 0.0, 'credit' => (float) $f['m'] );
			}
			foreach ( FKC_DB::q( "SELECT date_reglement d, reference, libelle, montant m, mode FROM reglements WHERE COALESCE(statut,'actif')<>'annule' AND sens='paiement' AND tiers_type='fournisseur' AND tiers_id=? ORDER BY date_reglement ASC, id ASC", array( $id ) )->fetchAll() as $r ) {
				$mvts[] = array( 'date' => $r['d'], 'piece' => $r['reference'] ?: '', 'journal' => 'TR', 'libelle' => $r['libelle'] ?: ( 'Paiement ' . ( $r['mode'] ?: '' ) ), 'debit' => (float) $r['m'], 'credit' => 0.0 );
			}
		}
		usort( $mvts, function ( $a, $b ) {
			$c = strcmp( $a['date'], $b['date'] );
			return $c !== 0 ? $c : 0;
		} );
		// Solde d'ouverture (cumul strictement avant $du)
		$ouv = 0.0;
		foreach ( $mvts as $m ) { if ( $du && $m['date'] < $du ) { $ouv += $m['debit'] - $m['credit']; } }
		$cumul = $ouv; $rows = array();
		foreach ( $mvts as $m ) {
			if ( $du && $m['date'] < $du ) { continue; }
			if ( $au && $m['date'] > $au ) { continue; }
			$cumul += $m['debit'] - $m['credit'];
			$m['solde'] = $cumul;
			$rows[] = $m;
		}
		return array( 'ouverture' => $ouv, 'mouvements' => $rows );
	}

	/* ════════════════════════════════════════════════════════════════════
	 * CENTRALISATION DES JOURNAUX (sur période)
	 * ════════════════════════════════════════════════════════════════════ */
	public static function centralisationJournaux( $du = null, $au = null ) {
		$duEff = $du ?: '0000-01-01';
		$auEff = $au ?: '9999-12-31';
		return FKC_DB::q(
			"SELECT j.code, j.libelle,
				COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) c, COUNT(DISTINCT e.id) nb
			 FROM journaux j
			 LEFT JOIN ecritures e ON e.journal_id=j.id AND e.date_ecriture>=? AND e.date_ecriture<=?
			 LEFT JOIN ecriture_lignes l ON l.ecriture_id=e.id
			 GROUP BY j.id ORDER BY j.code",
			array( $duEff, $auEff )
		)->fetchAll();
	}

	/* ════════════════════════════════════════════════════════════════════
	 * REGISTRE DES IMMOBILISATIONS (valeur, amortissements, VNC)
	 * ════════════════════════════════════════════════════════════════════ */
	public static function registreImmobilisations() {
		$rows = array();
		foreach ( FKC_Immobilisation::all() as $i ) {
			// Une fiche annulée n'est plus à l'actif (1.761.0) : la laisser au
			// registre ferait un total d'immobilisations plus élevé que le bilan.
			if ( FKC_Immobilisation::estAnnulee( $i ) ) { continue; }
			$cumul = FKC_Immobilisation::cumulAmorti( $i['id'] );
			$va    = (float) $i['valeur_acquisition'];
			// VNC d'un bien SORTI : nulle (1.855.0) — le registre annonçait la
			// valeur d'avant la cession, et son total dépassait le bilan.
			$rows[] = array(
				'code'     => $i['code'] ?: '—',
				'libelle'  => $i['libelle'],
				'date_acq' => $i['date_acquisition'],
				'duree'    => (float) $i['duree_annees'],
				'va'       => $va,
				'vr'       => (float) $i['valeur_residuelle'],
				'cumul'    => $cumul,
				'vnc'      => FKC_Immobilisation::vnc( $i ),
				'statut'   => $i['statut'],
				'date_cession' => (string) ( $i['date_cession'] ?? '' ),
				'amortissable' => FKC_Immobilisation::estAmortissable( $i ),
			);
		}
		return $rows;
	}

	/** Tableau d'amortissement consolidé (une ligne par immobilisation × exercice). */
	public static function tableauAmortissements() {
		$rows = array();
		foreach ( FKC_Immobilisation::all() as $i ) {
			if ( FKC_Immobilisation::estAnnulee( $i ) ) { continue; }
			foreach ( FKC_Immobilisation::plan( $i ) as $p ) {
				$rows[] = array(
					'code'     => $i['code'] ?: '—',
					'libelle'  => $i['libelle'],
					'exercice' => $p['exercice'],
					'dotation' => $p['dotation'],
					'cumul'    => $p['cumul'],
					'vnc'      => $p['vnc'],
				);
			}
		}
		return $rows;
	}

	/** Helper scalaire. */
	protected static function scalar( $sql, $args = array() ) {
		return (float) FKC_DB::q( $sql, $args )->fetchColumn();
	}
}
