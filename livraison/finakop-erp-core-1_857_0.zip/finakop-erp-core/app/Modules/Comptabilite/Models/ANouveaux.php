<?php
/**
 * À-NOUVEAUX — le report des soldes de bilan à l'ouverture d'un exercice.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * LE DÉFAUT CORRIGÉ : L'ÉQUILIBRAGE PAR DIFFÉRENCE
 *
 * L'ancienne génération (FKC_Exercice::genererANouveaux) faisait ceci :
 *
 *     $diff = totalDébit - totalCrédit;
 *     if ( $diff != 0 ) { … imputer $diff sur 121 ou 129 … }
 *
 * Autrement dit : quoi qu'il arrive, l'écriture s'équilibrait. Le compte de
 * report à nouveau servait de VARIABLE D'AJUSTEMENT, et absorbait n'importe
 * quel écart sans le nommer.
 *
 * Or les soldes des classes 1 à 5 ne peuvent être déséquilibrés QUE si
 * quelque chose ne va pas, et la cause est presque toujours la même :
 *
 *   — les classes 6, 7 et 8 de l'exercice précédent n'ont pas été soldées,
 *     c'est-à-dire que le résultat n'a jamais été déterminé. L'écart est
 *     alors exactement le résultat de l'exercice ;
 *   — ou bien une écriture mêle bilan et gestion de façon déséquilibrée.
 *
 * Dans le premier cas, l'ancien code logeait le résultat de l'exercice en
 * REPORT À NOUVEAU sans qu'aucune assemblée ne l'ait décidé, en sautant
 * l'affectation. Dans le second, il masquait une corruption de données.
 *
 * Les deux produisaient le même effet : un bilan d'ouverture parfaitement
 * équilibré et parfaitement faux, dont personne ne pouvait plus retrouver
 * l'origine — le montant fautif ayant pris l'apparence d'un report à nouveau
 * légitime.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * CE QUI LE REMPLACE
 *
 * On REFUSE, et on NOMME la cause. Le déséquilibre est mesuré, sa cause la
 * plus probable est calculée (solde des classes de gestion de N-1), et le
 * message dit quoi faire. Un refus qui explique coûte dix minutes ; un
 * équilibrage silencieux coûte un exercice.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * LE DÉTAIL AUXILIAIRE SURVIT À L'OUVERTURE
 *
 * L'ancienne génération groupait par compte seulement : au 1er janvier, le
 * grand livre auxiliaire repartait à zéro et le solde du client Konan se
 * retrouvait fondu dans un 411 collectif. Le lettrage d'un règlement reçu en
 * janvier sur une facture de décembre devenait impossible, et la balance
 * âgée des créances perdait toute son antériorité.
 *
 * On groupe donc par (compte, tiers, devise) : le collectif reste la somme de
 * ses auxiliaires — c'est la concordance que réclame l'AUDCIF — et chaque
 * position en devise garde son montant d'origine, sans quoi la revalorisation
 * de la clôture suivante n'aurait plus de base.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ANouveaux {

	/** Préfixe de référence des écritures d'à-nouveaux : sert à les retrouver. */
	const REF = 'AN-';

	/** Tolérance d'arrondi, en francs. */
	const TOLERANCE = 1.0;

	/* ── Détection : une écriture d'à-nouveaux existe-t-elle déjà ? ────────── */

	/**
	 * Toutes les écritures d'à-nouveaux de cet exercice.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * POURQUOI TROIS CRITÈRES, ET NON UN SEUL
	 *
	 * L'ancien contrôle d'unicité reposait entièrement sur `exercices.annee`,
	 * clé primaire : « l'exercice est déjà ouvert, donc les à-nouveaux
	 * existent ». Ce raisonnement se rompt dès qu'on annule une ouverture :
	 * `annulerOuverture()` supprimait la ligne d'exercice ET tentait de
	 * supprimer l'écriture. Si la seconde suppression échouait — écriture
	 * référencée, période entre-temps verrouillée, panne — la ligne
	 * d'exercice, elle, disparaissait quand même. Une réouverture générait
	 * alors un SECOND jeu d'à-nouveaux par-dessus le premier.
	 *
	 * Le bilan d'ouverture doublait : capital, immobilisations, dettes,
	 * trésorerie, tout. Et il restait équilibré — donc aucun contrôle
	 * comptable ne se déclenchait.
	 *
	 * On cherche donc l'écriture LÀ OÙ ELLE EST, par trois voies
	 * indépendantes : sa référence, son journal et sa date, et le pointeur
	 * conservé sur l'exercice. Une seule qui répond suffit à refuser.
	 *
	 * @return array Identifiants d'écritures, sans doublon.
	 */
	public static function ecrituresExistantes( $annee ) {
		$annee = (int) $annee;
		// Source unique depuis la 1.798.0 : le gestionnaire des À-nouveaux
		// applique exactement ces trois critères, pour tous les écrans.
		if ( class_exists( 'FKC_SoldeOuverture' ) ) { return FKC_SoldeOuverture::ecrituresAN( $annee ); }
		$ids   = array();
		$debut = self::debutDe( $annee );

		try {
			foreach ( FKC_DB::q( 'SELECT id FROM ecritures WHERE reference=?', array( self::REF . $annee ) )->fetchAll() as $r ) {
				$ids[] = (int) $r['id'];
			}
		} catch ( \Throwable $e ) { /* colonne absente : les autres voies restent */ }

		try {
			foreach ( FKC_DB::q(
				"SELECT e.id FROM ecritures e JOIN journaux j ON j.id=e.journal_id
				 WHERE j.code='AN' AND e.date_ecriture=?", array( $debut )
			)->fetchAll() as $r ) { $ids[] = (int) $r['id']; }
		} catch ( \Throwable $e ) { /* ignore */ }

		try {
			$r = FKC_DB::q( 'SELECT an_ecriture_id FROM exercices WHERE annee=?', array( $annee ) )->fetch();
			if ( $r && ! empty( $r['an_ecriture_id'] ) ) {
				// Le pointeur ne vaut que si l'écriture existe encore : un
				// pointeur orphelin n'est pas un doublon, c'est une incohérence
				// que resynchroniser() répare.
				$e = FKC_DB::q( 'SELECT 1 FROM ecritures WHERE id=?', array( (int) $r['an_ecriture_id'] ) )->fetch();
				if ( $e ) { $ids[] = (int) $r['an_ecriture_id']; }
			}
		} catch ( \Throwable $e ) { /* ignore */ }

		return array_values( array_unique( array_filter( $ids ) ) );
	}

	public static function existent( $annee ) {
		return array() !== self::ecrituresExistantes( $annee );
	}

	/* ── Prévisualisation ─────────────────────────────────────────────────── */

	/**
	 * Calcule les à-nouveaux SANS rien écrire.
	 *
	 * C'est l'écran que l'ancienne version n'avait pas : on voyait le résultat
	 * après coup, sur un exercice déjà ouvert. Prévisualiser permet de
	 * constater le déséquilibre AVANT qu'il ne soit équilibré de force.
	 *
	 * @return array{
	 *   ok:bool, message:string, lignes:array, total_debit:float,
	 *   total_credit:float, ecart:float, equilibre:bool, cause:string,
	 *   debut:string, fin_precedente:string, exercice_source:int,
	 *   nb_comptes:int, nb_auxiliaires:int
	 * }
	 */
	public static function previsualiser( $annee, $detailAuxiliaire = true ) {
		$annee   = (int) $annee;
		$finPrec = self::finDe( $annee - 1 );
		$debut   = self::debutDe( $annee );

		$out = array(
			'ok' => false, 'message' => '', 'lignes' => array(),
			'total_debit' => 0.0, 'total_credit' => 0.0, 'ecart' => 0.0,
			'equilibre' => false, 'cause' => '',
			'debut' => $debut, 'fin_precedente' => $finPrec, 'exercice_source' => $annee - 1,
			'nb_comptes' => 0, 'nb_auxiliaires' => 0,
		);

		/*
		 * LE GROUPEMENT EST LE CŒUR DE LA MÉTHODE.
		 *
		 * Par (compte, tiers, devise) quand on veut garder les auxiliaires ;
		 * par compte seul sinon. Le second mode existe pour les dossiers dont
		 * la balance auxiliaire compte des milliers de tiers et qui préfèrent
		 * un à-nouveau collectif — c'est un choix de tenue, pas un défaut, mais
		 * il se paie par la perte de l'antériorité des créances, et l'écran le
		 * dit.
		 */
		/*
		 * ═══════════════════════════════════════════════════════════════════
		 * LA SOURCE EST L'EXERCICE N-1, PAS « TOUT CE QUI PRÉCÈDE » (1.778.0).
		 *
		 * L'ancienne génération sommait depuis l'origine :
		 *
		 *     WHERE e.date_ecriture <= $finPrec
		 *
		 * Ce n'est juste qu'au DEUXIÈME exercice d'un dossier. Dès le
		 * troisième, les à-nouveaux de N-1 sont eux-mêmes compris dans la
		 * somme, et ils rapportent déjà tout ce qui précède : chaque solde
		 * antérieur est alors compté DEUX FOIS.
		 *
		 * Un capital de 5 000 000 F devenait 10 000 000 à l'ouverture de la
		 * troisième année, 15 000 000 à la quatrième. Et le bilan restait
		 * parfaitement équilibré — actif et passif doublaient ensemble —,
		 * donc aucun contrôle comptable ne se déclenchait. Le défaut
		 * n'apparaissait qu'à la lecture du bilan par un humain, la troisième
		 * année, quand plus personne ne pensait aux à-nouveaux.
		 *
		 * La bonne source est le solde de l'EXERCICE N-1 pris sur sa propre
		 * période : il contient déjà ses à-nouveaux, donc tout l'historique,
		 * exactement une fois. C'est aussi, et ce n'est pas un hasard, la
		 * définition que le bilan emploie (FKC_EtatsDgi::soldesPeriode) : les
		 * à-nouveaux de N+1 doivent valoir le bilan de N, et ne le peuvent
		 * que s'ils se calculent de la même manière.
		 * ═══════════════════════════════════════════════════════════════════
		 */
		$debPrec = self::debutDe( $annee - 1 );

		try {
			if ( $detailAuxiliaire && self::colonneTiersDisponible() ) {
				$sql = "SELECT c.id compte_id, c.numero, c.libelle,
							l.tiers_type, l.tiers_id, l.devise,
							COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) cr,
							COALESCE(SUM(CASE WHEN l.devise IS NOT NULL THEN COALESCE(l.montant_devise,0) * (CASE WHEN l.debit>0 THEN 1 ELSE -1 END) ELSE 0 END),0) dev
						FROM comptes c
						JOIN ecriture_lignes l ON l.compte_id=c.id
						JOIN ecritures e ON e.id=l.ecriture_id
						WHERE e.date_ecriture BETWEEN ? AND ? AND c.classe BETWEEN 1 AND 5
						GROUP BY c.id, l.tiers_type, l.tiers_id, l.devise
						ORDER BY c.numero, l.tiers_id";
			} else {
				$sql = "SELECT c.id compte_id, c.numero, c.libelle,
							NULL tiers_type, NULL tiers_id, NULL devise,
							COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) cr, 0 dev
						FROM comptes c
						JOIN ecriture_lignes l ON l.compte_id=c.id
						JOIN ecritures e ON e.id=l.ecriture_id
						WHERE e.date_ecriture BETWEEN ? AND ? AND c.classe BETWEEN 1 AND 5
						GROUP BY c.id
						ORDER BY c.numero";
			}
			$rows = FKC_DB::q( $sql, array( $debPrec, $finPrec ) )->fetchAll();
		} catch ( \Throwable $e ) {
			$out['message'] = 'Soldes d\'ouverture illisibles : ' . $e->getMessage();
			return $out;
		}

		$lignes = array(); $totD = 0.0; $totC = 0.0; $comptes = array(); $aux = 0;
		foreach ( $rows as $r ) {
			$solde = round( (float) $r['d'] - (float) $r['cr'], 2 );
			if ( abs( $solde ) < 0.005 ) { continue; }

			$lib = 'À-nouveaux ' . $annee;
			if ( ! empty( $r['tiers_id'] ) ) { $aux++; }

			$l = array(
				'compte_id' => (int) $r['compte_id'],
				'numero'    => (string) $r['numero'],
				'compte'    => (string) $r['libelle'],
				'libelle'   => $lib,
				'debit'     => $solde > 0 ? $solde : 0.0,
				'credit'    => $solde < 0 ? -$solde : 0.0,
				'tiers_type'=> ! empty( $r['tiers_type'] ) ? (string) $r['tiers_type'] : null,
				'tiers_id'  => ! empty( $r['tiers_id'] ) ? (int) $r['tiers_id'] : null,
				'devise'    => ! empty( $r['devise'] ) ? (string) $r['devise'] : null,
				// Le montant en devise suit le sens du solde : une position
				// nette débitrice de 1 200 EUR est ce que la revalorisation de
				// la clôture suivante devra réévaluer.
				'montant_devise' => ! empty( $r['devise'] ) ? round( (float) $r['dev'], 2 ) : null,
			);
			$lignes[] = $l;
			$totD += $l['debit']; $totC += $l['credit'];
			$comptes[ (int) $r['compte_id'] ] = true;
		}

		$out['lignes']       = $lignes;
		$out['total_debit']  = round( $totD, 2 );
		$out['total_credit'] = round( $totC, 2 );
		$out['ecart']        = round( $totD - $totC, 2 );
		$out['equilibre']    = abs( $out['ecart'] ) <= self::TOLERANCE;
		$out['nb_comptes']   = count( $comptes );
		$out['nb_auxiliaires'] = $aux;

		if ( ! $lignes ) {
			/*
			 * AUCUN SOLDE À REPORTER N'EST PAS UNE ERREUR.
			 *
			 * C'est le cas normal d'une première année d'exploitation, ou d'un
			 * dossier dont la reprise de bilan se fera par le module de
			 * migration. L'ancienne version renvoyait ici un ÉCHEC, que
			 * `ouvrir()` transformait en message d'alerte sur une ouverture
			 * pourtant réussie — un faux problème signalé à chaque première
			 * ouverture de chaque nouveau dossier.
			 */
			$out['ok'] = true;
			$out['message'] = 'Aucun solde de bilan à reporter depuis ' . ( $annee - 1 ) . ' : '
				. 'l\'exercice s\'ouvre sans à-nouveaux. C\'est normal pour une première année d\'exploitation ; '
				. 'si le dossier reprend une comptabilité existante, passez par Comptabilité → Migration.';
			return $out;
		}

		if ( ! $out['equilibre'] ) {
			$out['cause']   = self::diagnostiquer( $annee - 1, $out['ecart'] );
			$out['message'] = 'À-nouveaux déséquilibrés : débit ' . fkc_money( $out['total_debit'] )
				. ' ≠ crédit ' . fkc_money( $out['total_credit'] ) . ' F CFA (écart ' . fkc_money( $out['ecart'] ) . '). '
				. $out['cause'];
			return $out;
		}

		$out['ok'] = true;
		$out['message'] = count( $lignes ) . ' ligne(s) d\'à-nouveaux, équilibrées, pour '
			. fkc_money( $out['total_debit'] ) . ' F CFA.';
		return $out;
	}

	/**
	 * Nomme la cause d'un déséquilibre — la partie qui manquait le plus.
	 *
	 * Un message qui dit « écart de 4 312 500 » envoie chercher pendant une
	 * heure. Le même message qui ajoute « c'est exactement le solde de vos
	 * classes 6 et 7 : le résultat n'a pas été déterminé » envoie cliquer sur
	 * le bon bouton.
	 */
	protected static function diagnostiquer( $exercicePrec, $ecart ) {
		$gestion = null;
		if ( class_exists( 'FKC_ClotureProcessus' ) ) {
			$gestion = FKC_ClotureProcessus::soldeGestion( $exercicePrec );
		}

		if ( null !== $gestion && abs( $gestion ) > self::TOLERANCE && abs( abs( $gestion ) - abs( $ecart ) ) <= self::TOLERANCE ) {
			return 'Cet écart est EXACTEMENT le solde de vos comptes de gestion (classes 6, 7 et 8) sur '
				. $exercicePrec . ' : le résultat de l\'exercice n\'a jamais été déterminé. '
				. 'Clôturez l\'exercice ' . $exercicePrec . ' — la détermination du résultat soldera ces comptes vers 131 ou 139 — '
				. 'puis relancez l\'ouverture. FinaKop ne loge plus cet écart en report à nouveau : '
				. 'ce serait affecter un résultat que personne n\'a décidé d\'affecter.';
		}

		if ( null !== $gestion && abs( $gestion ) > self::TOLERANCE ) {
			return 'Les comptes de gestion de ' . $exercicePrec . ' portent encore ' . fkc_money( $gestion )
				. ' F CFA : le résultat n\'est pas entièrement déterminé. L\'écart des à-nouveaux ne s\'y ramène '
				. 'pourtant pas exactement, ce qui indique une seconde cause — vérifiez aussi le contrôle '
				. '« Balance de l\'exercice équilibrée » sur ' . $exercicePrec . '.';
		}

		return 'Les comptes de gestion de ' . $exercicePrec . ' sont soldés : l\'écart ne vient pas du résultat. '
			. 'Il vient donc d\'une écriture déséquilibrée ou d\'une ligne rattachée à un compte disparu — '
			. 'lancez les contrôles de clôture de ' . $exercicePrec . ', catégorie « Comptabilité générale ».';
	}

	/* ── Génération ───────────────────────────────────────────────────────── */

	/**
	 * Génère l'écriture d'à-nouveaux de l'exercice.
	 *
	 * Atomique de bout en bout : la vérification d'unicité, la création de
	 * l'écriture et la mise à jour du pointeur sur l'exercice tiennent dans une
	 * seule transaction. Le contrôle d'unicité est REFAIT dans la transaction :
	 * le vérifier avant de l'ouvrir laisserait la porte ouverte à deux
	 * générations simultanées, qui est précisément le scénario qu'on veut
	 * rendre impossible.
	 *
	 * @param int   $annee
	 * @param array $opts  detail_auxiliaire (bool), motif (string)
	 * @return array{bool,string,int|null} ( ok, message, ecriture_id )
	 */
	public static function generer( $annee, array $opts = array() ) {
		$annee  = (int) $annee;
		$detail = ! isset( $opts['detail_auxiliaire'] ) || (bool) $opts['detail_auxiliaire'];

		$journalId = self::journalAN();
		if ( ! $journalId ) {
			$msg = 'Journal AN (à-nouveaux) introuvable : créez-le avant d\'ouvrir l\'exercice. '
				. 'Les à-nouveaux ne se logent pas dans un journal d\'opérations diverses — '
				. 'ils doivent rester isolables pour être exclus des états de mouvements.';
			self::tracerRefus( $annee, $msg );
			return array( false, $msg, null );
		}

		/*
		 * LE DOUBLON SE DIT EN PREMIER, ET AVEC SES MOTS.
		 *
		 * La checklist le détecte aussi, mais son libellé est court — il tient
		 * sur une ligne d'écran. Ici, c'est le message qui reste à l'utilisateur
		 * après un clic : il doit expliquer CE QUI SE SERAIT PASSÉ, parce que
		 * c'est la seule chose qui empêche de chercher à contourner le refus.
		 */
		$dejaLa = self::ecrituresExistantes( $annee );
		if ( $dejaLa ) {
			$msg = 'À-nouveaux déjà générés pour ' . $annee . ' (écriture #' . implode( ', #', $dejaLa ) . '). '
				. 'Une seconde génération doublerait tous les soldes d\'ouverture — capital, immobilisations, '
				. 'dettes, trésorerie — sur un bilan qui resterait équilibré, donc sans qu\'aucun contrôle '
				. 'ne s\'en aperçoive. Annulez d\'abord les à-nouveaux existants si vous voulez les refaire.';
			self::tracerRefus( $annee, $msg );
			return array( false, $msg, null );
		}

		/*
		 * LES CONTRÔLES D'OUVERTURE SONT DANS LE MOTEUR, PAS DANS L'ÉCRAN.
		 *
		 * La vue désactive bien son bouton quand un contrôle bloque, mais un
		 * bouton désactivé n'est pas une règle : l'appel direct, l'API, un
		 * traitement planifié ou un formulaire rejoué contournent l'écran. Une
		 * règle qui ne vit que dans le HTML n'existe pas.
		 */
		if ( class_exists( 'FKC_ClotureChecklist' ) ) {
			$s = FKC_ClotureChecklist::synthese( $annee, 'ouverture' );
			if ( (int) $s['bloquants'] > 0 ) {
				$msg = 'Génération refusée : ' . implode( ' · ', $s['libelles_bloquants'] ) . '.';
				self::tracerRefus( $annee, $msg );
				return array( false, $msg, null );
			}
		}

		$vue = self::previsualiser( $annee, $detail );
		if ( ! $vue['ok'] ) {
			self::tracerRefus( $annee, $vue['message'] );
			return array( false, $vue['message'], null );
		}

		/*
		 * UNE SEULE SOURCE D'OUVERTURE PAR EXERCICE (1.798.0).
		 *
		 * Le doublon constaté ne venait pas d'une seconde génération — elle
		 * est refusée plus haut — mais d'une ouverture déjà faite par un
		 * autre chemin : reprise de bilan par la migration, OD saisie pour
		 * « reprendre les soldes », écriture importée au journal AN. Générer
		 * par-dessus doublait le bilan d'ouverture. On refuse, et on nomme
		 * l'écriture en cause.
		 */
		/*
		 * UNE OUVERTURE NON FIABLE NE SE PROPAGE PAS (1.799.0).
		 *
		 * Les À-nouveaux de N reprennent la clôture de N-1. Si l'ouverture de
		 * N-1 était doublée, sa clôture l'est aussi, et des À-nouveaux fidèles
		 * à cette clôture transporteraient le doublon dans l'exercice suivant —
		 * avec un rapprochement parfaitement concordant. On refuse, et on dit
		 * où réparer.
		 */
		if ( $vue['lignes'] && class_exists( 'FKC_SoldeOuverture' ) ) {
			$prec = FKC_SoldeOuverture::fiabilite( $annee - 1 );
			if ( ! $prec['fiable'] ) {
				$msg = 'Génération des À-nouveaux ' . $annee . ' refusée : l\'ouverture de ' . ( $annee - 1 ) . ' n\'est pas fiable — '
					. implode( ' ', $prec['raisons'] ) . ' Sa clôture la reprend, et des À-nouveaux fidèles à cette clôture '
					. 'transporteraient l\'anomalie dans ' . $annee . '. Réparez d\'abord ' . ( $annee - 1 ) . ' (Audit des À-nouveaux).';
				self::tracerRefus( $annee, $msg );
				return array( false, $msg, null );
			}
		}
		if ( $vue['lignes'] && class_exists( 'FKC_SoldeOuverture' ) ) {
			$autres = FKC_SoldeOuverture::autresSources( $annee );
			if ( $autres ) {
				$t = array();
				foreach ( $autres as $a ) {
					$t[] = $a['libelle_type'] . ' #' . $a['id'] . ' du ' . date( 'd/m/Y', strtotime( $a['date'] ) )
						. ' (' . $a['journal'] . ( $a['piece'] ? ', ' . $a['piece'] : '' ) . ', ' . fkc_money( $a['montant'] ) . ' F)';
				}
				$msg = 'Génération des À-nouveaux ' . $annee . ' refusée : l\'exercice possède déjà une autre source d\'ouverture — '
					. implode( ' ; ', $t ) . '. Générer par-dessus doublerait les soldes d\'ouverture. '
					. 'Contrôlez l\'Audit des À-nouveaux : si cette écriture reprend bien la clôture de ' . ( $annee - 1 )
					. ', elle tient lieu d\'ouverture ; sinon, contre-passez-la avant de générer.';
				self::tracerRefus( $annee, $msg );
				return array( false, $msg, null );
			}
		}
		if ( ! $vue['lignes'] ) {
			// Rien à reporter : succès sans écriture. L'appelant doit pouvoir
			// distinguer ce cas d'un échec — d'où le `true`.
			return array( true, $vue['message'], null );
		}

		try {
			return FKC_Tx::executer( function () use ( $annee, $vue, $journalId, $opts ) {

				$doublons = self::ecrituresExistantes( $annee );
				if ( $doublons ) {
					throw new \RuntimeException(
						'À-nouveaux déjà générés pour ' . $annee . ' (écriture #' . implode( ', #', $doublons ) . '). '
						. 'Une seconde génération doublerait tous les soldes d\'ouverture — capital, immobilisations, '
						. 'dettes, trésorerie — sur un bilan qui resterait équilibré, donc sans qu\'aucun contrôle '
						. 'ne s\'en aperçoive. Annulez d\'abord les à-nouveaux existants si vous voulez les refaire.'
					);
				}

				$lignes = array();
				foreach ( $vue['lignes'] as $l ) {
					$lignes[] = array(
						'compte_id' => $l['compte_id'],
						'libelle'   => $l['libelle'],
						'debit'     => $l['debit'],
						'credit'    => $l['credit'],
						'tiers_type'=> $l['tiers_type'],
						'tiers_id'  => $l['tiers_id'],
						'devise'    => $l['devise'],
						'montant_devise' => $l['montant_devise'],
					);
				}

				list( $ok, $msg, $eid ) = FKC_Ecriture::save(
					array(
						'journal_id'    => $journalId,
						'date_ecriture' => $vue['debut'],
						// Terminologie (1.798.0) : « Report à nouveau » désigne
						// l'affectation du résultat, jamais l'ouverture.
						'libelle'       => 'À-nouveaux — Ouverture de l\'exercice ' . $annee,
						'reference'     => self::REF . $annee,
						'created_by'    => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
						'source'        => 'cloture',
						'origine'       => 'anouveaux',
						'fait'          => 'ouverture_exercice',
						/*
						 * Écriture d'INVENTAIRE au sens de prepare() : elle est
						 * datée du premier jour de N+1 et produite par le moteur
						 * de clôture. Le drapeau ne la dispense d'aucun contrôle
						 * — il substitue simplement au verrou de période celui
						 * de l'exercice, qui est le bon garde-fou ici : si N+1
						 * est lui-même déjà clôturé, l'écriture est refusée.
						 */
						'inventaire'    => true,
					),
					$lignes
				);
				if ( ! $ok ) { throw new \RuntimeException( 'À-nouveaux non générés : ' . $msg ); }

				try {
					FKC_DB::q( 'UPDATE exercices SET an_ecriture_id=? WHERE annee=?', array( (int) $eid, $annee ) );
				} catch ( \Throwable $e ) { /* la ligne d'exercice peut ne pas exister encore */ }
				if ( class_exists( 'FKC_SoldeOuverture' ) ) {
					FKC_SoldeOuverture::tracerGeneration( $annee, (int) $eid, $vue['total_debit'] );
				}

				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $annee, 'anouveaux', array(
						'libelle'     => count( $lignes ) . ' ligne(s) d\'à-nouveaux au ' . date( 'd/m/Y', strtotime( $vue['debut'] ) ),
						'motif'       => (string) ( $opts['motif'] ?? '' ),
						'montant'     => $vue['total_debit'],
						'ecriture_id' => (int) $eid,
						'reference'   => self::REF . $annee,
						'detail'      => array(
							'comptes' => $vue['nb_comptes'], 'auxiliaires' => $vue['nb_auxiliaires'],
							'debit' => $vue['total_debit'], 'credit' => $vue['total_credit'],
						),
					) );
				}

				return array( true, 'À-nouveaux générés au ' . date( 'd/m/Y', strtotime( $vue['debut'] ) ) . ' : '
					. count( $lignes ) . ' ligne(s), ' . fkc_money( $vue['total_debit'] ) . ' F CFA, équilibrées.', (int) $eid );
			} );
		} catch ( \Throwable $e ) {
			self::tracerRefus( $annee, $e->getMessage() );
			return array( false, $e->getMessage(), null );
		}
	}

	/* ── Annulation ───────────────────────────────────────────────────────── */

	/**
	 * Supprime les à-nouveaux d'un exercice.
	 *
	 * Refusée si l'exercice a déjà vécu : des écritures postérieures reposent
	 * sur ces soldes d'ouverture, et les retirer laisserait un exercice dont
	 * la balance ne part de rien. Le message le dit plutôt que de laisser
	 * faire — c'est la différence avec `annulerOuverture()`, qui effaçait
	 * l'écriture sans rien regarder.
	 *
	 * @return array{bool,string}
	 */
	public static function annuler( $annee, $motif = '' ) {
		$annee = (int) $annee;
		$ids   = self::ecrituresExistantes( $annee );
		if ( ! $ids ) { return array( false, 'Aucune écriture d\'à-nouveaux à annuler pour ' . $annee . '.' ); }

		$motif = trim( (string) $motif );
		if ( mb_strlen( $motif ) < 10 ) {
			return array( false, 'Annuler des à-nouveaux est une opération exceptionnelle : indiquez le motif '
				. '(une phrase). Il sera consigné au journal de clôture.' );
		}

		if ( class_exists( 'FKC_ClotureProcessus' ) && FKC_ClotureProcessus::exerciceClos( $annee ) ) {
			return array( false, 'L\'exercice ' . $annee . ' est clôturé : ses à-nouveaux ne peuvent plus être '
				. 'retirés sans rouvrir d\'abord la clôture annuelle.' );
		}

		$autres = self::mouvementsHorsAN( $annee, $ids );
		if ( $autres > 0 ) {
			return array( false, 'L\'exercice ' . $annee . ' porte déjà ' . $autres . ' écriture(s) : retirer les '
				. 'à-nouveaux laisserait une comptabilité qui ne part d\'aucun solde d\'ouverture. '
				. 'Corrigez plutôt les à-nouveaux, ou reprenez l\'exercice depuis Paramètres → Maintenance.' );
		}

		try {
			return FKC_Tx::executer( function () use ( $annee, $ids, $motif ) {
				foreach ( $ids as $id ) {
					// Les lignes partent en cascade (FOREIGN KEY … ON DELETE
					// CASCADE) ; on les retire tout de même explicitement, car
					// les clés étrangères de SQLite ne sont actives que si
					// PRAGMA foreign_keys est posé — ce qui dépend du contexte.
					FKC_DB::q( 'DELETE FROM ecriture_lignes WHERE ecriture_id=?', array( (int) $id ) );
					FKC_DB::q( 'DELETE FROM ecritures WHERE id=?', array( (int) $id ) );
				}
				try { FKC_DB::q( 'UPDATE exercices SET an_ecriture_id=NULL WHERE annee=?', array( $annee ) ); }
				catch ( \Throwable $e ) { /* table absente */ }

				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $annee, 'anouveaux_annules', array(
						'issue' => 'avertissement',
						'libelle' => count( $ids ) . ' écriture(s) d\'à-nouveaux supprimée(s) : #' . implode( ', #', $ids ),
						'motif' => $motif,
					) );
				}
				return array( true, count( $ids ) . ' écriture(s) d\'à-nouveaux supprimée(s). '
					. 'L\'exercice ' . $annee . ' n\'a plus de soldes d\'ouverture.' );
			} );
		} catch ( \Throwable $e ) {
			return array( false, 'Annulation impossible : ' . $e->getMessage() );
		}
	}

	/* ── Rapprochement N / N+1 ────────────────────────────────────────────── */

	/**
	 * Confronte les soldes de CLÔTURE de N-1 aux soldes d'OUVERTURE de N.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * LE CONTRÔLE QUI N'EXISTAIT PAS
	 *
	 * Rien ne vérifiait que l'ouverture correspondait à la clôture. Tant que
	 * l'écriture d'à-nouveaux s'équilibrait, elle était réputée juste — y
	 * compris quand elle avait été équilibrée de force, quand un compte avait
	 * été oublié, ou quand elle avait été passée deux fois.
	 *
	 * Le rapprochement compare compte par compte et rend les écarts. Sur un
	 * dossier sain, la liste est vide — et c'est cette liste vide, imprimable,
	 * qui constitue la preuve qu'un vérificateur demande.
	 *
	 * L'affectation du résultat est traitée à part : si elle a été passée
	 * ENTRE la clôture et l'ouverture, les comptes 131/139 et 106/121/129 ont
	 * légitimement bougé. Ces écarts-là sont rapprochés de la décision
	 * d'affectation plutôt que signalés comme anomalies.
	 *
	 * @return array{ecarts:array, concordant:bool, nb_comptes:int, affectation:array}
	 */
	/**
	 * @param bool $tracer Consigner le rapprochement au journal de clôture.
	 *                     Faux pour une LECTURE (impression, Maestro) : le
	 *                     journal est un registre de gestes, et Maestro qui
	 *                     analyse le dossier dix fois par jour y aurait
	 *                     inscrit dix rapprochements que personne n'a faits.
	 */
	public static function rapprochement( $annee, $tracer = true ) {
		$annee   = (int) $annee;
		$finPrec = self::finDe( $annee - 1 );
		$debut   = self::debutDe( $annee );

		$out = array(
			'exercice' => $annee, 'fin_precedente' => $finPrec, 'debut' => $debut,
			'ecarts' => array(), 'concordant' => true, 'nb_comptes' => 0,
			'affectation' => array(), 'total_cloture' => 0.0, 'total_ouverture' => 0.0,
			'message' => '',
		);

		try {
			// Soldes de clôture de N-1, classes de bilan — pris sur la PÉRIODE
			// de N-1, comme le bilan les lit (voir previsualiser()).
			$cloture = self::soldesExercice( $annee - 1 );
			// Soldes d'OUVERTURE de N : uniquement l'écriture d'à-nouveaux.
			$ouverture = self::soldesANouveaux( $annee );
		} catch ( \Throwable $e ) {
			$out['concordant'] = false;
			$out['message'] = 'Rapprochement impossible : ' . $e->getMessage();
			return $out;
		}

		// Comptes affectés par une décision d'affectation passée entre les deux.
		$comptesAffectation = array();
		if ( class_exists( 'FKC_AffectationResultat' ) ) {
			$comptesAffectation = FKC_AffectationResultat::comptesConcernes( $annee - 1 );
		}

		$numeros = array_unique( array_merge( array_keys( $cloture ), array_keys( $ouverture ) ) );
		sort( $numeros );

		foreach ( $numeros as $num ) {
			$c = round( (float) ( $cloture[ $num ]['solde'] ?? 0 ), 2 );
			$o = round( (float) ( $ouverture[ $num ]['solde'] ?? 0 ), 2 );
			$out['total_cloture']   += $c;
			$out['total_ouverture'] += $o;
			$ecart = round( $c - $o, 2 );
			if ( abs( $ecart ) <= self::TOLERANCE ) { continue; }

			$ligne = array(
				'numero'  => $num,
				'libelle' => (string) ( $cloture[ $num ]['libelle'] ?? $ouverture[ $num ]['libelle'] ?? '' ),
				'cloture' => $c, 'ouverture' => $o, 'ecart' => $ecart,
				'affectation' => in_array( $num, $comptesAffectation, true ),
			);
			if ( $ligne['affectation'] ) {
				$out['affectation'][] = $ligne;
			} else {
				$out['ecarts'][] = $ligne;
				$out['concordant'] = false;
			}
		}

		$out['nb_comptes'] = count( $numeros );
		$out['message'] = $out['concordant']
			? 'Concordance vérifiée sur ' . $out['nb_comptes'] . ' compte(s) : les soldes d\'ouverture de ' . $annee
				. ' correspondent aux soldes de clôture de ' . ( $annee - 1 )
				. ( $out['affectation'] ? ', hors ' . count( $out['affectation'] ) . ' compte(s) mouvementé(s) par l\'affectation du résultat.' : '.' )
			: count( $out['ecarts'] ) . ' compte(s) en écart entre la clôture de ' . ( $annee - 1 )
				. ' et l\'ouverture de ' . $annee . '.';

		if ( $tracer && class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'rapprochement', array(
				'issue'   => $out['concordant'] ? 'ok' : 'avertissement',
				'libelle' => $out['message'],
				'detail'  => array_slice( $out['ecarts'], 0, 20 ),
			) );
		}
		return $out;
	}

	/* ── Réparation douce ─────────────────────────────────────────────────── */

	/**
	 * Recale `exercices.an_ecriture_id` sur l'écriture réellement trouvée.
	 *
	 * Répare l'incohérence laissée par les anciennes annulations d'ouverture :
	 * un pointeur vers une écriture disparue, ou une écriture d'à-nouveaux
	 * orpheline que plus aucun exercice ne réclame. N'écrit ni ne supprime
	 * aucune écriture — elle ne touche qu'au pointeur.
	 */
	public static function resynchroniser( $annee ) {
		$annee = (int) $annee;
		$ids   = self::ecrituresExistantes( $annee );
		try {
			FKC_DB::q( 'UPDATE exercices SET an_ecriture_id=? WHERE annee=?',
				array( $ids ? (int) $ids[0] : null, $annee ) );
		} catch ( \Throwable $e ) { return false; }
		return true;
	}

	/* ── Lectures ─────────────────────────────────────────────────────────── */

	/**
	 * Soldes de bilan (classes 1 à 5) d'un EXERCICE, indexés par numéro.
	 *
	 * Sur la période de l'exercice, à-nouveaux compris : c'est la définition du
	 * bilan, et la seule qui ne compte pas deux fois l'historique — voir le
	 * commentaire de previsualiser().
	 */
	public static function soldesExercice( $annee ) {
		// Clôture telle que le Bilan de l'exercice la montre (1.798.0).
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			$out = array();
			foreach ( FKC_SoldeOuverture::soldesCloture( $annee ) as $num => $r ) {
				$out[ $num ] = array( 'solde' => $r['solde'], 'libelle' => $r['libelle'] );
			}
			return $out;
		}
		list( $d, $f ) = self::bornes( $annee );
		$rows = FKC_DB::q(
			'SELECT c.numero, c.libelle, COALESCE(SUM(l.debit),0)-COALESCE(SUM(l.credit),0) solde
			 FROM comptes c JOIN ecriture_lignes l ON l.compte_id=c.id
			 JOIN ecritures e ON e.id=l.ecriture_id
			 WHERE e.date_ecriture BETWEEN ? AND ? AND c.classe BETWEEN 1 AND 5
			 GROUP BY c.id', array( $d, $f )
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$s = round( (float) $r['solde'], 2 );
			if ( abs( $s ) < 0.005 ) { continue; }
			$out[ (string) $r['numero'] ] = array( 'solde' => $s, 'libelle' => (string) $r['libelle'] );
		}
		return $out;
	}

	/** Soldes portés par la (les) écriture(s) d'à-nouveaux de l'exercice. */
	protected static function soldesANouveaux( $annee ) {
		$ids = self::ecrituresExistantes( $annee );
		if ( ! $ids ) { return array(); }
		$in = implode( ',', array_map( 'intval', $ids ) );
		$rows = FKC_DB::q(
			"SELECT c.numero, c.libelle, COALESCE(SUM(l.debit),0)-COALESCE(SUM(l.credit),0) solde
			 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
			 WHERE l.ecriture_id IN ($in) GROUP BY c.id"
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$s = round( (float) $r['solde'], 2 );
			if ( abs( $s ) < 0.005 ) { continue; }
			$out[ (string) $r['numero'] ] = array( 'solde' => $s, 'libelle' => (string) $r['libelle'] );
		}
		return $out;
	}

	/** Écritures de l'exercice autres que les à-nouveaux. */
	protected static function mouvementsHorsAN( $annee, array $idsAN ) {
		list( $d, $f ) = self::bornes( $annee );
		$excl = $idsAN ? ' AND id NOT IN (' . implode( ',', array_map( 'intval', $idsAN ) ) . ')' : '';
		try {
			return (int) FKC_DB::q(
				'SELECT COUNT(*) FROM ecritures WHERE date_ecriture BETWEEN ? AND ?' . $excl,
				array( $d, $f )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	protected static function journalAN() {
		try {
			$r = FKC_DB::q( "SELECT id FROM journaux WHERE code='AN' LIMIT 1" )->fetch();
			return $r ? (int) $r['id'] : 0;
		} catch ( \Throwable $e ) { return 0; }
	}

	/** La colonne `tiers_id` a-t-elle bien été ajoutée à ce dossier ? */
	protected static function colonneTiersDisponible() {
		static $ok = null;
		if ( null !== $ok ) { return $ok; }
		$ok = false;
		try {
			foreach ( FKC_DB::conn()->query( 'PRAGMA table_info(ecriture_lignes)' ) as $c ) {
				if ( 'tiers_id' === ( $c['name'] ?? '' ) ) { $ok = true; break; }
			}
		} catch ( \Throwable $e ) { $ok = false; }
		return $ok;
	}

	protected static function tracerRefus( $annee, $message ) {
		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracerRefus( $annee, 'anouveaux', $message );
		}
	}

	/* ── Bornes ───────────────────────────────────────────────────────────── */

	protected static function bornes( $annee ) {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'bornes' ) ) {
			return FKC_Exercice::bornes( (int) $annee );
		}
		return array( sprintf( '%04d-01-01', (int) $annee ), sprintf( '%04d-12-31', (int) $annee ) );
	}
	protected static function debutDe( $annee ) { $b = self::bornes( $annee ); return $b[0]; }
	protected static function finDe( $annee )   { $b = self::bornes( $annee ); return $b[1]; }
}
