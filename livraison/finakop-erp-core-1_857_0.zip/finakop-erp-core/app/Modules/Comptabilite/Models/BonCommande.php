<?php
/** Bons de commande fournisseurs (achats), rattachables aux factures fournisseurs. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_BonCommande {

	public static function statuts() {
		return array( 'ouvert' => 'Ouvert', 'rattache' => 'Rattaché à une facture', 'recu' => 'Reçu', 'annule' => 'Annulé' );
	}

	public static function all() {
		return FKC_DB::q(
			"SELECT b.*, f.numero AS facture_numero
			 FROM bons_commande b
			 LEFT JOIN factures_fournisseurs f ON f.id=b.facture_fournisseur_id
			 ORDER BY b.date_bc DESC, b.id DESC"
		)->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM bons_commande WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function nextNumero( $date = null ) {
		/*
		 * Le rang vient du PLUS GRAND numéro attribué, non du nombre de pièces
		 * existantes (1.616.0). Compter suppose que rien ne disparaît jamais :
		 * après une purge, le compte retombe et la pièce suivante réutilise un
		 * numéro déjà vivant. Deux pièces, un seul numéro, et aucune contrainte
		 * de base pour s'y opposer.
		 */
		/*
		 * L'ANNÉE VIENT DE LA DATE DE LA PIÈCE (1.726.0), pas de l'horloge.
		 * Une facture datée du 31/12 saisie le 3 janvier appartient à
		 * l'exercice précédent : son numéro doit le dire.
		 */
		return FKC_Numerotation::suivant( 'BC', 'bons_commande', '',
			FKC_Numerotation::anneeDe( $date ) );
	}

	public static function create( $d ) {
		$frn = ! empty( $d['fournisseur_id'] ) ? FKC_Fournisseur::find( (int) $d['fournisseur_id'] ) : null;
		$dateBc = ( $d['date_bc'] ?? '' ) ?: date( 'Y-m-d' );
		FKC_DB::q(
			'INSERT INTO bons_commande(numero,fournisseur_id,fournisseur_nom,date_bc,date_livraison,objet,montant_ht,montant_ttc,statut,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
			array(
				self::nextNumero( $dateBc ),
				$frn ? (int) $frn['id'] : null,
				$frn ? $frn['nom'] : ( trim( (string) ( $d['fournisseur_nom'] ?? '' ) ) ?: null ),
				$dateBc,
				( $d['date_livraison'] ?? '' ) ?: null,
				trim( (string) ( $d['objet'] ?? '' ) ) ?: null,
				(float) ( $d['montant_ht'] ?? 0 ),
				(float) ( $d['montant_ttc'] ?? 0 ),
				'ouvert',
				trim( (string) ( $d['notes'] ?? '' ) ) ?: null,
				FKC_Auth::id(),
			)
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/** Rattache un bon de commande à une facture fournisseur. */
	public static function rattacher( $id, $factureId ) {
		$bc = self::find( $id );
		if ( ! $bc ) { return array( false, 'Bon de commande introuvable.' ); }
		$f = FKC_DB::q( 'SELECT * FROM factures_fournisseurs WHERE id=?', array( (int) $factureId ) )->fetch();
		if ( ! $f ) { return array( false, 'Facture fournisseur introuvable.' ); }
		FKC_DB::q( "UPDATE bons_commande SET facture_fournisseur_id=?, statut='rattache' WHERE id=?", array( (int) $factureId, (int) $id ) );
		return array( true, 'Bon de commande rattaché à la facture ' . $f['numero'] . '.' );
	}
	public static function detacher( $id ) {
		FKC_DB::q( "UPDATE bons_commande SET facture_fournisseur_id=NULL, statut='ouvert' WHERE id=?", array( (int) $id ) );
		return array( true, 'Rattachement annulé.' );
	}
	public static function annuler( $id ) {
		FKC_DB::q( "UPDATE bons_commande SET statut='annule' WHERE id=?", array( (int) $id ) );
		return array( true, 'Bon de commande annulé.' );
	}

	/** Factures fournisseurs disponibles pour rattachement (non déjà liées à un autre BC). */
	public static function facturesDisponibles() {
		return FKC_DB::q(
			"SELECT * FROM factures_fournisseurs
			 WHERE statut!='annulee' AND id NOT IN ( SELECT facture_fournisseur_id FROM bons_commande WHERE facture_fournisseur_id IS NOT NULL )
			 ORDER BY date_facture DESC, id DESC"
		)->fetchAll();
	}
}
