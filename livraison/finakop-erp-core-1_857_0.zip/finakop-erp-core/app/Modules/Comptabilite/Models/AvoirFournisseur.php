<?php
/**
 * Avoirs fournisseurs.
 *
 * POURQUOI CE MODÈLE MANQUAIT CRUELLEMENT
 *
 * Sans avoir, un retour de marchandise laisse une dette qui ne s'éteint jamais.
 * Le fournisseur reprend son lot défectueux, mais le compte 401 continue
 * d'afficher la somme entière : le solde ne se lettre pas, le règlement se fait
 * pour un montant qui ne correspond à aucune pièce, et l'écart finit par être
 * absorbé dans un compte d'attente que personne ne justifiera.
 *
 * DEUX NATURES, DEUX COMPTABILISATIONS
 *
 * Elles ne se confondent pas, et les mélanger fausserait la lecture du compte
 * de résultat :
 *
 *   RETOUR DE MARCHANDISE — la marchandise repart. La charge d'achat est
 *   annulée à due concurrence, et le STOCK doit sortir : il ne contient plus
 *   ces articles.
 *
 *       D 401 Fournisseur
 *           C 6xx Achats          (annulation de la charge)
 *           C 4452 TVA déductible (la taxe suit la marchandise)
 *       et, si le stock est tenu :
 *       D 603 Variation           C 31x Stock
 *
 *   RABAIS, REMISE OU RISTOURNE — la marchandise reste, seul le prix baisse.
 *   Aucun mouvement de stock : le stock a été valorisé à un coût désormais trop
 *   élevé, mais le corriger rétroactivement supposerait de retrouver les
 *   sorties déjà valorisées. SYSCOHADA prévoit un compte dédié.
 *
 *       D 401 Fournisseur
 *           C 6019 RRR obtenus
 *           C 4452 TVA déductible
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AvoirFournisseur {

	/** Natures d'avoir. */
	const RETOUR = 'retour';
	const RRR    = 'rrr';

	/** Compte SYSCOHADA des rabais, remises et ristournes obtenus. */
	const COMPTE_RRR = '601900';

	public static function natures() {
		return array(
			self::RETOUR => 'Retour de marchandise',
			self::RRR    => 'Rabais, remise ou ristourne',
		);
	}

	protected static $pret = false;

	public static function ensure() {
		if ( self::$pret ) { return; }
		try {
			FKC_DB::conn()->exec(
				"CREATE TABLE IF NOT EXISTS avoirs_fournisseurs(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					numero TEXT,
					fournisseur_id INTEGER NOT NULL,
					fournisseur_nom TEXT,
					nature TEXT NOT NULL DEFAULT 'retour',
					date_avoir TEXT NOT NULL,
					reference TEXT,
					facture_id INTEGER,
					montant_ht REAL NOT NULL DEFAULT 0,
					taux_tva REAL NOT NULL DEFAULT 0,
					montant_tva REAL NOT NULL DEFAULT 0,
					montant_ttc REAL NOT NULL DEFAULT 0,
					compte_contrepartie TEXT,
					motif TEXT,
					ecriture_id INTEGER,
					statut TEXT NOT NULL DEFAULT 'valide',
					created_at TEXT DEFAULT(datetime('now','localtime'))
				);
				CREATE INDEX IF NOT EXISTS idx_avf_frn ON avoirs_fournisseurs(fournisseur_id);"
			);
			self::$pret = true;
		} catch ( \Throwable $e ) { self::$pret = false; }
	}

	public static function nextNumero( $date = null ) {
		self::ensure();
		/*
		 * Le rang vient du PLUS GRAND numéro attribué, non du nombre de pièces
		 * existantes (1.616.0). Compter suppose que rien ne disparaît jamais :
		 * après une purge, le compte retombe et la pièce suivante réutilise un
		 * numéro déjà vivant. Deux pièces, un seul numéro, et aucune contrainte
		 * de base pour s'y opposer.
		 */
		/*
		 * L'ANNÉE VIENT DE LA DATE DE LA PIÈCE (1.726.0), pas de l'horloge.
		 * Une facture datée du 31/12 saisie le 3 janvier appartient à
		 * l'exercice précédent : son numéro doit le dire.
		 */
		return FKC_Numerotation::suivant( 'AVF', 'avoirs_fournisseurs', '',
			FKC_Numerotation::anneeDe( $date ) );
	}

	/**
	 * Enregistre un avoir et son écriture.
	 *
	 * @param array $d fournisseur_id, nature, montant_ht, taux_tva, motif,
	 *                 compte_contrepartie, article_id/entrepot_id/quantite pour
	 *                 un retour avec sortie de stock.
	 * @return array{0: bool, 1: string, 2: int|null}
	 */
	public static function create( array $d ) {
		self::ensure();
		$frn = FKC_Fournisseur::find( (int) ( $d['fournisseur_id'] ?? 0 ) );
		if ( ! $frn ) { return array( false, 'Fournisseur introuvable.', null ); }

		$ht = round( (float) ( $d['montant_ht'] ?? 0 ), 2 );
		if ( $ht <= 0 ) {
			// Le montant se saisit POSITIF : c'est le sens de l'écriture qui
			// fait de l'avoir une diminution, pas un signe à retenir.
			return array( false, 'Le montant de l\'avoir doit être positif.', null );
		}

		$nature = isset( self::natures()[ $d['nature'] ?? '' ] ) ? (string) $d['nature'] : self::RETOUR;
		$taux   = (float) ( $d['taux_tva'] ?? 18 );
		$tva    = round( $ht * $taux / 100, 2 );
		$ttc    = round( $ht + $tva, 2 );
		$date   = (string) ( $d['date_avoir'] ?? '' ) ?: date( 'Y-m-d' );

		/*
		 * Un retour annule la charge d'achat d'origine ; un rabais crédite le
		 * compte dédié. Utiliser le même compte dans les deux cas ferait
		 * disparaître les remises obtenues du compte de résultat, alors qu'elles
		 * sont un indicateur de négociation à part entière.
		 */
		$compte = trim( (string) ( $d['compte_contrepartie'] ?? '' ) );
		if ( '' === $compte ) {
			$compte = ( self::RRR === $nature ) ? self::COMPTE_RRR : '601000';
		}

		/*
		 * Le compte de contrepartie est CRÉÉ s'il manque.
		 *
		 * Le 601900 « rabais, remises et ristournes obtenus » ne figure pas au
		 * plan par défaut : exiger sa présence rendait tout rabais impossible
		 * sur une installation neuve, avec pour seul message « compte
		 * introuvable » — l'utilisateur n'ayant aucun moyen de deviner lequel.
		 * FKC_Posting::compteId() est le mécanisme déjà employé ailleurs pour
		 * cela.
		 */
		$libContre = ( self::COMPTE_RRR === $compte )
			? 'Rabais, remises et ristournes obtenus sur achats'
			: 'Achats';
		$idContre = FKC_Posting::compteId( $compte, $libContre );
		$cFrn     = FKC_Compte::byNumero( $frn['compte'] );
		if ( ! $idContre ) { return array( false, 'Compte de contrepartie ' . $compte . ' introuvable et non créable.', null ); }
		if ( ! $cFrn ) { return array( false, 'Compte du fournisseur introuvable.', null ); }
		$cContre = array( 'id' => $idContre );

		$numero = self::nextNumero( $date );
		$lib    = 'Avoir ' . $frn['nom'] . ' — ' . self::natures()[ $nature ]
			. ( ! empty( $d['reference'] ) ? ' (' . $d['reference'] . ')' : '' );
		$aux    = array( 'tiers_type' => 'fournisseur', 'tiers_id' => (int) $frn['id'] );

		// D 401 fournisseur / C contrepartie + C TVA déductible.
		$lignes = array(
			array_merge( array( 'compte_id' => (int) $cFrn['id'], 'libelle' => $lib, 'debit' => $ttc, 'credit' => 0 ), $aux ),
			array( 'compte_id' => (int) $cContre['id'], 'libelle' => $lib, 'debit' => 0, 'credit' => $ht ),
		);
		if ( $tva > 0 ) {
			$cTva = FKC_Compte::byNumero( '445200' ) ?: FKC_Compte::byNumero( '445100' );
			if ( ! $cTva ) { return array( false, 'Compte de TVA déductible introuvable.', null ); }
			$lignes[] = array( 'compte_id' => (int) $cTva['id'], 'libelle' => $lib . ' — TVA', 'debit' => 0, 'credit' => $tva );
		}

		list( $ok, $msg, $eid ) = FKC_Ecriture::enregistrer(
			array( 'journal_id' => FKC_Posting::journalId( 'AC' ), 'date_ecriture' => $date,
				'piece' => $numero, 'libelle' => $lib ),
			$lignes,
			array( 'source' => 'achat' )
		);
		if ( ! $ok ) { return array( false, 'Écriture refusée : ' . $msg, null ); }

		FKC_DB::q(
			'INSERT INTO avoirs_fournisseurs(numero,fournisseur_id,fournisseur_nom,nature,date_avoir,reference,
			 facture_id,montant_ht,taux_tva,montant_tva,montant_ttc,compte_contrepartie,motif,ecriture_id)
			 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array(
				$numero, (int) $frn['id'], (string) $frn['nom'], $nature, $date,
				(string) ( $d['reference'] ?? '' ) ?: null,
				! empty( $d['facture_id'] ) ? (int) $d['facture_id'] : null,
				$ht, $taux, $tva, $ttc, $compte, (string) ( $d['motif'] ?? '' ) ?: null,
				$eid ? (int) $eid : null
			)
		);
		$id = (int) FKC_DB::conn()->lastInsertId();

		/*
		 * Sortie de stock : uniquement pour un RETOUR, et seulement si
		 * l'appelant a précisé l'article. Sur un rabais la marchandise reste :
		 * la faire sortir créerait un manquant que l'inventaire physique
		 * démentirait.
		 */
		$stock = null;
		if ( self::RETOUR === $nature && ! empty( $d['article_id'] ) && (float) ( $d['quantite'] ?? 0 ) > 0
			&& class_exists( 'FKC_InvMouvement' ) ) {
			try {
				$stock = FKC_InvMouvement::sortie(
					(int) $d['article_id'], (int) ( $d['entrepot_id'] ?? 0 ), (float) $d['quantite'],
					array( 'motif' => 'retour_fournisseur' )
				);
			} catch ( \Throwable $e ) { $stock = null; }
		}

		$suffixe = $stock ? ' Stock ajusté.' : '';
		return array( true, 'Avoir ' . $numero . ' enregistré (' . fkc_money( $ttc ) . ' F).' . $suffixe, $id );
	}

	/* ── Lecture ─────────────────────────────────────────────────────────── */

	public static function all( $fournisseurId = null, $limit = 200 ) {
		self::ensure();
		$w = ''; $p = array();
		if ( $fournisseurId ) { $w = 'WHERE fournisseur_id = ?'; $p[] = (int) $fournisseurId; }
		try {
			return FKC_DB::q( "SELECT * FROM avoirs_fournisseurs {$w} ORDER BY id DESC LIMIT " . max( 1, (int) $limit ), $p )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	public static function find( $id ) {
		self::ensure();
		try { return FKC_DB::q( 'SELECT * FROM avoirs_fournisseurs WHERE id=?', array( (int) $id ) )->fetch() ?: null; }
		catch ( \Throwable $e ) { return null; }
	}

	/** Total des avoirs d'un fournisseur, pour un état de solde. */
	public static function totalFournisseur( $fournisseurId ) {
		self::ensure();
		try {
			return (float) FKC_DB::q(
				"SELECT COALESCE(SUM(montant_ttc),0) FROM avoirs_fournisseurs WHERE fournisseur_id=? AND statut='valide'",
				array( (int) $fournisseurId )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
	}
}
