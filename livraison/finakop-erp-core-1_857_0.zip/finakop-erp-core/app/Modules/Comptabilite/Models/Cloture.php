<?php
/**
 * Clôtures comptables (mensuelle, trimestrielle, semestrielle, annuelle).
 * Verrouille les périodes et génère l'écriture de résultat à la clôture annuelle.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * CE QUI A CHANGÉ EN 1.778.0, ET POURQUOI
 *
 * 1. LA CLÔTURE N'ÉTAIT PAS TRANSACTIONNELLE.
 *    `create()` enregistrait l'écriture de résultat, PUIS insérait la ligne
 *    de clôture. Entre les deux, tout pouvait échouer : disque plein, verrou
 *    SQLite, coupure. Le dossier se retrouvait alors avec une écriture de
 *    détermination du résultat et AUCUNE clôture — c'est-à-dire des classes
 *    6 et 7 soldées sur un exercice resté ouvert. La clôture relancée
 *    n'ayant plus rien à solder, elle refusait, et l'exercice devenait
 *    inclôturable. Tout passe désormais par FKC_Tx : la clôture existe
 *    entièrement, ou pas du tout.
 *
 * 2. UN SEUL CONTRÔLE GARDAIT LA PORTE.
 *    Les dotations manquantes, et rien d'autre. Une balance déséquilibrée,
 *    des écritures encore au brouillard, un compte d'attente jamais soldé,
 *    une caisse créditrice : tout passait. La porte est désormais tenue par
 *    FKC_ClotureChecklist, dont les contrôles bloquants refusent la clôture
 *    et dont les avertissements demandent une justification.
 *
 * 3. UN CONTRÔLE QUI PLANTAIT LAISSAIT PASSER.
 *    `dotationsManquantes()` rattrapait ses propres exceptions et renvoyait
 *    un tableau VIDE : à la première panne de lecture, le contrôle bloquant
 *    se désactivait en silence et la clôture aboutissait sur un résultat
 *    amputé. Il propage désormais, et la checklist transforme la panne en
 *    anomalie bloquante — on ne clôture pas un exercice dont on ne peut pas
 *    vérifier l'état.
 *
 * 4. LA RÉOUVERTURE ÉTAIT UN BOUTON.
 *    `reopen()` supprimait la clôture et son écriture de résultat, sans
 *    motif, sans trace, sans regarder si l'exercice suivant avait déjà été
 *    ouvert sur ces soldes. Après elle, l'exercice ressemblait à un exercice
 *    jamais clôturé : la manipulation la plus lourde de la comptabilité ne
 *    laissait littéralement aucune trace. Elle est désormais réservée à
 *    l'administrateur, motivée, consignée, refusée si N+1 en dépend, et
 *    impossible sur une clôture rendue définitive.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Cloture {

	public static function types() {
		return array( 'mensuelle' => 'Mensuelle', 'trimestrielle' => 'Trimestrielle', 'semestrielle' => 'Semestrielle', 'annuelle' => 'Annuelle' );
	}

	public static function all() {
		return FKC_DB::q( 'SELECT * FROM clotures ORDER BY periode_fin DESC, id DESC' )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM clotures WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/**
	 * Suppression brute d'une ligne de clôture.
	 *
	 * Conservée pour les traitements techniques (migration, réinitialisation
	 * d'exercice) qui savent ce qu'ils font. La voie utilisateur est
	 * `reopen()`, qui contrôle, motive et consigne — appeler `delete()` depuis
	 * un écran contournerait tout le dispositif.
	 */
	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM clotures WHERE id=?', array( (int) $id ) );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * RÉOUVERTURE CONTRÔLÉE
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * Cette clôture peut-elle être rouverte, et sinon pourquoi ?
	 *
	 * Les motifs de refus sont rendus en clair : un « impossible » sans raison
	 * envoie chercher dans le code, et c'est le genre de message qui finit en
	 * appel au support.
	 *
	 * @return array{bool,string} ( possible, raison du refus )
	 */
	public static function peutRouvrir( $id ) {
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Clôture introuvable.' ); }

		if ( ! empty( $c['definitive'] ) ) {
			return array( false, 'Cette clôture a été rendue DÉFINITIVE le '
				. ( ! empty( $c['verrouille_le'] ) ? date( 'd/m/Y', strtotime( (string) $c['verrouille_le'] ) ) : '' )
				. '. Elle ne se rouvre plus — c\'est précisément ce que le verrou définitif signifie : '
				. 'les états financiers ont été arrêtés et, le cas échéant, déposés. '
				. 'Une correction passe désormais par une écriture de l\'exercice en cours, jamais par une '
				. 'modification rétroactive d\'un exercice déposé.' );
		}

		if ( 'annuelle' !== (string) $c['type'] ) { return array( true, '' ); }

		$annee = self::anneeDe( $c );

		// L'affectation du résultat s'appuie sur le résultat déterminé par
		// cette clôture : la rouvrir ferait varier un montant déjà réparti par
		// une décision d'assemblée.
		if ( class_exists( 'FKC_AffectationResultat' ) && FKC_AffectationResultat::estAffecte( $annee ) ) {
			return array( false, 'Le résultat ' . $annee . ' a été AFFECTÉ : réserves, report à nouveau ou '
				. 'dividendes ont été arrêtés sur ce montant par décision d\'assemblée. Rouvrir l\'exercice le '
				. 'ferait varier sans que la décision suive. Annulez d\'abord l\'affectation '
				. '(Comptabilité → Clôture → Affectation du résultat).' );
		}

		// L'exercice suivant a été ouvert sur ces soldes : les rouvrir
		// désaccorderait l'ouverture de N+1 de la clôture de N, sans que rien
		// ne le signale ensuite.
		if ( class_exists( 'FKC_ANouveaux' ) && FKC_ANouveaux::existent( $annee + 1 ) ) {
			return array( false, 'L\'exercice ' . ( $annee + 1 ) . ' a déjà été ouvert sur les soldes de cette '
				. 'clôture : ses à-nouveaux en découlent directement. Rouvrir ' . $annee . ' rendrait le bilan '
				. 'd\'ouverture de ' . ( $annee + 1 ) . ' faux, et rien ne le signalerait — il resterait équilibré. '
				. 'Annulez d\'abord les à-nouveaux de ' . ( $annee + 1 ) . '.' );
		}

		return array( true, '' );
	}

	/**
	 * Rouvre une période clôturée.
	 *
	 * @param int    $id
	 * @param string $motif Obligatoire, consigné au journal de clôture.
	 * @return array{bool,string}
	 */
	public static function reopen( $id, $motif = '' ) {
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Clôture introuvable.' ); }
		$annee = self::anneeDe( $c );

		if ( ! class_exists( 'FKC_Auth' ) || ! FKC_Auth::isAdmin() ) {
			return self::refus( $annee, 'reouverture', 'Rouvrir une période clôturée est une procédure '
				. 'exceptionnelle réservée à l\'administrateur du dossier.' );
		}

		$motif = trim( (string) $motif );
		if ( mb_strlen( $motif ) < 20 ) {
			return self::refus( $annee, 'reouverture', 'Motif obligatoire. Rouvrir une période clôturée est le '
				. 'geste qu\'un contrôle fiscal regarde en premier : expliquez en une phrase ce qui l\'impose '
				. '(écriture omise, erreur d\'imputation constatée, retraitement demandé par l\'expert-comptable). '
				. 'Ce motif sera conservé et lu.' );
		}

		list( $possible, $raison ) = self::peutRouvrir( $id );
		if ( ! $possible ) { return self::refus( $annee, 'reouverture', $raison ); }

		try {
			return FKC_Tx::executer( function () use ( $c, $id, $annee, $motif ) {
				$eid = ! empty( $c['ecriture_id'] ) ? (int) $c['ecriture_id'] : 0;
				if ( $eid ) {
					/*
					 * L'écriture de détermination du résultat est SUPPRIMÉE, non
					 * contre-passée : elle n'est pas une opération économique mais
					 * un solde technique, et sa contre-passation laisserait deux
					 * écritures qui s'annulent sur des comptes de gestion qu'on
					 * cherche justement à rouvrir. Les lignes sont retirées
					 * explicitement, les clés étrangères de SQLite n'étant actives
					 * que si PRAGMA foreign_keys est posé.
					 */
					FKC_DB::q( 'DELETE FROM ecriture_lignes WHERE ecriture_id=?', array( $eid ) );
					FKC_DB::q( 'DELETE FROM ecritures WHERE id=?', array( $eid ) );
				}
				FKC_DB::q( 'DELETE FROM clotures WHERE id=?', array( (int) $id ) );

				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $annee, 'reouverture', array(
						'issue'   => 'avertissement',
						'libelle' => 'Réouverture de « ' . $c['libelle'] .' » ('
							. date( 'd/m/Y', strtotime( (string) $c['periode_debut'] ) ) . ' → '
							. date( 'd/m/Y', strtotime( (string) $c['periode_fin'] ) ) . ')',
						'motif'   => $motif,
						'montant' => isset( $c['resultat'] ) ? (float) $c['resultat'] : null,
						'ecriture_id' => $eid ?: null,
						'detail'  => array( 'type' => $c['type'], 'cloturee_le' => $c['date_cloture'] ),
					) );
				}

				return array( true, '« ' . $c['libelle'] . ' » rouverte. Les écritures de la période redeviennent '
					. 'modifiables' . ( $eid ? ', et l\'écriture de détermination du résultat a été retirée' : '' )
					. '. La réouverture et son motif sont consignés au journal de clôture.' );
			} );
		} catch ( \Throwable $e ) {
			return self::refus( $annee, 'reouverture', 'Réouverture impossible : ' . $e->getMessage() );
		}
	}

	/**
	 * Rend une clôture DÉFINITIVE — le point de non-retour.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * POURQUOI CE VERROU EST SÉPARÉ DE LA CLÔTURE
	 *
	 * Clôturer et arrêter définitivement ne se font pas au même moment. On
	 * clôture pour produire les états financiers ; on arrête définitivement
	 * APRÈS que l'assemblée les a approuvés et que la liasse est déposée à la
	 * DGI. Entre les deux, il est normal — et fréquent — de rouvrir pour un
	 * retraitement demandé par l'expert-comptable.
	 *
	 * Confondre les deux gestes obligerait à choisir entre un exercice
	 * indéfiniment modifiable (ce qu'était FinaKop) et un exercice figé trop
	 * tôt (ce qui rendrait le logiciel inutilisable en pratique).
	 *
	 * @return array{bool,string}
	 */
	public static function verrouiller( $id, $note = '' ) {
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Clôture introuvable.' ); }
		if ( ! empty( $c['definitive'] ) ) { return array( false, 'Cette clôture est déjà définitive.' ); }
		if ( ! class_exists( 'FKC_Auth' ) || ! FKC_Auth::isAdmin() ) {
			return array( false, 'Le verrouillage définitif est réservé à l\'administrateur du dossier.' );
		}

		$annee = self::anneeDe( $c );
		$nom   = '';
		try {
			$u = FKC_Auth::user();
			if ( is_array( $u ) ) { $nom = (string) ( $u['nom'] ?? $u['login'] ?? $u['email'] ?? '' ); }
		} catch ( \Throwable $e ) { $nom = ''; }

		try {
			FKC_DB::q(
				"UPDATE clotures SET definitive=1, verrouille_le=datetime('now','localtime'),
					cloture_par=COALESCE(cloture_par,?), cloture_nom=CASE WHEN COALESCE(cloture_nom,'')='' THEN ? ELSE cloture_nom END
				 WHERE id=?",
				array( FKC_Auth::id(), mb_substr( $nom, 0, 120 ), (int) $id )
			);
		} catch ( \Throwable $e ) {
			return array( false, 'Verrouillage non enregistré : ' . $e->getMessage() );
		}

		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'verrouillage', array(
				'libelle' => 'Clôture « ' . $c['libelle'] . ' » rendue définitive',
				'motif'   => (string) $note,
				'montant' => isset( $c['resultat'] ) ? (float) $c['resultat'] : null,
			) );
		}
		return array( true, '« ' . $c['libelle'] . ' » est désormais DÉFINITIVE : elle ne pourra plus être rouverte, '
			. 'par personne. Toute correction ultérieure devra passer par une écriture de l\'exercice en cours.' );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * VERROUS DE PÉRIODE (lecture)
	 * ══════════════════════════════════════════════════════════════════════ */

	/** La date tombe-t-elle dans une période clôturée ? */
	public static function isLocked( $date ) {
		$r = FKC_DB::q( 'SELECT 1 FROM clotures WHERE ? BETWEEN periode_debut AND periode_fin LIMIT 1', array( $date ) )->fetch();
		return (bool) $r;
	}

	/**
	 * LA CLÔTURE QUI BLOQUE CETTE DATE — pour pouvoir la NOMMER (1.723.0).
	 *
	 * « Période clôturée » ne disait pas laquelle. L'utilisateur qui vient
	 * d'ouvrir son exercice N-1 dans Paramètres → Exercices en conclut que
	 * l'application lui refuse l'exercice, alors qu'elle lui refuse un MOIS
	 * — souvent clôturé au fil de l'eau des mois plus tôt, et oublié.
	 *
	 * Ouvrir un exercice et clôturer une période sont deux gestes
	 * indépendants, sur deux écrans différents : l'un n'annule pas l'autre,
	 * et c'est voulu. Encore faut-il que le refus le dise.
	 *
	 * @return array|null La clôture bloquante, ou null.
	 */
	public static function blocage( $date ) {
		try {
			$r = FKC_DB::q(
				'SELECT * FROM clotures WHERE ? BETWEEN periode_debut AND periode_fin ORDER BY periode_debut DESC LIMIT 1',
				array( $date )
			)->fetch();
			return $r ?: null;
		} catch ( \Throwable $e ) { return null; }
	}

	/** Phrase de refus nommant la clôture en cause et le geste qui la lève. */
	public static function motifBlocage( $date ) {
		$c = self::blocage( $date );
		if ( ! $c ) { return ''; }
		$types = self::types();
		$t = $types[ (string) ( $c['type'] ?? '' ) ] ?? 'Clôture';
		$msg = 'Clôture ' . strtolower( $t ) . ' du '
			. date( 'd/m/Y', strtotime( (string) $c['periode_debut'] ) ) . ' au '
			. date( 'd/m/Y', strtotime( (string) $c['periode_fin'] ) )
			. ' : la date du ' . date( 'd/m/Y', strtotime( (string) $date ) ) . ' y tombe, aucune écriture ne peut y être ajoutée. ';
		if ( ! empty( $c['definitive'] ) ) {
			return $msg . 'Cette clôture est DÉFINITIVE : elle ne se rouvre pas. '
				. 'Passez la correction sur l\'exercice en cours, ou datez l\'écriture hors de cette période.';
		}
		return $msg . 'Ouvrir l\'exercice ne lève pas cette clôture — ce sont deux gestes distincts : '
			. 'rouvrez la période depuis Comptabilité → Clôture, ou datez l\'écriture hors de cette période.';
	}

	/**
	 * L'EXERCICE couvrant cette date est-il clos ?
	 *
	 * VERROUILLER UNE PÉRIODE ET CLORE UN EXERCICE NE SONT PAS LA MÊME CHOSE
	 *
	 * Le code confondait les deux, et cette confusion rendait un exercice
	 * DÉFINITIVEMENT inclôturable dès qu'on avait travaillé proprement :
	 *
	 *   1. on clôture décembre au fil de l'eau (clôture mensuelle) ;
	 *   2. on veut clôturer l'exercice — son écriture de détermination du
	 *      résultat est datée du 31/12 ;
	 *   3. le 31/12 appartient à décembre, décembre est verrouillé, donc
	 *      FKC_Ecriture::prepare() refuse. La clôture annuelle échoue.
	 *
	 * Même impasse pour la dotation d'amortissement, toujours datée du 31/12.
	 * Autrement dit : le geste comptable le plus normal du monde — arrêter
	 * ses mois, puis arrêter son année — ne pouvait pas aboutir.
	 *
	 * La sortie n'est pas de percer le verrou, c'est de reconnaître que les
	 * DOTATIONS et la DÉTERMINATION DU RÉSULTAT sont des écritures
	 * d'inventaire : elles sont par nature postérieures aux mois qu'elles
	 * concernent, et c'est la clôture de l'EXERCICE — pas celle d'un mois —
	 * qui doit les arrêter. Une fois le résultat déterminé, plus rien ne
	 * passe : ajouter une charge après coup fausserait un résultat déjà arrêté.
	 *
	 * @param string $date Date au format AAAA-MM-JJ.
	 * @return bool
	 */
	public static function isExerciceClos( $date ) {
		try {
			$r = FKC_DB::q(
				"SELECT 1 FROM clotures WHERE type='annuelle' AND ? BETWEEN periode_debut AND periode_fin LIMIT 1",
				array( $date )
			)->fetch();
			return (bool) $r;
		} catch ( \Throwable $e ) {
			/*
			 * Le repli reste « non clos », et c'est délibéré : si la base ne
			 * répond plus, tout FinaKop est à l'arrêt, et bloquer en plus
			 * toute saisie n'aiderait personne. Mais la panne est JOURNALISÉE
			 * — l'ancienne version l'avalait en silence, et un verrou qui se
			 * désactive sans le dire est pire qu'un verrou absent.
			 */
			if ( function_exists( 'fkc_log' ) ) {
				fkc_log( 'FKC_Cloture::isExerciceClos — lecture impossible : ' . $e->getMessage(), 'ERROR' );
			}
			return false;
		}
	}

	/** La clôture annuelle d'un exercice, ou null. */
	public static function annuelleDe( $annee ) {
		try {
			list( $d, $f ) = self::bornesExercice( $annee );
			$r = FKC_DB::q(
				"SELECT * FROM clotures WHERE type='annuelle' AND periode_debut=? AND periode_fin=?",
				array( $d, $f )
			)->fetch();
			return $r ?: null;
		} catch ( \Throwable $e ) { return null; }
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * CONTRÔLES
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * Immobilisations dont la dotation de l'exercice n'est pas comptabilisée.
	 *
	 * Appelé AVANT la clôture annuelle. Sans ce contrôle, un dossier se
	 * clôturait sur un résultat amputé de ses amortissements — et, l'exercice
	 * étant dès lors clos, la dotation manquante ne pouvait PLUS être passée :
	 * une erreur définitive, produite en silence par un écran qui annonçait
	 * une réussite.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * LA MÉTHODE PROPAGE DÉSORMAIS SES PANNES (1.778.0).
	 *
	 * Elle rattrapait ses exceptions et renvoyait un tableau VIDE : à la
	 * première erreur de lecture, le contrôle bloquant se taisait et la
	 * clôture passait sur un résultat faux. Un contrôle qui ne peut pas
	 * répondre ne doit jamais répondre « rien à signaler ». L'appelant
	 * (FKC_ClotureChecklist) transforme l'exception en anomalie bloquante.
	 *
	 * @param int $annee Exercice concerné.
	 * @return array libellés des immobilisations concernées.
	 * @throws \Throwable si l'état des immobilisations est illisible.
	 */
	public static function dotationsManquantes( $annee ) {
		if ( ! class_exists( 'FKC_Immobilisation' ) ) { return array(); }
		$manque = array();
		foreach ( FKC_Immobilisation::all() as $immo ) {
			// Annulée depuis la 1.761.0 : aucune dotation n'est attendue.
			if ( in_array( (string) ( $immo['statut'] ?? '' ), array( 'cede', 'annulee' ), true ) ) { continue; }
			/*
			 * « Comptabilisée » et non « existe » (1.542.0).
			 *
			 * Depuis que la dotation passe par le contrôle avant
			 * comptabilisation, sa ligne de suivi peut exister alors que
			 * l'écriture attend encore. Une dotation EN ATTENTE n'a rien
			 * changé au résultat : la compter comme faite arrêterait
			 * l'exercice sur un résultat amputé, et la dotation en
			 * attente ne pourrait plus être validée ensuite. On la
			 * signale donc, en disant qu'il s'agit d'une validation à
			 * faire et non d'une dotation à créer — ce n'est pas le même
			 * geste, et envoyer quelqu'un créer un doublon serait pire
			 * que de ne rien dire.
			 */
			$due = 0.0;
			foreach ( FKC_Immobilisation::plan( $immo ) as $r ) {
				if ( (int) $r['exercice'] === (int) $annee ) { $due = (float) $r['dotation']; break; }
			}
			if ( $due <= 0 ) { continue; }
			/*
			 * LE MONTANT, PAS LA PRÉSENCE (1.855.0).
			 *
			 * Le contrôle demandait « une dotation existe-t-elle ? ». En
			 * amortissement mensuel, la première mensualité suffisait donc à
			 * tenir l'exercice pour servi : on clôturait avec un mois
			 * d'amortissement sur douze, et l'erreur devenait définitive. On
			 * compare désormais ce qui est COMPTABILISÉ à ce que le plan doit.
			 */
			$fait = 0.0; $attente = 0.0;
			try {
				foreach ( FKC_DB::q( 'SELECT montant, ecriture_id FROM immo_dotations WHERE immobilisation_id=? AND exercice=?',
					array( (int) $immo['id'], (int) $annee ) )->fetchAll() as $d ) {
					if ( empty( $d['ecriture_id'] ) ) { $attente += (float) $d['montant']; } else { $fait += (float) $d['montant']; }
				}
			} catch ( \Throwable $e ) { throw $e; }
			if ( $fait >= $due - 1 ) { continue; }
			if ( $fait + $attente >= $due - 1 ) {
				$manque[] = (string) $immo['libelle'] . ' (au journal temporaire, à valider)';
				continue;
			}
			$manque[] = (string) $immo['libelle'] . ( $fait > 0
				? ' (' . fkc_money( $due - $fait - $attente ) . ' F CFA restant à doter sur ' . fkc_money( $due ) . ')'
				: '' ) . ( $attente > 0 ? ' — dont une part au journal temporaire' : '' );
		}
		return $manque;
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * BORNES DE PÉRIODE
	 * ══════════════════════════════════════════════════════════════════════ */

	/** Bornes d'une période. $sub = mois (1-12) / trimestre (1-4) / semestre (1-2). */
	public static function bornes( $type, $annee, $sub ) {
		$annee = (int) $annee; $sub = max( 1, (int) $sub );
		switch ( $type ) {
			case 'mensuelle':
				$m = min( 12, $sub );
				$deb = sprintf( '%04d-%02d-01', $annee, $m );
				$fin = date( 'Y-m-t', strtotime( $deb ) );
				return array( $deb, $fin, 'Clôture mensuelle ' . date( 'm/Y', strtotime( $deb ) ) );
			/*
			 * Trimestres et semestres se comptent DEPUIS L'OUVERTURE DE
			 * L'EXERCICE, pas depuis janvier (1.544.0). Pour un exercice
			 * ouvert le 1er juillet, « T1 » va de juillet à septembre : c'est
			 * ce que veut dire le premier trimestre d'un dossier, et c'est ce
			 * que ses états intermédiaires doivent couvrir. Compter en
			 * trimestres civils ferait chevaucher T3 sur deux exercices.
			 *
			 * Sur un exercice calendaire, le calcul redonne exactement les
			 * trimestres civils : aucun dossier existant ne change.
			 */
			case 'trimestrielle':
				$t   = min( 4, max( 1, (int) $sub ) );
				$deb = self::moisExercice( $annee, ( $t - 1 ) * 3 );
				$fin = self::finPeriode( $deb, 3 );
				return array( $deb, $fin, 'Clôture T' . $t . ' ' . self::libelleExercice( $annee ) );
			case 'semestrielle':
				$sm  = min( 2, max( 1, (int) $sub ) );
				$deb = self::moisExercice( $annee, ( $sm - 1 ) * 6 );
				$fin = self::finPeriode( $deb, 6 );
				return array( $deb, $fin, 'Clôture S' . $sm . ' ' . self::libelleExercice( $annee ) );
			default: // annuelle
				list( $deb, $fin ) = self::bornesExercice( $annee );
				return array( $deb, $fin, 'Clôture annuelle ' . self::libelleExercice( $annee ) );
		}
	}

	/**
	 * Bornes de l'exercice — déléguées à FKC_Exercice, avec repli calendaire.
	 *
	 * Le repli n'est pas décoratif : ce modèle est chargé par des harnais et
	 * des traitements qui n'ouvrent pas forcément le module Paramètres. Sans
	 * lui, un exercice décalé ferait mieux que planter — il retomberait en
	 * silence sur l'année civile, ce qui est exactement le défaut corrigé.
	 * Le repli n'a donc lieu que si la classe est absente, jamais si elle
	 * répond autre chose que l'année civile.
	 */
	protected static function bornesExercice( $annee ) {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'bornes' ) ) {
			return FKC_Exercice::bornes( (int) $annee );
		}
		return array( sprintf( '%04d-01-01', (int) $annee ), sprintf( '%04d-12-31', (int) $annee ) );
	}

	protected static function libelleExercice( $annee ) {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'libelle' ) ) {
			return FKC_Exercice::libelle( (int) $annee );
		}
		return (string) (int) $annee;
	}

	/** Premier jour du (n+1)-ième mois de l'exercice $annee. */
	protected static function moisExercice( $annee, $decalage ) {
		list( $deb ) = self::bornesExercice( $annee );
		return date( 'Y-m-01', strtotime( $deb . ' +' . (int) $decalage . ' month' ) );
	}

	/** Dernier jour de la période de $nbMois commençant à $debut. */
	protected static function finPeriode( $debut, $nbMois ) {
		return date( 'Y-m-d', strtotime( $debut . ' +' . (int) $nbMois . ' month -1 day' ) );
	}

	public static function existsFor( $debut, $fin ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM clotures WHERE periode_debut=? AND periode_fin=?', array( $debut, $fin ) )->fetch();
	}

	/** Millésime de l'exercice auquel se rattache une ligne de clôture. */
	public static function anneeDe( array $c ) {
		if ( class_exists( 'FKC_Exercice' ) ) {
			return (int) FKC_Exercice::annee( (string) $c['periode_fin'] );
		}
		return (int) substr( (string) $c['periode_fin'], 0, 4 );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * CLÔTURE
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * Crée une clôture pour une période.
	 *
	 * Pour l'annuelle : passe les contrôles bloquants, détermine le résultat
	 * si ce n'est pas déjà fait, et verrouille — le tout dans une seule
	 * transaction.
	 *
	 * @param string $type
	 * @param int    $annee
	 * @param int    $sub
	 * @param array  $opts note (string)
	 * @return array{bool,string} ( ok, message )
	 */
	public static function create( $type, $annee, $sub, array $opts = array() ) {
		$annee = (int) $annee;
		list( $deb, $fin, $lib ) = self::bornes( $type, $annee, $sub );
		if ( self::existsFor( $deb, $fin ) ) { return array( false, 'Cette période est déjà clôturée.' ); }

		if ( 'annuelle' !== $type ) { return self::cloturerPeriode( $type, $annee, $deb, $fin, $lib, $opts ); }
		return self::cloturerExercice( $annee, $deb, $fin, $lib, $opts );
	}

	/**
	 * Clôture infra-annuelle : un verrou de période, sans écriture.
	 *
	 * On ne lui applique pas la checklist complète, et c'est voulu : une
	 * clôture mensuelle est un geste d'hygiène courant — « je ne veux plus
	 * qu'on touche à janvier » — et l'assortir des dix-sept contrôles de
	 * l'arrêté annuel la rendrait impraticable. Seul l'équilibre de la période
	 * est vérifié, parce qu'un mois déséquilibré est une corruption, pas un
	 * choix de gestion.
	 */
	protected static function cloturerPeriode( $type, $annee, $deb, $fin, $lib, array $opts = array() ) {
		try {
			$r = FKC_DB::q(
				'SELECT COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) c
				 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id
				 WHERE e.date_ecriture BETWEEN ? AND ?', array( $deb, $fin )
			)->fetch();
			$ecart = round( (float) $r['d'] - (float) $r['c'], 2 );
		} catch ( \Throwable $e ) {
			return self::refus( $annee, 'cloture', 'Équilibre de la période illisible : ' . $e->getMessage()
				. '. La clôture est refusée — on ne verrouille pas une période dont on ne peut pas vérifier l\'état.' );
		}
		if ( abs( $ecart ) > 1.0 ) {
			return self::refus( $annee, 'cloture', 'Clôture refusée : la période du '
				. date( 'd/m/Y', strtotime( $deb ) ) . ' au ' . date( 'd/m/Y', strtotime( $fin ) )
				. ' est déséquilibrée de ' . fkc_money( $ecart ) . ' F CFA. Verrouiller maintenant figerait '
				. 'l\'anomalie : elle ne pourrait plus être corrigée sans rouvrir.' );
		}

		try {
			FKC_Tx::executer( function () use ( $type, $deb, $fin, $lib ) {
				self::inserer( $type, $deb, $fin, $lib, null, null );
			} );
		} catch ( \Throwable $e ) {
			return self::refus( $annee, 'cloture', 'Clôture non enregistrée : ' . $e->getMessage() );
		}

		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'cloture', array(
				'libelle' => $lib . ' (' . date( 'd/m/Y', strtotime( $deb ) ) . ' → ' . date( 'd/m/Y', strtotime( $fin ) ) . ')',
				'motif'   => (string) ( $opts['note'] ?? '' ),
			) );
		}
		return array( true, $lib . ' enregistrée. Période verrouillée.' );
	}

	/**
	 * Clôture annuelle : contrôles, détermination du résultat, verrou.
	 */
	protected static function cloturerExercice( $annee, $deb, $fin, $lib, array $opts = array() ) {

		/* ── 1. Les contrôles bloquants ──────────────────────────────────── */

		if ( class_exists( 'FKC_ClotureChecklist' ) ) {
			$s = FKC_ClotureChecklist::synthese( $annee, 'cloture' );
			if ( (int) $s['bloquants'] > 0 ) {
				$liste = implode( ' · ', array_slice( $s['libelles_bloquants'], 0, 6 ) );
				if ( count( $s['libelles_bloquants'] ) > 6 ) { $liste .= ' …'; }
				return self::refus( $annee, 'cloture',
					'Clôture refusée : ' . $s['bloquants'] . ' contrôle(s) bloquant(s) en anomalie — ' . $liste . '. '
					. 'Corrigez-les depuis Comptabilité → Clôture ; après la clôture, l\'exercice serait verrouillé '
					. 'et ces corrections ne seraient plus possibles.'
					. ( $s['pannes'] > 0 ? ' (' . $s['pannes'] . ' contrôle(s) n\'ont pas pu être évalués : '
						. 'un exercice dont on ne peut pas vérifier l\'état ne se clôture pas.)' : '' ) );
			}
		}

		/* ── 2. Détermination du résultat + verrou, en une transaction ────── */

		try {
			$res = FKC_Tx::executer( function () use ( $annee, $deb, $fin, $lib ) {
				// Unicité revérifiée DANS la transaction : la vérifier avant de
				// l'ouvrir laisserait passer deux clôtures simultanées.
				if ( self::existsFor( $deb, $fin ) ) {
					throw new \RuntimeException( 'Cette période vient d\'être clôturée par ailleurs.' );
				}
				list( $ok, $msg, $resultat, $eid ) = self::determinerResultatInterne( $deb, $fin, $annee );
				if ( ! $ok ) { throw new \RuntimeException( $msg ); }
				self::inserer( 'annuelle', $deb, $fin, $lib, $resultat, $eid );
				return array( $resultat, $eid, $msg );
			} );
		} catch ( \Throwable $e ) {
			return self::refus( $annee, 'cloture', $e->getMessage() );
		}

		list( $resultat, $eid, $note ) = $res;

		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'cloture', array(
				'libelle' => $lib . ' — résultat net ' . fkc_money( $resultat ) . ' F CFA ('
					. ( $resultat >= 0 ? 'bénéfice' : 'perte' ) . ')',
				'motif'   => (string) ( $opts['note'] ?? '' ),
				'montant' => (float) $resultat,
				'ecriture_id' => $eid ? (int) $eid : null,
				'detail'  => array( 'debut' => $deb, 'fin' => $fin, 'note' => $note ),
			) );
		}

		return array( true, $lib . ' enregistrée. Période verrouillée. Résultat net : '
			. fkc_money( $resultat ) . ' FCFA (' . ( $resultat >= 0 ? 'bénéfice' : 'perte' ) . '). '
			. 'Prochaine étape : l\'affectation du résultat, puis l\'ouverture de ' . ( $annee + 1 ) . '.' );
	}

	/**
	 * Détermine le résultat SANS clôturer — étape 4 du processus.
	 *
	 * Séparer les deux gestes permet de vérifier le résultat, de sortir un
	 * compte de résultat, et seulement ensuite de verrouiller. L'ancienne
	 * version les soudait : on ne découvrait le résultat qu'une fois
	 * l'exercice déjà fermé dessus.
	 *
	 * @return array{bool,string,float|null,int|null}
	 */
	public static function determinerResultat( $annee ) {
		$annee = (int) $annee;
		list( $deb, $fin ) = self::bornesExercice( $annee );
		if ( self::existsFor( $deb, $fin ) ) {
			return array( false, 'L\'exercice ' . $annee . ' est déjà clôturé : son résultat est arrêté.', null, null );
		}
		try {
			$r = FKC_Tx::executer( function () use ( $deb, $fin, $annee ) {
				list( $ok, $msg, $resultat, $eid ) = self::determinerResultatInterne( $deb, $fin, $annee );
				if ( ! $ok ) { throw new \RuntimeException( $msg ); }
				return array( $msg, $resultat, $eid );
			} );
		} catch ( \Throwable $e ) {
			return array( false, $e->getMessage(), null, null );
		}
		list( $msg, $resultat, $eid ) = $r;

		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'resultat', array(
				'libelle' => 'Détermination du résultat ' . $annee . ' : ' . fkc_money( $resultat ) . ' F CFA',
				'montant' => (float) $resultat, 'ecriture_id' => $eid ? (int) $eid : null,
			) );
		}
		return array( true, $msg, $resultat, $eid );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * ÉCRITURE DE RÉSULTAT
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * Compte destinataire du résultat de l'exercice.
	 *
	 * BUG CORRIGÉ (1.538.0) — LA CLÔTURE ANNUELLE NE POUVAIT PAS ABOUTIR.
	 *
	 * L'ancienne version visait `byNumero('130')`, qui résout 130000
	 * « Résultat en instance d'affectation ». Deux erreurs en une :
	 *
	 *   — 130000 porte les subdivisions 130100/130900 : c'est donc un POSTE
	 *     D'AGRÉGATION, et FKC_Ecriture::prepare() refuse — à juste titre —
	 *     d'y imputer quoi que ce soit. La clôture échouait sur un message
	 *     parlant de plan comptable, que rien ne reliait à la clôture ;
	 *   — le compte n'était pas le bon. En SYSCOHADA, la détermination du
	 *     résultat solde les classes 6 et 7 vers 131 (bénéfice) ou 139
	 *     (perte). 130 ne reçoit le résultat qu'ENSUITE, quand l'assemblée
	 *     décide de son affectation — deux gestes distincts, à deux moments
	 *     distincts, que le code confondait.
	 *
	 * On refuse toujours d'imputer sur un poste d'agrégation : si le compte
	 * canonique porte des subdivisions dans CE dossier, on descend sur la
	 * première imputable plutôt que d'échouer.
	 *
	 * @param bool $benefice
	 * @return array{array|null, string} ( compte, message d'erreur )
	 */
	protected static function compteResultat( $benefice ) {
		$num = $benefice ? '131' : '139';
		$lib = $benefice ? 'Résultat net : bénéfice' : 'Résultat net : perte';
		$c   = FKC_Compte::byNumero( $num );
		if ( ! $c ) {
			return array( null, 'Compte ' . $num . ' (' . $lib . ') introuvable au plan comptable : '
				. 'la détermination du résultat ne peut pas être enregistrée.' );
		}
		if ( 'titre' !== (string) ( $c['type'] ?? '' ) ) { return array( $c, '' ); }

		// Le compte a été subdivisé dans ce dossier : on vise une subdivision réelle.
		try {
			$sub = FKC_DB::q(
				"SELECT * FROM comptes WHERE numero LIKE ? AND numero <> ? AND type <> 'titre' AND actif = 1
				 ORDER BY numero LIMIT 1",
				array( rtrim( (string) $c['numero'], '0' ) . '%', (string) $c['numero'] )
			)->fetch();
		} catch ( \Throwable $e ) { $sub = null; }
		if ( $sub ) { return array( $sub, '' ); }

		return array( null, 'Le compte ' . $c['numero'] . ' « ' . $c['libelle'] . ' » est un poste d\'agrégation '
			. 'et n\'a aucune subdivision imputable : ouvrez-en une avant de clôturer l\'exercice.' );
	}

	/**
	 * Génère l'écriture de détermination du résultat sur la période.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * LA CLASSE 8 N'ÉTAIT SOLDÉE PAR PERSONNE (corrigé 1.558.0).
	 *
	 * Le résultat se calculait sur les seules classes 6 et 7. Or la cession
	 * d'une immobilisation s'impute en 81 (valeur comptable de sortie) et 82
	 * (prix de cession) — le module Immobilisations le fait déjà —, et
	 * l'impôt sur le bénéfice en 89. Deux conséquences, toutes deux graves :
	 *
	 *   — la plus-value de cession n'entrait dans AUCUN résultat : une
	 *     entreprise pouvait vendre son parc automobile sans que le compte
	 *     de résultat en porte la trace ;
	 *   — ces comptes n'étant jamais soldés, leurs soldes SURVIVAIENT à la
	 *     clôture et s'accumulaient d'un exercice à l'autre, au bilan, sur
	 *     des comptes de gestion qui n'y ont rien à faire.
	 *
	 * La règle est désormais unique et ne dépend plus de la classe : tout
	 * compte de gestion est soldé par son propre sens, et sa contribution au
	 * résultat est son solde créditeur net. Pour les classes 6 et 7, cette
	 * règle redonne EXACTEMENT le calcul précédent — un produit a un solde
	 * créditeur, une charge un solde débiteur. Elle traite en plus, sans
	 * exception à écrire, le hors activités ordinaires et l'impôt : le
	 * résultat obtenu est bien le résultat NET, après impôt.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * LE RÉSULTAT DÉJÀ DÉTERMINÉ N'EST PLUS UN ÉCHEC (1.778.0).
	 *
	 * Quand les comptes de gestion étaient déjà soldés — résultat déterminé à
	 * l'étape précédente du processus, ou écriture passée à la main — la
	 * méthode renvoyait « Aucun mouvement de charges/produits sur la période :
	 * rien à clôturer », et la clôture échouait. Le message était doublement
	 * trompeur : il y avait eu des mouvements, et il n'y avait rien à
	 * reprocher. On reconnaît désormais ce cas, on lit le résultat sur
	 * 131/139, et la clôture se contente de verrouiller.
	 *
	 * @return array{bool,string,float|null,int|null}
	 */
	protected static function determinerResultatInterne( $deb, $fin, $annee ) {
		$rows = FKC_DB::q(
			"SELECT c.id, c.classe, COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) cr
			 FROM comptes c JOIN ecriture_lignes l ON l.compte_id=c.id JOIN ecritures e ON e.id=l.ecriture_id
			 WHERE e.date_ecriture BETWEEN ? AND ? AND c.classe IN (6,7,8)
			 GROUP BY c.id",
			array( $deb, $fin )
		)->fetchAll();

		$lignes = array(); $produits = 0.0; $charges = 0.0; $mouvements = false;
		foreach ( $rows as $r ) {
			$mouvements = true;
			$solde = (float) $r['d'] - (float) $r['cr'];
			if ( abs( $solde ) < 0.005 ) { continue; }
			if ( $solde < 0 ) { // solde créditeur (produit, ou 8x créditeur) : débiter pour solder
				$produits += -$solde;
				$lignes[] = array( 'compte_id' => (int) $r['id'], 'libelle' => 'Solde de résultat', 'debit' => -$solde, 'credit' => 0 );
			} else { // solde débiteur (charge, ou 8x débiteur) : créditer pour solder
				$charges += $solde;
				$lignes[] = array( 'compte_id' => (int) $r['id'], 'libelle' => 'Solde de résultat', 'debit' => 0, 'credit' => $solde );
			}
		}

		if ( ! $lignes ) {
			if ( ! $mouvements ) {
				return array( false, 'Aucun mouvement de charges ni de produits sur l\'exercice ' . $annee . ' : '
					. 'il n\'y a pas de résultat à déterminer. Si l\'exercice a réellement eu de l\'activité, '
					. 'vérifiez les dates de vos écritures — elles tombent peut-être hors des bornes de l\'exercice ('
					. date( 'd/m/Y', strtotime( $deb ) ) . ' → ' . date( 'd/m/Y', strtotime( $fin ) ) . ').', null, null );
			}
			// Comptes de gestion déjà soldés : le résultat est déterminé.
			$resultat = class_exists( 'FKC_ClotureProcessus' ) ? FKC_ClotureProcessus::resultatNet( $annee ) : 0.0;
			return array( true, 'Le résultat de l\'exercice ' . $annee . ' était déjà déterminé : les classes 6, 7 et 8 '
				. 'sont soldées. Aucune nouvelle écriture n\'a été produite.', $resultat, null );
		}

		$resultat = $produits - $charges; // > 0 = bénéfice
		list( $cRes, $err ) = self::compteResultat( $resultat >= 0 );
		if ( ! $cRes ) { return array( false, $err, null, null ); }
		if ( $resultat >= 0 ) {
			$lignes[] = array( 'compte_id' => (int) $cRes['id'], 'libelle' => 'Résultat net (bénéfice)', 'debit' => 0, 'credit' => $resultat );
		} else {
			$lignes[] = array( 'compte_id' => (int) $cRes['id'], 'libelle' => 'Résultat net (perte)', 'debit' => -$resultat, 'credit' => 0 );
		}

		$jod = 0;
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { $jod = (int) $j['id']; } }
		if ( ! $jod ) {
			return array( false, 'Journal OD (opérations diverses) introuvable : l\'écriture de détermination du '
				. 'résultat n\'a nulle part où aller.', null, null );
		}

		list( $ok, $msg, $eid ) = FKC_Ecriture::save(
			array(
				'journal_id' => $jod, 'date_ecriture' => $fin,
				'libelle' => 'Détermination du résultat ' . $annee, 'created_by' => FKC_Auth::id(),
				'reference' => 'RES-' . (int) $annee,
				'source' => 'cloture', 'origine' => 'resultat', 'fait' => 'determination_resultat',
				// Écriture d'inventaire : c'est la clôture elle-même qui
				// l'émet, au dernier jour d'un exercice dont les mois sont
				// normalement déjà verrouillés. Voir prepare().
				'inventaire' => true,
			),
			$lignes
		);
		if ( ! $ok ) { return array( false, 'Détermination du résultat refusée : ' . $msg, null, null ); }
		return array( true, 'Résultat déterminé : ' . fkc_money( $resultat ) . ' F CFA.', $resultat, $eid );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * INTERNE
	 * ══════════════════════════════════════════════════════════════════════ */

	/** Insère la ligne de clôture, avec son auteur. */
	protected static function inserer( $type, $deb, $fin, $lib, $resultat, $eid ) {
		$uid = null; $nom = '';
		try {
			if ( class_exists( 'FKC_Auth' ) ) {
				$uid = FKC_Auth::id();
				$u = FKC_Auth::user();
				if ( is_array( $u ) ) { $nom = (string) ( $u['nom'] ?? $u['login'] ?? $u['email'] ?? '' ); }
			}
		} catch ( \Throwable $e ) { /* hors session */ }

		// Les colonnes d'auteur n'existent que depuis le schéma 26 : on les
		// utilise si elles sont là, sans quoi l'insertion échouerait sur les
		// bases dont la migration n'a pas encore tourné.
		$avecAuteur = false;
		try {
			foreach ( FKC_DB::conn()->query( 'PRAGMA table_info(clotures)' ) as $col ) {
				if ( 'cloture_par' === ( $col['name'] ?? '' ) ) { $avecAuteur = true; break; }
			}
		} catch ( \Throwable $e ) { $avecAuteur = false; }

		if ( $avecAuteur ) {
			FKC_DB::q(
				'INSERT INTO clotures(type,periode_debut,periode_fin,libelle,resultat,ecriture_id,cloture_par,cloture_nom) VALUES(?,?,?,?,?,?,?,?)',
				array( $type, $deb, $fin, $lib, $resultat, $eid, $uid, mb_substr( $nom, 0, 120 ) )
			);
			return;
		}
		FKC_DB::q(
			'INSERT INTO clotures(type,periode_debut,periode_fin,libelle,resultat,ecriture_id) VALUES(?,?,?,?,?,?)',
			array( $type, $deb, $fin, $lib, $resultat, $eid )
		);
	}

	/** Consigne un refus au journal de clôture et le rend à l'appelant. */
	protected static function refus( $annee, $operation, $message ) {
		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracerRefus( (int) $annee, $operation, $message );
		}
		return array( false, $message );
	}
}
