<?php
/**
 * LIGNES DE DÉTAIL D'UN MOUVEMENT DE TRÉSORERIE (1.754.0).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CE QUI MANQUAIT
 *
 * Un encaissement ou un décaissement saisi depuis « Trésorerie · Mouvement »
 * n'avait qu'UN montant, UN libellé et UNE contrepartie. Or la caisse d'une
 * journée n'est presque jamais d'un seul tenant : une recette de prestation,
 * un remboursement, une vente d'accessoire. Il fallait donc saisir trois
 * mouvements — ou un seul, avec un libellé fourre-tout et une contrepartie
 * choisie au jugé, qui fausse le grand livre de tout ce qui n'entre pas dans
 * cette case.
 *
 * Une ligne de détail porte une DÉSIGNATION, un MONTANT et, facultativement,
 * SA PROPRE contrepartie. L'écriture est ventilée en conséquence : un seul
 * mouvement de trésorerie en face, autant de lignes de produit ou de charge
 * que nécessaire.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * CE QUI N'EST PAS FAIT
 *
 * Le détail ne se modifie pas après coup : l'écriture est partie au journal.
 * La correction passe par l'annulation puis la reprise du mouvement, comme
 * pour tout le reste de la comptabilité (voir FKC_Reglement::annuler).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ReglementDetail {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS reglement_details(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					reglement_id INTEGER NOT NULL,
					ordre INTEGER NOT NULL DEFAULT 0,
					designation TEXT NOT NULL,
					compte_id INTEGER,
					montant REAL NOT NULL DEFAULT 0
				);
				CREATE INDEX IF NOT EXISTS idx_regdet_reg ON reglement_details(reglement_id);
			" );
		} catch ( \Throwable $e ) { /* base indisponible : le mouvement reste saisissable */ }
	}

	/** Drapeau de création remis à zéro au changement de société. */
	public static function reset() { self::$ready = false; }

	/**
	 * Nettoie et contrôle les lignes reçues.
	 *
	 * Le contrôle est ICI et non dans l'écran : un import ou un futur
	 * appelant doit buter sur la même règle.
	 *
	 * @return array{0:array,1:float,2:?string} lignes propres, total, erreur
	 */
	public static function preparer( $lignes, $contrepartieDefaut = null ) {
		if ( ! is_array( $lignes ) ) { return array( array(), 0.0, null ); }
		$out = array(); $total = 0.0; $ordre = 0;
		foreach ( $lignes as $l ) {
			if ( ! is_array( $l ) ) { continue; }
			$des = trim( (string) ( $l['designation'] ?? '' ) );
			$brut = (string) ( $l['montant'] ?? '' );
			$m = class_exists( 'FKC_FiscalConfig' ) ? FKC_FiscalConfig::nombre( $brut ) : ( is_numeric( $brut ) ? (float) $brut : null );
			$cid = (int) ( $l['compte_id'] ?? 0 ) ?: (int) $contrepartieDefaut;
			// Ligne entièrement vide : l'écran en propose toujours quelques-unes.
			if ( '' === $des && ( null === $m || 0.0 === (float) $m ) ) { continue; }
			if ( '' === $des ) { return array( array(), 0.0, 'Une ligne de détail porte un montant sans désignation.' ); }
			if ( null === $m ) { return array( array(), 0.0, 'Le montant de la ligne « ' . $des . ' » n\'est pas un nombre.' ); }
			$m = round( (float) $m, 2 );
			if ( $m <= 0 ) { return array( array(), 0.0, 'Le montant de la ligne « ' . $des . ' » doit être positif.' ); }
			if ( $cid <= 0 ) { return array( array(), 0.0, 'La ligne « ' . $des . ' » n\'a pas de contrepartie comptable.' ); }
			// Division propre à la ligne (facultative) : un même décaissement
			// règle parfois deux natures relevant de deux divisions.
			$div = (int) ( $l['division_id'] ?? 0 );
			$out[] = array( 'ordre' => $ordre++, 'designation' => $des, 'compte_id' => $cid, 'montant' => $m,
				'division_id' => $div > 0 ? $div : null );
			$total += $m;
		}
		return array( $out, round( $total, 2 ), null );
	}

	public static function enregistrer( $reglementId, array $lignes ) {
		if ( ! $lignes ) { return; }
		self::ensure();
		try {
			foreach ( $lignes as $l ) {
				FKC_DB::q(
					'INSERT INTO reglement_details(reglement_id,ordre,designation,compte_id,montant) VALUES(?,?,?,?,?)',
					array( (int) $reglementId, (int) $l['ordre'], (string) $l['designation'], (int) $l['compte_id'], (float) $l['montant'] )
				);
			}
		} catch ( \Throwable $e ) {
			fkc_log( 'ReglementDetail::enregistrer ' . $e->getMessage(), 'ERROR' );
		}
	}

	public static function pour( $reglementId ) {
		self::ensure();
		try {
			return FKC_DB::q(
				'SELECT d.*, c.numero AS compte_numero, c.libelle AS compte_libelle
				   FROM reglement_details d LEFT JOIN comptes c ON c.id=d.compte_id
				  WHERE d.reglement_id=? ORDER BY d.ordre, d.id',
				array( (int) $reglementId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/** Nombre de lignes par règlement, pour une liste — une requête, pas N. */
	public static function compteParReglement( array $ids ) {
		$ids = array_values( array_unique( array_map( 'intval', $ids ) ) );
		if ( ! $ids ) { return array(); }
		self::ensure();
		try {
			$in = implode( ',', array_fill( 0, count( $ids ), '?' ) );
			$rows = FKC_DB::q( "SELECT reglement_id, COUNT(*) n FROM reglement_details WHERE reglement_id IN ({$in}) GROUP BY reglement_id", $ids )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		$out = array();
		foreach ( $rows as $r ) { $out[ (int) $r['reglement_id'] ] = (int) $r['n']; }
		return $out;
	}
}
