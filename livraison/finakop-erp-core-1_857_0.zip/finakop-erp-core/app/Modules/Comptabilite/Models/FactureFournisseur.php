<?php
/**
 * Factures fournisseurs (factures d'achat) : saisie, comptabilisation automatique
 * (charge + TVA déductible / fournisseur), annulation par contre-passation.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_FactureFournisseur {

	public static function tauxTva() { return array( 18, 9, 0 ); }

	public static function all( $fournisseurId = null, $limit = 300 ) {
		$limit = (int) $limit;
		if ( $fournisseurId ) {
			return FKC_DB::q( "SELECT * FROM factures_fournisseurs WHERE fournisseur_id=? ORDER BY date_facture DESC, id DESC LIMIT {$limit}", array( (int) $fournisseurId ) )->fetchAll();
		}
		return FKC_DB::q( "SELECT * FROM factures_fournisseurs ORDER BY date_facture DESC, id DESC LIMIT {$limit}" )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM factures_fournisseurs WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function nextNumero( $date = null ) {
		/*
		 * Le rang vient du PLUS GRAND numéro attribué, non du nombre de pièces
		 * existantes (1.616.0). Compter suppose que rien ne disparaît jamais :
		 * après une purge, le compte retombe et la pièce suivante réutilise un
		 * numéro déjà vivant. Deux pièces, un seul numéro, et aucune contrainte
		 * de base pour s'y opposer.
		 */
		/*
		 * L'ANNÉE VIENT DE LA DATE DE LA PIÈCE (1.726.0), pas de l'horloge.
		 * Une facture datée du 31/12 saisie le 3 janvier appartient à
		 * l'exercice précédent : son numéro doit le dire.
		 */
		return FKC_Numerotation::suivant( 'FA', 'factures_fournisseurs', '',
			FKC_Numerotation::anneeDe( $date ) );
	}

	/** Total facturé par un fournisseur (hors annulées). */
	public static function totalFournisseur( $id ) {
		return (float) FKC_DB::q( "SELECT COALESCE(SUM(montant_ttc),0) s FROM factures_fournisseurs WHERE fournisseur_id=? AND statut!='annulee'", array( (int) $id ) )->fetch()['s'];
	}

	protected static function journalAchat() {
		foreach ( FKC_Journal::all() as $j ) { if ( 'AC' === $j['code'] ) { return (int) $j['id']; } }
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		return 0;
	}

	/**
	 * Crée une facture fournisseur et la comptabilise.
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null id )
	 */
	/** Nombre de lignes de détail acceptées sur une facture d'achat. */
	const MAX_LIGNES = 60;

	/** Les lignes de détail d'une facture d'achat, dans l'ordre de saisie. */
	public static function lignes( $factureId ) {
		try {
			return FKC_DB::q(
				'SELECT * FROM factures_fournisseurs_lignes WHERE facture_id=? ORDER BY position, id',
				array( (int) $factureId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/**
	 * Nettoie les lignes saisies et calcule leur montant.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * CE QUI EST REFUSÉ, ET POURQUOI
	 *
	 * Une ligne sans désignation NI montant est une ligne vide : le formulaire
	 * en propose toujours quelques-unes d'avance, et les compter ferait naître
	 * des lignes fantômes à chaque facture. Une ligne désignée mais à zéro est
	 * en revanche CONSERVÉE : un article offert, une remise commerciale ou une
	 * reprise à zéro font partie de ce que le fournisseur a facturé, et les
	 * effacer réécrirait sa pièce.
	 *
	 * @return array{0:array,1:float} lignes normalisées, total HT.
	 */
	public static function normaliserLignes( $brut, $compteParDefaut = '601000' ) {
		$out = array(); $total = 0.0; $pos = 0;
		foreach ( (array) $brut as $l ) {
			if ( count( $out ) >= self::MAX_LIGNES ) { break; }
			$des = trim( (string) ( $l['designation'] ?? '' ) );
			$qte = (float) str_replace( ',', '.', (string) ( $l['quantite'] ?? 1 ) );
			$pu  = (float) str_replace( array( ' ', "\xc2\xa0", ',' ), array( '', '', '.' ), (string) ( $l['pu_ht'] ?? 0 ) );
			if ( '' === $des && 0.0 === $pu ) { continue; }
			if ( $qte <= 0 ) { $qte = 1; }
			$mt = round( $qte * $pu, 2 );
			$out[] = array(
				'designation'   => '' !== $des ? mb_substr( $des, 0, 250 ) : 'Ligne ' . ( $pos + 1 ),
				'quantite'      => $qte,
				'pu_ht'         => round( $pu, 2 ),
				'montant_ht'    => $mt,
				'compte_charge' => trim( (string) ( $l['compte_charge'] ?? '' ) ) ?: $compteParDefaut,
				'position'      => $pos++,
			);
			$total += $mt;
		}
		return array( $out, round( $total, 2 ) );
	}

	/**
	 * Construit une facture d'achat sans rien écrire (1.849.0) : contrôles,
	 * montants, lignes d'écriture, réceptions à solder. Partagé par create()
	 * et corriger(), pour qu'une correction ne puisse jamais comptabiliser
	 * autrement qu'une saisie.
	 *
	 * @return array{0:bool,1:string,2:array|null}
	 */
	protected static function construire( $d ) {
		$frn = FKC_Fournisseur::find( (int) ( $d['fournisseur_id'] ?? 0 ) );
		if ( ! $frn ) { return array( false, 'Fournisseur introuvable.', null ); }
		$compteDefaut = trim( (string) ( $d['compte_charge'] ?? '601000' ) ) ?: '601000';
		/*
		 * LES LIGNES, QUAND IL Y EN A, FONT LE MONTANT (1.737.0).
		 *
		 * La facture d'achat ne portait qu'un montant global : on enregistrait
		 * « 450 000 F en 601000 » sans jamais dire ce que le fournisseur avait
		 * livré. Six mois plus tard, devant un contrôle ou une réclamation, la
		 * pièce ne disait plus rien — alors que la facture papier, elle, porte
		 * ses articles, ses quantités et ses prix.
		 *
		 * Le champ « Montant HT » N'EST PAS SUPPRIMÉ : l'import FNE, les packs
		 * métier et les reprises d'historique saisissent un total sans détail,
		 * et le leur interdire casserait des chemins qui fonctionnent. Les
		 * lignes priment quand elles existent, le total sert de repli sinon.
		 */
		list( $lignesDetail, $htLignes ) = self::normaliserLignes( $d['lignes'] ?? array(), $compteDefaut );
		$ht = $lignesDetail ? $htLignes : round( (float) ( $d['montant_ht'] ?? 0 ), 2 );
		if ( $ht <= 0 ) {
			return array( false, $lignesDetail
				? 'Le total des lignes doit être positif.'
				: 'Le montant HT doit être positif.', null );
		}
		$taux = (float) ( $d['taux_tva'] ?? 18 );
		$tva = round( $ht * $taux / 100, 2 );
		$ttc = $ht + $tva;
		$compteCharge = $compteDefaut;
		$date = $d['date_facture'] ?: date( 'Y-m-d' );

		$cCharge = FKC_Compte::byNumero( $compteCharge );
		$cFrn = FKC_Compte::byNumero( $frn['compte'] );
		if ( ! $cCharge || ! $cFrn ) { return array( false, 'Compte de charge ou fournisseur introuvable.', null ); }

		$lib = 'Achat ' . $frn['nom'] . ( ! empty( $d['reference'] ) ? ' (' . $d['reference'] . ')' : '' );
		$div = ! empty( $d['division_id'] ) ? (int) $d['division_id'] : null;
		$aux = array( 'tiers_type' => 'fournisseur', 'tiers_id' => (int) $frn['id'] );

		/*
		 * PRÉ-AFFECTATION DE L'AXE « FOURNISSEURS » (1.547.0).
		 *
		 * La facture CLIENT pré-affecte depuis toujours l'axe Clients sur ses
		 * lignes de produit (FKC_Facture::comptabiliser). Rien d'équivalent
		 * n'existait à l'achat : l'axe Fournisseurs était bien créé et peuplé
		 * par FKC_AnalytiqueLink, mais AUCUNE écriture ne s'y rattachait
		 * jamais. Résultat, un axe qui s'affiche partout, propose ses valeurs
		 * dans tous les sélecteurs, et renvoie systématiquement un résultat
		 * vide avec 100 % de « non affecté ». On ne pouvait pas répondre à
		 * « combien me coûte ce fournisseur ? » sans tout affecter à la main.
		 *
		 * Comme au client : imputation AUTOMATIQUE seulement si l'utilisateur
		 * n'en a pas choisi une lui-même, et sur les lignes de CHARGE
		 * uniquement — ni la TVA déductible, ni la dette 401, qui ne sont pas
		 * des éléments de résultat.
		 */
		$impAxe = ! empty( $d['axe_id'] ) ? (int) $d['axe_id'] : null;
		$impVal = ! empty( $d['valeur_id'] ) ? (int) $d['valeur_id'] : null;
		if ( ! $impAxe && class_exists( 'FKC_AnalytiqueLink' ) ) {
			$fv = (int) FKC_AnalytiqueLink::sync( 'fournisseur', (int) $frn['id'], (string) ( $frn['code'] ?? '' ), (string) $frn['nom'] );
			if ( $fv ) {
				$fa = (int) FKC_AnalytiqueLink::axeFor( 'fournisseur' );
				if ( $fa ) { $impAxe = $fa; $impVal = $fv; }
			}
		}
		$ana = ( $impAxe && $impVal ) ? array( 'axe_id' => $impAxe, 'valeur_id' => $impVal ) : array();

		// RÉCEPTIONS RATTACHÉES — la marchandise a déjà été portée en stock à la
		// réception, avec sa contrepartie en 408 « factures non parvenues ». La
		// facture ne recrée donc PAS la charge : elle extourne le 408 et ouvre
		// la dette facturée en 401. Ne pas le faire compterait l'achat deux fois.
		// La sélection accepte un montant par réception : une livraison peut
		// être facturée en deux fois, ou une facture ne couvrir qu'une part de
		// ce qui a été reçu. À défaut de montant, le reliquat entier est imputé.
		$imputations = array();
		if ( ! empty( $d['receptions'] ) && class_exists( 'FKC_AchatReception' ) ) {
			$sel         = FKC_AchatReception::selection(
				(array) $d['receptions'], (int) $frn['id'],
				isset( $d['receptions_montants'] ) ? (array) $d['receptions_montants'] : array()
			);
			$imputations = $sel['imputations'];
			$extourne    = $sel['total'];
			if ( $extourne > $ht + 0.005 ) {
				return array( false, sprintf(
					'Les réceptions rattachées (%s F) dépassent le montant HT de la facture (%s F). Ajustez les montants imputés.',
					fkc_money( $extourne ), fkc_money( $ht )
				), null );
			}
		} else {
			$extourne = 0.0;
		}

		$lignes = array();
		if ( $extourne > 0 ) {
			$c408 = FKC_Compte::byNumero( FKC_AchatReception::compteAttente() );
			if ( ! $c408 ) {
				$c408id = FKC_Posting::compteId( FKC_AchatReception::compteAttente(), 'Fournisseurs, factures non parvenues' );
				$c408   = $c408id ? array( 'id' => $c408id ) : null;
			}
			if ( ! $c408 ) { return array( false, 'Compte 408 (factures non parvenues) introuvable.', null ); }
			$lignes[] = array( 'compte_id' => (int) $c408['id'], 'libelle' => 'Extourne réceptions — ' . $frn['nom'],
				'debit' => $extourne, 'credit' => 0 ) + $aux;
		}

		// Écart entre le montant reçu et le montant facturé : il doit apparaître
		// en charge (ou en diminution), jamais disparaître dans le compte de tiers.
		$ecart = round( $ht - $extourne, 2 );
		/*
		 * LE DÉTAIL DESCEND JUSQU'AU GRAND LIVRE — SAUF SI UNE RÉCEPTION EST
		 * RATTACHÉE.
		 *
		 * Sans réception, chaque ligne de la facture devient une ligne
		 * d'écriture portant SA désignation et SON compte : le grand livre
		 * cesse d'afficher « Achat Untel » pour tout, et une facture qui mêle
		 * du consommable et une prestation ne fausse plus le compte de
		 * résultat faute d'un second champ à la saisie.
		 *
		 * Avec réception, on garde l'écriture telle qu'elle était : la charge a
		 * déjà été portée à la livraison, et seul l'ÉCART entre le bon et la
		 * facture reste à comptabiliser. Répartir cet écart sur les lignes
		 * demanderait de décider laquelle l'a causé — ce que personne ne sait.
		 * Les lignes restent alors du détail de document, ce qu'elles sont.
		 */
		if ( $lignesDetail && $extourne <= 0 ) {
			foreach ( $lignesDetail as $ld ) {
				if ( abs( (float) $ld['montant_ht'] ) < 0.005 ) { continue; }
				$cl = FKC_Compte::byNumero( $ld['compte_charge'] );
				if ( ! $cl ) { $cl = $cCharge; }
				$mt = (float) $ld['montant_ht'];
				$lignes[] = array( 'compte_id' => (int) $cl['id'],
					'libelle' => mb_substr( $ld['designation'], 0, 120 ),
					'debit' => $mt > 0 ? $mt : 0, 'credit' => $mt < 0 ? -$mt : 0,
					'division_id' => $div ) + $ana;
			}
		} elseif ( $ecart > 0 ) {
			$lignes[] = array( 'compte_id' => (int) $cCharge['id'],
				'libelle' => $extourne > 0 ? $lib . ' — écart sur facture' : $lib,
				'debit' => $ecart, 'credit' => 0, 'division_id' => $div ) + $ana;
		} elseif ( $ecart < 0 ) {
			$lignes[] = array( 'compte_id' => (int) $cCharge['id'], 'libelle' => $lib . ' — écart sur facture',
				'debit' => 0, 'credit' => -$ecart, 'division_id' => $div ) + $ana;
		}

		if ( $tva > 0 ) {
			$cTva = FKC_Compte::byNumero( '445200' );
			if ( ! $cTva ) { return array( false, 'Compte de TVA déductible (445200) introuvable.', null ); }
			$lignes[] = array( 'compte_id' => (int) $cTva['id'], 'libelle' => 'TVA déductible', 'debit' => $tva, 'credit' => 0 );
		}
		// L'échéance ne se pose que sur la DETTE : c'est elle qui a un terme,
		// pas la charge ni la TVA déductible.
		$auxDette = $aux;
		if ( ! empty( $d['date_echeance'] ) ) { $auxDette['echeance'] = (string) $d['date_echeance']; }
		$lignes[] = array( 'compte_id' => (int) $cFrn['id'], 'libelle' => $lib, 'debit' => 0, 'credit' => $ttc ) + $auxDette;

		return array( true, '', compact( 'frn', 'ht', 'taux', 'tva', 'ttc', 'compteCharge', 'date', 'lib', 'div', 'ana',
			'impAxe', 'impVal', 'lignes', 'lignesDetail', 'imputations', 'extourne' ) );
	}

	public static function create( $d ) {
		list( $okB, $msgB, $x ) = self::construire( $d );
		if ( ! $okB ) { return array( false, $msgB, null ); }
		extract( $x );

		// Insère d'abord la facture (sans écriture), pour disposer de son identifiant.
		FKC_DB::q(
			/*
			 * LA PIÈCE GARDE SON IMPUTATION (1.739.0).
			 *
			 * L'axe et la valeur arrivaient bien jusqu'aux lignes d'écriture,
			 * mais la facture elle-même ne les conservait pas : rouvrir la
			 * fiche ne disait plus sur quel projet la charge avait été
			 * imputée, et la modifier repartait de zéro. L'écriture savait,
			 * la pièce avait oublié — et c'est la pièce qu'on relit.
			 */
			'INSERT INTO factures_fournisseurs(numero,reference,fournisseur_id,fournisseur_nom,date_facture,date_echeance,compte_charge,montant_ht,taux_tva,montant_tva,montant_ttc,statut,ecriture_id,division_id,axe_id,valeur_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array( self::nextNumero( $date ), $d['reference'] ?? null, $frn['id'], $frn['nom'], $date, $d['date_echeance'] ?? null, $compteCharge, $ht, $taux, $tva, $ttc, /* Le couple, ou rien : une valeur sans son axe ne veut rien dire, et
			   c'est déjà la règle appliquée aux lignes d'écriture ci-dessus. */
			'a_payer', null, $div, $ana ? $impAxe : null, $ana ? $impVal : null )
		);
		$fid = (int) FKC_DB::conn()->lastInsertId();
		if ( $lignesDetail ) {
			try {
				foreach ( $lignesDetail as $ld ) {
					FKC_DB::q(
						'INSERT INTO factures_fournisseurs_lignes(facture_id,designation,quantite,pu_ht,montant_ht,compte_charge,position)
						 VALUES(?,?,?,?,?,?,?)',
						array( $fid, $ld['designation'], $ld['quantite'], $ld['pu_ht'], $ld['montant_ht'], $ld['compte_charge'], $ld['position'] )
					);
				}
			} catch ( \Throwable $e ) {
				// Le détail est une information de document : son échec ne doit
				// pas faire perdre une facture dont l'écriture est juste. On le
				// consigne, la facture vit, et le total reste exact.
				if ( function_exists( 'fkc_log' ) ) { fkc_log( 'FactureFournisseur — lignes : ' . $e->getMessage(), 'WARN' ); }
			}
		}

		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer(
			array( 'journal_id' => self::journalAchat(), 'date_ecriture' => $date, 'libelle' => $lib, 'piece' => $d['reference'] ?? null, 'created_by' => FKC_Auth::id() ),
			$lignes,
			array( 'source' => 'achat', 'lien' => array( 'table' => 'factures_fournisseurs', 'colonne' => 'ecriture_id', 'ids' => array( $fid ) ) )
		);
		if ( ! $ok ) {
			// Les lignes partent avec la facture : `ON DELETE CASCADE` ne
			// s'applique que si les clés étrangères sont actives, ce qui n'est
			// pas garanti sur toutes les bases. On ne laisse pas derrière soi
			// le détail d'une facture qui n'existe plus.
			try { FKC_DB::q( 'DELETE FROM factures_fournisseurs_lignes WHERE facture_id=?', array( $fid ) ); } catch ( \Throwable $e ) {}
			FKC_DB::q( 'DELETE FROM factures_fournisseurs WHERE id=?', array( $fid ) );
			return array( false, $msg, null );
		}
		// Solde les réceptions rattachées et tisse la chaîne documentaire
		// réception → facture, elle-même reliée à l'objet du pack métier.
		if ( $imputations && class_exists( 'FKC_AchatReception' ) ) {
			FKC_AchatReception::rattacher( $imputations, $fid );
		}
		if ( class_exists( 'FKC_BPE' ) && $eid ) {
			FKC_BPE::lier( 'facture_fournisseur', $fid, 'ecriture', (int) $eid, 'comptabilise' );
		}

		// Pont vers le bus d'événements : recouvrement fournisseur, notifications,
		// automatisation et packs peuvent réagir sans double comptabilisation.
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'facture_fournisseur_enregistree', array(
				'facture_fournisseur_id' => $fid, 'fournisseur_id' => (int) $frn['id'],
				'fournisseur' => (string) $frn['nom'], 'reference' => (string) ( $d['reference'] ?? '' ),
				'date' => $date, 'ht' => $ht, 'tva' => $tva, 'ttc' => $ttc,
				'compte_charge' => $compteCharge, 'division_id' => $div,
				'receptions_soldees' => count( $imputations ), 'extourne_408' => $extourne,
				'ecriture_id' => $eid ? (int) $eid : null, 'brouillon_id' => $bid ? (int) $bid : null,
			), array( 'poster' => false ) );
			// Pont Achats ↔ Immobilisations : un achat imputé en classe 2 et
			// au-dessus du seuil d'immobilisation doit donner lieu à une fiche
			// (l'écran « Importer depuis écriture » la propose ; l'événement
			// permet notification/automatisation immédiates).
			if ( '2' === substr( $compteCharge, 0, 1 )
				&& class_exists( 'FKC_Immobilisation' ) && ! FKC_Immobilisation::sousSeuil( $ht ) ) {
				FKC_Events::emettre( 'immo_acquisition_detectee', array(
					'facture_fournisseur_id' => $fid, 'fournisseur' => (string) $frn['nom'],
					'compte_immo' => $compteCharge, 'valeur_acquisition' => $ht, 'date' => $date,
					'ecriture_id' => $eid ? (int) $eid : null,
				), array( 'poster' => false ) );
			}
		}
		if ( $bid ) {
			return array( true, 'Facture fournisseur enregistrée — écriture déposée au brouillard (à vérifier avant comptabilisation).', $fid );
		}
		return array( true, 'Facture fournisseur enregistrée et comptabilisée (écriture n°' . $eid . ').', $fid );
	}

	/**
	 * CORRIGER UNE FACTURE FOURNISSEUR — la pièce garde son numéro (1.849.0).
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * CE QUI A CHANGÉ, ET POURQUOI
	 *
	 * Jusqu'en 1.848.0, corriger une facture d'achat l'ANNULAIT et en créait
	 * une autre, sous un NOUVEAU numéro. Comptablement la trace était juste ;
	 * pour l'utilisateur, c'était faux : la facture du fournisseur est UN
	 * document. Une erreur de quantité ne la transforme pas en deux factures,
	 * le registre des achats se remplissait de numéros annulés, la pièce
	 * rattachée aux règlements devenait une autre, et une facture déjà en
	 * partie réglée ne pouvait même pas être corrigée (l'annulation l'interdit).
	 *
	 * La règle SYSCOHADA ne porte pas sur le DOCUMENT mais sur l'ÉCRITURE :
	 * une écriture validée ne se modifie pas, elle se contre-passe. C'est ce
	 * qui est fait ici — et seulement cela :
	 *
	 *   • l'écriture d'origine est CONTRE-PASSÉE, datée comme elle (la
	 *     période d'origine voit la charge disparaître puis réapparaître
	 *     corrigée ; une période clôturée refuse, et on le dit) ; si elle
	 *     dormait au brouillard, le brouillon est retiré ;
	 *   • une NOUVELLE écriture porte les montants corrigés ;
	 *   • la facture garde son identifiant, son NUMÉRO, ses pièces jointes et
	 *     ses règlements ;
	 *   • la version d'avant est CONSERVÉE (factures_fournisseurs_versions) :
	 *     montants, lignes, écriture, auteur, date. On voit ce qui a été
	 *     corrigé, quand et par qui — ce que l'ancienne méthode obtenait en
	 *     multipliant les pièces.
	 *
	 * TOUT OU RIEN : l'ensemble passe dans une transaction (FKC_Tx). Si la
	 * nouvelle écriture est refusée, la contre-passation et le retrait des
	 * réceptions sont défaits : la facture reste telle qu'elle était.
	 *
	 * Une facture déjà ANNULÉE n'est pas corrigée : elle est ressaisie (une
	 * nouvelle facture, liée à l'annulée) — une pièce annulée ne revit pas.
	 *
	 * @param int   $id Facture à corriger.
	 * @param array $d  Données corrigées (même format que create()).
	 * @return array{0:bool,1:string,2:int|null}
	 */
	public static function corriger( $id, $d ) {
		$f = self::find( $id );
		if ( ! $f ) { return array( false, 'Facture introuvable.', null ); }

		// Pièce annulée : ressaisie, jamais résurrection.
		if ( 'annulee' === (string) $f['statut'] ) {
			list( $ok, $msg, $nid ) = self::create( $d );
			if ( ! $ok ) { return array( false, $msg, null ); }
			if ( class_exists( 'FKC_BPE' ) ) {
				FKC_BPE::lier( 'facture_fournisseur', (int) $id, 'facture_fournisseur', (int) $nid, 'corrige' );
			}
			return array( true, 'Facture ressaisie à partir de ' . $f['numero'] . ' (annulée) : ' . $msg, (int) $nid );
		}

		/*
		 * LES RÈGLEMENTS RESTENT ACQUIS. Ils sont imputés sur cette facture,
		 * qui garde son identifiant : ils la suivent. Deux limites seulement :
		 * le fournisseur ne peut plus changer (le règlement lui a été fait), et
		 * le nouveau total ne peut pas descendre sous ce qui est déjà payé.
		 */
		$paye = 0.0;
		if ( class_exists( 'FKC_Imputation' ) ) {
			$paye = (float) ( FKC_Imputation::parFacture( array( (int) $id ), 'fournisseur' )[ (int) $id ] ?? 0 );
		}
		if ( $paye > 0.005 && (int) ( $d['fournisseur_id'] ?? 0 ) !== (int) $f['fournisseur_id'] ) {
			return array( false, 'Cette facture porte ' . fkc_money( $paye ) . ' F de règlement fait à ' . $f['fournisseur_nom']
				. ' : son fournisseur ne peut pas changer. Annulez d\'abord le règlement.', null );
		}

		// Réceptions déjà soldées par cette facture : elles restent rattachées
		// si le formulaire n'en dit rien (l'écran ne les propose plus, puisqu'elles
		// ne sont plus « à facturer »). Les perdre recréerait la charge en double.
		$anciennesReceptions = array();
		if ( class_exists( 'FKC_AchatReception' ) ) {
			try {
				foreach ( FKC_DB::q( 'SELECT id, montant_facture FROM achat_receptions WHERE facture_id=?', array( (int) $id ) )->fetchAll() as $r ) {
					$anciennesReceptions[ (int) $r['id'] ] = (float) $r['montant_facture'];
				}
			} catch ( \Throwable $e ) { $anciennesReceptions = array(); }
		}
		if ( empty( $d['receptions'] ) && $anciennesReceptions ) {
			$d['receptions'] = array_keys( $anciennesReceptions );
			$d['receptions_montants'] = $anciennesReceptions;
		}

		$avant = array(
			'facture' => $f,
			'lignes' => self::lignes( (int) $id ),
			'receptions' => $anciennesReceptions,
		);
		$resultat = null;
		try {
			$resultat = FKC_Tx::executer( function () use ( $f, $d, $id, $paye, $avant ) {
				// 1. L'écriture d'origine : contre-passée (datée comme elle), ou
				//    retirée du brouillard si elle n'a jamais été validée.
				$contre = null;
				if ( ! empty( $f['ecriture_id'] ) ) {
					list( $okCp, $msgCp, $cpId ) = array_pad( (array) FKC_EcritureAnnulation::contrepasser( (int) $f['ecriture_id'], (string) $f['date_facture'] ), 3, null );
					if ( ! $okCp ) { throw new \RuntimeException( 'Correction impossible : ' . $msgCp . ' Pour une période clôturée, passez une facture d\'avoir.' ); }
					$contre = $cpId ? (int) $cpId : null;
				} elseif ( class_exists( 'FKC_Brouillard' ) ) {
					foreach ( FKC_Brouillard::pendingFor( 'factures_fournisseurs', (int) $id ) as $bid ) { FKC_Brouillard::delete( (int) $bid ); }
				}

				// 2. Les réceptions sont libérées, pour être re-soldées par la version corrigée.
				if ( class_exists( 'FKC_AchatReception' ) ) { FKC_AchatReception::detacher( (int) $id ); }

				// 3. La version corrigée, construite exactement comme une saisie.
				list( $okB, $msgB, $x ) = self::construire( $d );
				if ( ! $okB ) { throw new \RuntimeException( $msgB ); }
				if ( $paye > 0.005 && (float) $x['ttc'] < $paye - 0.005 ) {
					throw new \RuntimeException( 'Le nouveau total (' . fkc_money( $x['ttc'] ) . ' F TTC) serait inférieur à ce qui est déjà payé ('
						. fkc_money( $paye ) . ' F). Annulez d\'abord le règlement en trop, ou demandez un avoir au fournisseur.' );
				}

				// 4. La version d'avant est conservée.
				self::assurerVersions();
				FKC_DB::q(
					'INSERT INTO factures_fournisseurs_versions(facture_id,version,donnees,ecriture_remplacee,contrepassation_id,auteur_id) VALUES(?,?,?,?,?,?)',
					array( (int) $id, self::nbVersions( (int) $id ) + 1, json_encode( $avant, JSON_UNESCAPED_UNICODE ),
						$f['ecriture_id'] ? (int) $f['ecriture_id'] : null, $contre, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
				);

				// 5. La pièce, MÊME identifiant, MÊME numéro.
				FKC_DB::q(
					'UPDATE factures_fournisseurs SET reference=?, fournisseur_id=?, fournisseur_nom=?, date_facture=?, date_echeance=?, compte_charge=?,
					   montant_ht=?, taux_tva=?, montant_tva=?, montant_ttc=?, ecriture_id=NULL, division_id=?, axe_id=?, valeur_id=? WHERE id=?',
					array( $d['reference'] ?? null, $x['frn']['id'], $x['frn']['nom'], $x['date'], $d['date_echeance'] ?? null, $x['compteCharge'],
						$x['ht'], $x['taux'], $x['tva'], $x['ttc'], $x['div'], $x['ana'] ? $x['impAxe'] : null, $x['ana'] ? $x['impVal'] : null, (int) $id )
				);
				FKC_DB::q( 'DELETE FROM factures_fournisseurs_lignes WHERE facture_id=?', array( (int) $id ) );
				foreach ( $x['lignesDetail'] as $ld ) {
					FKC_DB::q(
						'INSERT INTO factures_fournisseurs_lignes(facture_id,designation,quantite,pu_ht,montant_ht,compte_charge,position) VALUES(?,?,?,?,?,?,?)',
						array( (int) $id, $ld['designation'], $ld['quantite'], $ld['pu_ht'], $ld['montant_ht'], $ld['compte_charge'], $ld['position'] )
					);
				}

				// 6. La nouvelle écriture.
				list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer(
					array( 'journal_id' => self::journalAchat(), 'date_ecriture' => $x['date'], 'libelle' => $x['lib'] . ' — corrigée',
						'piece' => $d['reference'] ?? null, 'created_by' => FKC_Auth::id() ),
					$x['lignes'],
					array( 'source' => 'achat', 'lien' => array( 'table' => 'factures_fournisseurs', 'colonne' => 'ecriture_id', 'ids' => array( (int) $id ) ) )
				);
				if ( ! $ok ) { throw new \RuntimeException( $msg ); }

				if ( $x['imputations'] && class_exists( 'FKC_AchatReception' ) ) { FKC_AchatReception::rattacher( $x['imputations'], (int) $id ); }
				return array( 'eid' => $eid ? (int) $eid : null, 'bid' => $bid ? (int) $bid : null, 'contre' => $contre, 'x' => $x );
			} );
		} catch ( \Throwable $e ) {
			return array( false, $e->getMessage() . ' La facture ' . $f['numero'] . ' est inchangée.', null );
		}

		if ( class_exists( 'FKC_BPE' ) ) {
			if ( $resultat['eid'] ) { FKC_BPE::lier( 'facture_fournisseur', (int) $id, 'ecriture', (int) $resultat['eid'], 'comptabilise' ); }
			FKC_BPE::auditer( 'facture_fournisseur_corrigee', 'facture_fournisseur', (int) $id,
				'n° ' . $f['numero'] . ' — ' . fkc_money( $f['montant_ttc'] ) . ' → ' . fkc_money( $resultat['x']['ttc'] ) . ' F TTC' );
		}
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'facture_fournisseur_corrigee', array(
				'facture_fournisseur_id' => (int) $id, 'numero' => (string) $f['numero'],
				'ttc_avant' => (float) $f['montant_ttc'], 'ttc_apres' => (float) $resultat['x']['ttc'],
				'ecriture_annulee' => $f['ecriture_id'] ? (int) $f['ecriture_id'] : null, 'ecriture_id' => $resultat['eid'],
			), array( 'poster' => false ) );
		}

		$msg = 'Facture ' . $f['numero'] . ' corrigée — elle garde son numéro. ';
		if ( ! empty( $f['ecriture_id'] ) ) {
			$msg .= 'Son écriture n°' . (int) $f['ecriture_id'] . ' a été contre-passée' . ( $resultat['contre'] ? ' (écriture n°' . $resultat['contre'] . ')' : '' ) . ', ';
		} else {
			$msg .= 'Son écriture en attente au brouillard a été retirée, ';
		}
		$msg .= $resultat['bid']
			? 'et l\'écriture corrigée attend au brouillard.'
			: 'et remplacée par l\'écriture n°' . $resultat['eid'] . '.';
		return array( true, $msg, (int) $id );
	}

	/** Versions antérieures d'une facture corrigée, la plus récente d'abord. */
	public static function versions( $id ) {
		self::assurerVersions();
		$out = array();
		foreach ( FKC_DB::q( 'SELECT * FROM factures_fournisseurs_versions WHERE facture_id=? ORDER BY version DESC', array( (int) $id ) )->fetchAll() as $r ) {
			$r['donnees'] = json_decode( (string) $r['donnees'], true ) ?: array();
			$out[] = $r;
		}
		return $out;
	}

	protected static function nbVersions( $id ) {
		return (int) FKC_DB::q( 'SELECT COUNT(*) FROM factures_fournisseurs_versions WHERE facture_id=?', array( (int) $id ) )->fetchColumn();
	}

	protected static function assurerVersions() {
		static $fait = false;
		if ( $fait ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS factures_fournisseurs_versions(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				facture_id INTEGER NOT NULL,
				version INTEGER NOT NULL,
				donnees TEXT NOT NULL,
				/* Une TRACE, pas une pièce : la colonne n'a pas le nom
				   habituel des pièces, pour que la carte des origines
				   (FKC_Origine) ne la prenne pas pour la pièce de cette
				   écriture ni ne la délie. */
				ecriture_remplacee INTEGER,
				contrepassation_id INTEGER,
				auteur_id INTEGER,
				cree_at TEXT NOT NULL DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_ffv_facture ON factures_fournisseurs_versions(facture_id);
		" );
		$fait = true;
	}

	/**
	 * Supprime définitivement une facture ANNULÉE, et elle seule.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * POURQUOI UNE SUPPRESSION EST ICI ACCEPTABLE — ET SEULEMENT ICI
	 *
	 * Une facture annulée est déjà NEUTRE : sa contre-passation a été
	 * enregistrée, les deux écritures s'annulent au centime, et les réceptions
	 * rattachées ont été rendues à l'état « à facturer ». Elle ne pèse plus
	 * rien ; elle encombre simplement la liste, parfois pour des années, avec
	 * une erreur de saisie ou un doublon corrigé le jour même.
	 *
	 * CE QUI PART : le document, ses lignes de détail, ses pièces jointes
	 * (fichiers compris) et ses liens de chaîne documentaire.
	 *
	 * CE QUI RESTE, ET CE N'EST PAS NÉGOCIABLE : LES ÉCRITURES. Elles sont
	 * numérotées, datées, et le journal d'achats doit rester ininterrompu —
	 * c'est la règle SYSCOHADA, et c'est aussi ce qui rend la comptabilité
	 * opposable. Effacer une écriture pour faire disparaître une erreur est
	 * exactement ce qu'un contrôle cherche. La facture disparaît de l'écran ;
	 * son passage reste lisible au grand livre, contre-passé.
	 *
	 * Et rien ne part tant que le statut n'est pas « annulée » : sans ce
	 * verrou, l'écran offrirait un moyen d'effacer une dette vivante.
	 */
	public static function supprimer( $id ) {
		$f = self::find( $id );
		if ( ! $f ) { return array( false, 'Facture introuvable.' ); }
		if ( 'annulee' !== (string) $f['statut'] ) {
			return array( false, 'Seule une facture annulée peut être supprimée. Annulez-la d\'abord : une écriture de contre-passation sera générée.' );
		}
		$fid = (int) $f['id'];

		// Les pièces jointes partent par le modèle, pas par un DELETE : lui
		// seul efface AUSSI le fichier sur le disque. Une ligne supprimée sans
		// son fichier laisserait le justificatif orphelin, hors de portée de
		// l'écran comme de toute purge ultérieure.
		if ( class_exists( 'FKC_PieceJointe' ) ) {
			foreach ( FKC_PieceJointe::forSource( 'facture_fournisseur', $fid ) as $pj ) {
				FKC_PieceJointe::delete( (int) $pj['id'] );
			}
		}
		try { FKC_DB::q( 'DELETE FROM factures_fournisseurs_lignes WHERE facture_id=?', array( $fid ) ); } catch ( \Throwable $e ) {}
		try {
			FKC_DB::q(
				"DELETE FROM erp_document_links WHERE (amont_type='facture_fournisseur' AND amont_id=?) OR (aval_type='facture_fournisseur' AND aval_id=?)",
				array( $fid, $fid )
			);
		} catch ( \Throwable $e ) {}
		FKC_DB::q( 'DELETE FROM factures_fournisseurs WHERE id=?', array( $fid ) );

		if ( class_exists( 'FKC_BPE' ) ) {
			FKC_BPE::auditer( 'facture_fournisseur_supprimee', 'facture_fournisseur', $fid,
				'n° ' . (string) $f['numero'] . ' — ' . (string) $f['fournisseur_nom'] );
		}
		return array( true, 'Facture ' . $f['numero'] . ' supprimée. Les écritures de comptabilisation et de contre-passation restent au journal : elles s\'annulent, et le journal doit rester ininterrompu.' );
	}

	/** Annulation par contre-passation de l'écriture. */
	public static function annuler( $id ) {
		$f = self::find( $id );
		if ( ! $f || 'annulee' === $f['statut'] ) { return array( false, 'Facture introuvable ou déjà annulée.' ); }
		/*
		 * UNE FACTURE RÉGLÉE NE S'ANNULE PAS EN SILENCE (1.745.0). Le
		 * règlement qui l'éteignait se retrouverait sans objet et passerait
		 * en avance au fournisseur. On annule d'abord le règlement.
		 */
		if ( class_exists( 'FKC_Imputation' ) ) {
			$impute = (float) ( FKC_Imputation::parFacture( array( (int) $id ), 'fournisseur' )[ (int) $id ] ?? 0 );
			if ( $impute > 0.005 ) {
				return array( false, 'Cette facture porte ' . fkc_money( $impute ) . ' F de règlement. Annulez d\'abord le règlement : la dette se rouvrira, puis la facture pourra être annulée.' );
			}
		}
		$msgCp = '';
		if ( $f['ecriture_id'] ) {
			/*
			 * LA CONTRE-PASSATION PASSE PAR LE MOTEUR COMMUN (1.745.0).
			 * Elle était écrite ici à la main, directement au journal : sans
			 * marqueur (donc contre-passable une seconde fois), sans le numéro
			 * de l'écriture annulée, sans la division ni les axes analytiques,
			 * et hors du journal temporaire. FKC_EcritureAnnulation fait tout
			 * cela, et suit la politique de comptabilisation.
			 */
			list( $okCp, $msgCp ) = FKC_EcritureAnnulation::contrepasser( (int) $f['ecriture_id'] );
			if ( ! $okCp ) {
				return array( false, 'Annulation refusée : ' . $msgCp );
			}
		}
		/*
		 * SI L'ÉCRITURE DORT ENCORE AU BROUILLARD, ON LA RETIRE (1.741.0).
		 *
		 * `ecriture_id` n'est renseigné qu'à la comptabilisation. Une facture
		 * déposée au brouillard et annulée aussitôt ne déclenchait donc AUCUNE
		 * contre-passation — ce qui est juste — mais laissait son brouillon en
		 * attente. Validé plus tard, il comptabilisait une pièce qui n'existait
		 * plus. Le défaut ne se voyait pas : il fallait annuler, puis valider le
		 * brouillard un autre jour, et personne ne rapprochait les deux gestes.
		 *
		 * On ne contre-passe pas un brouillon : on le supprime. Il n'a rien
		 * touché, il n'a rien à annuler.
		 */
		$brouillonsRetires = 0;
		if ( empty( $f['ecriture_id'] ) && class_exists( 'FKC_Brouillard' ) ) {
			foreach ( FKC_Brouillard::pendingFor( 'factures_fournisseurs', (int) $id ) as $bid ) {
				try { FKC_Brouillard::delete( (int) $bid ); $brouillonsRetires++; } catch ( \Throwable $e ) {}
			}
		}
		FKC_DB::q( "UPDATE factures_fournisseurs SET statut='annulee' WHERE id=?", array( (int) $id ) );
		// Les réceptions redeviennent à facturer : la marchandise est toujours
		// en stock et toujours due, seule la facture a disparu.
		if ( class_exists( 'FKC_AchatReception' ) ) { FKC_AchatReception::detacher( (int) $id ); }
		if ( $brouillonsRetires > 0 ) {
			return array( true, 'Facture annulée. Son écriture dormait encore au brouillard : elle en a été retirée plutôt que contre-passée.' );
		}
		return array( true, 'Facture annulée. ' . ( '' !== $msgCp ? $msgCp : 'Aucune écriture à contre-passer.' ) );
	}
}
