<?php
/**
 * Imputation d'un encaissement sur les factures qu'il solde — le poste client
 * lu FACTURE PAR FACTURE, et non plus comme un solde global par client.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CE QUE CE MODÈLE RÉPARE
 *
 * L'écran « Encaissements » de la comptabilité posait une seule question :
 * « combien le client Konan a-t-il payé ? ». Jamais « laquelle de ses quatre
 * factures ? ». Le règlement n'était rattaché qu'au tiers, et le poste client
 * se reconstituait par un lettrage FIFO — le plus ancien d'abord.
 *
 * Le FIFO est un repli honnête tant que personne n'a décidé. Il devient faux
 * dès que quelqu'un décide, ce qui est le cas ordinaire : on règle la facture
 * de mars parce que la livraison de janvier est contestée. Le FIFO éteignait
 * alors janvier, laissait mars ouverte, et l'entreprise relançait sur la
 * mauvaise facture en considérant la litigieuse comme payée.
 *
 * TROIS SOURCES, UNE SEULE LECTURE
 *
 * L'imputation d'une facture ne vient pas d'un seul endroit :
 *
 *   1. `reglement_imputations` — la décision prise à l'encaissement (nouveau) ;
 *   2. `recus.facture_id`      — le module Encaissement le renseignait DÉJÀ,
 *      et personne ne le lisait côté comptabilité : des paiements parfaitement
 *      imputés étaient réimputés au hasard par le FIFO ;
 *   3. le FIFO, pour ce qui reste — avances, règlements globaux, historique.
 *
 * Les trois se combinent dans cet ordre. Rien n'est rejoué, rien n'est migré :
 * les bases existantes gagnent l'imputation des reçus dès la mise à jour.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Imputation {

	/** Tolérance d'arrondi : en dessous, une facture est considérée soldée. */
	const EPSILON = 0.5;

	/** @var bool|null Table présente ? (base antérieure au schéma 20) */
	protected static $dispo = null;

	/** La table d'imputation existe-t-elle sur cette base ? */
	public static function disponible() {
		if ( null !== self::$dispo ) { return self::$dispo; }
		try {
			FKC_DB::q( 'SELECT 1 FROM reglement_imputations LIMIT 1' );
			self::$dispo = true;
		} catch ( \Throwable $e ) {
			self::$dispo = false;
		}
		return self::$dispo;
	}

	/** Oublie le test de présence (changement de société). */
	public static function oublier() { self::$dispo = null; }

	/**
	 * Montant explicitement imputé, par facture.
	 *
	 * @param array|null $factureIds Restreint le calcul à ces factures.
	 * @return array facture_id => montant imputé (positif = créance éteinte)
	 */
	public static function parFacture( $factureIds = null, $type = 'client', $asOf = null ) {
		$type = ( 'fournisseur' === $type ) ? 'fournisseur' : 'client';
		$ids = null;
		if ( null !== $factureIds ) {
			$ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $factureIds ) ) ) );
			if ( ! $ids ) { return array(); }
		}
		$out = array();

		// 1. Imputations saisies à l'encaissement (ou au paiement).
		if ( self::disponible() ) {
			try {
				/*
				 * LE TYPE EST FILTRÉ, ET CE N'EST PAS UNE PRÉCAUTION DE STYLE.
				 * La facture client n°12 et la facture d'achat n°12 existent
				 * toutes deux. Sans ce filtre, un paiement fournisseur
				 * éteindrait une créance client — silencieusement, et dans le
				 * bon sens comptable, ce qui est le pire des cas.
				 */
				/*
				 * UN RÈGLEMENT ANNULÉ N'ÉTEINT PLUS RIEN (1.745.0). Son
				 * imputation est conservée — elle dit ce qu'il avait soldé, et
				 * redevient active si l'annulation est rejetée — mais elle ne
				 * compte plus : la facture se rouvre.
				 */
				$sql = "SELECT i.facture_id, COALESCE(SUM(i.montant),0) s FROM reglement_imputations i
				        LEFT JOIN reglements r ON r.id = i.reglement_id
				        WHERE COALESCE(i.type,'client')=? AND COALESCE(r.statut,'actif')<>'annule'";
				$arg = array( $type );
				// Arrêté (1.854.0) : seules comptent les imputations des règlements déjà passés.
				if ( $asOf ) { $sql .= ' AND r.date_reglement <= ?'; $arg[] = (string) $asOf; }
				if ( $ids ) {
					$sql .= ' AND i.facture_id IN (' . implode( ',', array_fill( 0, count( $ids ), '?' ) ) . ')';
					$arg  = array_merge( $arg, $ids );
				}
				$sql .= ' GROUP BY i.facture_id';
				foreach ( FKC_DB::q( $sql, $arg )->fetchAll() as $r ) {
					$out[ (int) $r['facture_id'] ] = ( $out[ (int) $r['facture_id'] ] ?? 0.0 ) + (float) $r['s'];
				}
			} catch ( \Throwable $e ) { /* lecture impossible : le FIFO prendra le relais */ }
		}

		/*
		 * 2. Reçus déjà rattachés à une facture. CÔTÉ CLIENT UNIQUEMENT : le
		 * module Encaissement n'émet pas de reçu pour ce que l'entreprise
		 * paie à ses fournisseurs.
		 */
		if ( 'fournisseur' === $type ) {
			foreach ( $out as $k => $v ) { $out[ $k ] = round( (float) $v, 2 ); }
			return $out;
		}
		/*
		 * Reçus déjà rattachés à une facture.
		 *
		 * MÊME PÉRIMÈTRE QUE L'ENCAISSÉ (1.841.1). Un acompte ou une avance
		 * non encore rapprochés dorment en 419 : ils n'ont pas touché le 411
		 * et n'éteignent donc aucune facture. Les compter ici alors que
		 * l'encaissé du client les ignore retranchait deux fois la même
		 * somme du pool de lettrage — l'encours ressortait surévalué du
		 * montant de l'acompte. Même chose pour un encaissement divers, qui
		 * crédite un produit et non le client.
		 *
		 * On ne retient que les reçus COMPTABILISÉS (`ecriture_id`) : un reçu
		 * en brouillon n'a rien éteint au grand livre, et l'imputer ici ferait
		 * disparaître une créance qui existe toujours. Un remboursement
		 * (sens `decaissement`) rouvre la facture à due concurrence.
		 */
		try {
			$sql = "SELECT facture_id,
			               COALESCE(SUM(CASE WHEN sens='decaissement' THEN -montant_ttc ELSE montant_ttc END),0) s
			        FROM recus
			        WHERE facture_id IS NOT NULL AND facture_id <> 0
			          AND ecriture_id IS NOT NULL AND statut NOT IN ('annule')
			          AND ( type_operation IN ('paiement_facture','vente_comptant','remboursement')
			                OR ( type_operation IN ('acompte_client','avance_commande') AND rapproche_at IS NOT NULL ) )";
			$arg = array();
			if ( $asOf ) { $sql .= " AND COALESCE(NULLIF(date_recu,''),substr(created_at,1,10)) <= ?"; $arg[] = (string) $asOf; }
			if ( $ids ) {
				$sql .= ' AND facture_id IN (' . implode( ',', array_fill( 0, count( $ids ), '?' ) ) . ')';
				$arg  = $ids;
			}
			$sql .= ' GROUP BY facture_id';
			foreach ( FKC_DB::q( $sql, $arg )->fetchAll() as $r ) {
				$out[ (int) $r['facture_id'] ] = ( $out[ (int) $r['facture_id'] ] ?? 0.0 ) + (float) $r['s'];
			}
		} catch ( \Throwable $e ) { /* module Encaissement absent : table `recus` inexistante */ }

		foreach ( $out as $k => $v ) { $out[ $k ] = round( (float) $v, 2 ); }
		return $out;
	}

	/** Lignes d'imputation d'un règlement donné (avec numéro de facture). */
	public static function duReglement( $reglementId ) {
		if ( ! self::disponible() ) { return array(); }
		try {
			return FKC_DB::q(
				'SELECT i.*, f.numero, f.date_facture, f.montant_ttc
				 FROM reglement_imputations i
				 LEFT JOIN factures f ON f.id = i.facture_id
				 WHERE i.reglement_id = ? ORDER BY f.date_facture ASC, i.id ASC',
				array( (int) $reglementId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/**
	 * Enregistre l'imputation d'un règlement.
	 *
	 * @param int   $reglementId Règlement déjà créé.
	 * @param array $lignes      facture_id => montant.
	 * @return array{0:bool,1:string,2:float} ok, message, total imputé.
	 */
	public static function enregistrer( $reglementId, $lignes, $type = 'client' ) {
		$type = ( 'fournisseur' === $type ) ? 'fournisseur' : 'client';
		$reglementId = (int) $reglementId;
		if ( $reglementId <= 0 ) { return array( false, 'Règlement inconnu.', 0.0 ); }
		if ( ! self::disponible() ) {
			// Base antérieure au schéma 20 : l'encaissement reste valable, il
			// se lettrera en FIFO. On le dit, on ne bloque pas la saisie.
			return array( false, 'Imputation par facture indisponible sur cette base (lettrage automatique appliqué).', 0.0 );
		}
		$total = 0.0;
		try {
			FKC_DB::q( 'DELETE FROM reglement_imputations WHERE reglement_id=?', array( $reglementId ) );
			foreach ( (array) $lignes as $fid => $m ) {
				$fid = (int) $fid;
				$m   = round( (float) $m, 2 );
				if ( $fid <= 0 || abs( $m ) < 0.005 ) { continue; }
				FKC_DB::q(
					'INSERT INTO reglement_imputations(reglement_id,facture_id,montant,type) VALUES(?,?,?,?)',
					array( $reglementId, $fid, $m, $type )
				);
				$total += $m;
			}
		} catch ( \Throwable $e ) {
			fkc_log( 'Imputation::enregistrer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Imputation non enregistrée.', 0.0 );
		}
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }
		return array( true, '', round( $total, 2 ) );
	}

	/** Supprime les imputations d'un règlement (annulation, correction). */
	public static function supprimer( $reglementId ) {
		if ( ! self::disponible() ) { return; }
		try { FKC_DB::q( 'DELETE FROM reglement_imputations WHERE reglement_id=?', array( (int) $reglementId ) ); } catch ( \Throwable $e ) {}
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }
	}

	/**
	 * AVOIRS : ILS ÉTEIGNENT LEUR FACTURE D'ORIGINE, PAS LA PLUS ANCIENNE (1.841.1).
	 *
	 * Un avoir qui porte `avoir_origine_id` dit sur quoi il porte : il annule
	 * CETTE facture. Il était pourtant versé au pool FIFO, qui l'imputait sur
	 * les factures les plus anciennes. Effet mesuré : une facture annulée par
	 * avoir restait ouverte et relancée, pendant qu'une facture légitime plus
	 * ancienne était déclarée soldée.
	 *
	 * On impute donc l'avoir sur son origine, dans la limite de ce qui y reste
	 * ouvert après les imputations nommées ; le surplus (origine déjà réglée,
	 * avoir sans origine) reste un crédit libre qui rejoint le pool.
	 *
	 * @param array $factures lignes avec id, client_id, montant_ttc
	 * @param array $imputes  facture_id => montant déjà imputé nommément
	 * @return array{par_facture:array, libres:array} libres = client_id => crédit
	 */
	public static function avoirsAffectes( array $factures, array $imputes = array() ) {
		$ttc = array(); $avoirs = array();
		foreach ( $factures as $f ) {
			$m = (float) $f['montant_ttc'];
			if ( $m > 0 ) { $ttc[ (int) $f['id'] ] = $m; }
			elseif ( $m < 0 ) { $avoirs[] = $f; }
		}
		$out = array( 'par_facture' => array(), 'libres' => array() );
		if ( ! $avoirs ) { return $out; }
		$origines = array();
		try {
			$ids = array_map( function ( $f ) { return (int) $f['id']; }, $avoirs );
			$rows = FKC_DB::q(
				'SELECT id, avoir_origine_id FROM factures WHERE id IN (' . implode( ',', array_fill( 0, count( $ids ), '?' ) ) . ')',
				$ids
			)->fetchAll();
			foreach ( $rows as $r ) { $origines[ (int) $r['id'] ] = (int) $r['avoir_origine_id']; }
		} catch ( \Throwable $e ) { /* colonne absente : tous les avoirs restent libres */ }
		foreach ( $avoirs as $a ) {
			$montant = -(float) $a['montant_ttc'];
			$cid = (int) $a['client_id'];
			$o = $origines[ (int) $a['id'] ] ?? 0;
			$applique = 0.0;
			if ( $o && isset( $ttc[ $o ] ) ) {
				$ouvert = $ttc[ $o ] - (float) ( $imputes[ $o ] ?? 0 ) - (float) ( $out['par_facture'][ $o ] ?? 0 );
				$applique = min( $montant, max( 0.0, $ouvert ) );
				if ( $applique > 0 ) { $out['par_facture'][ $o ] = ( $out['par_facture'][ $o ] ?? 0.0 ) + $applique; }
			}
			$libre = $montant - $applique;
			if ( $libre > 0 ) { $out['libres'][ $cid ] = ( $out['libres'][ $cid ] ?? 0.0 ) + $libre; }
		}
		return $out;
	}

	/**
	 * Factures émises d'un client, dans l'ordre d'ancienneté.
	 *
	 * Même filtre que le moteur de recouvrement, et pour la même raison : une
	 * facture n'est une créance qu'une fois ÉMISE. Le statut ne suffit pas
	 * (le chemin ordinaire de la facturation ne le repassait pas), l'écriture
	 * comptable sert de second témoignage.
	 */
	protected static function facturesClient( $clientId, $asOf = null ) {
		$id  = (int) $clientId;
		$b   = $asOf ? ' AND date_facture <= ?' : '';
		$arg = $asOf ? array( $id, (string) $asOf ) : array( $id );
		$sql = "SELECT id,numero,client_id,date_facture,echeance,montant_ttc,statut
		        FROM factures
		        WHERE client_id = ?
		          AND ( statut IS NULL OR (
		                statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
		                AND ( LOWER(statut) NOT IN ('brouillon','devis','proforma')
		                      OR COALESCE(ecriture_id,0) <> 0 ) ) )" . $b . "
		        ORDER BY date_facture ASC, id ASC";
		try {
			return FKC_DB::q( $sql, $arg )->fetchAll();
		} catch ( \Throwable $e ) {
			// Base antérieure à la colonne de liaison comptable.
			return FKC_DB::q(
				"SELECT id,numero,client_id,date_facture,echeance,montant_ttc,statut
				 FROM factures
				 WHERE client_id = ?
				   AND ( statut IS NULL OR (
				         statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
				         AND LOWER(statut) NOT IN ('brouillon','devis','proforma') ) )" . $b . "
				 ORDER BY date_facture ASC, id ASC",
				$arg
			)->fetchAll();
		}
	}

	/**
	 * POSTE CLIENT DÉTAILLÉ — une ligne par facture ouverte.
	 *
	 * C'est la réponse à la question que l'écran d'encaissement posait mal :
	 * « que dois-je encaisser, et sur quoi ? ». L'ordre est celui de
	 * l'ancienneté, parce que c'est celui dans lequel on encaisse.
	 *
	 * @param int $clientId
	 * @return array{
	 *   client_id:int, factures:array, ouvertes:array, facture:float,
	 *   encaisse:float, solde:float, du:float, credit:float, nb_ouvertes:int
	 * }
	 */
	public static function postesClient( $clientId, $asOf = null ) {
		/*
		 * $asOf (1.854.0) : le poste client AU SOIR d'une date — ce que lit la
		 * balance âgée arrêtée. Sans date : aujourd'hui, comme avant.
		 */
		$id     = (int) $clientId;
		$today  = strtotime( $asOf ? (string) $asOf : date( 'Y-m-d' ) );
		$delai  = 0;
		$cli    = class_exists( 'FKC_Client' ) ? FKC_Client::find( $id ) : null;
		if ( $cli && isset( $cli['delai_paiement'] ) ) { $delai = max( 0, (int) $cli['delai_paiement'] ); }

		$factures = self::facturesClient( $id, $asOf );
		$ids      = array_map( function ( $f ) { return (int) $f['id']; }, $factures );
		$imputes  = self::parFacture( $ids, 'client', $asOf );

		// Encaissé TOTAL du client, toutes sources confondues (règlements de
		// la comptabilité + reçus du module Encaissement). C'est le même
		// périmètre que le moteur de recouvrement : deux chiffres différents
		// sur le même client seraient pires que pas de chiffre du tout.
		$solde    = class_exists( 'FKC_Reglement' ) ? FKC_Reglement::soldeClient( $id, $asOf ) : array( 'facture' => 0, 'encaisse' => 0, 'solde' => 0 );
		$encaisse = (float) $solde['encaisse'];

		// Avoirs : montants négatifs. Ils ne sont jamais des postes à
		// encaisser ; ceux qui désignent leur facture d'origine l'éteignent
		// elle, le reste rejoint le pool (1.841.1).
		$affect = self::avoirsAffectes( $factures, $imputes );
		$avoirs = (float) array_sum( $affect['libres'] );

		// Le pool FIFO ne porte QUE ce qui n'a pas été imputé nommément.
		$totalImpute = 0.0;
		foreach ( $imputes as $m ) { $totalImpute += (float) $m; }
		$pool = $encaisse + $avoirs - $totalImpute;

		$lignes = array(); $ouvertes = array(); $du = 0.0; $totalFacture = 0.0;
		foreach ( $factures as $f ) {
			$ttc = (float) $f['montant_ttc'];
			$totalFacture += $ttc;
			if ( $ttc <= 0 ) { continue; } // avoir : déjà versé au pool de crédit

			$fid    = (int) $f['id'];
			$impute = (float) ( $imputes[ $fid ] ?? 0.0 );
			$avoir  = (float) ( $affect['par_facture'][ $fid ] ?? 0.0 );
			$base   = $ttc - $impute - $avoir;     // ce que l'imputation nommée et l'avoir laissent ouvert
			$fifo   = 0.0;
			if ( $base > 0 && $pool > 0 ) {
				$fifo  = min( $pool, $base );
				$pool -= $fifo;
			}
			$reste  = round( $base - $fifo, 2 );
			$ech    = ! empty( $f['echeance'] ) ? $f['echeance'] : date( 'Y-m-d', strtotime( $f['date_facture'] . ' +' . $delai . ' day' ) );
			$jours  = (int) floor( ( $today - strtotime( $ech ) ) / 86400 );

			$ligne = array(
				'id'           => $fid,
				'numero'       => (string) ( $f['numero'] ?? ( '#' . $fid ) ),
				'date_facture' => $f['date_facture'],
				'echeance'     => $ech,
				'ttc'          => round( $ttc, 2 ),
				'impute'       => round( $impute, 2 ),
				'fifo'         => round( $fifo, 2 ),
				'avoir'        => round( $avoir, 2 ),
				'regle'        => round( $impute + $fifo + $avoir, 2 ),
				'reste'        => $reste,
				'jours'        => $jours,
				'retard'       => $jours > 0,
				'soldee'       => $reste <= self::EPSILON,
			);
			$lignes[] = $ligne;
			if ( $reste > self::EPSILON ) { $ouvertes[] = $ligne; $du += $reste; }
		}

		return array(
			'client_id'   => $id,
			'factures'    => $lignes,
			'ouvertes'    => $ouvertes,
			'nb_ouvertes' => count( $ouvertes ),
			'facture'     => round( $totalFacture, 2 ),
			'encaisse'    => round( $encaisse, 2 ),
			'solde'       => round( (float) $solde['solde'], 2 ),
			'du'          => round( $du, 2 ),
			// Crédit resté sans emploi : avance reçue, double saisie, ou
			// encaissement sans facture derrière. On le publie, on ne le
			// corrige pas — c'est au poste d'anomalies de l'expliquer.
			'credit'      => round( max( 0.0, $pool ), 2 ),
		);
	}

	/**
	 * POSTE FOURNISSEUR DÉTAILLÉ — une ligne par facture d'achat ouverte.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LE MÊME DÉFAUT QU'AU CLIENT, DE L'AUTRE CÔTÉ DU BILAN
	 *
	 * L'écran « Comptabilité · Fournisseurs » ne posait qu'une question :
	 * « combien a-t-on payé à ce fournisseur ? ». Jamais « laquelle de ses
	 * factures ». Le règlement n'était rattaché qu'au tiers, et la dette se
	 * reconstituait par un lettrage FIFO — le plus ancien d'abord.
	 *
	 * Ce repli est faux dès que l'on choisit ce que l'on paie, ce qui est le
	 * cas ordinaire à l'achat : on règle la facture de mars parce que la
	 * livraison de janvier est contestée, ou parce qu'un escompte court sur
	 * celle-là. Le FIFO éteignait janvier, laissait mars ouverte, et la
	 * relance du fournisseur portait sur une facture déjà payée.
	 *
	 * On n'invente pas un second moteur : c'est la mécanique du client,
	 * appliquée à l'autre sens, avec les imputations nommées d'abord et le
	 * FIFO pour le seul reliquat.
	 *
	 * @return array{fournisseur_id:int,factures:array,ouvertes:array,facture:float,paye:float,du:float,credit:float,nb_ouvertes:int}
	 */
	public static function postesFournisseur( $fournisseurId, $asOf = null ) {
		$id    = (int) $fournisseurId;
		$today = strtotime( $asOf ? (string) $asOf : date( 'Y-m-d' ) );

		$factures = FKC_DB::q(
			"SELECT id,numero,reference,date_facture,date_echeance,montant_ttc,statut
			 FROM factures_fournisseurs
			 WHERE fournisseur_id=? AND statut!='annulee'" . ( $asOf ? ' AND date_facture<=?' : '' ) . "
			 ORDER BY date_facture ASC, id ASC",
			$asOf ? array( $id, (string) $asOf ) : array( $id )
		)->fetchAll();

		$ids     = array_map( function ( $f ) { return (int) $f['id']; }, $factures );
		$imputes = self::parFacture( $ids, 'fournisseur', $asOf );
		$paye    = class_exists( 'FKC_Fournisseur' ) ? (float) FKC_Fournisseur::totalPaye( $id, $asOf ) : 0.0;

		$totalImpute = 0.0;
		foreach ( $imputes as $m ) { $totalImpute += (float) $m; }
		$pool = $paye - $totalImpute;

		$lignes = array(); $ouvertes = array(); $du = 0.0; $totalFacture = 0.0;
		foreach ( $factures as $f ) {
			$ttc = (float) $f['montant_ttc'];
			$totalFacture += $ttc;
			if ( $ttc <= 0 ) { continue; }

			$fid    = (int) $f['id'];
			$impute = (float) ( $imputes[ $fid ] ?? 0.0 );
			$base   = $ttc - $impute;
			$fifo   = 0.0;
			if ( $base > 0 && $pool > 0 ) { $fifo = min( $pool, $base ); $pool -= $fifo; }
			$reste = round( $base - $fifo, 2 );

			// À l'achat, l'échéance est celle que le FOURNISSEUR a fixée. Sans
			// elle, la facture est exigible à sa date : on ne lui invente pas
			// un délai que personne n'a accordé.
			$ech   = ! empty( $f['date_echeance'] ) ? (string) $f['date_echeance'] : (string) $f['date_facture'];
			$jours = (int) floor( ( $today - strtotime( $ech ) ) / 86400 );

			$ligne = array(
				'id'           => $fid,
				'numero'       => (string) ( $f['numero'] ?? ( '#' . $fid ) ),
				'reference'    => (string) ( $f['reference'] ?? '' ),
				'date_facture' => $f['date_facture'],
				'echeance'     => $ech,
				'ttc'          => round( $ttc, 2 ),
				'impute'       => round( $impute, 2 ),
				'fifo'         => round( $fifo, 2 ),
				'regle'        => round( $impute + $fifo, 2 ),
				'reste'        => $reste,
				'jours'        => $jours,
				'retard'       => $jours > 0,
				'soldee'       => $reste <= self::EPSILON,
			);
			$lignes[] = $ligne;
			if ( $reste > self::EPSILON ) { $ouvertes[] = $ligne; $du += $reste; }
		}

		return array(
			'fournisseur_id' => $id,
			'factures'       => $lignes,
			'ouvertes'       => $ouvertes,
			'nb_ouvertes'    => count( $ouvertes ),
			'facture'        => round( $totalFacture, 2 ),
			'paye'           => round( $paye, 2 ),
			'du'             => round( $du, 2 ),
			// Payé sans facture en face : avance versée, double saisie, ou
			// facture pas encore enregistrée. On le publie, on ne le corrige pas.
			'credit'         => round( max( 0.0, $pool ), 2 ),
		);
	}

	/**
	 * FACTURES FOURNISSEURS ÉCHUES ET RÉELLEMENT NON RÉGLÉES (1.777.0).
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * CE QUE CETTE MÉTHODE REMPLACE
	 *
	 * Maestro lisait `factures_fournisseurs.statut = 'a_payer'`. Or ce
	 * statut est posé à la création et N'EST JAMAIS MIS À JOUR par un
	 * paiement — la 1.745.0 l'avait constaté pour les listes, qui calculent
	 * désormais leur état ; Maestro, lui, lisait encore la colonne. Toute
	 * facture échue restait donc « impayée » pour toujours, et l'alerte ne
	 * pouvait pas s'éteindre, quoi qu'on paie.
	 *
	 * On lit ici la MÊME chose que l'écran de paiement fournisseur :
	 * imputations nommées, puis FIFO. Et, par fournisseur, on plafonne au
	 * solde exigible du GRAND LIVRE auxiliaire : un règlement passé par une
	 * écriture de banque directe (sans fiche de règlement) éteint la dette
	 * au grand livre, et doit éteindre l'alerte aussi.
	 * ─────────────────────────────────────────────────────────────────────
	 *
	 * @return array{nb:int,montant:float,fournisseurs:array}
	 */
	public static function echuesFournisseurs() {
		$nb = 0; $montant = 0.0; $parTiers = array();
		try {
			$tiers = FKC_DB::q(
				"SELECT DISTINCT fournisseur_id FROM factures_fournisseurs
				  WHERE statut NOT LIKE 'annul%' AND fournisseur_id IS NOT NULL AND fournisseur_id > 0"
			)->fetchAll();
		} catch ( \Throwable $e ) { $tiers = array(); }

		/*
		 * Un statut « payée » EXPLICITE est honoré. L'application ne le pose
		 * pas elle-même, mais un import ou une reprise de données peut le
		 * faire sans créer de règlement : lui opposer le FIFO signalerait
		 * comme impayée une facture que le dossier déclare réglée.
		 * (Trouvé par maestro_experts_lot8_1599.)
		 */
		$declareesPayees = array();
		try {
			foreach ( FKC_DB::q(
				"SELECT id FROM factures_fournisseurs WHERE LOWER(statut) IN ('payee','payée','paye','payé','soldee','soldée','reglee','réglée')"
			)->fetchAll() as $r ) { $declareesPayees[ (int) $r['id'] ] = true; }
		} catch ( \Throwable $e ) {}

		foreach ( $tiers as $t ) {
			$id = (int) $t['fournisseur_id'];
			try { $p = self::postesFournisseur( $id ); } catch ( \Throwable $e ) { continue; }
			$echues = array_filter( $p['ouvertes'], function ( $l ) use ( $declareesPayees ) {
				return ! empty( $l['retard'] ) && ! isset( $declareesPayees[ (int) $l['id'] ] );
			} );
			if ( ! $echues ) { continue; }
			$reste = 0.0;
			foreach ( $echues as $l ) { $reste += (float) $l['reste']; }

			// Plafond du grand livre, seulement s'il porte le compte du tiers.
			if ( class_exists( 'FKC_Reglement' ) ) {
				try {
					$gl = FKC_Reglement::soldeFournisseur( $id );
					if ( (float) $gl['du'] > self::EPSILON ) { $reste = min( $reste, max( 0.0, (float) $gl['exigible'] ) ); }
				} catch ( \Throwable $e ) {}
			}
			if ( $reste <= self::EPSILON ) { continue; }
			$nb += count( $echues );
			$montant += $reste;
			$parTiers[ $id ] = round( $reste, 2 );
		}

		// Factures sans fiche fournisseur : seules les imputations nommées
		// peuvent les éteindre — le FIFO n'a pas de tiers sur lequel jouer.
		try {
			$orph = FKC_DB::q(
				"SELECT id, montant_ttc, COALESCE(NULLIF(TRIM(date_echeance),''), date_facture) ech
				   FROM factures_fournisseurs
				  WHERE statut NOT LIKE 'annul%' AND (fournisseur_id IS NULL OR fournisseur_id = 0) AND montant_ttc > 0"
			)->fetchAll();
		} catch ( \Throwable $e ) { $orph = array(); }
		if ( $orph ) {
			$imp = self::parFacture( array_map( function ( $r ) { return (int) $r['id']; }, $orph ), 'fournisseur' );
			foreach ( $orph as $r ) {
				if ( isset( $declareesPayees[ (int) $r['id'] ] ) ) { continue; }
				if ( strtotime( (string) $r['ech'] ) >= strtotime( date( 'Y-m-d' ) ) ) { continue; }
				$reste = (float) $r['montant_ttc'] - (float) ( $imp[ (int) $r['id'] ] ?? 0 );
				if ( $reste > self::EPSILON ) { $nb++; $montant += $reste; }
			}
		}
		return array( 'nb' => $nb, 'montant' => round( $montant, 2 ), 'fournisseurs' => $parTiers );
	}

	/**
	 * ÉTAT DE PAIEMENT de chaque facture d'une liste (1.745.0).
	 *
	 * Les listes n'affichaient qu'un statut stocké : côté achats, « À payer »
	 * n'était jamais remplacé par « Payée » ; côté ventes, rien. Le reste dû
	 * se calcule — imputations nommées puis FIFO — exactement comme sur
	 * l'écran d'encaissement ou de paiement. Un règlement annulé n'y compte
	 * plus : la facture qu'il soldait se lit de nouveau « à payer ».
	 *
	 * @param array  $rows  Lignes de factures (id + client_id | fournisseur_id).
	 * @param string $type  'client' | 'fournisseur'
	 * @return array<int, array{etat:string, regle:float, reste:float}>
	 *         etat : payee | partielle | a_payer | sans_objet
	 */
	public static function etatsPaiement( array $rows, $type = 'client' ) {
		$fournisseur = 'fournisseur' === $type;
		$col = $fournisseur ? 'fournisseur_id' : 'client_id';
		$tiers = array();
		foreach ( $rows as $r ) { if ( ! empty( $r[ $col ] ) ) { $tiers[ (int) $r[ $col ] ] = true; } }
		$postes = array();
		foreach ( array_keys( $tiers ) as $tid ) {
			try {
				$p = $fournisseur ? self::postesFournisseur( $tid ) : self::postesClient( $tid );
				foreach ( $p['factures'] as $l ) { $postes[ (int) $l['id'] ] = $l; }
			} catch ( \Throwable $e ) {}
		}
		$out = array();
		foreach ( $rows as $r ) {
			$id = (int) $r['id'];
			$st = strtolower( (string) ( $r['statut'] ?? '' ) );
			if ( 0 === strpos( $st, 'annul' ) || (float) ( $r['montant_ttc'] ?? 0 ) <= 0 || ! isset( $postes[ $id ] ) ) {
				$out[ $id ] = array( 'etat' => 'sans_objet', 'regle' => 0.0, 'reste' => 0.0 );
				continue;
			}
			$l = $postes[ $id ];
			$etat = $l['reste'] <= self::EPSILON ? 'payee' : ( $l['regle'] > self::EPSILON ? 'partielle' : 'a_payer' );
			$out[ $id ] = array( 'etat' => $etat, 'regle' => (float) $l['regle'], 'reste' => (float) $l['reste'] );
		}
		return $out;
	}

	/**
	 * Répartition FIFO d'un montant sur des postes ouverts.
	 *
	 * Sert de proposition à l'écran d'encaissement : l'utilisateur la voit,
	 * la modifie, ou la remplace. Rien n'est imputé sans qu'il ait regardé.
	 *
	 * @param array $ouvertes Postes issus de postesClient()['ouvertes'].
	 * @param float $montant  Somme encaissée.
	 * @return array facture_id => montant affecté
	 */
	public static function repartir( $ouvertes, $montant ) {
		$reste = round( (float) $montant, 2 );
		$out   = array();
		foreach ( (array) $ouvertes as $p ) {
			if ( $reste <= self::EPSILON ) { break; }
			$part = min( $reste, (float) $p['reste'] );
			if ( $part <= 0 ) { continue; }
			$out[ (int) $p['id'] ] = round( $part, 2 );
			$reste -= $part;
		}
		return $out;
	}
}
