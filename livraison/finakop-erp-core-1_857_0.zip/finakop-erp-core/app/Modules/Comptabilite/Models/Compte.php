<?php
/** Plan comptable SYSCOHADA. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Compte {
	public static function all() {
		return FKC_DB::q( 'SELECT * FROM comptes ORDER BY numero ASC' )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM comptes WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function byNumero( $numero ) {
		$numero = trim( (string) $numero );
		$r = FKC_DB::q( 'SELECT * FROM comptes WHERE numero=?', array( $numero ) )->fetch();
		if ( ! $r && strlen( $numero ) > 0 && strlen( $numero ) < 6 ) {
			// Plan comptable à 6 caractères : complément par des zéros (411 -> 411000).
			$r = FKC_DB::q( 'SELECT * FROM comptes WHERE numero=?', array( str_pad( $numero, 6, '0' ) ) )->fetch();
		}
		return $r ?: null;
	}
	/**
	 * Crée un compte de société.
	 *
	 * Le rattachement au compte OHADA parent est calculé, pas demandé : un
	 * utilisateur qui ouvre 706150 « ventes de podcasts » n'a pas à savoir que
	 * cela relève de 706 « Services vendus ». Le savoir, c'est le travail du
	 * référentiel ; le déduire garantit que le montant remonte au bon endroit
	 * dans la liasse même quand personne n'y a pensé.
	 */
	public static function create( $numero, $libelle, $type = 'detail', $origine = 'societe', $pack = null ) {
		$numero = FKC_PlanSyscohada::normaliser( $numero );
		FKC_DB::q(
			'INSERT INTO comptes(numero,libelle,classe,type,origine,pack,parent,sens,lettrable,verrouille) VALUES(?,?,?,?,?,?,?,?,?,?)',
			array(
				$numero, $libelle, (int) substr( $numero, 0, 1 ), $type, $origine, $pack,
				FKC_PlanSyscohada::parentOfficiel( $numero ),
				FKC_PlanSyscohada::sensNaturel( $numero ),
				FKC_PlanSyscohada::lettrable( $numero ) ? 1 : 0,
				( 'ohada' === $origine ) ? 1 : 0,
			)
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	public static function update( $id, $libelle, $type = 'detail' ) {
		FKC_DB::q( 'UPDATE comptes SET libelle=?,type=? WHERE id=?', array( $libelle, $type, (int) $id ) );
	}

	public static function setActif( $id, $actif ) {
		FKC_DB::q( 'UPDATE comptes SET actif=? WHERE id=?', array( $actif ? 1 : 0, (int) $id ) );
	}

	/** Nombre de lignes d'écriture portées par ce compte. */
	public static function nbEcritures( $id ) {
		try { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM ecriture_lignes WHERE compte_id=?', array( (int) $id ) )->fetchColumn(); }
		catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Retire un compte du plan.
	 *
	 * La suppression sèche laissait derrière elle des lignes d'écriture
	 * pointant un compte_id disparu : le grand livre citait un compte
	 * introuvable et la balance ne bouclait plus, sans le moindre message. Un
	 * compte MOUVEMENTÉ est désormais désactivé, jamais effacé ; un compte
	 * réglementaire ne s'efface pas non plus, il se désactive.
	 *
	 * @return array{0:bool,1:string,2:string} ok, message, action
	 */
	public static function delete( $id ) {
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Compte introuvable.', 'aucune' ); }

		$n = self::nbEcritures( $id );
		if ( $n > 0 ) {
			self::setActif( $id, 0 );
			return array( true, 'Compte ' . $c['numero'] . ' désactivé plutôt que supprimé : il porte ' . $n
				. ' ligne(s) d\'écriture. L\'effacer rendrait le grand livre et la balance incohérents.', 'archive' );
		}
		if ( ! empty( $c['verrouille'] ) || 'ohada' === ( $c['origine'] ?? '' ) ) {
			self::setActif( $id, 0 );
			return array( true, 'Compte réglementaire ' . $c['numero'] . ' désactivé : il reste dans le plan, '
				. 'car le référentiel SYSCOHADA ne se soustrait pas.', 'archive' );
		}
		FKC_DB::q( 'DELETE FROM comptes WHERE id=?', array( (int) $id ) );
		return array( true, 'Compte ' . $c['numero'] . ' supprimé : il n\'avait jamais servi.', 'supprime' );
	}
}
