<?php
/**
 * Grand livre auxiliaire des tiers (clients / fournisseurs).
 * Le tiers de chaque écriture est dérivé des pièces sources (factures, factures
 * fournisseurs, règlements) via leur lien ecriture_id — aucune dénormalisation requise.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_GrandLivreTiers {

	/** Préfixe du compte collectif selon le type de tiers (SYSCOHADA : 41 clients, 40 fournisseurs). */
	protected static function comptePrefix( $type ) {
		return 'fournisseur' === $type ? '40' : '41';
	}

	/**
	 * Sous-requête CTE associant chaque écriture à son tiers (type + id).
	 *
	 * Exposée publiquement (tmapPub) parce que les notes annexes de la liasse
	 * ont besoin de la MÊME correspondance pour ventiler ventes et achats par
	 * zone du tiers. En écrire une seconde serait s'exposer à ce qu'elles
	 * divergent — et à ce que la note et le grand livre auxiliaire ne
	 * désignent plus le même tiers pour la même écriture.
	 */
	public static function tmapPub() { return self::tmapSql(); }

	/** Sous-requête CTE associant chaque écriture à son tiers (type + id). */
	protected static function tmapSql() {
		return "tmap AS (
			SELECT ecriture_id AS eid, 'client' AS ttype, client_id AS tid FROM factures WHERE ecriture_id IS NOT NULL AND client_id IS NOT NULL
			UNION ALL
			SELECT ecriture_id, 'fournisseur', fournisseur_id FROM factures_fournisseurs WHERE ecriture_id IS NOT NULL AND fournisseur_id IS NOT NULL
			UNION ALL
			SELECT ecriture_id, tiers_type, tiers_id FROM reglements WHERE ecriture_id IS NOT NULL AND tiers_type IN ('client','fournisseur') AND tiers_id IS NOT NULL
		)";
	}

	/**
	 * Expression du tiers d'une LIGNE.
	 *
	 * LE TIERS PORTÉ PAR LA LIGNE PRIME SUR CELUI DE LA PIÈCE (1.538.0).
	 *
	 * Le grand livre auxiliaire ne dérivait le tiers que des pièces
	 * (factures, factures fournisseurs, règlements) par leur `ecriture_id`.
	 * Or `ecriture_lignes` porte depuis longtemps ses propres colonnes
	 * `tiers_type`/`tiers_id`, que FKC_Posting renseigne dès qu'un schéma
	 * marque une ligne « 'tiers' => true » — c'est même ce qui, d'après son
	 * propre commentaire, « rend le solde 401/411 attribuable, donc apurable
	 * par un règlement ».
	 *
	 * Personne ne les lisait ici. Conséquence : toutes les écritures
	 * auxiliarisées par les packs — cotisation d'un adhérent, dette envers un
	 * producteur de la coopérative, créance sur un bailleur d'ONG — étaient
	 * ABSENTES du grand livre auxiliaire. Donc invisibles à la balance âgée,
	 * et impossibles à lettrer : leur solde ne s'apurait jamais, alors même
	 * que le règlement existait.
	 *
	 * COALESCE et non une seconde jointure : ajouter les lignes tierçées à la
	 * table de correspondance aurait DÉDOUBLÉ toute écriture portant à la fois
	 * un tiers de ligne et une pièce — le solde auxiliaire aurait compté deux
	 * fois les mêmes montants. Ici, chaque ligne n'a qu'un tiers : le sien
	 * s'il en a un, celui de sa pièce sinon.
	 */
	protected static function tiersType() { return 'COALESCE(l.tiers_type, m.ttype)'; }
	protected static function tiersId()   { return 'COALESCE(l.tiers_id, m.tid)'; }

	/** Construit la clause WHERE + paramètres communs. $opts: tiers_id, from, to, lettrage(all|lettre|nonlettre), q. */
	protected static function where( $type, $opts, $withPeriod = true ) {
		$w = array( "c.numero LIKE ?", self::tiersType() . "=?" );
		$p = array( self::comptePrefix( $type ) . '%', $type );
		/*
		 * CAST, et non comparaison directe (1.798.0) : COALESCE() rend une
		 * expression SANS affinité de colonne, et PDO lie le paramètre en
		 * texte. En SQLite, 11 = '11' est alors FAUX : le grand livre d'un
		 * tiers porté par la ligne d'écriture — À-nouveaux détaillés par
		 * tiers, écritures des packs — sortait vide.
		 */
		if ( ! empty( $opts['tiers_id'] ) ) { $w[] = 'CAST(' . self::tiersId() . ' AS INTEGER)=?'; $p[] = (int) $opts['tiers_id']; }
		if ( $withPeriod ) {
			if ( ! empty( $opts['from'] ) ) { $w[] = 'e.date_ecriture>=?'; $p[] = $opts['from']; }
			if ( ! empty( $opts['to'] ) )   { $w[] = 'e.date_ecriture<=?'; $p[] = $opts['to']; }
			/*
			 * Les À-nouveaux des exercices commencés après le début de la
			 * période reprennent des soldes déjà présents : les lire en
			 * mouvement doublerait le solde du tiers (1.798.0).
			 */
			if ( class_exists( 'FKC_SoldeOuverture' ) ) {
				$excl = FKC_SoldeOuverture::anAExclure( FKC_SoldeOuverture::duEffectif( $opts['from'] ?? null ), $opts['to'] ?? null );
				if ( $excl ) { $w[] = 'e.id NOT IN (' . implode( ',', array_map( 'intval', $excl ) ) . ')'; }
			}
			$let = $opts['lettrage'] ?? 'all';
			if ( 'lettre' === $let )    { $w[] = "l.lettre IS NOT NULL AND l.lettre<>''"; }
			if ( 'nonlettre' === $let ) { $w[] = "(l.lettre IS NULL OR l.lettre='')"; }
			if ( ! empty( $opts['q'] ) ) {
				$w[] = '(l.libelle LIKE ? OR e.piece LIKE ?)';
				$p[] = '%' . $opts['q'] . '%'; $p[] = '%' . $opts['q'] . '%';
			}
		}
		return array( implode( ' AND ', $w ), $p );
	}

	/** Lignes du grand livre auxiliaire (avec solde progressif). */
	public static function lignes( $type, $opts = array() ) {
		list( $where, $params ) = self::where( $type, $opts, true );
		$sql = 'WITH ' . self::tmapSql() . '
			SELECT l.id AS ligne_id, e.date_ecriture AS date, e.piece, j.code AS journal,
			       COALESCE(NULLIF(l.libelle,\'\'), e.libelle) AS libelle,
			       l.debit, l.credit, l.lettre, COALESCE(l.tiers_id, m.tid) AS tiers_id, c.numero AS compte
			FROM ecriture_lignes l
			JOIN ecritures e ON e.id=l.ecriture_id
			JOIN journaux  j ON j.id=e.journal_id
			JOIN comptes   c ON c.id=l.compte_id
			LEFT JOIN tmap m ON m.eid=e.id
			WHERE ' . $where . '
			ORDER BY e.date_ecriture ASC, l.id ASC';
		$rows = FKC_DB::q( $sql, $params )->fetchAll();

		$noms = self::nomsMap( $type );
		$solde = self::soldeInitial( $type, $opts );
		$out = array();
		foreach ( $rows as $r ) {
			$solde += (float) $r['debit'] - (float) $r['credit'];
			$r['tiers_nom'] = $noms[ (int) $r['tiers_id'] ] ?? ( 'client' === $type ? 'Client' : 'Fournisseur' );
			$r['solde'] = round( $solde, 2 );
			$out[] = $r;
		}
		return $out;
	}

	/**
	 * Solde d'ouverture du tiers à la date `from`, filtré par tiers le cas échéant.
	 *
	 * Lu par le gestionnaire des À-nouveaux (1.798.0) : l'ancien cumul
	 * « tout ce qui précède » relisait les À-nouveaux de chaque exercice
	 * par-dessus les soldes qu'ils reprennent.
	 */
	public static function soldeInitial( $type, $opts ) {
		if ( empty( $opts['from'] ) ) { return 0.0; }
		list( $where, $params ) = self::where( $type, array( 'tiers_id' => $opts['tiers_id'] ?? null ), false );
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			list( $ca, $pa ) = FKC_SoldeOuverture::clauseAvant( $opts['from'] );
			$where .= ' AND ' . $ca; $params = array_merge( $params, $pa );
		} else {
			$where .= ' AND e.date_ecriture < ?'; $params[] = $opts['from'];
		}
		$sql = 'WITH ' . self::tmapSql() . '
			SELECT COALESCE(SUM(l.debit-l.credit),0) AS s
			FROM ecriture_lignes l
			JOIN ecritures e ON e.id=l.ecriture_id
			JOIN comptes   c ON c.id=l.compte_id
			LEFT JOIN tmap m ON m.eid=e.id
			WHERE ' . $where;
		return (float) FKC_DB::q( $sql, $params )->fetch()['s'];
	}

	/** Totaux débit/crédit/solde de la période (hors report). */
	public static function totaux( $lignes, $soldeInitial = 0.0 ) {
		$d = 0; $cr = 0;
		foreach ( $lignes as $l ) { $d += (float) $l['debit']; $cr += (float) $l['credit']; }
		return array(
			'debit' => round( $d, 2 ), 'credit' => round( $cr, 2 ),
			'solde' => round( $soldeInitial + $d - $cr, 2 ),
		);
	}

	/** Noms des tiers (id → nom). */
	protected static function nomsMap( $type ) {
		$map = array();
		$table = 'fournisseur' === $type ? 'fournisseurs' : 'clients';
		foreach ( FKC_DB::q( "SELECT id,nom FROM {$table}" )->fetchAll() as $r ) { $map[ (int) $r['id'] ] = $r['nom']; }
		return $map;
	}

	/** Liste des tiers pour le filtre (id, nom, code). */
	public static function tiersOptions( $type ) {
		$table = 'fournisseur' === $type ? 'fournisseurs' : 'clients';
		return FKC_DB::q( "SELECT id,nom,code FROM {$table} ORDER BY nom COLLATE NOCASE" )->fetchAll();
	}
}
