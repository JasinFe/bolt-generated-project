<?php
/**
 * Annulation d'UNE écriture désignée par son numéro.
 *
 * La purge de période existante répond à « je repars d'une base propre ».
 * Elle ne répond pas à « je me suis trompé sur cette écriture-là » — et
 * l'utiliser pour ça oblige à choisir une plage d'un jour, qui emporte au
 * passage toutes les autres écritures de la journée. D'où ce module.
 *
 * Deux voies, et le choix n'est pas cosmétique :
 *
 *   • CONTRE-PASSATION (voie normale) — une écriture inverse est générée à la
 *     date du jour. L'écriture d'origine reste lisible, le solde revient à sa
 *     valeur d'avant, et la piste d'audit montre l'erreur ET sa correction.
 *     C'est la seule voie admissible dès que l'écriture a été publiée,
 *     lettrée, rattachée à une pièce ou incluse dans une période clôturée.
 *
 *   • SUPPRESSION DÉFINITIVE (voie exceptionnelle) — la ligne disparaît. Ne
 *     doit servir qu'à une écriture qui n'aurait jamais dû exister (saisie de
 *     test, doublon constaté le jour même) et que rien ne référence. Le code
 *     refuse tout le reste plutôt que de faire confiance à l'utilisateur.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EcritureAnnulation {

	/** Marqueur porté par la contre-passation, qui la relie à sa source. */
	const MARQUEUR = 'ANN#';

	/* ── Recherche ────────────────────────────────────────────────────────── */

	/**
	 * Retrouve les écritures correspondant à un numéro saisi.
	 *
	 * Le numéro de pièce n'est pas unique : deux journaux, deux exercices
	 * peuvent porter la même. On renvoie donc TOUTES les correspondances et
	 * c'est l'utilisateur qui désigne la bonne — jamais un choix implicite.
	 *
	 * @param string $numero Numéro de pièce, référence, ou identifiant interne.
	 * @return array Lignes enrichies (journal, total, analyse).
	 */
	public static function rechercher( $numero, $limit = 25 ) {
		$n = trim( (string) $numero );
		if ( '' === $n ) { return array(); }

		/*
		 * La recherche accepte désormais le NUMÉRO COMPTABLE, sous ses deux
		 * formes : « 26000001 » (qui peut désigner une écriture par journal) et
		 * « AC-26000001 » (qui n'en désigne qu'une). C'est la référence que
		 * portent les états et que citera un contrôleur — la chercher devait
		 * être possible.
		 */
		$numero = $n;
		$codeJournal = '';
		if ( preg_match( '/^([A-Za-z]{1,4})[\s\-\/]?(\d{8})$/', $n, $mm ) ) {
			$codeJournal = strtoupper( $mm[1] );
			$numero      = $mm[2];
		}

		$sql = "SELECT e.*, j.code journal_code, j.libelle journal_libelle,
		               COALESCE((SELECT SUM(debit) FROM ecriture_lignes WHERE ecriture_id=e.id),0) total
		        FROM ecritures e LEFT JOIN journaux j ON j.id=e.journal_id
		        WHERE e.piece = ? OR e.reference = ? OR e.id = ? OR e.piece LIKE ?
		           OR ( e.numero = ? AND ( ? = '' OR j.code = ? ) )
		        ORDER BY e.date_ecriture DESC, e.id DESC LIMIT " . (int) $limit;
		try {
			$rows = FKC_DB::q( $sql, array( $n, $n, (int) $n, '%' . $n . '%', $numero, $codeJournal, $codeJournal ) )->fetchAll();
		} catch ( \Throwable $ex ) {
			fkc_log( 'EcritureAnnulation::rechercher ' . $ex->getMessage(), 'ERROR' );
			return array();
		}

		foreach ( $rows as &$r ) { $r['analyse'] = self::analyser( (int) $r['id'] ); }
		unset( $r );
		return $rows;
	}

	/** Une écriture avec son journal et son total. */
	public static function find( $id ) {
		try {
			return FKC_DB::q(
				"SELECT e.*, j.code journal_code,
				        COALESCE((SELECT SUM(debit) FROM ecriture_lignes WHERE ecriture_id=e.id),0) total
				 FROM ecritures e LEFT JOIN journaux j ON j.id=e.journal_id WHERE e.id=?",
				array( (int) $id )
			)->fetch() ?: null;
		} catch ( \Throwable $ex ) { return null; }
	}

	/* ── Analyse préalable ────────────────────────────────────────────────── */

	protected static function compte( $sql, $args = array() ) {
		try { return (int) FKC_DB::q( $sql, $args )->fetchColumn(); } catch ( \Throwable $ex ) { return 0; }
	}

	/**
	 * Ce qui rattache l'écriture au reste du système. Calculé AVANT d'agir :
	 * l'utilisateur doit voir ce qu'il retire, et le code doit pouvoir dire
	 * non sans avoir à deviner.
	 *
	 * @return array{ecriture:?array,lignes:array,supprimable:bool,contrepassable:bool,
	 *               deja_annulee:?int,raisons:array,blocages:array}
	 */
	public static function analyser( $id ) {
		$id = (int) $id;
		$e  = self::find( $id );
		if ( ! $e ) {
			return array( 'ecriture' => null, 'lignes' => array(), 'supprimable' => false,
				'contrepassable' => false, 'deja_annulee' => null,
				'raisons' => array( 'Écriture introuvable.' ), 'blocages' => array( 'introuvable' ) );
		}

		$lignes = array();
		try {
			$lignes = FKC_DB::q(
				"SELECT l.*, c.numero compte_numero, c.libelle compte_libelle
				 FROM ecriture_lignes l LEFT JOIN comptes c ON c.id=l.compte_id
				 WHERE l.ecriture_id=? ORDER BY l.ordre, l.id", array( $id )
			)->fetchAll();
		} catch ( \Throwable $ex ) { fkc_log( 'EcritureAnnulation::analyser ' . $ex->getMessage(), 'ERROR' ); }

		$raisons = array(); $blocages = array();

		// 1. Période clôturée. Rouvrir une période close par une suppression
		//    silencieuse rendrait la clôture mensongère.
		if ( class_exists( 'FKC_Cloture' ) && FKC_Cloture::isLocked( $e['date_ecriture'] ) ) {
			$raisons[]  = 'La période du ' . $e['date_ecriture'] . ' est clôturée.';
			$blocages[] = 'cloture';
		}

		// 2. Lignes lettrées : le lettrage rapproche cette écriture d'un
		//    règlement. La supprimer laisserait le lettrage pointer dans le vide.
		$n = self::compte( "SELECT COUNT(*) FROM ecriture_lignes WHERE ecriture_id=? AND lettre IS NOT NULL AND lettre<>''", array( $id ) );
		if ( $n ) { $raisons[] = $n . ' ligne(s) lettrée(s).'; $blocages[] = 'lettrage'; }

		// 3. Pièces qui désignent cette écriture comme leur comptabilisation.
		//    La liste vient de FKC_EcritureLiens : elle couvre les 16 tables
		//    porteuses d'un `ecriture_id`, et non les 6 codées en dur ici
		//    auparavant — dont `factures`, qui n'a même pas cette colonne. Des
		//    écritures référencées par un reçu, un mouvement de stock ou une
		//    déclaration de TVA étaient donc supprimables sans le moindre
		//    avertissement.
		$verrouContrepassation = false;
		if ( class_exists( 'FKC_EcritureLiens' ) ) {
			foreach ( FKC_EcritureLiens::dependances( $id ) as $dep ) {
				$raisons[]  = $dep['nombre'] . ' ' . $dep['libelle'] . '.';
				$blocages[] = 'pieces';
				if ( ! empty( $dep['verrou'] ) ) {
					$verrouContrepassation = true;
					$blocages[]            = 'verrou';
				}
			}
		}

		// 4. Justificatifs attachés.
		$n = self::compte( "SELECT COUNT(*) FROM pieces_jointes WHERE source_type='ecriture' AND source_id=?", array( $id ) );
		if ( $n ) { $raisons[] = $n . ' justificatif(s) attaché(s).'; $blocages[] = 'justificatifs'; }

		// 5. Contre-passation déjà passée ? On ne l'annule pas deux fois.
		$deja = null;
		try {
			$r = FKC_DB::q( 'SELECT id FROM ecritures WHERE reference=? LIMIT 1', array( self::MARQUEUR . $id ) )->fetch();
			if ( $r ) { $deja = (int) $r['id']; }
		} catch ( \Throwable $ex ) {}

		// 6. Contre-passation déjà demandée, qui attend au journal temporaire.
		$enAttente = class_exists( 'FKC_EcritureLiens' ) ? FKC_EcritureLiens::annulationEnAttente( $id ) : null;
		if ( $enAttente ) {
			$raisons[]  = 'Une contre-passation attend au journal temporaire (brouillon n°' . $enAttente . ').';
			$blocages[] = 'annulation_en_attente';
		}

		return array(
			'ecriture'       => $e,
			'lignes'         => $lignes,
			'raisons'        => $raisons,
			'blocages'       => array_values( array_unique( $blocages ) ),
			'deja_annulee'   => $deja,
			'annulation_en_attente' => $enAttente,
			'supprimable'    => empty( $raisons ) && null === $deja,
			// La contre-passation reste possible même sur période clôturée :
			// elle est datée du jour, elle ne touche pas la période close.
			// Elle est en revanche refusée sur l'écriture QUI EST une clôture :
			// contre-passer une clôture reviendrait à rouvrir la période en
			// douce, alors qu'une fonction dédiée existe pour cela.
			'contrepassable' => null === $deja && null === $enAttente && ! empty( $lignes ) && ! $verrouContrepassation,
			'verrou'         => $verrouContrepassation,
			// Ce que la contre-passation va délier, pour affichage avant action.
			'dependances'    => class_exists( 'FKC_EcritureLiens' ) ? FKC_EcritureLiens::dependances( $id ) : array(),
		);
	}

	/** Affectations analytiques d'une ligne : map axe_id => valeur_id. */
	protected static function affectationsDe( $ligneId ) {
		$m = array();
		try {
			foreach ( FKC_DB::q( 'SELECT axe_id, valeur_id FROM ligne_affectations WHERE ecriture_ligne_id=?', array( (int) $ligneId ) )->fetchAll() as $r ) {
				$m[ (int) $r['axe_id'] ] = (int) $r['valeur_id'];
			}
		} catch ( \Throwable $e ) { /* table absente */ }
		// Ventilations (1.823.0) : l'annulation les reprend, part pour part.
		if ( class_exists( 'FKC_Ventilation' ) ) {
			foreach ( FKC_Ventilation::compact( $ligneId ) as $axe => $parts ) { $m[ (int) $axe ] = $parts; }
		}
		return $m;
	}

	/* ── Voie normale : contre-passation ──────────────────────────────────── */

	/**
	 * Génère l'écriture inverse. Même journal, mêmes comptes, débit et crédit
	 * permutés, tiers et division repris — sans eux, le grand livre auxiliaire
	 * et l'analytique resteraient déséquilibrés après l'annulation.
	 *
	 * @param int         $id   Écriture d'origine.
	 * @param string|null $date Date de la contre-passation (défaut : aujourd'hui).
	 * @return array{0:bool,1:string,2:?int} ok, message, id de la contre-passation
	 */
	public static function contrepasser( $id, $date = null ) {
		$id = (int) $id;
		$an = self::analyser( $id );
		if ( ! $an['ecriture'] ) { return array( false, 'Écriture introuvable.', null ); }
		if ( null !== $an['deja_annulee'] ) {
			return array( false, 'Écriture déjà contre-passée par l\'écriture n°' . $an['deja_annulee'] . '.', null );
		}
		if ( ! empty( $an['annulation_en_attente'] ) ) {
			return array( false, 'Une contre-passation de cette écriture attend déjà au journal temporaire (brouillon n°'
				. $an['annulation_en_attente'] . ') : validez-la ou supprimez-la.', null );
		}
		if ( empty( $an['lignes'] ) ) { return array( false, 'Écriture sans ligne : rien à contre-passer.', null ); }
		if ( ! empty( $an['verrou'] ) ) {
			return array( false, 'Cette écriture matérialise une clôture de période : '
				. 'contre-passer reviendrait à rouvrir la période sans le dire. Utilisez la réouverture de clôture.', null );
		}

		$src  = $an['ecriture'];
		$jour = ( $date && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) ? (string) $date : date( 'Y-m-d' );

		/*
		 * La contre-passation est elle-même une écriture : si SA date tombe dans
		 * une période clôturée, elle est refusée comme n'importe quelle autre.
		 * Le cas se produit sans que l'utilisateur l'ait cherché — la date par
		 * défaut est celle du jour, et le mois en cours peut avoir été clôturé
		 * par anticipation. On le dit explicitement plutôt que de laisser
		 * remonter un message technique qui n'indique pas quoi faire.
		 */
		if ( class_exists( 'FKC_Cloture' ) && FKC_Cloture::isLocked( $jour ) ) {
			return array( false, 'La période du ' . $jour . ' est clôturée : la contre-passation ne peut pas y être datée. '
				. 'Choisissez une date dans une période ouverte, ou rouvrez la clôture.', null );
		}
		$piece = trim( (string) ( $src['piece'] ?? '' ) );
		$lib   = 'Annulation ' . ( '' !== $piece ? $piece : '#' . $id ) . ' — ' . (string) $src['libelle'];

		$rev = array();
		foreach ( $an['lignes'] as $l ) {
			$rev[] = array(
				'compte_id'   => (int) $l['compte_id'],
				'libelle'     => 'Annulation — ' . (string) ( $l['libelle'] ?? '' ),
				'debit'       => (float) $l['credit'],
				'credit'      => (float) $l['debit'],
				'division_id' => isset( $l['division_id'] ) ? $l['division_id'] : null,
				/*
				 * LA CONTRE-PASSATION ÉTAIT AVEUGLE AU MULTI-AXES (1.547.0).
				 *
				 * `division_id` et le tiers étaient bien repris — le
				 * commentaire de cette méthode disait même pourquoi : « sans
				 * eux, le grand livre auxiliaire et l'analytique resteraient
				 * déséquilibrés ». Mais les affectations de `ligne_affectations`
				 * ne l'étaient pas. Une charge affectée à un client, un projet
				 * ou un produit restait donc imputée à lui POUR TOUJOURS après
				 * annulation : le résultat par axe montrait la dépense, jamais
				 * son annulation, et l'écart avec le compte de résultat
				 * grandissait à chaque correction. Seul l'axe Division, qui
				 * passe par une colonne et non par cette table, était juste.
				 */
				'affectations' => self::affectationsDe( (int) $l['id'] ),
				'tiers_type'  => isset( $l['tiers_type'] ) ? $l['tiers_type'] : null,
				'tiers_id'    => isset( $l['tiers_id'] ) ? $l['tiers_id'] : null,
			);
		}

		$entete = array(
			'journal_id'    => (int) $src['journal_id'],
			'date_ecriture' => $jour,
			'piece'         => '' !== $piece ? 'ANN-' . $piece : null,
			'libelle'       => fkc_tronquer( $lib, 240 ),
			// Marqueur machine : c'est lui qui empêche la double annulation.
			'reference'     => self::MARQUEUR . $id,
			'created_by'    => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
			/*
			 * MÊME NUMÉRO que l'écriture annulée, et type « annulation ».
			 * Une contre-passation n'est pas une opération nouvelle : c'est
			 * l'annulation de celle-là. Le grand livre montre donc le même
			 * numéro deux fois — une fois à l'endroit, une fois à l'envers — ce
			 * qui se lit d'un coup d'œil au lieu d'obliger à rapprocher deux
			 * numéros éloignés. L'unicité est préservée par le couple
			 * (numéro, type), et la suite des numéros ne compte que les
			 * opérations réelles : une annulation n'y prend pas de place.
			 */
			'numero'        => ! empty( $src['numero'] ) ? (string) $src['numero'] : null,
			'type_ecriture' => class_exists( 'FKC_EcritureNumero' ) ? FKC_EcritureNumero::TYPE_ANNULATION : 'annulation',
		);

		/*
		 * Écriture inverse ET propagation dans UNE SEULE transaction.
		 *
		 * Auparavant, `save()` était appelée seule : la contre-passation était
		 * enregistrée mais aucune pièce source n'était touchée. La facture
		 * restait « comptabilisée », le reçu « comptabilisé », la dotation
		 * inchangée, et le lettrage continuait d'affirmer un rapprochement dont
		 * l'effet venait d'être annulé. Résultat : une pièce ni relisible dans
		 * « à comptabiliser », ni repassable.
		 *
		 * Les deux opérations doivent réussir ensemble : une écriture inverse
		 * sans déliaison laisse la divergence, une déliaison sans écriture
		 * inverse laisse un trou dans le grand livre.
		 */
		/*
		 * LA CONTRE-PASSATION SUIT LA POLITIQUE DE COMPTABILISATION (1.745.0).
		 *
		 * Elle était écrite directement au journal par FKC_Ecriture::save() :
		 * la seule écriture du dossier à ne jamais passer par le journal
		 * temporaire, alors que la règle posée par l'utilisateur est que
		 * CHAQUE écriture est contrôlée avant d'être comptabilisée, sans
		 * exception. Elle passe désormais par FKC_Ecriture::enregistrer(),
		 * origine « annulation », réglable comme les autres.
		 *
		 * Les pièces sont annulées TOUT DE SUITE — le règlement est annulé à
		 * l'instant où on le décide — et la contre-passation attend au
		 * journal temporaire comme n'importe quelle écriture. La rejeter
		 * rend aux pièces leur état (FKC_Brouillard::delete).
		 */
		$newId  = null;
		$bid    = null;
		$msgSav = '';
		$prop   = array( 'pieces' => 0, 'lettrages' => 0, 'detail' => array() );
		try {
			FKC_Tx::executer( function () use ( $entete, $rev, $id, &$newId, &$bid, &$msgSav, &$prop ) {
				list( $ok, $msg, $eid, $b ) = FKC_Ecriture::enregistrer( $entete, $rev, array( 'source' => 'annulation' ) );
				$msgSav = $msg;
				if ( ! $ok ) {
					// L'enregistrement a déjà annulé son propre savepoint ; on
					// remonte pour que rien de la propagation ne s'applique.
					throw new RuntimeException( $msg );
				}
				$newId = $eid ? (int) $eid : null;
				$bid   = $b ? (int) $b : null;
				if ( class_exists( 'FKC_EcritureLiens' ) ) {
					$prop = FKC_EcritureLiens::delier( $id, $newId, $bid );
				}
			} );
		} catch ( \Throwable $ex ) {
			fkc_log( 'EcritureAnnulation::contrepasser ' . $ex->getMessage(), 'ERROR' );
			return array( false, '' !== $msgSav ? $msgSav : 'Contre-passation impossible : aucune modification n\'a été enregistrée.', null );
		}

		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'ecriture_contrepassee',
				'Écriture #' . $id . ( '' !== $piece ? ' (pièce ' . $piece . ')' : '' )
				. ( $newId ? ' — contre-passation n°' . $newId : ' — contre-passation au journal temporaire (brouillon n°' . $bid . ')' ) . ' au ' . $jour
				. ( $prop['pieces'] ? ' — ' . $prop['pieces'] . ' pièce(s) déliée(s)' : '' )
				. ( $prop['lettrages'] ? ' — ' . $prop['lettrages'] . ' lettrage(s) retiré(s)' : '' ) );
		}

		// Le message dit ce qui a bougé ailleurs : c'est la seule façon pour
		// l'utilisateur de savoir que sa facture est repassée « à comptabiliser ».
		$suite = '';
		if ( $prop['pieces'] ) {
			$suite .= ' Pièces touchées : ' . implode( ', ', $prop['detail'] ) . '.';
		}
		if ( $prop['lettrages'] ) {
			$suite .= ' ' . $prop['lettrages'] . ' ligne(s) délettrée(s).';
		}

		if ( ! $newId ) {
			return array( true, 'Contre-passation de l\'écriture n°' . $id . ' déposée au journal temporaire (brouillon n°' . $bid
				. ', au ' . $jour . ') : elle prendra effet au grand livre à sa validation ; la supprimer rétablit les pièces.' . $suite, null );
		}
		return array( true, 'Écriture n°' . $id . ' annulée par contre-passation (nouvelle écriture n°' . $newId . ' au ' . $jour . ').' . $suite, (int) $newId );
	}

	/* ── Voie exceptionnelle : suppression définitive ─────────────────────── */

	/**
	 * Efface l'écriture et ses lignes. Refuse dès qu'un élément la référence :
	 * mieux vaut une contre-passation lisible qu'un trou dans le grand livre.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function supprimer( $id ) {
		$id = (int) $id;
		$an = self::analyser( $id );
		if ( ! $an['ecriture'] ) { return array( false, 'Écriture introuvable.' ); }

		if ( ! $an['supprimable'] ) {
			$motif = $an['raisons']
				? implode( ' ', $an['raisons'] )
				: 'Elle a déjà été contre-passée par l\'écriture n°' . $an['deja_annulee'] . '.';
			return array( false, 'Suppression refusée : ' . $motif
				. ' Utilisez la contre-passation, qui laisse l\'histoire lisible.' );
		}

		$src   = $an['ecriture'];
		$piece = (string) ( $src['piece'] ?? '' );
		$total = (float) ( $src['total'] ?? 0 );

		try {
			FKC_Tx::executer( function () use ( $id, $src ) {
				FKC_DB::q( "DELETE FROM pieces_jointes WHERE source_type='ecriture' AND source_id=?", array( $id ) );
				// Rend le numéro au compteur si c'est le dernier de sa série ; sinon
				// le trou est journalisé et remonté par le contrôle des séquences.
				if ( class_exists( 'FKC_EcritureNumero' ) ) { FKC_EcritureNumero::liberer( $src ); }
				/*
				 * `ligne_affectations` ne porte aucune clé étrangère : rien ne
				 * la nettoie par cascade. Sans ce retrait explicite, chaque
				 * suppression d'écriture y laissait des lignes pointant dans le
				 * vide — invisibles dans les états, mais accumulées sans fin.
				 */
				FKC_DB::q( 'DELETE FROM ligne_affectations WHERE ecriture_ligne_id IN (SELECT id FROM ecriture_lignes WHERE ecriture_id=?)', array( $id ) );
				if ( class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::ensure(); FKC_DB::q( 'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id IN (SELECT id FROM ecriture_lignes WHERE ecriture_id=?)', array( $id ) ); }
				FKC_DB::q( 'DELETE FROM ecriture_lignes WHERE ecriture_id=?', array( $id ) );
				FKC_DB::q( 'DELETE FROM ecritures WHERE id=?', array( $id ) );
			} );
		} catch ( \Throwable $ex ) {
			fkc_log( 'EcritureAnnulation::supprimer ' . $ex->getMessage(), 'ERROR' );
			return array( false, 'Suppression impossible : aucune modification n\'a été enregistrée.' );
		}

		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'ecriture_supprimee',
				self::designer( $src ) . ( '' !== $piece ? ' (pièce ' . $piece . ')' : '' )
				. ' du ' . $src['date_ecriture'] . ' — ' . fkc_money( $total ) . ' — ' . (string) $src['libelle'] );
		}

		return array( true, self::designer( $src ) . ( '' !== $piece ? ' (pièce ' . $piece . ')' : '' ) . ' supprimée définitivement.' );
	}

	/* ── Revenir sur une contre-passation ────────────────────────────────── */

	/**
	 * Annule une contre-passation et remet l'écriture d'origine en vigueur.
	 *
	 * Répond au cas « je me suis trompé d'écriture » : on vient d'en
	 * contre-passer une par erreur et on veut revenir en arrière sans laisser
	 * trois écritures dans le grand livre. Contre-passer la contre-passation
	 * serait plus orthodoxe mais illisible — un compte de tiers porterait le même
	 * montant trois fois, au débit, au crédit, puis au débit.
	 *
	 * La contre-passation est donc SUPPRIMÉE et les pièces qu'elle avait déliées
	 * sont rebranchées. C'est admissible parce qu'une contre-passation fraîche
	 * est une écriture technique qui n'a encore rien justifié : ni pièce jointe
	 * propre, ni lettrage, ni rattachement. Dès qu'elle en a acquis un,
	 * l'opération est refusée et il faut la contre-passer à son tour.
	 *
	 * REFUSÉ, chaque fois pour une raison précise :
	 *   - période clôturée (de la contre-passation ou de l'origine) : supprimer
	 *     une écriture d'une période close rendrait la clôture mensongère ;
	 *   - contre-passation référencée par une pièce, lettrée ou porteuse d'un
	 *     justificatif : elle a servi à quelque chose ;
	 *   - contre-passation elle-même déjà contre-passée : la situation est déjà
	 *     rétablie.
	 *
	 * Les pièces recomptabilisées depuis ne sont pas rebranchées de force : la
	 * comptabilisation la plus récente fait foi, et le message le signale.
	 *
	 * @param int $contrepassationId Écriture de contre-passation à annuler.
	 * @return array{0:bool,1:string,2:?int} ok, message, id de l'écriture d'origine
	 */
	public static function annulerContrepassation( $contrepassationId ) {
		$cp  = (int) $contrepassationId;
		$ecr = self::find( $cp );
		if ( ! $ecr ) { return array( false, 'Écriture introuvable.', null ); }

		$ref = (string) ( $ecr['reference'] ?? '' );
		if ( 0 !== strpos( $ref, self::MARQUEUR ) ) {
			return array( false, 'L\'écriture n°' . $cp . ' n\'est pas une contre-passation : il n\'y a rien à annuler.', null );
		}
		$origine = (int) substr( $ref, strlen( self::MARQUEUR ) );
		if ( $origine <= 0 ) { return array( false, 'Référence de contre-passation illisible.', null ); }

		$src = self::find( $origine );
		if ( ! $src ) {
			return array( false, 'L\'écriture d\'origine (n°' . $origine . ') n\'existe plus : '
				. 'annuler la contre-passation la laisserait sans objet.', null );
		}

		if ( class_exists( 'FKC_Cloture' ) ) {
			$dates = array( (string) $ecr['date_ecriture'] => 'de la contre-passation', (string) $src['date_ecriture'] => 'de l\'écriture d\'origine' );
			foreach ( $dates as $d => $quoi ) {
				if ( FKC_Cloture::isLocked( $d ) ) {
					return array( false, 'La période ' . $quoi . ' (' . $d . ') est clôturée : '
						. 'revenir en arrière rendrait la clôture mensongère.', null );
				}
			}
		}

		$an = self::analyser( $cp );
		if ( ! empty( $an['raisons'] ) ) {
			return array( false, 'Annulation refusée : la contre-passation n°' . $cp . ' a servi — '
				. implode( ' ', $an['raisons'] ) . ' Contre-passez-la plutôt que de la supprimer.', null );
		}
		if ( null !== $an['deja_annulee'] ) {
			return array( false, 'La contre-passation n°' . $cp . ' a elle-même été contre-passée (écriture n°'
				. $an['deja_annulee'] . ') : la situation est déjà rétablie.', null );
		}

		$prop = array( 'pieces' => 0, 'recreees' => 0, 'lettrages' => 0, 'detail' => array() );
		try {
			FKC_Tx::executer( function () use ( $cp, $origine, $ecr, &$prop ) {
				// Rebranchement d'abord : si la restauration échoue, la
				// contre-passation reste en place et l'état demeure cohérent.
				if ( class_exists( 'FKC_EcritureLiens' ) ) {
					$prop = FKC_EcritureLiens::relier( $origine, $cp );
				}
				if ( class_exists( 'FKC_EcritureNumero' ) ) { FKC_EcritureNumero::liberer( $ecr ); }
				FKC_DB::q( "DELETE FROM pieces_jointes WHERE source_type='ecriture' AND source_id=?", array( $cp ) );
				FKC_DB::q( 'DELETE FROM ligne_affectations WHERE ecriture_ligne_id IN (SELECT id FROM ecriture_lignes WHERE ecriture_id=?)', array( $cp ) );
				if ( class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::ensure(); FKC_DB::q( 'DELETE FROM ligne_ventilations WHERE ecriture_ligne_id IN (SELECT id FROM ecriture_lignes WHERE ecriture_id=?)', array( $cp ) ); }
				FKC_DB::q( 'DELETE FROM ecriture_lignes WHERE ecriture_id=?', array( $cp ) );
				FKC_DB::q( 'DELETE FROM ecritures WHERE id=?', array( $cp ) );
			} );
		} catch ( \Throwable $ex ) {
			fkc_log( 'EcritureAnnulation::annulerContrepassation ' . $ex->getMessage(), 'ERROR' );
			return array( false, 'Annulation impossible : aucune modification n\'a été enregistrée.', null );
		}

		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'contrepassation_annulee',
				'Contre-passation #' . $cp . ' supprimée — écriture n°' . $origine . ' remise en vigueur'
				. ( $prop['pieces'] ? ' — ' . $prop['pieces'] . ' pièce(s) rebranchée(s)' : '' )
				. ( $prop['recreees'] ? ' — ' . $prop['recreees'] . ' ligne(s) recréée(s)' : '' )
				. ( $prop['lettrages'] ? ' — ' . $prop['lettrages'] . ' lettrage(s) remis' : '' ) );
		}

		$suite = '';
		if ( $prop['pieces'] )    { $suite .= ' ' . $prop['pieces'] . ' pièce(s) rebranchée(s).'; }
		if ( $prop['recreees'] )  { $suite .= ' ' . $prop['recreees'] . ' ligne(s) recréée(s).'; }
		if ( $prop['lettrages'] ) { $suite .= ' ' . $prop['lettrages'] . ' lettrage(s) remis.'; }
		if ( $prop['detail'] )    { $suite .= ' À noter : ' . implode( ' · ', $prop['detail'] ) . '.'; }

		return array( true, 'Contre-passation n°' . $cp . ' annulée : l\'écriture n°' . $origine
			. ' est de nouveau en vigueur.' . $suite, $origine );
	}

	/**
	 * Une écriture est-elle une contre-passation ? Permet de n'afficher le
	 * bouton d'annulation que là où il a un sens.
	 */
	public static function estContrepassation( $id ) {
		$e = self::find( $id );
		if ( ! $e ) { return false; }
		return 0 === strpos( (string) ( $e['reference'] ?? '' ), self::MARQUEUR );
	}

	/**
	 * Désignation lisible d'une écriture : « écriture AC-26000001 » quand elle
	 * porte un numéro comptable, « écriture n°42 » (id technique) sinon — le cas
	 * des écritures antérieures à la numérotation, tant qu'elles n'ont pas été
	 * reprises.
	 */
	public static function designer( $e ) {
		if ( ! empty( $e['numero'] ) ) {
			$code = isset( $e['journal_code'] ) ? (string) $e['journal_code'] : '';
			return 'écriture ' . ( $code ? $code . '-' : '' ) . $e['numero'];
		}
		return 'écriture n°' . (int) ( $e['id'] ?? 0 );
	}
}
