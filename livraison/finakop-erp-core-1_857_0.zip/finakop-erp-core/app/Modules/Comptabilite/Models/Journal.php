<?php
/** Journaux comptables. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Journal {
	public static function all() {
		return FKC_DB::q( 'SELECT * FROM journaux ORDER BY code ASC' )->fetchAll();
	}
}
