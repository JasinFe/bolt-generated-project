<?php
/** Écritures en partie double (équilibre garanti, transaction atomique). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Ecriture {

	public static function listWithTotals( $limit = 200, $annee = null ) {
		$limit = (int) $limit;
		$where = ''; $params = array();
		if ( $annee && preg_match( '/^\\d+$/', (string) $annee ) ) { $where = "WHERE substr(e.date_ecriture,1,4)=?"; $params[] = (string) $annee; }
		return FKC_DB::q(
			"SELECT e.*, j.code AS journal_code,
				COALESCE(SUM(l.debit),0) AS total_debit,
				COALESCE(SUM(l.credit),0) AS total_credit
			 FROM ecritures e
			 JOIN journaux j ON j.id=e.journal_id
			 LEFT JOIN ecriture_lignes l ON l.ecriture_id=e.id
			 {$where}
			 GROUP BY e.id
			 ORDER BY e.date_ecriture DESC, e.id DESC
			 LIMIT {$limit}", $params
		)->fetchAll();
	}

	/** Exercices disponibles (années des écritures), année courante incluse, ordre décroissant. */
	public static function exercices() {
		if ( class_exists( 'FKC_Exercice' ) ) { $y = FKC_Exercice::annees(); if ( $y ) { return $y; } }
		$ys = array();
		try {
			foreach ( FKC_DB::q( "SELECT DISTINCT substr(date_ecriture,1,4) y FROM ecritures WHERE date_ecriture IS NOT NULL" )->fetchAll() as $r ) {
				if ( ! empty( $r['y'] ) ) { $ys[] = $r['y']; }
			}
		} catch ( \Throwable $e ) {}
		$cur = date( 'Y' );
		if ( ! in_array( $cur, $ys, true ) ) { $ys[] = $cur; }
		$ys = array_values( array_unique( $ys ) ); rsort( $ys );
		return $ys;
	}

	public static function withLignes( $id ) {
		$head = FKC_DB::q(
			'SELECT e.*, j.code AS journal_code, j.libelle AS journal_libelle
			 FROM ecritures e JOIN journaux j ON j.id=e.journal_id WHERE e.id=?',
			array( (int) $id )
		)->fetch();
		if ( ! $head ) { return null; }
		$head['lignes'] = FKC_DB::q(
			'SELECT l.*, c.numero AS compte_numero, c.libelle AS compte_libelle, d.libelle AS division_libelle, d.code AS division_code
			 FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
			 LEFT JOIN divisions d ON d.id=l.division_id
			 WHERE l.ecriture_id=? ORDER BY l.ordre ASC, l.id ASC',
			array( (int) $id )
		)->fetchAll();
		return $head;
	}

	/**
	 * Valide et normalise les lignes d'une écriture (équilibre, période, comptes).
	 * Partagé par la comptabilisation directe et la mise en brouillard.
	 * @return array{bool, string, array} ( bool ok, string message, array lignes_propres )
	 */
	public static function prepare( $entete, $lignes ) {
		/*
		 * ÉCRITURE D'INVENTAIRE — la seule exception au verrou de période.
		 *
		 * Une dotation d'amortissement et la détermination du résultat sont
		 * datées du dernier jour de l'exercice et produites APRÈS lui : elles
		 * butaient donc sur la clôture mensuelle de décembre, rendant
		 * l'exercice inclôturable (voir FKC_Cloture::isExerciceClos()).
		 *
		 * Ce drapeau n'ouvre pas une porte dérobée : il ne dispense PAS de
		 * contrôle, il en change un seul — la clôture de l'EXERCICE remplace
		 * le verrou de période. Une fois le résultat arrêté, ces écritures
		 * sont refusées comme les autres, et pour la bonne raison, dite en
		 * clair. Il n'est posé que par le moteur de clôture et par les
		 * dotations, jamais par un écran de saisie.
		 */
		if ( class_exists( 'FKC_Cloture' ) && ! empty( $entete['date_ecriture'] ) ) {
			$d = $entete['date_ecriture'];
			if ( ! empty( $entete['inventaire'] ) ) {
				if ( FKC_Cloture::isExerciceClos( $d ) ) {
					return array( false, 'Exercice clos : cette écriture d\'inventaire modifierait un résultat déjà '
						. 'déterminé. Rouvrez la clôture annuelle couvrant le ' . $d . ' avant de la passer.', array() );
				}
			} elseif ( FKC_Cloture::isLocked( $d ) ) {
				$motif = method_exists( 'FKC_Cloture', 'motifBlocage' ) ? FKC_Cloture::motifBlocage( $d ) : '';
				return array( false, $motif ?: ( 'Période clôturée : aucune écriture ne peut être enregistrée à la date du ' . $d . '.' ), array() );
			}
		}
		$clean = array();
		foreach ( $lignes as $l ) {
			$d = (float) ( isset( $l['debit'] ) ? $l['debit'] : 0 );
			$c = (float) ( isset( $l['credit'] ) ? $l['credit'] : 0 );
			if ( $d <= 0 && $c <= 0 ) { continue; }
			if ( $d > 0 && $c > 0 ) { return array( false, 'Une ligne ne peut être à la fois au débit et au crédit.', array() ); }
			if ( empty( $l['compte_id'] ) ) { return array( false, 'Chaque ligne doit référencer un compte.', array() ); }
			/*
			 * AFFECTATIONS MULTI-AXES (1.547.0). Le couple axe_id/valeur_id ne
			 * permettait d'en porter qu'UNE SEULE par ligne, alors que le
			 * modèle en admet autant qu'il y a d'axes. Toute reprise de
			 * l'analytique d'une ligne existante — une contre-passation, au
			 * premier chef — en perdait donc toutes sauf une. La clé
			 * 'affectations' (map axe_id => valeur_id) les accepte toutes ;
			 * axe_id/valeur_id restent honorés tels quels.
			 */
			$affectations = array();
			if ( isset( $l['affectations'] ) && is_array( $l['affectations'] ) ) {
				foreach ( $l['affectations'] as $aid => $vid ) {
					/*
					 * VENTILATION (1.823.0) : sur un axe, la valeur peut être un
					 * jeu de parts [valeur_id => pourcentage] au lieu d'un id.
					 * C'est ainsi qu'une contre-passation reprend la ventilation
					 * de la ligne qu'elle annule — y compris en passant par le
					 * journal temporaire, qui conserve ce tableau tel quel.
					 */
					if ( is_array( $vid ) ) {
						$parts = array();
						foreach ( $vid as $v => $p ) { if ( (int) $v > 0 && (float) $p > 0 ) { $parts[ (int) $v ] = (float) $p; } }
						if ( (int) $aid > 0 && count( $parts ) >= 2 ) { $affectations[ (int) $aid ] = $parts; }
						continue;
					}
					if ( (int) $aid > 0 && (int) $vid > 0 ) { $affectations[ (int) $aid ] = (int) $vid; }
				}
			}
			if ( ! empty( $l['axe_id'] ) && ! empty( $l['valeur_id'] ) ) {
				$affectations[ (int) $l['axe_id'] ] = (int) $l['valeur_id'];
			}
			$clean[] = array( 'compte_id' => (int) $l['compte_id'], 'libelle' => isset( $l['libelle'] ) ? $l['libelle'] : '', 'debit' => $d, 'credit' => $c, 'division_id' => ( isset( $l['division_id'] ) && $l['division_id'] ) ? (int) $l['division_id'] : null, 'axe_id' => ( isset( $l['axe_id'] ) && $l['axe_id'] ) ? (int) $l['axe_id'] : null, 'valeur_id' => ( isset( $l['valeur_id'] ) && $l['valeur_id'] ) ? (int) $l['valeur_id'] : null, 'affectations' => $affectations, 'tiers_type' => ( isset( $l['tiers_type'] ) && $l['tiers_type'] ) ? (string) $l['tiers_type'] : null, 'tiers_id' => ( isset( $l['tiers_id'] ) && $l['tiers_id'] ) ? (int) $l['tiers_id'] : null,
				// Terme restant à courir, pour les notes annexes de la liasse.
				'echeance' => ( isset( $l['echeance'] ) && $l['echeance'] ) ? (string) $l['echeance'] : null,
				// Traçabilité devise : montant d'origine et cours retenu. Sans eux,
				// aucune revalorisation de clôture ni justification devant un
				// contrôle ne sont possibles.
				'devise' => ( isset( $l['devise'] ) && $l['devise'] ) ? strtoupper( (string) $l['devise'] ) : null,
				'montant_devise' => isset( $l['montant_devise'] ) ? (float) $l['montant_devise'] : null,
				'taux_change' => ( isset( $l['taux_change'] ) && $l['taux_change'] > 0 ) ? (float) $l['taux_change'] : null,
				// RÉGIME FISCAL DE LA LIGNE (1.614.0). Le filtre de cette
				// méthode ne conserve que les clés qu'il connaît : sans cet
				// ajout, le régime posé par le moteur d'événements était
				// silencieusement écarté avant d'atteindre la base.
				'regime' => ( isset( $l['regime'] ) && $l['regime'] ) ? strtoupper( (string) $l['regime'] ) : null );
		}
		if ( count( $clean ) < 2 ) { return array( false, 'Une écriture doit comporter au moins deux lignes.', array() ); }

		$td = 0; $tc = 0;
		foreach ( $clean as $l ) { $td += $l['debit']; $tc += $l['credit']; }
		if ( ! fkc_equilibre( $td, $tc ) ) {
			return array( false, 'Écriture déséquilibrée : débit ' . fkc_money( $td ) . ' ≠ crédit ' . fkc_money( $tc ) . ' FCFA.', array() );
		}
		if ( 0 === fkc_cents( $td ) ) { return array( false, 'Le montant de l\'écriture est nul.', array() ); }

		/*
		 * ON N'IMPUTE PAS SUR UN POSTE D'AGRÉGATION.
		 *
		 * Le plan comptable est hiérarchique : 603 « Variations des stocks de
		 * biens achetés » n'est pas un compte, c'est la somme de 6031, 6032 et
		 * 6033. Autoriser une écriture sur 603 laisse la variation se répartir
		 * entre un poste et ses enfants : la balance reste équilibrée — donc
		 * personne n'est alerté — mais la ligne RB de la liasse ne totalise
		 * plus ce qu'elle devrait et la marge commerciale devient fausse.
		 *
		 * Le contrôle arrive ici, au seul point de passage de toute écriture,
		 * plutôt que dans chaque écran : un import CSV, une reprise de balance
		 * ou un schéma d'événement mal réglé doivent buter sur la même règle
		 * qu'une saisie manuelle.
		 */
		$postes = self::postesNonImputables( $clean );
		if ( $postes ) {
			$l = reset( $postes );
			return array( false, 'Le compte ' . $l['numero'] . ' « ' . $l['libelle'] . ' » est un poste d\'agrégation : '
				. 'il totalise ses subdivisions et ne reçoit pas d\'écriture. '
				. 'Choisissez l\'une de ses subdivisions' . ( $l['enfants'] ? ' (' . $l['enfants'] . ')' : '' ) . '.', array() );
		}
		/*
		 * NI SUR UN COMPTE DE REGROUPEMENT (1.791.0).
		 *
		 * 411000, 521000, 552000 et 571000 ne sont pas des « titres » du plan :
		 * ils ont été livrés comme comptes de détail dans les dossiers
		 * antérieurs, et l'on pouvait donc y imputer. Or chacun totalise ses
		 * subdivisions (411100 Clients, 521100 Banque…) : un solde qui y dort
		 * traverse la liasse sans rien signaler, en désignant le mauvais poste.
		 * La 1.789.0 le signalait à la clôture ; la règle posée par le dossier
		 * — imputer au niveau le plus fin, partout — le REFUSE désormais à la
		 * saisie, au seul point de passage de toute écriture.
		 *
		 * Trois écritures restent admises, parce qu'elles ne font que VIDER ou
		 * REPORTER ce qui s'y trouve déjà : la contre-passation d'une écriture
		 * ancienne, les à-nouveaux (journal AN) qui reportent un solde hérité, et
		 * l'OD de reclassement qui le transfère vers le compte d'imputation.
		 * Référentiel SYCEBNL : 521000 y est un compte d'imputation — règle
		 * non appliquée.
		 */
		if ( ! self::regroupementAdmis( $entete ) ) {
			$reg = self::comptesDeRegroupement( $clean );
			if ( $reg ) {
				$r = reset( $reg );
				if ( ! empty( $r['conditionnel'] ) ) {
					// Compte remplacé (et non regroupement) : 709000 du module Royalties (1.854.0).
					return array( false, 'Le compte ' . $r['numero'] . ' « ' . $r['libelle'] . ' » est remplacé par ' . $r['cible'] . ' « ' . $r['cible_libelle'] . ' ». '
						. $r['motif'] . ' Un solde hérité se transfère par l\'OD de reclassement (Arrêté des comptes → Faits économiques).', array() );
				}
				return array( false, 'Le compte ' . $r['numero'] . ' est un compte de regroupement : il totalise ses subdivisions et ne reçoit pas d\'écriture. '
					. 'Imputez sur ' . $r['cible'] . ' « ' . $r['cible_libelle'] . ' » (SYSCOHADA révisé : imputation au niveau le plus fin). '
					. 'Un solde hérité se transfère par l\'OD de reclassement (Arrêté des comptes → Faits économiques).', array() );
			}
		}
		return array( true, '', $clean );
	}

	/** Écritures qui peuvent toucher un compte de regroupement : elles le vident ou le reportent. */
	protected static function regroupementAdmis( $entete ) {
		if ( class_exists( 'FKC_Referentiel' ) && 'sycebnl' === FKC_Referentiel::actif() ) { return true; }
		if ( class_exists( 'FKC_EcritureNumero' ) && isset( $entete['type_ecriture'] ) && FKC_EcritureNumero::TYPE_ANNULATION === $entete['type_ecriture'] ) { return true; }
		if ( in_array( (string) ( $entete['source'] ?? '' ), array( 'reclassement', 'annulation', 'anouveaux' ), true ) ) { return true; }
		if ( ! empty( $entete['journal_id'] ) ) {
			try {
				$code = (string) FKC_DB::q( 'SELECT code FROM journaux WHERE id=?', array( (int) $entete['journal_id'] ) )->fetchColumn();
				if ( 'AN' === $code ) { return true; }
			} catch ( \Throwable $e ) {}
		}
		return false;
	}

	/** @return array numero => { numero, cible, cible_libelle } pour les lignes posées sur un compte de regroupement. */
	protected static function comptesDeRegroupement( array $lignes ) {
		if ( ! class_exists( 'FKC_Reclassement' ) ) { return array(); }
		$cat = array_filter( FKC_Reclassement::entrees(), function ( $d ) { return ! empty( $d['total'] ); } );
		if ( ! $cat ) { return array(); }
		$ids = array();
		foreach ( $lignes as $l ) { $ids[ (int) $l['compte_id'] ] = true; }
		try {
			$ph = implode( ',', array_fill( 0, count( $ids ), '?' ) );
			$rows = FKC_DB::q( "SELECT numero, libelle FROM comptes WHERE id IN ({$ph})", array_keys( $ids ) )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		$out = array();
		foreach ( $rows as $row ) {
			$n = (string) $row['numero'];
			if ( ! isset( $cat[ $n ] ) ) { continue; }
			$d = $cat[ $n ];
			/*
			 * Entrée CONDITIONNELLE (1.854.0) : le compte n'est visé que s'il
			 * porte encore le libellé attendu. Un 709000 « Rabais accordés »
			 * créé par le dossier reste parfaitement imputable.
			 */
			if ( ! empty( $d['si_libelle'] ) && FKC_Reclassement::normaliserLibelle( $row['libelle'] ) !== FKC_Reclassement::normaliserLibelle( $d['si_libelle'] ) ) { continue; }
			$out[ $n ] = array( 'numero' => $n, 'libelle' => (string) $row['libelle'], 'cible' => $d['cible'], 'cible_libelle' => $d['cible_libelle'],
				'conditionnel' => ! empty( $d['si_libelle'] ), 'motif' => (string) ( $d['motif'] ?? '' ) );
		}
		return $out;
	}

	/**
	 * Enregistre une écriture équilibrée dans une transaction (comptabilisation directe).
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null id )
	 */
	/**
	 * Repère les lignes imputées sur un compte de type « titre ».
	 *
	 * On lit le type stocké en base plutôt que de recalculer : un plan peut
	 * légitimement diverger du référentiel (comptes hérités, subdivisions
	 * maison), et c'est l'état RÉEL du plan de la société qui fait foi.
	 *
	 * @return array numéro => array(numero, libelle, enfants)
	 */
	protected static function postesNonImputables( array $lignes ) {
		$ids = array();
		foreach ( $lignes as $l ) { $ids[ (int) $l['compte_id'] ] = true; }
		if ( ! $ids ) { return array(); }
		try {
			$ph = implode( ',', array_fill( 0, count( $ids ), '?' ) );
			$rows = FKC_DB::q(
				"SELECT id, numero, libelle FROM comptes WHERE id IN ({$ph}) AND type = 'titre'",
				array_keys( $ids )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }

		$out = array();
		foreach ( $rows as $r ) {
			// On propose les subdivisions réellement ouvertes dans CE dossier :
			// un message qui renvoie vers des comptes inexistants ne dépanne pas.
			$racine = rtrim( (string) $r['numero'], '0' );
			$enfants = array();
			try {
				foreach ( FKC_DB::q(
					"SELECT numero FROM comptes WHERE numero LIKE ? AND numero <> ? AND type <> 'titre' AND actif = 1 ORDER BY numero LIMIT 4",
					array( $racine . '%', (string) $r['numero'] )
				)->fetchAll() as $e2 ) { $enfants[] = (string) $e2['numero']; }
			} catch ( \Throwable $e ) { $enfants = array(); }
			$out[ (string) $r['numero'] ] = array(
				'numero' => (string) $r['numero'],
				'libelle' => (string) $r['libelle'],
				'enfants' => implode( ', ', $enfants ),
			);
		}
		return $out;
	}

	public static function save( $entete, $lignes ) {
		list( $ok, $msg, $clean ) = self::prepare( $entete, $lignes );
		if ( ! $ok ) { return array( false, $msg, null ); }

		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $entete, $clean ) {
			/*
			 * Numéro d'écriture : AAnnnnnn, propre au journal et à l'exercice
			 * (26000001 pour la première écriture du journal en 2026). Alloué
			 * ici, dans la transaction : si l'insertion échoue, le compteur est
			 * annulé avec elle et aucun numéro n'est consommé pour rien.
			 * L'année vient de la DATE D'ÉCRITURE, pas du jour de saisie.
			 */
			$numero = null;
			$type   = 'normale';
			if ( class_exists( 'FKC_EcritureNumero' ) ) {
				$type = ( isset( $entete['type_ecriture'] ) && FKC_EcritureNumero::TYPE_ANNULATION === $entete['type_ecriture'] )
					? FKC_EcritureNumero::TYPE_ANNULATION
					: FKC_EcritureNumero::TYPE_NORMALE;
				/*
				 * Une CONTRE-PASSATION reprend le numéro de l'écriture qu'elle
				 * annule : ce n'est pas une opération nouvelle. L'appelant le
				 * fournit dans « numero », et aucune place n'est prise dans la
				 * suite — celle-ci ne compte que les opérations réelles.
				 */
				if ( ! empty( $entete['numero'] ) ) {
					$numero = (string) $entete['numero'];
				} else {
					$numero = FKC_EcritureNumero::allouer( (int) $entete['journal_id'], $entete['date_ecriture'] );
				}
			}
			/*
			 * TRAÇABILITÉ — la provenance s'écrit AVEC l'écriture.
			 *
			 * Ces cinq colonnes répondent à « pourquoi cette écriture
			 * existe-t-elle ? » depuis le grand livre. Elles n'existaient pas :
			 * l'étiquette « pack:{evenement} » posée par FKC_Posting servait
			 * uniquement à orienter vers le journal temporaire, puis était
			 * abandonnée. On pouvait remonter d'une facture vers son écriture,
			 * jamais l'inverse.
			 *
			 * Elles sont facultatives : une saisie manuelle n'a pas d'événement,
			 * et la trace le dira plutôt que d'inventer une origine.
			 */
			$colsTrace = array();
			try {
				foreach ( $db->query( 'PRAGMA table_info(ecritures)' ) as $c ) { $colsTrace[ $c['name'] ] = true; }
			} catch ( \Throwable $e ) { $colsTrace = array(); }
			$avecTrace = isset( $colsTrace['source'] ) && isset( $colsTrace['origine'] )
				&& isset( $colsTrace['fait'] ) && isset( $colsTrace['referentiel'] ) && isset( $colsTrace['lien'] )
				&& isset( $colsTrace['regime'] );

			if ( $avecTrace ) {
				$stmt = $db->prepare( 'INSERT INTO ecritures(journal_id,date_ecriture,piece,libelle,reference,created_by,numero,type_ecriture,source,origine,fait,referentiel,regime,lien) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)' );
				$stmt->execute( array(
					(int) $entete['journal_id'], $entete['date_ecriture'],
					isset( $entete['piece'] ) ? $entete['piece'] : null,
					$entete['libelle'],
					isset( $entete['reference'] ) ? $entete['reference'] : null,
					isset( $entete['created_by'] ) ? $entete['created_by'] : null,
					$numero, $type,
					! empty( $entete['source'] ) ? (string) $entete['source'] : null,
					! empty( $entete['origine'] ) ? (string) $entete['origine'] : null,
					! empty( $entete['fait'] ) ? (string) $entete['fait'] : null,
					! empty( $entete['referentiel'] ) ? (string) $entete['referentiel'] : null,
					! empty( $entete['regime'] ) ? (string) $entete['regime'] : null,
					! empty( $entete['lien'] )
						? ( is_string( $entete['lien'] ) ? $entete['lien'] : (string) json_encode( $entete['lien'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) )
						: null,
				) );
			} else {
				$stmt = $db->prepare( 'INSERT INTO ecritures(journal_id,date_ecriture,piece,libelle,reference,created_by,numero,type_ecriture) VALUES(?,?,?,?,?,?,?,?)' );
				$stmt->execute( array(
					(int) $entete['journal_id'], $entete['date_ecriture'],
					isset( $entete['piece'] ) ? $entete['piece'] : null,
					$entete['libelle'],
					isset( $entete['reference'] ) ? $entete['reference'] : null,
					isset( $entete['created_by'] ) ? $entete['created_by'] : null,
					$numero, $type,
				) );
			}
			$eid = (int) $db->lastInsertId();
			/*
			 * La colonne `regime` peut manquer sur une base ancienne dont la
			 * migration n'a pas encore tourné : on n'y prétend rien plutôt que
			 * de faire échouer toutes les écritures du dossier.
			 */
			$colL = array();
			try { foreach ( $db->query( 'PRAGMA table_info(ecriture_lignes)' ) as $c ) { $colL[ $c['name'] ] = true; } }
			catch ( \Throwable $e ) { $colL = array(); }
			$avecRegimeL = isset( $colL['regime'] );
			$ins = $avecRegimeL
				? $db->prepare( 'INSERT INTO ecriture_lignes(ecriture_id,compte_id,libelle,debit,credit,ordre,division_id,tiers_type,tiers_id,devise,montant_devise,taux_change,echeance,regime) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)' )
				: $db->prepare( 'INSERT INTO ecriture_lignes(ecriture_id,compte_id,libelle,debit,credit,ordre,division_id,tiers_type,tiers_id,devise,montant_devise,taux_change,echeance) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)' );
			$affect = null;
			try { $db->query( 'SELECT 1 FROM ligne_affectations LIMIT 1' ); $affect = $db->prepare( 'INSERT OR IGNORE INTO ligne_affectations(ecriture_ligne_id,axe_id,valeur_id) VALUES(?,?,?)' ); } catch ( Throwable $e ) { $affect = null; }
			$i = 0;
			foreach ( $clean as $l ) {
				$args = array( $eid, $l['compte_id'], $l['libelle'], $l['debit'], $l['credit'], $i++, $l['division_id'],
					! empty( $l['tiers_type'] ) ? (string) $l['tiers_type'] : null,
					! empty( $l['tiers_id'] ) ? (int) $l['tiers_id'] : null,
					isset( $l['devise'] ) ? $l['devise'] : null,
					isset( $l['montant_devise'] ) ? $l['montant_devise'] : null,
					isset( $l['taux_change'] ) ? $l['taux_change'] : null,
					isset( $l['echeance'] ) ? $l['echeance'] : null );
				if ( $avecRegimeL ) {
					// À défaut de régime propre à la ligne, celui de l'écriture :
					// une ligne sans régime dans une écriture qui en a un serait
					// comptée « non déterminée » alors qu'on le connaît.
					$args[] = ! empty( $l['regime'] ) ? (string) $l['regime']
						: ( ! empty( $entete['regime'] ) ? (string) $entete['regime'] : null );
				}
				$ins->execute( $args );
				if ( $affect && ! empty( $l['affectations'] ) ) {
					$ligneId = (int) $db->lastInsertId();
					$vent = array();
					foreach ( $l['affectations'] as $axeId => $valeurId ) {
						if ( is_array( $valeurId ) ) { $vent[ (int) $axeId ] = $valeurId; continue; }
						$affect->execute( array( $ligneId, (int) $axeId, (int) $valeurId ) );
					}
					if ( $vent && class_exists( 'FKC_Ventilation' ) ) { FKC_Ventilation::reprendre( $ligneId, $vent ); }
				}
			}
			/*
			 * RÈGLES D'IMPUTATION AUTOMATIQUE (1.824.0) : elles remplissent les
			 * axes restés vides des lignes de charges et produits. Jamais
			 * bloquant — la méthode avale ses propres erreurs.
			 */
			if ( class_exists( 'FKC_AnaRegle' ) ) { FKC_AnaRegle::appliquerEcriture( $eid ); }
			$ref = $numero ? ( ' ' . $numero ) : ( ' n°' . $eid );
			/*
			 * Purge de la carte des soldes mémorisée.
			 *
			 * Elle était posée sur enregistrer(), mais save() est appelée
			 * DIRECTEMENT par la validation du journal temporaire : une
			 * écriture publiée depuis le brouillard laissait donc les états sur
			 * la situation d'avant. Le défaut ne se voyait qu'en publiant puis
			 * en lisant un solde dans la même requête — exactement ce que fait
			 * un écran de clôture.
			 */
			if ( class_exists( 'FKC_EtatsDgi' ) ) { FKC_EtatsDgi::oublierSoldes(); }
			if ( class_exists( 'FKC_Maestro' ) ) { FKC_Maestro::invaliderCache(); } // l'analyse partagée décrivait les livres d'avant
			return array( true, 'Écriture' . $ref . ' enregistrée.', $eid );
			} );
		} catch ( Throwable $ex ) {
			fkc_log( 'Ecriture::save ' . $ex->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de l\'enregistrement.', null );
		}
	}

	/**
	 * Point d'entrée unique de comptabilisation. Selon l'option « vérification avant
	 * comptabilisation » (globale ou explicite), l'écriture est soit comptabilisée
	 * directement, soit déposée au brouillard pour contrôle/modification préalable.
	 *
	 * @param array $opts  'source' (origine), 'lien' (array{table,colonne,ids} à renseigner
	 *                     après validation), 'brouillard' (bool|null pour forcer/ignorer le mode).
	 * @return array{bool, string, int|null, int|null} ( bool ok, string message, int|null ecriture_id, int|null brouillon_id )
	 */
	public static function enregistrer( $entete, $lignes, $opts = array() ) {
		/*
		 * Le passage par le journal temporaire ne dépend plus d'un interrupteur
		 * global mais de la POLITIQUE DE L'ORIGINE : la caisse peut publier en
		 * fin de journée pendant que la pharmacie publie en temps réel et que
		 * les achats attendent la signature d'un comptable.
		 *
		 * L'option 'brouillard' reste prioritaire : elle sert aux traitements
		 * techniques — reprises, imports, tests — qui doivent pouvoir imposer
		 * leur comportement quelle que soit la configuration de la société.
		 */
		$forcer = array_key_exists( 'brouillard', $opts ) ? $opts['brouillard'] : null;
		if ( null !== $forcer ) {
			$brouillard = (bool) $forcer;
		} elseif ( class_exists( 'FKC_PolitiqueCompta' ) ) {
			$brouillard = FKC_PolitiqueCompta::differe( $opts['source'] ?? 'manuelle' );
		} else {
			$brouillard = FKC_Brouillard::enabled();
		}

		if ( $brouillard ) {
			$source = isset( $opts['source'] ) ? $opts['source'] : 'manuelle';
			$lien   = isset( $opts['lien'] ) ? $opts['lien'] : null;
			// La provenance transite par l'en-tête : le brouillon la stocke, la
			// validation la restitue. Sans ce passage, elle mourait au dépôt.
			foreach ( array( 'origine', 'fait', 'referentiel', 'regime' ) as $cle ) {
				if ( ! empty( $opts[ $cle ] ) && empty( $entete[ $cle ] ) ) { $entete[ $cle ] = $opts[ $cle ]; }
			}
			// La source sert aussi au contrôle des comptes de regroupement.
			if ( empty( $entete['source'] ) ) { $entete['source'] = $source; }
			list( $ok, $msg, $bid ) = FKC_Brouillard::save( $entete, $lignes, $source, $lien );
			return array( $ok, $msg, null, $ok ? (int) $bid : null );
		}

		/*
		 * CHEMIN DIRECT — la provenance doit suivre ici AUSSI.
		 *
		 * Une écriture en comptabilisation immédiate ne passe pas par le
		 * journal temporaire : si la trace n'était portée que par le
		 * brouillon, les dossiers réglés en « immédiate » n'auraient jamais
		 * de provenance, et le trou serait invisible parce qu'il ne
		 * concernerait qu'une partie du parc.
		 */
		foreach ( array( 'source', 'origine', 'fait', 'referentiel', 'regime' ) as $cle ) {
			if ( ! empty( $opts[ $cle ] ) && empty( $entete[ $cle ] ) ) { $entete[ $cle ] = $opts[ $cle ]; }
		}
		if ( ! empty( $opts['lien'] ) && empty( $entete['lien'] ) ) { $entete['lien'] = $opts['lien']; }

		list( $ok, $msg, $eid ) = self::save( $entete, $lignes );
		if ( $ok && ! empty( $opts['lien'] ) ) {
			FKC_Brouillard::backfill( $opts['lien'], $eid );
		}
		/*
		 * PONT ÉCRITURE → PIÈCE D'ORIGINE (1.621.0).
		 *
		 * L'écriture qui arrive ici SANS lien vient presque toujours de
		 * FKC_Posting, qui n'en pose jamais : les 228 événements des packs
		 * produisent donc des écritures sans pièce d'origine. Le rattachement
		 * ne peut pas se faire maintenant — le module inscrira `ecriture_id`
		 * sur sa pièce APRÈS ce retour, avec l'identifiant qu'il vient de
		 * recevoir. On demande donc un balayage différé, qui lira ce lien
		 * une fois posé.
		 *
		 * La demande est groupée (un seul balayage en attente à la fois) et
		 * ne retarde rien : c'est exactement l'usage pour lequel la file
		 * existe.
		 */
		if ( $ok && empty( $opts['lien'] ) && class_exists( 'FKC_Origine' ) ) {
			try { FKC_Origine::demander(); } catch ( \Throwable $e ) { /* la trace attendra */ }
		}
		/*
		 * Les états s'appuient sur une carte de soldes mémorisée par période.
		 * Sans cette purge, un contrôleur qui comptabilise puis affiche dans la
		 * même requête lirait la situation d'AVANT l'écriture qu'il vient
		 * d'accepter.
		 */
		if ( $ok && class_exists( 'FKC_EtatsDgi' ) ) { FKC_EtatsDgi::oublierSoldes(); }
		if ( $ok && class_exists( 'FKC_Maestro' ) ) { FKC_Maestro::invaliderCache(); }
		return array( $ok, $msg, $ok ? (int) $eid : null, null );
	}
}
