<?php
/**
 * État de comptabilisation d'un document, pour les LISTES (1.742.0).
 *
 * ─────────────────────────────────────────────────────────────────────────
 * LE DÉFAUT
 *
 * Les fiches savaient dire « Comptabilisée — écriture n° » ou « Au journal
 * temporaire » (1.729.0). Les listes, elles, ne disaient rien : une facture
 * comptabilisée et une facture oubliée s'y ressemblaient trait pour trait.
 * Pour savoir ce qui restait à passer, il fallait ouvrir les fiches une par
 * une — ce que personne ne fait, et c'est ainsi qu'une facture sort de la
 * comptabilité sans que rien ne le signale.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * TROIS ÉTATS, PAS DEUX
 *
 * La politique de comptabilisation range par défaut les écritures au journal
 * temporaire (1.541.0). « Comptabilisée / non comptabilisée » serait donc un
 * mensonge par omission : l'écriture d'une facture « non comptabilisée » peut
 * très bien exister et attendre un clic. On distingue :
 *
 *   comptabilisee    `ecriture_id` renseigné — l'écriture est au journal
 *   attente          un brouillon rattaché attend d'être validé
 *   a_comptabiliser  ni l'un ni l'autre — rien n'a été produit
 *   sans_objet       document annulé qui n'a jamais été comptabilisé
 *
 * La règle est la même que celle des fiches (Facture::editable(),
 * factures/show.php) : un seul point de vérité, lu ici en lot.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EtatCompta {

	const COMPTABILISEE   = 'comptabilisee';
	const ATTENTE         = 'attente';
	const A_COMPTABILISER = 'a_comptabiliser';
	const SANS_OBJET      = 'sans_objet';

	/**
	 * Libellés courts et DISTINCTS à la frappe : le filtre instantané des
	 * listes cherche dans le texte de la ligne, « comptabilisée » ne doit pas
	 * attraper « à comptabiliser ».
	 */
	public static function libelles() {
		return array(
			self::COMPTABILISEE   => 'Comptabilisée',
			self::ATTENTE         => 'Au brouillard',
			self::A_COMPTABILISER => 'À comptabiliser',
			self::SANS_OBJET      => 'Sans écriture',
		);
	}

	/**
	 * État de chaque ligne d'une liste.
	 *
	 * @param string $table Table du document, telle que déclarée dans le lien
	 *                      du brouillon (`factures`, `factures_fournisseurs`).
	 * @param array  $rows  Lignes lues en base (id, ecriture_id, statut).
	 * @return array<int, array{etat:string, ecriture_id:int, brouillons:int[]}>
	 */
	public static function pour( $table, array $rows ) {
		$ids = array();
		foreach ( $rows as $r ) {
			if ( empty( $r['ecriture_id'] ) ) { $ids[] = (int) $r['id']; }
		}
		$attente = ( $ids && class_exists( 'FKC_Brouillard' ) ) ? FKC_Brouillard::pendingMap( $table, $ids ) : array();
		/*
		 * 1.745.0 — une pièce contre-passée perd son `ecriture_id` (la
		 * contre-passation la délie). Annulée, elle doit pourtant se lire
		 * « Contre-passée », pas « Sans écriture » : on retrouve l'écriture
		 * d'origine dans la piste des annulations.
		 */
		$annulees = array();
		foreach ( $rows as $r ) {
			if ( empty( $r['ecriture_id'] ) && self::annulee( $r ) ) { $annulees[] = (int) $r['id']; }
		}
		$histo = array();
		if ( $annulees ) {
			try {
				$in = implode( ',', array_map( 'intval', $annulees ) );
				foreach ( FKC_DB::q( "SELECT ligne_id, MAX(ecriture_id) e FROM ecriture_annulations WHERE table_source=? AND ligne_id IN ({$in}) GROUP BY ligne_id", array( $table ) )->fetchAll() as $h ) {
					$histo[ (int) $h['ligne_id'] ] = (int) $h['e'];
				}
			} catch ( \Throwable $e ) { /* journal absent : aucune annulation n'a eu lieu */ }
		}

		$out = array();
		foreach ( $rows as $r ) {
			$id  = (int) $r['id'];
			$eid = (int) ( $r['ecriture_id'] ?? 0 );
			if ( ! $eid && isset( $histo[ $id ] ) ) { $eid = $histo[ $id ]; }
			if ( $eid > 0 ) {
				$etat = self::COMPTABILISEE;
			} elseif ( ! empty( $attente[ $id ] ) ) {
				$etat = self::ATTENTE;
			} elseif ( self::annulee( $r ) ) {
				$etat = self::SANS_OBJET;
			} else {
				$etat = self::A_COMPTABILISER;
			}
			$out[ $id ] = array( 'etat' => $etat, 'ecriture_id' => $eid, 'brouillons' => $attente[ $id ] ?? array() );
		}
		return $out;
	}

	/** Décompte par état, pour les compteurs en tête de liste. */
	public static function compter( array $etats ) {
		$n = array( self::COMPTABILISEE => 0, self::ATTENTE => 0, self::A_COMPTABILISER => 0, self::SANS_OBJET => 0 );
		foreach ( $etats as $e ) { $n[ $e['etat'] ] = ( $n[ $e['etat'] ] ?? 0 ) + 1; }
		return $n;
	}

	/**
	 * Ne garde que les lignes dans l'état demandé. Un filtre inconnu ne filtre
	 * rien — on n'affiche jamais une liste vide pour une faute de frappe dans
	 * l'adresse.
	 */
	public static function filtrer( array $rows, array $etats, $filtre ) {
		if ( ! isset( self::libelles()[ (string) $filtre ] ) ) { return $rows; }
		return array_values( array_filter( $rows, function ( $r ) use ( $etats, $filtre ) {
			return ( $etats[ (int) $r['id'] ]['etat'] ?? '' ) === $filtre;
		} ) );
	}

	/** Filtre lu dans la requête, validé. */
	public static function filtreDemande() {
		$f = (string) ( $_GET['compta'] ?? '' );
		return isset( self::libelles()[ $f ] ) ? $f : '';
	}

	protected static function annulee( array $r ) {
		return 0 === stripos( (string) ( $r['statut'] ?? '' ), 'annul' );
	}
}
