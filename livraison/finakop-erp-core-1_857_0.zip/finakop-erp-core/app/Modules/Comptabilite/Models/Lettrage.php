<?php
/**
 * Lettrage des écritures de tiers : rapprochement débit/crédit sur un compte
 * collectif (411 clients / 401 fournisseurs) via un code-lettre partagé.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Lettrage {

	/** Convertit 1→A, 26→Z, 27→AA … */
	public static function numToAlpha( $n ) {
		$n = (int) $n; $s = '';
		while ( $n > 0 ) { $n--; $s = chr( 65 + ( $n % 26 ) ) . $s; $n = intdiv( $n, 26 ); }
		return $s ?: 'A';
	}
	/** Convertit A→1, Z→26, AA→27 … */
	public static function alphaToNum( $s ) {
		$s = strtoupper( trim( (string) $s ) ); $n = 0;
		for ( $i = 0, $L = strlen( $s ); $i < $L; $i++ ) {
			$c = ord( $s[ $i ] );
			if ( $c < 65 || $c > 90 ) { return 0; }
			$n = $n * 26 + ( $c - 64 );
		}
		return $n;
	}

	/** Prochain code-lettre disponible (séquence globale sur le grand livre). */
	public static function nextCode() {
		$max = 0;
		foreach ( FKC_DB::q( "SELECT DISTINCT lettre FROM ecriture_lignes WHERE lettre IS NOT NULL AND lettre<>''" )->fetchAll() as $r ) {
			$max = max( $max, self::alphaToNum( $r['lettre'] ) );
		}
		return self::numToAlpha( $max + 1 );
	}

	/** Solde net (débit - crédit) d'un ensemble de lignes. */
	public static function soldeOf( $ids ) {
		$ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		if ( ! $ids ) { return 0.0; }
		$in = implode( ',', array_fill( 0, count( $ids ), '?' ) );
		return (float) FKC_DB::q( "SELECT COALESCE(SUM(debit-credit),0) FROM ecriture_lignes WHERE id IN ($in)", $ids )->fetchColumn();
	}

	/**
	 * Lettre un ensemble de lignes (déjà non lettrées). $force permet le lettrage
	 * partiel (solde non nul). Renvoie array( ok, message, code|null ).
	 */
	public static function lettrer( $ids, $force = false ) {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ) ) ) );
		if ( count( $ids ) < 2 ) { return array( false, 'Sélectionnez au moins deux lignes à lettrer.', null ); }
		$in = implode( ',', array_fill( 0, count( $ids ), '?' ) );
		// Toutes les lignes doivent être actuellement non lettrées.
		$dejaLet = (int) FKC_DB::q( "SELECT COUNT(*) FROM ecriture_lignes WHERE id IN ($in) AND lettre IS NOT NULL AND lettre<>''", $ids )->fetchColumn();
		if ( $dejaLet > 0 ) { return array( false, 'Certaines lignes sont déjà lettrées — délettrez-les d\'abord.', null ); }
		/*
		 * ON NE LETTRE QUE DES LIGNES DU MÊME COMPTE.
		 *
		 * Le contrôle manquait : lettrer() vérifiait l'équilibre et l'absence
		 * de double-lettrage, jamais l'appartenance. GrandLivreController
		 * transmet les identifiants du POST tels quels. Tant que l'écran est
		 * filtré sur un tiers, le risque reste théorique — mais en vue « tous
		 * tiers », rien n'empêchait de lettrer ensemble une facture du client A
		 * et un règlement du fournisseur B qui se compensent par hasard. Les
		 * deux soldes auxiliaires se seraient alors apurés à tort, chacun de
		 * son côté, sans qu'aucune balance ne s'en aperçoive : le lettrage ne
		 * touche pas aux montants, seulement à leur suivi.
		 *
		 * La règle est ici, dans le modèle, et non dans l'écran : un import,
		 * une reprise ou un futur écran doivent buter dessus de la même façon.
		 * Défense en profondeur — l'interface peut changer, l'invariant non.
		 */
		$comptes = FKC_DB::q(
			"SELECT DISTINCT compte_id FROM ecriture_lignes WHERE id IN ($in)", $ids
		)->fetchAll( PDO::FETCH_COLUMN );
		if ( count( $comptes ) > 1 ) {
			$nums = FKC_DB::q(
				'SELECT numero FROM comptes WHERE id IN (' . implode( ',', array_fill( 0, count( $comptes ), '?' ) ) . ') ORDER BY numero',
				array_map( 'intval', $comptes )
			)->fetchAll( PDO::FETCH_COLUMN );
			return array( false, 'Ces lignes n\'appartiennent pas au même compte (' . implode( ', ', $nums ) . ') : '
				. 'le lettrage rapproche un débit et un crédit d\'un MÊME compte de tiers. '
				. 'Filtrez le grand livre auxiliaire sur un tiers avant de sélectionner.', null );
		}

		/*
		 * Et, quand les lignes portent un tiers (comptabilité auxiliaire), du
		 * même tiers : un compte collectif 411100 héberge tous les clients, et
		 * un même compte ne suffit donc pas à garantir un rapprochement sensé.
		 * Les lignes SANS tiers ne bloquent pas — beaucoup d'écritures
		 * légitimes n'en portent pas, et refuser reviendrait à interdire le
		 * lettrage manuel là où il rend le plus service.
		 */
		$tiers = FKC_DB::q(
			"SELECT DISTINCT tiers_type || '#' || tiers_id AS t FROM ecriture_lignes
			 WHERE id IN ($in) AND tiers_id IS NOT NULL AND tiers_type IS NOT NULL", $ids
		)->fetchAll( PDO::FETCH_COLUMN );
		if ( count( $tiers ) > 1 ) {
			return array( false, 'Ces lignes concernent des tiers différents : le lettrage rapproche '
				. 'les mouvements d\'un seul tiers sur son compte.', null );
		}

		$solde = self::soldeOf( $ids );
		if ( ! $force && round( $solde, 2 ) !== 0.0 ) {
			return array( false, 'Le rapprochement n\'est pas équilibré (solde ' . fkc_money( $solde ) . ' FCFA). Activez le lettrage partiel pour forcer.', null );
		}
		$code = self::nextCode();
		FKC_DB::q( "UPDATE ecriture_lignes SET lettre=?, lettre_at=datetime('now','localtime') WHERE id IN ($in)", array_merge( array( $code ), $ids ) );
		/*
		 * CHAÎNE DOCUMENTAIRE (1.623.0). Le lettrage EST le rapprochement
		 * entre une facture et le règlement qui la solde : `reglements` ne
		 * porte aucun `facture_id`, et ce code-lettre est la seule trace du
		 * lien. On le reporte dans la chaîne au moment où il est posé, plutôt
		 * que d'attendre le balayage — un utilisateur qui vient de lettrer
		 * doit voir le parcours complet immédiatement.
		 *
		 * Silencieux par construction : la chaîne est une vue, et refuser un
		 * lettrage juste parce qu'un registre de traçabilité n'a pas pu
		 * s'écrire serait hors de proportion.
		 */
		if ( class_exists( 'FKC_ChaineDoc' ) ) {
			try { FKC_ChaineDoc::depuisLettrage( $code ); } catch ( \Throwable $e ) { /* la vue attendra */ }
		}
		$msg = round( $solde, 2 ) === 0.0 ? 'Lettrage ' . $code . ' effectué (équilibré).' : 'Lettrage partiel ' . $code . ' effectué (solde résiduel ' . fkc_money( $solde ) . ').';
		return array( true, $msg, $code );
	}

	/** Délettre des lignes (par ids) ou tout un code-lettre. */
	public static function delettrer( $ids = array(), $code = null ) {
		/*
		 * LES MAILLONS SONT RETIRÉS AVANT L'EFFACEMENT DU CODE (1.623.0), et
		 * l'ordre est impératif : `retirerLettrage()` retrouve les documents
		 * concernés EN LISANT le code sur les lignes. Une fois le code effacé,
		 * il n'y a plus rien à lire et le maillon resterait à affirmer un
		 * rapprochement défait — exactement le défaut « le lettrage survivait
		 * à l'annulation » corrigé par FKC_EcritureLiens.
		 */
		if ( $code ) {
			if ( class_exists( 'FKC_ChaineDoc' ) ) {
				try { FKC_ChaineDoc::retirerLettrage( (string) $code ); } catch ( \Throwable $e ) {}
			}
			FKC_DB::q( "UPDATE ecriture_lignes SET lettre=NULL, lettre_at=NULL WHERE lettre=?", array( $code ) );
			return array( true, 'Lettrage ' . $code . ' annulé.' );
		}
		$ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
		if ( ! $ids ) { return array( false, 'Aucune ligne sélectionnée.' ); }
		$in = implode( ',', array_fill( 0, count( $ids ), '?' ) );
		if ( class_exists( 'FKC_ChaineDoc' ) ) {
			try {
				$codes = FKC_DB::q(
					"SELECT DISTINCT lettre FROM ecriture_lignes WHERE id IN ($in) AND lettre IS NOT NULL AND lettre<>''",
					$ids
				)->fetchAll( PDO::FETCH_COLUMN );
				foreach ( (array) $codes as $c ) { FKC_ChaineDoc::retirerLettrage( (string) $c ); }
			} catch ( \Throwable $e ) {}
		}
		FKC_DB::q( "UPDATE ecriture_lignes SET lettre=NULL, lettre_at=NULL WHERE id IN ($in)", $ids );
		return array( true, 'Lignes délettrées.' );
	}

	/**
	 * Lettrage automatique du solde nul d'un tiers : si l'ensemble des lignes non
	 * lettrées d'un tiers s'équilibre exactement, on les lettre ensemble.
	 */
	public static function autoSolde( $type, $tiersId ) {
		$opts = array( 'tiers_id' => (int) $tiersId, 'lettrage' => 'nonlettre' );
		$lignes = FKC_GrandLivreTiers::lignes( $type, $opts );
		$ids = array(); $solde = 0.0;
		foreach ( $lignes as $l ) { $ids[] = (int) $l['ligne_id']; $solde += (float) $l['debit'] - (float) $l['credit']; }
		if ( count( $ids ) < 2 ) { return array( false, 'Pas assez de lignes non lettrées.', null ); }
		if ( round( $solde, 2 ) !== 0.0 ) { return array( false, 'Le solde non lettré du tiers n\'est pas nul (' . fkc_money( $solde ) . ').', null ); }
		return self::lettrer( $ids, false );
	}
}
