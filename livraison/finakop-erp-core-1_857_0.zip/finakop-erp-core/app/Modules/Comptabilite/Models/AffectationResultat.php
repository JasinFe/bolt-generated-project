<?php
/**
 * AFFECTATION DU RÉSULTAT — la décision, et l'écriture qui la constate.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * DEUX GESTES QUE FINAKOP N'AVAIT JAMAIS SÉPARÉS
 *
 * Déterminer le résultat et l'affecter sont deux opérations distinctes, à
 * deux moments distincts, décidées par deux instances distinctes :
 *
 *   — la DÉTERMINATION est un calcul. Elle solde les classes 6, 7 et 8 vers
 *     131 (bénéfice) ou 139 (perte), le dernier jour de l'exercice. Le
 *     comptable la fait, personne ne la vote.
 *
 *   — l'AFFECTATION est une DÉCISION. Elle répartit ce résultat entre réserve
 *     légale, réserves statutaires, report à nouveau et dividendes. Elle
 *     appartient à l'assemblée générale ordinaire, qui se tient après la
 *     clôture — dans les six mois, en droit OHADA — et elle se constate au
 *     vu de son procès-verbal, dans l'exercice SUIVANT.
 *
 * FinaKop n'avait que la première. Le résultat restait indéfiniment sur
 * 131/139, et les à-nouveaux le reportaient d'année en année. Pire : quand
 * l'écriture d'à-nouveaux ne s'équilibrait pas, l'ancien code logeait
 * l'écart en 121/129 — c'est-à-dire qu'il affectait, tout seul, en report à
 * nouveau, un résultat dont aucune assemblée n'avait délibéré, et sans
 * qu'aucune trace ne dise que c'était arrivé.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * CE QUE CE MODULE IMPOSE
 *
 *   — l'exercice doit être CLÔTURÉ : on n'affecte pas un résultat qui peut
 *     encore bouger ;
 *   — la somme des affectations doit valoir EXACTEMENT le résultat, au
 *     centime. Pas de reliquat, pas d'ajustement automatique : un franc qui
 *     manque est un franc que personne n'a attribué, et l'écran doit le dire
 *     plutôt que de le loger quelque part ;
 *   — un justificatif est exigé (référence du procès-verbal) : c'est la
 *     pièce comptable de l'écriture, et sans elle l'écriture n'en a pas ;
 *   — la réserve légale est CALCULÉE et rappelée — sans être imposée, car
 *     l'obligation dépend de la forme sociale, et FinaKop ne la connaît pas
 *     toujours.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * L'ORDRE N'EST PAS IMPOSÉ, ET C'EST VOULU
 *
 * L'affectation peut être enregistrée AVANT ou APRÈS l'ouverture de N+1 :
 *
 *   — avant : les à-nouveaux reportent directement 111, 121, 465… et 131/139
 *     sont à zéro. C'est la tenue la plus lisible ;
 *   — après : les à-nouveaux reportent 131/139 en instance, et l'écriture
 *     d'affectation, datée du jour de l'assemblée, les solde dans N+1. C'est
 *     la pratique la plus courante, puisque l'assemblée se tient en cours
 *     d'exercice suivant.
 *
 * Les deux sont régulières. Le rapprochement N/N+1 sait les distinguer, et
 * ne signale pas comme écart un compte mouvementé par l'affectation.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AffectationResultat {

	protected static $ready = false;

	/** Tolérance : aucune. Une affectation se boucle au franc près. */
	const TOLERANCE = 0.005;

	/* ── Registre ─────────────────────────────────────────────────────────── */

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		try {
			FKC_DB::conn()->exec( "
				CREATE TABLE IF NOT EXISTS affectations_resultat(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					/* Un exercice n'a qu'UNE décision d'affectation : la clé
					   unique l'impose, de sorte qu'on ne puisse pas affecter
					   deux fois le même résultat. */
					exercice INTEGER NOT NULL UNIQUE,
					resultat_net REAL NOT NULL DEFAULT 0,
					sens TEXT NOT NULL DEFAULT 'benefice',
					date_decision TEXT NOT NULL,
					reference_pv TEXT NOT NULL DEFAULT '',
					note TEXT DEFAULT '',
					ecriture_id INTEGER,
					cree_par INTEGER,
					cree_nom TEXT DEFAULT '',
					cree_le TEXT DEFAULT(datetime('now','localtime'))
				);
				CREATE TABLE IF NOT EXISTS affectation_lignes(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					affectation_id INTEGER NOT NULL,
					compte_numero TEXT NOT NULL,
					compte_id INTEGER,
					libelle TEXT NOT NULL DEFAULT '',
					montant REAL NOT NULL DEFAULT 0,
					ordre INTEGER NOT NULL DEFAULT 0,
					FOREIGN KEY(affectation_id) REFERENCES affectations_resultat(id) ON DELETE CASCADE
				);
				CREATE INDEX IF NOT EXISTS idx_afl_aff ON affectation_lignes(affectation_id);
			" );
		} catch ( \Throwable $e ) { /* base indisponible : le métier continue */ }
	}

	/* ── Catalogue des destinations ───────────────────────────────────────── */

	/**
	 * Où peut aller un résultat, selon son sens.
	 *
	 * La liste n'est pas décorative : elle est la seule autorisée. Affecter un
	 * bénéfice sur un compte de charge ou sur un compte de tiers autre que 465
	 * n'est pas une affectation, c'est une erreur d'imputation — et c'est
	 * exactement ce que l'ancien équilibrage par différence produisait.
	 */
	public static function destinations( $sens = 'benefice' ) {
		if ( 'perte' === $sens ) {
			return array(
				'129' => array( 'label' => 'Report à nouveau débiteur', 'note' => 'Le traitement le plus courant : la perte attend d\'être absorbée par les bénéfices futurs.' ),
				'111' => array( 'label' => 'Réserve légale', 'note' => 'Imputation de la perte sur la réserve légale — possible, mais elle devra être reconstituée.' ),
				'112' => array( 'label' => 'Réserves statutaires ou contractuelles', 'note' => 'Sur décision de l\'assemblée, dans les limites des statuts.' ),
				'118' => array( 'label' => 'Autres réserves', 'note' => 'Réserves facultatives (1181) ou diverses (1188).' ),
				'121' => array( 'label' => 'Report à nouveau créditeur', 'note' => 'Lorsqu\'un report bénéficiaire antérieur absorbe tout ou partie de la perte.' ),
				'101' => array( 'label' => 'Capital social', 'note' => 'Réduction de capital motivée par les pertes — suppose une décision extraordinaire et des formalités.' ),
			);
		}
		return array(
			'111' => array( 'label' => 'Réserve légale', 'note' => 'En droit OHADA, la dotation est de 10 % du bénéfice net jusqu\'à ce que la réserve atteigne 20 % du capital (sociétés de capitaux).' ),
			'112' => array( 'label' => 'Réserves statutaires ou contractuelles', 'note' => 'Dotation prévue par les statuts.' ),
			'113' => array( 'label' => 'Réserves réglementées', 'note' => 'Plus-values à long terme, subventions d\'investissement, actions gratuites.' ),
			'118' => array( 'label' => 'Autres réserves', 'note' => 'Réserves facultatives (1181) ou diverses (1188), sur décision de l\'assemblée.' ),
			'121' => array( 'label' => 'Report à nouveau créditeur', 'note' => 'La part non distribuée et non mise en réserve, laissée en attente.' ),
			'129' => array( 'label' => 'Report à nouveau débiteur', 'note' => 'Apurement d\'un report déficitaire antérieur : le bénéfice l\'absorbe en priorité.' ),
			'465' => array( 'label' => 'Associés, dividendes à payer', 'note' => 'Part distribuée. Elle devient une dette envers les associés, à régler et, le cas échéant, à soumettre à l\'IRVM.' ),
			'421' => array( 'label' => 'Personnel — participation aux bénéfices', 'note' => 'Lorsqu\'un accord de participation la prévoit.' ),
		);
	}

	/* ── Lectures ─────────────────────────────────────────────────────────── */

	public static function find( $exercice ) {
		self::ensure();
		try {
			$a = FKC_DB::q( 'SELECT * FROM affectations_resultat WHERE exercice=?', array( (int) $exercice ) )->fetch();
			if ( ! $a ) { return null; }
			$a['lignes'] = FKC_DB::q(
				'SELECT * FROM affectation_lignes WHERE affectation_id=? ORDER BY ordre, id',
				array( (int) $a['id'] )
			)->fetchAll();
			return $a;
		} catch ( \Throwable $e ) { return null; }
	}

	public static function estAffecte( $exercice ) {
		return null !== self::find( $exercice );
	}

	public static function toutes( $limite = 50 ) {
		self::ensure();
		try {
			return FKC_DB::q( 'SELECT * FROM affectations_resultat ORDER BY exercice DESC LIMIT ' . max( 1, (int) $limite ) )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/**
	 * Numéros de comptes mouvementés par l'affectation d'un exercice.
	 *
	 * Sert au rapprochement N/N+1 : ces comptes ont légitimement bougé entre
	 * la clôture et l'ouverture, et les signaler comme écarts ferait crier au
	 * loup sur l'opération la plus normale qui soit.
	 */
	public static function comptesConcernes( $exercice ) {
		$a = self::find( $exercice );
		if ( ! $a ) { return array(); }
		$out = array( '131000', '139000', '131', '139' );
		foreach ( (array) $a['lignes'] as $l ) {
			$out[] = (string) $l['compte_numero'];
			// Le plan est à six caractères : on ajoute les deux formes pour que
			// la comparaison n'échoue pas sur un zéro de complément.
			$out[] = str_pad( preg_replace( '/\D/', '', (string) $l['compte_numero'] ), 6, '0' );
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Résultat net de l'exercice, tel qu'il ressort de la clôture.
	 *
	 * Lu d'abord sur la clôture annuelle enregistrée — c'est le chiffre arrêté,
	 * celui qui figure aux états financiers. À défaut, recalculé depuis les
	 * mouvements de 131/139 : un dossier repris peut porter le résultat sans
	 * porter la ligne de clôture.
	 *
	 * @return float positif = bénéfice, négatif = perte.
	 */
	public static function resultatNet( $exercice ) {
		$exercice = (int) $exercice;
		try {
			if ( class_exists( 'FKC_Exercice' ) ) {
				list( $d, $f ) = FKC_Exercice::bornes( $exercice );
				$c = FKC_DB::q(
					"SELECT resultat FROM clotures WHERE type='annuelle' AND periode_debut=? AND periode_fin=?",
					array( $d, $f )
				)->fetch();
				if ( $c && null !== $c['resultat'] ) { return round( (float) $c['resultat'], 2 ); }
			}
		} catch ( \Throwable $e ) { /* on recalcule */ }

		return class_exists( 'FKC_ClotureProcessus' ) ? FKC_ClotureProcessus::resultatNet( $exercice ) : 0.0;
	}

	/**
	 * Dotation à la réserve légale suggérée, en droit OHADA.
	 *
	 * 10 % du bénéfice net, plafonnés à ce qui manque pour que la réserve
	 * atteigne 20 % du capital social. Rendue comme SUGGESTION et non comme
	 * contrainte : l'obligation vise les sociétés de capitaux, et FinaKop ne
	 * connaît pas toujours la forme sociale du dossier. Un chiffre proposé que
	 * l'on peut remplacer vaut mieux qu'une règle imposée à tort.
	 *
	 * @return array{suggestion:float, capital:float, reserve:float, plafond:float, applicable:bool}
	 */
	public static function reserveLegale( $exercice, $benefice ) {
		$out = array( 'suggestion' => 0.0, 'capital' => 0.0, 'reserve' => 0.0, 'plafond' => 0.0, 'applicable' => false );
		if ( $benefice <= 0 ) { return $out; }
		try {
			/*
			 * Sur la PÉRIODE de l'exercice, à-nouveaux compris — et non depuis
			 * l'origine : les à-nouveaux reportent déjà tout l'historique, et
			 * cumuler par-dessus doublerait le capital, donc le plafond légal
			 * de la réserve. Même raisonnement que FKC_ANouveaux.
			 */
			list( $deb, $fin ) = class_exists( 'FKC_Exercice' )
				? FKC_Exercice::bornes( (int) $exercice )
				: array( sprintf( '%04d-01-01', (int) $exercice ), sprintf( '%04d-12-31', (int) $exercice ) );
			$solde = function ( $racine ) use ( $deb, $fin ) {
				$r = FKC_DB::q(
					'SELECT COALESCE(SUM(l.credit),0)-COALESCE(SUM(l.debit),0) s
					 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id
					 JOIN comptes c ON c.id=l.compte_id
					 WHERE c.numero LIKE ? AND e.date_ecriture BETWEEN ? AND ?', array( $racine . '%', $deb, $fin )
				)->fetch();
				return round( (float) $r['s'], 2 );
			};
			$out['capital'] = $solde( '101' );
			$out['reserve'] = $solde( '111' );
		} catch ( \Throwable $e ) { return $out; }

		if ( $out['capital'] <= 0 ) { return $out; }
		$out['applicable'] = true;
		$out['plafond']    = round( $out['capital'] * 0.20, 2 );
		$manque            = max( 0.0, $out['plafond'] - $out['reserve'] );
		$out['suggestion'] = round( min( $benefice * 0.10, $manque ), 2 );
		return $out;
	}

	/**
	 * Prépare l'écran d'affectation : ce qu'il y a à affecter, et les repères.
	 *
	 * @return array
	 */
	public static function preparer( $exercice ) {
		$exercice = (int) $exercice;
		$resultat = self::resultatNet( $exercice );
		$sens     = $resultat >= 0 ? 'benefice' : 'perte';
		$clos     = class_exists( 'FKC_ClotureProcessus' ) && FKC_ClotureProcessus::exerciceClos( $exercice );

		return array(
			'exercice'      => $exercice,
			'resultat'      => $resultat,
			'montant'       => abs( $resultat ),
			'sens'          => $sens,
			'clos'          => $clos,
			'deja'          => self::find( $exercice ),
			'destinations'  => self::destinations( $sens ),
			'reserve_legale'=> self::reserveLegale( $exercice, max( 0.0, $resultat ) ),
			'date_defaut'   => self::dateDecisionDefaut( $exercice ),
			'compte_source' => $resultat >= 0 ? '131' : '139',
		);
	}

	/* ── Enregistrement ───────────────────────────────────────────────────── */

	/**
	 * Enregistre la décision d'affectation et passe l'écriture.
	 *
	 * @param int   $exercice Exercice dont le résultat est affecté.
	 * @param array $lignes   Liste de array( 'compte' => '111', 'montant' => 1200000, 'libelle' => '' ).
	 * @param array $opts     date_decision, reference_pv, note.
	 * @return array{bool,string,int|null} ( ok, message, ecriture_id )
	 */
	public static function enregistrer( $exercice, array $lignes, array $opts = array() ) {
		self::ensure();
		$exercice = (int) $exercice;

		/* ── Contrôles de recevabilité ───────────────────────────────────── */

		if ( self::estAffecte( $exercice ) ) {
			return self::refus( $exercice, 'Le résultat ' . $exercice . ' est déjà affecté. '
				. 'Annulez d\'abord la décision existante si l\'assemblée en a pris une nouvelle.' );
		}

		if ( class_exists( 'FKC_ClotureProcessus' ) && ! FKC_ClotureProcessus::exerciceClos( $exercice ) ) {
			return self::refus( $exercice, 'L\'exercice ' . $exercice . ' n\'est pas clôturé : son résultat peut '
				. 'encore changer. Affecter maintenant reviendrait à répartir un montant qui n\'est pas arrêté — '
				. 'et la répartition ne serait plus la bonne dès la première écriture ajoutée.' );
		}

		$resultat = self::resultatNet( $exercice );
		if ( abs( $resultat ) < self::TOLERANCE ) {
			return self::refus( $exercice, 'Le résultat de l\'exercice ' . $exercice . ' est nul : il n\'y a rien à affecter.' );
		}
		$sens    = $resultat >= 0 ? 'benefice' : 'perte';
		$montant = round( abs( $resultat ), 2 );

		$refPv = trim( (string) ( $opts['reference_pv'] ?? '' ) );
		if ( mb_strlen( $refPv ) < 3 ) {
			return self::refus( $exercice, 'Référence du procès-verbal manquante. L\'affectation constate une '
				. 'décision d\'assemblée : sans sa référence, l\'écriture n\'a pas de pièce justificative, et '
				. 'une écriture sans pièce est irrégulière.' );
		}

		$dateDecision = trim( (string) ( $opts['date_decision'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dateDecision ) ) { $dateDecision = self::dateDecisionDefaut( $exercice ); }
		$finEx = class_exists( 'FKC_Exercice' ) ? FKC_Exercice::finDe( $exercice ) : sprintf( '%04d-12-31', $exercice );
		if ( $dateDecision <= $finEx ) {
			return self::refus( $exercice, 'La date de décision (' . date( 'd/m/Y', strtotime( $dateDecision ) ) . ') '
				. 'tombe avant la clôture de l\'exercice (' . date( 'd/m/Y', strtotime( $finEx ) ) . '). '
				. 'Une assemblée ne peut pas affecter un résultat qui n\'est pas encore arrêté : la décision '
				. 'appartient à l\'exercice suivant.' );
		}

		/* ── Contrôle des lignes ─────────────────────────────────────────── */

		$autorisees = self::destinations( $sens );
		$propres    = array(); $total = 0.0;
		foreach ( $lignes as $l ) {
			$num = preg_replace( '/\D/', '', (string) ( $l['compte'] ?? '' ) );
			$mt  = round( (float) ( $l['montant'] ?? 0 ), 2 );
			if ( $mt <= 0 ) { continue; }
			if ( '' === $num ) { return self::refus( $exercice, 'Une ligne d\'affectation ne désigne aucun compte.' ); }

			$racine = substr( $num, 0, 3 );
			if ( ! isset( $autorisees[ $racine ] ) ) {
				return self::refus( $exercice, 'Le compte ' . $num . ' n\'est pas une destination admise pour '
					. ( 'benefice' === $sens ? 'un bénéfice' : 'une perte' ) . '. Destinations possibles : '
					. implode( ', ', array_keys( $autorisees ) ) . '.' );
			}
			$propres[] = array(
				'numero'  => $num,
				'racine'  => $racine,
				'montant' => $mt,
				'libelle' => trim( (string) ( $l['libelle'] ?? '' ) ) ?: $autorisees[ $racine ]['label'],
			);
			$total += $mt;
		}

		if ( ! $propres ) { return self::refus( $exercice, 'Aucune ligne d\'affectation saisie.' ); }

		$ecart = round( $montant - $total, 2 );
		if ( abs( $ecart ) >= self::TOLERANCE ) {
			/*
			 * PAS D'AJUSTEMENT AUTOMATIQUE. C'est le défaut de l'ancienne
			 * génération d'à-nouveaux, transposé ici : loger le reliquat
			 * « quelque part » pour que ça tombe juste. Un franc non attribué
			 * est un franc dont personne n'a décidé du sort.
			 */
			return self::refus( $exercice, 'La répartition ne boucle pas : résultat à affecter '
				. fkc_money( $montant ) . ' F CFA, réparti ' . fkc_money( $total ) . ' F CFA — '
				. ( $ecart > 0 ? 'il reste ' . fkc_money( $ecart ) . ' F CFA à attribuer.'
				                : 'vous avez attribué ' . fkc_money( -$ecart ) . ' F CFA de trop.' )
				. ' FinaKop n\'ajuste pas de lui-même : le reliquat doit être attribué par la décision, pas par le logiciel.' );
		}

		/* ── Écriture ────────────────────────────────────────────────────── */

		try {
			return FKC_Tx::executer( function () use ( $exercice, $propres, $montant, $sens, $resultat, $dateDecision, $refPv, $opts ) {

				// Unicité revérifiée dans la transaction (voir FKC_ANouveaux).
				if ( self::estAffecte( $exercice ) ) {
					throw new \RuntimeException( 'Le résultat ' . $exercice . ' vient d\'être affecté par ailleurs.' );
				}

				list( $cSource, $errSource ) = self::compteImputable( 'benefice' === $sens ? '131' : '139' );
				if ( ! $cSource ) { throw new \RuntimeException( $errSource ); }

				$lignesEcriture = array();

				// Le compte de résultat est soldé : débité pour un bénéfice,
				// crédité pour une perte.
				$lignesEcriture[] = array(
					'compte_id' => (int) $cSource['id'],
					'libelle'   => 'Affectation du résultat ' . $exercice,
					'debit'     => 'benefice' === $sens ? $montant : 0,
					'credit'    => 'benefice' === $sens ? 0 : $montant,
				);

				$lignesStock = array();
				foreach ( $propres as $p ) {
					list( $c, $err ) = self::compteImputable( $p['numero'] );
					if ( ! $c ) { throw new \RuntimeException( $err ); }
					$lignesEcriture[] = array(
						'compte_id' => (int) $c['id'],
						'libelle'   => $p['libelle'] . ' — résultat ' . $exercice,
						'debit'     => 'benefice' === $sens ? 0 : $p['montant'],
						'credit'    => 'benefice' === $sens ? $p['montant'] : 0,
					);
					$lignesStock[] = array(
						'numero' => (string) $c['numero'], 'compte_id' => (int) $c['id'],
						'libelle' => $p['libelle'], 'montant' => $p['montant'],
					);
				}

				$jod = self::journal( 'OD' );
				if ( ! $jod ) { throw new \RuntimeException( 'Journal OD (opérations diverses) introuvable.' ); }

				list( $ok, $msg, $eid ) = FKC_Ecriture::save(
					array(
						'journal_id'    => $jod,
						'date_ecriture' => $dateDecision,
						'libelle'       => 'Affectation du résultat ' . $exercice . ' — ' . $refPv,
						'reference'     => $refPv,
						'piece'         => $refPv,
						'created_by'    => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
						'source'        => 'cloture',
						'origine'       => 'affectation',
						'fait'          => 'affectation_resultat',
					),
					$lignesEcriture
				);
				if ( ! $ok ) { throw new \RuntimeException( 'Écriture d\'affectation refusée : ' . $msg ); }

				$nom = '';
				try {
					$u = class_exists( 'FKC_Auth' ) ? FKC_Auth::user() : null;
					if ( is_array( $u ) ) { $nom = (string) ( $u['nom'] ?? $u['login'] ?? $u['email'] ?? '' ); }
				} catch ( \Throwable $e ) { $nom = ''; }

				FKC_DB::q(
					'INSERT INTO affectations_resultat(exercice,resultat_net,sens,date_decision,reference_pv,note,ecriture_id,cree_par,cree_nom)
					 VALUES(?,?,?,?,?,?,?,?,?)',
					array( $exercice, $resultat, $sens, $dateDecision, mb_substr( $refPv, 0, 120 ),
						mb_substr( (string) ( $opts['note'] ?? '' ), 0, 1000 ), (int) $eid,
						class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null, mb_substr( $nom, 0, 120 ) )
				);
				$aid = (int) FKC_DB::conn()->lastInsertId();

				$i = 0;
				foreach ( $lignesStock as $s ) {
					FKC_DB::q(
						'INSERT INTO affectation_lignes(affectation_id,compte_numero,compte_id,libelle,montant,ordre) VALUES(?,?,?,?,?,?)',
						array( $aid, $s['numero'], $s['compte_id'], mb_substr( $s['libelle'], 0, 200 ), $s['montant'], $i++ )
					);
				}

				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $exercice, 'affectation', array(
						'libelle' => 'Affectation du résultat ' . $exercice . ' (' . ( 'benefice' === $sens ? 'bénéfice' : 'perte' )
							. ' de ' . fkc_money( $montant ) . ' F CFA) en ' . count( $lignesStock ) . ' poste(s)',
						'motif'   => (string) ( $opts['note'] ?? '' ),
						'reference' => $refPv,
						'montant' => $resultat,
						'ecriture_id' => (int) $eid,
						'detail'  => $lignesStock,
					) );
				}

				return array( true, 'Résultat ' . $exercice . ' affecté : ' . fkc_money( $montant )
					. ' F CFA répartis en ' . count( $lignesStock ) . ' poste(s), écriture du '
					. date( 'd/m/Y', strtotime( $dateDecision ) ) . ' (' . $refPv . ').', (int) $eid );
			} );
		} catch ( \Throwable $e ) {
			return self::refus( $exercice, $e->getMessage() );
		}
	}

	/**
	 * Annule une affectation : contre-passe l'écriture et efface la décision.
	 *
	 * Réservée à l'administrateur, motif obligatoire. On CONTRE-PASSE plutôt
	 * que de supprimer : l'écriture d'affectation est datée de l'exercice
	 * suivant, souvent déjà partiellement clôturé, et l'effacer laisserait un
	 * trou dans une numérotation que l'AUDCIF veut ininterrompue.
	 *
	 * @return array{bool,string}
	 */
	public static function annuler( $exercice, $motif = '' ) {
		self::ensure();
		$exercice = (int) $exercice;
		$a = self::find( $exercice );
		if ( ! $a ) { return array( false, 'Aucune affectation enregistrée pour ' . $exercice . '.' ); }

		if ( ! class_exists( 'FKC_Auth' ) || ! FKC_Auth::isAdmin() ) {
			return array( false, 'Annuler une affectation de résultat est réservé à l\'administrateur du dossier.' );
		}
		$motif = trim( (string) $motif );
		if ( mb_strlen( $motif ) < 15 ) {
			return array( false, 'Motif obligatoire : expliquez pourquoi la décision d\'affectation est reprise '
				. '(nouvelle assemblée, erreur de saisie du procès-verbal…). Il sera consigné au journal de clôture.' );
		}

		try {
			return FKC_Tx::executer( function () use ( $a, $exercice, $motif ) {
				$msgContre = '';
				if ( ! empty( $a['ecriture_id'] ) && class_exists( 'FKC_EcritureAnnulation' ) ) {
					list( $ok, $m ) = FKC_EcritureAnnulation::contrepasser( (int) $a['ecriture_id'], null );
					if ( ! $ok ) {
						throw new \RuntimeException( 'L\'écriture d\'affectation n\'a pas pu être contre-passée : ' . $m
							. ' L\'affectation est laissée en l\'état — supprimer la décision en gardant son écriture '
							. 'produirait un résultat affecté que rien ne documente.' );
					}
					$msgContre = ' Écriture contre-passée.';
				}
				FKC_DB::q( 'DELETE FROM affectation_lignes WHERE affectation_id=?', array( (int) $a['id'] ) );
				FKC_DB::q( 'DELETE FROM affectations_resultat WHERE id=?', array( (int) $a['id'] ) );

				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $exercice, 'affectation_annulee', array(
						'issue' => 'avertissement',
						'libelle' => 'Affectation du résultat ' . $exercice . ' annulée (PV ' . $a['reference_pv'] . ')',
						'motif' => $motif,
						'montant' => (float) $a['resultat_net'],
						'ecriture_id' => (int) $a['ecriture_id'],
					) );
				}
				return array( true, 'Affectation du résultat ' . $exercice . ' annulée.' . $msgContre
					. ' Le résultat revient en instance sur ' . ( 'benefice' === $a['sens'] ? '131' : '139' ) . '.' );
			} );
		} catch ( \Throwable $e ) {
			return array( false, $e->getMessage() );
		}
	}

	/* ── Interne ──────────────────────────────────────────────────────────── */

	/**
	 * Date d'assemblée proposée par défaut.
	 *
	 * Aujourd'hui si nous sommes déjà dans l'exercice suivant ; sinon le
	 * lendemain de la clôture. Jamais une date antérieure à la clôture, qui
	 * serait refusée par le contrôle de recevabilité — proposer une valeur
	 * qu'on va soi-même rejeter est un défaut d'écran classique.
	 */
	public static function dateDecisionDefaut( $exercice ) {
		$fin = class_exists( 'FKC_Exercice' ) ? FKC_Exercice::finDe( (int) $exercice ) : sprintf( '%04d-12-31', (int) $exercice );
		$today = date( 'Y-m-d' );
		return $today > $fin ? $today : date( 'Y-m-d', strtotime( $fin . ' +1 day' ) );
	}

	/**
	 * Résout un numéro vers un compte IMPUTABLE, en le créant si besoin.
	 *
	 * Même précaution que partout ailleurs dans la clôture : un compte
	 * principal subdivisé dans ce dossier devient un poste d'agrégation, sur
	 * lequel FKC_Ecriture::prepare() refuse — à juste titre — d'imputer. On
	 * descend alors sur la première subdivision réelle plutôt que d'échouer
	 * sur un message de plan comptable que rien ne relie à l'affectation.
	 *
	 * @return array{array|null,string} ( compte, message d'erreur )
	 */
	protected static function compteImputable( $numero ) {
		$numero = preg_replace( '/\D/', '', (string) $numero );
		if ( '' === $numero ) { return array( null, 'Numéro de compte vide.' ); }

		$c = FKC_Compte::byNumero( $numero );
		if ( ! $c ) {
			$labels = array(
				'111' => 'Réserve légale', '112' => 'Réserves statutaires ou contractuelles',
				'113' => 'Réserves réglementées', '118' => 'Autres réserves',
				'121' => 'Report à nouveau créditeur', '129' => 'Report à nouveau débiteur',
				'131' => 'Résultat net : bénéfice', '139' => 'Résultat net : perte',
				'465' => 'Associés, dividendes à payer', '421' => 'Personnel, participation aux bénéfices',
				'101' => 'Capital social',
			);
			$racine = substr( $numero, 0, 3 );
			if ( ! isset( $labels[ $racine ] ) ) {
				return array( null, 'Compte ' . $numero . ' introuvable au plan comptable de ce dossier.' );
			}
			FKC_Compte::create( $numero, $labels[ $racine ], 'detail' );
			$c = FKC_Compte::byNumero( $numero );
			if ( ! $c ) { return array( null, 'Compte ' . $numero . ' introuvable et non créable.' ); }
		}

		if ( 'titre' !== (string) ( $c['type'] ?? '' ) ) { return array( $c, '' ); }

		try {
			$sub = FKC_DB::q(
				"SELECT * FROM comptes WHERE numero LIKE ? AND numero <> ? AND type <> 'titre' AND actif = 1
				 ORDER BY numero LIMIT 1",
				array( rtrim( (string) $c['numero'], '0' ) . '%', (string) $c['numero'] )
			)->fetch();
		} catch ( \Throwable $e ) { $sub = null; }
		if ( $sub ) { return array( $sub, '' ); }

		return array( null, 'Le compte ' . $c['numero'] . ' « ' . $c['libelle'] . ' » est un poste d\'agrégation '
			. 'et n\'a aucune subdivision imputable : ouvrez-en une avant d\'affecter le résultat.' );
	}

	protected static function journal( $code ) {
		try {
			$r = FKC_DB::q( 'SELECT id FROM journaux WHERE code=? LIMIT 1', array( (string) $code ) )->fetch();
			return $r ? (int) $r['id'] : 0;
		} catch ( \Throwable $e ) { return 0; }
	}

	/** Consigne le refus et le rend à l'appelant. */
	protected static function refus( $exercice, $message ) {
		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracerRefus( $exercice, 'affectation', $message );
		}
		return array( false, $message, null );
	}
}
