<?php
/** Factures fournisseurs (achats). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AchatController {

	public function index() {
		$rows = FKC_FactureFournisseur::all();
		/*
		 * COMBIEN DE JUSTIFICATIFS PAR FACTURE. Une facture d'achat sans pièce
		 * est le premier point qu'un contrôle relève : la liste doit le montrer
		 * sans qu'on ouvre les fiches une par une.
		 */
		$pj = array();
		if ( class_exists( 'FKC_PieceJointe' ) && $rows ) {
			$pj = FKC_PieceJointe::countMap( 'facture_fournisseur', array_map( function ( $r ) { return (int) $r['id']; }, $rows ) );
		}
		$totHt = 0; $totTtc = 0;
		foreach ( $rows as $r ) { if ( 'annulee' !== $r['statut'] ) { $totHt += $r['montant_ht']; $totTtc += $r['montant_ttc']; } }
		/*
		 * ÉTAT DE COMPTABILISATION DE CHAQUE FACTURE (1.742.0). La liste ne
		 * distinguait pas une facture comptabilisée d'une facture oubliée.
		 * Les compteurs portent sur toute la liste ; le filtre ne réduit que
		 * l'affichage (les totaux restent ceux des achats, pas du filtre).
		 */
		$etats  = FKC_EtatCompta::pour( 'factures_fournisseurs', $rows );
		$nbEtat = FKC_EtatCompta::compter( $etats );
		$filtre = FKC_EtatCompta::filtreDemande();
		$liste  = $filtre ? FKC_EtatCompta::filtrer( $rows, $etats, $filtre ) : $rows;
		FKC_View::render( 'comptabilite::achats.index', array(
			'title' => 'Comptabilité · Factures fournisseurs', 'tab' => 'achats',
			'factures' => $liste, 'totHt' => $totHt, 'totTtc' => $totTtc, 'pj' => $pj, 'flash' => $this->flash(),
			'etats' => $etats, 'nbEtat' => $nbEtat, 'filtreCompta' => $filtre,
			'paiements' => class_exists( 'FKC_Imputation' ) ? FKC_Imputation::etatsPaiement( $liste, 'fournisseur' ) : array(),
			// Réceptions reçues mais pas encore facturées, et parmi elles celles
			// dont le fournisseur n'a pas été identifié : ce sont des dettes au
			// bilan qui n'ont encore aucun document à régler.
			'receptions' => class_exists( 'FKC_AchatReception' ) ? FKC_AchatReception::enAttente( null, 100 ) : array(),
			'suspens'    => class_exists( 'FKC_AchatReception' ) ? FKC_AchatReception::suspens() : array( 'nombre' => 0, 'montant' => 0 ),
			'orphelines' => class_exists( 'FKC_AchatReception' ) ? FKC_AchatReception::sansFournisseur( 50 ) : array(),
			'fournisseurs' => class_exists( 'FKC_Fournisseur' ) ? FKC_Fournisseur::all() : array(),
		) );
	}

	/**
	 * Attribue un fournisseur à une réception qui n'en avait pas.
	 *
	 * Sans cela la marchandise reçue reste une dette anonyme : elle pèse au
	 * bilan mais ne peut être ni facturée ni réglée.
	 */
	public function receptionAttribuer() {
		list( $ok, $msg ) = FKC_AchatReception::attribuer(
			(int) ( $_POST['reception_id'] ?? 0 ),
			(int) ( $_POST['fournisseur_id'] ?? 0 )
		);
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats' );
	}

	/*
	 * AXES ET VALEURS ANALYTIQUES (1.739.0).
	 *
	 * La division répond à « quelle entité de l'entreprise ? ». Les axes
	 * répondent à « selon quel angle ? » — projet, artiste, œuvre, chantier —
	 * et ce sont eux qu'un label interroge le plus souvent : « combien ce
	 * titre m'a-t-il coûté ? » n'est pas une question de division.
	 *
	 * Le moteur d'achat savait DÉJÀ imputer un axe et une valeur sur ses
	 * lignes de charge : FKC_FactureFournisseur::create() lit `axe_id` et
	 * `valeur_id` et les pose sur chaque écriture. Seul l'écran ne les
	 * demandait pas, et la facture client, elle, les demandait depuis
	 * longtemps. Un moteur prêt et un formulaire muet : les charges partaient
	 * donc sans imputation, et le résultat par axe n'avait que des produits.
	 *
	 * Ces trois aides sont copiées de FKC_FactureController — même résolution,
	 * mêmes replis silencieux si le module n'est pas vendu.
	 */
	protected function axes() {
		if ( ! class_exists( 'FKC_Axe' ) ) { return array(); }
		try { return FKC_Axe::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	protected function valeursMap() {
		$map = array();
		if ( ! class_exists( 'FKC_Valeur' ) ) { return $map; }
		foreach ( $this->axes() as $a ) {
			$opts = array();
			try {
				foreach ( FKC_Valeur::byAxe( (int) $a['id'], true ) as $v ) {
					$opts[] = array( 'id' => (int) $v['id'], 't' => $v['code'] . ' · ' . $v['libelle'] );
				}
			} catch ( \Throwable $e ) {}
			$map[ (int) $a['id'] ] = $opts;
		}
		return $map;
	}
	protected function showAxes( $lic ) {
		return in_array( 'analytique', $lic['modules'] ?? array(), true ) && count( $this->axes() ) > 0;
	}

	public function create() { $this->formulaire( null ); }

	/**
	 * Écran de correction : le MÊME formulaire, pré-rempli à partir d'une
	 * facture existante.
	 *
	 * On ne construit pas un second écran. Une saisie corrigée est une saisie :
	 * lui donner un formulaire différent, c'est se condamner à corriger deux
	 * fois chaque évolution — et à découvrir un jour que le champ ajouté d'un
	 * côté manque de l'autre. Les axes analytiques ajoutés en 1.739.0 en sont
	 * l'illustration : un second écran les aurait manqués.
	 */
	public function corrigerForm( $id ) {
		$f = FKC_FactureFournisseur::find( $id );
		if ( ! $f ) { redirect( 'comptabilite/achats' ); }
		$f['lignes'] = FKC_FactureFournisseur::lignes( $id );
		$this->formulaire( $f );
	}

	protected function formulaire( $source ) {
		$frns = FKC_Fournisseur::all();
		$divisions = array();
		if ( class_exists( 'FKC_Division' ) ) { try { $divisions = FKC_Division::all( true ); } catch ( Exception $e ) { $divisions = array(); } }
		$lic = FKC_License::resolve();
		/*
		 * Un item n'est proposé que si son compte existe (1.743.0) : sinon le
		 * choisir ne change pas le compte imputé. On ouvre d'abord les
		 * comptes déclarés qui manquent, puis on écarte les irrécupérables.
		 */
		$items = array();
		if ( class_exists( 'FKC_ItemFacturation' ) ) {
			FKC_ItemFacturation::assurerComptes( 'achat' );
			foreach ( FKC_ItemFacturation::all( 'achat', true ) as $it ) {
				if ( FKC_Compte::byNumero( (string) $it['compte'] ) ) { $items[] = $it; }
			}
		}
		FKC_View::render( 'comptabilite::achats.form', array(
			'title' => $source ? ( 'Correction · ' . $source['numero'] ) : 'Nouvelle facture fournisseur', 'tab' => 'achats',
			'source' => $source,
			'fournisseurs' => $frns, 'plan' => FKC_Compte::all(),
			'taux' => FKC_FactureFournisseur::tauxTva(), 'errors' => array(),
			'items' => $items,
			'divisions' => $divisions, 'showDivision' => in_array( 'analytique', $lic['modules'] ?? array(), true ),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes( $lic ),
			// `piece` porte déjà l'imputation analytique pré-remplie : la
			// correction s'y branche sans inventer un second chemin.
			'piece' => $source ?: array(),
			// Réceptions déjà entrées en stock par un pack métier et pas encore
			// facturées : les rattacher évite de compter l'achat deux fois.
			'receptions' => class_exists( 'FKC_AchatReception' ) ? FKC_AchatReception::enAttente() : array(),
		) );
	}

	public function store() {
		$d = $_POST;
		$d['receptions'] = isset( $_POST['receptions'] ) ? (array) $_POST['receptions'] : array();
		$d['receptions_montants'] = isset( $_POST['receptions_montants'] ) ? (array) $_POST['receptions_montants'] : array();
		/*
		 * UNE CORRECTION PASSE PAR LA MÊME PORTE QU'UNE SAISIE.
		 *
		 * `corrige_id` dit « cette facture remplace celle-là » ; le modèle
		 * extourne l'ancienne puis crée la nouvelle. Le champ vient du
		 * formulaire, donc de l'utilisateur : le modèle revérifie tout, et une
		 * facture introuvable ou déjà annulée ne fait rien perdre.
		 */
		$corrige = (int) ( $_POST['corrige_id'] ?? 0 );
		if ( $corrige > 0 ) {
			list( $ok, $msg, $id ) = FKC_FactureFournisseur::corriger( $corrige, $d );
		} else {
			list( $ok, $msg, $id ) = FKC_FactureFournisseur::create( $d );
		}
		/*
		 * LES PIÈCES SONT ATTACHÉES APRÈS COUP, ET C'EST INÉVITABLE.
		 *
		 * Une pièce jointe se range sous un identifiant ; la facture n'en a pas
		 * tant qu'elle n'existe pas. Les fichiers arrivent pourtant dans la
		 * MÊME requête : on les garde donc en main jusqu'à ce que la facture
		 * soit créée, puis on les range. Si la création échoue, ils partent
		 * avec elle — rien n'est écrit sur le disque pour une facture qui
		 * n'existera jamais.
		 *
		 * L'échec du téléversement ne fait PAS échouer la facture : l'écriture
		 * est juste, le montant est juste, et perdre tout cela parce qu'un
		 * scan dépasse 8 Mo serait le mauvais arbitrage. On le dit, et la pièce
		 * se rattache depuis la fiche.
		 */
		if ( $ok && $id && class_exists( 'FKC_PieceJointe' ) && ! empty( $_FILES['pieces']['name'][0] ) ) {
			$n = FKC_PieceJointe::addMany( 'facture_fournisseur', (int) $id, $_FILES['pieces'] );
			$attendus = count( array_filter( (array) $_FILES['pieces']['name'], 'strlen' ) );
			if ( $n > 0 ) { $msg .= ' ' . $n . ' pièce' . ( $n > 1 ? 's' : '' ) . ' jointe' . ( $n > 1 ? 's' : '' ) . '.'; }
			if ( $n < $attendus ) {
				$msg .= ' ' . ( $attendus - $n ) . ' fichier(s) refusé(s) — formats acceptés : PDF, JPG, PNG, WEBP, GIF, 8 Mo maximum. Rattachez-les depuis la fiche.';
			}
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/achats/' . $id
			: ( $corrige > 0 ? 'comptabilite/achats/' . $corrige . '/corriger' : 'comptabilite/achats/nouvelle' ) );
	}

	public function show( $id ) {
		$f = FKC_FactureFournisseur::find( $id );
		if ( ! $f ) { redirect( 'comptabilite/achats' ); }
		$frn = FKC_Fournisseur::find( $f['fournisseur_id'] );
		FKC_View::render( 'comptabilite::achats.show', array(
			'title' => 'Facture ' . $f['numero'], 'tab' => 'achats',
			'f' => $f, 'frn' => $frn, 'ecriture' => $f['ecriture_id'] ? FKC_Ecriture::withLignes( $f['ecriture_id'] ) : null,
			'lignes' => FKC_FactureFournisseur::lignes( $id ),
			'versions' => FKC_FactureFournisseur::versions( $id ),
			'pieces' => class_exists( 'FKC_PieceJointe' ) ? FKC_PieceJointe::forSource( 'facture_fournisseur', $id ) : array(),
			'flash' => $this->flash(),
		) );
	}

	public function imprimer( $id ) {
		$f = FKC_FactureFournisseur::find( $id );
		if ( ! $f ) { redirect( 'comptabilite/achats' ); return; }
		FKC_View::render( 'comptabilite::achats.print', array(
			'f'      => $f,
			'frn'    => FKC_Fournisseur::find( $f['fournisseur_id'] ),
			'charge' => FKC_Compte::byNumero( $f['compte_charge'] ),
			'lignes' => FKC_FactureFournisseur::lignes( $f['id'] ),
		), false );
	}

	/* ── Pièces justificatives (1.738.0) ──────────────────────────────────
	 *
	 * La facture d'achat était le SEUL document comptable à ne pas pouvoir
	 * porter son justificatif, alors qu'elle est la seule dont l'original ne
	 * sort pas du logiciel : on le reçoit par courrier ou par e-mail, et c'est
	 * lui que réclamera un contrôle. Le mécanisme existait déjà pour les
	 * écritures, le brouillard, les factures de vente et les immobilisations —
	 * il n'y était simplement pas branché.
	 * ─────────────────────────────────────────────────────────────────── */

	public function pieceUpload( $id ) {
		$f = FKC_FactureFournisseur::find( $id );
		if ( ! $f ) { redirect( 'comptabilite/achats' ); }
		list( $ok, $msg ) = FKC_PieceJointe::add( 'facture_fournisseur', (int) $id, $_FILES['piece'] ?? array() );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/' . (int) $id );
	}
	public function pieceDownload( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		// Le type de source est vérifié : sans cela, cette route servirait de
		// porte dérobée pour lire n'importe quelle pièce de la société.
		if ( ! $pj || 'facture_fournisseur' !== $pj['source_type'] ) { http_response_code( 404 ); echo 'Pièce introuvable.'; return; }
		FKC_PieceJointe::stream( $pj );
	}
	public function pieceDelete( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj || 'facture_fournisseur' !== $pj['source_type'] ) { redirect( 'comptabilite/achats' ); }
		$fid = (int) $pj['source_id'];
		list( $ok, $msg ) = FKC_PieceJointe::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/' . $fid );
	}

	/** Supprime définitivement une facture ANNULÉE (le modèle refuse les autres). */
	public function supprimer( $id ) {
		list( $ok, $msg ) = FKC_FactureFournisseur::supprimer( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/achats' : 'comptabilite/achats/' . (int) $id );
	}

	public function annuler( $id ) {
		list( $ok, $msg ) = FKC_FactureFournisseur::annuler( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/' . $id );
	}

	/** Import FNE : récupération des factures fournisseurs reçues dans le compte FNE. */
	public function importFne() {
		$configured = class_exists( 'FKC_Fne' ) && FKC_Fne::isConfigured();
		FKC_View::render( 'comptabilite::achats.import_fne', array(
			'title' => 'Factures fournisseurs · Import FNE', 'tab' => 'achats',
			'fournisseurs' => FKC_Fournisseur::all(), 'taux' => FKC_FactureFournisseur::tauxTva(),
			'configured' => $configured, 'flash' => $this->flash(),
		) );
	}
	public function importFneStore() {
		$ref = trim( (string) ( $_POST['reference'] ?? '' ) );
		if ( '' === $ref ) { $this->setFlash( 'La référence FNE de la facture reçue est requise.', 'err' ); redirect( 'comptabilite/achats/import-fne' ); }
		$d = array(
			'reference'      => $ref,
			'fournisseur_id' => (int) ( $_POST['fournisseur_id'] ?? 0 ),
			'fournisseur_nom' => trim( (string) ( $_POST['fournisseur_nom'] ?? '' ) ),
			'date_facture'   => $_POST['date_facture'] ?? date( 'Y-m-d' ),
			'compte_charge'  => $_POST['compte_charge'] ?? '',
			'montant_ht'     => (float) ( $_POST['montant_ht'] ?? 0 ),
			'taux_tva'       => (float) ( $_POST['taux_tva'] ?? 18 ),
		);
		list( $ok, $msg, $id ) = FKC_FactureFournisseur::create( $d );
		$this->setFlash( $ok ? 'Facture FNE importée (réf. ' . $ref . ').' : $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/achats/' . $id : 'comptabilite/achats/import-fne' );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_ach'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_ach'] ?? null; unset( $_SESSION['__flash_ach'] ); return $m; }
}
