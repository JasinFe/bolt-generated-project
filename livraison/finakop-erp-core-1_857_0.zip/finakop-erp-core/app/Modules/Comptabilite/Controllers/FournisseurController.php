<?php
/** Comptabilité Fournisseur : fournisseurs + paiements. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_FournisseurController {

	/**
	 * LA LISTE EST PAR FACTURE, PAS PAR FOURNISSEUR (1.737.0).
	 *
	 * L'écran n'affichait qu'un solde global par fournisseur : impossible de
	 * savoir QUELLE facture payer. Le règlement portait donc sur un tiers, et
	 * la dette se reconstituait ensuite par un lettrage au plus ancien — faux
	 * dès qu'on choisit ce qu'on règle, ce qui est le cas à l'achat (une
	 * livraison contestée, un escompte qui court sur une autre facture).
	 *
	 * C'est le symétrique exact du correctif porté au client en 1.731.0, et il
	 * s'appuie sur le même moteur : aucun second calcul de poste.
	 */
	public function index() {
		$vue = ( 'fournisseurs' === ( $_GET['vue'] ?? '' ) ) ? 'fournisseurs' : 'factures';
		$rows = array(); $totalDu = 0.0; $postes = array(); $credits = 0.0;
		foreach ( FKC_Fournisseur::all() as $f ) {
			$p = FKC_Imputation::postesFournisseur( (int) $f['id'] );
			$f['total_facture'] = $p['facture'];
			$f['total_paye']    = $p['paye'];
			$f['solde']         = $p['du'];
			$f['nb_ouvertes']   = $p['nb_ouvertes'];
			$totalDu += $p['du'];
			$credits += $p['credit'];
			$rows[] = $f;
			foreach ( $p['ouvertes'] as $o ) {
				$o['fournisseur_id']  = (int) $f['id'];
				$o['fournisseur_nom'] = (string) $f['nom'];
				$postes[] = $o;
			}
		}
		// La plus ancienne d'abord : c'est l'ordre dans lequel on paie.
		usort( $postes, function ( $a, $b ) { return $b['jours'] <=> $a['jours']; } );
		FKC_View::render( 'comptabilite::fournisseurs.index', array(
			'title' => 'Comptabilité · Fournisseurs', 'tab' => 'fournisseurs',
			'fournisseurs' => $rows, 'postes' => $postes, 'vue' => $vue,
			'totalDu' => $totalDu, 'nbOuvertes' => count( $postes ), 'credits' => $credits,
			'flash' => $this->flash(),
		) );
	}
	public function dettes() {
		$rows = array(); $total = 0; $nb = 0;
		foreach ( FKC_Fournisseur::all() as $f ) {
			// Même source que l'écran principal : deux totaux différents pour
			// la même dette seraient pires que pas de total du tout.
			$p = FKC_Imputation::postesFournisseur( (int) $f['id'] );
			if ( $p['du'] > 0.5 ) {
				$f['total_facture'] = $p['facture'];
				$f['total_paye']    = $p['paye'];
				$f['solde']         = $p['du'];
				$rows[] = $f; $total += $p['du']; $nb++;
			}
		}
		usort( $rows, function ( $a, $b ) { return $b['solde'] <=> $a['solde']; } );
		FKC_View::render( 'comptabilite::fournisseurs.dettes', array(
			'title' => 'Comptabilité · Total dettes fournisseurs', 'tab' => 'fournisseurs',
			'fournisseurs' => $rows, 'total' => $total, 'nb' => $nb, 'flash' => $this->flash(),
		) );
	}
	public function create() {
		FKC_View::render( 'comptabilite::fournisseurs.form', array( 'title' => 'Nouveau fournisseur', 'tab' => 'fournisseurs', 'frn' => null, 'errors' => array() ) );
	}
	public function store() {
		$d = $this->input(); if ( '' === $d['nom'] ) { return FKC_View::render( 'comptabilite::fournisseurs.form', array( 'title' => 'Nouveau fournisseur', 'tab' => 'fournisseurs', 'frn' => null, 'errors' => array( 'Le nom est requis.' ) ) ); }
		FKC_Fournisseur::create( $d ); $this->setFlash( 'Fournisseur créé.' ); redirect( 'comptabilite/fournisseurs' );
	}
	public function edit( $id ) {
		$f = FKC_Fournisseur::find( $id ); if ( ! $f ) { redirect( 'comptabilite/fournisseurs' ); }
		FKC_View::render( 'comptabilite::fournisseurs.form', array( 'title' => 'Modifier', 'tab' => 'fournisseurs', 'frn' => $f, 'errors' => array() ) );
	}
	public function update( $id ) {
		$f = FKC_Fournisseur::find( $id ); if ( ! $f ) { redirect( 'comptabilite/fournisseurs' ); }
		$d = $this->input(); if ( '' === $d['nom'] ) { return FKC_View::render( 'comptabilite::fournisseurs.form', array( 'title' => 'Modifier', 'tab' => 'fournisseurs', 'frn' => $f, 'errors' => array( 'Le nom est requis.' ) ) ); }
		FKC_Fournisseur::update( $id, $d ); $this->setFlash( 'Fournisseur mis à jour.' ); redirect( 'comptabilite/fournisseurs' );
	}
	/** Lit un montant saisi : « 1 250,50 », « 1250.50 », espace insécable compris. */
	protected static function montantSaisi( $v ) {
		$v = str_replace( array( ' ', "\xc2\xa0", "\xe2\x80\xaf", "'" ), '', (string) $v );
		return round( (float) str_replace( ',', '.', $v ), 2 );
	}

	public function payerForm( $id ) {
		$f = FKC_Fournisseur::find( $id ); if ( ! $f ) { redirect( 'comptabilite/fournisseurs' ); }
		$poste   = FKC_Imputation::postesFournisseur( (int) $id );
		$cible   = (int) ( $_GET['facture'] ?? 0 );
		$montant = $poste['du'];
		if ( $cible ) {
			$montant = 0.0;
			foreach ( $poste['ouvertes'] as $p ) {
				if ( (int) $p['id'] === $cible ) { $montant = (float) $p['reste']; break; }
			}
			if ( $montant <= 0 ) { $cible = 0; $montant = $poste['du']; }
		}
		FKC_View::render( 'comptabilite::fournisseurs.payer', array(
			'title' => 'Paiement · ' . $f['nom'], 'tab' => 'fournisseurs',
			'frn' => $f, 'comptes' => FKC_Tresorerie::comptes( true ), 'modes' => FKC_Reglement::modes(),
			'totalPaye' => $poste['paye'], 'poste' => $poste, 'cible' => $cible, 'montant' => $montant,
			'imputable' => FKC_Imputation::disponible(),
			'reglements' => FKC_Reglement::duTiers( 'fournisseur', (int) $id ),
			'flash' => $this->flash(),
		) );
	}
	public function payer( $id ) {
		$f = FKC_Fournisseur::find( $id ); if ( ! $f ) { redirect( 'comptabilite/fournisseurs' ); }

		/*
		 * Deux gestes, tous deux légitimes : « je règle ces trois factures »,
		 * où la somme des lignes fait le montant ; et « je verse 200 000 F au
		 * compte du fournisseur », où rien n'est coché et le lettrage au plus
		 * ancien s'applique comme avant. On n'en impose aucun.
		 */
		$imputations = array(); $somme = 0.0;
		foreach ( (array) ( $_POST['imput'] ?? array() ) as $fid => $m ) {
			$fid = (int) $fid; $m = self::montantSaisi( $m );
			if ( $fid <= 0 || $m <= 0 ) { continue; }
			$imputations[ $fid ] = $m; $somme += $m;
		}
		$brut    = trim( (string) ( $_POST['montant'] ?? '' ) );
		$montant = ( '' === $brut ) ? $somme : self::montantSaisi( $brut );
		if ( $somme > 0 && $montant <= 0 ) { $montant = $somme; }

		list( $ok, $msg, $rid ) = FKC_Reglement::create( array(
			'sens' => 'paiement', 'tiers_type' => 'fournisseur', 'tiers_id' => (int) $id,
			'tresorerie_id' => (int) ( $_POST['tresorerie_id'] ?? 0 ),
			'date_reglement' => $_POST['date_reglement'] ?? date( 'Y-m-d' ),
			'montant' => $montant, 'mode' => $_POST['mode'] ?? null,
			'reference' => $_POST['reference'] ?? null, 'libelle' => 'Paiement ' . $f['nom'],
			'imputations' => $imputations,
		) );
		/*
		 * PIÈCE JUSTIFICATIVE DU RÈGLEMENT (1.752.0).
		 *
		 * L'écran permettait de saisir un paiement Mobile Money sans pouvoir
		 * joindre le reçu — la seule preuve qu'il existe. Le justificatif
		 * finissait dans un dossier à part, ou nulle part, et le règlement
		 * restait invérifiable au rapprochement comme au contrôle.
		 *
		 * La pièce est rattachée APRÈS le règlement et n'en conditionne pas
		 * la réussite : un échec de téléversement (fichier trop lourd, type
		 * refusé) ne doit pas annuler un paiement déjà comptabilisé. On le
		 * dit, on ne le cache pas.
		 */
		if ( $ok && ! empty( $rid ) && class_exists( 'FKC_GedDocument' )
			&& ! empty( $_FILES['piece'] ) && UPLOAD_ERR_NO_FILE !== ( $_FILES['piece']['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			list( $pok, $pmsg ) = FKC_GedDocument::add( array(
				'titre'      => trim( (string) ( $_POST['piece_titre'] ?? '' ) )
					?: 'Justificatif règlement ' . $f['nom'] . ' — ' . ( $_POST['date_reglement'] ?? date( 'Y-m-d' ) ),
				'categorie'  => 'Justificatifs de règlement',
				'lien_type'  => 'reglement',
				'lien_id'    => (int) $rid,
				'lien_label' => $f['nom'] . ' — ' . fkc_money( $montant ) . ' F',
				'note'       => trim( (string) ( $_POST['reference'] ?? '' ) ) ?: null,
			), $_FILES['piece'] );
			$msg .= $pok
				? ' Justificatif joint.'
				: ' ⚠️ Le règlement est enregistré, mais le justificatif n\'a pas pu être joint : ' . $pmsg;
		}
		if ( $ok && $imputations ) {
			$n = count( $imputations );
			$msg .= ' Imputé sur ' . $n . ' facture' . ( $n > 1 ? 's' : '' ) . '.';
			if ( $montant - $somme > 0.5 ) {
				$msg .= ' Reliquat de ' . fkc_money( $montant - $somme ) . ' F porté au compte du fournisseur.';
			}
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/fournisseurs' : 'comptabilite/fournisseurs/' . $id . '/payer' );
	}
	protected function input() {
		return array(
			'nom' => trim( (string) ( $_POST['nom'] ?? '' ) ), 'ncc' => trim( (string) ( $_POST['ncc'] ?? '' ) ),
			'telephone' => trim( (string) ( $_POST['telephone'] ?? '' ) ), 'email' => trim( (string) ( $_POST['email'] ?? '' ) ),
			'adresse' => trim( (string) ( $_POST['adresse'] ?? '' ) ), 'compte' => trim( (string) ( $_POST['compte'] ?? '401' ) ) ?: '401',
		);
	}
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_fr'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_fr'] ?? null; unset( $_SESSION['__flash_fr'] ); return $m; }
}
