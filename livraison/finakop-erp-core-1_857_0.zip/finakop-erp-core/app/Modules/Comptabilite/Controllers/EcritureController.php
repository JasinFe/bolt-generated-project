<?php
/** Écritures comptables. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EcritureController {

	public function index() {
		$annee = isset( $_GET['annee'] ) && preg_match( '/^\\d+$/', (string) $_GET['annee'] ) ? (string) $_GET['annee'] : null;
		$ecritures = FKC_Ecriture::listWithTotals( 200, $annee );
		FKC_View::render( 'comptabilite::ecritures.index', array(
			'title'     => 'Comptabilité · Écritures',
			'tab'       => 'ecritures',
			'ecritures' => $ecritures,
			'pieces'    => FKC_PieceJointe::countMap( 'ecriture', array_column( $ecritures, 'id' ) ),
			'annee'     => $annee,
			'annees'    => FKC_Ecriture::exercices(),
			'flash'     => $this->flash(),
		) );
	}

	/**
	 * Plafond réel d'un envoi de fichiers, en octets (1.769.0).
	 *
	 * Le formulaire annonçait « PDF ou images » sans dire jusqu'à quel poids.
	 * Le plus petit des trois plafonds commande : celui du produit (8 Mo),
	 * celui d'un fichier (upload_max_filesize) et celui de la requête entière
	 * (post_max_size) — c'est ce dernier qui, dépassé, fait répondre le
	 * serveur avant PHP, sans message utile.
	 */
	protected function plafondPieces() {
		$octets = function ( $v ) {
			$v = trim( (string) $v );
			if ( '' === $v ) { return 0; }
			$u = strtolower( substr( $v, -1 ) );
			$n = (float) $v;
			if ( 'g' === $u ) { return (int) ( $n * 1024 * 1024 * 1024 ); }
			if ( 'm' === $u ) { return (int) ( $n * 1024 * 1024 ); }
			if ( 'k' === $u ) { return (int) ( $n * 1024 ); }
			return (int) $n;
		};
		$candidats = array( (int) FKC_PieceJointe::MAX );
		foreach ( array( 'upload_max_filesize', 'post_max_size' ) as $cle ) {
			$v = $octets( ini_get( $cle ) );
			if ( $v > 0 ) { $candidats[] = $v; }
		}
		return min( $candidats );
	}

	public function create() {
		// Exercice de travail : si un exercice passé est consulté, la date par défaut le suit.
		$annee = isset( $_GET['annee'] ) && preg_match( '/^\\d+$/', (string) $_GET['annee'] ) ? (string) $_GET['annee'] : '';
		$defaultDate = date( 'Y-m-d' );
		$pastExercice = false;
		if ( $annee && $annee !== date( 'Y' ) ) {
			$cand = $annee . '-' . date( 'm-d' );
			$defaultDate = strtotime( $cand ) ? $cand : $annee . '-12-31';
			$pastExercice = true;
		}
		FKC_View::render( 'comptabilite::ecritures.form', array(
			'title'    => 'Saisir une écriture', 'tab' => 'ecritures',
			'journaux' => FKC_Journal::all(), 'comptes' => FKC_Compte::all(), 'errors' => array(),
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(), 'brouillardOn' => FKC_Brouillard::enabled(),
			'plafondPieces' => $this->plafondPieces(),
			'defaultDate' => $defaultDate, 'pastExercice' => $pastExercice, 'exercice' => $annee,
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	public function store() {
		$entete = array(
			'journal_id'    => (int) ( $_POST['journal_id'] ?? 0 ),
			'date_ecriture' => trim( (string) ( $_POST['date_ecriture'] ?? '' ) ),
			'piece'         => trim( (string) ( $_POST['piece'] ?? '' ) ),
			'libelle'       => trim( (string) ( $_POST['libelle'] ?? '' ) ),
			'reference'     => trim( (string) ( $_POST['reference'] ?? '' ) ),
			'created_by'    => FKC_Auth::id(),
		);
		$comptes = $_POST['compte_id'] ?? array();
		$libs    = $_POST['ligne_libelle'] ?? array();
		$debits  = $_POST['debit'] ?? array();
		$credits = $_POST['credit'] ?? array();
		$divs    = $_POST['division_id'] ?? array();
		$axes    = $_POST['axe_id'] ?? array();
		$vals    = $_POST['valeur_id'] ?? array();
		$lignes  = array();
		foreach ( (array) $comptes as $i => $cid ) {
			$lignes[] = array(
				'compte_id'   => $cid,
				'libelle'     => $libs[ $i ] ?? '',
				'debit'       => $this->num( $debits[ $i ] ?? 0 ),
				'credit'      => $this->num( $credits[ $i ] ?? 0 ),
				'division_id' => isset( $divs[ $i ] ) && $divs[ $i ] !== '' ? (int) $divs[ $i ] : null,
				'axe_id'      => isset( $axes[ $i ] ) && $axes[ $i ] !== '' ? (int) $axes[ $i ] : null,
				'valeur_id'   => isset( $vals[ $i ] ) && $vals[ $i ] !== '' ? (int) $vals[ $i ] : null,
			);
		}

		$errs = array();
		if ( ! $entete['journal_id'] ) { $errs[] = 'Sélectionnez un journal.'; }
		if ( ! $entete['date_ecriture'] ) { $errs[] = 'La date est requise.'; }
		if ( '' === $entete['libelle'] ) { $errs[] = 'Le libellé est requis.'; }
		if ( ! $errs ) {
			$brouillard = isset( $_POST['brouillard'] ) ? true : null;
			list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, array( 'source' => 'manuelle', 'brouillard' => $brouillard ) );
			if ( $ok ) {
				/*
				 * LE CHAMP DE FICHIERS S'APPELLE `pieces[]` (1.769.0).
				 *
				 * Il s'appelait `piece[]`, du nom EXACT du champ texte voisin
				 * « N° de pièce ». PHP sépare $_POST et $_FILES, donc le
				 * produit fonctionnait — mais le corps multipart envoyé au
				 * serveur portait deux fois le même nom, une fois en scalaire
				 * et une fois en tableau. C'est précisément ce que la
				 * validation stricte du multipart de ModSecurity refuse, et
				 * l'hébergeur répond alors 403 sans que la requête atteigne
				 * PHP : l'écran de saisie disparaît, l'écriture est perdue,
				 * et rien n'explique pourquoi.
				 *
				 * L'ancien nom reste lu : un formulaire en cache ou un script
				 * tiers ne doit pas cesser de fonctionner du jour au lendemain.
				 */
				$fichiers = ( ! empty( $_FILES['pieces']['name'] ) ) ? $_FILES['pieces'] : ( $_FILES['piece'] ?? array() );
				if ( ! empty( $eid ) && ! empty( $fichiers['name'] ) ) {
					$np = FKC_PieceJointe::addMany( 'ecriture', $eid, $fichiers );
					if ( $np ) { $msg .= ' ' . $np . ' pièce(s) jointe(s).'; }
				} elseif ( ! empty( $bid ) && ! empty( $fichiers['name'] ) ) {
					$np = FKC_PieceJointe::addMany( 'brouillon', $bid, $fichiers );
					if ( $np ) { $msg .= ' ' . $np . ' pièce(s) jointe(s) au brouillon (reportées à la validation).'; }
				}
				/*
				 * On redirige d'après CE QUI S'EST PASSÉ, pas d'après ce
				 * qu'on avait prévu. L'ancienne condition rejouait le
				 * raisonnement de FKC_Ecriture::enregistrer() — donc le
				 * dupliquait, donc pouvait en diverger : depuis que la
				 * politique se décide par origine, `FKC_Brouillard::enabled()`
				 * ne suffit plus à dire où l'écriture est partie. Le
				 * résultat, lui, ne se trompe pas.
				 */
				$this->setFlash( $msg ); redirect( ! empty( $bid ) ? 'comptabilite/brouillard' : 'comptabilite/ecritures' );
			}
			$errs[] = $msg;
		}
		FKC_View::render( 'comptabilite::ecritures.form', array(
			'title' => 'Saisir une écriture', 'tab' => 'ecritures',
			'journaux' => FKC_Journal::all(), 'comptes' => FKC_Compte::all(), 'errors' => $errs,
			'divisions' => $this->divisions(), 'showDivision' => $this->analytiqueOn(), 'brouillardOn' => FKC_Brouillard::enabled(),
			'plafondPieces' => $this->plafondPieces(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	/** Divisions actives (vide si la table n'existe pas encore). */
	protected function divisions() {
		if ( ! class_exists( 'FKC_Division' ) ) { return array(); }
		try { return FKC_Division::all( true ); } catch ( Exception $e ) { return array(); }
	}

	/** Axes analytiques actifs (multi-axes). */
	protected function axes() {
		if ( ! class_exists( 'FKC_Axe' ) ) { return array(); }
		try { return FKC_Axe::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	/** Carte axe_id => [ {id,t} ] des valeurs actives, pour les listes dépendantes. */
	protected function valeursMap() {
		$map = array();
		if ( ! class_exists( 'FKC_Valeur' ) ) { return $map; }
		foreach ( $this->axes() as $a ) {
			$opts = array();
			try { foreach ( FKC_Valeur::byAxe( (int) $a['id'], true ) as $v ) { $opts[] = array( 'id' => (int) $v['id'], 't' => $v['code'] . ' · ' . $v['libelle'] ); } } catch ( \Throwable $e ) {}
			$map[ (int) $a['id'] ] = $opts;
		}
		return $map;
	}
	/** Imputation multi-axes disponible : analytique actif ET au moins un axe défini. */
	protected function showAxes() {
		return $this->analytiqueOn() && count( $this->axes() ) > 0;
	}

	/** L'analytique est-il disponible dans l'édition de la société ? */
	protected function analytiqueOn() {
		$lic = FKC_License::resolve();
		return in_array( 'analytique', $lic['modules'] ?? array(), true );
	}

	public function show( $id ) {
		$e = FKC_Ecriture::withLignes( $id );
		if ( ! $e ) { redirect( 'comptabilite/ecritures' ); }
		$titre = ! empty( $e['numero'] )
			? 'Écriture ' . $e['journal_code'] . '-' . $e['numero']
			: 'Écriture n°' . (int) $id;
		FKC_View::render( 'comptabilite::ecritures.show', array(
			'title' => $titre, 'tab' => 'ecritures', 'ecriture' => $e,
			'pieces' => FKC_PieceJointe::forSource( 'ecriture', $id ),
			// Annulation accessible depuis la fiche de l'écriture. Elle n'existait
			// que dans Paramètres → Maintenance : pour annuler une écriture, il
			// fallait quitter la comptabilité, retrouver l'écran d'administration
			// puis rechercher l'écriture qu'on avait justement sous les yeux.
			'analyse' => FKC_EcritureAnnulation::analyser( (int) $id ),
			'flash'   => $this->flash(),
		) );
	}

	/**
	 * « Pourquoi cette écriture existe-t-elle ? »
	 *
	 * L'écran qui manquait : depuis le grand livre, remonter la chaîne
	 * jusqu'au fait économique, à la pièce, à l'utilisateur et au référentiel
	 * en vigueur. Il ne devine rien — quand un maillon manque, il le dit.
	 */
	public function trace( $id ) {
		$t = FKC_Trace::pour( (int) $id );
		if ( ! $t ) { redirect( 'comptabilite/ecritures' ); }
		$e = $t['ecriture'];
		FKC_View::render( 'comptabilite::ecritures.trace', array(
			'title' => 'Provenance de l\'écriture',
			'tab'   => 'ecritures',
			'trace' => $t,
			'ecriture' => $e,
		) );
	}

	/**
	 * Contre-passe l'écriture consultée.
	 *
	 * La contre-passation reprend le NUMÉRO de l'écriture annulée : ce n'est pas
	 * une opération nouvelle, c'est l'annulation de celle-là.
	 */
	public function contrepasser( $id ) {
		list( $ok, $msg ) = FKC_EcritureAnnulation::contrepasser( (int) $id, $_POST['date'] ?? null );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/ecritures/' . (int) $id );
	}

	/** Revient sur une contre-passation passée par erreur. */
	public function annulerContrepassation( $id ) {
		list( $ok, $msg, $origine ) = FKC_EcritureAnnulation::annulerContrepassation( (int) $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok && $origine ? 'comptabilite/ecritures/' . (int) $origine : 'comptabilite/ecritures' );
	}

	/** Supprime définitivement une écriture (refusé dès qu'elle est référencée). */
	public function supprimerEcriture( $id ) {
		list( $ok, $msg ) = FKC_EcritureAnnulation::supprimer( (int) $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/ecritures' : 'comptabilite/ecritures/' . (int) $id );
	}


	/** Ajoute une pièce justificative à une écriture. */
	public function pieceUpload( $id ) {
		$e = FKC_Ecriture::withLignes( $id );
		if ( ! $e ) { redirect( 'comptabilite/ecritures' ); }
		list( $ok, $msg ) = FKC_PieceJointe::add( 'ecriture', $id, $_FILES['piece'] ?? array() );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/ecritures/' . (int) $id );
	}

	/** Diffuse une pièce jointe (lecture serveur ; dossier protégé). */
	public function pieceDownload( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj ) { http_response_code( 404 ); echo 'Pièce introuvable.'; return; }
		FKC_PieceJointe::stream( $pj );
	}

	/** Supprime une pièce jointe. */
	public function pieceDelete( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj ) { redirect( 'comptabilite/ecritures' ); }
		$ecr = (int) $pj['source_id'];
		list( $ok, $msg ) = FKC_PieceJointe::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/ecritures/' . $ecr );
	}

	/** Page d'import : modèle à télécharger + dépôt du fichier. */
	public function importIndex() {
		FKC_View::render( 'comptabilite::ecritures.import', array(
			'title' => 'Comptabilité · Importer des écritures', 'tab' => 'ecritures',
			'colonnes' => FKC_EcritureImport::colonnes(), 'modele' => FKC_EcritureImport::modele(),
			'brouillardOn' => FKC_Brouillard::enabled(), 'resultat' => null, 'flash' => $this->flash(),
		) );
	}

	/** Téléchargement du modèle CSV (séparateur « ; », UTF-8). */
	public function importModele() {
		fkc_csv( 'modele-import-ecritures.csv', FKC_EcritureImport::modele() );
	}

	/** Traite le fichier déposé : importe les écritures équilibrées, rapporte les rejets. */
	public function importStore() {
		$resultat = null; $errs = array();
		$f = $_FILES['fichier'] ?? null;
		if ( ! $f || ! is_uploaded_file( $f['tmp_name'] ?? '' ) || UPLOAD_ERR_OK !== ( $f['error'] ?? 1 ) ) {
			$errs[] = 'Veuillez sélectionner un fichier CSV à importer.';
		} elseif ( (int) ( $f['size'] ?? 0 ) > 3 * 1024 * 1024 ) {
			$errs[] = 'Fichier trop volumineux (max 3 Mo).';
		} else {
			$raw = file_get_contents( $f['tmp_name'] );
			if ( false === $raw || '' === trim( $raw ) ) {
				$errs[] = 'Le fichier est vide ou illisible.';
			} else {
				$brouillard = isset( $_POST['brouillard'] ) ? true : null;
				$resultat = FKC_EcritureImport::importer( $raw, $brouillard );
			}
		}
		FKC_View::render( 'comptabilite::ecritures.import', array(
			'title' => 'Comptabilité · Importer des écritures', 'tab' => 'ecritures',
			'colonnes' => FKC_EcritureImport::colonnes(), 'modele' => FKC_EcritureImport::modele(),
			'brouillardOn' => FKC_Brouillard::enabled(), 'resultat' => $resultat, 'errors' => $errs, 'flash' => null,
		) );
	}

	protected function num( $v ) { return (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $v ); }
	/**
	 * Message flash, avec un niveau facultatif.
	 *
	 * La signature d'origine ne portait qu'un texte, et les vues affichaient tout
	 * en vert. Un refus d'annulation — période clôturée, écriture référencée —
	 * ressemblait donc à une réussite. Le second paramètre reste optionnel : les
	 * appels existants continuent de fonctionner.
	 */
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_ecr'] = array( 'type' => $t, 'msg' => (string) $m ); }

	/** @return array{type:string,msg:string}|null */
	protected function flash() {
		$f = $_SESSION['__flash_ecr'] ?? null;
		unset( $_SESSION['__flash_ecr'] );
		if ( null === $f ) { return null; }
		// Tolère l'ancienne forme (chaîne nue) laissée en session par une version
		// antérieure : un utilisateur connecté pendant la mise à jour ne doit pas
		// tomber sur une erreur d'affichage.
		return is_array( $f ) ? $f : array( 'type' => 'ok', 'msg' => (string) $f );
	}
}
