<?php
/**
 * Faits économiques — catalogue et couverture.
 *
 * L'écran qui donne sa raison d'être au lot déclaratif : il ne change aucune
 * écriture, il MESURE. Combien d'événements savent ce qu'ils décrivent, et
 * lesquels ne le savent pas encore.
 *
 * Le chiffre partira très bas. C'est l'intérêt : le registre de provenance de
 * 1.541.0 avait révélé 142 événements orphelins sur 264, et personne ne le
 * soupçonnait avant qu'un compteur ne le dise.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_FaitEcoController {

	/** Passe l'OD de reclassement des imputations héritées. */
	public function reclasser() {
		list( $ok, $msg ) = FKC_Reclassement::passer(
			$_POST['date'] ?? date( 'Y-m-d' ),
			array_values( array_filter( (array) ( $_POST['sources'] ?? array() ) ) )
		);
		$_SESSION['__fkc_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( 'comptabilite/faits-economiques' );
	}

	/**
	 * Rattache les écritures à leur pièce d'origine, à la demande.
	 *
	 * Le balayage tourne aussi tout seul par la file différée ; ce bouton
	 * existe pour le premier passage, qui porte tout l'historique du dossier
	 * et qu'un utilisateur veut voir aboutir tout de suite.
	 */
	public function rattacherOrigines() {
		$r = FKC_Origine::balayer( 2000 );
		$msg = sprintf(
			'%d écriture(s) examinée(s), %d rattachée(s) à leur pièce, %d maillon(s) de chaîne documentaire posé(s).',
			$r['examinees'], $r['rattachees'], $r['maillons']
		);
		if ( $r['orphelines'] ) {
			$msg .= ' ' . $r['orphelines'] . ' écriture(s) qu\'aucune pièce ne revendique — elles restent sans origine, et c\'est ce que dit le contrôle.';
		}
		if ( ! $r['examinees'] ) { $msg = 'Toutes les écritures portent déjà leur pièce d\'origine.'; }
		$_SESSION['__fkc_flash'] = array( 'type' => 'ok', 'msg' => $msg );
		redirect( 'comptabilite/faits-economiques' );
	}

	public function index() {
		$couv = FKC_FaitEco::couverture();

		/*
		 * Les incohérences ne concernent QUE les schémas qui déclarent déjà
		 * leur fait : sur les autres, il n'y a rien à confronter. C'est
		 * volontairement peu bavard — un écran qui signale deux cents
		 * problèmes le premier jour ne se lit pas.
		 */
		$incoherences = array();
		foreach ( FKC_Posting::all() as $evt => $schema ) {
			$obs = FKC_FaitEco::incoherences( $evt, $schema );
			if ( $obs ) { $incoherences[ $evt ] = $obs; }
		}

		FKC_View::render( 'comptabilite::faits.index', array(
			'title'        => 'Comptabilité · Faits économiques',
			'tab'          => 'faits',
			'catalogue'    => FKC_FaitEco::parFamille(),
			'couverture'   => $couv,
			'incoherences' => $incoherences,
			'roles'        => FKC_Resolveur::roles(),
			'diagnostic'   => FKC_Resolveur::diagnostic(),
			'detenues'     => FKC_SommeDetenue::synthese(),
			'provisions'   => FKC_Provision::ouvertes(),
			'ecarts'       => FKC_Provision::ecartsEstimation( 20 ),
			'reclassement' => FKC_Reclassement::analyse(),
			'divergences'  => FKC_Divergence::balayage(),
			'dimensions'   => FKC_Divergence::dimensions(),
			'origines'     => FKC_Origine::couverture(),
			'sansPiece'    => FKC_Origine::sansPiece( 15 ),
			'chaine'       => FKC_ChaineDoc::couverture(),
			'nonFacturees' => FKC_ChaineDoc::livraisonsNonFacturees( 7, 15 ),
			'nonLettres'   => FKC_ChaineDoc::reglementsNonLettres( 30, 15 ),
			// 1.624.0 : prestations portées sur une note d'hôtel soldée sans
			// jamais avoir été comptabilisées — perte silencieuse de produit.
			'perdues'      => class_exists( 'FKC_HotelFolio' ) ? FKC_HotelFolio::prestationsPerdues( 15 ) : array(),
			// 1.625.0 : encaissements dont l'opérateur mobile n'a jamais été
			// saisi — information, pas alerte (voir sansOperateur()).
			'sansOp'       => FKC_Reglement::sansOperateur( 45 ),
			// 1.626.0 : tickets réglés de plusieurs façons — limite connue du
			// moteur d'écritures, pas une faute de saisie.
			'mixtes'       => class_exists( 'FKC_Pos' ) ? FKC_Pos::ticketsMixtes( 10 ) : array(),
			// 1.627.0 : le réalisé budgétaire vient enfin des réceptions, ce
			// qui rend ces deux contrôles mesurables.
			'depassements' => FKC_BudgetConso::depassements( 12 ),
			'budgetOrph'   => FKC_BudgetConso::rattachementsOrphelins( 10 ),
			// 1.628.0 : missions livrées dont personne n'a réclamé le solde.
			'missionsNF'   => class_exists( 'FKC_Mission' ) ? FKC_Mission::missionsNonFacturees( null, 12 ) : array(),
			// 1.633.0 : opérations dont la contrepartie comptable a été refusée.
			'refus'        => FKC_Posting::refusRecents( 90, 12 ),
		) );
	}
}
