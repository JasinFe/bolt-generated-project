<?php
/** Brouillard : vérification/modification des écritures avant comptabilisation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_BrouillardController {

	public function index() {
		$brouillons = FKC_Brouillard::all();
		FKC_View::render( 'comptabilite::brouillard.index', array(
			'title'      => 'Comptabilité · Brouillard',
			'tab'        => 'brouillard',
			'brouillons' => $brouillons,
			'pieces'     => FKC_PieceJointe::countMap( 'brouillon', array_column( $brouillons, 'id' ) ),
			'actif'      => FKC_Brouillard::enabled(),
			// Journal temporaire : ce qui attend, par origine, et ce qui se
			// publiera automatiquement contre ce qui réclame une signature.
			'synthese'   => class_exists( 'FKC_PolitiqueCompta' ) ? FKC_PolitiqueCompta::synthese() : array(),
			'declencheurs' => class_exists( 'FKC_PolitiqueCompta' ) ? FKC_PolitiqueCompta::declencheurs() : array(),
			'lots'       => $this->lotsEnAttente(),
			'politiques' => $this->politiques(),
			// Temporisation : ce qui partira tout seul, et dans combien de temps.
			'echeances'  => class_exists( 'FKC_PolitiqueCompta' ) ? FKC_PolitiqueCompta::echeances() : array(),
			'delaiDefaut' => class_exists( 'FKC_PolitiqueCompta' ) ? FKC_PolitiqueCompta::DELAI_DEFAUT : 6,
			'engorgement' => $this->engorgement(),
			// Le tableau n'affiche que les premières : on dit combien il y en
			// a vraiment, sinon « 300 » se lit comme un total.
			'total'      => FKC_Brouillard::compter(),
			// État du planificateur : une temporisation réglée mais jamais
			// déclenchée serait une promesse en l'air (voir FKC_Balayeur).
			'planif'     => $this->planification(),
			'flash'      => $this->flash(),
		) );
	}

	/**
	 * Écritures qui attendent depuis trop longtemps.
	 *
	 * LE RISQUE DE L'EXCÈS DE PRUDENCE
	 *
	 * Depuis que rien ne se comptabilise tout seul, le danger n'est plus la
	 * publication hâtive : c'est le journal temporaire que personne n'ouvre.
	 * Une comptabilité qui s'arrête ne prévient pas — elle a l'air normale,
	 * simplement les états ne bougent plus. On compte donc ce qui dort, et on
	 * le dit AVANT que le mois se termine dessus.
	 *
	 * @return array{nb:int, plus_ancien:int} jours d'attente du plus ancien.
	 */
	protected function engorgement() {
		/*
		 * Compté en base, sur la TOTALITÉ (1.543.0).
		 *
		 * Cette alerte se calculait sur les écritures déjà chargées pour
		 * l'affichage — les 300 plus récentes. Elle pouvait donc annoncer
		 * « rien d'ancien » alors que les plus vieilles étaient précisément
		 * celles qu'elle n'avait pas sous la main : une alerte d'engorgement
		 * aveugle à l'engorgement.
		 */
		if ( ! class_exists( 'FKC_Brouillard' ) || ! method_exists( 'FKC_Brouillard', 'anciennete' ) ) {
			return array( 'nb' => 0, 'plus_ancien' => 0, 'seuil' => 7 );
		}
		return FKC_Brouillard::anciennete( 7 );
	}

	/**
	 * État du balayage planifié de la temporisation.
	 *
	 * On ne se contente pas de dire « c'est programmé » : `DISABLE_WP_CRON`
	 * est courant en hébergement sérieux, où l'on coupe le pseudo-cron de
	 * WordPress pour le remplacer par un vrai cron système. Le dire est
	 * indispensable — sinon l'écran promettrait une publication automatique
	 * qui n'aurait jamais lieu, ce qui est pire que de ne rien promettre.
	 *
	 * @return array{planifie:bool, prochain:int|null, cron_coupe:bool}
	 */
	protected function planification() {
		if ( ! class_exists( 'FKC_Balayeur' ) ) {
			return array( 'planifie' => false, 'prochain' => null, 'cron_coupe' => false );
		}
		$prochain = FKC_Balayeur::prochainPassage();
		return array(
			'planifie'   => (bool) $prochain,
			'prochain'   => $prochain,
			'cron_coupe' => FKC_Balayeur::cronDesactive(),
		);
	}

	/**
	 * Retient ou relâche une écriture : la temporisation ne la publiera pas.
	 */
	public function retenir( $id ) {
		$on    = ! empty( $_POST['retenir'] );
		$motif = trim( (string) ( $_POST['motif'] ?? '' ) );
		list( $ok, $msg ) = FKC_Brouillard::retenir( (int) $id, $on, $motif );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/brouillard' );
	}

	/**
	 * Passe la temporisation à la main, sans attendre le balayage.
	 *
	 * Le balayage automatique n'a lieu qu'à l'occasion d'une requête, au plus
	 * une fois par quart d'heure : un comptable qui veut solder tout de suite
	 * ce dont le délai est écoulé doit pouvoir le demander plutôt que
	 * recharger sa page en espérant.
	 */
	public function publierEchues() {
		$res = FKC_PolitiqueCompta::publierEchues();
		$msg = $res['publiees'] . ' écriture(s) échue(s) publiée(s).';
		if ( $res['retenues'] ) { $msg .= ' ' . $res['retenues'] . ' retenue(s), volontairement laissée(s) de côté.'; }
		if ( $res['refusees'] ) {
			$msg .= ' ' . $res['refusees'] . ' refusée(s) : ' . implode( ' · ', array_slice( $res['messages'], 0, 3 ) );
		}
		$this->setFlash( $msg, $res['refusees'] ? 'err' : 'ok' );
		redirect( 'comptabilite/brouillard' );
	}

	/** Nombre d'écritures en attente pour chaque déclencheur de lot. */
	protected function lotsEnAttente() {
		if ( ! class_exists( 'FKC_PolitiqueCompta' ) ) { return array(); }
		$out = array();
		foreach ( FKC_PolitiqueCompta::declencheurs() as $code => $lib ) {
			$out[ $code ] = count( FKC_PolitiqueCompta::enAttente( $code ) );
		}
		return $out;
	}

	/** Politique en vigueur pour chaque origine connue. */
	protected function politiques() {
		if ( ! class_exists( 'FKC_PolitiqueCompta' ) ) { return array(); }
		$out = array();
		foreach ( FKC_PolitiqueCompta::origines() as $src ) {
			$out[ $src ] = FKC_PolitiqueCompta::pour( $src );
		}
		return $out;
	}

	/**
	 * Enregistre la politique d'une origine.
	 *
	 * Une politique n'est pas un réglage anodin : elle décide du moment où une
	 * écriture devient opposable. Le changement est donc journalisé par
	 * FKC_PolitiqueCompta::definir(), qui appelle l'audit de sécurité.
	 */
	public function politiqueSave() {
		$src  = preg_replace( '/[^a-z0-9_]/', '', (string) ( $_POST['source'] ?? '' ) );
		$mode = (string) ( $_POST['mode'] ?? '' );
		$decl = preg_replace( '/[^a-z0-9_]/', '', (string) ( $_POST['declencheur'] ?? '' ) );
		$delai = isset( $_POST['delai'] ) ? (float) str_replace( ',', '.', (string) $_POST['delai'] ) : null;
		if ( '' === $src ) { return redirect( 'comptabilite/brouillard' ); }

		FKC_PolitiqueCompta::definir( $src, $mode, $decl ?: null, $delai );
		$this->setFlash( 'Politique de « ' . $src .' » enregistrée.' );
		/*
		 * ON REVIENT AVEC LE PANNEAU OUVERT (1.740.0). Le bloc des politiques
		 * est désormais replié par défaut ; le refermer juste après une
		 * modification cacherait son résultat, et l'on ressaisirait en croyant
		 * que rien n'a été pris.
		 */
		redirect( 'comptabilite/brouillard?politique=1' );
	}

	/**
	 * Clôture : publie le lot d'un déclencheur vers les journaux définitifs.
	 *
	 * Les écritures refusées restent au journal temporaire — elles seront
	 * reprises au prochain déclenchement, une fois leur cause corrigée. Les
	 * masquer donnerait l'illusion d'une clôture complète.
	 */
	public function cloturerLot( $declencheur ) {
		$d = preg_replace( '/[^a-z0-9_]/', '', (string) $declencheur );
		$res = FKC_PolitiqueCompta::publier( $d );

		$msg = $res['publiees'] . ' écriture(s) publiée(s) aux journaux définitifs.';
		if ( $res['refusees'] ) {
			$msg .= ' ' . $res['refusees'] . ' refusée(s), restée(s) au journal temporaire : '
				. implode( ' · ', array_slice( $res['messages'], 0, 3 ) );
		}
		$this->setFlash( $msg, $res['refusees'] ? 'err' : 'ok' );
		redirect( 'comptabilite/brouillard' );
	}

	/** Active/désactive la vérification avant comptabilisation. */
	public function toggle() {
		$on = ! empty( $_POST['actif'] );
		FKC_Brouillard::setEnabled( $on );
		$this->setFlash( $on
			? 'Vérification activée : les nouvelles écritures (saisie, ventes, achats, règlements, OD de paie) passeront par le brouillard.'
			: 'Vérification désactivée : les écritures seront comptabilisées directement.' );
		redirect( 'comptabilite/brouillard' );
	}

	public function edit( $id ) {
		$b = FKC_Brouillard::withLignes( $id );
		if ( ! $b ) { redirect( 'comptabilite/brouillard' ); }
		FKC_View::render( 'comptabilite::brouillard.edit', array(
			'title'    => 'Vérifier le brouillon n°' . (int) $id, 'tab' => 'brouillard',
			'b'        => $b, 'journaux' => FKC_Journal::all(), 'comptes' => FKC_Compte::all(),
			'errors'   => array(), 'pieces' => FKC_PieceJointe::forSource( 'brouillon', $id ),
			// État des lieux affiché AVANT le bouton de comptabilisation : on ne
			// valide pas ce qu'on n'a pas vu.
			'controle' => FKC_Brouillard::controler( $id ),
			// Imputations modifiables (1.763.0) : elles ne voyageaient qu'en
			// champs cachés, donc se corrigeaient en supprimant le brouillon.
			'divisions' => $this->divisions(), 'showDivision' => $this->showDivision(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	public function update( $id ) {
		$entete = array(
			'journal_id'    => (int) ( $_POST['journal_id'] ?? 0 ),
			'date_ecriture' => trim( (string) ( $_POST['date_ecriture'] ?? '' ) ),
			'piece'         => trim( (string) ( $_POST['piece'] ?? '' ) ),
			'libelle'       => trim( (string) ( $_POST['libelle'] ?? '' ) ),
			'reference'     => trim( (string) ( $_POST['reference'] ?? '' ) ),
		);
		$lignes = $this->lignesFromPost();
		$errs = array();
		if ( ! $entete['journal_id'] ) { $errs[] = 'Sélectionnez un journal.'; }
		if ( ! $entete['date_ecriture'] ) { $errs[] = 'La date est requise.'; }
		if ( '' === $entete['libelle'] ) { $errs[] = 'Le libellé est requis.'; }
		if ( ! $errs ) {
			list( $ok, $msg ) = FKC_Brouillard::update( $id, $entete, $lignes );
			if ( $ok ) { $this->setFlash( $msg ); redirect( 'comptabilite/brouillard' ); }
			$errs[] = $msg;
		}
		$b = FKC_Brouillard::withLignes( $id );
		FKC_View::render( 'comptabilite::brouillard.edit', array(
			'title' => 'Vérifier le brouillon n°' . (int) $id, 'tab' => 'brouillard',
			'b' => $b, 'journaux' => FKC_Journal::all(), 'comptes' => FKC_Compte::all(), 'errors' => $errs, 'pieces' => FKC_PieceJointe::forSource( 'brouillon', $id ),
			'controle' => FKC_Brouillard::controler( $id ),
			'divisions' => $this->divisions(), 'showDivision' => $this->showDivision(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
		) );
	}

	public function valider( $id ) {
		list( $ok, $msg ) = FKC_Brouillard::valider( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/brouillard' );
	}

	public function delete( $id ) {
		list( $ok, $msg ) = FKC_Brouillard::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/brouillard' );
	}

	public function validerTout() {
		list( $ok, $ko ) = FKC_Brouillard::validerTout();
		$msg = $ok . ' écriture(s) comptabilisée(s)' . ( $ko ? ', ' . $ko . ' en échec (déséquilibre ou période clôturée)' : '' ) . '.';
		$this->setFlash( $msg, $ko ? 'err' : 'ok' );
		redirect( 'comptabilite/brouillard' );
	}

	/** Divisions actives (vide si l'analytique n'est pas ouvert). */
	protected function divisions() {
		if ( ! class_exists( 'FKC_Division' ) ) { return array(); }
		try { return FKC_Division::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	protected function axes() {
		if ( ! class_exists( 'FKC_Axe' ) ) { return array(); }
		try { return FKC_Axe::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	protected function valeursMap() {
		$map = array();
		if ( ! class_exists( 'FKC_Valeur' ) ) { return $map; }
		foreach ( $this->axes() as $a ) {
			$opts = array();
			try { foreach ( FKC_Valeur::byAxe( (int) $a['id'], true ) as $v ) { $opts[] = array( 'id' => (int) $v['id'], 't' => $v['code'] . ' · ' . $v['libelle'] ); } } catch ( \Throwable $e ) {}
			$map[ (int) $a['id'] ] = $opts;
		}
		return $map;
	}
	protected function analytiqueOn() {
		$lic = FKC_License::resolve();
		return in_array( 'analytique', $lic['modules'] ?? array(), true );
	}
	protected function showDivision() { return $this->analytiqueOn() && count( $this->divisions() ) > 0; }
	protected function showAxes() { return $this->analytiqueOn() && count( $this->axes() ) > 0; }

	protected function lignesFromPost() {
		$comptes = $_POST['compte_id'] ?? array();
		$libs    = $_POST['ligne_libelle'] ?? array();
		$debits  = $_POST['debit'] ?? array();
		$credits = $_POST['credit'] ?? array();
		$divs    = $_POST['division_id'] ?? array();
		$axes    = $_POST['axe_id'] ?? array();
		$vals    = $_POST['valeur_id'] ?? array();
		$affs    = $_POST['affectations'] ?? array();
		$lignes  = array();
		foreach ( (array) $comptes as $i => $cid ) {
			/*
			 * AFFECTATIONS DES AUTRES AXES (1.763.0). L'écran ne modifie qu'un
			 * couple axe/valeur ; une ligne peut en porter plusieurs, posées
			 * par un module. Elles voyagent en clair dans le formulaire pour
			 * revenir intactes — sans ce report, enregistrer le brouillon les
			 * effaçait.
			 */
			$autres = array();
			if ( isset( $affs[ $i ] ) && '' !== $affs[ $i ] ) {
				$d = json_decode( (string) $affs[ $i ], true );
				if ( is_array( $d ) ) {
					foreach ( $d as $aid => $vid ) {
						// Une ventilation (jeu de parts) repart telle quelle (1.823.0).
						if ( is_array( $vid ) ) { if ( (int) $aid > 0 ) { $autres[ (int) $aid ] = $vid; } continue; }
						if ( (int) $aid > 0 && (int) $vid > 0 ) { $autres[ (int) $aid ] = (int) $vid; }
					}
				}
			}
			$axe = isset( $axes[ $i ] ) && $axes[ $i ] !== '' ? (int) $axes[ $i ] : null;
			$val = isset( $vals[ $i ] ) && $vals[ $i ] !== '' ? (int) $vals[ $i ] : null;
			// Le couple saisi fait foi sur SON axe ; l'axe vidé à l'écran est
			// retiré, les autres restent.
			if ( $axe && $val ) { $autres[ $axe ] = $val; }
			$lignes[] = array(
				'compte_id'    => $cid,
				'libelle'      => $libs[ $i ] ?? '',
				'debit'        => $this->num( $debits[ $i ] ?? 0 ),
				'credit'       => $this->num( $credits[ $i ] ?? 0 ),
				'division_id'  => isset( $divs[ $i ] ) && $divs[ $i ] !== '' ? (int) $divs[ $i ] : null,
				'axe_id'       => $axe,
				'valeur_id'    => $val,
				'affectations' => $autres,
			);
		}
		return $lignes;
	}

	protected function num( $v ) { return (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $v ); }
	public function pieceUpload( $id ) {
		$b = FKC_Brouillard::find( $id );
		if ( ! $b ) { redirect( 'comptabilite/brouillard' ); }
		list( $ok, $msg ) = FKC_PieceJointe::add( 'brouillon', $id, $_FILES['piece'] ?? array() );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/brouillard/' . (int) $id );
	}
	public function pieceDownload( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj || 'brouillon' !== $pj['source_type'] ) { http_response_code( 404 ); echo 'Pièce introuvable.'; return; }
		FKC_PieceJointe::stream( $pj );
	}
	public function pieceDelete( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj ) { redirect( 'comptabilite/brouillard' ); }
		$bid = (int) $pj['source_id'];
		list( $ok, $msg ) = FKC_PieceJointe::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/brouillard/' . $bid );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_brl'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_brl'] ?? null; unset( $_SESSION['__flash_brl'] ); return $m; }
}
