<?php
/**
 * Demandes d'achat — le maillon amont de la chaîne d'approvisionnement.
 *
 * Sans cet écran, les demandes créées automatiquement par FKC_ReglesStock
 * s'empilaient sans que personne ne puisse les voir ni les décider : un
 * mécanisme automatique qui produit des enregistrements inaccessibles est pire
 * que pas de mécanisme du tout.
 *
 * Le contrôleur n'implémente aucune règle : il expose FKC_SupplyChain, qui
 * reste le seul endroit où le cycle est décrit.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_DemandeAchatController {

	/*
	 * Flash local, sur la même clé que FKC_AchatController : les deux écrans
	 * appartiennent au même parcours, un message posé par l'un doit pouvoir
	 * s'afficher sur l'autre après redirection.
	 */
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_ach'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_ach'] ?? null; unset( $_SESSION['__flash_ach'] ); return $m; }


	/**
	 * Liste des demandes, filtrable par statut.
	 *
	 * Par défaut on montre CE QUI ATTEND UNE DÉCISION : c'est la seule vue qui
	 * appelle une action. Ouvrir sur l'historique complet obligerait à chercher
	 * le travail à faire au milieu de ce qui est déjà fait.
	 */
	public function index() {
		$statut = isset( $_GET['statut'] ) ? preg_replace( '/[^a-z_]/', '', (string) $_GET['statut'] ) : FKC_SupplyChain::A_VALIDER;
		if ( 'toutes' === $statut ) { $statut = null; }

		FKC_View::render( 'comptabilite::achats.demandes', array(
			'title'      => 'Achats · Demandes',
			'tab'        => 'demandes',
			'statut'     => $statut,
			'demandes'   => FKC_SupplyChain::demandes( $statut ),
			'compteurs'  => FKC_SupplyChain::compteurs(),
			'statuts'    => $this->statuts(),
			'fournisseurs' => class_exists( 'FKC_Fournisseur' ) ? FKC_Fournisseur::all() : array(),
			'part_directe' => $this->partDirecte(),
			'flash'      => $this->flash(),
		) );
	}

	/** Libellés des statuts, dans l'ordre du cycle. */
	protected function statuts() {
		return array(
			FKC_SupplyChain::A_VALIDER => 'À valider',
			FKC_SupplyChain::VALIDEE   => 'Validées',
			FKC_SupplyChain::COMMANDEE => 'Commandées',
			FKC_SupplyChain::RECUE     => 'Reçues',
			FKC_SupplyChain::REFUSEE   => 'Refusées',
		);
	}

	/*
	 * Part des approvisionnements reçus sans demande préalable.
	 *
	 * Un indicateur de contrôle interne plus qu'un chiffre de gestion : si la
	 * quasi-totalité des réceptions arrive au comptoir, le circuit d'achat
	 * n'est pas suivi, et il vaut mieux le savoir que de le découvrir en
	 * révision.
	 */
	protected function partDirecte() {
		$c = FKC_SupplyChain::compteurs();
		$total = array_sum( $c );
		if ( $total < 1 ) { return null; }
		$directes = count( array_filter(
			FKC_SupplyChain::demandes( null, 2000 ),
			function ( $d ) { return FKC_SupplyChain::O_DIRECTE === $d['origine']; }
		) );
		return array( 'nb' => $directes, 'total' => $total, 'pct' => round( $directes / $total * 100 ) );
	}

	/** Création manuelle d'une demande. */
	public function store() {
		list( $ok, $msg ) = FKC_SupplyChain::demander( array(
			'designation'     => (string) ( $_POST['designation'] ?? '' ),
			'quantite'        => (float) ( $_POST['quantite'] ?? 0 ),
			'unite'           => (string) ( $_POST['unite'] ?? '' ),
			'article_ref'     => (string) ( $_POST['article_ref'] ?? '' ),
			'fournisseur_id'  => (int) ( $_POST['fournisseur_id'] ?? 0 ) ?: null,
			'pu_estime'       => (float) ( $_POST['pu_estime'] ?? 0 ),
			'motif'           => (string) ( $_POST['motif'] ?? '' ),
			'origine'         => FKC_SupplyChain::O_MANUELLE,
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/demandes' );
	}

	/** Validation ou refus. */
	public function decider( $id ) {
		$action = (string) ( $_POST['decision'] ?? '' );
		$note   = (string) ( $_POST['note'] ?? '' );

		if ( 'refuser' === $action ) {
			list( $ok, $msg ) = FKC_SupplyChain::refuser( (int) $id, $note );
		} else {
			list( $ok, $msg ) = FKC_SupplyChain::valider( (int) $id, $note );
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/demandes' );
	}

	/** Transformation en bon de commande. */
	public function commander( $id ) {
		list( $ok, $msg ) = FKC_SupplyChain::commander( (int) $id, array(
			'fournisseur_id' => (int) ( $_POST['fournisseur_id'] ?? 0 ) ?: null,
			'montant'        => (float) ( $_POST['montant'] ?? 0 ) ?: null,
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/demandes?statut=' . ( $ok ? FKC_SupplyChain::COMMANDEE : FKC_SupplyChain::VALIDEE ) );
	}

	/**
	 * Lance le moteur de règles : crée les demandes de réapprovisionnement.
	 *
	 * Déclenché à la main depuis l'écran plutôt que par une tâche horaire :
	 * réapprovisionner à 3 h du matin ne sert personne, le faire quand
	 * l'acheteur ouvre son écran oui.
	 */
	public function evaluer() {
		$r = FKC_ReglesStock::reapprovisionner();
		$msg = $r['demandes'] > 0
			? $r['demandes'] . ' demande(s) créée(s) sur ' . $r['examines'] . ' article(s) sous leur seuil.'
			: 'Aucun article sous son seuil : rien à commander.';
		$this->setFlash( $msg );
		redirect( 'comptabilite/achats/demandes' );
	}
}
