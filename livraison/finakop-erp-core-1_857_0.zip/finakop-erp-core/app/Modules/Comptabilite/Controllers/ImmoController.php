<?php
/** Immobilisations : fiches, amortissement, dotations, cessions. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ImmoController {

	/** Exercice en cours (et non l'année civile — 1.855.0). */
	protected function exerciceCourant() {
		return class_exists( 'FKC_Exercice' ) ? (int) FKC_Exercice::courant() : (int) date( 'Y' );
	}

	public function index() {
		/*
		 * Filtre par statut (1.855.0) : la liste mêlait biens en service, biens
		 * cédés et fiches annulées, sans total — impossible d'y lire le parc.
		 */
		$statut = (string) ( $_GET['statut'] ?? 'en_service' );
		if ( ! in_array( $statut, array( 'en_service', 'cede', 'annulee', 'tous' ), true ) ) { $statut = 'en_service'; }
		$rows = array(); $compte = array( 'en_service' => 0, 'cede' => 0, 'annulee' => 0, 'tous' => 0 );
		foreach ( FKC_Immobilisation::all() as $im ) {
			$st = (string) $im['statut'];
			$compte[ isset( $compte[ $st ] ) ? $st : 'en_service' ]++; $compte['tous']++;
			if ( 'tous' !== $statut && $st !== $statut ) { continue; }
			$im['vnc'] = FKC_Immobilisation::vnc( $im );
			$im['cumul'] = FKC_Immobilisation::cumulAmorti( $im['id'] );
			$im['amortissable'] = FKC_Immobilisation::estAmortissable( $im );
			$rows[] = $im;
		}
		FKC_View::render( 'comptabilite::immobilisations.index', array(
			'title' => 'Comptabilité · Immobilisations', 'tab' => 'immo',
			'immos' => $rows, 'flash' => $this->flash(),
			'statut' => $statut, 'compteStatuts' => $compte,
			'synthese' => FKC_Immobilisation::synthese( $this->exerciceCourant() ),
			'rapprochement' => FKC_Immobilisation::rapprochement(),
			'pieces' => FKC_PieceJointe::countMap( 'immobilisation', array_column( $rows, 'id' ) ),
			'seuil' => FKC_Immobilisation::seuil(),
			'isAdmin' => ! class_exists( 'FKC_Auth' ) || FKC_Auth::isAdmin(),
		) );
	}
	public function create() {
		/*
		 * REPRISE D'UNE FICHE (1.761.0) — `?copie={id}`. Ressaisir de mémoire
		 * une fiche que l'on vient d'annuler est le meilleur moyen de se
		 * tromper une seconde fois. Le code et le code-barres ne sont PAS
		 * repris : ils appartiennent à la fiche annulée, qui les garde.
		 */
		$old = array();
		if ( ! empty( $_GET['copie'] ) ) {
			$src = FKC_Immobilisation::find( (int) $_GET['copie'] );
			if ( $src ) {
				foreach ( array( 'libelle', 'compte_immo', 'compte_amort', 'compte_dotation', 'date_acquisition',
					'valeur_acquisition', 'valeur_residuelle', 'duree_annees', 'division_id', 'methode', 'coef_degressif', 'unites_total', 'date_mise_en_service' ) as $k ) {
					$old[ $k ] = $src[ $k ] ?? '';
				}
				$old['__copie'] = (int) $src['id'];
			}
		}
		FKC_View::render( 'comptabilite::immobilisations.form', array( 'title' => 'Nouvelle immobilisation', 'tab' => 'immo', 'plan' => FKC_Compte::all(), 'errors' => array(), 'seuil' => FKC_Immobilisation::seuil(), 'old' => $old, 'belowSeuil' => false ) );
	}
	/**
	 * Contrôles communs à la saisie et à l'import (1.855.0) : montants lus par
	 * FKC_Immobilisation::nombre() — « 1 500 000 » valait 1 —, durée exigée
	 * seulement pour un bien qui s'amortit, date valide.
	 */
	protected function erreursFiche( array $p ) {
		$errs = array();
		if ( '' === trim( (string) ( $p['libelle'] ?? '' ) ) ) { $errs[] = 'Le libellé est requis.'; }
		if ( FKC_Immobilisation::nombre( $p['valeur_acquisition'] ?? 0 ) <= 0 ) { $errs[] = 'La valeur d\'acquisition doit être positive.'; }
		if ( FKC_Immobilisation::nombre( $p['valeur_residuelle'] ?? 0 ) >= FKC_Immobilisation::nombre( $p['valeur_acquisition'] ?? 0 )
			&& FKC_Immobilisation::nombre( $p['valeur_residuelle'] ?? 0 ) > 0 ) { $errs[] = 'La valeur résiduelle doit rester inférieure à la valeur d\'acquisition.'; }
		$amort = FKC_Immobilisation::estAmortissable( (string) ( ( $p['compte_immo'] ?? '' ) ?: '241000' ) );
		if ( $amort && FKC_Immobilisation::nombre( $p['duree_annees'] ?? 0 ) <= 0 ) { $errs[] = 'La durée doit être positive.'; }
		$d = (string) ( $p['date_acquisition'] ?? '' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) || ! strtotime( $d ) ) { $errs[] = 'La date d\'acquisition est invalide.'; }
		// 1.856.0 — méthode d'amortissement et mise en service.
		$m = (string) ( $p['methode'] ?? 'lineaire' );
		if ( $amort && 'unites' === $m && FKC_Immobilisation::nombre( $p['unites_total'] ?? 0 ) <= 0 ) {
			$errs[] = 'Indiquez le nombre total d\'unités d\'œuvre prévues (kilomètres, heures…).';
		}
		if ( $amort && 'degressif' === $m && FKC_Immobilisation::nombre( $p['duree_annees'] ?? 0 ) < 3 ) {
			$errs[] = 'Le dégressif ne s\'applique qu\'aux biens amortis sur 3 ans au moins.';
		}
		$ms = trim( (string) ( $p['date_mise_en_service'] ?? '' ) );
		if ( '' !== $ms && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $ms ) || ! strtotime( $ms ) || $ms < $d ) ) {
			$errs[] = 'La date de mise en service doit être valide et postérieure à l\'acquisition.';
		}
		return $errs;
	}

	public function store() {
		$errs = $this->erreursFiche( $_POST );
		$val = FKC_Immobilisation::nombre( $_POST['valeur_acquisition'] ?? 0 );
		$below = empty( $errs ) && FKC_Immobilisation::sousSeuil( $val ) && empty( $_POST['immo_force'] );
		if ( $errs || $below ) {
			return FKC_View::render( 'comptabilite::immobilisations.form', array(
				'title' => 'Nouvelle immobilisation', 'tab' => 'immo', 'plan' => FKC_Compte::all(),
				'errors' => $errs, 'seuil' => FKC_Immobilisation::seuil(), 'old' => $_POST, 'belowSeuil' => $below,
			) );
		}
		$id = FKC_Immobilisation::create( $_POST );
		$this->setFlash( 'Immobilisation enregistrée.' );
		redirect( 'comptabilite/immobilisations/' . $id );
	}
	/** Enregistre le seuil d'immobilisation (admin). */
	public function seuilSave() {
		if ( class_exists( 'FKC_Auth' ) && ! FKC_Auth::isAdmin() ) { redirect( 'comptabilite/immobilisations' ); }
		FKC_Immobilisation::setSeuil( $_POST['seuil'] ?? 0 );
		$s = FKC_Immobilisation::seuil();
		$this->setFlash( $s > 0 ? 'Seuil d\'immobilisation fixé à ' . fkc_money( $s ) . ' FCFA.' : 'Seuil d\'immobilisation désactivé.' );
		redirect( 'comptabilite/immobilisations' );
	}
	public function show( $id ) {
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { redirect( 'comptabilite/immobilisations' ); }
		$dots = FKC_Immobilisation::dotations( $id );
		$faits = array();
		foreach ( $dots as $d ) { $faits[ (int) $d['exercice'] ] = $d; }
		FKC_View::render( 'comptabilite::immobilisations.show', array(
			'title' => $im['libelle'], 'tab' => 'immo',
			'im' => $im, 'plan' => FKC_Immobilisation::plan( $im ), 'faits' => $faits,
			'cumul' => FKC_Immobilisation::cumulAmorti( $id ), 'vnc' => FKC_Immobilisation::vnc( $im ),
			'comptes' => FKC_Tresorerie::comptes( true ), 'flash' => $this->flash(),
			'pieces' => FKC_PieceJointe::forSource( 'immobilisation', $id ),
			'dejaPasse' => FKC_Immobilisation::dotationsComptabilisees( $id ),
			// Annulation (1.761.0) : ce qui l'empêche, et l'état de l'écriture
			// d'acquisition — que rien ne disait jusqu'ici.
			'planMensuel' => FKC_Immobilisation::planMensuel( $im ),
			'mensuel' => FKC_Immobilisation::mensuel(),
			'faitsMois' => self::faitsMois( $id ),
			'blocages' => FKC_Immobilisation::blocages( $id ),
			'blocagesSuppression' => FKC_Immobilisation::blocagesSuppression( $id ),
			'contrepassation' => FKC_Immobilisation::acquisitionContrepassee( $im ),
			'amortissable' => FKC_Immobilisation::estAmortissable( $im ),
			// 1.856.0 — fonctions avancées.
			'depreciations' => FKC_Immobilisation::depreciations( $id ),
			'cumulDeprecie' => FKC_Immobilisation::cumulDeprecie( $id ),
			'numDep' => FKC_Immobilisation::numerosDepreciation( $im ),
			'composants' => FKC_Immobilisation::composants( $id ),
			'parent' => ! empty( $im['parent_id'] ) ? FKC_Immobilisation::find( (int) $im['parent_id'] ) : null,
			'reevaluations' => FKC_Immobilisation::reevaluations( (int) $id ),
			'unites' => FKC_Immobilisation::unites( (int) $id ),
			'enCours' => FKC_Immobilisation::estEnCours( $im ),
			'exercice' => $this->exerciceCourant(),
			'complementAujourdhui' => FKC_Immobilisation::estEnService( $im ) ? FKC_Immobilisation::dotationComplementaire( $im, date( 'Y-m-d' ) ) : 0.0,
			'isAdmin' => ! class_exists( 'FKC_Auth' ) || FKC_Auth::isAdmin(),
			'reclassement' => ( ( $_SESSION['__immo_reclassement']['immo'] ?? 0 ) === (int) $id )
				? ( $_SESSION['__immo_reclassement']['lignes'] ?? array() ) : array(),
		) );
		unset( $_SESSION['__immo_reclassement'] );
	}
	/**
	 * CORRECTION DES COMPTES D'UNE FICHE (1.726.0).
	 *
	 * Le reclassement des dotations déjà passées n'est pas fait ici : il est
	 * PROPOSÉ à l'écran, et c'est le comptable qui le date et le valide. Le
	 * produit n'a aucun moyen de savoir quels exercices sont réellement
	 * arrêtés chez le client.
	 */
	public function comptesSave( $id ) {
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { redirect( 'comptabilite/immobilisations' ); }
		$ancienAmort = (string) $im['compte_amort'];
		list( $ok, $msg ) = FKC_Immobilisation::corrigerComptes( $id, array(
			'compte_immo'     => $_POST['compte_immo'] ?? '',
			'compte_amort'    => $_POST['compte_amort'] ?? '',
			'compte_dotation' => $_POST['compte_dotation'] ?? '',
		) );
		if ( $ok ) {
			$apres = FKC_Immobilisation::find( $id );
			$prop = FKC_Immobilisation::reclassementPropose( $apres, $ancienAmort, (string) $im['compte_dotation'] );
			if ( $prop ) { $_SESSION['__immo_reclassement'] = array( 'immo' => (int) $id, 'lignes' => $prop ); }
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . $id );
	}

	/** État des dotations mensuelles déjà passées : "exercice-mois" => état. */
	protected static function faitsMois( $id ) {
		$out = array();
		try {
			$rows = FKC_DB::q( 'SELECT exercice, mois, ecriture_id FROM immo_dotations WHERE immobilisation_id=? AND mois IS NOT NULL', array( (int) $id ) )->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( $rows as $r ) {
			$out[ (int) $r['exercice'] . '-' . (int) $r['mois'] ] = empty( $r['ecriture_id'] ) ? 'attente' : 'comptabilisee';
		}
		return $out;
	}

	public function doter( $id ) {
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { redirect( 'comptabilite/immobilisations' ); }
		$mois = ( isset( $_POST['mois'] ) && '' !== $_POST['mois'] ) ? (int) $_POST['mois'] : null;
		list( $ok, $msg ) = FKC_Immobilisation::comptabiliserDotation( $im, (int) ( $_POST['exercice'] ?? $this->exerciceCourant() ), $mois );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . $id );
	}
	/**
	 * ANNULER LA FICHE (1.761.0) — voir FKC_Immobilisation::annuler().
	 *
	 * L'écriture d'acquisition n'est pas touchée ici : elle se contre-passe
	 * depuis l'écran des écritures, et le message le rappelle quand elle est
	 * encore en place.
	 */
	public function annuler( $id ) {
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { redirect( 'comptabilite/immobilisations' ); }
		list( $ok, $msg ) = FKC_Immobilisation::annuler( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}

	/** Suppression définitive — administrateur, fiche vierge uniquement. */
	public function supprimer( $id ) {
		if ( class_exists( 'FKC_Auth' ) && ! FKC_Auth::isAdmin() ) {
			$this->setFlash( 'Seul un administrateur peut supprimer définitivement une fiche.', 'err' );
			redirect( 'comptabilite/immobilisations/' . (int) $id );
		}
		list( $ok, $msg ) = FKC_Immobilisation::supprimer( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/immobilisations' : 'comptabilite/immobilisations/' . (int) $id );
	}

	public function ceder( $id ) {
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { redirect( 'comptabilite/immobilisations' ); }
		// Le prix est lu par le modèle (« 1 500 000 ») ; sans prix, c'est une mise au rebut.
		list( $ok, $msg ) = FKC_Immobilisation::ceder( $im, (string) ( $_POST['date_cession'] ?? date( 'Y-m-d' ) ), (string) ( $_POST['valeur_cession'] ?? '0' ), (int) ( $_POST['tresorerie_id'] ?? 0 ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . $id );
	}

	/* ── 1.856.0 : dépréciation, unités d'œuvre, composant, réévaluation, mise en service ── */

	public function deprecier( $id ) {
		$montant = FKC_Immobilisation::nombre( $_POST['montant'] ?? 0 );
		if ( 'reprise' === (string) ( $_POST['sens'] ?? '' ) ) { $montant = -abs( $montant ); }
		list( $ok, $msg ) = FKC_Immobilisation::deprecier( (int) $id, (string) ( $_POST['date'] ?? date( 'Y-m-d' ) ), $montant, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}

	public function unites( $id ) {
		list( $ok, $msg ) = FKC_Immobilisation::saisirUnites( (int) $id, (int) ( $_POST['exercice'] ?? $this->exerciceCourant() ), (string) ( $_POST['unites'] ?? '0' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}

	public function composant( $id ) {
		list( $ok, $msg, $cid ) = FKC_Immobilisation::ventilerComposant( (int) $id, array(
			'libelle' => $_POST['libelle'] ?? '', 'valeur' => $_POST['valeur'] ?? 0,
			'duree_annees' => $_POST['duree_annees'] ?? 0, 'compte_immo' => $_POST['compte_immo'] ?? '',
			'methode' => $_POST['methode'] ?? 'lineaire',
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}

	public function reevaluer( $id ) {
		list( $ok, $msg ) = FKC_Immobilisation::reevaluer( (int) $id, (string) ( $_POST['date'] ?? date( 'Y-m-d' ) ), (string) ( $_POST['valeur_actuelle'] ?? '0' ), (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}

	public function miseEnService( $id ) {
		list( $ok, $msg ) = FKC_Immobilisation::mettreEnService( (int) $id, (string) ( $_POST['date'] ?? date( 'Y-m-d' ) ),
			(string) ( $_POST['compte_immo'] ?? '' ), (string) ( $_POST['duree_annees'] ?? '0' ), (string) ( $_POST['methode'] ?? 'lineaire' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}

	/** Plan d'amortissement consolidé (toutes les immobilisations). */
	/**
	 * Écran de correspondance immobilisation → amortissement.
	 *
	 * Il sert deux publics à la fois : celui qui veut comprendre la règle
	 * appliquée, et celui qui reprend un dossier existant et doit savoir ce qui
	 * y est mal mappé. Les deux tiennent sur le même écran parce que la
	 * question est la même — « où part l'amortissement de ce bien ? ».
	 */
	public function mapping() {
		/*
		 * LE GARDE QUI ÉTAIT ICI N'EXISTAIT PAS (corrigé en 1.589.0).
		 *
		 * Les deux méthodes de correspondance appelaient « $this->feature(…) ».
		 * Ce helper vit dans trois autres contrôleurs (Inventaire, Analytique,
		 * RH) ; FKC_ImmoController n'étend aucune classe de base et ne l'a
		 * jamais défini. Les deux routes tombaient donc sur « Call to undefined
		 * method » — l'écran des comptes d'amortissement était inatteignable
		 * et son enregistrement impossible, pour tous les packs.
		 *
		 * Le garde n'est pas réécrit, il est RETIRÉ, pour deux raisons : son
		 * argument « comptabilite » est un code de MODULE et non de
		 * fonctionnalité (FKC_Modules::features() n'en contient aucun, et
		 * featureEnabled() rend « true » pour tout code inconnu — le garde
		 * n'aurait donc jamais rien gardé) ; et le module comptabilité est
		 * déjà exigé par la route elle-même, au routeur, où vivent tous les
		 * autres contrôles d'accès.
		 */
		FKC_View::render( 'comptabilite::immobilisations.comptes', array(
			'title' => 'Immobilisations · Comptes d\'amortissement',
			'tab'   => 'immobilisations',
			'table' => FKC_MappingAmortissement::table(),
			'audit' => FKC_MappingAmortissement::auditer(),
			'flash' => $this->flash(),
		) );
	}

	/** Enregistre une correspondance propre à la société. */
	public function mappingSave() {
		/* Même garde inexistant que dans mapping() — voir le commentaire là-bas. */
		list( , $msg ) = FKC_MappingAmortissement::definirSurcharge(
			(string) ( $_POST['racine'] ?? '' ),
			(string) ( $_POST['amortissement'] ?? '' ),
			(string) ( $_POST['depreciation'] ?? '' )
		);
		$this->setFlash( $msg );
		redirect( 'comptabilite/immobilisations/comptes' );
	}

	public function plan() {
		$rows = array();
		foreach ( FKC_Immobilisation::all() as $im ) {
			// Fiche annulée ou bien non amortissable : pas de plan à montrer (1.855.0).
			if ( FKC_Immobilisation::estAnnulee( $im ) || ! FKC_Immobilisation::estAmortissable( $im ) ) { continue; }
			$rows[] = array( 'immo' => $im, 'plan' => FKC_Immobilisation::plan( $im ), 'cumul' => FKC_Immobilisation::cumulAmorti( $im['id'] ), 'vnc' => FKC_Immobilisation::vnc( $im ) );
		}
		FKC_View::render( 'comptabilite::immobilisations.plan', array(
			'title' => 'Immobilisations · Plan d\'amortissement', 'tab' => 'immo',
			'lignes' => $rows, 'flash' => $this->flash(),
		) );
	}

	/** Importer une immobilisation depuis une écriture (compte de classe 2). */
	public function importIndex() {
		FKC_View::render( 'comptabilite::immobilisations.import', array(
			'title' => 'Immobilisations · Importer depuis écriture', 'tab' => 'immo',
			'sources' => FKC_Immobilisation::ecrituresImmobilisables(), 'flash' => $this->flash(),
		) );
	}
	public function importStore() {
		$errs = $this->erreursFiche( $_POST );
		if ( $errs ) { $this->setFlash( implode( ' ', $errs ), 'err' ); redirect( 'comptabilite/immobilisations/import' ); }
		$id = FKC_Immobilisation::create( $_POST );
		$this->setFlash( 'Immobilisation créée depuis l\'écriture et rattachée.' );
		redirect( 'comptabilite/immobilisations/' . $id );
	}

	/** Lancer l'amortissement d'un exercice (toutes les immobilisations en service). */
	public function amortirForm() {
		FKC_View::render( 'comptabilite::immobilisations.amortir', array(
			'title' => 'Immobilisations · Lancer l\'amortissement', 'tab' => 'immo',
			'immos' => array_values( array_filter( FKC_Immobilisation::enService(), array( 'FKC_Immobilisation', 'estAmortissable' ) ) ),
			'exercice' => $this->exerciceCourant(),
			'mensuel' => FKC_Immobilisation::mensuel(), 'moisCourant' => (int) date( 'n' ),
			'flash' => $this->flash(),
		) );
	}
	public function amortirRun() {
		$ex = (int) ( $_POST['exercice'] ?? $this->exerciceCourant() );
		// En périodicité mensuelle, la campagne porte sur UN mois (1.765.0).
		$mois = ( isset( $_POST['mois'] ) && '' !== $_POST['mois'] ) ? (int) $_POST['mois'] : null;
		list( $ok, $skip, $total ) = FKC_Immobilisation::lancerAmortissement( $ex, $mois );
		$periode = ( null === $mois ) ? 'l\'exercice ' . $ex : sprintf( '%02d/%04d', $mois, $ex );
		$this->setFlash( $ok . ' dotation(s) comptabilisée(s) pour ' . $periode . ' (' . fkc_money( $total ) . ' FCFA)' . ( $skip ? ', ' . $skip . ' ignorée(s)' : '' ) . '.', $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/amortir' );
	}

	/** Périodicité des dotations : annuelle ou mensuelle (1.765.0). */
	public function periodiciteSave() {
		$v = FKC_Immobilisation::definirPeriodicite( $_POST['periodicite'] ?? 'annuelle' );
		$this->setFlash( 'mensuelle' === $v
			? 'Amortissement mensuel : les dotations se comptabilisent mois par mois, datées de la fin du mois.'
			: 'Amortissement annuel : une dotation par exercice, datée de la clôture.', 'ok' );
		redirect( 'comptabilite/immobilisations/amortir' );
	}

	/** Cession : sélection d'une immobilisation et saisie. */
	public function cessionForm() {
		FKC_View::render( 'comptabilite::immobilisations.cession', array(
			'title' => 'Immobilisations · Cession', 'tab' => 'immo',
			'immos' => FKC_Immobilisation::enService(), 'comptes' => FKC_Tresorerie::comptes( true ), 'flash' => $this->flash(),
		) );
	}
	public function cederSelection() {
		$id = (int) ( $_POST['immo_id'] ?? 0 );
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { $this->setFlash( 'Immobilisation introuvable.', 'err' ); redirect( 'comptabilite/immobilisations/cession' ); }
		list( $ok, $msg ) = FKC_Immobilisation::ceder( $im, (string) ( $_POST['date_cession'] ?? date( 'Y-m-d' ) ), (string) ( $_POST['valeur_cession'] ?? '0' ), (int) ( $_POST['tresorerie_id'] ?? 0 ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? ( 'comptabilite/immobilisations/' . $id ) : 'comptabilite/immobilisations/cession' );
	}
	/** Ajoute une pièce justificative à une immobilisation. */
	public function pieceUpload( $id ) {
		$im = FKC_Immobilisation::find( $id );
		if ( ! $im ) { redirect( 'comptabilite/immobilisations' ); }
		list( $ok, $msg ) = FKC_PieceJointe::add( 'immobilisation', $id, $_FILES['piece'] ?? array() );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . (int) $id );
	}
	public function pieceDownload( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj || 'immobilisation' !== $pj['source_type'] ) { http_response_code( 404 ); echo 'Pièce introuvable.'; return; }
		FKC_PieceJointe::stream( $pj );
	}
	public function pieceDelete( $id ) {
		$pj = FKC_PieceJointe::find( $id );
		if ( ! $pj ) { redirect( 'comptabilite/immobilisations' ); }
		$iid = (int) $pj['source_id'];
		list( $ok, $msg ) = FKC_PieceJointe::delete( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/immobilisations/' . $iid );
	}

	/* ── Récolement (inventaire physique des actifs) ───────────────────── */

	public function recolement() {
		FKC_ImmoRecolement::ensure();
		FKC_View::render( 'comptabilite::immobilisations.recolement', array(
			'title' => 'Immobilisations · Récolement', 'tab' => 'immobilisations',
			'campagne' => FKC_ImmoRecolement::campagneOuverte(),
			'rapport'  => FKC_ImmoRecolement::rapport(),
			'sansCode' => $this->sansCodeBarres(),
			'flash'    => $this->flash(),
		) );
	}

	/** Ouverture, clôture, pointage manuel et rattrapage des codes. */
	public function recolementAction() {
		$a = (string) ( $_POST['action'] ?? '' );
		if ( 'ouvrir' === $a ) {
			list( $ok, $msg ) = FKC_ImmoRecolement::ouvrir( (string) ( $_POST['libelle'] ?? '' ) );
			$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		} elseif ( 'cloturer' === $a ) {
			list( $ok, $msg ) = FKC_ImmoRecolement::cloturer( (string) ( $_POST['note'] ?? '' ) );
			$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		} elseif ( 'pointer' === $a ) {
			// Saisie manuelle : tout le parc n'est pas accessible à la douchette
			// (matériel scellé, véhicule en mission, étiquette arrachée).
			list( $ok, $msg ) = FKC_ImmoRecolement::pointer( (int) ( $_POST['immobilisation_id'] ?? 0 ), array(
				'emplacement' => (string) ( $_POST['emplacement'] ?? '' ),
				'detenteur'   => (string) ( $_POST['detenteur'] ?? '' ),
			) );
			$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		} elseif ( 'codes' === $a ) {
			$r = FKC_ImmoRecolement::attribuerCodesManquants();
			$this->setFlash( sprintf( '%d code(s) attribué(s), %d actif(s) en avaient déjà un.', $r['traitees'], $r['deja'] ) );
		}
		redirect( 'comptabilite/immobilisations/recolement' );
	}

	/** Actifs encore sans code-barres : ils échapperaient au scan. */
	protected function sansCodeBarres() {
		try {
			return (int) FKC_DB::q( "SELECT COUNT(*) FROM immobilisations WHERE COALESCE(code_barres,'')='' AND COALESCE(statut,'') NOT IN ('cede','annulee')" )->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_im'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_im'] ?? null; unset( $_SESSION['__flash_im'] ); return $m; }
}
