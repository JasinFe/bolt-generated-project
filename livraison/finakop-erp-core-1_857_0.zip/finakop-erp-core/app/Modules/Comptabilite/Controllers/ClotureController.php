<?php
/**
 * ASSISTANT DE CLÔTURE — l'écran qui manquait.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * POURQUOI UN ÉCRAN, ET POURQUOI ICI
 *
 * Clôturer un exercice se faisait depuis Paramètres → Exercices, entre la
 * purge des données et la gestion des comptes de trésorerie. Trois problèmes,
 * tous les trois de fond :
 *
 *   — l'arrêté des comptes est un travail COMPTABLE, pas un réglage. Un
 *     comptable qui cherche « comment je clôture » ne va pas dans Paramètres,
 *     et l'écran était réservé aux administrateurs, ce qui excluait
 *     précisément la personne qui fait le travail ;
 *   — le formulaire ne montrait aucun état : ni l'avancement, ni les
 *     anomalies, ni ce qui restait à faire. On cliquait, et on découvrait
 *     après coup si ça passait ;
 *   — l'affectation du résultat et les à-nouveaux n'avaient aucun écran du
 *     tout — le premier parce que la fonction n'existait pas, le second
 *     parce qu'il était noyé dans une case à cocher de l'ouverture
 *     d'exercice.
 *
 * Cet écran réunit les sept étapes du processus, la checklist, l'affectation,
 * les à-nouveaux, le rapprochement N/N+1 et le journal de clôture. Il reste
 * accessible depuis Paramètres → Exercices, qui garde ses réglages.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ClotureController {

	/* ══════════════════════════════════════════════════════════════════════
	 * ASSISTANT
	 * ══════════════════════════════════════════════════════════════════════ */

	public function index() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.index', array(
			'title'     => 'Comptabilité · Clôture de l\'exercice ' . $annee,
			'tab'       => 'cloture',
			'annee'     => $annee,
			'annees'    => $this->annees(),
			'libelle'   => class_exists( 'FKC_Exercice' ) ? FKC_Exercice::libelle( $annee ) : (string) $annee,
			'processus' => FKC_ClotureProcessus::etat( $annee ),
			'categories'=> FKC_ClotureChecklist::parCategorie( $annee, 'cloture' ),
			'synthese'  => FKC_ClotureChecklist::synthese( $annee, 'cloture' ),
			'cloture'   => FKC_Cloture::annuelleDe( $annee ),
			'affectation' => class_exists( 'FKC_AffectationResultat' ) ? FKC_AffectationResultat::find( $annee ) : null,
			'an_existent' => class_exists( 'FKC_ANouveaux' ) ? FKC_ANouveaux::existent( $annee + 1 ) : false,
			// Une ligne, et le lien : l'assistant n'a pas la place de neuf domaines.
			'inventaire'  => class_exists( 'FKC_Inventaire' ) ? FKC_Inventaire::resume( $annee ) : '',
			// Une ligne également : l'assistant annonce l'impôt, l'écran fiscal
			// l'explique. Un impôt qu'on lit sans pouvoir l'expliquer ne se
			// défend pas devant un vérificateur.
			'fiscal'      => class_exists( 'FKC_ResultatFiscal' ) ? $this->resumeFiscal( $annee ) : '',
			'admin'     => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'flash'     => $this->flash(),
		) );
	}

	/**
	 * RAPPORTS IMPRIMABLES (phase 5) — état de clôture, anomalies, à-nouveaux,
	 * rapprochement N/N+1, passage fiscal, ou le dossier complet.
	 *
	 * Feuille autonome (sans le gabarit de l'application) : elle s'imprime
	 * ou s'enregistre en PDF depuis le navigateur, comme la liasse DGI.
	 * L'impression est consignée au journal de clôture pour le dossier
	 * COMPLET seulement — c'est lui qui sort pour l'assemblée ou le
	 * commissaire aux comptes ; consigner chaque aperçu noierait le registre.
	 */
	public function imprimer() {
		$annee = $this->annee();
		$type  = (string) ( $_GET['rapport'] ?? 'etat' );
		$rapport = FKC_ClotureRapport::assembler( $type, $annee );
		if ( 'dossier' === $rapport['type'] && class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'impression', array(
				'libelle' => 'Édition du dossier de clôture' . ( '' !== $rapport['entete']['mention'] ? ' (PROVISOIRE)' : '' ),
			) );
		}
		FKC_View::render( 'comptabilite::cloture.imprimer', array(
			'rapport' => $rapport,
			'types'   => FKC_ClotureRapport::types(),
		), false );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * TVA RAPPROCHÉE DES DÉCLARATIONS, ACOMPTES D'IS (1.784.0)
	 * ══════════════════════════════════════════════════════════════════════ */

	public function tva() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.tva', array(
			'title'  => 'Comptabilité · Rapprochement TVA ' . $annee,
			'tab'    => 'cloture',
			'annee'  => $annee,
			'annees' => $this->annees(),
			'rap'    => FKC_TvaRapprochement::exercice( $annee ),
			'flash'  => $this->flash(),
		) );
	}

	public function acomptes() {
		$annee = $this->annee();
		$impot = null;
		if ( class_exists( 'FKC_ResultatFiscal' ) && FKC_ClotureExplication::exerciceTermine( $annee ) ) {
			try { $impot = FKC_ResultatFiscal::tableau( $annee )['impot']; } catch ( \Throwable $e ) {}
		}
		FKC_View::render( 'comptabilite::cloture.acomptes', array(
			'title'   => 'Comptabilité · Acomptes d\'impôt ' . $annee,
			'tab'     => 'cloture',
			'annee'   => $annee,
			'annees'  => $this->annees(),
			'liste'   => FKC_AcompteIs::lister( $annee ),
			'totaux'  => FKC_AcompteIs::totaux( $annee ),
			'base'    => FKC_AcompteIs::baseProposee( $annee ),
			'dates'   => FKC_AcompteIs::echeancesParDefaut(),
			'statuts' => FKC_AcompteIs::statuts(),
			'tresos'  => class_exists( 'FKC_Tresorerie' ) ? FKC_Tresorerie::comptes( true ) : array(),
			'impot'   => $impot,
			'flash'   => $this->flash(),
		) );
	}

	protected function retourAcomptes( $annee ) { redirect( 'comptabilite/cloture/acomptes?annee=' . (int) $annee ); }

	public function acomptesPlanifier() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_AcompteIs::planifier( $annee, (string) ( $_POST['base'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' ); $this->retourAcomptes( $annee );
	}

	public function acompteCreer() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_AcompteIs::creer( $annee, (string) ( $_POST['echeance'] ?? '' ), (string) ( $_POST['montant'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' ); $this->retourAcomptes( $annee );
	}

	public function acomptePayer( $id ) {
		$a = FKC_AcompteIs::find( $id );
		list( $ok, $msg ) = FKC_AcompteIs::payer( $id, (int) ( $_POST['tresorerie_id'] ?? 0 ), (string) ( $_POST['date'] ?? '' ), (string) ( $_POST['reference'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' ); $this->retourAcomptes( $a ? (int) $a['exercice'] : $this->annee() );
	}

	public function acompteAnnuler( $id ) {
		$a = FKC_AcompteIs::find( $id );
		list( $ok, $msg ) = FKC_AcompteIs::annuler( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' ); $this->retourAcomptes( $a ? (int) $a['exercice'] : $this->annee() );
	}

	public function acomptesImputer() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_AcompteIs::imputer( $annee );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' ); $this->retourAcomptes( $annee );
	}

	/** Journal de clôture : la trace, pour l'audit. */
	public function journal() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.journal', array(
			'title'  => 'Comptabilité · Journal de clôture ' . $annee,
			'tab'    => 'cloture',
			'annee'  => $annee,
			'annees' => $this->annees(),
			'lignes' => FKC_ClotureJournal::pour( $annee, 300 ),
			'operations' => FKC_ClotureJournal::operations(),
			'flash'  => $this->flash(),
		) );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * ÉTAPES ET CONTRÔLES
	 * ══════════════════════════════════════════════════════════════════════ */

	public function validerEtape() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		$etape = (string) ( $_POST['etape'] ?? '' );
		$valide = ! empty( $_POST['valide'] );
		list( $ok, $msg ) = FKC_ClotureProcessus::valider( $annee, $etape, $valide, (string) ( $_POST['note'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	public function justifier() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		$code  = (string) ( $_POST['controle'] ?? '' );
		list( $ok, $msg ) = FKC_ClotureChecklist::justifier( $annee, $code, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	public function retirerJustification() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		$code  = (string) ( $_POST['controle'] ?? '' );
		list( $ok, $msg ) = FKC_ClotureChecklist::retirerJustification( $annee, $code );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * RÉSULTAT ET CLÔTURE
	 * ══════════════════════════════════════════════════════════════════════ */

	public function determinerResultat() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_Cloture::determinerResultat( $annee );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	public function cloturer() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		$type  = (string) ( $_POST['type'] ?? 'annuelle' );
		$sub   = (int) ( $_POST['sub'] ?? 1 );
		list( $ok, $msg ) = FKC_Cloture::create( $type, $annee, $sub, array( 'note' => (string) ( $_POST['note'] ?? '' ) ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	public function rouvrir( $id ) {
		$c = FKC_Cloture::find( $id );
		$annee = $c ? FKC_Cloture::anneeDe( $c ) : $this->annee();
		list( $ok, $msg ) = FKC_Cloture::reopen( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	public function verrouiller( $id ) {
		$c = FKC_Cloture::find( $id );
		$annee = $c ? FKC_Cloture::anneeDe( $c ) : $this->annee();
		/*
		 * Le verrou définitif demande une confirmation FRAPPÉE, pas une boîte
		 * de dialogue. Un « OK » se clique par réflexe ; écrire le mot suppose
		 * d'avoir lu ce qu'on fait — et ce geste-là ne se défait pas.
		 */
		if ( 'DEFINITIF' !== trim( (string) ( $_POST['confirm'] ?? '' ) ) ) {
			$this->setFlash( 'Confirmation incorrecte : saisissez DEFINITIF pour verrouiller définitivement cette clôture. '
				. 'Après ce geste, l\'exercice ne pourra plus être rouvert, par personne.', 'err' );
			$this->retour( $annee );
		}
		list( $ok, $msg ) = FKC_Cloture::verrouiller( (int) $id, (string) ( $_POST['note'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retour( $annee );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * AFFECTATION DU RÉSULTAT
	 * ══════════════════════════════════════════════════════════════════════ */

	public function affectation() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.affectation', array(
			'title'   => 'Comptabilité · Affectation du résultat ' . $annee,
			'tab'     => 'cloture',
			'annee'   => $annee,
			'annees'  => $this->annees(),
			'aff'     => FKC_AffectationResultat::preparer( $annee ), // « data » est masqué par FKC_View::render (extract EXTR_SKIP)
			'admin'   => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'flash'   => $this->flash(),
		) );
	}

	public function affecter() {
		$annee  = (int) ( $_POST['annee'] ?? 0 );
		$lignes = array();
		foreach ( (array) ( $_POST['compte'] ?? array() ) as $i => $compte ) {
			$mt = (float) str_replace( array( ' ', ' ', ',' ), array( '', '', '.' ), (string) ( $_POST['montant'][ $i ] ?? 0 ) );
			if ( $mt <= 0 ) { continue; }
			$lignes[] = array(
				'compte'  => (string) $compte,
				'montant' => $mt,
				'libelle' => (string) ( $_POST['libelle'][ $i ] ?? '' ),
			);
		}
		list( $ok, $msg ) = FKC_AffectationResultat::enregistrer( $annee, $lignes, array(
			'date_decision' => (string) ( $_POST['date_decision'] ?? '' ),
			'reference_pv'  => (string) ( $_POST['reference_pv'] ?? '' ),
			'note'          => (string) ( $_POST['note'] ?? '' ),
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/affectation?annee=' . $annee );
	}

	public function annulerAffectation() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_AffectationResultat::annuler( $annee, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/affectation?annee=' . $annee );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * À-NOUVEAUX
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * L'écran des à-nouveaux porte sur l'exercice à OUVRIR.
	 *
	 * Le sélecteur d'exercice de l'assistant désigne l'exercice à CLÔTURER :
	 * les à-nouveaux concernent donc, par défaut, le suivant. Confondre les
	 * deux est l'erreur d'écran la plus facile à commettre ici, et la plus
	 * coûteuse — on générerait les à-nouveaux du mauvais exercice.
	 */
	public function anouveaux() {
		$aOuvrir = (int) ( $_GET['ouvrir'] ?? ( $this->annee() + 1 ) );
		$vue     = FKC_ANouveaux::previsualiser( $aOuvrir, empty( $_GET['collectif'] ) );
		FKC_View::render( 'comptabilite::cloture.anouveaux', array(
			'title'    => 'Comptabilité · À-nouveaux ' . $aOuvrir,
			'tab'      => 'cloture',
			'annee'    => $aOuvrir,
			'annees'   => $this->annees(),
			'vue'      => $vue,
			'existent' => FKC_ANouveaux::ecrituresExistantes( $aOuvrir ),
			'ouvert'   => FKC_ClotureProcessus::exerciceOuvert( $aOuvrir ),
			'controles'=> FKC_ClotureChecklist::parCategorie( $aOuvrir, 'ouverture' ),
			'synthese' => FKC_ClotureChecklist::synthese( $aOuvrir, 'ouverture' ),
			'collectif'=> ! empty( $_GET['collectif'] ),
			'rapprochement' => FKC_ANouveaux::existent( $aOuvrir ) ? FKC_ANouveaux::rapprochement( $aOuvrir ) : null,
			// La cause de chaque écart, lue sans reconsigner le rapprochement.
			'explication' => FKC_ANouveaux::existent( $aOuvrir ) && class_exists( 'FKC_ClotureExplication' ) ? FKC_ClotureExplication::ecartsANouveaux( $aOuvrir ) : null,
			'admin'    => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'flash'    => $this->flash(),
		) );
	}

	public function ouvrirExercice() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_Exercice::ouvrir( $annee, ! empty( $_POST['report_an'] ), array(
			'forcer' => ! empty( $_POST['forcer'] ),
			'motif'  => (string) ( $_POST['motif'] ?? '' ),
			'detail_auxiliaire' => empty( $_POST['collectif'] ),
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/anouveaux?ouvrir=' . $annee );
	}

	public function genererAnouveaux() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_ANouveaux::generer( $annee, array(
			'detail_auxiliaire' => empty( $_POST['collectif'] ),
			'motif' => (string) ( $_POST['motif'] ?? '' ),
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/anouveaux?ouvrir=' . $annee );
	}

	public function annulerAnouveaux() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_ANouveaux::annuler( $annee, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/anouveaux?ouvrir=' . $annee );
	}

	/**
	 * AUDIT DES À-NOUVEAUX (1.798.0).
	 *
	 * Un écran, une question : l'ouverture de cet exercice est-elle faite
	 * UNE fois, par la bonne écriture, et reprend-elle exactement la clôture
	 * précédente ? Il liste toutes les sources d'ouverture détectées, la
	 * cohérence de la référence portée par l'exercice, les deux
	 * rapprochements (À-nouveaux seul / ouverture effective) et chaque ligne
	 * d'ouverture avec son compte, son montant, son journal, sa référence,
	 * son exercice et son origine.
	 */
	public function auditAnouveaux() {
		$annees = FKC_SoldeOuverture::exercicesAudites();
		$annee  = (int) ( $_GET['annee'] ?? 0 );
		if ( $annee < 2000 || $annee > 2100 ) { $annee = $annees ? (int) $annees[0] : (int) date( 'Y' ); }
		$synthese = array();
		foreach ( array_slice( $annees, 0, 8 ) as $a ) {
			$d = FKC_SoldeOuverture::diagnostic( $a );
			$synthese[] = array( 'annee' => $a, 'statut' => $d['statut'], 'nb_sources' => count( $d['sources'] ), 'anomalies' => count( $d['anomalies'] ) );
		}
		FKC_View::render( 'comptabilite::cloture.audit_anouveaux', array(
			'title'     => 'Comptabilité · Audit des À-nouveaux ' . $annee,
			'tab'       => 'cloture',
			'annee'     => $annee,
			'annees'    => $annees ?: array( $annee ),
			'diag'      => FKC_SoldeOuverture::diagnostic( $annee ),
			'synthese'  => $synthese,
			'admin'     => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'flash'     => $this->flash(),
		) );
	}

	/**
	 * Recale la référence d'À-nouveaux portée par l'exercice sur l'écriture
	 * réellement trouvée. Ne crée, ne modifie ni ne supprime AUCUNE écriture.
	 */
	public function resynchroniserAnouveaux() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		$avant = FKC_SoldeOuverture::pointeur( $annee );
		if ( 'multiples' === $avant['etat'] ) {
			$this->setFlash( 'Resynchronisation refusée : plusieurs écritures d\'À-nouveaux existent pour ' . $annee
				. '. Levez d\'abord le doublon — la référence ne choisira pas à votre place.', 'err' );
			redirect( 'comptabilite/cloture/audit-anouveaux?annee=' . $annee );
		}
		$ok = FKC_ANouveaux::resynchroniser( $annee );
		$apres = FKC_SoldeOuverture::pointeur( $annee );
		if ( $ok && class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'anouveaux_resynchronises', array(
				'libelle' => 'Référence d\'À-nouveaux resynchronisée : ' . $avant['message'] . ' → ' . $apres['message'],
			) );
		}
		$this->setFlash( $ok ? $apres['message'] : 'Resynchronisation impossible.', $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/audit-anouveaux?annee=' . $annee );
	}

	/**
	 * RÉPARATION GUIDÉE D'UNE OUVERTURE AMBIGUË (1.799.0) : conserver une
	 * origine, contre-passer les autres. Tout le contrôle est dans le moteur
	 * (administrateur, motif, simulation, vérification après écriture).
	 */
	public function reparerOuverture() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_SoldeOuverture::reparer( $annee, (int) ( $_POST['conserver'] ?? -1 ), (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/audit-anouveaux?annee=' . $annee );
	}

	/** Qualifie une écriture : source d'ouverture, ou hors ouverture (1.799.0). */
	public function qualifierOuverture() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_SoldeOuverture::qualifier( (int) ( $_POST['ecriture_id'] ?? 0 ),
			(string) ( $_POST['qualification'] ?? '' ), (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/cloture/audit-anouveaux?annee=' . $annee );
	}

	/**
	 * Les travaux d'inventaire, par domaine.
	 *
	 * Écran distinct de l'assistant, et c'est voulu : l'assistant est classé
	 * par GRAVITÉ et répond à « qu'est-ce qui me bloque ? » ; celui-ci est
	 * classé par DOMAINE DE TRAVAIL et répond à « où vais-je travailler ? ».
	 * Les mêmes faits, deux moments du travail.
	 */
	public function inventaire() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.inventaire', array(
			'title'   => 'Comptabilité · Travaux d\'inventaire ' . $annee,
			'tab'     => 'cloture',
			'annee'   => $annee,
			'annees'  => $this->annees(),
			'etat'    => FKC_Inventaire::etat( $annee ),
			'cloture' => FKC_Cloture::annuelleDe( $annee ),
			'flash'   => $this->flash(),
		) );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * TABLEAU DE PASSAGE FISCAL
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * Du résultat comptable au résultat fiscal.
	 *
	 * L'écran vit dans l'arrêté des comptes et non dans le module Fiscalité,
	 * pour la même raison que les rattachements : les retraitements se
	 * décident pendant la clôture, sur la base d'un résultat comptable arrêté,
	 * et ils déterminent l'impôt que la clôture doit comptabiliser. Les
	 * renvoyer ailleurs reviendrait à couper la chaîne en son milieu.
	 */
	public function fiscal() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.fiscal', array(
			'title'   => 'Comptabilité · Résultat fiscal ' . $annee,
			'tab'     => 'cloture',
			'annee'   => $annee,
			'annees'  => $this->annees(),
			'fisc'    => FKC_ResultatFiscal::tableau( $annee ),
			'natures' => FKC_ResultatFiscal::natures(),
			'conf'    => FKC_ResultatFiscal::confrontation( $annee ),
			'cloture' => FKC_Cloture::annuelleDe( $annee ),
			'admin'   => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'flash'   => $this->flash(),
		) );
	}

	/** Une ligne pour l'assistant : où en est le passage fiscal. */
	protected function resumeFiscal( $annee ) {
		try {
			$t = FKC_ResultatFiscal::tableau( $annee );
		} catch ( \Throwable $e ) { return ''; }
		$s = 'Résultat fiscal : ' . fkc_money( $t['resultat_fiscal'] ) . ' F CFA';
		if ( $t['reintegrations'] || $t['deductions'] ) {
			$s .= ' après ' . fkc_money( $t['reintegrations'] ) . ' de réintégrations et '
				. fkc_money( $t['deductions'] ) . ' de déductions';
		}
		$s .= ', base imposable ' . fkc_money( $t['base_imposable'] ) . ' F CFA, impôt '
			. fkc_money( $t['impot']['du'] ) . ' F CFA.';
		if ( $t['propositions'] ) {
			$s .= ' ' . count( $t['propositions'] ) . ' retraitement(s) proposé(s) et non examiné(s).';
		}
		return $s;
	}

	protected function retourFiscal( $annee ) { redirect( 'comptabilite/cloture/fiscal?annee=' . (int) $annee ); }

	public function retraitementAjouter() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_ResultatFiscal::ajouter( array(
			'exercice'      => $annee,
			'nature'        => (string) ( $_POST['nature'] ?? '' ),
			'libelle'       => (string) ( $_POST['libelle'] ?? '' ),
			'montant'       => $this->montant( $_POST['montant'] ?? 0 ),
			'justification' => (string) ( $_POST['justification'] ?? '' ),
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retourFiscal( $annee );
	}

	public function retraitementAccepter() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_ResultatFiscal::accepter( $annee,
			(string) ( $_POST['source_type'] ?? '' ), (int) ( $_POST['source_id'] ?? 0 ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retourFiscal( $annee );
	}

	public function retraitementRetirer( $id ) {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_ResultatFiscal::retirer( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retourFiscal( $annee );
	}

	public function figerFiscal() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_ResultatFiscal::figer( $annee );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retourFiscal( $annee );
	}

	public function defigerFiscal() {
		$annee = $this->annee();
		list( $ok, $msg ) = FKC_ResultatFiscal::defiger( $annee, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		$this->retourFiscal( $annee );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * RÉGULARISATIONS D'INVENTAIRE
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * Le rattachement des charges et des produits.
	 *
	 * L'écran vit dans l'arrêté des comptes, et non dans la saisie courante :
	 * une facture non parvenue n'est pas une écriture ordinaire qu'on passerait
	 * au fil de l'eau, c'est un geste d'inventaire, daté du dernier jour de
	 * l'exercice, et qui appelle son extourne au premier jour du suivant. Le
	 * séparer de la clôture reviendrait à séparer les deux moitiés d'une même
	 * opération.
	 */
	public function regularisations() {
		$annee = $this->annee();
		FKC_View::render( 'comptabilite::cloture.regularisations', array(
			'title'    => 'Comptabilité · Rattachements ' . $annee,
			'tab'      => 'cloture',
			'annee'    => $annee,
			'annees'   => $this->annees(),
			'natures'  => FKC_Regularisation::natures(),
			'lignes'   => FKC_Regularisation::lister( $annee ),
			'totaux'   => FKC_Regularisation::totaux( $annee ),
			'suggestions' => FKC_Regularisation::suggestions( $annee ),
			'a_extourner' => FKC_Regularisation::aExtourner( $annee + 1 ),
			'cloture'  => FKC_Cloture::annuelleDe( $annee ),
			'fin'      => class_exists( 'FKC_Exercice' ) ? FKC_Exercice::finDe( $annee ) : ( $annee . '-12-31' ),
			'debut_suivant' => class_exists( 'FKC_Exercice' ) ? FKC_Exercice::debutDe( $annee + 1 ) : ( ( $annee + 1 ) . '-01-01' ),
			'admin'    => class_exists( 'FKC_Auth' ) && FKC_Auth::isAdmin(),
			'flash'    => $this->flash(),
		) );
	}

	public function regularisationCreer() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg, $id ) = FKC_Regularisation::creer( array(
			'exercice'       => $annee,
			'nature'         => (string) ( $_POST['nature'] ?? '' ),
			'libelle'        => (string) ( $_POST['libelle'] ?? '' ),
			'tiers'          => (string) ( $_POST['tiers'] ?? '' ),
			'compte_gestion' => (string) ( $_POST['compte_gestion'] ?? '' ),
			'compte_bilan'   => (string) ( $_POST['compte_bilan'] ?? '' ),
			'montant_ht'     => $this->montant( $_POST['montant_ht'] ?? 0 ),
			'montant_tva'    => $this->montant( $_POST['montant_tva'] ?? 0 ),
			'periode_debut'  => (string) ( $_POST['periode_debut'] ?? '' ),
			'periode_fin'    => (string) ( $_POST['periode_fin'] ?? '' ),
			'base_prorata'   => $this->montant( $_POST['base_prorata'] ?? 0 ),
			'justificatif'   => (string) ( $_POST['justificatif'] ?? '' ),
		) );
		// Comptabiliser dans la foulée est le geste normal : préparer sans
		// passer ne sert qu'à découper un travail long, pas à temporiser.
		if ( $ok && $id && ! empty( $_POST['passer'] ) ) {
			list( $ok2, $msg2 ) = FKC_Regularisation::passer( (int) $id );
			$msg .= ' ' . $msg2;
			$ok   = $ok2;
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/regularisations?annee=' . $annee );
	}

	public function regularisationPasser( $id ) {
		$r = FKC_Regularisation::find( $id );
		$annee = $r ? (int) $r['exercice'] : $this->annee();
		list( $ok, $msg ) = FKC_Regularisation::passer( (int) $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/regularisations?annee=' . $annee );
	}

	public function regularisationPasserTout() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $ko, $msgs ) = FKC_Regularisation::passerTout( $annee );
		$msg = $ok . ' rattachement(s) comptabilisé(s)';
		if ( $ko ) { $msg .= ', ' . $ko . ' en échec — ' . implode( ' · ', array_slice( $msgs, 0, 3 ) ); }
		if ( ! $ok && ! $ko ) { $msg = 'Aucun rattachement en attente.'; }
		$this->setFlash( $msg . '.', $ko ? 'err' : 'ok' );
		redirect( 'comptabilite/regularisations?annee=' . $annee );
	}

	public function regularisationAnnuler( $id ) {
		$r = FKC_Regularisation::find( $id );
		$annee = $r ? (int) $r['exercice'] : $this->annee();
		list( $ok, $msg ) = FKC_Regularisation::annuler( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/regularisations?annee=' . $annee );
	}

	/**
	 * Extourne à la demande.
	 *
	 * L'ouverture d'exercice la déclenche déjà. Ce bouton sert aux dossiers
	 * dont l'exercice suivant a été ouvert AVANT que ce module n'existe, ou
	 * dont l'extourne a échoué : sans lui, ils resteraient avec des
	 * rattachements que plus rien ne contre-passerait.
	 */
	public function regularisationExtourner() {
		$annee = (int) ( $_POST['annee'] ?? 0 );
		list( $ok, $msg ) = FKC_Regularisation::extourner( $annee + 1 );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/regularisations?annee=' . $annee );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * OUTILS
	 * ══════════════════════════════════════════════════════════════════════ */

	/** Montant saisi : on accepte l'espace insécable et la virgule décimale. */
	protected function montant( $v ) {
		return (float) str_replace( array( ' ', "\xc2\xa0", ',' ), array( '', '', '.' ), (string) $v );
	}


	protected function annee() {
		$a = (int) ( $_GET['annee'] ?? $_POST['annee'] ?? 0 );
		if ( $a >= 2000 && $a <= 2100 ) { return $a; }
		/*
		 * Par défaut, l'exercice qu'on est en train de clôturer est le
		 * PRÉCÉDENT : on arrête 2025 pendant les premiers mois de 2026. Mais
		 * seulement s'il reste à clôturer — sans quoi l'écran s'ouvrirait
		 * indéfiniment sur un exercice déjà arrêté.
		 */
		$courant = class_exists( 'FKC_Exercice' ) ? (int) FKC_Exercice::courant() : (int) date( 'Y' );
		if ( class_exists( 'FKC_ClotureProcessus' ) && ! FKC_ClotureProcessus::exerciceClos( $courant - 1 )
			&& FKC_ClotureProcessus::exercicePrecedentMouvemente( $courant ) ) {
			return $courant - 1;
		}
		return $courant;
	}

	protected function annees() {
		$ys = class_exists( 'FKC_Exercice' ) ? FKC_Exercice::annees() : array( date( 'Y' ) );
		$ys = array_map( 'intval', (array) $ys );
		$cur = class_exists( 'FKC_Exercice' ) ? (int) FKC_Exercice::courant() : (int) date( 'Y' );
		foreach ( array( $cur - 1, $cur, $cur + 1 ) as $a ) { if ( ! in_array( $a, $ys, true ) ) { $ys[] = $a; } }
		rsort( $ys );
		return $ys;
	}

	protected function retour( $annee ) { redirect( 'comptabilite/cloture?annee=' . (int) $annee ); }
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_clot'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_clot'] ?? null; unset( $_SESSION['__flash_clot'] ); return $m; }
}
