<?php
/**
 * Contrôleur de l'assistant de migration comptable.
 *
 * Écran unique en deux temps : l'utilisateur dépose son fichier CSV et choisit
 * le type d'import → APERÇU (totaux, résultat de période, anomalies, comptes à
 * créer) sans rien écrire ; puis, si l'aperçu est bon, il confirme → EXÉCUTION
 * (les écritures sont enregistrées). Le fichier est retransmis d'un temps à
 * l'autre via un stockage temporaire chiffré en session pour éviter un second
 * upload.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_MigrationController {

	const MAX_MO = 4;

	/** Écran principal. */
	public function index() {
		$this->render();
	}

	/** Étape 1 : aperçu (analyse sans exécution). */
	public function apercu() {
		$type = (string) ( $_POST['type'] ?? 'balance' );
		$opts = $this->options();
		$csv = $this->fichierUploade();
		if ( null === $csv[0] ) { $this->render( array( 'errors' => array( $csv[1] ) ) ); return; }
		$contenu = $csv[0];
		// Conserver le fichier pour l'étape de confirmation (pas de ré-upload).
		$_SESSION['__mig_csv'] = base64_encode( $contenu );
		$_SESSION['__mig_type'] = $type;
		$_SESSION['__mig_opts'] = $opts;
		$resultat = $this->executer( $type, $contenu, $opts, false );
		$this->render( array( 'resultat' => $resultat, 'type' => $type, 'opts' => $opts, 'peut_confirmer' => ! empty( $resultat['ok'] ) ) );
	}

	/** Étape 2 : confirmation (exécution réelle). */
	public function confirmer() {
		$contenu = isset( $_SESSION['__mig_csv'] ) ? base64_decode( (string) $_SESSION['__mig_csv'] ) : '';
		$type = (string) ( $_SESSION['__mig_type'] ?? 'balance' );
		$opts = (array) ( $_SESSION['__mig_opts'] ?? array() );
		if ( '' === $contenu ) {
			$this->render( array( 'errors' => array( 'Session expirée : veuillez recharger votre fichier.' ) ) );
			return;
		}
		if ( ! empty( $_POST['forcer_doublon'] ) ) { $opts['forcer_doublon'] = true; }
		$resultat = $this->executer( $type, $contenu, $opts, true );
		// Purge du fichier temporaire après exécution.
		unset( $_SESSION['__mig_csv'], $_SESSION['__mig_type'], $_SESSION['__mig_opts'] );
		$this->render( array( 'resultat' => $resultat, 'type' => $type, 'opts' => $opts, 'apres_execution' => true ) );
	}

	/* ── Helpers ─────────────────────────────────────────────────────────── */

	/** Aiguille vers la bonne méthode du moteur. */
	protected function executer( $type, $contenu, array $opts, $executer ) {
		$opts['executer'] = $executer;
		switch ( $type ) {
			case 'plan':
				$r = FKC_ComptaMigration::importerPlan( $contenu, $executer );
				$r['_type'] = 'plan';
				return $r;
			case 'ecritures':
				$r = FKC_ComptaMigration::importerEcritures( $contenu, $opts );
				$r['_type'] = 'ecritures';
				return $r;
			case 'balance':
			default:
				$r = FKC_ComptaMigration::importerBalance( $contenu, $opts );
				$r['_type'] = 'balance';
				return $r;
		}
	}

	/** Options de reprise depuis le formulaire. */
	protected function options() {
		$mode = 'complete' === ( $_POST['mode'] ?? 'anouveaux' ) ? 'complete' : 'anouveaux';
		$opts = array(
			'mode' => $mode,
			'date' => $this->dateValide( $_POST['date'] ?? '' ) ?: date( 'Y-m-d' ),
			'creer_comptes' => ! empty( $_POST['creer_comptes'] ),
			'journal' => strtoupper( trim( (string) ( $_POST['journal'] ?? 'OD' ) ) ) ?: 'OD',
		);
		if ( 'complete' === $mode ) {
			$opts['debut_exercice'] = $this->dateValide( $_POST['debut_exercice'] ?? '' ) ?: ( substr( $opts['date'], 0, 4 ) . '-01-01' );
			$cr = preg_replace( '/\D/', '', (string) ( $_POST['compte_resultat'] ?? '130000' ) );
			$opts['compte_resultat'] = $cr ?: '130000';
		}
		return $opts;
	}

	protected function dateValide( $v ) {
		$v = trim( (string) $v );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
	}

	/** Récupère et valide le fichier uploadé. @return array( contenu|null, erreur ) */
	protected function fichierUploade() {
		$f = $_FILES['fichier'] ?? null;
		if ( ! $f || ! is_uploaded_file( $f['tmp_name'] ?? '' ) || UPLOAD_ERR_OK !== ( $f['error'] ?? 1 ) ) {
			return array( null, 'Veuillez sélectionner un fichier CSV à importer.' );
		}
		if ( (int) ( $f['size'] ?? 0 ) > self::MAX_MO * 1024 * 1024 ) {
			return array( null, 'Fichier trop volumineux (max ' . self::MAX_MO . ' Mo).' );
		}
		$raw = file_get_contents( $f['tmp_name'] );
		if ( false === $raw || '' === trim( $raw ) ) { return array( null, 'Le fichier est vide ou illisible.' ); }
		return array( $raw, '' );
	}

	/** Rendu de la vue avec valeurs par défaut. */
	protected function render( array $data = array() ) {
		FKC_View::render( 'comptabilite::migration', array_merge( array(
			'title' => 'Comptabilité · Migration / Reprise', 'tab' => 'migration',
			'resultat' => null, 'errors' => array(), 'type' => 'balance',
			'opts' => array( 'mode' => 'anouveaux', 'date' => date( 'Y-m-d' ), 'journal' => 'OD', 'creer_comptes' => true ),
			'peut_confirmer' => false, 'apres_execution' => false,
		), $data ) );
	}
}
