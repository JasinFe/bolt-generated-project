<?php
/** Plan comptable. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_CompteController {

	public function index() {
		/*
		 * Le plan se synchronise sur le PACK MÉTIER, plus sur l'édition de
		 * licence. L'ancien appel liait le contenu du plan au niveau
		 * d'abonnement : une société en licence « creative » recevait les
		 * comptes de label même si elle exploitait un hôtel, et le pack
		 * « creative » lui-même n'avait aucun jeu de comptes propre. La
		 * licence ouvre des modules ; le métier décide du plan.
		 */
		$added = 0;
		try {
			$g = FKC_GenerateurPlan::generer( null, array(
				'journaux' => false, 'taxes' => false, 'ecritures' => false,
				'cockpits' => false, 'workflows' => false, 'documents' => false,
			) );
			$added = (int) ( $g['etapes']['plan_ohada']['ajoutes'] ?? 0 ) + (int) ( $g['etapes']['plan_metier']['ajoutes'] ?? 0 );
		} catch ( \Throwable $e ) { $added = 0; }
		$cl = isset( $_GET['cl'] ) ? (int) $_GET['cl'] : 0;
		$comptes = FKC_Compte::all();
		if ( $cl >= 1 && $cl <= 9 ) {
			$comptes = array_values( array_filter( $comptes, function ( $c ) use ( $cl ) { return (int) $c['classe'] === $cl; } ) );
		}
		$classement = FKC_PlanAudit::classerPlan();
		FKC_View::render( 'comptabilite::comptes.index', array(
			'title'   => 'Comptabilité · Plan comptable',
			'tab'     => 'comptes',
			'comptes' => $comptes,
			'total'   => (int) FKC_DB::q( 'SELECT COUNT(*) FROM comptes' )->fetchColumn(),
			'cl'      => $cl,
			'edition' => FKC_PlanComptable::edition(),
			'pack'    => class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : 'generique',
			'audit'   => FKC_PlanAudit::analyser(),
			/*
			 * Classification à quatre statuts, calculée UNE fois pour toute la
			 * page : la vue en tire la synthèse en tête et la colonne du tableau.
			 * Une classification par ligne aurait relu le socle transversal et le
			 * référentiel à chaque compte — un millier de fois sur un plan complet.
			 */
			'classement'    => $classement,
			'statuts'       => $classement['comptes'],
			'statutsConnus' => FKC_PlanAudit::statutsConnus(),
			'flash'   => $this->flash() ?: ( $added > 0 ? $added . ' compte(s) ajouté(s) au plan du métier actif.' : null ),
		) );
	}

	/** Export CSV du plan comptable (filtre de classe optionnel). */
	public function export() {
		try { FKC_PlanComptable::sync(); } catch ( \Throwable $e ) {}
		$cl = isset( $_GET['cl'] ) ? (int) $_GET['cl'] : 0;
		$rows = array( array( 'numero', 'libelle', 'classe', 'classe_libelle', 'nature', 'actif' ) );
		$classes = FKC_PlanComptable::classes();
		foreach ( FKC_Compte::all() as $c ) {
			if ( $cl >= 1 && $cl <= 9 && (int) $c['classe'] !== $cl ) { continue; }
			$rows[] = array(
				$c['numero'], $c['libelle'], (int) $c['classe'],
				$classes[ (int) $c['classe'] ] ?? '',
				FKC_PlanComptable::nature( $c['numero'] ),
				! empty( $c['actif'] ) ? 1 : 0,
			);
		}
		$suffix = ( $cl >= 1 && $cl <= 9 ) ? '-classe-' . $cl : '';
		fkc_csv( 'plan-comptable' . $suffix . '-' . date( 'Ymd' ) . '.csv', $rows );
	}

	public function create() {
		FKC_View::render( 'comptabilite::comptes.form', array(
			'title'  => 'Nouveau compte', 'tab' => 'comptes',
			'compte' => null, 'errors' => array(),
		) );
	}

	public function store() {
		$numero  = trim( (string) ( $_POST['numero'] ?? '' ) );
		$libelle = trim( (string) ( $_POST['libelle'] ?? '' ) );
		$type    = (string) ( $_POST['type'] ?? 'detail' );
		$errs = array();
		if ( ! preg_match( '/^[1-9][0-9]{0,5}$/', $numero ) ) { $errs[] = 'Numéro SYSCOHADA invalide : 1 à 6 chiffres, classe 1 à 9.'; }
		if ( '' === $libelle ) { $errs[] = 'Le libellé est requis.'; }
		if ( ! $errs && FKC_Compte::byNumero( $numero ) ) { $errs[] = 'Ce numéro de compte existe déjà.'; }
		/*
		 * Un compte librement créé doit tout de même se rattacher au
		 * référentiel. Sans cela, l'utilisateur peut ouvrir « 950000 — divers »
		 * en toute bonne foi : le montant n'apparaîtra dans aucune rubrique de
		 * la liasse, et l'écart ne se découvrira qu'au bilan.
		 */
		if ( ! $errs ) {
			$n6 = FKC_PlanSyscohada::normaliser( $numero );
			if ( ! FKC_PlanSyscohada::estOfficiel( $n6 ) && ! FKC_PlanSyscohada::parentOfficiel( $n6 ) ) {
				$errs[] = 'Ce numéro ne se rattache à aucun compte SYSCOHADA : il ne remonterait dans aucun état financier. '
					. 'Ouvrez plutôt une subdivision sous un compte existant (par exemple 706150 sous 706 « Services vendus »).';
			}
		}
		if ( $errs ) {
			$_SESSION['__old'] = compact( 'numero', 'libelle' );
			return FKC_View::render( 'comptabilite::comptes.form', array(
				'title' => 'Nouveau compte', 'tab' => 'comptes', 'compte' => null, 'errors' => $errs,
			) );
		}
		FKC_Compte::create( $numero, $libelle, $type );
		unset( $_SESSION['__old'] );
		$this->setFlash( "Compte {$numero} créé." );
		redirect( 'comptabilite/comptes' );
	}

	public function edit( $id ) {
		$compte = FKC_Compte::find( $id );
		if ( ! $compte ) { redirect( 'comptabilite/comptes' ); }
		FKC_View::render( 'comptabilite::comptes.form', array(
			'title' => 'Modifier le compte', 'tab' => 'comptes', 'compte' => $compte, 'errors' => array(),
		) );
	}

	public function update( $id ) {
		$compte = FKC_Compte::find( $id );
		if ( ! $compte ) { redirect( 'comptabilite/comptes' ); }
		$libelle = trim( (string) ( $_POST['libelle'] ?? '' ) );
		$type    = (string) ( $_POST['type'] ?? 'detail' );
		/*
		 * Un compte du référentiel OHADA ne se renomme pas.
		 *
		 * Les états DGI, la liasse et la balance agrègent par racine de
		 * compte : rebaptiser 627 « Frais bancaires » ne casse rien de visible
		 * le jour même, mais fait tomber la publicité dans la mauvaise
		 * rubrique de la liasse — et l'on ne s'en aperçoit qu'au contrôle.
		 * L'utilisateur garde toute liberté sur SES subdivisions.
		 */
		if ( ! empty( $compte['verrouille'] ) || 'ohada' === ( $compte['origine'] ?? '' ) ) {
			return FKC_View::render( 'comptabilite::comptes.form', array(
				'title' => 'Modifier le compte', 'tab' => 'comptes', 'compte' => $compte,
				'errors' => array(
					'Le compte ' . $compte['numero'] . ' appartient au référentiel SYSCOHADA : son intitulé réglementaire '
					. 'n\'est pas modifiable. Pour préciser un usage, créez une subdivision sous ce compte '
					. '(par exemple ' . substr( (string) $compte['numero'], 0, 3 ) . '100).',
				),
			) );
		}
		if ( '' === $libelle ) {
			return FKC_View::render( 'comptabilite::comptes.form', array(
				'title' => 'Modifier le compte', 'tab' => 'comptes', 'compte' => $compte, 'errors' => array( 'Le libellé est requis.' ),
			) );
		}
		FKC_Compte::update( $id, $libelle, $type );
		$this->setFlash( 'Compte mis à jour.' );
		redirect( 'comptabilite/comptes' );
	}

	public function destroy( $id ) {
		list( , $msg ) = FKC_Compte::delete( $id );
		$this->setFlash( $msg );
		redirect( 'comptabilite/comptes' );
	}

	/* ── Générateur de dossier comptable ─────────────────────────────────── */

	/** Écran du générateur : ce que le métier actif poserait, et l'état du plan. */
	public function generateur() {
		$pack = class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : 'generique';
		FKC_View::render( 'comptabilite::comptes.generateur', array(
			'title'   => 'Comptabilité · Générateur de plan',
			'tab'     => 'comptes',
			'pack'    => $pack,
			'packLabel' => class_exists( 'FKC_Packs' ) ? ( FKC_Packs::get( $pack )['label'] ?? $pack ) : $pack,
			'axes'    => FKC_PlanMetier::axesPourPack( $pack ),
			'journaux' => array_merge( FKC_GenerateurPlan::journauxSocle(), FKC_PlanMetier::journauxPourPack( $pack ) ),
			'metier'  => FKC_PlanMetier::pourPack( $pack ),
			'socle'   => FKC_PlanMetier::socleCommun(),
			'nbOfficiels' => FKC_PlanSyscohada::compte(),
			'ecritures' => class_exists( 'FKC_ModelesEcritures' ) ? FKC_ModelesEcritures::pourPack( $pack ) : array(),
			'audit'   => FKC_PlanAudit::analyser(),
			/*
			 * Audit du plan aux DEUX niveaux : numérique (un numéro, plusieurs
			 * sens) et sémantique (plusieurs numéros, un même sens). Le second ne
			 * se déduit pas du premier — il voit ce que le premier ne peut pas
			 * voir, à savoir un plan qui enfle de comptes faisant double emploi.
			 */
			'auditPlan' => class_exists( 'FKC_PlanCanonique' ) ? FKC_PlanCanonique::auditComplet() : array(),
			'derniere' => FKC_GenerateurPlan::derniereGeneration(),
			'flash'   => $this->flash(),
		) );
	}

	/** Lance la génération complète du dossier comptable. */
	public function generer() {
		$pack = class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : 'generique';
		$r = FKC_GenerateurPlan::generer( $pack );
		$bouts = array();
		$e = $r['etapes'];
		if ( ! empty( $e['plan_ohada']['ajoutes'] ) )  { $bouts[] = $e['plan_ohada']['ajoutes'] . ' compte(s) OHADA'; }
		if ( ! empty( $e['plan_metier']['ajoutes'] ) ) { $bouts[] = $e['plan_metier']['ajoutes'] . ' subdivision(s) métier'; }
		if ( ! empty( $e['journaux']['ajoutes'] ) )    { $bouts[] = $e['journaux']['ajoutes'] . ' journal(aux)'; }
		if ( ! empty( $e['axes']['ajoutes'] ) )        { $bouts[] = $e['axes']['ajoutes'] . ' axe(s) analytique(s)'; }
		if ( ! empty( $e['taxes']['poses'] ) )         { $bouts[] = $e['taxes']['poses'] . ' paramètre(s) fiscal(aux)'; }
		if ( ! empty( $e['workflows']['poses'] ) )     { $bouts[] = $e['workflows']['poses'] . ' workflow(s)'; }

		$msg = $bouts
			? 'Dossier généré : ' . implode( ', ', $bouts ) . '. Rien d\'existant n\'a été modifié.'
			: 'Dossier déjà complet pour ce métier — aucune addition nécessaire.';
		if ( ! empty( $r['refus'] ) ) {
			$msg .= ' ' . count( $r['refus'] ) . ' subdivision(s) refusée(s) faute de rattachement SYSCOHADA (voir l\'écran).';
		}
		$this->setFlash( $msg );
		redirect( 'comptabilite/plan/generateur' );
	}

	/** Désactive un compte divergent vierge au profit de son numéro conforme. */
	/**
	 * Bascule assistée d'un compte non conforme MOUVEMENTÉ.
	 *
	 * Passe l'écriture de virement puis désactive le compte d'origine. La
	 * décision reste humaine : cette action n'est atteinte que depuis un bouton
	 * qui a affiché le sens, le montant et la date de l'écriture avant de la
	 * proposer. Le modèle refuse de lui-même une période clôturée et n'a aucun
	 * chemin qui supprime physiquement un compte.
	 */
	/* ── Purge du plan comptable ────────────────────────────────────────── */

	public function purge() {
		FKC_View::render( 'comptabilite::comptes.purge', array(
			'title' => 'Comptabilité · Purge du plan comptable', 'tab' => 'comptes',
			'analyse'  => FKC_PlanPurge::analyser(),
			'verdicts' => FKC_PlanPurge::verdicts(),
			'motifs'   => FKC_PlanPurge::motifs(),
			/*
			 * Simulation systématique à l'affichage : l'écran montre ce qui
			 * SERAIT supprimé avant que quiconque clique. Sur une action
			 * irréversible, voir la liste nominative vaut tous les avertissements.
			 */
			'simulation' => FKC_PlanPurge::purger( true ),
			'flash' => $this->flash(),
		) );
	}

	/**
	 * Supprime définitivement. Le mot « SUPPRIMER » doit être saisi : un
	 * bouton seul, sur une action irréversible qui touche le plan comptable,
	 * se clique trop facilement.
	 */
	public function purgeExecuter() {
		$confirme = strtoupper( trim( (string) ( $_POST['confirmation'] ?? '' ) ) );
		if ( 'SUPPRIMER' !== $confirme ) {
			$this->setFlash( "\xE2\x9A\xA0\xEF\xB8\x8F Purge annulée : saisissez SUPPRIMER pour confirmer." );
			redirect( 'comptabilite/plan/purge' );
		}
		$r = FKC_PlanPurge::purger( false );
		$this->setFlash( $r['message'] );
		redirect( 'comptabilite/plan/purge' );
	}

	public function purgeDesactiver() {
		list( $n, $msg ) = FKC_PlanPurge::desactiverSoldes();
		$this->setFlash( $n > 0 ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'comptabilite/plan/purge' );
	}

	public function virer() {
		$numero = (string) ( $_POST['numero'] ?? '' );
		$date   = trim( (string) ( $_POST['date'] ?? '' ) ) ?: null;
		list( , $msg ) = FKC_PlanAudit::executerVirement( $numero, $date );
		$this->setFlash( $msg );
		redirect( 'comptabilite/plan/generateur' );
	}

	public function corriger() {
		$numero = (string) ( $_POST['numero'] ?? '' );
		/*
		 * TOUT-EN-UN OU UN PAR UN — même route, même garde-fou.
		 *
		 * Le formulaire de masse ne poste pas de numéro. Le traitement en lot
		 * réutilise exactement corrigerSiVierge() compte par compte : il n'y a
		 * donc aucun chemin par lequel un compte mouvementé serait désactivé,
		 * pas même en cochant tout.
		 */
		if ( '' === $numero && ! empty( $_POST['tout'] ) ) {
			$r = FKC_PlanAudit::corrigerTout();
			$this->setFlash( FKC_PlanAudit::resumerCorrection( $r ) );
			return redirect( 'comptabilite/plan/generateur' );
		}
		list( , $msg ) = FKC_PlanAudit::corrigerSiVierge( $numero );
		$this->setFlash( $msg );
		redirect( 'comptabilite/plan/generateur' );
	}

	protected function setFlash( $m ) { $_SESSION['__flash_compte'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_compte'] ?? null; unset( $_SESSION['__flash_compte'] ); return $m; }
}
