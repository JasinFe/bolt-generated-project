<?php
/**
 * Avoirs fournisseurs.
 *
 * Sans avoir, un retour de marchandise laisse une dette qui ne s'éteint jamais :
 * le solde 401 ne se lettre pas, et le règlement porte sur un montant qui ne
 * correspond à aucune pièce.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_AvoirFournisseurController {

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_ach'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_ach'] ?? null; unset( $_SESSION['__flash_ach'] ); return $m; }

	public function index() {
		$frn = isset( $_GET['fournisseur'] ) ? (int) $_GET['fournisseur'] : null;
		FKC_View::render( 'comptabilite::achats.avoirs', array(
			'title'        => 'Achats · Avoirs fournisseurs',
			'tab'          => 'avoirs',
			'avoirs'       => FKC_AvoirFournisseur::all( $frn ),
			'natures'      => FKC_AvoirFournisseur::natures(),
			'fournisseurs' => FKC_Fournisseur::all(),
			'taux'         => FKC_FactureFournisseur::tauxTva(),
			'filtre'       => $frn,
			'flash'        => $this->flash(),
		) );
	}

	public function store() {
		list( $ok, $msg ) = FKC_AvoirFournisseur::create( array(
			'fournisseur_id'      => (int) ( $_POST['fournisseur_id'] ?? 0 ),
			'nature'              => (string) ( $_POST['nature'] ?? '' ),
			'date_avoir'          => (string) ( $_POST['date_avoir'] ?? '' ),
			'reference'           => (string) ( $_POST['reference'] ?? '' ),
			'montant_ht'          => (float) ( $_POST['montant_ht'] ?? 0 ),
			'taux_tva'            => (float) ( $_POST['taux_tva'] ?? 18 ),
			'compte_contrepartie' => (string) ( $_POST['compte_contrepartie'] ?? '' ),
			'motif'               => (string) ( $_POST['motif'] ?? '' ),
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/avoirs' );
	}
}
