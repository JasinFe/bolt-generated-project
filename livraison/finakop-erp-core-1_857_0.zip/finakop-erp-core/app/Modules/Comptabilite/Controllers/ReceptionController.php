<?php
/**
 * Bons de réception.
 *
 * POURQUOI CET ÉCRAN MANQUAIT
 *
 * Les réceptions existaient, portaient leur dette en compte 408 et alimentaient
 * la facturation — mais aucune vue ne les montrait. Or c'est là que se loge un
 * engagement particulier : de la marchandise reçue, entrée au bilan, dont la
 * facture n'est pas arrivée. Ce suspens n'apparaissait qu'en creux dans la
 * balance, sur un compte collectif, sans qu'on puisse dire de quelles
 * livraisons il provenait.
 *
 * Plus grave : une réception SANS FOURNISSEUR identifié génère une dette que
 * rien ne peut apurer — aucun règlement ne sait à qui l'imputer. L'écran les
 * met en tête, avec le moyen de leur attribuer un fournisseur.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ReceptionController {

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_ach'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_ach'] ?? null; unset( $_SESSION['__flash_ach'] ); return $m; }

	public function index() {
		$frn = isset( $_GET['fournisseur'] ) ? (int) $_GET['fournisseur'] : null;

		/*
		 * Deux listes distinctes, et c'est délibéré : les réceptions sans
		 * fournisseur appellent une action immédiate, les autres seulement une
		 * lecture. Les mélanger dans un tableau trié par date noierait
		 * l'urgence dans l'historique.
		 */
		FKC_View::render( 'comptabilite::achats.receptions', array(
			'title'        => 'Achats · Bons de réception',
			'tab'          => 'receptions',
			'orphelines'   => FKC_AchatReception::sansFournisseur(),
			'attente'      => FKC_AchatReception::enAttente( $frn ),
			'suspens'      => FKC_AchatReception::suspens(),
			'fournisseurs' => FKC_Fournisseur::all(),
			'filtre'       => $frn,
			'flash'        => $this->flash(),
		) );
	}

	/** Attribue un fournisseur à une réception qui n'en avait pas. */
	public function attribuer( $id ) {
		list( $ok, $msg ) = FKC_AchatReception::attribuer(
			(int) $id, (int) ( $_POST['fournisseur_id'] ?? 0 )
		);
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/achats/receptions' );
	}
}
