<?php
/** Trésorerie : caisse, banque, mobile money, mouvements, rapprochement. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_TresorerieController {

	public function index() {
		FKC_View::render( 'comptabilite::tresorerie.index', array(
			'title' => 'Comptabilité · Trésorerie', 'tab' => 'tresorerie',
			'comptes' => FKC_Tresorerie::comptes(), 'soldes' => FKC_Tresorerie::soldes(),
			'total' => FKC_Tresorerie::totalDisponible(),
			'mouvements' => FKC_Reglement::all( null, 25 ),
			'derniersReglements' => FKC_DB::q( "SELECT * FROM reglements WHERE tiers_type IN ('client','fournisseur') ORDER BY date_reglement DESC, id DESC LIMIT 15" )->fetchAll(),
			'types' => FKC_Tresorerie::types(), 'modes' => FKC_Reglement::modes(),
			// Comptes mouvementés mais jamais déclarés : leurs soldes étaient
			// absents du total et du cockpit, sans aucun signe à l'écran.
			'nonDeclares' => FKC_Tresorerie::nonDeclares(),
			'flash' => $this->flash(),
		) );
	}

	/** Déclare d'un geste les comptes de trésorerie mouvementés qui manquent. */
	public function declarerManquants() {
		list( $n, $msg ) = FKC_Tresorerie::declarerManquants();
		$this->setFlash( $msg, $n > 0 ? 'ok' : 'err' );
		redirect( 'comptabilite/tresorerie' );
	}

	public function storeCompte() {
		$id = FKC_Tresorerie::create( $_POST );
		$this->setFlash( $id ? 'Compte de trésorerie ajouté.' : 'Compte SYSCOHADA introuvable.', $id ? 'ok' : 'err' );
		redirect( 'comptabilite/tresorerie' );
	}

	public function mouvementForm() {
		$sens = in_array( $_GET['sens'] ?? '', array( 'encaissement', 'decaissement', 'virement' ), true ) ? ( $_GET['sens'] ?? '' ) : 'encaissement';
		/*
		 * REPRISE D'UN MOUVEMENT (1.754.0) — `?copie={id}`.
		 *
		 * Une écriture partie au journal ne se modifie pas : corriger, c'est
		 * annuler puis ressaisir. Ressaisir de mémoire, en revanche, est le
		 * meilleur moyen de se tromper une seconde fois : le formulaire revient
		 * donc prérempli avec le mouvement d'origine, détail compris.
		 */
		$copie = null;
		if ( ! empty( $_GET['copie'] ) ) {
			$copie = FKC_DB::q( 'SELECT * FROM reglements WHERE id=?', array( (int) $_GET['copie'] ) )->fetch() ?: null;
			if ( $copie ) {
				$copie['detail'] = FKC_ReglementDetail::pour( (int) $copie['id'] );
				$sens = ( 'paiement' === $copie['sens'] ) ? 'decaissement' : (string) $copie['sens'];
			}
		}
		// Saisie refusée : elle est réaffichée telle quelle plutôt que perdue.
		$saisie = $_SESSION['__tr_saisie'] ?? null; unset( $_SESSION['__tr_saisie'] );
		FKC_View::render( 'comptabilite::tresorerie.mouvement', array(
			'title' => 'Trésorerie · Mouvement', 'tab' => 'tresorerie', 'sens' => $sens,
			'comptes' => FKC_Tresorerie::comptes( true ),
			'plan' => FKC_Compte::all(), 'modes' => FKC_Reglement::modes(),
			'copie' => $copie, 'saisie' => is_array( $saisie ) ? $saisie : null,
			'flash' => $this->flash(),
			// Analytique : mêmes aides et mêmes conditions d'affichage que
			// l'écran d'achat, pour que les deux se conduisent pareil.
			'divisions' => $this->divisions(), 'showDivision' => $this->showDivision(),
			'axes' => $this->axes(), 'valeursMap' => $this->valeursMap(), 'showAxes' => $this->showAxes(),
			'errors' => array(),
		) );
	}

	/* ── Aides analytiques (mêmes résolutions que FKC_AchatController) ──── */

	protected function divisions() {
		if ( ! class_exists( 'FKC_Division' ) ) { return array(); }
		try { return FKC_Division::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	protected function axes() {
		if ( ! class_exists( 'FKC_Axe' ) ) { return array(); }
		try { return FKC_Axe::all( true ); } catch ( \Throwable $e ) { return array(); }
	}
	protected function valeursMap() {
		$map = array();
		if ( ! class_exists( 'FKC_Valeur' ) ) { return $map; }
		foreach ( $this->axes() as $a ) {
			$opts = array();
			try {
				foreach ( FKC_Valeur::byAxe( (int) $a['id'], true ) as $v ) {
					$opts[] = array( 'id' => (int) $v['id'], 't' => $v['code'] . ' · ' . $v['libelle'] );
				}
			} catch ( \Throwable $e ) {}
			$map[ (int) $a['id'] ] = $opts;
		}
		return $map;
	}
	/** Le module analytique est-il vendu à cette société ? */
	protected function moduleAnalytique() {
		if ( ! class_exists( 'FKC_License' ) ) { return false; }
		try { $lic = FKC_License::resolve(); } catch ( \Throwable $e ) { return false; }
		return in_array( 'analytique', $lic['modules'] ?? array(), true );
	}
	protected function showDivision() { return $this->moduleAnalytique() && count( $this->divisions() ) > 0; }
	protected function showAxes() { return $this->moduleAnalytique() && count( $this->axes() ) > 0; }

	public function store() {
		$sens = $_POST['sens'] ?? 'encaissement';
		$data = array(
			'sens'           => 'decaissement' === $sens ? 'paiement' : $sens,
			'tiers_type'     => 'autre',
			'tresorerie_id'  => (int) ( $_POST['tresorerie_id'] ?? 0 ),
			'tresorerie_dest_id' => (int) ( $_POST['tresorerie_dest_id'] ?? 0 ),
			'date_reglement' => $_POST['date_reglement'] ?? date( 'Y-m-d' ),
			'montant'        => $_POST['montant'] ?? 0,
			'mode'           => $_POST['mode'] ?? null,
			'reference'      => $_POST['reference'] ?? null,
			'libelle'        => $_POST['libelle'] ?? null,
			'contrepartie_compte_id' => (int) ( $_POST['contrepartie_compte_id'] ?? 0 ),
			// Imputation analytique du mouvement : portée par les lignes de
			// contrepartie, jamais par la ligne de trésorerie.
			'division_id'    => (int) ( $_POST['division_id'] ?? 0 ),
			'axe_id'         => (int) ( $_POST['axe_id'] ?? 0 ),
			'valeur_id'      => (int) ( $_POST['valeur_id'] ?? 0 ),
		);
		$data['detail'] = isset( $_POST['detail'] ) && is_array( $_POST['detail'] ) ? $_POST['detail'] : array();
		list( $ok, $msg, $rid ) = FKC_Reglement::create( $data );
		if ( $ok && $rid ) { $msg .= $this->joindrePieces( (int) $rid, $data ); }
		if ( ! $ok ) {
			// La ressaisie complète d'un détail de dix lignes après un simple
			// refus de contrepartie est une punition, pas un message d'erreur.
			$_SESSION['__tr_saisie'] = $_POST;
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/tresorerie' : 'comptabilite/tresorerie/mouvement?sens=' . $sens );
	}

	/**
	 * JUSTIFICATIFS DU MOUVEMENT (1.754.0).
	 *
	 * Le reçu Wave, l'avis de virement ou le bordereau de versement se joignent
	 * ici comme ils se joignent déjà à un encaissement client depuis la 1.752.0 :
	 * même catégorie GED, même type de lien, donc même endroit où les retrouver
	 * au rapprochement ou au contrôle.
	 *
	 * L'échec d'une pièce n'annule jamais le mouvement — l'argent est entré ou
	 * sorti — mais il est DIT, et nommément.
	 */
	protected function joindrePieces( $rid, array $data ) {
		if ( ! class_exists( 'FKC_GedDocument' ) || empty( $_FILES['pieces'] ) ) { return ''; }
		$f = $_FILES['pieces'];
		if ( ! isset( $f['name'] ) ) { return ''; }
		$noms = is_array( $f['name'] ) ? $f['name'] : array( $f['name'] );
		$joints = 0; $echecs = array();
		foreach ( array_keys( $noms ) as $i ) {
			$file = is_array( $f['name'] )
				? array( 'name' => $f['name'][ $i ], 'type' => $f['type'][ $i ], 'tmp_name' => $f['tmp_name'][ $i ], 'error' => $f['error'][ $i ], 'size' => $f['size'][ $i ] )
				: $f;
			if ( UPLOAD_ERR_NO_FILE === ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) { continue; }
			$titre = trim( (string) ( $_POST['piece_titre'] ?? '' ) );
			list( $pok, $pmsg ) = FKC_GedDocument::add( array(
				'titre'      => $titre ?: ( 'Justificatif mouvement — ' . ( $data['date_reglement'] ?? date( 'Y-m-d' ) ) ),
				'categorie'  => 'Justificatifs de règlement',
				'lien_type'  => 'reglement',
				'lien_id'    => (int) $rid,
				'lien_label' => trim( (string) ( $data['libelle'] ?? '' ) ) ?: ( fkc_money( $data['montant'] ?? 0 ) . ' F' ),
				'note'       => trim( (string) ( $data['reference'] ?? '' ) ) ?: null,
			), $file );
			if ( $pok ) { $joints++; } else { $echecs[] = $file['name'] . ' — ' . $pmsg; }
		}
		$out = '';
		if ( $joints ) { $out .= ' ' . $joints . ' justificatif' . ( $joints > 1 ? 's joints' : ' joint' ) . '.'; }
		if ( $echecs ) { $out .= ' ⚠️ Le mouvement est enregistré, mais ' . implode( ' ; ', $echecs ) . '.'; }
		return $out;
	}

	/**
	 * CORRIGER UN MOUVEMENT (1.754.0) : annuler, puis rouvrir la saisie.
	 *
	 * Le moteur savait annuler depuis la 1.745.0, mais l'écran de trésorerie
	 * n'offrait ce geste que pour les règlements de clients et de fournisseurs :
	 * un encaissement libre saisi de travers n'avait AUCUNE issue à l'écran.
	 */
	public function corrigerReglement( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM reglements WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { $this->setFlash( 'Mouvement introuvable.', 'err' ); redirect( 'comptabilite/tresorerie' ); }
		$sens = ( 'paiement' === $r['sens'] ) ? 'decaissement' : (string) $r['sens'];
		if ( FKC_Reglement::estAnnule( $r ) ) {
			// Déjà annulé : rien à contre-passer, on rouvre simplement la saisie.
			redirect( 'comptabilite/tresorerie/mouvement?sens=' . $sens . '&copie=' . (int) $id );
		}
		$motif = trim( (string) ( $_POST['motif'] ?? '' ) ) ?: 'Correction de saisie';
		list( $ok, $msg ) = FKC_Reglement::annuler( (int) $id, $motif );
		if ( ! $ok ) { $this->setFlash( $msg, 'err' ); redirect( 'comptabilite/tresorerie' ); }
		$this->setFlash( $msg . ' Reprenez la saisie ci-dessous : les champs sont préremplis.', 'ok' );
		redirect( 'comptabilite/tresorerie/mouvement?sens=' . $sens . '&copie=' . (int) $id );
	}

	public function rapprochements() {
		$rows = array();
		foreach ( FKC_Tresorerie::comptes() as $t ) {
			/*
			 * L'ÉCART TOTAL NE SUFFIT PAS (1.676.0). Il vit et se résorbe :
			 * un chèque met quelques jours à être encaissé. Ce qui doit
			 * alerter, c'est la PART QUI NE BOUGE PLUS — « 800 000 en
			 * attente, dont 200 000 depuis plus de deux mois » est une
			 * phrase actionnable là où un seul chiffre ne l'est pas.
			 */
			$rows[] = array(
				'compte' => $t,
				'solde' => FKC_Tresorerie::solde( $t['compte_id'] ),
				'pointe' => FKC_Reglement::soldePointe( $t['id'] ),
				'detail' => FKC_Reglement::ecartRapprochement( (int) $t['id'], 60 ),
			);
		}
		FKC_View::render( 'comptabilite::tresorerie.rapprochements', array(
			'title' => 'Trésorerie · Rapprochements bancaires', 'tab' => 'tresorerie',
			'lignes' => $rows,
			'dormants' => FKC_Reglement::nonPointesAnciens( 60, 30 ),
			'flash' => $this->flash(),
		) );
	}

	public function rapprochement( $id ) {
		$t = FKC_Tresorerie::find( $id );
		if ( ! $t ) { redirect( 'comptabilite/tresorerie' ); }
		FKC_View::render( 'comptabilite::tresorerie.rapprochement', array(
			'title' => 'Rapprochement · ' . $t['libelle'], 'tab' => 'tresorerie',
			'compte' => $t, 'mouvements' => FKC_Reglement::all( $id, 300 ),
			'solde' => FKC_Tresorerie::solde( $t['compte_id'] ),
			'soldePointe' => FKC_Reglement::soldePointe( $id ),
			'flash' => $this->flash(),
		) );
	}
	public function pointe( $id ) {
		FKC_Reglement::togglePointe( (int) $id );
		$back = (int) ( $_POST['tresorerie_id'] ?? 0 );
		redirect( 'comptabilite/tresorerie/rapprochement/' . $back );
	}

	/**
	 * Annule un règlement (1.745.0). Le retour est borné aux écrans de la
	 * comptabilité : jamais une adresse fournie telle quelle.
	 */
	public function annulerReglement( $id ) {
		list( $ok, $msg ) = FKC_Reglement::annuler( (int) $id, (string) ( $_POST['motif'] ?? '' ), $_POST['date'] ?? null );
		$retour = (string) ( $_POST['retour'] ?? '' );
		if ( ! preg_match( '~^comptabilite/[a-z0-9/_-]+$~', $retour ) ) { $retour = 'comptabilite/tresorerie'; }
		$flash = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		// Chaque écran lit sa propre clé de message : on n'écrit que celle de
		// l'écran de retour, sinon le message ressurgirait ailleurs plus tard.
		$cle = '__flash_tr';
		if ( 0 === strpos( $retour, 'comptabilite/clients/' ) ) { $cle = '__flash_cc'; }
		elseif ( 0 === strpos( $retour, 'comptabilite/fournisseurs/' ) ) { $cle = '__flash_fr'; }
		$_SESSION[ $cle ] = $flash;
		redirect( $retour );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_tr'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_tr'] ?? null; unset( $_SESSION['__flash_tr'] ); return $m; }
}
