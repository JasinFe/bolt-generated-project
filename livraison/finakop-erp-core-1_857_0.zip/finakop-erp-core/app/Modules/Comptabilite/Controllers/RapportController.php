<?php
/** Balance et grand livre. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RapportController {

	public function balance() {
		if ( class_exists( 'FKC_Facture' ) ) { FKC_Facture::comptabiliserAvoirsEnAttente(); }
		$du = $_GET['du'] ?? null; $au = $_GET['au'] ?? null;
		$lignes = FKC_Rapport::balance( $du ?: null, $au ?: null );
		$tot = array( 'ouv_debit'=>0,'ouv_credit'=>0,'debit'=>0,'credit'=>0,'sd'=>0,'sc'=>0 );
		foreach ( $lignes as $l ) {
			$tot['ouv_debit']+=(float)$l['ouv_debit']; $tot['ouv_credit']+=(float)$l['ouv_credit'];
			$tot['debit']+=(float)$l['debit']; $tot['credit']+=(float)$l['credit'];
			$tot['sd']+=(float)$l['solde_debiteur']; $tot['sc']+=(float)$l['solde_crediteur'];
		}
		FKC_View::render( 'comptabilite::rapports.balance', array(
			'title' => 'Comptabilité · Balance', 'tab' => 'balance',
			'lignes' => $lignes, 'tot' => $tot, 'du' => $du, 'au' => $au,
			'contexte' => FKC_Rapport::contexteOuverture(),
		) );
	}

	public function grandLivre() {
		if ( class_exists( 'FKC_Facture' ) ) { FKC_Facture::comptabiliserAvoirsEnAttente(); }
		$f = $this->glFilters();
		$data = FKC_Rapport::grandLivreGeneral( $f );
		FKC_View::render( 'comptabilite::rapports.grand_livre', array(
			'title' => 'Comptabilité · Grand livre général', 'tab' => 'grand-livre',
			'comptes'  => $data['comptes'], 'totaux' => $data['totaux'], 'nb' => $data['nb_comptes'],
			'liste'    => FKC_Compte::all(),
			'journaux' => class_exists( 'FKC_Journal' ) ? FKC_Journal::all() : array(),
			'f' => $f, 'contexte' => $data['contexte'] ?? null, 'duEff' => $data['du'] ?? $f['du'],
		) );
	}

	/** Filtres normalisés du grand livre général. */
	protected function glFilters() {
		return array(
			'du'        => trim( (string) ( $_GET['du'] ?? '' ) ) ?: null,
			'au'        => trim( (string) ( $_GET['au'] ?? '' ) ) ?: null,
			'compte_de' => trim( (string) ( $_GET['compte_de'] ?? '' ) ) ?: null,
			'compte_a'  => trim( (string) ( $_GET['compte_a'] ?? '' ) ) ?: null,
			'journal'   => trim( (string) ( $_GET['journal'] ?? '' ) ) ?: null,
			'compte_id' => (int) ( $_GET['compte_id'] ?? 0 ) ?: null,
			'q'         => trim( (string) ( $_GET['q'] ?? '' ) ) ?: null,
			'non_zero'  => empty( $_GET['all'] ),
			// Détail d'un poste (1.833.0) : préfixes de comptes « 601,6031 »
			// et exclusion de l'écriture de détermination du résultat.
			'prefixes'  => array_values( array_filter( array_map( function ( $x ) { return preg_replace( '/\D/', '', $x ); },
				explode( ',', (string) ( $_GET['prefixes'] ?? '' ) ) ), 'strlen' ) ),
			'gestion'   => ! empty( $_GET['gestion'] ),
		);
	}

	public function grandLivreCsv() {
		$f = $this->glFilters();
		$data = FKC_Rapport::grandLivreGeneral( $f );
		$rows = array( array( 'Grand livre general' ) );
		if ( ! empty( $data['contexte'] ) && array_key_exists( 'fiable', $data['contexte'] ) && ! $data['contexte']['fiable'] ) {
			$rows[] = array( $data['contexte']['alerte'] );
		}
		$rows[] = array( 'Compte', 'Intitule', 'Date', 'Journal', 'Piece', 'Libelle', 'Debit', 'Credit', 'Solde', 'Let.' );
		foreach ( $data['comptes'] as $a ) {
			if ( abs( (float) $a['ouverture'] ) >= 0.005 ) {
				$rows[] = array( $a['numero'], $a['libelle'], $data['du'] ?? ( $f['du'] ?: '' ), '', '', $a['libelle_ouverture'] ?? "Solde d'ouverture", $a['ouverture'] > 0 ? $a['ouverture'] : 0, $a['ouverture'] < 0 ? -$a['ouverture'] : 0, $a['ouverture'], '' );
			}
			foreach ( $a['mouvements'] as $m ) {
				$rows[] = array( $a['numero'], $a['libelle'], $m['date'], $m['journal'], $m['piece'], $m['libelle'], $m['debit'], $m['credit'], $m['solde'], $m['lettre'] );
			}
			$rows[] = array( $a['numero'], 'TOTAL ' . $a['numero'], '', '', '', '', $a['td'], $a['tc'], $a['solde'], '' );
		}
		$rows[] = array( 'TOTAL GENERAL', '', '', '', '', '', $data['totaux']['debit'], $data['totaux']['credit'], '', '' );
		fkc_csv( 'grand-livre-general.csv', $rows );
	}

	public function compteResultat() {
		if ( class_exists( 'FKC_Facture' ) ) { FKC_Facture::comptabiliserAvoirsEnAttente(); }
		$du = $_GET['du'] ?? null; $au = $_GET['au'] ?? null;
		FKC_View::render( 'comptabilite::rapports.compte_resultat', array(
			'title' => 'Comptabilité · Compte de résultat', 'tab' => 'compte-resultat',
			'cr' => FKC_Etats::compteResultat( $du ?: null, $au ?: null ), 'du' => $du, 'au' => $au,
		) );
	}

	public function bilan() {
		$du = $_GET['du'] ?? null; $au = $_GET['au'] ?? null;
		FKC_View::render( 'comptabilite::rapports.bilan', array(
			'title' => 'Comptabilité · Bilan', 'tab' => 'bilan',
			'bilan' => FKC_Etats::bilan( $du ?: null, $au ?: null ), 'du' => $du, 'au' => $au,
		) );
	}
}
