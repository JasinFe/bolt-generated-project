<?php
/**
 * Devises : cours de change et revalorisation de clôture.
 *
 * Deux écrans, deux responsabilités bien distinctes :
 *   - la saisie des cours, opération courante et sans conséquence comptable
 *     immédiate ;
 *   - la revalorisation de clôture, qui écrit dans les comptes et se présente
 *     donc toujours en aperçu chiffré avant toute action.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_DeviseController {

	/* Messages flash : chaque contrôleur du projet porte les siens, il n'existe
	   pas de classe de base commune. Clé dédiée pour ne pas écraser celle d'un
	   autre écran. */
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_devise'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_devise'] ?? null; unset( $_SESSION['__flash_devise'] ); return $m; }


	/** Écran des cours de change. */
	public function index() {
		FKC_Devise::assurerSchema();
		$devise = isset( $_GET['devise'] ) ? strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) $_GET['devise'] ) ) : '';
		FKC_View::render( 'comptabilite::devises.index', array(
			'title'      => 'Comptabilité · Devises et cours de change',
			'tab'        => 'devises',
			'pivot'      => FKC_Devise::pivot(),
			'catalogue'  => FKC_Devise::catalogue(),
			'historique' => FKC_Devise::historique( $devise ?: null ),
			'filtre'     => $devise,
			'utilisees'  => FKC_Devise::utilisees(),
			// Récupération automatique : source retenue, état des identifiants,
			// et rafraîchissement au plus une fois par jour.
			'auto'       => FKC_DeviseSource::rafraichirSiNecessaire(),
			'fournisseurs' => FKC_DeviseSource::fournisseurs(),
			'source'     => FKC_DeviseSource::fournisseur(),
			'xe_ok'      => FKC_DeviseSource::xeConfigure(),
			'derniere_maj' => FKC_DeviseSource::derniereMaj(),
			'flash'      => $this->flash(),
		) );
	}

	/** Choisit la source des cours. */
	public function definirSource() {
		list( $ok, $msg ) = FKC_DeviseSource::definirFournisseur( $_POST['fournisseur'] ?? '' );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/devises' );
	}

	/** Enregistre ou efface les identifiants Xe. */
	public function identifiantsXe() {
		if ( ! empty( $_POST['oublier'] ) ) {
			list( $ok, $msg ) = FKC_DeviseSource::oublierXe();
		} else {
			list( $ok, $msg ) = FKC_DeviseSource::enregistrerXe( $_POST['account_id'] ?? '', $_POST['api_key'] ?? '' );
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/devises' );
	}

	/** Récupère les cours maintenant. */
	public function recuperer() {
		$r = FKC_DeviseSource::recuperer( null, $_POST['date'] ?? null, ! empty( $_POST['ecraser'] ) );
		$msg = $r['message'];
		if ( $r['ignorees'] ) {
			$bouts = array();
			foreach ( $r['ignorees'] as $d => $raison ) { $bouts[] = $d . ' (' . $raison . ')'; }
			$msg .= ' Écartées : ' . implode( ', ', $bouts ) . '.';
		}
		$this->setFlash( $msg, $r['ok'] ? 'ok' : 'err' );
		redirect( 'comptabilite/devises' );
	}

	/** Enregistre un cours. */
	public function enregistrer() {
		list( $ok, $msg ) = FKC_Devise::enregistrerTaux(
			$_POST['devise'] ?? '',
			str_replace( ',', '.', (string) ( $_POST['taux'] ?? '' ) ),
			$_POST['date_taux'] ?? null,
			$_POST['source'] ?? 'manuel',
			$_POST['note'] ?? ''
		);
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/devises' );
	}

	/**
	 * Écran de revalorisation : toujours l'aperçu d'abord.
	 *
	 * Une revalorisation modifie le bilan sur la seule base d'un cours de
	 * clôture. La présenter sous forme de bouton sans chiffrage préalable serait
	 * une invitation à l'accident.
	 */
	public function revalorisation() {
		FKC_Devise::assurerSchema();
		$date = isset( $_GET['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $_GET['date'] )
			? (string) $_GET['date']
			: date( 'Y' ) . '-12-31';
		FKC_View::render( 'comptabilite::devises.revalorisation', array(
			'title'      => 'Comptabilité · Revalorisation des devises',
			'tab'        => 'devises',
			'date'       => $date,
			'apercu'     => FKC_DeviseRevalorisation::apercu( $date ),
			'historique' => FKC_DeviseRevalorisation::historique( 100 ),
			'flash'      => $this->flash(),
		) );
	}

	/** Passe la revalorisation. */
	public function passerRevalorisation() {
		$date = (string) ( $_POST['date'] ?? '' );
		list( $ok, $msg ) = FKC_DeviseRevalorisation::passer( $date );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/devises/revalorisation?date=' . urlencode( $date ) );
	}

	/** Extourne les écarts de conversion à l'ouverture. */
	public function extourner() {
		$date = (string) ( $_POST['date'] ?? '' );
		list( $ok, $msg ) = FKC_DeviseRevalorisation::extourner( $date, $_POST['date_ouverture'] ?? null );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/devises/revalorisation?date=' . urlencode( $date ) );
	}
}
