<?php
/** Comptabilité GL : centralisation, opérations diverses, clôtures. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_GlController {

	public function centralisation() {
		$annee = (int) ( $_GET['annee'] ?? date( 'Y' ) );
		// Auto-réparation : déverse les avoirs restés en attente dans les journaux.
		$posted = class_exists( 'FKC_Facture' ) ? FKC_Facture::comptabiliserAvoirsEnAttente() : 0;
		/*
		 * LE JOURNAL CENTRALISATEUR SUIT L'EXERCICE (1.630.0).
		 *
		 * Ces deux bornes étaient en dur. Sur une société à exercice décalé,
		 * l'écran totalisait les journaux du 1er janvier au 31 décembre —
		 * donc à cheval sur deux exercices, dont un partiellement clos.
		 *
		 * Ce n'est pas un tableau de bord : le journal centralisateur est
		 * une pièce que l'OHADA impose de tenir PAR EXERCICE. Le sortir sur
		 * l'année civile produit un document qui ne recoupe ni la balance,
		 * ni les états financiers, ni le grand livre — et personne ne s'en
		 * aperçoit avant le contrôle, puisqu'il s'équilibre parfaitement.
		 * Même défaut, même cause et même correction qu'aux états DGI
		 * (1.564.0) et à la clôture (1.615.0).
		 */
		list( $deb, $fin ) = class_exists( 'FKC_Exercice' )
			? FKC_Exercice::bornes( $annee )
			: array( $annee . '-01-01', $annee . '-12-31' );
		$journaux = FKC_DB::q(
			"SELECT j.code, j.libelle,
				COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) c, COUNT(DISTINCT e.id) nb
			 FROM journaux j
			 LEFT JOIN ecritures e ON e.journal_id=j.id AND e.date_ecriture BETWEEN ? AND ?
			 LEFT JOIN ecriture_lignes l ON l.ecriture_id=e.id
			 GROUP BY j.id ORDER BY j.code", array( $deb, $fin )
		)->fetchAll();
		$cl = FKC_DB::q(
			"SELECT c.classe, COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) c
			 FROM comptes c JOIN ecriture_lignes l ON l.compte_id=c.id JOIN ecritures e ON e.id=l.ecriture_id
			 WHERE e.date_ecriture BETWEEN ? AND ? AND c.classe IN (6,7) GROUP BY c.classe", array( $deb, $fin )
		)->fetchAll();
		$produits = 0; $charges = 0;
		foreach ( $cl as $r ) { if ( 7 === (int) $r['classe'] ) { $produits = $r['c'] - $r['d']; } else { $charges = $r['d'] - $r['c']; } }
		FKC_View::render( 'comptabilite::gl.centralisation', array(
			'title' => 'Comptabilité · Centralisation (GL)', 'tab' => 'gl',
			'annee' => $annee, 'journaux' => $journaux,
			'produits' => $produits, 'charges' => $charges, 'resultat' => $produits - $charges,
			'clotures' => FKC_Cloture::all(), 'flash' => $posted ? array( 'type' => 'ok', 'msg' => $posted . ' avoir(s) en attente comptabilisé(s) et déversé(s) dans les journaux.' ) : $this->flash(),
		) );
	}

	public function cloturer() {
		$type = $_POST['type'] ?? 'mensuelle';
		$annee = (int) ( $_POST['annee'] ?? date( 'Y' ) );
		$sub = (int) ( $_POST['sub'] ?? 1 );
		/*
		 * La clôture ANNUELLE ne se déclenche plus depuis le journal
		 * centralisateur (1.778.0). Elle n'est pas un verrou de période de
		 * plus : elle détermine le résultat, exige ses contrôles et engage
		 * l'affectation puis l'ouverture de N+1. La lancer depuis un écran qui
		 * n'en montre ni l'état ni les prérequis, c'est ce qui permettait de
		 * clôturer sur un résultat faux d'un seul clic.
		 */
		if ( 'annuelle' === $type ) {
			$this->setFlash( 'La clôture annuelle se fait depuis l\'assistant de clôture, qui montre les contrôles, '
				. 'le résultat et les étapes restantes : Comptabilité → Clôture.', 'err' );
			redirect( 'comptabilite/cloture?annee=' . $annee );
		}
		list( $ok, $msg ) = FKC_Cloture::create( $type, $annee, $sub );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/gl' );
	}

	/**
	 * Réouverture d'une période depuis le journal centralisateur.
	 *
	 * Appelait `FKC_Cloture::delete()` : la ligne de clôture disparaissait,
	 * son écriture de résultat restait, aucun motif n'était demandé et rien
	 * n'était consigné. Sur une clôture annuelle, cela laissait un exercice
	 * dont les classes 6 et 7 étaient soldées mais qui se disait ouvert —
	 * état dont on ne sortait plus, la clôture relancée n'ayant plus rien à
	 * solder. Tout passe désormais par la voie contrôlée.
	 */
	public function rouvrir( $id ) {
		list( $ok, $msg ) = FKC_Cloture::reopen( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/gl' );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_gl'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_gl'] ?? null; unset( $_SESSION['__flash_gl'] ); return $m; }
}
