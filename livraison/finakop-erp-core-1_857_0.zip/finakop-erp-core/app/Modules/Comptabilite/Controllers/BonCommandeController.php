<?php
/** Bons de commande fournisseurs (achats). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_BonCommandeController {

	public function index() {
		FKC_View::render( 'comptabilite::bons-commande.index', array(
			'title' => 'Comptabilité · Bons de commande', 'tab' => 'achats',
			'bons' => FKC_BonCommande::all(), 'statuts' => FKC_BonCommande::statuts(),
			'factures' => FKC_BonCommande::facturesDisponibles(), 'flash' => $this->flash(),
		) );
	}

	public function create() {
		FKC_View::render( 'comptabilite::bons-commande.form', array(
			'title' => 'Nouveau bon de commande', 'tab' => 'achats',
			'fournisseurs' => FKC_Fournisseur::all( true ), 'errors' => array(),
		) );
	}

	public function store() {
		$errs = array();
		if ( '' === trim( (string) ( $_POST['objet'] ?? '' ) ) && empty( $_POST['fournisseur_id'] ) && '' === trim( (string) ( $_POST['fournisseur_nom'] ?? '' ) ) ) {
			$errs[] = 'Indiquez au moins un fournisseur ou un objet.';
		}
		if ( (float) ( $_POST['montant_ttc'] ?? 0 ) <= 0 ) { $errs[] = 'Le montant TTC doit être positif.'; }
		if ( $errs ) {
			return FKC_View::render( 'comptabilite::bons-commande.form', array(
				'title' => 'Nouveau bon de commande', 'tab' => 'achats',
				'fournisseurs' => FKC_Fournisseur::all( true ), 'errors' => $errs,
			) );
		}
		FKC_BonCommande::create( $_POST );
		$this->setFlash( 'Bon de commande créé.' );
		redirect( 'comptabilite/bons-commande' );
	}

	public function rattacher( $id ) {
		list( $ok, $msg ) = FKC_BonCommande::rattacher( (int) $id, (int) ( $_POST['facture_fournisseur_id'] ?? 0 ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/bons-commande' );
	}
	public function detacher( $id ) {
		list( $ok, $msg ) = FKC_BonCommande::detacher( (int) $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/bons-commande' );
	}
	public function annuler( $id ) {
		list( $ok, $msg ) = FKC_BonCommande::annuler( (int) $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'comptabilite/bons-commande' );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_bc'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_bc'] ?? null; unset( $_SESSION['__flash_bc'] ); return $m; }
}
