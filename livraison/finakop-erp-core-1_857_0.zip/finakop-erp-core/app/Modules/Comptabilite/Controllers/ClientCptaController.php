<?php
/**
 * Comptabilité Client : postes clients, factures ouvertes et encaissements.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CE QUE CET ÉCRAN MONTRE, ET POURQUOI IL A CHANGÉ (1.731.0)
 *
 * Il listait des CLIENTS avec un solde global, et l'encaissement portait sur
 * ce solde. C'est une lecture de banquier, pas de comptable : on n'encaisse
 * pas « un client », on encaisse UNE FACTURE. Tant que le détail n'existait
 * pas, l'entreprise ne pouvait ni dire ce qu'un versement soldait, ni
 * relancer sur la bonne pièce, ni justifier une créance devant un contrôle.
 *
 * La liste par défaut est donc celle des FACTURES OUVERTES, la plus ancienne
 * d'abord — l'ordre dans lequel on encaisse. La vue par client reste
 * accessible : elle répond à une autre question, « qui me doit le plus ? ».
 *
 * AUCUN SECOND MOTEUR. Les postes viennent de FKC_Recouvrement, qui tient
 * déjà l'antériorité, le lettrage et les suspensions. Deux moteurs auraient
 * fini par afficher deux encours différents pour le même client.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ClientCptaController {

	/** Lit un montant saisi : « 1 250,50 », « 1250.50 », espace insécable compris. */
	protected static function montantSaisi( $v ) {
		$v = str_replace( array( ' ', "\xc2\xa0", "\xe2\x80\xaf", "'" ), '', (string) $v );
		$v = str_replace( ',', '.', $v );
		return round( (float) $v, 2 );
	}

	public function index() {
		$vue = ( 'clients' === ( $_GET['vue'] ?? '' ) ) ? 'clients' : 'factures';
		$d   = FKC_Recouvrement::compute();

		/*
		 * UNE SEULE PASSE, PAS UNE REQUÊTE PAR CLIENT.
		 *
		 * L'écran appelait soldeClient() dans une boucle : deux requêtes par
		 * client, donc quatre cents requêtes pour deux cents clients, à chaque
		 * affichage. Le moteur de recouvrement calcule tout en trois requêtes
		 * et mémorise son instantané pour la durée de la requête HTTP.
		 */
		$rows = array(); $totalDu = 0.0; $nbOuvertes = 0;
		foreach ( FKC_Client::all() as $c ) {
			$id = (int) $c['id'];
			$r  = $d['clients'][ $id ] ?? null;
			$c['encours']     = $r ? (float) $r['encours'] : 0.0;
			$c['facture']     = $r ? (float) $r['facture'] : 0.0;
			$c['encaisse']    = $r ? (float) $r['encaisse'] : 0.0;
			$c['credit']      = $r ? (float) ( $r['credit'] ?? 0 ) : 0.0;
			$c['retard']      = $r ? (float) $r['retard'] : 0.0;
			$c['jours_max']   = $r ? (int) $r['jours_max'] : 0;
			$c['nb_ouvertes'] = 0;
			$rows[ $id ]      = $c;
			$totalDu         += $c['encours'];
		}

		$postes = array();
		foreach ( $d['factures'] as $f ) {
			$cid = (int) $f['client_id'];
			if ( isset( $rows[ $cid ] ) ) { $rows[ $cid ]['nb_ouvertes']++; }
			$postes[] = $f;
			$nbOuvertes++;
		}
		/*
		 * La liste de travail du recouvrement place en tête ce qui est
		 * relançable. Ici la question est autre — « qu'est-ce qui reste à
		 * encaisser ? » — et l'ordre naturel est l'ancienneté : une facture
		 * sous promesse de paiement s'encaisse quand même.
		 */
		usort( $postes, function ( $a, $b ) { return $b['jours'] <=> $a['jours']; } );

		FKC_View::render( 'comptabilite::clients.index', array(
			'title' => 'Comptabilité · Clients', 'tab' => 'cpta-clients',
			'clients' => array_values( $rows ), 'postes' => $postes, 'vue' => $vue,
			'totalDu' => $totalDu, 'nbOuvertes' => $nbOuvertes,
			// Créances au grand livre sans fiche client : elles existent, on
			// ne peut pas les encaisser d'ici. Les taire serait pire.
			'orphelines' => (float) ( $d['kpis']['creances_orphelines'] ?? 0 ),
			'credits'    => (float) ( $d['kpis']['credits_non_affectes'] ?? 0 ),
			'flash' => $this->flash(),
		) );
	}

	public function creances() {
		$d = FKC_Recouvrement::compute();
		$rows = array(); $total = 0; $nb = 0;
		foreach ( FKC_Client::all() as $c ) {
			$r = $d['clients'][ (int) $c['id'] ] ?? null;
			if ( ! $r || $r['encours'] <= 0.5 ) { continue; }
			$c['solde_info'] = array(
				'facture'  => (float) $r['facture'],
				'encaisse' => (float) $r['encaisse'],
				'solde'    => (float) $r['encours'],
			);
			$rows[] = $c; $total += (float) $r['encours']; $nb++;
		}
		usort( $rows, function ( $a, $b ) { return $b['solde_info']['solde'] <=> $a['solde_info']['solde']; } );
		FKC_View::render( 'comptabilite::clients.creances', array(
			'title' => 'Comptabilité · Total créances clients', 'tab' => 'cpta-clients',
			'clients' => $rows, 'total' => $total, 'nb' => $nb, 'flash' => $this->flash(),
		) );
	}

	public function store() {
		$d = array(
			'nom' => trim( (string) ( $_POST['nom'] ?? '' ) ),
			'type' => 'B2B' === ( $_POST['type'] ?? 'B2C' ) ? 'B2B' : 'B2C',
			'ncc' => $_POST['ncc'] ?? '', 'telephone' => $_POST['telephone'] ?? '',
			'email' => $_POST['email'] ?? '', 'adresse' => $_POST['adresse'] ?? '',
		);
		if ( '' === $d['nom'] ) { $this->setFlash( 'Le nom du client est requis.', 'err' ); redirect( 'comptabilite/clients' ); }
		FKC_Client::create( $d );
		$this->setFlash( 'Client « ' . $d['nom'] . ' » créé.' );
		redirect( 'comptabilite/clients' );
	}

	/**
	 * Formulaire d'encaissement — LE DÉTAIL PAR FACTURE Y EST, MAINTENANT.
	 *
	 * `?facture=` pré-sélectionne un poste : c'est le chemin depuis la liste,
	 * où l'utilisateur a déjà désigné la facture qu'il encaisse. Sans ce
	 * paramètre, la répartition est proposée au plus ancien, et reste
	 * modifiable ligne à ligne.
	 */
	public function encaisserForm( $id ) {
		$c = FKC_Client::find( $id );
		if ( ! $c ) { redirect( 'comptabilite/clients' ); }
		$poste   = FKC_Imputation::postesClient( (int) $id );
		$cible   = (int) ( $_GET['facture'] ?? 0 );
		$montant = $poste['du'];
		if ( $cible ) {
			$montant = 0.0;
			foreach ( $poste['ouvertes'] as $p ) {
				if ( (int) $p['id'] === $cible ) { $montant = (float) $p['reste']; break; }
			}
			if ( $montant <= 0 ) { $cible = 0; $montant = $poste['du']; }
		}
		FKC_View::render( 'comptabilite::clients.encaisser', array(
			'title' => 'Encaissement · ' . $c['nom'], 'tab' => 'cpta-clients',
			'client' => $c, 'poste' => $poste, 'cible' => $cible, 'montant' => $montant,
			'imputable' => FKC_Imputation::disponible(),
			'comptes' => FKC_Tresorerie::comptes( true ), 'modes' => FKC_Reglement::modes(),
			'reglements' => FKC_Reglement::duTiers( 'client', (int) $id ),
			'flash' => $this->flash(),
		) );
	}

	public function encaisser( $id ) {
		$c = FKC_Client::find( $id );
		if ( ! $c ) { redirect( 'comptabilite/clients' ); }

		/*
		 * LA RÉPARTITION EST LUE AVANT LE MONTANT, ET ELLE PEUT LE FIXER.
		 *
		 * Deux gestes existent et doivent tous deux rester possibles :
		 *
		 *   — « j'encaisse ces trois factures » : la somme des lignes fait le
		 *     montant, et la saisir une seconde fois serait une occasion de
		 *     se tromper ;
		 *   — « j'encaisse 200 000 F sur le compte du client » : aucune ligne
		 *     n'est renseignée, le lettrage FIFO s'applique comme avant.
		 *
		 * Si les deux sont saisis, le montant fait foi : l'écart part au
		 * crédit du client. C'est un acompte, pas une erreur — et le modèle
		 * refuse déjà le cas inverse, une répartition plus grosse que la
		 * somme reçue.
		 */
		$imputations = array(); $sommeImp = 0.0;
		foreach ( (array) ( $_POST['imput'] ?? array() ) as $fid => $m ) {
			$fid = (int) $fid;
			$m   = self::montantSaisi( $m );
			if ( $fid <= 0 || $m <= 0 ) { continue; }
			$imputations[ $fid ] = $m; $sommeImp += $m;
		}
		$brut    = trim( (string) ( $_POST['montant'] ?? '' ) );
		$montant = ( '' === $brut ) ? $sommeImp : self::montantSaisi( $brut );
		if ( $sommeImp > 0 && $montant <= 0 ) { $montant = $sommeImp; }

		list( $ok, $msg, $rid ) = FKC_Reglement::create( array(
			'sens' => 'encaissement', 'tiers_type' => 'client', 'tiers_id' => (int) $id,
			'tresorerie_id' => (int) ( $_POST['tresorerie_id'] ?? 0 ),
			'date_reglement' => $_POST['date_reglement'] ?? date( 'Y-m-d' ),
			'montant' => $montant, 'mode' => $_POST['mode'] ?? null,
			'reference' => $_POST['reference'] ?? null,
			'libelle' => 'Encaissement ' . $c['nom'],
			'imputations' => $imputations,
		) );

		// Justificatif de l'encaissement — même besoin que côté fournisseur :
		// un virement reçu sans son avis est invérifiable au rapprochement.
		if ( $ok && ! empty( $rid ) && class_exists( 'FKC_GedDocument' )
			&& ! empty( $_FILES['piece'] ) && UPLOAD_ERR_NO_FILE !== ( $_FILES['piece']['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
			list( $pok, $pmsg ) = FKC_GedDocument::add( array(
				'titre'      => trim( (string) ( $_POST['piece_titre'] ?? '' ) )
					?: 'Justificatif encaissement ' . $c['nom'] . ' — ' . ( $_POST['date_reglement'] ?? date( 'Y-m-d' ) ),
				'categorie'  => 'Justificatifs de règlement',
				'lien_type'  => 'reglement',
				'lien_id'    => (int) $rid,
				'lien_label' => $c['nom'] . ' — ' . fkc_money( $montant ) . ' F',
				'note'       => trim( (string) ( $_POST['reference'] ?? '' ) ) ?: null,
			), $_FILES['piece'] );
			$msg .= $pok ? ' Justificatif joint.'
				: ' ⚠️ L\'encaissement est enregistré, mais le justificatif n\'a pas pu être joint : ' . $pmsg;
		}
		if ( $ok && $imputations ) {
			$n = count( $imputations );
			$msg .= ' Imputé sur ' . $n . ' facture' . ( $n > 1 ? 's' : '' ) . '.';
			if ( $montant - $sommeImp > 0.5 ) {
				$msg .= ' Reliquat de ' . fkc_money( $montant - $sommeImp ) . ' F porté au crédit du client.';
			}
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( $ok ? 'comptabilite/clients' : 'comptabilite/clients/' . $id . '/encaisser' );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_cc'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_cc'] ?? null; unset( $_SESSION['__flash_cc'] ); return $m; }
}
