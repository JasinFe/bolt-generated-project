<?php
/** États financiers de synthèse (SYSCOHADA, présentation DGI — SMT ou SN). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EtatsFinanciersController {

	public function index() {
		$defaut = class_exists( 'FKC_Exercice' ) ? (int) FKC_Exercice::courant() : (int) date( 'Y' );
		$an = isset( $_GET['annee'] ) ? (int) preg_replace( '/\D/', '', (string) $_GET['annee'] ) : $defaut;
		if ( $an < 2000 || $an > 2100 ) { $an = $defaut; }

		/*
		 * LE SYSTÈME SUIT LE DOSSIER (1.853.0).
		 *
		 * Cette page n'affichait que le Système Minimal de Trésorerie : un
		 * dossier au Système Normal y lisait un bilan à cinq lignes qui n'est
		 * pas le sien. Elle suit désormais le système enregistré pour le
		 * dossier, et se bascule d'un clic.
		 */
		$sys = $_GET['systeme'] ?? FKC_EtatsDgiController::systemeDossier();
		$sys = ( 'sn' === $sys ) ? 'sn' : 'smt';

		$data = array(
			'title'    => 'États financiers',
			'annee'    => $an,
			'annees'   => $this->annees(),
			'systeme'  => $sys,
			'systeme_dossier' => FKC_EtatsDgiController::systemeDossier(),
			'societe'  => FKC_Tenant::current(),
			// Même en-tête que la liasse DGI : un seul point de vérité pour
			// les dates d'exercice, la durée et l'identification du dossier.
			'entete'   => FKC_EtatsDgi::entete( $an ),
			'controle' => FKC_EtatsDgi::controle( $an ),
			'synthese' => FKC_EtatsDgi::synthese( $an, $sys ),
		);
		if ( 'sn' === $sys ) {
			$data['bilan'] = FKC_EtatsDgi::bilanSN( $an );
			$data['crsn']  = FKC_EtatsDgi::resultatSN( $an );
		} else {
			$data['bilan'] = FKC_EtatsDgi::bilan( $an );
			$data['cr']    = FKC_EtatsDgi::resultat( $an );
		}
		$data['flash'] = $_SESSION['__flash_dgi'] ?? null;
		unset( $_SESSION['__flash_dgi'] );
		FKC_View::render( 'comptabilite::etats_financiers.index', $data );
	}

	/** Millésimes proposés, en entiers, du plus récent au plus ancien. */
	protected function annees() {
		if ( class_exists( 'FKC_Exercice' ) ) { $y = FKC_Exercice::annees(); if ( $y ) { return array_map( 'intval', $y ); } }
		$ys = array();
		try {
			foreach ( FKC_DB::q( "SELECT DISTINCT substr(date_ecriture,1,4) y FROM ecritures WHERE date_ecriture IS NOT NULL ORDER BY y DESC" )->fetchAll() as $r ) {
				if ( ! empty( $r['y'] ) ) { $ys[] = (int) $r['y']; }
			}
		} catch ( Exception $e ) {}
		$ys[] = (int) date( 'Y' );
		$ys = array_values( array_unique( $ys ) );
		rsort( $ys );
		return $ys;
	}
}
