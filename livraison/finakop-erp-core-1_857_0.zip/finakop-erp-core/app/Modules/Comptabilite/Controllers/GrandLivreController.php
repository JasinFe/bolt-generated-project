<?php
/** Grand livre auxiliaire clients/fournisseurs + lettrage. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_GrandLivreController {

	protected function filters() {
		return array(
			'tiers_id' => (int) ( $_GET['tiers_id'] ?? 0 ) ?: null,
			'from'     => trim( (string) ( $_GET['from'] ?? '' ) ) ?: null,
			'to'       => trim( (string) ( $_GET['to'] ?? '' ) ) ?: null,
			'lettrage' => in_array( $_GET['lettrage'] ?? 'all', array( 'all', 'lettre', 'nonlettre' ), true ) ? ( $_GET['lettrage'] ?? 'all' ) : 'all',
			'q'        => trim( (string) ( $_GET['q'] ?? '' ) ) ?: null,
		);
	}

	protected function show( $type ) {
		$opts   = $this->filters();
		$lignes = FKC_GrandLivreTiers::lignes( $type, $opts );
		$sini   = FKC_GrandLivreTiers::soldeInitial( $type, $opts );
		FKC_View::render( 'comptabilite::grandlivre.tiers', array(
			'title'   => 'fournisseur' === $type ? 'Grand livre Fournisseurs' : 'Grand livre Clients',
			'tab'     => 'gl-' . $type, 'type' => $type,
			'lignes'  => $lignes,
			'sini'    => $sini,
			'totaux'  => FKC_GrandLivreTiers::totaux( $lignes, $sini ),
			'tiers'   => FKC_GrandLivreTiers::tiersOptions( $type ),
			'opts'    => $opts,
			'flash'   => $this->flash(),
		) );
	}

	public function clients() { $this->show( 'client' ); }
	public function fournisseurs() { $this->show( 'fournisseur' ); }

	protected function backTo( $type ) {
		$base = 'fournisseur' === $type ? 'comptabilite/grand-livre-fournisseurs' : 'comptabilite/grand-livre-clients';
		$qs = $_POST['_filters'] ?? '';
		return $base . ( $qs ? ( '?' . $qs ) : '' );
	}

	protected function doLettrer( $type ) {
		$ids   = (array) ( $_POST['ids'] ?? array() );
		$force = ! empty( $_POST['force'] );
		list( $ok, $msg ) = FKC_Lettrage::lettrer( $ids, $force );
		$this->setFlash( $msg );
		redirect( $this->backTo( $type ) );
	}
	protected function doDelettrer( $type ) {
		$ids  = (array) ( $_POST['ids'] ?? array() );
		$code = trim( (string) ( $_POST['code'] ?? '' ) ) ?: null;
		list( $ok, $msg ) = FKC_Lettrage::delettrer( $ids, $code );
		$this->setFlash( $msg );
		redirect( $this->backTo( $type ) );
	}
	protected function doAuto( $type ) {
		$tid = (int) ( $_POST['tiers_id'] ?? 0 );
		if ( ! $tid ) { $this->setFlash( 'Choisissez un tiers pour le lettrage automatique.' ); }
		else { list( $ok, $msg ) = FKC_Lettrage::autoSolde( $type, $tid ); $this->setFlash( $msg ); }
		redirect( $this->backTo( $type ) );
	}

	public function lettrerClients() { $this->doLettrer( 'client' ); }
	public function delettrerClients() { $this->doDelettrer( 'client' ); }
	public function autoClients() { $this->doAuto( 'client' ); }
	public function lettrerFournisseurs() { $this->doLettrer( 'fournisseur' ); }
	public function delettrerFournisseurs() { $this->doDelettrer( 'fournisseur' ); }
	public function autoFournisseurs() { $this->doAuto( 'fournisseur' ); }

	protected function setFlash( $m ) { $_SESSION['__flash_gl'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_gl'] ?? null; unset( $_SESSION['__flash_gl'] ); return $m; }
}
