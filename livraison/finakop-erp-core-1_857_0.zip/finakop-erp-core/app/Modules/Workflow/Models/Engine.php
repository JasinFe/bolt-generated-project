<?php
/**
 * Moteur de processus (Workflow Engine) : machine à états déclarative.
 *
 * Une DÉFINITION (JSON, éditable sans code) décrit : les états, les
 * transitions (action, rôles autorisés, condition sur le contexte) et les
 * EFFETS exécutés à l'arrivée dans un état (comptabilisation via FKC_Posting,
 * notification, rappel d'un module via un handler enregistré).
 *
 * Une INSTANCE suit un objet métier (ref_type + ref_id) le long de la
 * définition ; chaque transition est historisée (acteur, commentaire, date).
 *
 * Les packs livrent des définitions par défaut (workflows.php), installées de
 * façon additive par FKC_Packs::ensureSociete() ; le client les adapte ensuite
 * depuis l'écran Workflow → Processus. FKC_Validation (file d'approbation
 * simple) est conservé et coexiste : le moteur est la génération suivante.
 *
 * Rôles d'une transition : 'admin' (administrateur), ou un code de module /
 * sous-module (l'utilisateur doit détenir la permission FKC_Auth::can()).
 * Liste vide = tout utilisateur connecté.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_WorkflowEngine {

	/** @var array type d'effet => callable( array $effet, array $instance, array $ctx ) */
	protected static $handlers = array();
	protected static $ready = false;

	/* ── Schéma (idempotent, à la demande) ───────────────────────────────── */

	public static function ensure() {
		if ( self::$ready ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS wf_definitions(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				code TEXT NOT NULL UNIQUE,
				libelle TEXT NOT NULL,
				objet TEXT,
				pack TEXT,
				definition TEXT NOT NULL,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				updated_at TEXT
			);
			CREATE TABLE IF NOT EXISTS wf_instances(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				definition_id INTEGER NOT NULL,
				code TEXT NOT NULL,
				ref_type TEXT, ref_id INTEGER,
				etat TEXT NOT NULL,
				contexte TEXT,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				updated_at TEXT,
				FOREIGN KEY(definition_id) REFERENCES wf_definitions(id)
			);
			CREATE INDEX IF NOT EXISTS idx_wfi_ref ON wf_instances(ref_type, ref_id);
			CREATE INDEX IF NOT EXISTS idx_wfi_etat ON wf_instances(etat);
			CREATE TABLE IF NOT EXISTS wf_historique(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				instance_id INTEGER NOT NULL,
				de_etat TEXT, vers_etat TEXT NOT NULL,
				action TEXT, acteur_id INTEGER, acteur_nom TEXT, commentaire TEXT,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				FOREIGN KEY(instance_id) REFERENCES wf_instances(id)
			);
		" );
		self::$ready = true;
	}

	/* ── Handlers d'effets (modules & packs) ─────────────────────────────── */

	/** Enregistre un handler d'effet personnalisé : type => callable($effet,$instance,$ctx). */
	public static function onEffet( $type, $callable ) {
		if ( is_callable( $callable ) ) { self::$handlers[ (string) $type ] = $callable; }
	}

	/* ── Définitions ─────────────────────────────────────────────────────── */

	/** Installe (additivement) les définitions par défaut d'un pack : code déjà présent = jamais écrasé. */
	public static function seed( array $defs, $pack = '' ) {
		self::ensure();
		foreach ( $defs as $d ) {
			if ( empty( $d['code'] ) || empty( $d['etats'] ) ) { continue; }
			$exists = FKC_DB::q( 'SELECT 1 FROM wf_definitions WHERE code=?', array( $d['code'] ) )->fetchColumn();
			if ( $exists ) { continue; }
			FKC_DB::q(
				'INSERT INTO wf_definitions(code,libelle,objet,pack,definition,actif) VALUES(?,?,?,?,?,1)',
				array(
					(string) $d['code'],
					(string) ( $d['libelle'] ?? $d['code'] ),
					(string) ( $d['objet'] ?? '' ),
					(string) $pack,
					json_encode( $d, JSON_UNESCAPED_UNICODE ),
				)
			);
		}
	}

	public static function definitions() {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM wf_definitions ORDER BY pack, code' )->fetchAll();
	}

	/** Définition décodée par code (ou null). */
	public static function definition( $code ) {
		self::ensure();
		$row = FKC_DB::q( 'SELECT * FROM wf_definitions WHERE code=? AND actif=1', array( (string) $code ) )->fetch();
		if ( ! $row ) { return null; }
		$def = json_decode( (string) $row['definition'], true );
		if ( ! is_array( $def ) ) { return null; }
		$def['_id'] = (int) $row['id'];
		return $def;
	}

	/** Met à jour le JSON d'une définition (écran d'administration). @return array(ok, message) */
	public static function saveDefinition( $id, $json ) {
		self::ensure();
		$def = json_decode( (string) $json, true );
		if ( ! is_array( $def ) || empty( $def['code'] ) || empty( $def['etats'] ) || ! is_array( $def['etats'] ) ) {
			return array( false, 'Définition invalide : JSON avec au minimum « code » et « etats » (liste).' );
		}
		foreach ( (array) ( $def['transitions'] ?? array() ) as $t ) {
			if ( empty( $t['de'] ) || empty( $t['vers'] ) || ! in_array( $t['de'], $def['etats'], true ) || ! in_array( $t['vers'], $def['etats'], true ) ) {
				return array( false, 'Transition invalide : « de » et « vers » doivent référencer des états déclarés.' );
			}
		}
		FKC_DB::q(
			"UPDATE wf_definitions SET libelle=?, objet=?, definition=?, updated_at=datetime('now','localtime') WHERE id=?",
			array( (string) ( $def['libelle'] ?? $def['code'] ), (string) ( $def['objet'] ?? '' ), json_encode( $def, JSON_UNESCAPED_UNICODE ), (int) $id )
		);
		return array( true, 'Processus enregistré.' );
	}

	/* ── Instances ───────────────────────────────────────────────────────── */

	/**
	 * Démarre une instance sur un objet métier. L'état initial est le premier
	 * état déclaré. @return int id d'instance (0 si définition absente).
	 */
	public static function start( $code, $refType, $refId, array $ctx = array() ) {
		self::ensure();
		$def = self::definition( $code );
		if ( ! $def ) { return 0; }
		$etat = (string) $def['etats'][0];
		FKC_DB::q(
			'INSERT INTO wf_instances(definition_id,code,ref_type,ref_id,etat,contexte,created_by) VALUES(?,?,?,?,?,?,?)',
			array( (int) $def['_id'], (string) $code, (string) $refType, (int) $refId, $etat, json_encode( $ctx, JSON_UNESCAPED_UNICODE ), class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		self::historise( $id, null, $etat, 'creation', '' );
		return $id;
	}

	public static function instance( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM wf_instances WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/** Instance active (dernière) attachée à un objet. */
	public static function instanceFor( $refType, $refId ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM wf_instances WHERE ref_type=? AND ref_id=? ORDER BY id DESC LIMIT 1', array( (string) $refType, (int) $refId ) )->fetch();
		return $r ?: null;
	}

	public static function historique( $instanceId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM wf_historique WHERE instance_id=? ORDER BY id ASC', array( (int) $instanceId ) )->fetchAll();
	}

	public static function enCours( $limit = 100 ) {
		self::ensure();
		return FKC_DB::q( 'SELECT i.*, d.libelle AS definition_libelle FROM wf_instances i JOIN wf_definitions d ON d.id=i.definition_id ORDER BY i.updated_at DESC, i.id DESC LIMIT ' . (int) $limit )->fetchAll();
	}

	/* ── Transitions ─────────────────────────────────────────────────────── */

	/** Un utilisateur peut-il déclencher une transition ? (rôles : vide=connecté, 'admin', ou permission de module) */
	public static function autorise( array $t ) {
		$roles = (array) ( $t['roles'] ?? array() );
		if ( empty( $roles ) ) { return FKC_Auth::check(); }
		if ( FKC_Auth::isAdmin() ) { return true; }
		foreach ( $roles as $r ) {
			if ( 'admin' === $r ) { continue; }
			if ( FKC_Auth::can( (string) $r ) ) { return true; }
		}
		return false;
	}

	/** Actions manuelles disponibles depuis l'état courant, pour l'utilisateur connecté. */
	public static function actionsDisponibles( array $instance ) {
		$def = self::definition( $instance['code'] );
		if ( ! $def ) { return array(); }
		$ctx = json_decode( (string) ( $instance['contexte'] ?? '' ), true ) ?: array();
		$out = array();
		foreach ( (array) ( $def['transitions'] ?? array() ) as $t ) {
			if ( ( $t['de'] ?? '' ) !== $instance['etat'] || ! empty( $t['auto'] ) || empty( $t['action'] ) ) { continue; }
			if ( ! self::autorise( $t ) ) { continue; }
			if ( ! empty( $t['condition'] ) && ! FKC_Posting::evalCondition( (string) $t['condition'], $ctx ) ) { continue; }
			$out[] = $t;
		}
		return $out;
	}

	/**
	 * Applique une action manuelle puis enchaîne les transitions automatiques.
	 * @return array{bool, string, string} ( bool ok, string message, string etat_final )
	 */
	public static function transition( $instanceId, $action, $commentaire = '' ) {
		self::ensure();
		$i = self::instance( $instanceId );
		if ( ! $i ) { return array( false, 'Instance de processus introuvable.', '' ); }
		$def = self::definition( $i['code'] );
		if ( ! $def ) { return array( false, 'Définition de processus introuvable ou désactivée.', $i['etat'] ); }
		$ctx = json_decode( (string) ( $i['contexte'] ?? '' ), true ) ?: array();

		$cible = null;
		foreach ( (array) ( $def['transitions'] ?? array() ) as $t ) {
			if ( ( $t['de'] ?? '' ) === $i['etat'] && ( $t['action'] ?? '' ) === $action && empty( $t['auto'] ) ) { $cible = $t; break; }
		}
		if ( ! $cible ) { return array( false, "Action « {$action} » indisponible depuis l'état « {$i['etat']} ».", $i['etat'] ); }
		if ( ! self::autorise( $cible ) ) { return array( false, 'Vous n\'êtes pas autorisé à effectuer cette action.', $i['etat'] ); }
		if ( ! empty( $cible['condition'] ) && ! FKC_Posting::evalCondition( (string) $cible['condition'], $ctx ) ) {
			return array( false, 'Condition non remplie : ' . $cible['condition'], $i['etat'] );
		}

		$etat = self::appliquer( $i, $cible, $ctx, $action, $commentaire );

		// Enchaînement des transitions automatiques (garde-fou : 5 maximum).
		for ( $n = 0; $n < 5; $n++ ) {
			$auto = null;
			foreach ( (array) ( $def['transitions'] ?? array() ) as $t ) {
				if ( ( $t['de'] ?? '' ) !== $etat || empty( $t['auto'] ) ) { continue; }
				if ( ! empty( $t['condition'] ) && ! FKC_Posting::evalCondition( (string) $t['condition'], $ctx ) ) { continue; }
				$auto = $t; break;
			}
			if ( ! $auto ) { break; }
			$i['etat'] = $etat;
			$etat = self::appliquer( $i, $auto, $ctx, 'auto', '' );
		}
		return array( true, 'Processus : état « ' . $etat . ' ».', $etat );
	}

	/** Applique une transition : état, historique, effets. @return string nouvel état */
	protected static function appliquer( array $i, array $t, array &$ctx, $action, $commentaire ) {
		$vers = (string) $t['vers'];
		FKC_DB::q( "UPDATE wf_instances SET etat=?, contexte=?, updated_at=datetime('now','localtime') WHERE id=?", array( $vers, json_encode( $ctx, JSON_UNESCAPED_UNICODE ), (int) $i['id'] ) );
		self::historise( (int) $i['id'], (string) $i['etat'], $vers, (string) $action, (string) $commentaire );
		foreach ( (array) ( $t['effets'] ?? array() ) as $e ) { self::effet( (array) $e, array_merge( $i, array( 'etat' => $vers ) ), $ctx ); }
		return $vers;
	}

	/** Exécute un effet : posting (FKC_Posting), notification, ou handler enregistré. Le contexte peut être enrichi (ecriture_id…). */
	protected static function effet( array $e, array $instance, array &$ctx ) {
		$type = (string) ( $e['type'] ?? '' );
		try {
			if ( 'posting' === $type && class_exists( 'FKC_Posting' ) ) {
				// L'événement peut être interpolé depuis le contexte (packs génériques : '{evenement}').
				$evt = FKC_Posting::interp( (string) ( $e['evenement'] ?? '' ), $ctx );
				list( $ok, $msg, $eid, $bid ) = FKC_Posting::emettre( $evt, $ctx );
				$ctx['posting_ok']  = $ok ? 1 : 0;
				$ctx['ecriture_id'] = $eid; $ctx['brouillon_id'] = $bid;
				if ( ! $ok ) { fkc_log( 'Workflow effet posting: ' . $msg, 'ERROR' ); }
			} elseif ( 'notification' === $type && class_exists( 'FKC_Notification' ) ) {
				FKC_Notification::notifyAdmins(
					(string) ( $e['titre'] ?? 'Processus' ),
					FKC_Posting::interp( (string) ( $e['message'] ?? '' ), $ctx ),
					'workflow',
					'workflow/processus/instances/' . (int) $instance['id']
				);
			} elseif ( isset( self::$handlers[ $type ] ) ) {
				$h = self::$handlers[ $type ];
				$h( $e, array_merge( $instance ), $ctx ); // invocation directe : $ctx passé par référence
			}
		} catch ( \Throwable $ex ) {
			fkc_log( 'Workflow effet ' . $type . ' : ' . $ex->getMessage(), 'ERROR' );
		}
		// Persistance du contexte enrichi par les effets.
		FKC_DB::q( 'UPDATE wf_instances SET contexte=? WHERE id=?', array( json_encode( $ctx, JSON_UNESCAPED_UNICODE ), (int) $instance['id'] ) );
	}

	protected static function historise( $instanceId, $de, $vers, $action, $commentaire ) {
		$u = class_exists( 'FKC_Auth' ) ? FKC_Auth::user() : null;
		FKC_DB::q(
			'INSERT INTO wf_historique(instance_id,de_etat,vers_etat,action,acteur_id,acteur_nom,commentaire) VALUES(?,?,?,?,?,?,?)',
			array( (int) $instanceId, $de, (string) $vers, (string) $action, $u['id'] ?? null, $u['nom_complet'] ?? ( $u['login'] ?? null ), $commentaire ?: null )
		);
	}
}
