<?php
/**
 * Workflow de validation : demandes d'approbation (factures, OD de paie,
 * dépenses…). Table « validations » dans la base de l'entité active.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Validation {

	public static function types() {
		return array(
			'facture'  => 'Facture',
			'od_paie'  => 'OD de paie',
			'depense'  => 'Dépense / achat',
			'ecriture' => 'Écriture',
			'autre'    => 'Autre',
		);
	}

	public static function statuts() {
		return array(
			'en_attente' => 'En attente',
			'approuve'   => 'Approuvé',
			'refuse'     => 'Refusé',
		);
	}

	public static function typeLabel( $t ) { $a = self::types(); return $a[ $t ] ?? $t; }
	public static function statutLabel( $s ) { $a = self::statuts(); return $a[ $s ] ?? $s; }

	/**
	 * Crée une demande de validation et notifie les validateurs (administrateurs).
	 * @return int id de la demande (0 si échec).
	 */
	public static function create( $data ) {
		$types = self::types();
		$type  = isset( $types[ $data['type'] ?? '' ] ) ? $data['type'] : 'autre';
		FKC_DB::q(
			'INSERT INTO validations(type,ref_type,ref_id,objet,montant,demandeur_id,demandeur_nom,statut,url)
			 VALUES(?,?,?,?,?,?,?,\'en_attente\',?)',
			array(
				$type,
				$data['ref_type'] ?? null,
				! empty( $data['ref_id'] ) ? (int) $data['ref_id'] : null,
				(string) ( $data['objet'] ?? 'Demande de validation' ),
				(float) ( $data['montant'] ?? 0 ),
				! empty( $data['demandeur_id'] ) ? (int) $data['demandeur_id'] : null,
				trim( (string) ( $data['demandeur_nom'] ?? '' ) ) ?: null,
				$data['url'] ?? null,
			)
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		if ( $id && class_exists( 'FKC_Notification' ) ) {
			$mt = (float) ( $data['montant'] ?? 0 );
			$msg = self::typeLabel( $type ) . ' · ' . ( $data['objet'] ?? '' ) . ( $mt > 0 ? ' · ' . number_format( $mt, 0, ',', ' ' ) . ' F' : '' );
			FKC_Notification::notifyAdmins( 'Demande de validation', $msg, 'validation', 'validations/' . $id );
		}
		return $id;
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM validations WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	public static function pending( $limit = 100 ) {
		$limit = (int) $limit;
		return FKC_DB::q( "SELECT * FROM validations WHERE statut='en_attente' ORDER BY id DESC LIMIT {$limit}" )->fetchAll();
	}

	public static function history( $limit = 100 ) {
		$limit = (int) $limit;
		return FKC_DB::q( "SELECT * FROM validations WHERE statut<>'en_attente' ORDER BY decided_at DESC, id DESC LIMIT {$limit}" )->fetchAll();
	}

	public static function countPending() {
		return (int) FKC_DB::q( "SELECT COUNT(*) FROM validations WHERE statut='en_attente'" )->fetchColumn();
	}

	/** Une référence est-elle déjà en attente de validation ? (évite les doublons). */
	public static function pendingExists( $refType, $refId ) {
		return (bool) FKC_DB::q(
			"SELECT 1 FROM validations WHERE statut='en_attente' AND ref_type=? AND ref_id=?",
			array( (string) $refType, (int) $refId )
		)->fetchColumn();
	}

	/** Une référence a-t-elle une validation approuvée ? */
	public static function approvedExists( $refType, $refId ) {
		return (bool) FKC_DB::q(
			"SELECT 1 FROM validations WHERE statut='approuve' AND ref_type=? AND ref_id=?",
			array( (string) $refType, (int) $refId )
		)->fetchColumn();
	}

	/** Dernière demande pour une référence (toutes décisions confondues). */
	public static function latestFor( $refType, $refId ) {
		$r = FKC_DB::q(
			'SELECT * FROM validations WHERE ref_type=? AND ref_id=? ORDER BY id DESC LIMIT 1',
			array( (string) $refType, (int) $refId )
		)->fetch();
		return $r ?: null;
	}

	/** Seuil de validation des factures (TTC). 0 = désactivé. */
	public static function seuilFacture() {
		return class_exists( 'FKC_License' ) ? (float) FKC_License::param( 'wf_seuil_facture', 0 ) : 0.0;
	}

	/**
	 * Approuve ou refuse une demande en attente, puis notifie le demandeur.
	 * @return bool succès (false si déjà traitée ou statut invalide).
	 */
	public static function decide( $id, $statut, $validatorId, $validatorNom, $motif = '' ) {
		$statut = in_array( $statut, array( 'approuve', 'refuse' ), true ) ? $statut : null;
		if ( ! $statut ) { return false; }
		$v = self::find( $id );
		if ( ! $v || 'en_attente' !== $v['statut'] ) { return false; }
		FKC_DB::q(
			"UPDATE validations SET statut=?, validateur_id=?, validateur_nom=?, motif=?, decided_at=datetime('now','localtime') WHERE id=?",
			array(
				$statut,
				(int) $validatorId ?: null,
				trim( (string) $validatorNom ) ?: null,
				trim( (string) $motif ) ?: null,
				(int) $id,
			)
		);
		if ( ! empty( $v['demandeur_id'] ) && class_exists( 'FKC_Notification' ) ) {
			$lib  = 'approuve' === $statut ? 'approuvée' : 'refusée';
			$type = 'approuve' === $statut ? 'succes' : 'alerte';
			$msg  = $v['objet'] . ( '' !== trim( (string) $motif ) ? ' · ' . trim( (string) $motif ) : '' );
			FKC_Notification::create( (int) $v['demandeur_id'], 'Demande ' . $lib, $msg, $type, $v['url'] ?: ( 'validations/' . (int) $id ) );
		}
		return true;
	}
}
