<?php
/** Workflow de validation — centre « À valider ». @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ValidationController {

	public function index() {
		FKC_View::render( 'workflow::index', array(
			'title'   => 'Validations',
			'pending' => FKC_Validation::pending(),
			'history' => FKC_Validation::history( 50 ),
			'seuil'   => FKC_Validation::seuilFacture(),
			'flash'   => $this->flash(),
		) );
	}

	/** Réglage du seuil de validation des factures (0 = désactivé). */
	public function settings() {
		$seuil = (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) ( $_POST['wf_seuil_facture'] ?? 0 ) );
		if ( $seuil < 0 ) { $seuil = 0; }
		FKC_License::setParam( 'wf_seuil_facture', $seuil );
		$this->setFlash( $seuil > 0 ? ( 'Seuil de validation des factures fixé à ' . number_format( $seuil, 0, ',', ' ' ) . ' F.' ) : 'Validation des factures désactivée (seuil à 0).' );
		redirect( 'validations' );
	}

	public function show( $id ) {
		$v = FKC_Validation::find( $id );
		if ( ! $v ) { redirect( 'validations' ); }
		FKC_View::render( 'workflow::show', array(
			'title'   => 'Validation #' . (int) $id,
			'v'       => $v,
			'is_self' => ! empty( $v['demandeur_id'] ) && (int) $v['demandeur_id'] === (int) FKC_Auth::id(),
			'flash'   => $this->flash(),
		) );
	}

	public function decide( $id ) {
		$v = FKC_Validation::find( $id );
		if ( ! $v ) { redirect( 'validations' ); }
		if ( 'en_attente' !== $v['statut'] ) { $this->setFlash( 'Cette demande a déjà été traitée.', 'err' ); redirect( 'validations/' . (int) $id ); }
		// Sécurité : un demandeur ne peut pas valider sa propre demande.
		if ( ! empty( $v['demandeur_id'] ) && (int) $v['demandeur_id'] === (int) FKC_Auth::id() ) {
			$this->setFlash( 'Vous ne pouvez pas valider votre propre demande.', 'err' ); redirect( 'validations/' . (int) $id );
		}
		$dec = $_POST['decision'] ?? '';
		$statut = ( 'approuve' === $dec ) ? 'approuve' : ( ( 'refuse' === $dec ) ? 'refuse' : '' );
		if ( '' === $statut ) { $this->setFlash( 'Décision invalide.', 'err' ); redirect( 'validations/' . (int) $id ); }
		$motif = trim( (string) ( $_POST['motif'] ?? '' ) );
		if ( 'refuse' === $statut && '' === $motif ) { $this->setFlash( 'Un motif est requis pour un refus.', 'err' ); redirect( 'validations/' . (int) $id ); }
		$u = FKC_Auth::user();
		FKC_Validation::decide( (int) $id, $statut, FKC_Auth::id(), $u['nom_complet'] ?? '', $motif );
		$this->setFlash( 'approuve' === $statut ? 'Demande approuvée.' : 'Demande refusée.' );
		redirect( 'validations/' . (int) $id );
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_wf'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_wf'] ?? null; unset( $_SESSION['__flash_wf'] ); return $m; }
}
