<?php
/** Écrans du moteur de processus : définitions (admin) + instances. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ProcessusController {

	/** Liste des définitions + instances en cours. */
	public function index() {
		FKC_WorkflowEngine::ensure();
		if ( class_exists( 'FKC_Packs' ) ) { FKC_Packs::ensureSociete(); }
		FKC_View::render( 'workflow::processus', array(
			'title'       => 'Processus métier',
			'module'      => 'workflow',
			'definitions' => FKC_WorkflowEngine::definitions(),
			'instances'   => FKC_WorkflowEngine::enCours( 100 ),
			'flash'       => $this->flash(),
		) );
	}

	/** Éditeur JSON d'une définition (réservé à l'administrateur). */
	public function edit( $id ) {
		FKC_WorkflowEngine::ensure();
		$row = FKC_DB::q( 'SELECT * FROM wf_definitions WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $row ) { redirect( 'workflow/processus' ); }
		FKC_View::render( 'workflow::processus_form', array(
			'title' => 'Processus — ' . $row['libelle'], 'module' => 'workflow',
			'row'   => $row, 'flash' => $this->flash(),
		) );
	}

	public function update( $id ) {
		list( $ok, $msg ) = FKC_WorkflowEngine::saveDefinition( (int) $id, (string) ( $_POST['definition'] ?? '' ) );
		$_SESSION['__wf_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $ok ? 'workflow/processus' : 'workflow/processus/' . (int) $id . '/modifier' );
	}

	public function toggle( $id ) {
		FKC_WorkflowEngine::ensure();
		FKC_DB::q( 'UPDATE wf_definitions SET actif=1-actif WHERE id=?', array( (int) $id ) );
		redirect( 'workflow/processus' );
	}

	/** Fiche d'une instance : état, actions disponibles, historique. */
	public function instance( $id ) {
		$i = FKC_WorkflowEngine::instance( (int) $id );
		if ( ! $i ) { redirect( 'workflow/processus' ); }
		FKC_View::render( 'workflow::processus_instance', array(
			'title'      => 'Processus #' . (int) $id, 'module' => 'workflow',
			'instance'   => $i,
			'actions'    => FKC_WorkflowEngine::actionsDisponibles( $i ),
			'historique' => FKC_WorkflowEngine::historique( (int) $id ),
			'flash'      => $this->flash(),
		) );
	}

	/** Applique une action de workflow depuis la fiche d'instance. */
	public function action( $id ) {
		list( $ok, $msg ) = FKC_WorkflowEngine::transition( (int) $id, (string) ( $_POST['action'] ?? '' ), trim( (string) ( $_POST['commentaire'] ?? '' ) ) );
		$_SESSION['__wf_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( 'workflow/processus/instances/' . (int) $id );
	}

	protected function flash() {
		$f = $_SESSION['__wf_flash'] ?? null;
		unset( $_SESSION['__wf_flash'] );
		return $f;
	}
}
