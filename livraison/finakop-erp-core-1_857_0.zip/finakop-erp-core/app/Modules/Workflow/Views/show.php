<?php /** @var array $v @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres/processus', 'backLabel' => 'Processus' ) );
$badge = function ( $s ) {
	$map = array( 'en_attente' => array( 'var(--warn-bg)', 'var(--warn)' ), 'approuve' => array( 'var(--ok-bg)', 'var(--ok)' ), 'refuse' => array( 'var(--danger-bg)', 'var(--danger)' ) );
	$c = $map[ $s ] ?? array( 'var(--panel2)', 'var(--text)' );
	return '<span class="tag" style="background:' . $c[0] . ';color:' . $c[1] . '">' . e( FKC_Validation::statutLabel( $s ) ) . '</span>';
};
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( in_array( $flash['type'], array('ok','err','warn'), true ) ? $flash['type'] : 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card" style="max-width:640px">
	<div class="card-head"><h2>Demande de validation <?= $badge( $v['statut'] ) ?></h2>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'validations' ) ) ?>">← Retour</a></div>
	<div class="card-body">
		<table class="kv">
			<tr><th>Objet</th><td><strong><?= e( $v['objet'] ) ?></strong></td></tr>
			<tr><th>Type</th><td><?= e( FKC_Validation::typeLabel( $v['type'] ) ) ?></td></tr>
			<tr><th>Montant</th><td><?= $v['montant'] > 0 ? e( fkc_money( $v['montant'] ) ) . ' F' : '—' ?></td></tr>
			<tr><th>Demandeur</th><td><?= e( $v['demandeur_nom'] ?: '—' ) ?></td></tr>
			<tr><th>Créée le</th><td><?= e( $v['created_at'] ) ?></td></tr>
			<?php if ( 'en_attente' !== $v['statut'] ) : ?>
				<tr><th>Décision</th><td><?= $badge( $v['statut'] ) ?> par <?= e( $v['validateur_nom'] ?: '—' ) ?> le <?= e( $v['decided_at'] ?: '—' ) ?></td></tr>
				<?php if ( ! empty( $v['motif'] ) ) : ?><tr><th>Motif</th><td><?= e( $v['motif'] ) ?></td></tr><?php endif; ?>
			<?php endif; ?>
		</table>
		<?php if ( ! empty( $v['url'] ) ) : ?>
			<p style="margin-top:14px"><a class="btn btn-ghost btn-sm" href="<?= e( url( ltrim( (string) $v['url'], '/' ) ) ) ?>">Ouvrir le document lié →</a></p>
		<?php endif; ?>
		<?php if ( 'en_attente' === $v['statut'] ) : ?>
			<?php if ( ! empty( $is_self ) ) : ?>
				<p class="alert alert-warn" style="margin-top:14px">Vous êtes le demandeur : la décision revient à un autre validateur.</p>
			<?php else : ?>
				<form method="post" action="<?= e( url( 'validations/' . (int) $v['id'] . '/decider' ) ) ?>" style="margin-top:16px">
					<?= FKC_Csrf::field() ?>
					<label class="fld"><span>Motif / commentaire <span class="muted">(obligatoire en cas de refus)</span></span>
						<textarea name="motif" rows="2" placeholder="Commentaire de décision…"></textarea></label>
					<div class="actions" style="gap:8px">
						<button class="btn btn-primary" name="decision" value="approuve" type="submit">✓ Approuver</button>
						<button class="btn" name="decision" value="refuse" type="submit" style="background:var(--danger-bg);color:var(--danger)" onclick="var m=this.form.motif;if(!m.value.trim()){alert('Un motif est requis pour un refus.');m.focus();return false;}">✕ Refuser</button>
					</div>
				</form>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</div>
