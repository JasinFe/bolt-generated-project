<?php /** @var array $instance @var array $actions @var array $historique @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'workflow', 'back' => 'workflow/processus', 'backLabel' => 'Processus' ) );
$ctx = json_decode( (string) ( $instance['contexte'] ?? '' ), true ) ?: array();
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( in_array( $flash['type'], array( 'ok', 'err', 'warn' ), true ) ? $flash['type'] : 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="margin-bottom:16px">
	<div class="card-head"><h2>Instance #<?= (int) $instance['id'] ?> — <code><?= e( $instance['code'] ) ?></code></h2></div>
	<div class="card-body" style="display:flex;gap:28px;flex-wrap:wrap;align-items:flex-start">
		<div>
			<div class="muted" style="font-size:12px">Objet</div>
			<div><strong><?= e( ( $instance['ref_type'] ?: '—' ) . ( $instance['ref_id'] ? ' #' . (int) $instance['ref_id'] : '' ) ) ?></strong></div>
		</div>
		<div>
			<div class="muted" style="font-size:12px">État courant</div>
			<div><span class="tag" style="background:var(--warn-bg);color:var(--warn)"><?= e( $instance['etat'] ) ?></span></div>
		</div>
		<?php if ( isset( $ctx['montant'] ) || isset( $ctx['ttc'] ) ) : ?>
		<div>
			<div class="muted" style="font-size:12px">Montant</div>
			<div><strong><?= e( fkc_money( $ctx['montant'] ?? $ctx['ttc'] ) ) ?> F</strong></div>
		</div>
		<?php endif; ?>
		<?php if ( ! empty( $ctx['ecriture_id'] ) ) : ?>
		<div>
			<div class="muted" style="font-size:12px">Écriture générée</div>
			<div><a href="<?= e( url( 'comptabilite/ecritures/' . (int) $ctx['ecriture_id'] ) ) ?>">Écriture #<?= (int) $ctx['ecriture_id'] ?> →</a></div>
		</div>
		<?php endif; ?>
	</div>
	<?php if ( $actions ) : ?>
	<div class="card-body" style="border-top:1px solid var(--line);display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
		<?php foreach ( $actions as $a ) : ?>
		<form method="post" action="<?= e( url( 'workflow/processus/instances/' . (int) $instance['id'] . '/action' ) ) ?>" style="display:flex;gap:8px;align-items:flex-end;margin:0">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="action" value="<?= e( $a['action'] ) ?>">
			<label class="fld" style="margin:0"><span>Commentaire (facultatif)</span><input name="commentaire" style="width:220px"></label>
			<button class="btn btn-primary btn-sm" type="submit"><?= e( ucfirst( str_replace( '_', ' ', $a['action'] ) ) ) ?> → <?= e( $a['vers'] ) ?></button>
		</form>
		<?php endforeach; ?>
	</div>
	<?php endif; ?>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Historique</h2></div>
	<table class="table"><thead><tr><th>Date</th><th>Transition</th><th>Action</th><th>Acteur</th><th>Commentaire</th></tr></thead><tbody>
	<?php foreach ( $historique as $h ) : ?>
		<tr>
			<td class="muted" style="font-size:12px"><?= e( $h['created_at'] ) ?></td>
			<td><?= e( $h['de_etat'] ? $h['de_etat'] . ' → ' : '' ) ?><strong><?= e( $h['vers_etat'] ) ?></strong></td>
			<td><?= e( $h['action'] ?: '—' ) ?></td>
			<td><?= e( $h['acteur_nom'] ?: '—' ) ?></td>
			<td class="muted"><?= e( $h['commentaire'] ?: '—' ) ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody></table>
</div>
