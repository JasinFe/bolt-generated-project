<?php /** @var array $pending @var array $history @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$badge = function ( $s ) {
	$map = array( 'en_attente' => array( 'var(--warn-bg)', 'var(--warn)' ), 'approuve' => array( 'var(--ok-bg)', 'var(--ok)' ), 'refuse' => array( 'var(--danger-bg)', 'var(--danger)' ) );
	$c = $map[ $s ] ?? array( 'var(--panel2)', 'var(--text)' );
	return '<span class="tag" style="background:' . $c[0] . ';color:' . $c[1] . '">' . e( FKC_Validation::statutLabel( $s ) ) . '</span>';
};
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( in_array( $flash['type'], array('ok','err','warn'), true ) ? $flash['type'] : 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="margin-bottom:16px">
	<div class="card-body" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
		<form method="post" action="<?= e( url( 'validations/parametres' ) ) ?>" style="display:flex;align-items:flex-end;gap:10px;margin:0">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0"><span>Seuil de validation des factures (TTC, F — 0 = désactivé)</span>
				<input class="num" name="wf_seuil_facture" value="<?= e( (int) ( $seuil ?? 0 ) ) ?>" style="width:160px"></label>
			<button class="btn btn-ghost btn-sm" type="submit">Enregistrer le seuil</button>
		</form>
		<span class="muted" style="font-size:12.5px"><?= ( $seuil ?? 0 ) > 0 ? 'Au-dessus de ' . e( fkc_money( $seuil ) ) . ' F, une facture doit être approuvée avant comptabilisation.' : 'Validation des factures désactivée.' ?></span>
	</div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>À valider<?= $pending ? ' <span class="tag" style="background:var(--orange);color:#241500">' . count( $pending ) . '</span>' : '' ?></h2></div>
	<table class="table"><thead><tr><th>Objet</th><th>Type</th><th class="num">Montant</th><th>Demandeur</th><th>Date</th><th></th></tr></thead><tbody>
	<?php if ( ! $pending ) : ?><tr><td colspan="6" class="empty">Aucune demande en attente.</td></tr>
	<?php else : foreach ( $pending as $v ) : ?><tr>
		<td><a href="<?= e( url( 'validations/' . (int) $v['id'] ) ) ?>"><strong><?= e( $v['objet'] ) ?></strong></a></td>
		<td><?= e( FKC_Validation::typeLabel( $v['type'] ) ) ?></td>
		<td class="num"><?= $v['montant'] > 0 ? e( fkc_money( $v['montant'] ) ) : '—' ?></td>
		<td><?= e( $v['demandeur_nom'] ?: '—' ) ?></td>
		<td><?= e( $v['created_at'] ) ?></td>
		<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'validations/' . (int) $v['id'] ) ) ?>">Examiner →</a></td>
	</tr><?php endforeach; endif; ?>
	</tbody></table>
</div>

<?php if ( $history ) : ?>
<div class="card card-flush" style="margin-top:16px">
	<div class="card-head"><h2>Décisions récentes</h2></div>
	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer l\'historique…' ) ); ?>
	<table class="table"><thead><tr><th>Objet</th><th>Type</th><th class="num">Montant</th><th>Statut</th><th>Validateur</th><th>Décidé le</th></tr></thead><tbody>
	<?php foreach ( $history as $v ) : ?><tr>
		<td><a href="<?= e( url( 'validations/' . (int) $v['id'] ) ) ?>"><?= e( $v['objet'] ) ?></a></td>
		<td><?= e( FKC_Validation::typeLabel( $v['type'] ) ) ?></td>
		<td class="num"><?= $v['montant'] > 0 ? e( fkc_money( $v['montant'] ) ) : '—' ?></td>
		<td><?= $badge( $v['statut'] ) ?></td>
		<td><?= e( $v['validateur_nom'] ?: '—' ) ?></td>
		<td><?= e( $v['decided_at'] ?: '—' ) ?></td>
	</tr><?php endforeach; ?>
	</tbody></table>
</div>
<?php endif; ?>
