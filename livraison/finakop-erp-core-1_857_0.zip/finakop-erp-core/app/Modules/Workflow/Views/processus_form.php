<?php /** @var array $row @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'workflow', 'back' => 'workflow/processus', 'backLabel' => 'Processus' ) );
$json = json_encode( json_decode( (string) $row['definition'], true ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( in_array( $flash['type'], array( 'ok', 'err', 'warn' ), true ) ? $flash['type'] : 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card">
	<div class="card-head"><h2>⚙️ <?= e( $row['libelle'] ) ?> <span class="muted" style="font-weight:400;font-size:13px">(<?= e( $row['code'] ) ?>)</span></h2></div>
	<div class="card-body">
		<p class="muted" style="font-size:12.5px;margin-top:0">
			Structure : <code>etats</code> (liste ordonnée, le premier est l'état initial), <code>transitions</code>
			(<code>de</code>, <code>vers</code>, <code>action</code> ou <code>auto:true</code>, <code>roles</code> = <code>admin</code> ou codes de modules,
			<code>condition</code> ex. <code>montant &gt; 0</code>, <code>effets</code> : <code>{"type":"posting","evenement":"…"}</code>,
			<code>{"type":"notification","titre":"…","message":"…"}</code> ou un type de handler de pack).
		</p>
		<form method="post" action="<?= e( url( 'workflow/processus/' . (int) $row['id'] ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Définition (JSON)</span>
				<textarea name="definition" rows="24" style="width:100%;font-family:ui-monospace,Consolas,monospace;font-size:12.5px;line-height:1.5"><?= e( $json ) ?></textarea>
			</label>
			<div style="display:flex;gap:10px;margin-top:12px">
				<button class="btn btn-primary" type="submit">Enregistrer le processus</button>
				<a class="btn btn-ghost" href="<?= e( url( 'workflow/processus' ) ) ?>">Annuler</a>
			</div>
		</form>
	</div>
</div>
