<?php /** @var array $definitions @var array $instances @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'workflow', 'back' => 'validations', 'backLabel' => 'Validations' ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( in_array( $flash['type'], array( 'ok', 'err', 'warn' ), true ) ? $flash['type'] : 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card card-flush" style="margin-bottom:16px">
	<div class="card-head"><h2>⚙️ Processus métier (Workflow Engine)</h2></div>
	<div class="card-body" style="padding-top:0">
		<p class="muted" style="font-size:12.5px;margin:6px 0 12px">Chaque processus est une machine à états déclarative : états, transitions (action, rôles, condition) et effets (comptabilisation automatique, notification). Les packs métier livrent des processus par défaut ; adaptez-les ici sans développement.</p>
	</div>
	<table class="table"><thead><tr><th>Code</th><th>Libellé</th><th>Objet</th><th>Pack</th><th>États</th><th>Actif</th><th></th></tr></thead><tbody>
	<?php if ( ! $definitions ) : ?><tr><td colspan="7" class="empty">Aucun processus. Les packs métier en installent automatiquement à la première utilisation.</td></tr>
	<?php else : foreach ( $definitions as $d ) :
		$def = json_decode( (string) $d['definition'], true ) ?: array(); ?>
		<tr>
			<td><code><?= e( $d['code'] ) ?></code></td>
			<td><strong><?= e( $d['libelle'] ) ?></strong></td>
			<td><?= e( $d['objet'] ?: '—' ) ?></td>
			<td><?= e( $d['pack'] ?: '—' ) ?></td>
			<td class="muted" style="font-size:12px"><?= e( implode( ' → ', array_slice( (array) ( $def['etats'] ?? array() ), 0, 6 ) ) ) ?></td>
			<td><?= $d['actif'] ? '<span class="tag" style="background:var(--ok-bg);color:var(--ok)">Actif</span>' : '<span class="tag">Inactif</span>' ?></td>
			<td class="num" style="white-space:nowrap">
				<?php if ( FKC_Auth::isAdmin() ) : ?>
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'workflow/processus/' . (int) $d['id'] . '/modifier' ) ) ?>">Modifier</a>
				<form method="post" action="<?= e( url( 'workflow/processus/' . (int) $d['id'] . '/basculer' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit"><?= $d['actif'] ? 'Désactiver' : 'Activer' ?></button></form>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody></table>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Instances en cours</h2></div>
	<table class="table"><thead><tr><th>#</th><th>Processus</th><th>Objet</th><th>État</th><th>Mise à jour</th><th></th></tr></thead><tbody>
	<?php if ( ! $instances ) : ?><tr><td colspan="6" class="empty">Aucune instance de processus.</td></tr>
	<?php else : foreach ( $instances as $i ) : ?>
		<tr>
			<td><?= (int) $i['id'] ?></td>
			<td><strong><?= e( $i['definition_libelle'] ) ?></strong></td>
			<td class="muted"><?= e( ( $i['ref_type'] ?: '—' ) . ( $i['ref_id'] ? ' #' . (int) $i['ref_id'] : '' ) ) ?></td>
			<td><span class="tag"><?= e( $i['etat'] ) ?></span></td>
			<td class="muted" style="font-size:12px"><?= e( $i['updated_at'] ?: $i['created_at'] ) ?></td>
			<td class="num"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'workflow/processus/instances/' . (int) $i['id'] ) ) ?>">Ouvrir</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody></table>
</div>
