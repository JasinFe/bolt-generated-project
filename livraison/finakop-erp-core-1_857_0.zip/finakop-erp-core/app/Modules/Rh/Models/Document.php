<?php
/** Documents employé (contrat, diplômes, certificats…). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhDocument {
	public static function types() { return array( 'contrat'=>'Contrat','diplome'=>'Diplôme','certificat'=>'Certificat','cni'=>'Pièce d\'identité','autre'=>'Autre' ); }
	public static function forEmploye( $employeId ) {
		return FKC_DB::q( 'SELECT * FROM rh_documents WHERE employe_id=? ORDER BY created_at DESC', array( (int) $employeId ) )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO rh_documents(employe_id,type,libelle,url,date) VALUES(?,?,?,?,?)',
			array( (int) $d['employe_id'], isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'autre',
				trim( (string) $d['libelle'] ), trim( (string) ( $d['url'] ?? '' ) ) ?: null, trim( (string) ( $d['date'] ?? '' ) ) ?: null ) );
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM rh_documents WHERE id=?', array( (int) $id ) ); }
}
