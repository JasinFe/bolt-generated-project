<?php
/**
 * Pointage du personnel (badge, saisie manuelle). Table « rh_pointages ».
 *
 * ─────────────────────────────────────────────────────────────────────────
 * POURQUOI CE FICHIER EXISTE (1.561.0)
 *
 * Le moteur de scan déclarait depuis longtemps un contexte « Pointage du
 * personnel » (Core/ScanResolvers.php), avec son résolveur d'employé, son
 * action « badge » et ses deux routes annoncées : `rh/pointage` et
 * `rh/presences`. Or :
 *
 *   — AUCUNE de ces deux routes n'existait dans le routeur ; le contexte ne
 *     pouvait donc jamais s'activer, et un scan d'employé retombait sur
 *     « identification » — le lecteur affichait au lieu d'agir ;
 *   — l'action `badge` renvoyait un tableau `pointage_rh` que PERSONNE ne
 *     lisait : le badge était lu, l'horodatage calculé, puis jeté ;
 *   — le résolveur de recherche interrogeait une table `employes` et une
 *     colonne `prenoms` QUI N'EXISTENT PAS (le référentiel est
 *     `paie_employes`, colonne `prenom`). L'exception étant avalée par un
 *     try/catch, la recherche renvoyait toujours une liste vide : impossible
 *     de badger quelqu'un dont on n'avait pas le code exact.
 *
 * C'était une capacité entièrement décorative — le défaut que ce produit a
 * déjà corrigé ailleurs (1.520.140) et qui s'était réinstallé ici. Plutôt
 * que de retirer le contexte, on lui donne son moteur : le pointage est le
 * seul fait qui manquait entre le module RH et le calcul des absences.
 * ─────────────────────────────────────────────────────────────────────────
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhPointage {

	public static function sens() {
		return array( 'entree' => 'Entrée', 'sortie' => 'Sortie' );
	}

	/**
	 * Enregistre un pointage.
	 *
	 * Le SENS n'est pas imposé par l'écran : il se déduit du dernier
	 * pointage du jour, parce qu'un lecteur de badge n'a qu'un bouton. Une
	 * valeur explicite reste prioritaire (saisie de rattrapage).
	 *
	 * @return array{bool,string,int}
	 */
	public static function create( $d ) {
		$empId = (int) ( $d['employe_id'] ?? 0 );
		if ( ! $empId || ! FKC_Employe::find( $empId ) ) { return array( false, 'Employé introuvable.', 0 ); }
		$horo = trim( (string) ( $d['horodatage'] ?? '' ) ) ?: date( 'Y-m-d H:i:s' );
		$ts   = strtotime( $horo );
		if ( ! $ts ) { return array( false, 'Horodatage invalide.', 0 ); }
		$horo = date( 'Y-m-d H:i:s', $ts );
		$jour = date( 'Y-m-d', $ts );

		$sens = (string) ( $d['sens'] ?? '' );
		if ( ! isset( self::sens()[ $sens ] ) ) { $sens = self::sensSuivant( $empId, $jour ); }

		// Un doublon à la minute près n'est pas un pointage : c'est un badge
		// passé deux fois devant le lecteur. On le refuse en le disant.
		$dup = FKC_DB::q(
			'SELECT id FROM rh_pointages WHERE employe_id=? AND horodatage=? AND sens=?',
			array( $empId, $horo, $sens )
		)->fetch();
		if ( $dup ) { return array( false, 'Pointage déjà enregistré à cette seconde.', (int) $dup['id'] ); }

		FKC_DB::q(
			'INSERT INTO rh_pointages(employe_id,jour,sens,horodatage,source,note,created_by) VALUES(?,?,?,?,?,?,?)',
			array(
				$empId, $jour, $sens, $horo,
				in_array( $d['source'] ?? '', array( 'badge', 'saisie', 'import' ), true ) ? $d['source'] : 'saisie',
				trim( (string) ( $d['note'] ?? '' ) ) ?: null,
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
			)
		);
		return array( true, self::sens()[ $sens ] . ' enregistrée à ' . date( 'H:i', $ts ) . '.', (int) FKC_DB::conn()->lastInsertId() );
	}

	/** Sens attendu au prochain badge : alterne à partir du dernier du jour. */
	public static function sensSuivant( $employeId, $jour = null ) {
		$jour = $jour ?: date( 'Y-m-d' );
		$last = FKC_DB::q(
			'SELECT sens FROM rh_pointages WHERE employe_id=? AND jour=? ORDER BY horodatage DESC, id DESC LIMIT 1',
			array( (int) $employeId, $jour )
		)->fetch();
		return ( $last && 'entree' === $last['sens'] ) ? 'sortie' : 'entree';
	}

	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM rh_pointages WHERE id=?', array( (int) $id ) ); }

	/** Pointages d'un jour, tous employés, avec le nom. */
	public static function duJour( $jour ) {
		return FKC_DB::q(
			'SELECT p.*, e.nom, e.prenom, e.matricule FROM rh_pointages p
			 JOIN paie_employes e ON e.id=p.employe_id
			 WHERE p.jour=? ORDER BY p.horodatage DESC, p.id DESC',
			array( (string) $jour )
		)->fetchAll();
	}

	public static function forEmploye( $employeId, $limit = 100 ) {
		$limit = (int) $limit;
		return FKC_DB::q(
			"SELECT * FROM rh_pointages WHERE employe_id=? ORDER BY horodatage DESC LIMIT {$limit}",
			array( (int) $employeId )
		)->fetchAll();
	}

	/**
	 * Synthèse d'une période AAAA-MM : par employé, jours pointés et heures
	 * cumulées (entrée→sortie appariées dans l'ordre).
	 *
	 * Une entrée sans sortie n'est PAS comptée en heures : elle est signalée.
	 * Compter une journée entière sur une sortie oubliée serait pire que ne
	 * rien compter — c'est une heure supplémentaire née d'un oubli.
	 */
	public static function synthese( $periode ) {
		$rows = FKC_DB::q(
			'SELECT p.employe_id, p.jour, p.sens, p.horodatage, e.nom, e.prenom
			   FROM rh_pointages p JOIN paie_employes e ON e.id=p.employe_id
			  WHERE substr(p.jour,1,7)=? ORDER BY p.employe_id, p.horodatage, p.id',
			array( (string) $periode )
		)->fetchAll();
		$out = array();
		$ouvert = array(); // employe_id|jour => timestamp d'entrée en cours
		foreach ( $rows as $r ) {
			$eid = (int) $r['employe_id'];
			if ( ! isset( $out[ $eid ] ) ) {
				$out[ $eid ] = array(
					'employe_id' => $eid,
					'nom' => trim( ( $r['prenom'] ?? '' ) . ' ' . $r['nom'] ),
					'jours' => array(), 'heures' => 0.0, 'incomplets' => 0,
				);
			}
			$out[ $eid ]['jours'][ $r['jour'] ] = true;
			$cle = $eid . '|' . $r['jour'];
			if ( 'entree' === $r['sens'] ) {
				if ( isset( $ouvert[ $cle ] ) ) { $out[ $eid ]['incomplets']++; }
				$ouvert[ $cle ] = strtotime( $r['horodatage'] );
			} else {
				if ( isset( $ouvert[ $cle ] ) ) {
					$out[ $eid ]['heures'] += max( 0, strtotime( $r['horodatage'] ) - $ouvert[ $cle ] ) / 3600;
					unset( $ouvert[ $cle ] );
				} else {
					$out[ $eid ]['incomplets']++;
				}
			}
		}
		foreach ( $ouvert as $cle => $t ) {
			$eid = (int) explode( '|', $cle )[0];
			if ( isset( $out[ $eid ] ) ) { $out[ $eid ]['incomplets']++; }
		}
		foreach ( $out as $eid => $v ) {
			$out[ $eid ]['nb_jours'] = count( $v['jours'] );
			$out[ $eid ]['heures']   = round( $v['heures'], 2 );
			unset( $out[ $eid ]['jours'] );
		}
		usort( $out, function ( $a, $b ) { return strcmp( $a['nom'], $b['nom'] ); } );
		return $out;
	}

	/**
	 * Heures supplémentaires d'un salarié sur une période AAAA-MM (1.843.3),
	 * à partir des pointages appariés (entrée → sortie, même jour).
	 *
	 * Les heures sont comptées PAR SEMAINE (lundi-dimanche) : au-delà de la
	 * durée hebdomadaire (40 h), les 6 premières sont majorées de 15 %, les
	 * suivantes de 50 %. Seuls les jours du mois payé comptent, si bien
	 * qu'une semaine à cheval sur deux mois est partagée entre eux. Une
	 * entrée sans sortie n'est pas comptée : elle est signalée.
	 *
	 * @return array{hs_15:float,hs_50:float,heures:float,semaines:int,incomplets:int}
	 */
	public static function heuresSupp( $employeId, $periode, $params = array() ) {
		$hebdo = (float) ( $params['hs_duree_hebdo'] ?? 40 );
		$t15   = (float) ( $params['hs_tranche_15'] ?? 6 );
		$rows = FKC_DB::q(
			'SELECT jour, sens, horodatage FROM rh_pointages WHERE employe_id=? AND substr(jour,1,7)=? ORDER BY horodatage, id',
			array( (int) $employeId, (string) $periode )
		)->fetchAll();
		$parSemaine = array(); $ouvert = array(); $incomplets = 0; $total = 0.0;
		foreach ( $rows as $r ) {
			$j = (string) $r['jour'];
			if ( 'entree' === $r['sens'] ) {
				if ( isset( $ouvert[ $j ] ) ) { $incomplets++; }
				$ouvert[ $j ] = strtotime( $r['horodatage'] );
				continue;
			}
			if ( ! isset( $ouvert[ $j ] ) ) { $incomplets++; continue; }
			$h = max( 0, strtotime( $r['horodatage'] ) - $ouvert[ $j ] ) / 3600;
			unset( $ouvert[ $j ] );
			$sem = date( 'o-W', strtotime( $j ) );
			$parSemaine[ $sem ] = ( $parSemaine[ $sem ] ?? 0.0 ) + $h;
			$total += $h;
		}
		$incomplets += count( $ouvert );
		$hs15 = 0.0; $hs50 = 0.0;
		foreach ( $parSemaine as $h ) {
			$sup = max( 0.0, $h - $hebdo );
			$a = min( $sup, $t15 );
			$hs15 += $a; $hs50 += $sup - $a;
		}
		return array( 'hs_15' => round( $hs15, 2 ), 'hs_50' => round( $hs50, 2 ), 'heures' => round( $total, 2 ),
			'semaines' => count( $parSemaine ), 'incomplets' => $incomplets );
	}
}
