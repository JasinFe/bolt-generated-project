<?php
/** Avances & prêts : validation, échéancier, déduction automatique sur paie. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhAvance {

	public static function types() { return array( 'avance'=>'Avance sur salaire', 'pret'=>'Prêt' ); }

	public static function all( $statut = '' ) {
		$w = ''; $p = array();
		if ( '' !== $statut ) { $w = ' WHERE a.statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT a.*, e.nom, e.prenom FROM rh_avances a JOIN paie_employes e ON e.id=a.employe_id{$w} ORDER BY a.date DESC", $p )->fetchAll();
	}
	public static function forEmploye( $employeId ) {
		return FKC_DB::q( 'SELECT * FROM rh_avances WHERE employe_id=? ORDER BY date DESC', array( (int) $employeId ) )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM rh_avances WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		$r['echeances'] = FKC_DB::q( 'SELECT * FROM rh_avance_echeances WHERE avance_id=? ORDER BY mois', array( (int) $id ) )->fetchAll();
		return $r;
	}
	public static function enAttente() { return (int) FKC_DB::q( "SELECT COUNT(*) FROM rh_avances WHERE statut='demande'" )->fetchColumn(); }

	public static function create( $d ) {
		$type = isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'avance';
		$montant = (float) ( $d['montant'] ?? 0 );
		$duree = 'pret' === $type ? max( 1, (int) ( $d['duree_mois'] ?? 1 ) ) : 1;
		$mensualite = 'pret' === $type ? round( $montant / $duree ) : $montant;
		FKC_DB::q( 'INSERT INTO rh_avances(employe_id,type,montant,date,duree_mois,mensualite,motif,statut,reste_du) VALUES(?,?,?,?,?,?,?,?,?)',
			array( (int) $d['employe_id'], $type, $montant, $d['date'] ?? date( 'Y-m-d' ), $duree, $mensualite,
				trim( (string) ( $d['motif'] ?? '' ) ) ?: null, 'demande', $montant ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/** Validation : génère l'échéancier (prêt = mensualités ; avance = 1 prélèvement le mois suivant). */
	public static function valider( $id ) {
		$a = self::find( $id ); if ( ! $a || 'demande' !== $a['statut'] ) { return; }
		FKC_DB::q( 'DELETE FROM rh_avance_echeances WHERE avance_id=?', array( (int) $id ) );
		$start = strtotime( ( $a['date'] ?: date( 'Y-m-d' ) ) . ' first day of next month' );
		$duree = 'pret' === $a['type'] ? (int) $a['duree_mois'] : 1;
		$reste = (float) $a['montant'];
		for ( $i = 0; $i < $duree; $i++ ) {
			$mois = date( 'Y-m', strtotime( "+{$i} month", $start ) );
			$mt = ( $i === $duree - 1 ) ? $reste : (float) $a['mensualite'];
			FKC_DB::q( 'INSERT INTO rh_avance_echeances(avance_id,mois,montant,statut) VALUES(?,?,?,?)', array( (int) $id, $mois, round( $mt ), 'prevu' ) );
			$reste -= (float) $a['mensualite'];
		}
		FKC_DB::q( "UPDATE rh_avances SET statut='valide' WHERE id=?", array( (int) $id ) );
	}
	public static function refuser( $id ) { FKC_DB::q( "UPDATE rh_avances SET statut='refuse' WHERE id=? AND statut='demande'", array( (int) $id ) ); }

	/**
	 * Supprime une avance — sauf si elle a déjà été retenue sur un bulletin.
	 *
	 * Depuis que le prélèvement existe vraiment (1.561.0), effacer l'avance
	 * effacerait la justification d'une retenue déjà versée au salarié et
	 * déjà comptabilisée dans l'OD de paie. Le refus dit quoi défaire d'abord.
	 *
	 * @return array{bool,string}
	 */
	public static function delete( $id ) {
		$preleve = (int) FKC_DB::q(
			"SELECT COUNT(*) FROM rh_avance_echeances WHERE avance_id=? AND statut='preleve'",
			array( (int) $id )
		)->fetchColumn();
		if ( $preleve > 0 ) {
			return array( false, 'Cette avance a déjà été retenue sur ' . $preleve . ' bulletin(s) de paie. Supprimez d\'abord ces bulletins si la retenue était une erreur.' );
		}
		$a = self::find( $id );
		if ( $a && ! empty( $a['ecriture_id'] ) ) {
			return array( false, 'Le versement de cette avance est comptabilisé (écriture n°' . (int) $a['ecriture_id']
				. '). Contre-passez l\'écriture en comptabilité avant de la supprimer.' );
		}
		if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'rh_avances', (int) $id ) ) {
			return array( false, 'L\'écriture de versement attend au journal temporaire. Traitez-la avant de supprimer l\'avance.' );
		}
		FKC_DB::q( 'DELETE FROM rh_avance_echeances WHERE avance_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM rh_avances WHERE id=?', array( (int) $id ) );
		return array( true, 'Avance supprimée.' );
	}

	/** Total à déduire sur la paie d'un employé pour un mois donné (échéances prévues). */
	/**
	 * Montant DÉDUCTIBLE ce mois : échéances prévues d'avances VERSÉES.
	 *
	 * Le filtre `verse=1` doit rester aligné sur `echeancesDuMois()` : sans
	 * lui, l'écran annonçait « échéance reportée (quotité cessible) » pour
	 * une avance qui n'était en réalité pas versée — un message exact sur le
	 * montant et faux sur la cause, ce qui est pire que le silence : on
	 * cherche à réduire une retenue qui n'a jamais été empêchée par le
	 * plafond. La cause réelle est dite par `echeancesNonVersees()`.
	 */
	public static function deductionPaie( $employeId, $mois ) {
		return (float) FKC_DB::q(
			"SELECT COALESCE(SUM(ec.montant),0) FROM rh_avance_echeances ec
			 JOIN rh_avances a ON a.id=ec.avance_id
			 WHERE a.employe_id=? AND a.statut='valide' AND a.verse=1
			   AND ec.statut='prevu' AND ec.mois=?",
			array( (int) $employeId, (string) $mois )
		)->fetchColumn();
	}

	/** Échéances du mois bloquées faute de versement (montant dû, non retenu). */
	public static function echeancesNonVersees( $employeId, $mois ) {
		return (float) FKC_DB::q(
			"SELECT COALESCE(SUM(ec.montant),0) FROM rh_avance_echeances ec
			 JOIN rh_avances a ON a.id=ec.avance_id
			 WHERE a.employe_id=? AND a.statut='valide' AND a.verse=0
			   AND ec.statut='prevu' AND ec.mois=?",
			array( (int) $employeId, (string) $mois )
		)->fetchColumn();
	}
	/**
	 * Échéances prévues du mois, détaillées (libellé de la ligne de bulletin).
	 *
	 * `a.verse=1` est la condition ajoutée en 1.563.0 : ON NE RETIENT PAS
	 * D'ARGENT À QUELQU'UN À QUI L'ON N'A RIEN REMIS. Valider une avance est
	 * une APPROBATION ; le versement est un décaissement. Tant que la retenue
	 * n'existait pas, confondre les deux ne coûtait rien ; depuis qu'elle
	 * fonctionne, un prêt approuvé mais jamais versé aurait amputé le
	 * salaire du mois suivant.
	 */
	public static function echeancesDuMois( $employeId, $mois ) {
		return FKC_DB::q(
			"SELECT ec.id, ec.avance_id, ec.montant, a.type, a.motif
			   FROM rh_avance_echeances ec JOIN rh_avances a ON a.id=ec.avance_id
			  WHERE a.employe_id=? AND a.statut='valide' AND a.verse=1
			    AND ec.statut='prevu' AND ec.mois=?
			  ORDER BY ec.id",
			array( (int) $employeId, (string) $mois )
		)->fetchAll();
	}

	/* ═══════════ PONT AVANCES → TRÉSORERIE (1.563.0) ═══════════
	 *
	 * LE DEMI-CIRCUIT QUE CE PONT FERME
	 *
	 * Depuis la 1.561.0, le REMBOURSEMENT d'une avance crédite bien le compte
	 * « Personnel, avances » à chaque bulletin. Mais rien ne le DÉBITAIT
	 * jamais : le versement de l'argent au salarié ne produisait aucune
	 * écriture. Le compte partait donc en solde créditeur à mesure des
	 * remboursements — l'entreprise se retrouvait à DEVOIR de l'argent à un
	 * salarié qu'elle était en train de se faire rembourser, ce qui n'a
	 * aucun sens — à moins que le comptable ne pense à saisir le
	 * décaissement à la main, en devinant le bon compte.
	 *
	 * Le versement est désormais un acte du logiciel : il sort la trésorerie
	 * choisie, débite la créance sur le salarié, et c'est lui — non plus la
	 * validation — qui autorise la retenue sur la paie.
	 */

	/** Comptes du versement d'avance (paramétrable). */
	public static function compteAvances() {
		return array( FKC_License::param( 'od_paie_cpt_avances', '421100' ), 'Personnel, avances' );
	}

	/** Avances validées dont l'argent n'est pas encore sorti. */
	public static function aVerser() {
		return FKC_DB::q(
			"SELECT a.*, e.nom, e.prenom FROM rh_avances a JOIN paie_employes e ON e.id=a.employe_id
			  WHERE a.statut='valide' AND a.verse=0 ORDER BY a.date"
		)->fetchAll();
	}

	/**
	 * Verse l'avance : sortie de trésorerie et créance sur le salarié.
	 *
	 * @return array{bool,string,int|null,int|null} ( ok, message, ecriture_id, brouillon_id )
	 */
	public static function verser( $id, $tresorerieId, $date = null, $brouillard = null ) {
		$a = self::find( $id );
		if ( ! $a ) { return array( false, 'Avance introuvable.', null, null ); }
		if ( 'valide' !== $a['statut'] ) {
			return array( false, 'Seule une avance VALIDÉE se verse — celle-ci est au stade « ' . $a['statut'] . ' ».', null, null );
		}
		if ( ! empty( $a['verse'] ) ) {
			return array( false, 'Avance déjà versée' . ( $a['ecriture_id'] ? ' (écriture n°' . (int) $a['ecriture_id'] . ')' : '' ) . '.', null, null );
		}
		if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'rh_avances', (int) $id ) ) {
			return array( false, 'L\'écriture de versement attend déjà au journal temporaire.', null, null );
		}
		$montant = round( (float) $a['montant'], 2 );
		if ( $montant <= 0 ) { return array( false, 'Montant nul : il n\'y a rien à verser.', null, null ); }

		$tres = $tresorerieId ? FKC_Tresorerie::find( (int) $tresorerieId ) : null;
		if ( ! $tres ) { return array( false, 'Sélectionnez le compte de trésorerie d\'où sort l\'argent.', null, null ); }
		$ctres = FKC_Compte::find( (int) $tres['compte_id'] );
		if ( ! $ctres ) { return array( false, 'Compte de trésorerie introuvable.', null, null ); }

		$def = self::compteAvances();
		$cpt = FKC_Compte::byNumero( $def[0] );
		if ( ! $cpt ) { FKC_Compte::create( str_pad( (string) $def[0], 6, '0' ), $def[1] ); $cpt = FKC_Compte::byNumero( $def[0] ); }
		if ( ! $cpt ) { return array( false, 'Compte ' . $def[0] . ' introuvable et impossible à créer.', null, null ); }

		$emp = FKC_Employe::find( (int) $a['employe_id'] );
		$qui = $emp ? trim( ( $emp['prenom'] ?? '' ) . ' ' . $emp['nom'] ) : ( 'Employé n°' . (int) $a['employe_id'] );
		$quoi = ( 'pret' === $a['type'] ? 'Prêt' : 'Avance sur salaire' ) . ' — ' . $qui;
		$journalId = 0;
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { $journalId = (int) $j['id']; } }
		if ( ! $journalId ) { return array( false, 'Journal des Opérations Diverses (OD) introuvable.', null, null ); }

		$entete = array(
			'journal_id' => $journalId, 'date_ecriture' => $date ?: ( $a['date'] ?: date( 'Y-m-d' ) ),
			'piece' => 'AVANCE-' . (int) $id, 'libelle' => $quoi,
			'reference' => 'Avance RH n°' . (int) $id, 'created_by' => FKC_Auth::id(),
		);
		$lignes = array(
			array( 'compte_id' => (int) $cpt['id'],   'libelle' => $quoi, 'debit' => $montant, 'credit' => 0.0 ),
			array( 'compte_id' => (int) $ctres['id'], 'libelle' => 'Versement — ' . $qui, 'debit' => 0.0, 'credit' => $montant ),
		);
		$opts = array(
			'source' => 'rh_avance',
			'lien'   => array( 'table' => 'rh_avances', 'colonne' => 'ecriture_id', 'ids' => array( (int) $id ) ),
		);
		if ( null !== $brouillard ) { $opts['brouillard'] = (bool) $brouillard; }

		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, $opts );
		if ( ! $ok ) { return array( false, $msg, null, null ); }
		if ( $bid ) {
			// L'argent n'est pas encore sorti tant que le brouillon n'est pas
			// validé : on ne marque pas « versée », donc on ne retient rien.
			return array( true, 'Versement déposé au journal temporaire — l\'avance ne sera retenue sur la paie qu\'une fois l\'écriture validée.', null, (int) $bid );
		}
		FKC_DB::q( 'UPDATE rh_avances SET verse=1, date_versement=? WHERE id=?', array( $entete['date_ecriture'], (int) $id ) );
		return array( true, 'Avance versée : ' . fkc_money( $montant ) . ' F sortis de « ' . $tres['libelle']
			. ' ». La retenue sur paie démarre à la première échéance.', (int) $eid, null );
	}

	/** Rebranche `verse` quand le brouillon de versement est validé. */
	public static function marquerVersee( $id, $date = null ) {
		FKC_DB::q( 'UPDATE rh_avances SET verse=1, date_versement=COALESCE(date_versement,?) WHERE id=? AND verse=0',
			array( $date ?: date( 'Y-m-d' ), (int) $id ) );
	}

	/** Marque les échéances d'un mois comme prélevées et met à jour le reste dû / statut soldé. */
	public static function preleverMois( $employeId, $mois ) {
		return self::preleverPourBulletin( $employeId, $mois, null );
	}

	/* ═════════════════ PONT RH → PAIE (1.561.0) ═════════════════
	 *
	 * LE DÉFAUT QUE CE PONT FERME
	 *
	 * `deductionPaie()` et `preleverMois()` existaient, étaient corrects, et
	 * n'étaient APPELÉS PAR PERSONNE : une recherche sur tout le plugin ne
	 * renvoyait que leur propre déclaration. L'écran des avances promettait
	 * pourtant « déductible automatiquement sur la paie (mois suivant) ».
	 * Un prêt de 120 000 F validé sur trois mois générait bien son
	 * échéancier ; le bulletin du mois suivant versait le net entier, et le
	 * reste dû ne bougeait jamais. L'employeur prêtait sans jamais se
	 * rembourser, et rien ne le disait.
	 *
	 * Le prélèvement est désormais RATTACHÉ AU BULLETIN qui le porte
	 * (colonne `bulletin_id`). C'est ce qui le rend réversible : supprimer
	 * un bulletin erroné rend l'échéance à l'état « prévu », au lieu de
	 * laisser une retenue acquise sur un bulletin qui n'existe plus.
	 */

	/**
	 * Montant réellement prélevable ce mois sous un plafond donné, SANS rien
	 * écrire. La ligne portée au bulletin et le prélèvement effectif sont
	 * ainsi calculés par la même règle : ils ne peuvent pas diverger.
	 *
	 * Une échéance n'est jamais coupée en deux — sous plafond, elle est
	 * REPORTÉE entière au mois suivant. Un échéancier tronqué serait plus
	 * difficile à expliquer au salarié qu'un mois de décalage.
	 *
	 * @return array{float,int} montant, nombre d'échéances retenues.
	 */
	public static function montantPrelevable( $employeId, $mois, $plafond = null ) {
		$restant = ( null === $plafond ) ? INF : max( 0.0, (float) $plafond );
		$total = 0.0; $nb = 0;
		foreach ( self::echeancesDuMois( $employeId, $mois ) as $l ) {
			$mt = (float) $l['montant'];
			if ( $mt > $restant ) { continue; }
			$restant -= $mt; $total += $mt; $nb++;
		}
		return array( $total, $nb );
	}

	/**
	 * Prélève les échéances du mois et les rattache au bulletin qui les porte.
	 *
	 * @param int|null $bulletinId bulletin porteur (null = prélèvement manuel).
	 * @param float|null $plafond  montant maximal réellement retenu (quotité
	 *                             saisissable) ; au-delà, les échéances
	 *                             restent « prévues » et seront reprises le
	 *                             mois suivant.
	 * @return float montant effectivement prélevé.
	 */
	public static function preleverPourBulletin( $employeId, $mois, $bulletinId = null, $plafond = null ) {
		$lignes = self::echeancesDuMois( $employeId, $mois );
		if ( ! $lignes ) { return 0.0; }
		$restant = ( null === $plafond ) ? INF : max( 0.0, (float) $plafond );
		$preleve = 0.0; $avances = array();
		foreach ( $lignes as $l ) {
			$mt = (float) $l['montant'];
			if ( $mt > $restant ) { continue; } // échéance non couverte : reportée telle quelle
			FKC_DB::q(
				"UPDATE rh_avance_echeances SET statut='preleve', bulletin_id=? WHERE id=?",
				array( $bulletinId ? (int) $bulletinId : null, (int) $l['id'] )
			);
			$restant -= $mt; $preleve += $mt;
			$avances[ (int) $l['avance_id'] ] = true;
		}
		foreach ( array_keys( $avances ) as $aid ) { self::recalculerReste( $aid ); }
		return $preleve;
	}

	/**
	 * Rend au bulletin supprimé les échéances qu'il avait prélevées.
	 * @return float montant restitué.
	 */
	public static function libererBulletin( $bulletinId ) {
		$bulletinId = (int) $bulletinId;
		if ( ! $bulletinId ) { return 0.0; }
		$lignes = FKC_DB::q( 'SELECT id, avance_id, montant FROM rh_avance_echeances WHERE bulletin_id=?', array( $bulletinId ) )->fetchAll();
		if ( ! $lignes ) { return 0.0; }
		FKC_DB::q( "UPDATE rh_avance_echeances SET statut='prevu', bulletin_id=NULL WHERE bulletin_id=?", array( $bulletinId ) );
		$total = 0.0; $avances = array();
		foreach ( $lignes as $l ) { $total += (float) $l['montant']; $avances[ (int) $l['avance_id'] ] = true; }
		foreach ( array_keys( $avances ) as $aid ) { self::recalculerReste( $aid ); }
		return $total;
	}

	/** Recalcule le reste dû d'une avance et son statut (soldée / en cours). */
	protected static function recalculerReste( $avanceId ) {
		$aid = (int) $avanceId;
		$reste = (float) FKC_DB::q(
			"SELECT COALESCE(SUM(montant),0) FROM rh_avance_echeances WHERE avance_id=? AND statut='prevu'",
			array( $aid )
		)->fetchColumn();
		FKC_DB::q( 'UPDATE rh_avances SET reste_du=? WHERE id=?', array( $reste, $aid ) );
		$statut = FKC_DB::q( 'SELECT statut FROM rh_avances WHERE id=?', array( $aid ) )->fetchColumn();
		if ( $reste <= 0 && 'valide' === $statut ) {
			FKC_DB::q( "UPDATE rh_avances SET statut='solde' WHERE id=?", array( $aid ) );
		} elseif ( $reste > 0 && 'solde' === $statut ) {
			// Un bulletin annulé peut « dé-solder » un prêt : le statut suit
			// le fait, il ne le décrète pas.
			FKC_DB::q( "UPDATE rh_avances SET statut='valide' WHERE id=?", array( $aid ) );
		}
	}
}
