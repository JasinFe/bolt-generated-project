<?php
/** Organisation & structure : départements/services. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhDepartement {
	public static function all( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE actif=1' : '';
		return FKC_DB::q( "SELECT * FROM rh_departements{$w} ORDER BY ordre, libelle COLLATE NOCASE" )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM rh_departements WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function map() {
		$m = array(); foreach ( self::all() as $d ) { $m[ (int) $d['id'] ] = $d['libelle']; } return $m;
	}
	public static function codeExists( $code, $exceptId = 0 ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM rh_departements WHERE code=? AND id<>?', array( strtoupper( $code ), (int) $exceptId ) )->fetch();
	}
	public static function effectifs() {
		$m = array();
		foreach ( FKC_DB::q( 'SELECT departement_id, COUNT(*) n FROM paie_employes WHERE actif=1 GROUP BY departement_id' )->fetchAll() as $r ) {
			$m[ (int) $r['departement_id'] ] = (int) $r['n'];
		}
		return $m;
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO rh_departements(code,libelle,parent_id,responsable_id,site,actif,ordre) VALUES(?,?,?,?,?,?,?)',
			array( strtoupper( trim( (string) $d['code'] ) ), trim( (string) $d['libelle'] ),
				! empty( $d['parent_id'] ) ? (int) $d['parent_id'] : null,
				! empty( $d['responsable_id'] ) ? (int) $d['responsable_id'] : null,
				trim( (string) ( $d['site'] ?? '' ) ) ?: null, empty( $d['actif'] ) ? 0 : 1, (int) ( $d['ordre'] ?? 0 ) ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		FKC_DB::q( 'UPDATE rh_departements SET code=?, libelle=?, parent_id=?, responsable_id=?, site=?, actif=?, ordre=? WHERE id=?',
			array( strtoupper( trim( (string) $d['code'] ) ), trim( (string) $d['libelle'] ),
				! empty( $d['parent_id'] ) ? (int) $d['parent_id'] : null,
				! empty( $d['responsable_id'] ) ? (int) $d['responsable_id'] : null,
				trim( (string) ( $d['site'] ?? '' ) ) ?: null, empty( $d['actif'] ) ? 0 : 1, (int) ( $d['ordre'] ?? 0 ), (int) $id ) );
	}
	public static function delete( $id ) {
		FKC_DB::q( 'UPDATE paie_employes SET departement_id=NULL WHERE departement_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM rh_departements WHERE id=?', array( (int) $id ) );
	}
}
