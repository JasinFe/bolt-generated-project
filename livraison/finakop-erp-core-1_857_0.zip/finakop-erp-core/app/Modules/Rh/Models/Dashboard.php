<?php
/** Tableau de bord RH : effectif, masse salariale, alertes, KPI. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhDashboard {

	/** Employés dont une échéance (champ date) tombe dans les $jours prochains (ou déjà dépassée). */
	protected static function echeances( $champ, $jours ) {
		$limite = date( 'Y-m-d', strtotime( "+{$jours} days" ) );
		return FKC_DB::q(
			"SELECT id, nom, prenom, {$champ} ech FROM paie_employes
			 WHERE actif=1 AND {$champ} IS NOT NULL AND {$champ}<>'' AND {$champ} <= ? ORDER BY {$champ}",
			array( $limite )
		)->fetchAll();
	}

	public static function compute( $annee ) {
		$actifs = FKC_Employe::countActifs();
		$masseMois = FKC_Employe::masseSalarialeMois();

		// Absences (maladie + absence) validées dans l'année.
		$joursAbs = (float) FKC_DB::q(
			"SELECT COALESCE(SUM(nb_jours),0) FROM rh_conges WHERE statut='valide' AND type IN('maladie','sans_solde') AND substr(date_debut,1,4)=?",
			array( (string) $annee )
		)->fetchColumn();
		$moisEcoules = ( (string) $annee === date( 'Y' ) ) ? (int) date( 'n' ) : 12;
		$joursOuvres = max( 1, $actifs * 22 * $moisEcoules );
		$departs = FKC_Employe::departs( $annee );

		return array(
			'effectif' => array(
				'actifs'   => $actifs,
				'nouveaux' => FKC_Employe::nouveaux( $annee ),
				'departs'  => $departs,
			),
			'masse' => array(
				'mois'  => $masseMois,
				'annee' => $masseMois * 12,
			),
			'alertes' => array(
				'contrats'  => self::echeances( 'date_fin_contrat', 60 ),
				'essais'    => self::echeances( 'fin_essai', 30 ),
				'visites'   => self::echeances( 'prochaine_visite_medicale', 30 ),
			),
			'kpi' => array(
				'absenteisme' => round( $joursAbs / $joursOuvres * 100, 1 ),
				'turnover'    => $actifs > 0 ? round( $departs / $actifs * 100, 1 ) : 0,
				'cout_salarial' => $masseMois,
			),
		);
	}
}
