<?php
/** Congés & absences : types, workflow (employé→manager→RH→validation), soldes automatiques. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhConge {

	public static function types() {
		return array( 'annuel'=>'Congé annuel','maladie'=>'Maladie','maternite'=>'Maternité','paternite'=>'Paternité','deces'=>'Décès','mariage'=>'Mariage','sans_solde'=>'Sans solde' );
	}
	/** Étapes du workflow. */
	public static function etapes() {
		return array( 'demande'=>'Demande employé','manager'=>'Validé manager','rh'=>'Validé RH','valide'=>'Validé','refuse'=>'Refusé' );
	}
	/** Étape suivante du circuit de validation. */
	public static function suivant( $statut ) {
		$ordre = array( 'demande'=>'manager', 'manager'=>'rh', 'rh'=>'valide' );
		return $ordre[ $statut ] ?? null;
	}

	public static function all( $statut = '' ) {
		$w = ''; $p = array();
		if ( '' !== $statut ) { $w = ' WHERE c.statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT c.*, e.nom, e.prenom FROM rh_conges c JOIN paie_employes e ON e.id=c.employe_id{$w} ORDER BY c.date_debut DESC", $p )->fetchAll();
	}
	public static function forEmploye( $employeId ) {
		return FKC_DB::q( 'SELECT * FROM rh_conges WHERE employe_id=? ORDER BY date_debut DESC', array( (int) $employeId ) )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM rh_conges WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}
	public static function enAttente() {
		return (int) FKC_DB::q( "SELECT COUNT(*) FROM rh_conges WHERE statut IN('demande','manager','rh')" )->fetchColumn();
	}

	/** Nombre de jours entre deux dates (bornes incluses). */
	public static function joursEntre( $debut, $fin ) {
		$d1 = strtotime( $debut ); $d2 = strtotime( $fin );
		if ( ! $d1 || ! $d2 || $d2 < $d1 ) { return 0; }
		return (int) floor( ( $d2 - $d1 ) / 86400 ) + 1;
	}

	public static function create( $d ) {
		$nb = (float) ( $d['nb_jours'] ?? 0 );
		if ( $nb <= 0 ) { $nb = self::joursEntre( $d['date_debut'], $d['date_fin'] ); }
		FKC_DB::q( 'INSERT INTO rh_conges(employe_id,type,date_debut,date_fin,nb_jours,motif,statut) VALUES(?,?,?,?,?,?,?)',
			array( (int) $d['employe_id'], isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'annuel',
				$d['date_debut'], $d['date_fin'], $nb, trim( (string) ( $d['motif'] ?? '' ) ) ?: null,
				in_array( $d['statut'] ?? 'demande', array_keys( self::etapes() ), true ) ? ( $d['statut'] ?? 'demande' ) : 'demande' ) );
		$id = (int) FKC_DB::conn()->lastInsertId();
		// Un congé créé DÉJÀ validé (reprise d'historique, import) doit se
		// refléter en paie tout de suite : sinon il n'y a plus jamais de
		// transition de statut pour déclencher le miroir.
		self::synchroniserPaie( $id );
		return $id;
	}
	public static function avancer( $id ) {
		$c = self::find( $id ); if ( ! $c ) { return array(); }
		$next = self::suivant( $c['statut'] ); if ( ! $next ) { return array(); }
		FKC_DB::q( 'UPDATE rh_conges SET statut=?, valide_par=? WHERE id=?', array( $next, FKC_Auth::id(), (int) $id ) );
		return self::synchroniserPaie( $id );
	}
	public static function refuser( $id ) {
		FKC_DB::q( 'UPDATE rh_conges SET statut=?, valide_par=? WHERE id=?', array( 'refuse', FKC_Auth::id(), (int) $id ) );
		return self::synchroniserPaie( $id );
	}
	public static function delete( $id ) {
		$periodes = class_exists( 'FKC_Absence' ) ? FKC_Absence::supprimerPourConge( $id ) : array();
		FKC_DB::q( 'DELETE FROM rh_conges WHERE id=?', array( (int) $id ) );
		return $periodes;
	}

	/* ═════════════════ PONT RH → PAIE (1.561.0) ═════════════════
	 *
	 * LE DÉFAUT QUE CE PONT FERME
	 *
	 * L'écran des congés promettait, noir sur blanc : « le solde de congé
	 * annuel se déduit automatiquement à la validation ». Il ne se déduisait
	 * pas. Le module RH tenait `rh_conges`, le module Paie tenait
	 * `paie_absences`, et AUCUNE ligne de code ne faisait passer un fait de
	 * l'un à l'autre. Conséquences mesurées avant correction, sur un seul
	 * employé et un seul jour :
	 *
	 *   — cinq jours de congé SANS SOLDE validés par les trois étapes du
	 *     circuit ; le bulletin du mois payait le salaire entier, parce que
	 *     `FKC_Absence::joursNonRemuneres()` interrogeait une table où rien
	 *     n'avait été écrit ;
	 *   — l'écran RH annonçait 21 jours de congés restants, l'écran Paie
	 *     75,8 — deux chiffres, un salarié, aucun moyen de savoir lequel
	 *     opposer à qui.
	 *
	 * Le principe retenu est celui déjà posé ailleurs dans l'ERP (« on
	 * partage les référentiels, jamais les compteurs ») appliqué à l'envers :
	 * ici le FAIT est unique et vit dans RH ; la paie en reçoit un REFLET
	 * tracé (`conge_id`), qu'elle ne peut pas modifier pour son compte. Une
	 * seule décision, une seule vérité, dans les deux sens : refuser ou
	 * supprimer le congé retire l'absence.
	 *
	 * Un congé à cheval sur deux mois est DÉCOUPÉ par mois : la paie
	 * raisonne par période, et retenir cinq jours de mars sur le bulletin de
	 * février serait une erreur de plus, pas une simplification.
	 */

	/** Type d'absence de paie correspondant à un type de congé RH, et son impact. */
	public static function typePaie( $type ) {
		$map = array(
			'annuel'     => array( 'conge_paye', 0 ),
			'maladie'    => array( 'maladie', 0 ),
			'maternite'  => array( 'autre', 0 ),
			'paternite'  => array( 'autre', 0 ),
			'deces'      => array( 'autre', 0 ),
			'mariage'    => array( 'autre', 0 ),
			'sans_solde' => array( 'conge_sans_solde', 1 ),
		);
		return $map[ $type ] ?? array( 'autre', 0 );
	}

	/** Jours du congé ventilés par période AAAA-MM (bornes incluses). */
	public static function ventilerParPeriode( $debut, $fin ) {
		$d1 = strtotime( (string) $debut ); $d2 = strtotime( (string) $fin );
		if ( ! $d1 || ! $d2 || $d2 < $d1 ) { return array(); }
		$out = array();
		for ( $t = $d1; $t <= $d2; $t += 86400 ) {
			$p = date( 'Y-m', $t );
			$out[ $p ] = ( $out[ $p ] ?? 0 ) + 1;
		}
		return $out;
	}

	/**
	 * Aligne le reflet du congé dans `paie_absences` sur son statut actuel.
	 *
	 * @return array périodes AAAA-MM touchées (pour avertir si un bulletin
	 *               a DÉJÀ été édité dessus : le miroir ne le recalcule pas).
	 */
	public static function synchroniserPaie( $id ) {
		if ( ! class_exists( 'FKC_Absence' ) ) { return array(); }
		$c = self::find( $id );
		if ( ! $c ) { return FKC_Absence::supprimerPourConge( $id ); }

		$touchees = FKC_Absence::supprimerPourConge( $id );
		if ( 'valide' !== $c['statut'] ) { return $touchees; }

		$emp = class_exists( 'FKC_Employe' ) ? FKC_Employe::find( (int) $c['employe_id'] ) : null;
		list( $typePaie, $impact ) = self::typePaie( $c['type'] );
		$parMois = self::ventilerParPeriode( $c['date_debut'], $c['date_fin'] );
		$totalJoursCal = array_sum( $parMois );
		// `nb_jours` peut avoir été saisi à la main (jours ouvrables). On
		// respecte le total déclaré et on le répartit au prorata des jours
		// calendaires de chaque mois — jamais l'inverse.
		$declare = (float) $c['nb_jours'];
		if ( $declare <= 0 ) { $declare = (float) $totalJoursCal; }
		$reste = $declare; $i = 0; $n = count( $parMois );
		foreach ( $parMois as $periode => $jCal ) {
			$i++;
			$jours = ( $i === $n ) ? $reste : round( $declare * $jCal / max( 1, $totalJoursCal ), 2 );
			$reste = round( $reste - $jours, 2 );
			if ( $jours <= 0 ) { continue; }
			FKC_Absence::create( array(
				'employe_id'  => (int) $c['employe_id'],
				'employe_nom' => $emp ? ( $emp['nom'] ?? '' ) : '',
				'periode'     => $periode,
				'type'        => $typePaie,
				'jours'       => $jours,
				'impact_paie' => $impact,
				'note'        => 'Congé RH n°' . (int) $id . ' (' . ( self::types()[ $c['type'] ] ?? $c['type'] ) . ')',
				'conge_id'    => (int) $id,
			) );
			$touchees[] = $periode;
		}
		return array_values( array_unique( $touchees ) );
	}

	/** Périodes touchées portant DÉJÀ un bulletin — le miroir ne le refait pas. */
	public static function bulletinsExistants( $employeId, array $periodes ) {
		$out = array();
		if ( ! class_exists( 'FKC_Bulletin' ) ) { return $out; }
		foreach ( $periodes as $p ) {
			if ( FKC_Bulletin::exists( (int) $employeId, $p ) ) { $out[] = $p; }
		}
		return $out;
	}

	/**
	 * Soldes de congé annuel d'un employé pour une année : acquis (proraté depuis l'embauche),
	 * consommés (congés annuels validés), restants.
	 */
	public static function soldes( $employe, $annee ) {
		$annee = (string) $annee;
		$joursAn = ! empty( $employe['conge_jours_an'] ) ? (float) $employe['conge_jours_an'] : (float) FKC_License::param( 'rh_conge_jours_an', 26.4 ); // 2,2 j × 12 (Code du travail)
		// Mois de présence dans l'année (proratisation sur l'embauche).
		$mois = 12;
		if ( ! empty( $employe['date_embauche'] ) && substr( $employe['date_embauche'], 0, 4 ) === $annee ) {
			$m = (int) substr( $employe['date_embauche'], 5, 2 );
			$mois = max( 0, 12 - $m + 1 );
		} elseif ( ! empty( $employe['date_embauche'] ) && substr( $employe['date_embauche'], 0, 4 ) > $annee ) {
			$mois = 0;
		}
		$acquis = round( $joursAn / 12 * $mois, 1 );
		$consommes = (float) FKC_DB::q(
			"SELECT COALESCE(SUM(nb_jours),0) FROM rh_conges WHERE employe_id=? AND type='annuel' AND statut='valide' AND substr(date_debut,1,4)=?",
			array( (int) $employe['id'], $annee )
		)->fetchColumn();
		/*
		 * DEUX LECTURES, PLUS DEUX VÉRITÉS (1.561.0).
		 *
		 * Ce module compte les droits de l'ANNÉE (proratés sur l'embauche) ;
		 * la paie compte les droits ACQUIS DEPUIS L'EMBAUCHE. Les deux sont
		 * légitimes — mais tant qu'elles s'affichaient l'une sans l'autre,
		 * sur deux écrans, sans être nommées, l'utilisateur lisait « 21 »
		 * ici et « 75,8 » là sans pouvoir trancher. Elles sont désormais
		 * rendues ENSEMBLE et étiquetées, et surtout elles reposent enfin
		 * sur le MÊME fait : depuis le miroir, un congé annuel validé
		 * alimente `paie_absences`, donc `FKC_Conge::solde()` le voit.
		 */
		$cumul = null;
		if ( class_exists( 'FKC_Conge' ) && class_exists( 'FKC_PaieParams' ) ) {
			try {
				$cumul = FKC_Conge::solde( $employe, FKC_PaieParams::get( (int) $annee ) );
			} catch ( \Throwable $e ) { $cumul = null; }
		}
		return array(
			'jours_an' => $joursAn, 'acquis' => $acquis, 'consommes' => $consommes,
			'restants' => round( $acquis - $consommes, 1 ),
			'cumul_acquis' => $cumul['acquis'] ?? null,
			'cumul_pris'   => $cumul['pris'] ?? null,
			'cumul_solde'  => $cumul['solde'] ?? null,
		);
	}
}
