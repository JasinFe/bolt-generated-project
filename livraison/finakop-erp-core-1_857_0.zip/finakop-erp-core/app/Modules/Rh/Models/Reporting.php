<?php
/** Reporting RH : effectif et masse salariale par dimension. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhReporting {

	/** Effectif (employés actifs) regroupé par dimension : departement|site|sexe|poste. */
	public static function effectifPar( $dim ) {
		$deptMap = FKC_RhDepartement::map();
		$out = array();
		foreach ( FKC_Employe::all( true ) as $e ) {
			switch ( $dim ) {
				case 'departement': $k = ! empty( $e['departement_id'] ) ? ( $deptMap[ (int) $e['departement_id'] ] ?? 'Inconnu' ) : 'Non affecté'; break;
				case 'site':        $k = trim( (string) ( $e['site'] ?? '' ) ) ?: 'Non renseigné'; break;
				case 'sexe':        $k = 'F' === ( $e['sexe'] ?? '' ) ? 'Femmes' : ( 'M' === ( $e['sexe'] ?? '' ) ? 'Hommes' : 'Non renseigné' ); break;
				default:            $k = trim( (string) ( $e['poste'] ?? '' ) ) ?: 'Non renseigné';
			}
			if ( ! isset( $out[ $k ] ) ) { $out[ $k ] = 0; }
			$out[ $k ]++;
		}
		arsort( $out );
		return $out;
	}

	/** Masse salariale (coût mensuel) regroupée par dimension : departement|projet|division. */
	public static function massePar( $dim ) {
		$deptMap = FKC_RhDepartement::map();
		$divMap = array();
		foreach ( FKC_DB::q( 'SELECT id, libelle FROM divisions' )->fetchAll() as $d ) { $divMap[ (int) $d['id'] ] = $d['libelle']; }
		$valMap = array();
		foreach ( FKC_DB::q( 'SELECT id, libelle FROM analytique_valeurs' )->fetchAll() as $v ) { $valMap[ (int) $v['id'] ] = $v['libelle']; }
		$out = array();
		foreach ( FKC_Employe::all( true ) as $e ) {
			switch ( $dim ) {
				case 'projet':   $k = ! empty( $e['projet_valeur_id'] ) ? ( $valMap[ (int) $e['projet_valeur_id'] ] ?? 'Inconnu' ) : 'Non affecté'; break;
				case 'division': $k = ! empty( $e['division_id'] ) ? ( $divMap[ (int) $e['division_id'] ] ?? 'Inconnu' ) : 'Non affecté'; break;
				default:         $k = ! empty( $e['departement_id'] ) ? ( $deptMap[ (int) $e['departement_id'] ] ?? 'Inconnu' ) : 'Non affecté';
			}
			if ( ! isset( $out[ $k ] ) ) { $out[ $k ] = 0.0; }
			$out[ $k ] += FKC_Employe::coutMensuel( $e );
		}
		arsort( $out );
		return $out;
	}
}
