<?php
/** Historique employé : promotions, mutations, sanctions, formations, absences. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhHistorique {
	public static function types() { return array( 'promotion'=>'Promotion','mutation'=>'Mutation','sanction'=>'Sanction','formation'=>'Formation','absence'=>'Absence','autre'=>'Autre' ); }
	public static function forEmploye( $employeId ) {
		return FKC_DB::q( 'SELECT * FROM rh_historique WHERE employe_id=? ORDER BY date DESC, id DESC', array( (int) $employeId ) )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO rh_historique(employe_id,type,libelle,date,detail) VALUES(?,?,?,?,?)',
			array( (int) $d['employe_id'], isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'autre',
				trim( (string) $d['libelle'] ), trim( (string) ( $d['date'] ?? '' ) ) ?: date( 'Y-m-d' ), trim( (string) ( $d['detail'] ?? '' ) ) ?: null ) );
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM rh_historique WHERE id=?', array( (int) $id ) ); }
}
