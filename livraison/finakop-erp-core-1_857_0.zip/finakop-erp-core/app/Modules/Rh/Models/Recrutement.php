<?php
/** Recrutement : demandes de recrutement + candidatures. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhRecrutement {
	public static function statutsCand() { return array( 'recu'=>'Reçu','entretien'=>'Entretien','retenu'=>'Retenu','rejete'=>'Rejeté' ); }

	public static function all( $statut = '' ) {
		$w = ''; $p = array();
		if ( '' !== $statut ) { $w = ' WHERE r.statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT r.*, d.libelle departement,
			(SELECT COUNT(*) FROM rh_candidatures c WHERE c.recrutement_id=r.id) nb_candidats
			FROM rh_recrutements r LEFT JOIN rh_departements d ON d.id=r.departement_id{$w} ORDER BY r.created_at DESC", $p )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM rh_recrutements WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		$r['candidatures'] = FKC_DB::q( 'SELECT * FROM rh_candidatures WHERE recrutement_id=? ORDER BY created_at DESC', array( (int) $id ) )->fetchAll();
		return $r;
	}
	public static function ouverts() { return (int) FKC_DB::q( "SELECT COUNT(*) FROM rh_recrutements WHERE statut='ouvert'" )->fetchColumn(); }

	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO rh_recrutements(poste,motif,budget,departement_id,statut) VALUES(?,?,?,?,?)',
			array( trim( (string) $d['poste'] ), trim( (string) ( $d['motif'] ?? '' ) ) ?: null, (float) ( $d['budget'] ?? 0 ),
				! empty( $d['departement_id'] ) ? (int) $d['departement_id'] : null, 'ouvert' ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function cloturer( $id ) { FKC_DB::q( "UPDATE rh_recrutements SET statut='clos' WHERE id=?", array( (int) $id ) ); }
	public static function rouvrir( $id ) { FKC_DB::q( "UPDATE rh_recrutements SET statut='ouvert' WHERE id=?", array( (int) $id ) ); }
	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM rh_candidatures WHERE recrutement_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM rh_recrutements WHERE id=?', array( (int) $id ) );
	}

	public static function addCandidature( $d ) {
		FKC_DB::q( 'INSERT INTO rh_candidatures(recrutement_id,nom,email,telephone,cv_url,lettre_url,pieces,statut,note) VALUES(?,?,?,?,?,?,?,?,?)',
			array( (int) $d['recrutement_id'], trim( (string) $d['nom'] ), trim( (string) ( $d['email'] ?? '' ) ) ?: null,
				trim( (string) ( $d['telephone'] ?? '' ) ) ?: null, trim( (string) ( $d['cv_url'] ?? '' ) ) ?: null,
				trim( (string) ( $d['lettre_url'] ?? '' ) ) ?: null, trim( (string) ( $d['pieces'] ?? '' ) ) ?: null,
				'recu', trim( (string) ( $d['note'] ?? '' ) ) ?: null ) );
	}
	public static function setCandStatut( $id, $statut ) {
		if ( isset( self::statutsCand()[ $statut ] ) ) { FKC_DB::q( 'UPDATE rh_candidatures SET statut=? WHERE id=?', array( $statut, (int) $id ) ); }
	}
	public static function deleteCandidature( $id ) { FKC_DB::q( 'DELETE FROM rh_candidatures WHERE id=?', array( (int) $id ) ); }
}
