<?php
/** Missions & frais : ordre de mission, dépenses, workflow de validation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhMission {
	public static function etapes() { return FKC_RhConge::etapes(); }
	public static function suivant( $statut ) { return FKC_RhConge::suivant( $statut ); }

	public static function all( $statut = '' ) {
		$w = ''; $p = array();
		if ( '' !== $statut ) { $w = ' WHERE m.statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT m.*, e.nom, e.prenom FROM rh_missions m JOIN paie_employes e ON e.id=m.employe_id{$w} ORDER BY m.date_debut DESC", $p )->fetchAll();
	}
	public static function forEmploye( $employeId ) {
		return FKC_DB::q( 'SELECT * FROM rh_missions WHERE employe_id=? ORDER BY date_debut DESC', array( (int) $employeId ) )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM rh_missions WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function enAttente() { return (int) FKC_DB::q( "SELECT COUNT(*) FROM rh_missions WHERE statut IN('demande','manager','rh')" )->fetchColumn(); }
	public static function total( $m ) { return (float) $m['transport'] + (float) $m['hotel'] + (float) $m['repas'] + (float) $m['autres']; }

	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO rh_missions(employe_id,ville,objet,date_debut,date_fin,transport,hotel,repas,autres,statut) VALUES(?,?,?,?,?,?,?,?,?,?)',
			array( (int) $d['employe_id'], trim( (string) $d['ville'] ), trim( (string) ( $d['objet'] ?? '' ) ) ?: null,
				$d['date_debut'], $d['date_fin'], (float) ( $d['transport'] ?? 0 ), (float) ( $d['hotel'] ?? 0 ),
				(float) ( $d['repas'] ?? 0 ), (float) ( $d['autres'] ?? 0 ), 'demande' ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	/** @return bool la mission vient-elle d'atteindre la validation finale ? */
	public static function avancer( $id ) {
		$m = self::find( $id ); if ( ! $m ) { return false; }
		$next = self::suivant( $m['statut'] ); if ( ! $next ) { return false; }
		FKC_DB::q( 'UPDATE rh_missions SET statut=?, valide_par=? WHERE id=?', array( $next, FKC_Auth::id(), (int) $id ) );
		return 'valide' === $next;
	}
	public static function refuser( $id ) { FKC_DB::q( "UPDATE rh_missions SET statut='refuse', valide_par=? WHERE id=?", array( FKC_Auth::id(), (int) $id ) ); }

	/**
	 * Supprime une mission — sauf si elle est déjà passée en comptabilité.
	 *
	 * @return array{bool,string}
	 */
	public static function delete( $id ) {
		$m = self::find( $id );
		if ( ! $m ) { return array( false, 'Mission introuvable.' ); }
		if ( ! empty( $m['ecriture_id'] ) ) {
			return array( false, 'Cette mission est comptabilisée (écriture n°' . (int) $m['ecriture_id']
				. '). Contre-passez l\'écriture en comptabilité avant de la supprimer.' );
		}
		if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'rh_missions', (int) $id ) ) {
			return array( false, 'L\'écriture de cette mission attend au journal temporaire. Traitez-la avant de supprimer la mission.' );
		}
		FKC_DB::q( 'DELETE FROM rh_missions WHERE id=?', array( (int) $id ) );
		return array( true, 'Mission supprimée.' );
	}

	/* ═══════════ PONT MISSIONS → COMPTABILITÉ (1.562.0) ═══════════
	 *
	 * LE DÉFAUT QUE CE PONT FERME
	 *
	 * Une mission portait de l'ARGENT RÉEL — transport, hôtel, repas, autres
	 * — saisi poste par poste, soumis à un circuit de validation en trois
	 * étapes, validé par le manager puis par les RH… et ensuite : rien.
	 * Aucune écriture, aucun remboursement, aucun lien vers quoi que ce soit.
	 * Le salarié avait avancé les frais de sa poche, l'entreprise avait
	 * approuvé la dépense, et le grand livre n'en savait rien : la charge
	 * manquait au résultat, la dette envers le salarié manquait au bilan, et
	 * aucun écran ne montrait qu'il restait quelque chose à payer.
	 *
	 * C'est la même famille de défaut que les avances jamais retenues et les
	 * congés sans effet sur la paie (1.561.0) : un écran qui enregistre un
	 * fait que personne ne traite ensuite.
	 *
	 * LE CHOIX DES COMPTES APPARTIENT AU DOSSIER. Les quatre postes de frais
	 * et le compte de dette sont des PARAMÈTRES, avec des défauts SYSCOHADA
	 * plausibles — 6181 « Voyages et déplacements » pour la charge, 4213
	 * « Frais avancés et fournitures au personnel » pour ce que l'entreprise
	 * doit au salarié. Un dossier qui ventile l'hôtel ailleurs le fait sans
	 * toucher au code.
	 */

	/** Comptes d'imputation des frais de mission (paramétrables). */
	public static function comptes() {
		return array(
			'transport' => array( FKC_License::param( 'rh_mission_cpt_transport', '618100' ), 'Voyages et déplacements' ),
			'hotel'     => array( FKC_License::param( 'rh_mission_cpt_hotel',     '618100' ), 'Voyages et déplacements' ),
			'repas'     => array( FKC_License::param( 'rh_mission_cpt_repas',     '618100' ), 'Voyages et déplacements' ),
			'autres'    => array( FKC_License::param( 'rh_mission_cpt_autres',    '618100' ), 'Voyages et déplacements' ),
			'dette'     => array( FKC_License::param( 'rh_mission_cpt_dette',     '421300' ), 'Frais avancés et fournitures au personnel' ),
		);
	}

	/** Postes de frais, dans l'ordre d'affichage. */
	public static function postes() {
		return array( 'transport' => 'Transport', 'hotel' => 'Hôtel', 'repas' => 'Repas', 'autres' => 'Autres frais' );
	}

	/** Missions validées dont les frais ne sont pas encore au grand livre. */
	public static function aComptabiliser() {
		return FKC_DB::q(
			"SELECT m.*, e.nom, e.prenom FROM rh_missions m JOIN paie_employes e ON e.id=m.employe_id
			  WHERE m.statut='valide' AND m.ecriture_id IS NULL
			    AND (m.transport + m.hotel + m.repas + m.autres) > 0
			  ORDER BY m.date_fin"
		)->fetchAll();
	}

	/**
	 * Lignes d'écriture d'une mission : charges au débit, dette au crédit.
	 *
	 * Les postes imputés sur un MÊME compte sont fusionnés — un dossier qui
	 * laisse les quatre postes sur 6181 obtient une ligne de charge, pas
	 * quatre lignes identiques qui n'apprennent rien au lecteur du journal.
	 *
	 * @return array{lignes:array, total:float, equilibre:bool}
	 */
	public static function lignes( $m ) {
		$c = self::comptes();
		$par = array();
		foreach ( self::postes() as $poste => $libPoste ) {
			$mt = round( (float) ( $m[ $poste ] ?? 0 ), 2 );
			if ( $mt <= 0 ) { continue; }
			$num = $c[ $poste ][0];
			if ( ! isset( $par[ $num ] ) ) { $par[ $num ] = array( 'montant' => 0.0, 'postes' => array() ); }
			$par[ $num ]['montant'] += $mt;
			$par[ $num ]['postes'][] = $libPoste;
		}
		$total = 0.0; $lignes = array();
		foreach ( $par as $num => $d ) {
			$total += $d['montant'];
			$lignes[] = array(
				'numero' => $num,
				'libelle' => 'Frais de mission ' . $m['ville'] . ' — ' . implode( ', ', $d['postes'] ),
				'debit' => round( $d['montant'], 2 ), 'credit' => 0.0, 'charge' => true,
			);
		}
		if ( $total > 0 ) {
			$lignes[] = array(
				'numero' => $c['dette'][0],
				'libelle' => 'Frais avancés — ' . trim( ( $m['prenom'] ?? '' ) . ' ' . ( $m['nom'] ?? '' ) ),
				'debit' => 0.0, 'credit' => round( $total, 2 ), 'charge' => false,
			);
		}
		return array( 'lignes' => $lignes, 'total' => round( $total, 2 ), 'equilibre' => true );
	}

	protected static function compteId( $numero, $libelleDefaut ) {
		$cpt = FKC_Compte::byNumero( $numero );
		if ( ! $cpt ) {
			FKC_Compte::create( str_pad( (string) $numero, 6, '0' ), $libelleDefaut );
			$cpt = FKC_Compte::byNumero( $numero );
		}
		return $cpt ? (int) $cpt['id'] : 0;
	}

	protected static function journalOd() {
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		return 0;
	}

	/**
	 * Constate les frais d'une mission validée au grand livre.
	 *
	 * @return array{bool,string,int|null,int|null} ( ok, message, ecriture_id, brouillon_id )
	 */
	public static function comptabiliser( $id, $date = null, $brouillard = null, $divisionId = null ) {
		$m = self::find( $id );
		if ( ! $m ) { return array( false, 'Mission introuvable.', null, null ); }
		if ( 'valide' !== $m['statut'] ) {
			return array( false, 'Seule une mission VALIDÉE se comptabilise — celle-ci est au stade « '
				. ( self::etapes()[ $m['statut'] ] ?? $m['statut'] ) . ' ». Terminez le circuit de validation.', null, null );
		}
		if ( ! empty( $m['ecriture_id'] ) ) {
			return array( false, 'Mission déjà comptabilisée (écriture n°' . (int) $m['ecriture_id'] . ').', null, null );
		}
		if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'rh_missions', (int) $id ) ) {
			return array( false, 'L\'écriture de cette mission attend déjà au journal temporaire.', null, null );
		}
		$emp = FKC_Employe::find( (int) $m['employe_id'] );
		$m['nom'] = $emp['nom'] ?? ''; $m['prenom'] = $emp['prenom'] ?? '';
		$plan = self::lignes( $m );
		if ( $plan['total'] <= 0 ) {
			return array( false, 'Cette mission ne porte aucun frais : il n\'y a rien à comptabiliser.', null, null );
		}
		$journalId = self::journalOd();
		if ( ! $journalId ) { return array( false, 'Journal des Opérations Diverses (OD) introuvable.', null, null ); }

		$c = self::comptes();
		$libParNum = array();
		foreach ( $c as $def ) { $libParNum[ $def[0] ] = $def[1]; }
		// Pont Missions ↔ Analytique : la charge est imputable à une division.
		$div = $divisionId ? (int) $divisionId : (int) FKC_License::param( 'rh_mission_division_id', 0 );
		$lignes = array();
		foreach ( $plan['lignes'] as $l ) {
			$cid = self::compteId( $l['numero'], $libParNum[ $l['numero'] ] ?? ( 'Compte ' . $l['numero'] ) );
			if ( ! $cid ) { return array( false, 'Compte ' . $l['numero'] . ' introuvable et impossible à créer.', null, null ); }
			$lignes[] = array(
				'compte_id' => $cid, 'libelle' => $l['libelle'],
				'debit' => $l['debit'], 'credit' => $l['credit'],
				'division_id' => ( $l['charge'] && $div > 0 ) ? $div : null,
			);
		}

		$entete = array(
			'journal_id' => $journalId,
			'date_ecriture' => $date ?: $m['date_fin'],
			'piece' => 'MISSION-' . (int) $id,
			'libelle' => 'Frais de mission ' . $m['ville'] . ' — ' . trim( ( $m['prenom'] ?? '' ) . ' ' . $m['nom'] ),
			'reference' => 'Mission ' . $m['date_debut'] . ' → ' . $m['date_fin'],
			'created_by' => FKC_Auth::id(),
		);
		$opts = array(
			'source' => 'rh_mission',
			'lien'   => array( 'table' => 'rh_missions', 'colonne' => 'ecriture_id', 'ids' => array( (int) $id ) ),
		);
		if ( null !== $brouillard ) { $opts['brouillard'] = (bool) $brouillard; }

		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, $opts );
		if ( ! $ok ) { return array( false, $msg, null, null ); }
		if ( $bid ) {
			return array( true, 'Frais de mission (' . fkc_money( $plan['total'] ) . ' F) déposés au journal temporaire — à vérifier avant comptabilisation.', null, (int) $bid );
		}
		return array( true, 'Frais de mission comptabilisés : ' . fkc_money( $plan['total'] )
			. ' F en charge, portés au crédit du compte « ' . $c['dette'][1] . ' » — reste à régler au salarié.', (int) $eid, null );
	}
}
