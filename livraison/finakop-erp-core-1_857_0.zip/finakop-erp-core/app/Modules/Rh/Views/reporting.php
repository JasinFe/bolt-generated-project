<?php /** @var array $effectif @var array $masse @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$barEff = function ( $rows ) {
	$max = 0; foreach ( $rows as $n ) { $max = max( $max, $n ); }
	$out = '';
	foreach ( $rows as $lib => $n ) {
		$w = $max > 0 ? round( $n / $max * 100 ) : 0;
		$out .= '<tr><td>' . e( $lib ) . '</td><td class="num">' . (int) $n . '</td><td style="width:50%"><div class="bar-track" style="background:var(--line);border-radius:4px;height:10px"><div style="width:' . $w . '%;height:10px;background:var(--orange);border-radius:4px"></div></div></td></tr>';
	}
	return $out ?: '<tr><td colspan="3" class="empty">Aucune donnée.</td></tr>';
};
$tblMasse = function ( $rows ) {
	$tot = 0; foreach ( $rows as $m ) { $tot += $m; }
	$out = '';
	foreach ( $rows as $lib => $m ) {
		$pct = $tot > 0 ? round( $m / $tot * 100, 1 ) : 0;
		$out .= '<tr><td>' . e( $lib ) . '</td><td class="num">' . e( fkc_money( $m ) ) . '</td><td class="num">' . $pct . ' %</td></tr>';
	}
	$out .= '<tr class="total"><td>Total</td><td class="num">' . e( fkc_money( $tot ) ) . '</td><td class="num">100 %</td></tr>';
	return $rows ? $out : '<tr><td colspan="3" class="empty">Aucune donnée.</td></tr>';
};
$effLabels = array( 'departement'=>'Par département','site'=>'Par site','sexe'=>'Par sexe','poste'=>'Par poste' );
$masseLabels = array( 'departement'=>'Par département','projet'=>'Par projet','division'=>'Par division' ); ?>
<?php FKC_View::partial( 'rh::_subnav', array( 'tab' => 'reporting' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<h2 style="margin:4px 0 10px">Effectif</h2>
<div class="form-grid">
	<?php foreach ( $effLabels as $k => $lib ) : ?>
	<div class="card card-flush"><div class="card-head"><h2><?= e( $lib ) ?></h2></div>
		<table class="table"><thead><tr><th>Catégorie</th><th class="num">Eff.</th><th></th></tr></thead>
		<tbody><?= $barEff( $effectif[ $k ] ) ?></tbody></table>
	</div>
	<?php endforeach; ?>
</div>

<h2 style="margin:18px 0 10px">Masse salariale (coût mensuel théorique)</h2>
<div class="form-grid">
	<?php foreach ( $masseLabels as $k => $lib ) : ?>
	<div class="card card-flush"><div class="card-head"><h2><?= e( $lib ) ?></h2></div>
		<table class="table"><thead><tr><th>Axe</th><th class="num">Masse</th><th class="num">%</th></tr></thead>
		<tbody><?= $tblMasse( $masse[ $k ] ) ?></tbody></table>
	</div>
	<?php endforeach; ?>
</div>
<p class="help" style="margin:10px 0 0">La ventilation par projet et division provient de l'affectation analytique de chaque salarié (fiche employé).</p>
