<?php /** @var array $avances @var array $types @var array $employes @var array $tresoreries @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$badge = array( 'demande'=>'b-off','valide'=>'b-on','refuse'=>'b-off','solde'=>'' ); ?>
<?php FKC_View::partial( 'rh::_subnav', array( 'tab' => 'avances' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouvelle avance / prêt</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'rh/avances' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:200px"><span>Employé</span><select name="employe_id" required><option value="">—</option><?php foreach ( $employes as $e ) : ?><option value="<?= (int) $e['id'] ?>"><?= e( FKC_Employe::nomComplet( $e ) ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Type</span><select name="type"><?php foreach ( $types as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Montant</span><input type="number" name="montant" required style="width:130px"></label>
		<label class="fld" style="margin:0"><span>Durée (mois, prêt)</span><input type="number" name="duree_mois" value="1" min="1" style="width:90px"></label>
		<label class="fld" style="margin:0;flex:1;min-width:120px"><span>Motif</span><input name="motif"></label>
		<button class="btn btn-primary" type="submit">Enregistrer</button>
	</form>
	<p class="help" style="margin:8px 0 0">À la validation, l'échéancier est généré et <strong>réellement retenu sur le bulletin</strong> du mois d'échéance (à partir du mois suivant), <strong>à condition que l'avance ait été versée</strong> : approuver n'est pas décaisser, et le logiciel ne retient rien à un salarié à qui l'entreprise n'a encore rien remis. Le bouton <em>Verser</em> sort l'argent de la trésorerie choisie et inscrit la créance sur le salarié — c'est elle que chaque retenue vient éteindre. La retenue est plafonnée par la <em>quotité cessible</em> paramétrée dans les barèmes de paie : une échéance qui ne tient pas dessous est reportée entière au mois suivant. Supprimer le bulletin rend l'échéance au reste dû.</p>
</div></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Employé</th><th>Type</th><th class="num">Montant</th><th class="num">Mensualité</th><th class="num">Reste dû</th><th>Statut</th><th>Versement</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $avances ) : ?><tr><td colspan="8" class="empty">Aucune avance ni prêt.</td></tr>
	<?php else : foreach ( $avances as $a ) : ?>
		<tr>
			<td><?= e( trim( ( $a['prenom'] ?? '' ) . ' ' . $a['nom'] ) ) ?></td>
			<td><?= e( $types[ $a['type'] ] ?? $a['type'] ) ?><?= 'pret'===$a['type'] ? ' <span class="muted">('.(int)$a['duree_mois'].' m)</span>' : '' ?></td>
			<td class="num"><?= e( fkc_money( $a['montant'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $a['mensualite'] ) ) ?></td>
			<td class="num"><?= 'valide'===$a['statut'] ? e( fkc_money( $a['reste_du'] ) ) : '—' ?></td>
			<td><span class="modbadge <?= $badge[ $a['statut'] ] ?? '' ?>"><?= e( ucfirst( $a['statut'] ) ) ?></span></td>
			<td><?php if ( ! empty( $a['ecriture_id'] ) ) : ?>
					<a class="muted" href="<?= e( url( 'comptabilite/ecritures/' . (int) $a['ecriture_id'] ) ) ?>">Versée — écriture n°<?= (int) $a['ecriture_id'] ?></a>
				<?php elseif ( 'valide' === $a['statut'] && empty( $a['verse'] ) ) : ?>
					<span class="modbadge b-off">À verser</span>
				<?php elseif ( ! empty( $a['verse'] ) ) : ?><span class="muted">Versée</span>
				<?php else : ?><span class="muted">—</span><?php endif; ?></td>
			<td><form method="post" action="<?= e( url( 'rh/avances/' . (int) $a['id'] . '/action' ) ) ?>" style="display:flex;gap:4px">
				<?= FKC_Csrf::field() ?>
				<?php if ( 'valide' === $a['statut'] && empty( $a['verse'] ) ) : ?>
					<?php if ( $tresoreries ) : ?>
						<select name="tresorerie_id" required style="max-width:150px"><option value="">Depuis…</option>
						<?php foreach ( $tresoreries as $t ) : ?><option value="<?= (int) $t['id'] ?>"><?= e( $t['libelle'] ) ?></option><?php endforeach; ?>
						</select>
						<button class="btn btn-sm" name="action" value="verser">Verser</button>
					<?php else : ?><span class="muted">Créez un compte de trésorerie pour verser</span><?php endif; ?>
				<?php endif; ?>
				<?php if ( 'demande' === $a['statut'] ) : ?>
					<button class="btn btn-sm" name="action" value="valider">Valider</button>
					<button class="btn btn-ghost btn-sm" name="action" value="refuser">Refuser</button>
				<?php else : ?>
					<?php if ( empty( $a['ecriture_id'] ) ) : ?>
						<button class="btn btn-ghost btn-sm" name="action" value="supprimer" onclick="return confirm('Supprimer ?')">✕</button>
					<?php else : ?><span class="muted" title="Versement comptabilisé — contre-passez l'écriture">🔒</span><?php endif; ?>
				<?php endif; ?>
			</form></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
