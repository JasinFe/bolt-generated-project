<?php
/** Module RH (SIRH) : tableau de bord, personnel, organisation, congés, avances, missions, recrutement, portail, reporting. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RhController {

	/* ── Tableau de bord ── */
	public function index() {
		if ( ! $this->feature( 'rh.dashboard' ) ) { return; }
		$annee = $this->anneeParam();
		FKC_View::render( 'rh::dashboard', array(
			'title' => 'RH · Tableau de bord', 'tab' => 'dashboard',
			'annee' => $annee, 'annees' => $this->annees(), 'd' => FKC_RhDashboard::compute( $annee ), 'flash' => $this->flash(),
		) );
	}

	/* ── Administration du personnel ── */
	public function employes() {
		if ( ! $this->feature( 'rh.personnel' ) ) { return; }
		FKC_View::render( 'rh::employes', array(
			'title' => 'RH · Personnel', 'tab' => 'employes',
			'employes' => FKC_Employe::all(), 'depts' => FKC_RhDepartement::map(), 'flash' => $this->flash(),
		) );
	}
	public function fiche( $id ) {
		if ( ! $this->feature( 'rh.personnel' ) ) { return; }
		$e = FKC_Employe::fiche( $id );
		if ( ! $e ) { $this->setFlash( 'Employé introuvable.' ); redirect( 'rh/employes' ); }
		FKC_View::render( 'rh::fiche', array(
			'title' => 'RH · ' . FKC_Employe::nomComplet( $e ), 'tab' => 'employes', 'e' => $e,
			'depts' => FKC_RhDepartement::all( true ), 'managers' => FKC_Employe::all( true ),
			'docTypes' => FKC_RhDocument::types(), 'histTypes' => FKC_RhHistorique::types(),
			'documents' => FKC_RhDocument::forEmploye( $id ), 'historique' => FKC_RhHistorique::forEmploye( $id ),
			'conges' => FKC_RhConge::forEmploye( $id ), 'avances' => FKC_RhAvance::forEmploye( $id ),
			'soldes' => FKC_RhConge::soldes( $e, date( 'Y' ) ),
			'anaOn' => FKC_Modules::featureEnabled( 'rh.analytique' ),
			'divisions' => FKC_DB::q( 'SELECT id, code, libelle FROM divisions WHERE actif=1 ORDER BY libelle' )->fetchAll(),
			'projets' => $this->projets(), 'flash' => $this->flash(),
		) );
	}
	public function ficheSave( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.personnel' ) ) { redirect( 'rh' ); }
		$d = $_POST;
		if ( ! FKC_Modules::featureEnabled( 'rh.analytique' ) ) { unset( $d['division_id'], $d['projet_valeur_id'], $d['centre_id'] ); }
		FKC_Employe::updateRh( $id, $d );
		$this->setFlash( 'Fiche employé mise à jour.' );
		redirect( 'rh/employes/' . (int) $id );
	}
	public function documentStore( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.personnel' ) ) { redirect( 'rh' ); }
		$_POST['employe_id'] = (int) $id;
		if ( '' !== trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { FKC_RhDocument::create( $_POST ); $this->setFlash( 'Document ajouté.' ); }
		redirect( 'rh/employes/' . (int) $id );
	}
	public function documentDelete( $id, $docId ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.personnel' ) ) { redirect( 'rh' ); }
		FKC_RhDocument::delete( $docId ); $this->setFlash( 'Document supprimé.' );
		redirect( 'rh/employes/' . (int) $id );
	}
	public function historiqueStore( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.personnel' ) ) { redirect( 'rh' ); }
		$_POST['employe_id'] = (int) $id;
		if ( '' !== trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { FKC_RhHistorique::create( $_POST ); $this->setFlash( 'Événement ajouté à l\'historique.' ); }
		redirect( 'rh/employes/' . (int) $id );
	}
	public function historiqueDelete( $id, $histId ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.personnel' ) ) { redirect( 'rh' ); }
		FKC_RhHistorique::delete( $histId ); $this->setFlash( 'Événement supprimé.' );
		redirect( 'rh/employes/' . (int) $id );
	}

	/* ── Organisation & structure ── */
	public function organisation() {
		if ( ! $this->feature( 'rh.organisation' ) ) { return; }
		FKC_View::render( 'rh::organisation', array(
			'title' => 'RH · Organisation', 'tab' => 'organisation',
			'depts' => FKC_RhDepartement::all(), 'effectifs' => FKC_RhDepartement::effectifs(),
			'managers' => FKC_Employe::all( true ), 'flash' => $this->flash(),
		) );
	}
	public function deptStore() {
		if ( ! FKC_Modules::featureEnabled( 'rh.organisation' ) ) { redirect( 'rh' ); }
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		if ( '' === $code || '' === trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { $this->setFlash( 'Code et libellé requis.' ); }
		elseif ( FKC_RhDepartement::codeExists( $code ) ) { $this->setFlash( 'Ce code existe déjà.' ); }
		else { FKC_RhDepartement::create( $_POST ); $this->setFlash( 'Département créé.' ); }
		redirect( 'rh/organisation' );
	}
	public function deptDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.organisation' ) ) { redirect( 'rh' ); }
		FKC_RhDepartement::delete( $id ); $this->setFlash( 'Département supprimé.' );
		redirect( 'rh/organisation' );
	}

	/* ── Congés & absences ── */
	public function conges() {
		if ( ! $this->feature( 'rh.conges' ) ) { return; }
		FKC_View::render( 'rh::conges', array(
			'title' => 'RH · Congés', 'tab' => 'conges',
			'conges' => FKC_RhConge::all(), 'types' => FKC_RhConge::types(), 'etapes' => FKC_RhConge::etapes(),
			'employes' => FKC_Employe::all( true ), 'flash' => $this->flash(),
		) );
	}
	public function congeStore() {
		if ( ! FKC_Modules::featureEnabled( 'rh.conges' ) ) { redirect( 'rh' ); }
		if ( empty( $_POST['employe_id'] ) || empty( $_POST['date_debut'] ) || empty( $_POST['date_fin'] ) ) { $this->setFlash( 'Employé et dates requis.' ); }
		else { FKC_RhConge::create( $_POST ); $this->setFlash( 'Demande de congé enregistrée.' ); }
		redirect( 'rh/conges' );
	}
	public function congeAction( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.conges' ) ) { redirect( 'rh' ); }
		$a = $_POST['action'] ?? '';
		$c = FKC_RhConge::find( $id );
		$empId = $c ? (int) $c['employe_id'] : 0;
		if ( 'avancer' === $a ) {
			$per = FKC_RhConge::avancer( $id );
			$apres = FKC_RhConge::find( $id );
			$msg = 'Congé : étape validée.';
			if ( $apres && 'valide' === $apres['statut'] ) {
				$msg .= ' L\'absence est reportée en paie' . ( $per ? ' (' . implode( ', ', $per ) . ')' : '' ) . '.';
			}
			$this->setFlash( $msg . $this->alerteBulletins( $empId, $per ) );
		} elseif ( 'refuser' === $a ) {
			$per = FKC_RhConge::refuser( $id );
			$this->setFlash( 'Congé refusé.' . ( $per ? ' L\'absence correspondante est retirée de la paie.' : '' ) . $this->alerteBulletins( $empId, $per ) );
		} elseif ( 'supprimer' === $a ) {
			$per = FKC_RhConge::delete( $id );
			$this->setFlash( 'Congé supprimé.' . $this->alerteBulletins( $empId, $per ) );
		}
		redirect( 'rh/conges' );
	}

	/**
	 * Prévient si l'on vient de modifier une absence sur un mois DÉJÀ payé.
	 * Le miroir alimente la paie ; il ne réécrit pas un bulletin édité — et
	 * un décalage silencieux entre RH et paie est précisément ce que ce
	 * chantier ferme.
	 */
	protected function alerteBulletins( $employeId, $periodes ) {
		if ( ! $employeId || ! $periodes ) { return ''; }
		$deja = FKC_RhConge::bulletinsExistants( $employeId, (array) $periodes );
		if ( ! $deja ) { return ''; }
		return ' ⚠ Le bulletin de ' . implode( ', ', $deja ) . ' est déjà édité : il ne tient pas compte de ce changement (Paie → Bulletins : supprimer puis régénérer).';
	}

	/* ── Avances & prêts ── */
	public function avances() {
		if ( ! $this->feature( 'rh.avances' ) ) { return; }
		FKC_View::render( 'rh::avances', array(
			'title' => 'RH · Avances & prêts', 'tab' => 'avances',
			'avances' => FKC_RhAvance::all(), 'types' => FKC_RhAvance::types(),
			'employes' => FKC_Employe::all( true ), 'flash' => $this->flash(),
			'tresoreries' => class_exists( 'FKC_Tresorerie' ) ? FKC_Tresorerie::comptes( true ) : array(),
		) );
	}
	public function avanceStore() {
		if ( ! FKC_Modules::featureEnabled( 'rh.avances' ) ) { redirect( 'rh' ); }
		if ( empty( $_POST['employe_id'] ) || (float) ( $_POST['montant'] ?? 0 ) <= 0 ) { $this->setFlash( 'Employé et montant requis.' ); }
		else { FKC_RhAvance::create( $_POST ); $this->setFlash( 'Demande enregistrée.' ); }
		redirect( 'rh/avances' );
	}
	public function avanceAction( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.avances' ) ) { redirect( 'rh' ); }
		$a = $_POST['action'] ?? '';
		if ( 'valider' === $a ) { FKC_RhAvance::valider( $id ); $this->setFlash( 'Validé — échéancier généré.' ); }
		elseif ( 'refuser' === $a ) { FKC_RhAvance::refuser( $id ); $this->setFlash( 'Demande refusée.' ); }
		elseif ( 'supprimer' === $a ) { list( , $m ) = FKC_RhAvance::delete( $id ); $this->setFlash( $m ); }
		redirect( 'rh/avances' );
	}

	/* ── Missions & frais ── */
	public function missions() {
		if ( ! $this->feature( 'rh.missions' ) ) { return; }
		FKC_View::render( 'rh::missions', array(
			'title' => 'RH · Missions', 'tab' => 'missions',
			'missions' => FKC_RhMission::all(), 'etapes' => FKC_RhMission::etapes(),
			'employes' => FKC_Employe::all( true ), 'flash' => $this->flash(),
		) );
	}
	public function missionStore() {
		if ( ! FKC_Modules::featureEnabled( 'rh.missions' ) ) { redirect( 'rh' ); }
		if ( empty( $_POST['employe_id'] ) || empty( $_POST['ville'] ) || empty( $_POST['date_debut'] ) || empty( $_POST['date_fin'] ) ) { $this->setFlash( 'Employé, ville et dates requis.' ); }
		else { FKC_RhMission::create( $_POST ); $this->setFlash( 'Ordre de mission créé.' ); }
		redirect( 'rh/missions' );
	}
	public function missionAction( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.missions' ) ) { redirect( 'rh' ); }
		$a = $_POST['action'] ?? '';
		if ( 'avancer' === $a ) {
			$final = FKC_RhMission::avancer( $id );
			$msg = 'Mission : étape validée.';
			if ( $final ) {
				$m = FKC_RhMission::find( $id );
				$tot = $m ? FKC_RhMission::total( $m ) : 0;
				$msg .= $tot > 0
					? ' Les frais (' . fkc_money( $tot ) . ' F) restent À COMPTABILISER : sans écriture, ni la charge ni ce que vous devez au salarié ne figurent au grand livre.'
					: ' Cette mission ne porte aucun frais.';
			}
			$this->setFlash( $msg );
		}
		elseif ( 'refuser' === $a ) { FKC_RhMission::refuser( $id ); $this->setFlash( 'Mission refusée.' ); }
		elseif ( 'comptabiliser' === $a ) {
			list( $ok, $msg ) = FKC_RhMission::comptabiliser( $id );
			$this->setFlash( $msg );
		}
		elseif ( 'supprimer' === $a ) { list( , $m ) = FKC_RhMission::delete( $id ); $this->setFlash( $m ); }
		redirect( 'rh/missions' );
	}

	/* ── Recrutement ── */
	public function recrutement() {
		if ( ! $this->feature( 'rh.recrutement' ) ) { return; }
		$sel = isset( $_GET['r'] ) ? FKC_RhRecrutement::find( (int) $_GET['r'] ) : null;
		FKC_View::render( 'rh::recrutement', array(
			'title' => 'RH · Recrutement', 'tab' => 'recrutement',
			'recrutements' => FKC_RhRecrutement::all(), 'depts' => FKC_RhDepartement::all( true ),
			'sel' => $sel, 'statutsCand' => FKC_RhRecrutement::statutsCand(), 'flash' => $this->flash(),
		) );
	}
	public function recrutementStore() {
		if ( ! FKC_Modules::featureEnabled( 'rh.recrutement' ) ) { redirect( 'rh' ); }
		if ( '' === trim( (string) ( $_POST['poste'] ?? '' ) ) ) { $this->setFlash( 'Le poste est requis.' ); redirect( 'rh/recrutement' ); }
		$rid = FKC_RhRecrutement::create( $_POST ); $this->setFlash( 'Demande de recrutement créée.' );
		redirect( 'rh/recrutement?r=' . $rid );
	}
	public function recrutementAction( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.recrutement' ) ) { redirect( 'rh' ); }
		$a = $_POST['action'] ?? '';
		if ( 'cloturer' === $a ) { FKC_RhRecrutement::cloturer( $id ); }
		elseif ( 'rouvrir' === $a ) { FKC_RhRecrutement::rouvrir( $id ); }
		elseif ( 'supprimer' === $a ) { FKC_RhRecrutement::delete( $id ); $this->setFlash( 'Supprimé.' ); redirect( 'rh/recrutement' ); }
		redirect( 'rh/recrutement?r=' . (int) $id );
	}
	public function candidatureStore( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.recrutement' ) ) { redirect( 'rh' ); }
		$_POST['recrutement_id'] = (int) $id;
		if ( '' !== trim( (string) ( $_POST['nom'] ?? '' ) ) ) { FKC_RhRecrutement::addCandidature( $_POST ); $this->setFlash( 'Candidature ajoutée.' ); }
		redirect( 'rh/recrutement?r=' . (int) $id );
	}
	public function candidatureAction( $id, $candId ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.recrutement' ) ) { redirect( 'rh' ); }
		$st = $_POST['statut'] ?? '';
		if ( 'supprimer' === $st ) { FKC_RhRecrutement::deleteCandidature( $candId ); }
		else { FKC_RhRecrutement::setCandStatut( $candId, $st ); }
		redirect( 'rh/recrutement?r=' . (int) $id );
	}

	/* ── Portail employé ── */
	public function portail() {
		if ( ! $this->feature( 'rh.portail' ) ) { return; }
		$id = (int) ( $_GET['e'] ?? 0 );
		$e = $id ? FKC_Employe::fiche( $id ) : null;
		FKC_View::render( 'rh::portail', array(
			'title' => 'RH · Portail employé', 'tab' => 'portail',
			'employes' => FKC_Employe::all( true ), 'e' => $e,
			'bulletins' => $e ? $this->bulletins( $id ) : array(),
			'documents' => $e ? FKC_RhDocument::forEmploye( $id ) : array(),
			'conges' => $e ? FKC_RhConge::forEmploye( $id ) : array(),
			'avances' => $e ? FKC_RhAvance::forEmploye( $id ) : array(),
			'soldes' => $e ? FKC_RhConge::soldes( $e, date( 'Y' ) ) : null,
			'flash' => $this->flash(),
		) );
	}

	/* ── Pointage & présences ── */
	public function pointage() {
		if ( ! $this->feature( 'rh.pointage' ) ) { return; }
		$jour = trim( (string) ( $_GET['jour'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $jour ) ) { $jour = date( 'Y-m-d' ); }
		$periode = substr( $jour, 0, 7 );
		FKC_View::render( 'rh::pointage', array(
			'title' => 'RH · Pointage', 'tab' => 'pointage',
			'jour' => $jour, 'periode' => $periode,
			'employes' => FKC_Employe::all( true ),
			'pointages' => FKC_RhPointage::duJour( $jour ),
			'synthese' => FKC_RhPointage::synthese( $periode ),
			'sens' => FKC_RhPointage::sens(),
			'flash' => $this->flash(),
		) );
	}
	public function pointageStore() {
		if ( ! FKC_Modules::featureEnabled( 'rh.pointage' ) ) { redirect( 'rh' ); }
		$jour = trim( (string) ( $_POST['jour'] ?? '' ) ) ?: date( 'Y-m-d' );
		$heure = trim( (string) ( $_POST['heure'] ?? '' ) );
		$d = array(
			'employe_id' => (int) ( $_POST['employe_id'] ?? 0 ),
			'sens'       => (string) ( $_POST['sens'] ?? '' ),
			'horodatage' => $heure ? ( $jour . ' ' . $heure . ':00' ) : null,
			'source'     => 'saisie',
			'note'       => $_POST['note'] ?? '',
		);
		list( , $msg ) = FKC_RhPointage::create( $d );
		$this->setFlash( $msg );
		redirect( 'rh/pointage?jour=' . rawurlencode( $jour ) );
	}
	public function pointageDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'rh.pointage' ) ) { redirect( 'rh' ); }
		$jour = trim( (string) ( $_POST['jour'] ?? '' ) ) ?: date( 'Y-m-d' );
		FKC_RhPointage::delete( $id );
		$this->setFlash( 'Pointage supprimé.' );
		redirect( 'rh/pointage?jour=' . rawurlencode( $jour ) );
	}

	/* ── Reporting RH ── */
	public function reporting() {
		if ( ! $this->feature( 'rh.reporting' ) ) { return; }
		FKC_View::render( 'rh::reporting', array(
			'title' => 'RH · Reporting', 'tab' => 'reporting',
			'effectif' => array(
				'departement' => FKC_RhReporting::effectifPar( 'departement' ),
				'site'        => FKC_RhReporting::effectifPar( 'site' ),
				'sexe'        => FKC_RhReporting::effectifPar( 'sexe' ),
				'poste'       => FKC_RhReporting::effectifPar( 'poste' ),
			),
			'masse' => array(
				'departement' => FKC_RhReporting::massePar( 'departement' ),
				'projet'      => FKC_RhReporting::massePar( 'projet' ),
				'division'    => FKC_RhReporting::massePar( 'division' ),
			),
			'flash' => $this->flash(),
		) );
	}

	/* ── helpers ── */
	protected function feature( $code ) {
		if ( FKC_Modules::featureEnabled( $code ) ) { return true; }
		FKC_View::render( 'rh::_locked', array(
			'title' => 'RH · ' . FKC_Modules::featureLabel( $code ), 'tab' => '',
			'label' => FKC_Modules::featureLabel( $code ), 'min' => FKC_Modules::featureMinLabel( $code ),
		) );
		return false;
	}
	protected function anneeParam() {
		$a = isset( $_GET['annee'] ) ? preg_replace( '/\D/', '', (string) $_GET['annee'] ) : '';
		return '' === $a ? date( 'Y' ) : $a;
	}
	protected function annees() {
		$ys = array(); $cur = (int) date( 'Y' );
		for ( $y = $cur; $y >= $cur - 3; $y-- ) { $ys[] = (string) $y; }
		if ( class_exists( 'FKC_Exercice' ) ) { foreach ( FKC_Exercice::annees() as $a ) { if ( ! in_array( $a, $ys, true ) ) { $ys[] = $a; } } }
		rsort( $ys );
		return $ys;
	}
	protected function projets() {
		try {
			$axe = FKC_DB::q( "SELECT id FROM analytique_axes WHERE code='PROJ'" )->fetchColumn();
			if ( ! $axe ) { return array(); }
			return FKC_DB::q( 'SELECT id, code, libelle FROM analytique_valeurs WHERE axe_id=? AND actif=1 ORDER BY libelle', array( (int) $axe ) )->fetchAll();
		} catch ( Exception $e ) { return array(); }
	}
	protected function bulletins( $employeId ) {
		try { return FKC_DB::q( 'SELECT * FROM paie_bulletins WHERE employe_id=? ORDER BY periode DESC', array( (int) $employeId ) )->fetchAll(); }
		catch ( Exception $e ) { return array(); }
	}
	protected function setFlash( $m ) { $_SESSION['__flash_rh'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_rh'] ?? null; unset( $_SESSION['__flash_rh'] ); return $m; }
}
