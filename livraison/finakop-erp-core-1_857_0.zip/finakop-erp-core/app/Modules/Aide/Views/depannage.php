<?php /** @var array $groupes */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="bar"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide' ) ) ?>"><span aria-hidden="true">←</span> Centre d'aide</a></div>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico">🩺</div>
	<div><h1 class="launch-title">Dépannage</h1>
	<p class="launch-sub">Les symptômes fréquents, et ce qu'il faut regarder en premier.</p></div>
</div>

<?php foreach ( $groupes as $nom => $items ) : ?>
<div class="card"><div class="card-head"><h2><?= e( $nom ) ?></h2></div>
	<div class="card-body" style="padding-top:6px">
		<?php foreach ( $items as $d ) : ?>
			<details class="aide-dep">
				<summary><?= e( $d['q'] ) ?></summary>
				<p><?= e( $d['r'] ) ?></p>
			</details>
		<?php endforeach; ?>
	</div>
</div>
<?php endforeach; ?>

<div class="card"><div class="card-body">
	<p class="muted" style="margin:0">Le symptôme n'est pas dans la liste ? Le <a href="<?= e( url( 'aide/glossaire' ) ) ?>">glossaire</a> aide souvent quand on cherche sans connaître le bon terme, et la <a href="<?= e( url( 'aide' ) ) ?>">recherche</a> couvre aussi les articles.</p>
</div></div>

<style>
.aide-dep{border-bottom:1px solid var(--line);padding:10px 0}
.aide-dep:last-child{border-bottom:none}
.aide-dep summary{cursor:pointer;font-weight:600;font-size:14px;list-style:none;display:flex;align-items:center;gap:8px}
.aide-dep summary::before{content:'▸';color:var(--muted);transition:transform .15s}
.aide-dep[open] summary::before{transform:rotate(90deg)}
.aide-dep summary::-webkit-details-marker{display:none}
.aide-dep p{margin:8px 0 2px 18px;font-size:13.5px;color:var(--muted);line-height:1.6}
</style>
