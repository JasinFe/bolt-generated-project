<?php /** @var string $cat @var array $meta @var array $articles */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="bar"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide' ) ) ?>"><span aria-hidden="true">←</span> Centre d'aide</a></div>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico"><?= e( $meta['icon'] ) ?></div>
	<div><h1 class="launch-title"><?= e( $meta['titre'] ) ?></h1><p class="launch-sub"><?= e( $meta['intro'] ) ?></p></div>
</div>
<div class="card card-flush"><table class="table"><tbody>
	<?php foreach ( $articles as $a ) : ?>
		<tr>
			<td>
				<a href="<?= e( url( 'aide/article/' . $a['id'] ) ) ?>" style="font-weight:600;color:var(--text)"><?= e( $a['titre'] ) ?></a>
				<?php if ( 'essentiel' === ( $a['niveau'] ?? '' ) ) : ?><span class="pill" style="margin-left:8px">À lire en premier</span><?php endif; ?>
			</td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide/article/' . $a['id'] ) ) ?>">Lire →</a></td>
		</tr>
	<?php endforeach; ?>
	<?php if ( ! $articles ) : ?><tr><td class="empty">Aucun article dans cette rubrique pour le moment.</td></tr><?php endif; ?>
</tbody></table></div>
