<?php /** Fiche pratique d'un pack métier. @var array $f @var string $actif @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="aide-head">
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide/packs' ) ) ?>">← Tous les packs</a>
	<h1><?= e( $f['icone'] ) ?> <?= e( $f['label'] ) ?>
		<?php if ( $actif === $f['code'] ) : ?><span class="modbadge b-on">pack actif</span><?php endif; ?>
	</h1>
	<?php if ( $f['description'] ) : ?><p class="muted"><?= e( $f['description'] ) ?></p><?php endif; ?>
</div>

<?php if ( $f['terminologie'] ) : ?>
<div class="card">
	<div class="card-head"><h2>Le vocabulaire de votre métier</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Les écrans emploient vos mots, pas ceux d'un logiciel générique. Voici la
			correspondance : c'est la première chose à connaître pour retrouver un menu.
		</p>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr><th>Notion</th><th>Nom dans ce pack</th></tr></thead>
				<tbody>
				<?php foreach ( $f['terminologie'] as $t ) : ?>
					<tr><td class="muted"><?= e( $t['generique'] ) ?></td><td><strong><?= e( $t['metier'] ) ?></strong></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Premiers pas</h2></div>
	<div class="card-body">
		<?php /*
		 * Le balisage suit maintenant celui du Guide et des Tutoriels :
		 * pastille numérotée + bloc de contenu. Il s'en écartait, et cela se
		 * voyait deux fois. D'abord, `.aide-steps` porte `list-style:none` :
		 * les numéros du <ol> ne s'affichaient PAS, et le `padding-left:22px`
		 * du <style> en ligne creusait un retrait pour des numéros absents.
		 * Ensuite `.aide-steps li` est en `display:flex` : le <strong>, le
		 * <br> et le <span> devenaient trois éléments de rangée — le titre de
		 * l'étape et son explication se retrouvaient COLLÉS SUR UNE LIGNE, le
		 * <br> sans effet.
		 */ ?>
		<ol class="aide-steps">
			<?php foreach ( $f['demarrage'] as $n => $e ) : ?>
				<li>
					<span class="aide-step-n"><?= (int) $n + 1 ?></span>
					<span class="aide-step-c"><strong><?= e( $e['titre'] ) ?></strong><br><span class="muted"><?= e( $e['texte'] ) ?></span></span>
				</li>
			<?php endforeach; ?>
		</ol>
	</div>
</div>

<?php if ( $f['pieces'] ) : ?>
<div class="card">
	<div class="card-head"><h2>Ce qui part en comptabilité</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Chaque document validé déclenche son écriture. Le moment où elle rejoint les
			journaux dépend de votre politique de comptabilisation.
		</p>
		<div class="ckp-table-wrap">
			<table class="ckp-table">
				<thead><tr><th>Document</th><th>TVA</th><th>Écriture déclenchée</th></tr></thead>
				<tbody>
				<?php foreach ( $f['pieces'] as $p ) : ?>
					<tr>
						<td><strong><?= e( $p['label'] ) ?></strong></td>
						<td><?= null !== $p['tva'] ? e( rtrim( rtrim( number_format( $p['tva'], 1, ',', ' ' ), '0' ), ',' ) ) . ' %' : '—' ?></td>
						<td class="muted" style="font-family:ui-monospace,monospace;font-size:12px"><?= e( $p['evenement'] ?: '—' ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php endif; ?>

<?php if ( $f['stock'] ) : ?>
<div class="card">
	<div class="card-head"><h2>Gestion du stock</h2></div>
	<div class="card-body">
		<?php if ( ! empty( $f['stock']['catalogue_seul'] ) ) : ?>
			<p>Ce pack tient un <strong>catalogue</strong> sans suivi de quantités ni de coût moyen :
			les articles servent à la facturation, pas à la valorisation d'un stock.</p>
		<?php else : ?>
			<p>Nature stockée : <strong><?= e( $f['stock']['nature_label'] ) ?></strong>.
			Ce choix décide de la ligne du compte de résultat SYSCOHADA où vos sorties apparaissent.</p>
			<div class="ckp-table-wrap">
				<table class="ckp-table">
					<tbody>
						<tr><td>Compte de stock</td><td><strong><?= e( $f['stock']['compte_stock'] ) ?></strong></td></tr>
						<tr><td>Variation de stocks (le coût des sorties)</td><td><strong><?= e( $f['stock']['compte_var'] ) ?></strong></td></tr>
						<tr><td>Achats</td><td><strong><?= e( $f['stock']['compte_achat'] ) ?></strong></td></tr>
						<tr><td>Réceptions non facturées</td><td><strong><?= e( $f['stock']['attente'] ) ?></strong></td></tr>
					</tbody>
				</table>
			</div>
			<p class="help">
				À la réception, la marchandise entre en stock et la dette est constatée en compte
				d'attente : <strong>aucune charge n'est encore comptabilisée</strong>. La charge
				apparaît à la sortie — vente ou consommation —, en regard du produit qu'elle a permis.
			</p>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

<?php if ( $f['cockpits'] ) : ?>
<div class="card">
	<div class="card-head"><h2>Pilotage</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">Ce pack apporte ses indicateurs au Centre de Pilotage :</p>
		<div style="display:flex;gap:8px;flex-wrap:wrap">
			<?php foreach ( $f['cockpits'] as $c ) : ?>
				<span class="modbadge b-on"><?= e( $c['label'] ) ?></span>
			<?php endforeach; ?>
		</div>
	</div>
</div>
<?php endif; ?>

<?php /* Le <style> qui vivait ici redéfinissait .aide-steps sans reprendre son
   `display` ni son `list-style` : la règle globale survivait et le retrait
   qu'il posait ne servait à rien. Mise en forme unique dans app.css. */ ?>
