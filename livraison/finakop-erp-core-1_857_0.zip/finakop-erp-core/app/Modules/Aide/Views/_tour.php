<?php /** Moteur de visite guidée interactive. Attend window.FKC_TOURS (objet id => {label, etapes:[{cible,titre,texte}]}). */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<style>
#fkc-tour-ov{position:fixed;inset:0;z-index:9998;display:none}
#fkc-tour-spot{position:absolute;border-radius:10px;box-shadow:0 0 0 9999px rgba(6,10,20,.72);transition:all .28s cubic-bezier(.4,0,.2,1);pointer-events:none;border:2px solid var(--blue,#4C7BEC)}
#fkc-tour-card{position:absolute;z-index:9999;max-width:320px;background:var(--panel,#131D33);border:1px solid var(--line2,#2E3E5C);border-radius:14px;box-shadow:0 18px 40px -10px rgba(0,0,0,.6);padding:16px 18px;transition:all .28s cubic-bezier(.4,0,.2,1)}
#fkc-tour-card h4{font-family:Syne,Inter,sans-serif;font-size:15px;margin:0 0 5px;color:var(--text,#EAEFF7)}
#fkc-tour-card p{font-size:13.5px;color:var(--muted,#93A2BE);line-height:1.6;margin:0 0 12px}
#fkc-tour-card .ftc-foot{display:flex;align-items:center;justify-content:space-between;gap:10px}
#fkc-tour-card .ftc-step{font-size:11.5px;color:var(--muted2,#647194);font-weight:600}
#fkc-tour-card .ftc-btns{display:flex;gap:7px}
.ftc-b{font-family:inherit;font-size:12.5px;font-weight:600;padding:6px 12px;border-radius:8px;cursor:pointer;border:1px solid var(--line2,#2E3E5C);background:transparent;color:var(--muted,#93A2BE);transition:.15s}
.ftc-b:hover{color:var(--text,#EAEFF7);border-color:var(--muted2,#647194)}
.ftc-b.ftc-primary{background:linear-gradient(135deg,#4C7BEC,#3258C9);border-color:transparent;color:#fff}
@media (prefers-reduced-motion:reduce){#fkc-tour-spot,#fkc-tour-card{transition:none}}
</style>
<div id="fkc-tour-ov" role="dialog" aria-modal="true">
	<div id="fkc-tour-spot"></div>
	<div id="fkc-tour-card">
		<h4 id="fkc-tour-title"></h4>
		<p id="fkc-tour-text"></p>
		<div class="ftc-foot">
			<span class="ftc-step" id="fkc-tour-count"></span>
			<div class="ftc-btns">
				<button class="ftc-b" id="fkc-tour-prev" type="button">Précédent</button>
				<button class="ftc-b ftc-primary" id="fkc-tour-next" type="button">Suivant</button>
			</div>
		</div>
	</div>
</div>
<script>
(function(){
	var ov=document.getElementById('fkc-tour-ov'), spot=document.getElementById('fkc-tour-spot'), card=document.getElementById('fkc-tour-card');
	var elT=document.getElementById('fkc-tour-title'), elX=document.getElementById('fkc-tour-text'), elC=document.getElementById('fkc-tour-count');
	var bPrev=document.getElementById('fkc-tour-prev'), bNext=document.getElementById('fkc-tour-next');
	var steps=[], i=0;
	function place(){
		var s=steps[i]; if(!s){return;}
		var el=document.querySelector(s.cible);
		elT.textContent=s.titre||''; elX.textContent=s.texte||'';
		elC.textContent=(i+1)+' / '+steps.length;
		bPrev.style.visibility=i===0?'hidden':'visible';
		bNext.textContent=(i===steps.length-1)?'Terminer':'Suivant';
		if(!el){ // cible absente : on centre la carte
			spot.style.width='0px';spot.style.height='0px';spot.style.left='50%';spot.style.top='50%';
			card.style.left='50%';card.style.top='50%';card.style.transform='translate(-50%,-50%)';return;
		}
		el.scrollIntoView({behavior:'smooth',block:'center'});
		setTimeout(function(){
			var r=el.getBoundingClientRect(), pad=8;
			spot.style.left=(r.left-pad)+'px';spot.style.top=(r.top-pad)+'px';
			spot.style.width=(r.width+pad*2)+'px';spot.style.height=(r.height+pad*2)+'px';
			card.style.transform='none';
			var cw=card.offsetWidth||320, ch=card.offsetHeight||140, gap=14;
			var left=r.right+gap, top=r.top;
			if(left+cw>window.innerWidth-12){ left=r.left-cw-gap; }
			if(left<12){ left=Math.min(Math.max(12,r.left), window.innerWidth-cw-12); top=r.bottom+gap; }
			if(top+ch>window.innerHeight-12){ top=window.innerHeight-ch-12; }
			if(top<12){ top=12; }
			card.style.left=left+'px';card.style.top=top+'px';
		}, 280);
	}
	function open(id){
		var t=(window.FKC_TOURS||{})[id]; if(!t){return;}
		steps=t.etapes||[]; i=0; if(!steps.length){return;}
		ov.style.display='block'; document.body.style.overflow='hidden'; place();
	}
	function close(){ ov.style.display='none'; document.body.style.overflow=''; }
	bNext.onclick=function(){ if(i>=steps.length-1){close();}else{i++;place();} };
	bPrev.onclick=function(){ if(i>0){i--;place();} };
	ov.addEventListener('click',function(e){ if(e.target===ov){close();} });
	document.addEventListener('keydown',function(e){ if(ov.style.display==='block'&&e.key==='Escape'){close();} });
	window.addEventListener('resize',function(){ if(ov.style.display==='block'){place();} });
	window.fkcStartTour=open;
	document.addEventListener('click',function(e){
		var t=e.target.closest('[data-fkc-tour]'); if(t){ e.preventDefault(); open(t.getAttribute('data-fkc-tour')); }
	});
})();
</script>
