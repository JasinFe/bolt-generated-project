<?php /** @var array $parcours */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="bar"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide' ) ) ?>"><span aria-hidden="true">←</span> Centre d'aide</a></div>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico">🎯</div>
	<div><h1 class="launch-title">Guide de prise en main</h1>
	<p class="launch-sub">Les étapes dans l'ordre où elles doivent être faites. Chacune suppose la précédente.</p></div>
</div>

<div class="alert alert-warn">Comptez une demi-journée pour une petite structure, deux à trois jours si vous reprenez une comptabilité existante avec un stock à inventorier. Les étapes 1 et 2 ne se sautent pas.</div>

<?php foreach ( $parcours as $i => $p ) : ?>
<div class="card aide-phase" id="<?= e( $p['id'] ) ?>">
	<div class="card-head">
		<h2><span class="aide-phase-n"><?= $i + 1 ?></span> <?= e( $p['icon'] . ' ' . $p['titre'] ) ?></h2>
		<span class="pill"><?= e( $p['duree'] ) ?></span>
	</div>
	<div class="card-body">
		<p class="aide-phase-intro"><?= e( $p['intro'] ) ?></p>
		<ol class="aide-steps">
			<?php foreach ( $p['etapes'] as $n => $s ) : ?>
			<li>
				<span class="aide-step-n"><?= $n + 1 ?></span>
				<span class="aide-step-c"><strong><?= e( $s['titre'] ) ?></strong><br><span class="muted"><?= e( $s['detail'] ) ?></span></span>
				<span style="display:flex;gap:6px;white-space:nowrap">
					<?php if ( ! empty( $s['aide'] ) ) : ?>
						<a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide/article/' . $s['aide'] ) ) ?>">En savoir plus</a>
					<?php endif; ?>
					<a class="btn btn-primary btn-sm" href="<?= e( url( $s['route'] ) ) ?>">Ouvrir →</a>
				</span>
			</li>
			<?php endforeach; ?>
		</ol>
	</div>
</div>
<?php endforeach; ?>

<div class="card"><div class="card-body">
	<h2 style="margin-top:0">Et ensuite ?</h2>
	<p class="muted">Une fois le rythme pris, trois écrans méritent une visite régulière : la <a href="<?= e( url( 'recouvrement/balance-agee' ) ) ?>">balance âgée</a> chaque semaine, la <a href="<?= e( url( 'comptabilite/balance' ) ) ?>">balance comptable</a> avant chaque clôture, et le <a href="<?= e( url( 'aide/depannage' ) ) ?>">dépannage</a> quand un chiffre ne tombe pas juste.</p>
</div></div>

<style>
.aide-phase{margin-bottom:16px}
.aide-phase .card-head h2{display:flex;align-items:center;gap:10px;font-size:16px}
.aide-phase-n{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:50%;background:var(--accent);color:#fff;font-size:13px;font-weight:700;flex:none}
.aide-phase-intro{margin:0 0 14px;font-size:13.5px;color:var(--muted)}
</style>
