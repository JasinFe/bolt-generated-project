<?php /** @var array $groupes */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="bar"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide' ) ) ?>"><span aria-hidden="true">←</span> Centre d'aide</a></div>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico">📖</div>
	<div><h1 class="launch-title">Glossaire</h1>
	<p class="launch-sub">Les termes comptables et métier employés dans l'application, expliqués sans jargon.</p></div>
</div>

<div class="aide-glo-filtre">
	<input id="gloq" placeholder="Filtrer : 408, lettrage, CUMP…" autocomplete="off">
</div>

<?php foreach ( $groupes as $nom => $termes ) : ?>
<div class="card glo-grp"><div class="card-head"><h2><?= e( $nom ) ?></h2></div>
	<div class="card-body" style="padding-top:6px">
		<?php foreach ( $termes as $t ) : ?>
			<div class="aide-qa glo-item"><strong><?= e( $t['terme'] ) ?></strong><p class="muted"><?= e( $t['def'] ) ?></p></div>
		<?php endforeach; ?>
	</div>
</div>
<?php endforeach; ?>

<script>
(function () {
	var q = document.getElementById('gloq');
	if (!q) { return; }
	q.addEventListener('input', function () {
		var v = q.value.trim().toLowerCase();
		document.querySelectorAll('.glo-grp').forEach(function (g) {
			var visibles = 0;
			g.querySelectorAll('.glo-item').forEach(function (it) {
				var ok = !v || it.textContent.toLowerCase().indexOf(v) !== -1;
				it.style.display = ok ? '' : 'none';
				if (ok) { visibles++; }
			});
			g.style.display = visibles ? '' : 'none';
		});
	});
})();
</script>
<style>
.aide-glo-filtre{margin:0 0 14px}
.aide-glo-filtre input{width:100%;max-width:420px}
</style>
