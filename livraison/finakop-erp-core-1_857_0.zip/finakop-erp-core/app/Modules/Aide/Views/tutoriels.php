<?php /** @var array $tutoriels */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="bar"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide' ) ) ?>"><span aria-hidden="true">←</span> Centre d'aide</a></div>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico">🎓</div>
	<div><h1 class="launch-title">Tutoriels guidés</h1><p class="launch-sub">Suivez les étapes pas à pas — chaque étape ouvre l'écran concerné.</p></div>
</div>
<?php foreach ( $tutoriels as $t ) : ?>
	<div class="card" id="<?= e( $t['id'] ) ?>"><div class="card-head"><h2><?= e( $t['icon'] . ' ' . $t['titre'] ) ?></h2><span class="muted"><?= e( $t['objectif'] ) ?></span></div>
		<div class="card-body">
			<ol class="aide-steps">
				<?php foreach ( $t['etapes'] as $n => $s ) : ?>
					<li>
						<span class="aide-step-n"><?= $n + 1 ?></span>
						<span class="aide-step-c"><strong><?= e( $s['titre'] ) ?></strong><br><span class="muted"><?= e( $s['detail'] ) ?></span></span>
						<a class="btn btn-ghost btn-sm" href="<?= e( url( $s['route'] ) ) ?>"<?= 0 === strpos( $s['route'], 'api/' ) ? ' target="_blank"' : '' ?>>Ouvrir →</a>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>
	</div>
<?php endforeach; ?>
