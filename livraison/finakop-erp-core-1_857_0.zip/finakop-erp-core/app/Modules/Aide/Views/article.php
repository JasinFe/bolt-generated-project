<?php /** @var array $article @var ?array $catMeta @var array $voisins */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="bar">
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide/categorie/' . $article['cat'] ) ) ?>"><span aria-hidden="true">←</span> <?= e( $catMeta['titre'] ?? 'Aide' ) ?></a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'aide' ) ) ?>">Centre d'aide</a>
</div>
<article class="aide-article">
	<div class="aide-article-cat">
		<?= e( ( $catMeta['icon'] ?? '' ) . ' ' . ( $catMeta['titre'] ?? '' ) ) ?>
		<?php if ( 'essentiel' === ( $article['niveau'] ?? '' ) ) : ?><span class="pill" style="margin-left:8px">À lire en premier</span><?php endif; ?>
	</div>
	<h1><?= e( $article['titre'] ) ?></h1>
	<div class="aide-article-body"><?= $article['corps'] ?></div>
</article>

<?php if ( $voisins ) : ?>
<div class="card"><div class="card-head"><h2>Dans la même rubrique</h2></div><div class="card-body" style="padding-top:8px">
	<?php foreach ( array_slice( $voisins, 0, 6 ) as $v ) : ?>
		<a class="aide-tuto-row" href="<?= e( url( 'aide/article/' . $v['id'] ) ) ?>">
			<span class="aide-tuto-ico"><?= e( $catMeta['icon'] ?? '📄' ) ?></span>
			<span><strong><?= e( $v['titre'] ) ?></strong></span>
		</a>
	<?php endforeach; ?>
</div></div>
<?php endif; ?>

<div class="card"><div class="card-body">
	<p class="muted" style="margin:0">Besoin d'autre chose ? Le <a href="<?= e( url( 'aide/guide' ) ) ?>">guide de prise en main</a> déroule les étapes dans l'ordre, le <a href="<?= e( url( 'aide/depannage' ) ) ?>">dépannage</a> traite les symptômes fréquents, et le <a href="<?= e( url( 'aide/glossaire' ) ) ?>">glossaire</a> explique les termes.</p>
</div></div>
