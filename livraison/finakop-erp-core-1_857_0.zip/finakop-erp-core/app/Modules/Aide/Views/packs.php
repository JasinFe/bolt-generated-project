<?php /** Sommaire des packs métier. @var array $familles @var string $actif @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="aide-head">
	<h1>🧩 Packs métier</h1>
	<p class="muted">
		Un pack adapte FinaKop à votre activité : le vocabulaire des écrans, les modules
		ouverts, les écritures comptables et les indicateurs de pilotage. Chaque fiche est
		<strong>lue dans la configuration réelle du pack</strong> — elle ne peut pas décrire
		autre chose que ce qui est installé.
	</p>
</div>

<?php foreach ( $familles as $famille => $packs ) : ?>
	<div class="card">
		<div class="card-head"><h2><?= e( ucfirst( str_replace( '_', ' ', $famille ) ) ) ?> — <?= count( $packs ) ?> pack(s)</h2></div>
		<div class="card-body">
			<div class="aide-grid">
				<?php foreach ( $packs as $code => $p ) : ?>
					<a class="aide-card<?= $actif === $code ? ' aide-card-actif' : '' ?>"
						href="<?= e( url( 'aide/pack/' . $code ) ) ?>">
						<span class="aide-card-ico"><?= e( $p['icone'] ) ?></span>
						<span class="aide-card-t"><?= e( $p['label'] ) ?>
							<?php if ( $actif === $code ) : ?><span class="modbadge b-on">actif</span><?php endif; ?>
						</span>
						<?php if ( $p['description'] ) : ?><span class="aide-card-d"><?= e( $p['description'] ) ?></span><?php endif; ?>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
<?php endforeach; ?>

<style>
.aide-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}
.aide-card{display:block;padding:12px 14px;border:1px solid var(--line,#243049);border-radius:10px;
	text-decoration:none;color:inherit;transition:border-color .15s}
.aide-card:hover{border-color:var(--blue,#3b82f6)}
.aide-card-actif{border-color:var(--ok);box-shadow:inset 0 0 0 1px var(--ok)}
.aide-card-ico{font-size:20px;display:block;margin-bottom:4px}
.aide-card-t{font-weight:700;display:block}
.aide-card-d{display:block;font-size:12.5px;opacity:.7;margin-top:4px;line-height:1.45}
</style>
