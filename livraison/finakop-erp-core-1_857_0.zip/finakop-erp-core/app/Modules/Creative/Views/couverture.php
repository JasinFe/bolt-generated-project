<?php
/**
 * Couverture métier des dix-sept secteurs créatifs.
 * @var array $inventaire @var array $socles @var string $secteur_actif
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$etat = array( 'livre' => array( 'Livré', '#3ddc84' ), 'partiel' => array( 'Partiel', '#ffb020' ), 'a_construire' => array( 'À construire', '#ff6b6b' ) );
?>
<div class="card"><div class="card-head"><h2 style="margin:0">Couverture métier des secteurs créatifs</h2></div><div class="card-body">
	<p class="muted" style="margin:0;font-size:12.5px">
		Les moteurs transversaux sont communs aux dix-sept secteurs : revenus numériques, comptabilité, fiscalité, clôture.
		Ce qui reste propre à chaque métier, c'est son objet central et son cycle. Cette page dit, secteur par secteur, ce que
		FinaKop sait déjà en faire — briques vérifiées dans ce dossier — et ce qui manque encore.
	</p>
</div></div>

<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Socles communs</h3></div>
<table class="table"><thead><tr><th>Socle</th><th>État</th><th>Secteurs servis</th><th>Ce qu'il apportera</th></tr></thead><tbody>
<?php foreach ( $socles as $code => $s ) : $e = $etat[ $s['etat'] ] ?? array( $s['etat'], '#9aa3b5' ); ?>
	<tr><td><strong><?= e( $s['libelle'] ) ?></strong><div class="muted" style="font-size:12px"><?= e( $s['note'] ) ?></div></td>
		<td style="color:<?= e( $e[1] ) ?>"><?= e( $e[0] ) ?></td>
		<td style="font-size:12px"><?= e( implode( ', ', $s['secteurs'] ) ) ?></td>
		<td style="font-size:12px"><?php if ( $s['manques'] ) : ?><ul style="margin:0 0 0 16px"><?php foreach ( $s['manques'] as $m ) : ?><li><?= e( $m ) ?></li><?php endforeach; ?></ul><?php else : ?><span class="muted">—</span><?php endif; ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>

<?php foreach ( $inventaire as $code => $c ) : ?>
<div class="card" style="margin-top:12px<?= $code === $secteur_actif ? ';border:1px solid #3ddc8466' : '' ?>">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
		<h3 style="margin:0"><?= e( $c['libelle'] ) ?><?= $code === $secteur_actif ? ' — secteur actif' : '' ?></h3>
		<span>Couverture <strong style="color:<?= $c['taux'] >= 80 ? '#3ddc84' : ( $c['taux'] >= 50 ? '#ffb020' : '#ff6b6b' ) ?>"><?= (int) $c['taux'] ?> %</strong> · socle <?= e( $c['socle_libelle'] ) ?></span>
	</div>
	<div class="card-body">
		<p style="margin:0 0 6px"><strong>Objet central :</strong> <?= e( $c['objet'] ) ?></p>
		<p style="margin:0 0 6px"><strong>Cycle :</strong> <?= e( implode( ' → ', $c['cycle'] ) ) ?></p>
		<p style="margin:0 0 6px;font-size:12.5px"><strong>Déjà servi par :</strong> <?= e( implode( ', ', $c['presentes'] ) ) ?></p>
		<?php if ( $c['absentes'] ) : ?><p style="margin:0 0 6px;color:#ff6b6b;font-size:12.5px"><strong>Briques annoncées mais absentes de ce dossier :</strong> <?= e( implode( ', ', array_keys( $c['absentes'] ) ) ) ?></p><?php endif; ?>
		<?php if ( $c['manques'] ) : ?>
			<p style="margin:0;font-size:12.5px;color:#ffb020"><strong>Manque :</strong> <?= e( implode( ' · ', $c['manques'] ) ) ?></p>
		<?php else : ?>
			<p style="margin:0;font-size:12.5px;color:#3ddc84"><strong>Métier couvert.</strong></p>
		<?php endif; ?>
	</div>
</div>
<?php endforeach; ?>
