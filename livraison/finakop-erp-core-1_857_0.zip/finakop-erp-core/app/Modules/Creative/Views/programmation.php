<?php
/**
 * Catalogue de programmes, droits de diffusion et grille (1.796.0).
 * @var array $programmes @var array $grilles @var array|null $grille @var array $cases
 * @var array $expirent @var array $types @var array $origines @var array $supports @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$jours = array( 1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi', 5 => 'Vendredi', 6 => 'Samedi', 7 => 'Dimanche' );
?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div><?php endif; ?>
<div class="card"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
	<h2 style="margin:0">Grille & catalogue de programmes</h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'creative/programmation/diffusions' ) ) ?>">Conducteur & preuves</a>
</div><div class="card-body">
	<p class="muted" style="margin:0;font-size:12.5px">Un programme acquis ou coproduit ne se place en grille que dans sa fenêtre de droits : le conducteur saute les cases dont la licence a expiré, au lieu de les diffuser.</p>
</div></div>

<?php if ( $expirent ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Droits qui expirent</h3></div><div class="card-body">
	<?php foreach ( $expirent as $p ) : ?>
		<p style="margin:0 0 4px"><strong><?= e( $p['titre'] ) ?></strong> — licence jusqu'au <?= e( date( 'd/m/Y', strtotime( $p['droits_fin'] ) ) ) ?>
		<?= (int) $p['apres'] ? '<span style="color:#ff6b6b">· ' . (int) $p['apres'] . ' diffusion(s) déjà prévue(s) APRÈS cette date</span>' : '' ?></p>
	<?php endforeach; ?>
</div></div>
<?php endif; ?>

<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Catalogue</h3></div>
<table class="table"><thead><tr><th>Titre</th><th>Type</th><th>Origine</th><th>Durée</th><th>Droits</th><th>Passages</th></tr></thead><tbody>
<?php foreach ( $programmes as $p ) : ?>
	<tr><td><strong><?= e( $p['titre'] ) ?></strong><?= $p['producteur'] ? '<div class="muted" style="font-size:12px">' . e( $p['producteur'] ) . '</div>' : '' ?></td>
		<td><?= e( $types[ $p['type'] ] ?? $p['type'] ) ?></td><td><?= e( $origines[ $p['origine'] ] ?? $p['origine'] ) ?></td>
		<td><?= (int) $p['duree_min'] ?> min</td>
		<td><?= $p['droits_fin'] ? e( date( 'd/m/Y', strtotime( (string) $p['droits_debut'] ) ) . ' → ' . date( 'd/m/Y', strtotime( $p['droits_fin'] ) ) ) : '<span class="muted">sans limite</span>' ?></td>
		<td><?= (int) $p['droits_passages'] ? FKC_Programmation::passages( (int) $p['id'] ) . ' / ' . (int) $p['droits_passages'] : FKC_Programmation::passages( (int) $p['id'] ) ?></td></tr>
<?php endforeach; ?>
<?php if ( ! $programmes ) : ?><tr><td colspan="6" class="muted" style="text-align:center;padding:16px">Catalogue vide.</td></tr><?php endif; ?>
</tbody></table>
<div class="card-body">
	<form method="post" action="<?= e( url( 'creative/programmation/programme' ) ) ?>" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px">
		<?= FKC_Csrf::field() ?>
		<label style="display:flex;flex-direction:column;font-size:12px">Titre<input type="text" name="titre" required></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Type<select name="type"><?php foreach ( $types as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Origine<select name="origine"><?php foreach ( $origines as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Producteur<input type="text" name="producteur"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Durée (min)<input type="number" name="duree_min" value="30"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Droits du<input type="date" name="droits_debut"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">au<input type="date" name="droits_fin"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Passages autorisés<input type="number" name="droits_passages" value="0" title="0 = illimité"></label>
		<div style="grid-column:1/-1"><button class="btn btn-sm">Ajouter au catalogue</button></div>
	</form>
</div></div>

<div class="card card-flush" style="margin-top:12px"><div class="card-head" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
	<h3 style="margin:0">Grille<?= $grille ? ' — ' . e( $grille['libelle'] ) : '' ?></h3>
	<form method="get" style="margin:0"><select name="grille" onchange="this.form.submit()">
		<?php foreach ( $grilles as $g ) : ?><option value="<?= (int) $g['id'] ?>" <?= $grille && (int) $g['id'] === (int) $grille['id'] ? 'selected' : '' ?>><?= e( $g['libelle'] ) ?></option><?php endforeach; ?>
	</select></form>
</div>
<?php if ( $grille ) : ?>
<table class="table"><thead><tr><th>Jour</th><th>Heure</th><th>Programme</th><th>Durée</th><th>Droits jusqu'au</th></tr></thead><tbody>
<?php foreach ( $cases as $c ) : ?>
	<tr><td><?= e( $jours[ (int) $c['jour'] ] ?? $c['jour'] ) ?></td><td><?= e( $c['heure'] ) ?></td>
		<td><?= e( $c['titre'] ) ?><?= (int) $c['rediffusion'] ? ' <span class="muted">(rediffusion)</span>' : '' ?></td>
		<td><?= (int) $c['duree_min'] ?> min</td>
		<td><?= $c['droits_fin'] ? e( date( 'd/m/Y', strtotime( $c['droits_fin'] ) ) ) : '—' ?></td></tr>
<?php endforeach; ?>
<?php if ( ! $cases ) : ?><tr><td colspan="5" class="muted" style="text-align:center;padding:16px">Grille vide.</td></tr><?php endif; ?>
</tbody></table>
<div class="card-body" style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-end">
	<form method="post" action="<?= e( url( 'creative/programmation/case' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap;margin:0">
		<?= FKC_Csrf::field() ?><input type="hidden" name="grille_id" value="<?= (int) $grille['id'] ?>">
		<label style="display:flex;flex-direction:column;font-size:12px">Programme<select name="programme_id"><?php foreach ( $programmes as $p ) : ?><option value="<?= (int) $p['id'] ?>"><?= e( $p['titre'] ) ?></option><?php endforeach; ?></select></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Jour<select name="jour"><?php foreach ( $jours as $k => $v ) : ?><option value="<?= (int) $k ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Heure<input type="time" name="heure" value="18:00"></label>
		<label style="font-size:12px"><input type="checkbox" name="rediffusion" value="1"> Rediffusion</label>
		<button class="btn btn-ghost btn-sm">Placer en grille</button>
	</form>
	<form method="post" action="<?= e( url( 'creative/programmation/conducteur' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;margin:0">
		<?= FKC_Csrf::field() ?><input type="hidden" name="grille_id" value="<?= (int) $grille['id'] ?>">
		<label style="display:flex;flex-direction:column;font-size:12px">Du<input type="date" name="du" value="<?= e( max( $grille['date_debut'], date( 'Y-m-01' ) ) ) ?>"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Au<input type="date" name="au" value="<?= e( min( $grille['date_fin'], date( 'Y-m-t' ) ) ) ?>"></label>
		<button class="btn btn-sm">Générer le conducteur</button>
	</form>
</div>
<?php endif; ?>
<div class="card-body">
	<form method="post" action="<?= e( url( 'creative/programmation/grille' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap;margin:0">
		<?= FKC_Csrf::field() ?>
		<label style="display:flex;flex-direction:column;font-size:12px">Nouvelle grille<input type="text" name="libelle" placeholder="Grille d'antenne 2026"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Support<select name="support"><?php foreach ( $supports as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Du<input type="date" name="date_debut"></label>
		<label style="display:flex;flex-direction:column;font-size:12px">Au<input type="date" name="date_fin"></label>
		<button class="btn btn-ghost btn-sm">Créer la grille</button>
	</form>
</div></div>
