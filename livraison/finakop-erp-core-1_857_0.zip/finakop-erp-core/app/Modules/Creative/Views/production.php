<?php
/**
 * Œuvres audiovisuelles — financement, coproduction, fenêtres, recettes (1.797.0).
 * @var array $projets @var array|null $synthese @var array $financements @var array $coproducteurs
 * @var array $fenetres @var array $remontees @var array $repartitions @var array $types @var array $statuts
 * @var array $types_financement @var array $types_fenetre @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$p = $synthese['projet'] ?? null; $pl = $synthese['plan'] ?? null;
$lab = function ( $l, $in ) { return '<label style="display:flex;flex-direction:column;font-size:12px">' . $l . $in . '</label>'; };
?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div><?php endif; ?>
<div class="card"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
	<h2 style="margin:0">Œuvres audiovisuelles<?= $p ? ' — ' . e( $p['titre'] ) : '' ?></h2>
	<form method="get" style="margin:0"><select name="id" onchange="this.form.submit()"><?php foreach ( $projets as $x ) : ?><option value="<?= (int) $x['id'] ?>" <?= $p && (int) $x['id'] === (int) $p['id'] ? 'selected' : '' ?>><?= e( $x['titre'] ) ?></option><?php endforeach; ?></select></form>
</div><div class="card-body">
	<form method="post" action="<?= e( url( 'creative/production/creer' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap;margin:0"><?= FKC_Csrf::field() ?>
		<?= $lab( 'Nouvelle œuvre', '<input type="text" name="titre">' ) ?>
		<label style="display:flex;flex-direction:column;font-size:12px">Type<select name="type"><?php foreach ( $types as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
		<?= $lab( 'Budget (F)', '<input type="text" name="budget">' ) ?>
		<?= $lab( 'Livraison prévue', '<input type="date" name="date_livraison_prevue">' ) ?>
		<button class="btn btn-sm">Créer</button>
	</form>
</div></div>

<?php if ( $p ) : ?>
<div class="card" style="margin-top:12px"><div class="card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px">
	<div><div class="muted" style="font-size:12px">Budget</div><strong><?= fkc_money( $pl['budget'] ) ?> F</strong><div class="muted" style="font-size:12px"><?= e( $statuts[ $p['statut'] ] ?? $p['statut'] ) ?></div></div>
	<div><div class="muted" style="font-size:12px">Plan de financement</div><strong style="color:<?= $pl['trou'] > 0 ? '#ffb020' : '#3ddc84' ?>"><?= e( (string) $pl['couverture_pct'] ) ?> %</strong><div class="muted" style="font-size:12px">sécurisé <?= e( (string) $pl['securise_pct'] ) ?> %<?= $pl['trou'] > 0 ? ' · trou ' . fkc_money( $pl['trou'] ) . ' F' : '' ?></div></div>
	<div><div class="muted" style="font-size:12px">Recettes nettes producteur</div><strong><?= fkc_money( $synthese['recettes_nettes'] ) ?> F</strong><div class="muted" style="font-size:12px">sur <?= fkc_money( $synthese['recettes_brutes'] ) ?> F bruts</div></div>
	<div><div class="muted" style="font-size:12px">Amortissement du budget</div><strong><?= e( (string) $synthese['amortissement_pct'] ) ?> %</strong><div class="muted" style="font-size:12px">part du délégué <?= e( (string) $synthese['part_delegue_pct'] ) ?> %</div></div>
</div>
<?php if ( 'livre' !== $p['statut'] ) : ?><div class="card-body" style="padding-top:0"><form method="post" action="<?= e( url( 'creative/production/livrer' ) ) ?>" style="display:flex;gap:6px;margin:0"><?= FKC_Csrf::field() ?><input type="hidden" name="projet_id" value="<?= (int) $p['id'] ?>"><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>"><button class="btn btn-ghost btn-sm">Constater la livraison</button><span class="muted" style="font-size:12px">— c'est elle qui rend acquises les préventes et les minimums garantis.</span></form></div><?php endif; ?>
</div>

<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Plan de financement</h3></div>
<table class="table"><thead><tr><th>Source</th><th>Organisme</th><th class="right">Montant</th><th>Statut</th><th>Traitement comptable</th></tr></thead><tbody>
<?php foreach ( $financements as $f ) : $t = $types_financement[ $f['type'] ]; ?>
	<tr><td><?= e( $t[0] ) ?></td><td><?= e( $f['organisme'] ) ?></td><td class="right"><?= fkc_money( $f['montant'] ) ?></td>
	<td><?= e( $f['statut'] ) ?><?= $f['date_encaissement'] ? ' le ' . e( date( 'd/m/Y', strtotime( $f['date_encaissement'] ) ) ) : '' ?></td><td class="muted" style="font-size:12px"><?= e( $t[2] ) ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<div class="card-body"><form method="post" action="<?= e( url( 'creative/production/financement' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap;margin:0"><?= FKC_Csrf::field() ?>
	<input type="hidden" name="projet_id" value="<?= (int) $p['id'] ?>">
	<label style="display:flex;flex-direction:column;font-size:12px">Source<select name="type"><?php foreach ( $types_financement as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v[0] ) ?></option><?php endforeach; ?></select></label>
	<?= $lab( 'Organisme', '<input type="text" name="organisme">' ) ?><?= $lab( 'Montant', '<input type="text" name="montant">' ) ?>
	<label style="display:flex;flex-direction:column;font-size:12px">Statut<select name="statut"><option value="prevu">Prévu</option><option value="acquis">Acquis (contrat signé)</option><option value="encaisse">Encaissé</option></select></label>
	<?= $lab( 'Encaissé le', '<input type="date" name="date_encaissement">' ) ?>
	<button class="btn btn-ghost btn-sm">Ajouter</button>
</form></div></div>

<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Coproducteurs</h3></div>
<table class="table"><thead><tr><th>Coproducteur</th><th class="right">Quote-part</th><th class="right">Apport</th></tr></thead><tbody>
<?php foreach ( $coproducteurs as $c ) : ?><tr><td><?= e( $c['nom'] ) ?></td><td class="right"><?= e( (string) $c['quote_part'] ) ?> %</td><td class="right"><?= fkc_money( $c['apport'] ) ?></td></tr><?php endforeach; ?>
<tr><td class="muted">Producteur délégué</td><td class="right"><?= e( (string) $synthese['part_delegue_pct'] ) ?> %</td><td></td></tr>
</tbody></table>
<div class="card-body"><form method="post" action="<?= e( url( 'creative/production/coproducteur' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;margin:0"><?= FKC_Csrf::field() ?>
	<input type="hidden" name="projet_id" value="<?= (int) $p['id'] ?>"><?= $lab( 'Coproducteur', '<input type="text" name="nom">' ) ?><?= $lab( 'Quote-part %', '<input type="text" name="quote_part" style="width:80px">' ) ?><?= $lab( 'Apport', '<input type="text" name="apport">' ) ?>
	<button class="btn btn-ghost btn-sm">Ajouter</button>
</form></div></div>

<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Fenêtres d'exploitation</h3></div>
<table class="table"><thead><tr><th>Mode</th><th>Territoire</th><th>Partenaire</th><th>Période</th><th>Commission</th></tr></thead><tbody>
<?php foreach ( $fenetres as $f ) : ?><tr><td><?= e( $types_fenetre[ $f['type'] ] ?? $f['type'] ) ?><?= $f['exclusif'] ? ' <span class="muted">(exclusif)</span>' : '' ?></td><td><?= e( $f['territoire'] ) ?></td><td><?= e( $f['partenaire'] ) ?></td>
	<td><?= e( date( 'd/m/Y', strtotime( $f['date_debut'] ) ) . ' → ' . date( 'd/m/Y', strtotime( $f['date_fin'] ) ) ) ?></td><td><?= e( (string) $f['commission_pct'] ) ?> %</td></tr><?php endforeach; ?>
</tbody></table>
<div class="card-body"><form method="post" action="<?= e( url( 'creative/production/fenetre' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap;margin:0"><?= FKC_Csrf::field() ?>
	<input type="hidden" name="projet_id" value="<?= (int) $p['id'] ?>">
	<label style="display:flex;flex-direction:column;font-size:12px">Mode<select name="type"><?php foreach ( $types_fenetre as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
	<?= $lab( 'Territoire', '<input type="text" name="territoire" value="Côte d\'Ivoire">' ) ?><?= $lab( 'Partenaire', '<input type="text" name="partenaire">' ) ?>
	<?= $lab( 'Du', '<input type="date" name="date_debut">' ) ?><?= $lab( 'Au', '<input type="date" name="date_fin">' ) ?><?= $lab( 'Commission %', '<input type="text" name="commission_pct" style="width:70px">' ) ?>
	<label style="font-size:12px"><input type="checkbox" name="exclusif" value="1"> Exclusif</label>
	<button class="btn btn-ghost btn-sm">Ouvrir la fenêtre</button>
</form></div></div>

<div class="card card-flush" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Remontées de recettes et quotes-parts</h3></div>
<table class="table"><thead><tr><th>Exploitant</th><th>Période</th><th class="right">Brut</th><th class="right">Commission</th><th class="right">Frais</th><th class="right">Net producteur</th></tr></thead><tbody>
<?php foreach ( $remontees as $r ) : ?><tr><td><?= e( $r['exploitant'] ) ?></td><td><?= e( FKC_RnPeriode::libelle( $r['periode_debut'], $r['periode_fin'] ) ) ?></td>
	<td class="right"><?= fkc_money( $r['recettes_brutes'] ) ?></td><td class="right"><?= fkc_money( $r['commission'] ) ?></td><td class="right"><?= fkc_money( $r['frais'] ) ?></td><td class="right"><?= fkc_money( $r['net_producteur'] ) ?></td></tr><?php endforeach; ?>
</tbody></table>
<?php if ( $repartitions ) : ?><div class="card-body" style="font-size:12.5px"><?php foreach ( $repartitions as $r ) : ?>
	<div style="display:flex;gap:8px;align-items:center;margin-bottom:4px"><?= e( $r['nom'] ) ?> (<?= e( (string) $r['quote_part'] ) ?> %) : <?= fkc_money( $r['montant'] ) ?> F — <?= $r['reverse'] ? 'reversé le ' . e( date( 'd/m/Y', strtotime( (string) $r['date_reversement'] ) ) ) : ( $r['encaisse'] ? '<span style="color:#ffb020">dû</span>' : 'recette non encaissée' ) ?>
	<?php if ( ! $r['reverse'] && $r['encaisse'] ) : ?><form method="post" action="<?= e( url( 'creative/production/reverser' ) ) ?>" style="margin:0"><?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="projet_id" value="<?= (int) $p['id'] ?>"><button class="btn btn-ghost btn-sm">Reverser</button></form><?php endif; ?></div>
<?php endforeach; ?></div><?php endif; ?>
<div class="card-body"><form method="post" action="<?= e( url( 'creative/production/remontee' ) ) ?>" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap;margin:0"><?= FKC_Csrf::field() ?>
	<input type="hidden" name="projet_id" value="<?= (int) $p['id'] ?>">
	<label style="display:flex;flex-direction:column;font-size:12px">Fenêtre<select name="fenetre_id"><option value="">—</option><?php foreach ( $fenetres as $f ) : ?><option value="<?= (int) $f['id'] ?>"><?= e( ( $types_fenetre[ $f['type'] ] ?? $f['type'] ) . ' — ' . $f['partenaire'] ) ?></option><?php endforeach; ?></select></label>
	<?= $lab( 'Exploitant', '<input type="text" name="exploitant">' ) ?><?= $lab( 'Du', '<input type="date" name="periode_debut">' ) ?><?= $lab( 'Au', '<input type="date" name="periode_fin">' ) ?>
	<?= $lab( 'Recettes brutes', '<input type="text" name="recettes_brutes">' ) ?><?= $lab( 'Frais', '<input type="text" name="frais">' ) ?>
	<button class="btn btn-ghost btn-sm">Enregistrer la remontée</button>
</form></div></div>
<?php endif; ?>
