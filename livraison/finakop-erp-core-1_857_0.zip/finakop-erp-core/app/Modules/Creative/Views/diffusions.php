<?php
/**
 * Conducteur, constats et preuves de diffusion (1.796.0).
 * @var string $du @var string $au @var array $conducteur @var array $synthese
 * @var array $non_constatees @var array $hors_droits @var array $avance @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$st = array( 'prevue' => array( 'Prévue', '#9aa3b5' ), 'diffusee' => array( 'Diffusée', '#3ddc84' ), 'reportee' => array( 'Reportée', '#ffb020' ), 'annulee' => array( 'Annulée', '#ff6b6b' ) );
?>
<?php if ( ! empty( $flash ) ) : ?><div class="alert alert-<?= 'ok' === ( $flash['type'] ?? '' ) ? 'ok' : 'err' ?>"><?= e( (string) $flash['msg'] ) ?></div><?php endif; ?>
<div class="card"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
	<h2 style="margin:0">Conducteur & preuves de diffusion</h2>
	<form method="get" style="display:flex;gap:6px;margin:0">
		<input type="date" name="du" value="<?= e( $du ) ?>"><input type="date" name="au" value="<?= e( $au ) ?>">
		<button class="btn btn-ghost btn-sm">Voir</button>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'creative/programmation' ) ) ?>">Grille</a>
	</form>
</div><div class="card-body">
	<p style="margin:0"><?= (int) $synthese['diffusees'] ?> diffusée(s) · <?= (int) $synthese['prevues'] ?> prévue(s) · <?= (int) $synthese['reportees'] ?> reportée(s) ·
	<?= (int) $synthese['minutes'] ?> minutes d'antenne<?= (int) $synthese['sans_preuve'] ? ' · <span style="color:#ffb020">' . (int) $synthese['sans_preuve'] . ' sans preuve jointe</span>' : '' ?></p>
</div></div>

<?php if ( $hors_droits || $non_constatees || $avance ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">À traiter</h3></div><div class="card-body">
	<?php foreach ( $hors_droits as $h ) : ?>
		<p style="margin:0 0 4px;color:#ff6b6b">« <?= e( $h['titre'] ) ?> » est prévu le <?= e( date( 'd/m/Y', strtotime( $h['date'] ) ) ) ?>, après la fin de ses droits (<?= e( date( 'd/m/Y', strtotime( $h['droits_fin'] ) ) ) ?>).</p>
	<?php endforeach; ?>
	<?php if ( $non_constatees ) : ?><p style="margin:0 0 4px;color:#ffb020"><?= count( $non_constatees ) ?> diffusion(s) passée(s) jamais constatée(s) : sans constat, aucune preuve.</p><?php endif; ?>
	<?php foreach ( $avance as $a ) : ?>
		<p style="margin:0 0 4px;color:#ffb020"><?= e( $a['libelle'] ) ?> — <?= e( $a['passages'] ) ?> passages diffusés : <?= fkc_money( $a['a_reporter'] ) ?> F facturés mais non encore acquis (produit constaté d'avance).</p>
	<?php endforeach; ?>
</div></div>
<?php endif; ?>

<div class="card card-flush" style="margin-top:12px">
<table class="table"><thead><tr><th>Date</th><th>Heure</th><th>Programme</th><th>Durée</th><th>Statut</th><th>Preuve</th><th></th></tr></thead><tbody>
<?php foreach ( $conducteur as $d ) : $s = $st[ $d['statut'] ] ?? array( $d['statut'], '#9aa3b5' ); ?>
	<tr>
		<td><?= e( date( 'd/m/Y', strtotime( $d['date'] ) ) ) ?></td><td><?= e( $d['heure'] ) ?></td>
		<td><?= e( $d['titre'] ) ?></td><td><?= (int) $d['duree_min'] ?> min</td>
		<td style="color:<?= e( $s[1] ) ?>"><?= e( $s[0] ) ?><?= $d['motif'] ? '<div class="muted" style="font-size:12px">' . e( $d['motif'] ) . '</div>' : '' ?></td>
		<td style="font-size:12px"><?= e( $d['preuve'] ) ?></td>
		<td style="white-space:nowrap">
		<?php if ( 'prevue' === $d['statut'] ) : ?>
			<form method="post" action="<?= e( url( 'creative/programmation/constater' ) ) ?>" style="display:inline-flex;gap:4px;margin:0">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<input type="text" name="preuve" placeholder="référence de la preuve" style="width:150px">
				<button class="btn btn-sm">Constater</button>
			</form>
			<form method="post" action="<?= e( url( 'creative/programmation/reporter' ) ) ?>" style="display:inline-flex;gap:4px;margin:0">
				<?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
				<input type="text" name="motif" placeholder="motif" style="width:110px"><input type="date" name="date">
				<button class="btn btn-ghost btn-sm">Reporter</button>
			</form>
		<?php endif; ?>
		</td>
	</tr>
<?php endforeach; ?>
<?php if ( ! $conducteur ) : ?><tr><td colspan="7" class="muted" style="text-align:center;padding:18px">Aucune diffusion sur la période : générez le conducteur depuis la grille.</td></tr><?php endif; ?>
</tbody></table></div>
