<?php
/**
 * ÉCRAN « COUVERTURE MÉTIER » DES SECTEURS CRÉATIFS (1.795.0).
 *
 * Ce que FinaKop sait faire du métier de chaque secteur, ce qui manque encore,
 * et dans quel socle commun le manque sera comblé. L'écran lit l'inventaire
 * (FKC_CreativeMetier) et le confronte au code présent dans CE dossier.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_CreativeMetierController {

	public function index() {
		$actif = class_exists( 'FKC_Secteur' ) ? (string) FKC_Secteur::active() : '';
		FKC_View::render( 'Creative::couverture', array(
			'title' => 'Créatif · Couverture métier',
			'tab' => 'metiers',
			'inventaire' => FKC_CreativeMetier::inventaire(),
			'socles' => FKC_CreativeMetier::parSocle(),
			'secteur_actif' => $actif,
		) );
	}
}
