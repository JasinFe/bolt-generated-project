<?php
/**
 * ÉCRANS « PROGRAMMATION & DIFFUSION » (1.796.0) — socle commun aux secteurs
 * d'antenne et d'édition en ligne : catalogue de programmes et droits, grille,
 * conducteur, preuve de diffusion.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ProgrammationController {

	protected function flash() { $m = $_SESSION['__flash_prog'] ?? null; unset( $_SESSION['__flash_prog'] ); return $m; }
	protected function setFlash( $m, $ok = true ) { $_SESSION['__flash_prog'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $m ); }

	protected function vue( $vue, array $data ) {
		FKC_View::render( 'Creative::' . $vue, array_merge( array(
			'title' => 'Créatif · Programmation',
			'tab' => 'programmation',
			'flash' => $this->flash(),
			'supports' => FKC_Programmation::supports(),
			'types' => FKC_Programmation::typesProgramme(),
			'origines' => FKC_Programmation::origines(),
		), $data ) );
	}

	/** Catalogue et grille. */
	public function index() {
		$gid = (int) ( $_GET['grille'] ?? 0 );
		$grilles = FKC_Programmation::grilles();
		if ( ! $gid && $grilles ) { $gid = (int) $grilles[0]['id']; }
		$this->vue( 'programmation', array(
			'programmes' => FKC_Programmation::programmes(),
			'grilles' => $grilles,
			'grille' => $gid ? FKC_Programmation::grille( $gid ) : null,
			'cases' => $gid ? FKC_Programmation::cases( $gid ) : array(),
			'expirent' => FKC_Programmation::droitsQuiExpirent(),
		) );
	}

	/** Conducteur, constats et attestations. */
	public function diffusions() {
		$du = (string) ( $_GET['du'] ?? date( 'Y-m-01' ) );
		$au = (string) ( $_GET['au'] ?? date( 'Y-m-t' ) );
		$this->vue( 'diffusions', array(
			'du' => $du, 'au' => $au,
			'conducteur' => FKC_Programmation::conducteur( $du, $au ),
			'synthese' => FKC_Programmation::synthese( $du, $au ),
			'non_constatees' => FKC_Programmation::diffusionsNonConstatees(),
			'hors_droits' => FKC_Programmation::diffusionsHorsDroits(),
			'avance' => FKC_Programmation::produitsAvance( class_exists( 'FKC_Exercice' ) ? FKC_Exercice::courant() : (int) date( 'Y' ) ),
		) );
	}

	public function creerProgramme() {
		list( $ok, $msg ) = FKC_Programmation::creerProgramme( $_POST );
		$this->setFlash( $msg, $ok ); redirect( 'creative/programmation' );
	}

	public function creerGrille() {
		list( $ok, $msg ) = FKC_Programmation::creerGrille( $_POST );
		$this->setFlash( $msg, $ok ); redirect( 'creative/programmation' );
	}

	public function ajouterCase() {
		list( $ok, $msg ) = FKC_Programmation::ajouterCase( (int) ( $_POST['grille_id'] ?? 0 ), $_POST );
		$this->setFlash( $msg, $ok ); redirect( 'creative/programmation?grille=' . (int) ( $_POST['grille_id'] ?? 0 ) );
	}

	public function genererConducteur() {
		list( $ok, $msg ) = FKC_Programmation::genererConducteur( (int) ( $_POST['grille_id'] ?? 0 ), (string) ( $_POST['du'] ?? '' ), (string) ( $_POST['au'] ?? '' ) );
		$this->setFlash( $msg, $ok ); redirect( 'creative/programmation/diffusions?du=' . urlencode( (string) ( $_POST['du'] ?? '' ) ) . '&au=' . urlencode( (string) ( $_POST['au'] ?? '' ) ) );
	}

	public function constater() {
		list( $ok, $msg ) = FKC_Programmation::marquerDiffuse( (int) ( $_POST['id'] ?? 0 ), (string) ( $_POST['preuve'] ?? '' ) );
		$this->setFlash( $msg, $ok ); redirect( 'creative/programmation/diffusions' );
	}

	public function reporter() {
		list( $ok, $msg ) = FKC_Programmation::reporter( (int) ( $_POST['id'] ?? 0 ), (string) ( $_POST['motif'] ?? '' ), (string) ( $_POST['date'] ?? '' ) ?: null );
		$this->setFlash( $msg, $ok ); redirect( 'creative/programmation/diffusions' );
	}
}
