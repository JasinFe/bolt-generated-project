<?php
/**
 * ÉCRAN « ŒUVRES AUDIOVISUELLES » (1.797.0) — socle Production audiovisuelle :
 * financement, coproducteurs, fenêtres d'exploitation, remontées de recettes.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ProductionAvController {

	protected function flash() { $m = $_SESSION['__flash_av'] ?? null; unset( $_SESSION['__flash_av'] ); return $m; }
	protected function setFlash( $m, $ok = true ) { $_SESSION['__flash_av'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $m ); }
	protected function retour( $id = 0 ) { redirect( 'creative/production' . ( $id ? '?id=' . (int) $id : '' ) ); }

	public function index() {
		$id = (int) ( $_GET['id'] ?? 0 );
		$projets = FKC_ProductionAv::projets();
		if ( ! $id && $projets ) { $id = (int) $projets[0]['id']; }
		FKC_View::render( 'Creative::production', array(
			'title' => 'Créatif · Œuvres audiovisuelles',
			'tab' => 'production',
			'flash' => $this->flash(),
			'projets' => $projets,
			'synthese' => $id ? FKC_ProductionAv::synthese( $id ) : null,
			'financements' => $id ? FKC_ProductionAv::financements( $id ) : array(),
			'coproducteurs' => $id ? FKC_ProductionAv::coproducteurs( $id ) : array(),
			'fenetres' => $id ? FKC_ProductionAv::fenetres( $id ) : array(),
			'remontees' => $id ? FKC_ProductionAv::remontees( $id ) : array(),
			'repartitions' => $id ? FKC_ProductionAv::repartitions( $id ) : array(),
			'types' => FKC_ProductionAv::types(),
			'statuts' => FKC_ProductionAv::statuts(),
			'types_financement' => FKC_ProductionAv::typesFinancement(),
			'types_fenetre' => FKC_ProductionAv::typesFenetre(),
		) );
	}

	public function creer() { list( $ok, $m, $id ) = FKC_ProductionAv::creerProjet( $_POST ); $this->setFlash( $m, $ok ); $this->retour( $ok ? $id : 0 ); }
	public function financement() { $id = (int) ( $_POST['projet_id'] ?? 0 ); list( $ok, $m ) = FKC_ProductionAv::ajouterFinancement( $id, $_POST ); $this->setFlash( $m, $ok ); $this->retour( $id ); }
	public function coproducteur() { $id = (int) ( $_POST['projet_id'] ?? 0 ); list( $ok, $m ) = FKC_ProductionAv::ajouterCoproducteur( $id, $_POST ); $this->setFlash( $m, $ok ); $this->retour( $id ); }
	public function fenetre() { $id = (int) ( $_POST['projet_id'] ?? 0 ); list( $ok, $m ) = FKC_ProductionAv::ajouterFenetre( $id, $_POST ); $this->setFlash( $m, $ok ); $this->retour( $id ); }
	public function remontee() { $id = (int) ( $_POST['projet_id'] ?? 0 ); list( $ok, $m ) = FKC_ProductionAv::ajouterRemontee( $id, $_POST ); $this->setFlash( $m, $ok ); $this->retour( $id ); }
	public function livrer() { $id = (int) ( $_POST['projet_id'] ?? 0 ); list( $ok, $m ) = FKC_ProductionAv::livrer( $id, (string) ( $_POST['date'] ?? '' ) ); $this->setFlash( $m, $ok ); $this->retour( $id ); }
	public function reverser() { list( $ok, $m ) = FKC_ProductionAv::reverser( (int) ( $_POST['id'] ?? 0 ), (string) ( $_POST['date'] ?? date( 'Y-m-d' ) ) ); $this->setFlash( $m, $ok ); $this->retour( (int) ( $_POST['projet_id'] ?? 0 ) ); }
}
