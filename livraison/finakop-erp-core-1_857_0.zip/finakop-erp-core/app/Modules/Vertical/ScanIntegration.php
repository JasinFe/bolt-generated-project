<?php
/**
 * Moteur vertical × Scan — le DOSSIER devient un objet scannable.
 *
 * CE QUE CE FICHIER RÉSOUT
 *
 * Sept packs sur cinquante ont la brique stock ; les quarante-trois autres
 * travaillent sur des DOSSIERS : une mission de cabinet, un chantier, une
 * hospitalisation, un contrat d'assurance, une commande d'imprimerie, un
 * élève inscrit. Le moteur de scan ne résolvait que le vocabulaire du
 * commerce — article, lot, palette, immobilisation — de sorte que dans ces
 * quarante-trois packs, scanner ne servait à rien.
 *
 * POURQUOI UN SEUL FICHIER SUFFIT
 *
 * Ces packs ne stockent pas chacun ses dossiers : ils partagent la table
 * `vp_dossiers`, distinguée par une colonne `pack`. Le dossier est donc un
 * objet du MOTEUR VERTICAL, pas de chaque pack — et c'est au moteur de le
 * déclarer, une fois. Un pack qui veut aller plus loin garde la main : le
 * cabinet juridique déclare son propre type « affaire » sur sa table `jr_`,
 * avec sa logique de délais, sans que rien d'ici le gêne.
 *
 * LE CLOISONNEMENT PAR PACK N'EST PAS COSMÉTIQUE
 *
 * `vp_dossiers` étant commune, un code scanné pourrait résoudre un dossier
 * appartenant à un pack qui n'est pas actif. Le résolveur refuse ce cas :
 * ouvrir « clinique/dossiers/412 » alors que le pack actif est « btp »
 * mènerait à une route qui n'existe pas — et, pire, afficherait à
 * l'utilisateur le libellé d'un dossier qui ne le concerne pas.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

/**
 * Intégration du dossier vertical au moteur de scan.
 *
 * Regroupée dans une classe plutôt qu'écrite à la racine du fichier : les
 * fermetures ont besoin de ces deux helpers, et une fonction globale de plus
 * dans l'espace de noms n'apporterait rien.
 */
class FKC_VpScan {

	/** Code du pack actif, en minuscules, ou '' si aucun. */
	public static function packActif() {
		if ( ! class_exists( 'FKC_Packs' ) ) { return ''; }
		try { return strtolower( (string) FKC_Packs::verticalModule() ); }
		catch ( \Throwable $e ) { return ''; }
	}

	/**
	 * Nombre de pièces rattachées à un dossier.
	 *
	 * Chargé avec le dossier : c'est ce qui dit si le dossier a déjà produit
	 * quelque chose de facturable, et l'analyseur ci-dessous en dépend.
	 */
	public static function nbPieces( $dossierId ) {
		try {
			return (int) FKC_DB::q(
				'SELECT COUNT(*) FROM vp_pieces WHERE dossier_id=?', array( (int) $dossierId )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Pièces par TYPE et par statut : array( type => array( n, ht, valides ) ).
	 *
	 * POURQUOI LE DÉTAIL, ET PAS SEULEMENT LE COMPTE
	 *
	 * L'analyseur générique n'a besoin que de savoir s'il y a zéro pièce. Les
	 * analyseurs SECTORIELS, eux, raisonnent sur la composition : un courtier
	 * qui a encaissé une prime sans la reverser à la compagnie, une imprimerie
	 * qui a facturé la création sans l'impression. Ce sont des types de pièces
	 * déclarés par le manifeste du pack, donc parfaitement fiables — à la
	 * différence du JSON libre de la colonne `champs`.
	 *
	 * Une seule requête, agrégée : un analyseur qui interrogerait la base à
	 * chaque scan ferait payer son confort au poste de travail.
	 */
	public static function piecesParType( $dossierId ) {
		$out = array();
		try {
			$rows = FKC_DB::q(
				"SELECT type, COUNT(*) n, COALESCE(SUM(montant_ht),0) ht,
				        SUM(CASE WHEN statut='brouillon' THEN 0 ELSE 1 END) valides
				 FROM vp_pieces WHERE dossier_id=? GROUP BY type",
				array( (int) $dossierId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( (array) $rows as $r ) {
			$out[ (string) $r['type'] ] = array(
				'n' => (int) $r['n'], 'ht' => (float) $r['ht'], 'valides' => (int) $r['valides'],
			);
		}
		return $out;
	}

	/**
	 * Champs métier du dossier, décodés depuis le JSON de `vp_dossiers.champs`.
	 *
	 * Le cœur ne sait pas ce que ces clés veulent dire — c'est le manifeste du
	 * pack qui les déclare. Il se contente donc de les décoder proprement et de
	 * rendre un tableau, à charge pour l'analyseur du pack d'y lire ce qu'il a
	 * lui-même déclaré. Un JSON illisible rend un tableau vide plutôt qu'une
	 * erreur : un champ mal formé ne doit pas empêcher le scan.
	 */
	public static function champs( $brut ) {
		$json = is_array( $brut ) ? ( $brut['champs'] ?? '' ) : '';
		if ( ! is_string( $json ) || '' === trim( $json ) ) { return array(); }
		$d = json_decode( $json, true );
		return is_array( $d ) ? $d : array();
	}

	/** Le dossier est-il clos ? Les statuts fermants du moteur vertical. */
	public static function estClos( $statut ) {
		return in_array( strtolower( (string) $statut ), array( 'clos', 'cloture', 'clôturé', 'cloture', 'annule', 'annulé' ), true );
	}
}

/* ═══════════════════ RÉSOLVEUR ═══════════════════ */

if ( class_exists( 'FKC_Scan' ) ) {
	FKC_Scan::resolveur( 'dossier', function ( $id ) {
		try {
			$d = FKC_DB::q( 'SELECT * FROM vp_dossiers WHERE id=?', array( (int) $id ) )->fetch();
		} catch ( \Throwable $e ) { return null; }
		if ( ! $d ) { return null; }

		/*
		 * Refus explicite du dossier d'un autre pack. Rendre null plutôt qu'un
		 * objet partiel : le moteur affichera « code inconnu », ce qui est la
		 * vérité utile — ce code ne veut rien dire ICI.
		 */
		$actif = FKC_VpScan::packActif();
		if ( '' !== $actif && strtolower( (string) $d['pack'] ) !== $actif ) { return null; }

		return array(
			'libelle'      => (string) $d['code'] . ' — ' . (string) $d['libelle'],
			'code_interne' => (string) $d['code'],
			'statut'       => (string) $d['statut'],
			'pack'         => (string) $d['pack'],
			'tiers'        => (string) ( $d['tiers_nom'] ?? '' ),
			'montant_ref'  => (float) ( $d['montant_ref'] ?? 0 ),
			'date_fin'     => (string) ( $d['date_fin'] ?? '' ),
			'pieces'       => FKC_VpScan::nbPieces( (int) $id ),
			// Mis à disposition des analyseurs SECTORIELS des packs. Le cœur ne
			// s'en sert pas : lui ne raisonne que sur « zéro pièce ou non ».
			'pieces_type'  => FKC_VpScan::piecesParType( (int) $id ),
			'champs'       => FKC_VpScan::champs( $d ),
			'brut'         => $d,
		);
	} );
}

/* ═══════════════════ PORTES ═══════════════════ */

if ( class_exists( 'FKC_ScanNavigation' ) ) {

	/*
	 * Les routes sont construites depuis le pack ACTIF, pas depuis le pack du
	 * dossier : le résolveur a déjà garanti qu'ils coïncident. Une porte dont
	 * la route serait vide est ignorée par le moteur, donc rien ne s'affiche
	 * hors contexte vertical.
	 */
	FKC_ScanNavigation::porte( 'dossier', array(
		'libelle' => 'Ouvrir le dossier', 'icone' => '📂', 'priorite' => 5,
		'route' => function ( $r ) {
			$p = FKC_VpScan::packActif();
			return '' === $p ? '' : $p . '/dossiers/' . (int) $r->id();
		},
		'description' => 'Fiche, champs métier, pièces rattachées',
	) );

	FKC_ScanNavigation::porte( 'dossier', array(
		'libelle' => 'Ses pièces', 'icone' => '🧾', 'priorite' => 6,
		'route' => function ( $r ) {
			$p = FKC_VpScan::packActif();
			return '' === $p ? '' : $p . '/dossiers/' . (int) $r->id() . '/pieces';
		},
		'description' => 'Ce que le dossier a déjà produit de facturable',
		'visible' => function ( $r ) {
			return (int) ( $r->objet( 'dossier' )['donnees']['pieces'] ?? 0 ) > 0;
		},
	) );

	FKC_ScanNavigation::porte( 'dossier', array(
		'libelle' => 'Nouvelle pièce', 'icone' => '➕', 'priorite' => 7,
		'route' => function ( $r ) {
			$p = FKC_VpScan::packActif();
			return '' === $p ? '' : $p . '/dossiers/' . (int) $r->id() . '/pieces/nouvelle';
		},
		'description' => 'Facturer une prestation sur ce dossier',
		// Un dossier clos ne se facture plus : offrir le geste serait offrir
		// une erreur.
		'visible' => function ( $r ) {
			return ! FKC_VpScan::estClos( $r->objet( 'dossier' )['donnees']['statut'] ?? '' );
		},
	) );

	FKC_ScanNavigation::porte( 'dossier', array(
		'libelle' => 'Tous les dossiers', 'icone' => '📚', 'priorite' => 8,
		'route' => function ( $r ) {
			$p = FKC_VpScan::packActif();
			return '' === $p ? '' : $p . '/dossiers';
		},
		'description' => 'Portefeuille du pack, par statut',
	) );
}

/* ═══════════════════ ANALYSEUR ═══════════════════ */

if ( class_exists( 'FKC_ScanAssistant' ) ) {
	/*
	 * DEUX CAS, ET SEULEMENT DEUX.
	 *
	 * La tentation serait d'analyser ici le métier de chaque pack — retards de
	 * chantier, sorties d'hospitalisation, échéances de contrat. Ce serait une
	 * erreur : le moteur vertical ne connaît que `vp_dossiers`, dont les
	 * colonnes sont volontairement génériques. Un analyseur qui prétendrait
	 * lire du sens métier dans `champs` (du JSON libre, différent par pack)
	 * produirait des conseils faux avec l'assurance de ceux qui viennent du
	 * cœur.
	 *
	 * On s'en tient donc à ce que la table dit vraiment, et qui vaut pour les
	 * quarante-trois packs sans exception :
	 *
	 *   1. le dossier est CLOS — le geste qu'on s'apprêtait à faire n'a plus
	 *      lieu d'être, et c'est la cause la plus banale de pièce émise sur un
	 *      dossier archivé ;
	 *   2. le dossier est OUVERT et n'a produit AUCUNE pièce alors que sa date
	 *      de fin est passée — du travail livré, jamais facturé. Dans les
	 *      métiers de dossier, c'est la première source de perte de chiffre,
	 *      et personne ne la voit : un dossier non facturé ne réclame rien.
	 *
	 * Le sectoriel, lui, se déclare pack par pack — comme le cabinet juridique
	 * le fait pour ses délais irrattrapables. C'est le bon endroit pour ça.
	 */
	FKC_ScanAssistant::analyseur( function ( $r, $ctx ) {
		if ( 'dossier' !== $r->type() || ! $r->ok() ) { return null; }
		$d      = (array) ( $r->objet( 'dossier' )['donnees'] ?? array() );
		$pack   = FKC_VpScan::packActif();
		$statut = (string) ( $d['statut'] ?? '' );
		$pieces = (int) ( $d['pieces'] ?? 0 );

		if ( FKC_VpScan::estClos( $statut ) ) {
			return array(
				'niveau'  => 'attention',
				'constat' => $r->libelle() . ' est ' . $statut . ' : le dossier n\'accepte plus de pièce.',
				'propositions' => array(
					array(
						'cle' => 'consulter', 'libelle' => 'Consulter sans modifier',
						'pourquoi' => 'Un dossier clos reste consultable — c\'est même souvent pour cela qu\'on le rescanne.',
						'route' => $pack ? $pack . '/dossiers/' . (int) $r->id() : '',
						'recommande' => true,
					),
					array(
						'cle' => 'nouveau_dossier', 'libelle' => 'Ouvrir un nouveau dossier',
						'pourquoi' => 'Rattacher une prestation nouvelle à un dossier archivé faussera son résultat et le rapprochement de la période déjà close.',
						'route' => $pack ? $pack . '/dossiers/nouveau' : '',
					),
				),
			);
		}

		$fin = (string) ( $d['date_fin'] ?? '' );
		if ( 0 === $pieces && '' !== $fin && strtotime( $fin ) && strtotime( $fin ) < strtotime( date( 'Y-m-d' ) ) ) {
			$jours = (int) floor( ( strtotime( date( 'Y-m-d' ) ) - strtotime( $fin ) ) / 86400 );
			return array(
				'niveau'  => 'critique',
				'constat' => $r->libelle() . ' est terminé depuis ' . $jours . ' jour(s) et n\'a produit AUCUNE pièce facturable.',
				'propositions' => array(
					array(
						'cle' => 'facturer', 'libelle' => 'Émettre la pièce maintenant',
						'pourquoi' => 'Du travail livré et non facturé ne réclame rien : il disparaît simplement du chiffre d\'affaires. Plus le délai s\'allonge, plus le client conteste.',
						'route' => $pack ? $pack . '/dossiers/' . (int) $r->id() . '/pieces/nouvelle' : '',
						'recommande' => true,
					),
					array(
						'cle' => 'clore', 'libelle' => 'Clore le dossier sans facturer',
						'pourquoi' => 'Prestation offerte, dossier abandonné ou doublon : le clore explicitement le retire des relances au lieu de le laisser traîner.',
						'route' => $pack ? $pack . '/dossiers/' . (int) $r->id() . '/modifier' : '',
					),
					array(
						'cle' => 'corriger_date', 'libelle' => 'Corriger la date de fin',
						'pourquoi' => 'Si le dossier est en réalité toujours en cours, c\'est la date qui est fausse — et elle faussera aussi le pilotage.',
						'route' => $pack ? $pack . '/dossiers/' . (int) $r->id() . '/modifier' : '',
					),
				),
			);
		}
		return null;
	}, 'vertical_dossier' );
}
