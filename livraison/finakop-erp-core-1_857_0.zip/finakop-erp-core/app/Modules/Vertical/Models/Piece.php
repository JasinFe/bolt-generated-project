<?php
/**
 * Moteur vertical générique — PIÈCE (document facturable d'un dossier).
 *
 * Une pièce (facture de réparation, frais de scolarité, quittance de loyer,
 * recette journalière, subvention…) suit le processus générique
 * « {pack}_validation_piece » : brouillon → soumise → validée → comptabilisée
 * automatiquement par l'événement déclaré dans le manifest pour son type.
 * Le handler d'effet « vp.piece » synchronise le statut local et rattache
 * l'écriture générée (même mécanique que le pack BTP).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpPiece {

	public static function statuts() {
		return array(
			'brouillon' => 'Brouillon', 'soumise' => 'Soumise', 'validee' => 'Validée',
			'comptabilisee' => 'Comptabilisée', 'rejetee' => 'Rejetée',
		);
	}

	public static function find( $id ) {
		FKC_VpDossier::ensure();
		$r = FKC_DB::q(
			'SELECT p.*, d.pack, d.code AS dossier_code, d.libelle AS dossier_libelle, d.tiers_nom, d.division_id
			 FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id WHERE p.id=?',
			array( (int) $id )
		)->fetch();
		return $r ?: null;
	}

	public static function duDossier( $dossierId ) {
		FKC_VpDossier::ensure();
		return FKC_DB::q( 'SELECT * FROM vp_pieces WHERE dossier_id=? ORDER BY id DESC', array( (int) $dossierId ) )->fetchAll();
	}

	/** Pièces récentes du pack courant (en attente en tête). */
	public static function recentes( $limit = 100 ) {
		FKC_VpDossier::ensure();
		return FKC_DB::q(
			"SELECT p.*, d.code AS dossier_code, d.libelle AS dossier_libelle
			 FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE d.pack=?
			 ORDER BY p.statut IN ('soumise','brouillon') DESC, p.date_piece DESC, p.id DESC LIMIT " . (int) $limit,
			array( FKC_VpDossier::pack() )
		)->fetchAll();
	}

	/** Montants dérivés : HT, TVA, TTC. */
	public static function montants( array $p ) {
		$ht  = round( (float) $p['montant_ht'], 2 );
		$tva = round( $ht * (float) $p['tva_pct'] / 100, 2 );
		return array( 'ht' => $ht, 'tva' => $tva, 'ttc' => round( $ht + $tva, 2 ) );
	}

	/**
	 * Crée une pièce en brouillon et démarre le processus de validation du pack.
	 * @param array $cfg bloc « vertical » du manifest.
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null id )
	 */
	public static function create( $dossierId, array $d, array $cfg ) {
		FKC_VpDossier::ensure();
		$dos = FKC_VpDossier::find( $dossierId );
		if ( ! $dos ) { return array( false, 'Dossier introuvable.', null ); }
		if ( 'clos' === $dos['statut'] ) { return array( false, 'Dossier clos : aucune pièce ne peut être créée.', null ); }
		$types = (array) ( $cfg['pieces'] ?? array() );
		$type  = (string) ( $d['type'] ?? '' );
		if ( ! isset( $types[ $type ] ) ) { $type = (string) array_key_first( $types ); }
		if ( '' === $type ) { return array( false, 'Aucun type de pièce déclaré par le pack.', null ); }
		$ht = (float) ( $d['montant_ht'] ?? 0 );
		if ( $ht <= 0 ) { return array( false, 'Le montant HT doit être positif.', null ); }

		/*
		 * UNE REPRISE DE PROVISION EXIGE SON MOTIF (1.722.0).
		 *
		 * `FKC_Provision::reprendre()` refuse une reprise sans motif — le seul
		 * refus dur de tout le moteur du fait économique, et il est justifié :
		 * une reprise améliore le résultat sans le moindre mouvement de
		 * trésorerie, et c'est le premier point qu'un contrôle regarde.
		 *
		 * Or le libellé d'une pièce est FACULTATIF : laissé vide, il se
		 * remplit tout seul avec « Reprise de provision (PSAP) n°3 ». La
		 * pièce se serait donc comptabilisée pendant que le registre, lui,
		 * aurait refusé l'écriture — écriture passée, provision restée
		 * ouverte, et personne pour le voir. On refuse ICI, à la saisie, là
		 * où l'utilisateur peut encore répondre.
		 *
		 * Le contrôle porte sur le FAIT déclaré par le schéma, jamais sur le
		 * nom du type de pièce : un autre pack qui déclarera demain sa propre
		 * reprise sera tenu par la même règle sans écrire une ligne.
		 */
		$evtType = (string) ( $types[ $type ]['evenement'] ?? '' );
		if ( $evtType && class_exists( 'FKC_Posting' ) ) {
			$sch = FKC_Posting::schema( $evtType );
			$fait = strtoupper( (string) ( $sch['fait'] ?? '' ) );
			if ( 'REPRISE_PROVISION' === $fait && '' === trim( (string) ( $d['libelle'] ?? '' ) ) ) {
				return array( false, 'Une reprise de provision doit porter son motif : indiquez-le dans le libellé de la pièce.', null );
			}
		}

		$numero = 1 + (int) FKC_DB::q( 'SELECT COALESCE(MAX(numero),0) FROM vp_pieces WHERE dossier_id=? AND type=?', array( (int) $dossierId, $type ) )->fetchColumn();
		/*
		 * TVA par défaut de la pièce (COM-001) — résolue par nature de pièce,
		 * paramétrable écran Fiscalité, plutôt que le 'tva' figé du manifest.
		 * La saisie manuelle ($d['tva_pct']) garde priorité absolue : c'est
		 * la valeur que l'utilisateur voit et confirme à l'écran.
		 */
		$repliType = (float) ( $types[ $type ]['tva'] ?? 0 );
		$tvaDefaut = ( class_exists( 'FKC_CategorieFiscale' ) )
			? FKC_CategorieFiscale::tauxNatureDossier( FKC_VpDossier::pack(), $type, $repliType )
			: $repliType;
		FKC_DB::q(
			'INSERT INTO vp_pieces(dossier_id,type,numero,date_piece,libelle,montant_ht,tva_pct,statut,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
			array(
				(int) $dossierId, $type, $numero,
				(string) ( $d['date_piece'] ?? '' ) ?: date( 'Y-m-d' ),
				trim( (string) ( $d['libelle'] ?? '' ) ) ?: ( ( $types[ $type ]['label'] ?? ucfirst( $type ) ) . ' n°' . $numero ),
				$ht,
				isset( $d['tva_pct'] ) && '' !== $d['tva_pct'] ? max( 0, min( 25, (float) $d['tva_pct'] ) ) : $tvaDefaut,
				'brouillon',
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
			)
		);
		$id = (int) FKC_DB::conn()->lastInsertId();

		$p   = self::find( $id );
		$wf  = FKC_VpDossier::pack() . '_validation_piece';
		$wid = FKC_WorkflowEngine::start( $wf, 'vp.piece', $id, self::contexte( $p, $cfg ) );
		if ( $wid ) { FKC_DB::q( 'UPDATE vp_pieces SET wf_instance_id=? WHERE id=?', array( $wid, $id ) ); }
		return array( true, ( $types[ $type ]['label'] ?? 'Pièce' ) . " n°{$numero} créée (brouillon). Soumettez-la pour validation.", $id );
	}

	/** @var array hooks d'enrichissement du contexte : callable( array &$ctx, array $piece, array $dossier ) */
	protected static $ctxHooks = array();

	/** Un pack peut enrichir le contexte comptable de ses pièces (ex. courtage : commission/net). */
	public static function onContexte( $callable ) {
		if ( is_callable( $callable ) ) { self::$ctxHooks[] = $callable; }
	}

	/** Contexte transmis au workflow puis au moteur d'événements comptables. */
	public static function contexte( array $p, array $cfg ) {
		$m = self::montants( $p );
		FKC_VpDossier::ensureDivision( (int) $p['dossier_id'] );
		$dos   = FKC_VpDossier::find( (int) $p['dossier_id'] );
		$types = (array) ( $cfg['pieces'] ?? array() );
		$tdef  = $types[ $p['type'] ] ?? array();
		$ctx = array_merge( $m, array(
			'numero'      => (int) $p['numero'],
			'piece_id'    => (int) $p['id'],
			'piece_type'  => (string) $p['type'],
			'piece_label' => (string) ( $tdef['label'] ?? ucfirst( $p['type'] ) ),
			'evenement'   => (string) ( $tdef['evenement'] ?? '' ), // interpolé par l'effet posting du workflow
			'dossier'     => $dos ? ( $dos['code'] . ' ' . $dos['libelle'] ) : '',
			'tiers'       => $dos['tiers_nom'] ?? '',
			'date'        => $p['date_piece'],
			'piece'       => ( $dos['code'] ?? 'DOS' ) . '-' . strtoupper( substr( $p['type'], 0, 3 ) ) . '-' . str_pad( (string) $p['numero'], 3, '0', STR_PAD_LEFT ),
			'reference'   => 'vp.piece#' . (int) $p['id'],
			'division_id' => $dos['division_id'] ?? null,
			'montant'     => $m['ttc'],
			/*
			 * LE MOTIF, ET LA PROVISION QU'ON REPREND (1.722.0).
			 *
			 * Le schéma de reprise interpole « {motif} » sur sa ligne de
			 * produit : sans cette clé, la contrepartie d'une reprise
			 * s'inscrivait au journal sans un mot de justification.
			 *
			 * `provision_id` est ce qui permet au registre de RAPPROCHER la
			 * reprise de sa dotation, donc de solder la provision et de
			 * mesurer l'écart d'estimation. On le résout depuis le dossier —
			 * mais SEULEMENT s'il n'y a aucune ambiguïté : une provision
			 * ouverte et une seule sur ce dossier. Deux provisions, ou zéro,
			 * et l'on ne rattache rien plutôt que de choisir à la place du
			 * comptable. L'écriture passe, le registre reste ouvert, et
			 * l'écran des faits économiques le montre — une vue incomplète
			 * vaut mieux qu'une vue fausse (même arbitrage qu'en 1.624.0 sur
			 * deux séjours en cours dans une même chambre).
			 */
			'motif'       => (string) ( $p['libelle'] ?? '' ),
		) );
		/*
		 * 1.857.0 — LE CLIENT DU DOSSIER PORTE LA CRÉANCE. Une pièce facturée
		 * (facture de gros, commission…) débitait le 411 général : le compte
		 * du revendeur restait vierge, son encours à zéro, et le recouvrement
		 * ne savait pas qui relancer. Les lignes marquées « tiers » du schéma
		 * reçoivent désormais le client rattaché au dossier.
		 */
		if ( ! empty( $dos['client_id'] ) && empty( $ctx['tiers_id'] ) ) {
			$ctx['tiers_type'] = 'client';
			$ctx['tiers_id']   = (int) $dos['client_id'];
		}
		if ( class_exists( 'FKC_Provision' ) && ! empty( $ctx['dossier'] ) ) {
			$candidates = array();
			foreach ( FKC_Provision::ouvertes() as $pv ) {
				if ( (string) $pv['objet'] === (string) $ctx['dossier'] && (float) $pv['solde'] > 0 ) {
					$candidates[] = (int) $pv['id'];
				}
			}
			if ( 1 === count( $candidates ) ) { $ctx['provision_id'] = $candidates[0]; }
		}
		// Champs personnalisés du dossier disponibles au posting (ex. compagnie, taux_commission).
		foreach ( (array) ( $dos['champs_arr'] ?? array() ) as $k => $v ) {
			if ( ! isset( $ctx[ $k ] ) ) { $ctx[ $k ] = $v; }
		}
		// Hooks des packs (enrichissement métier du contexte).
		foreach ( self::$ctxHooks as $h ) { $h( $ctx, $p, (array) $dos ); }
		return $ctx;
	}
}

/* ── Handler d'effet du workflow : synchronisation du statut de la pièce ───── */
if ( class_exists( 'FKC_WorkflowEngine' ) ) {
	FKC_WorkflowEngine::onEffet( 'vp.piece', function ( $effet, $instance, &$ctx ) {
		$pid = (int) ( $ctx['piece_id'] ?? $instance['ref_id'] ?? 0 );
		if ( ! $pid ) { return; }
		$statut  = (string) ( $effet['statut'] ?? '' );
		$statuts = FKC_VpPiece::statuts();
		if ( ! isset( $statuts[ $statut ] ) ) { return; }
		FKC_DB::q( 'UPDATE vp_pieces SET statut=? WHERE id=?', array( $statut, $pid ) );
		if ( 'comptabilisee' === $statut ) {
			FKC_DB::q( 'UPDATE vp_pieces SET ecriture_id=?, brouillon_id=? WHERE id=?', array(
				! empty( $ctx['ecriture_id'] ) ? (int) $ctx['ecriture_id'] : null,
				! empty( $ctx['brouillon_id'] ) ? (int) $ctx['brouillon_id'] : null,
				$pid,
			) );
		}
	} );
}
