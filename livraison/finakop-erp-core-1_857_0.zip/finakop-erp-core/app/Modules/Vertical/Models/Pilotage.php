<?php
/**
 * Pilotage vertical générique.
 *
 * Calcule des indicateurs de gestion pour N'IMPORTE QUEL pack déclaratif (ceux
 * qui reposent sur le moteur vertical : dossiers = objet central, pièces =
 * recettes/prestations facturables). Un pack expert n'a plus qu'à brancher ces
 * chiffres sur les socles (KPI, alertes, assistant, rapports, prévisions,
 * scénarios) via son hooks.php, en leur donnant le vocabulaire de son métier.
 *
 * Indicateurs : chiffre d'affaires (jour/mois/année), CA par type de pièce, CA
 * par dossier (section analytique), évolution mensuelle, dossiers actifs, pièces
 * en attente de validation, recette moyenne par pièce.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpPilotage {

	protected static function pack() {
		return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : '';
	}

	protected static function scalar( $sql, $params = array() ) {
		try { return FKC_DB::q( $sql, $params )->fetchColumn(); }
		catch ( \Throwable $e ) { return 0; }
	}
	protected static function rows( $sql, $params = array() ) {
		try { return FKC_DB::q( $sql, $params )->fetchAll(); }
		catch ( \Throwable $e ) { return array(); }
	}

	/** Chiffre d'affaires HT des pièces comptabilisées sur une période. */
	public static function caPeriode( $depuis, $jusqua = null ) {
		$jusqua = $jusqua ?: date( 'Y-m-d' );
		return (float) self::scalar(
			"SELECT COALESCE(SUM(p.montant_ht),0) FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE d.pack=? AND p.statut='comptabilisee' AND substr(p.date_piece,1,10) BETWEEN ? AND ?",
			array( self::pack(), $depuis, $jusqua )
		);
	}

	public static function caJour( $date = null ) {
		$d = $date ?: date( 'Y-m-d' );
		return self::caPeriode( $d, $d );
	}
	public static function caMois( $ym = null ) {
		$ym = $ym ?: date( 'Y-m' );
		return self::caPeriode( $ym . '-01', $ym . '-31' );
	}
	/**
	 * Chiffre d'affaires de l'EXERCICE, et non de l'année civile (1.630.0).
	 *
	 * Le millésime par défaut venait de `date('Y')` et les bornes étaient en
	 * dur. Sur un commerce à exercice décalé, le cockpit annonçait un CA
	 * calculé sur une période que la comptabilité ne connaît pas : le chiffre
	 * ne recoupait ni le compte de résultat, ni la liasse. Un dirigeant qui
	 * compare son cockpit à ses états financiers et trouve deux montants
	 * différents cesse de croire l'un des deux — et rien ne lui dit lequel.
	 */
	public static function caAnnee( $y = null ) {
		$ex = class_exists( 'FKC_Exercice' );
		$y  = $y ?: ( $ex ? FKC_Exercice::courant() : date( 'Y' ) );
		list( $deb, $fin ) = $ex ? FKC_Exercice::bornes( (int) $y )
			: array( $y . '-01-01', $y . '-12-31' );
		return self::caPeriode( $deb, $fin );
	}

	/** Synthèse générale. */
	public static function synthese() {
		$pk = self::pack();
		$dossiersActifs = (int) self::scalar( "SELECT COUNT(*) FROM vp_dossiers WHERE pack=? AND statut='ouvert'", array( $pk ) );
		$piecesAttente = (int) self::scalar(
			"SELECT COUNT(*) FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id WHERE d.pack=? AND p.statut IN ('brouillon','soumise')",
			array( $pk )
		);
		$nbPiecesMois = (int) self::scalar(
			"SELECT COUNT(*) FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE d.pack=? AND p.statut='comptabilisee' AND substr(p.date_piece,1,7)=?",
			array( $pk, date( 'Y-m' ) )
		);
		$caMois = self::caMois();
		$recetteMoyenne = $nbPiecesMois > 0 ? round( $caMois / $nbPiecesMois ) : 0;
		return array(
			'dossiers_actifs' => $dossiersActifs,
			'pieces_attente' => $piecesAttente,
			'ca_jour' => self::caJour(),
			'ca_mois' => $caMois,
			'ca_annee' => self::caAnnee(),
			'nb_pieces_mois' => $nbPiecesMois,
			'recette_moyenne' => $recetteMoyenne,
		);
	}

	/** CA par type de pièce sur le mois (repas, boissons, etc.). */
	public static function caParType( $ym = null ) {
		$ym = $ym ?: date( 'Y-m' );
		$rows = self::rows(
			"SELECT p.type, COALESCE(SUM(p.montant_ht),0) ht FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE d.pack=? AND p.statut='comptabilisee' AND substr(p.date_piece,1,7)=? GROUP BY p.type ORDER BY ht DESC",
			array( self::pack(), $ym )
		);
		$out = array();
		foreach ( $rows as $r ) { $out[ $r['type'] ] = (float) $r['ht']; }
		return $out;
	}

	/** CA par dossier (point de vente / section) sur le mois. */
	public static function caParDossier( $ym = null, $limit = 10 ) {
		$ym = $ym ?: date( 'Y-m' );
		return self::rows(
			"SELECT d.libelle, d.code, COALESCE(SUM(p.montant_ht),0) ht
			 FROM vp_dossiers d LEFT JOIN vp_pieces p ON p.dossier_id=d.id AND p.statut='comptabilisee' AND substr(p.date_piece,1,7)=?
			 WHERE d.pack=? GROUP BY d.id ORDER BY ht DESC LIMIT " . (int) $limit,
			array( $ym, self::pack() )
		);
	}

	/** Évolution mensuelle du CA sur N mois. */
	public static function evolutionMensuelle( $mois = 6 ) {
		$out = array();
		for ( $i = $mois - 1; $i >= 0; $i-- ) {
			// « first day of » : le 31 mars, « -1 month » donnait le 3 mars —
			// un mois apparaissait deux fois et février disparaissait (1.851.0).
			$ym = date( 'Y-m', strtotime( "first day of -{$i} month" ) );
			$out[ $ym ] = self::caMois( $ym );
		}
		return $out;
	}

	/** Série journalière du CA sur N jours (pour prévisions). */
	public static function serieJournaliere( $jours = 14 ) {
		$out = array();
		for ( $i = $jours - 1; $i >= 0; $i-- ) {
			$out[] = self::caJour( date( 'Y-m-d', strtotime( "-{$i} day" ) ) );
		}
		return $out;
	}

	/** Dossiers sans aucune recette ce mois (points de vente inactifs). */
	public static function dossiersInactifs( $ym = null ) {
		$ym = $ym ?: date( 'Y-m' );
		return self::rows(
			"SELECT d.libelle, d.code FROM vp_dossiers d
			 WHERE d.pack=? AND d.statut='ouvert'
			   AND NOT EXISTS (SELECT 1 FROM vp_pieces p WHERE p.dossier_id=d.id AND p.statut='comptabilisee' AND substr(p.date_piece,1,7)=?)",
			array( self::pack(), $ym )
		);
	}

	public static function compteurs() {
		$s = self::synthese();
		return array(
			'attente' => $s['pieces_attente'],
			'inactifs' => count( self::dossiersInactifs() ),
		);
	}
}
