<?php
/**
 * MARQUES ET MODÈLES (ELM-004).
 *
 * CE QUI MANQUAIT, ET POURQUOI CELA COMPTAIT
 *
 * Le cahier des charges de l'Électroménager plaçait « marques et modèles »
 * au premier niveau, parmi les capacités du métier. Rien n'existait : une
 * marque ne pouvait s'exprimer que comme caractéristique texte libre. Trois
 * conséquences concrètes.
 *
 *   1. « Samsung », « SAMSUNG » et « samsung » cohabitaient dans le
 *      catalogue, sans que rien ne les rapproche.
 *   2. Impossible de filtrer le catalogue par marque — le premier geste d'un
 *      vendeur à qui un client demande « qu'avez-vous en LG ? ».
 *   3. La section analytique MARQUE était déclarée dans le plan comptable de
 *      l'Électroménager depuis sa livraison, et rien ne l'alimentait.
 *
 * MARQUE ET MODÈLE NE SONT PAS DE MÊME NATURE, ET NE SE TRAITENT PAS PAREIL
 *
 * La MARQUE est un référentiel : un petit nombre de valeurs, partagées par
 * beaucoup d'articles, sur lesquelles on filtre, on regroupe et on analyse.
 * Elle mérite sa table.
 *
 * Le MODÈLE est une référence commerciale du fabricant — « RT38K5982SL ».
 * Elle appartient à UN article et à lui seul ; deux articles qui partageraient
 * le même modèle seraient le même produit. Une table de modèles n'aurait
 * jamais qu'une ligne par article : c'est donc une COLONNE.
 *
 * Et surtout : le « Modèle » du schéma Produit / Modèle / Variante n'est PAS
 * cette référence. Un modèle qui se décline en tailles ou en couleurs est
 * déjà porté par COM-021 (un article parent et ses variantes, chacune avec
 * son stock et son prix). Ouvrir ici une seconde hiérarchie aurait dupliqué
 * le stock à deux endroits — la faute classique.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpMarque {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_marques(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				code TEXT NOT NULL,
				libelle TEXT NOT NULL,
				pays TEXT,
				ordre INTEGER NOT NULL DEFAULT 100,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, code)
			);
			CREATE INDEX IF NOT EXISTS idx_vpmar_pack ON vp_marques(pack, actif, ordre);
		" );
		/*
		 * Comme pour la catégorie (BAZ-001), l'article porte l'identifiant ET
		 * une copie du libellé. Le libellé dénormalisé sert aux états, aux
		 * regroupements et à la section analytique MARQUE : une jointure de
		 * moins sur chaque ligne de mouvement, et un historique qui reste
		 * lisible même si la marque est un jour supprimée.
		 */
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN marque_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN marque TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN modele TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/**
	 * Le pack propose-t-il les marques ?
	 *
	 * Aucune semence n'est livrée, et c'est délibéré : une liste de marques
	 * est un choix commercial qui appartient au commerçant. Livrer
	 * « Samsung, LG, Hisense » reviendrait à décider pour lui ce qu'il
	 * distribue, et à laisser dans son catalogue des marques qu'il ne vend
	 * pas.
	 */
	public static function offert( ?array $cfg = null ) {
		if ( is_array( $cfg ) && isset( $cfg['stock']['marques'] ) ) { return ! empty( $cfg['stock']['marques'] ); }
		$p = class_exists( 'FKC_Packs' ) ? FKC_Packs::get( self::pack() ) : null;
		return ! empty( $p['stock']['marques'] );
	}

	/* ── Lecture ─────────────────────────────────────────────────────────── */

	public static function toutes( $inclureInactives = false ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( ! $inclureInactives ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_marques {$w} ORDER BY ordre, libelle", $p )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_marques WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	public static function parLibelle( $libelle ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_marques WHERE pack=? AND libelle=? LIMIT 1',
			array( self::pack(), trim( (string) $libelle ) ) )->fetch();
		return $r ?: null;
	}

	public static function options( $inclureInactives = false ) {
		$out = array();
		foreach ( self::toutes( $inclureInactives ) as $m ) {
			$out[ (int) $m['id'] ] = ( $m['actif'] ? '' : '(inactive) ' ) . $m['libelle'];
		}
		return $out;
	}

	/** Nombre d'articles portant cette marque. */
	public static function compteArticles( $id ) {
		self::ensure();
		try {
			return (int) FKC_DB::q( 'SELECT COUNT(*) FROM vp_articles WHERE pack=? AND marque_id=?',
				array( self::pack(), (int) $id ) )->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/* ── Écriture ────────────────────────────────────────────────────────── */

	/** @return array{bool, string, int|null} */
	public static function creer( array $d ) {
		self::ensure();
		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom de la marque est obligatoire.', null ); }

		/*
		 * LA COMPARAISON EST INSENSIBLE À LA CASSE, ET C'EST TOUT L'INTÉRÊT.
		 *
		 * « Samsung » et « SAMSUNG » sont la même marque. Les laisser
		 * coexister ramènerait exactement le problème que ce référentiel
		 * existe pour résoudre : un rapport par marque qui compte deux fois
		 * le même fabricant.
		 */
		$exist = FKC_DB::q( 'SELECT libelle FROM vp_marques WHERE pack=? AND LOWER(libelle)=LOWER(?)',
			array( self::pack(), $libelle ) )->fetch();
		if ( $exist ) {
			return array( false, 'La marque « ' . $exist['libelle'] . ' » existe déjà — c\'est la même, écrite autrement.', null );
		}

		FKC_DB::q( 'INSERT INTO vp_marques(pack,code,libelle,pays,ordre,actif) VALUES(?,?,?,?,?,1)', array(
			self::pack(), self::codeLibre( $libelle ), $libelle,
			trim( (string) ( $d['pays'] ?? '' ) ) ?: null,
			isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : self::prochainOrdre(),
		) );
		return array( true, 'Marque « ' . $libelle . ' » créée.', (int) FKC_DB::conn()->lastInsertId() );
	}

	/** @return array{bool, string} */
	public static function modifier( $id, array $d ) {
		self::ensure();
		$m = self::find( $id );
		if ( ! $m ) { return array( false, 'Marque introuvable.' ); }
		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom de la marque est obligatoire.' ); }

		$exist = FKC_DB::q( 'SELECT libelle FROM vp_marques WHERE pack=? AND LOWER(libelle)=LOWER(?) AND id<>?',
			array( self::pack(), $libelle, (int) $m['id'] ) )->fetch();
		if ( $exist ) { return array( false, 'La marque « ' . $exist['libelle'] . ' » existe déjà.' ); }

		FKC_DB::q( 'UPDATE vp_marques SET libelle=?, pays=?, ordre=?, actif=? WHERE id=? AND pack=?', array(
			$libelle, trim( (string) ( $d['pays'] ?? '' ) ) ?: null,
			isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : (int) $m['ordre'],
			array_key_exists( 'actif', $d ) ? ( ! empty( $d['actif'] ) ? 1 : 0 ) : (int) $m['actif'],
			(int) $m['id'], self::pack(),
		) );
		// Le libellé dénormalisé suit, sans quoi une marque rebaptisée
		// apparaîtrait sous deux noms dans les états.
		if ( $libelle !== (string) $m['libelle'] ) {
			FKC_DB::q( 'UPDATE vp_articles SET marque=? WHERE pack=? AND marque_id=?', array( $libelle, self::pack(), (int) $m['id'] ) );
		}
		return array( true, 'Marque mise à jour.' );
	}

	public static function basculer( $id ) {
		self::ensure();
		$m = self::find( $id );
		if ( ! $m ) { return array( false, 'Marque introuvable.' ); }
		$nouvel = empty( $m['actif'] ) ? 1 : 0;
		FKC_DB::q( 'UPDATE vp_marques SET actif=? WHERE id=? AND pack=?', array( $nouvel, (int) $m['id'], self::pack() ) );
		return array( true, $nouvel
			? 'Marque « ' . $m['libelle'] . ' » réactivée.'
			: 'Marque « ' . $m['libelle'] . ' » désactivée — elle ne sera plus proposée, les articles qui la portent la gardent.' );
	}

	/** @return array{bool, string} */
	public static function supprimer( $id ) {
		self::ensure();
		$m = self::find( $id );
		if ( ! $m ) { return array( false, 'Marque introuvable.' ); }
		$n = self::compteArticles( (int) $m['id'] );
		if ( $n ) {
			return array( false, 'Suppression impossible : ' . $n . ' article(s) portent la marque « ' . $m['libelle']
				. ' ». Désactivez-la plutôt — elle disparaîtra des listes sans effacer l\'historique de vente.' );
		}
		FKC_DB::q( 'DELETE FROM vp_marques WHERE id=? AND pack=?', array( (int) $m['id'], self::pack() ) );
		return array( true, 'Marque « ' . $m['libelle'] . ' » supprimée.' );
	}

	/* ── Rattachement d'un article ───────────────────────────────────────── */

	/**
	 * Résout la marque d'un article : identifiant + libellé dénormalisé.
	 * Accepte aussi un libellé libre (import, API) et le rattache s'il
	 * correspond à une marque connue — sans en créer une à l'aveugle, sinon
	 * la moindre faute de frappe polluerait le référentiel.
	 *
	 * @return array{0:int|null,1:string|null} ( marque_id, libellé )
	 */
	public static function resoudre( array $d ) {
		if ( ! empty( $d['marque_id'] ) ) {
			$m = self::find( (int) $d['marque_id'] );
			if ( $m ) { return array( (int) $m['id'], (string) $m['libelle'] ); }
		}
		$texte = trim( (string) ( $d['marque'] ?? '' ) );
		if ( '' === $texte ) { return array( null, null ); }
		$m = self::parLibelle( $texte );
		return $m ? array( (int) $m['id'], (string) $m['libelle'] ) : array( null, $texte );
	}

	/**
	 * RATTRAPAGE — les articles créés avant cette brique, ou importés, ne
	 * portent qu'un libellé texte. On les raccroche quand la marque existe
	 * déjà, et on crée les manquantes : le commerçant retrouve son
	 * référentiel tel qu'il l'avait saisi, sans ressaisie.
	 *
	 * @return int Nombre d'articles raccrochés.
	 */
	public static function rattraperArticles() {
		self::ensure();
		$rows = FKC_DB::q(
			"SELECT DISTINCT marque FROM vp_articles WHERE pack=? AND marque_id IS NULL AND marque IS NOT NULL AND TRIM(marque)<>''",
			array( self::pack() )
		)->fetchAll();
		$n = 0;
		foreach ( $rows as $r ) {
			$lib = trim( (string) $r['marque'] );
			$m = self::parLibelle( $lib );
			if ( ! $m ) {
				list( $ok, , $id ) = self::creer( array( 'libelle' => $lib ) );
				if ( ! $ok ) { continue; }
			} else {
				$id = (int) $m['id'];
			}
			$n += (int) FKC_DB::q( 'UPDATE vp_articles SET marque_id=? WHERE pack=? AND marque_id IS NULL AND marque=?',
				array( (int) $id, self::pack(), $lib ) )->rowCount();
		}
		return $n;
	}

	/* ── Analyse ─────────────────────────────────────────────────────────── */

	/**
	 * Chiffre d'affaires par marque sur un mois — ce qui alimente enfin la
	 * section analytique MARQUE déclarée au plan de l'Électroménager.
	 *
	 * @return array libellé => montant
	 */
	public static function caParMarque( $ym = null, $limit = 12 ) {
		self::ensure();
		$m = $ym ?: date( 'Y-m' );
		try {
			$rows = FKC_DB::q(
				"SELECT COALESCE(NULLIF(a.marque,''),'Sans marque') mq, COALESCE(SUM(mo.montant),0) ca
				 FROM vp_mouvements mo JOIN vp_articles a ON a.id=mo.article_id
				 WHERE mo.pack=? AND mo.sens='sortie' AND substr(mo.created_at,1,7)=?
				 GROUP BY mq ORDER BY ca DESC LIMIT " . (int) $limit,
				array( self::pack(), $m )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		$out = array();
		foreach ( $rows as $r ) { $out[ $r['mq'] ] = (float) $r['ca']; }
		return $out;
	}

	/* ── Utilitaires ─────────────────────────────────────────────────────── */

	protected static function prochainOrdre() {
		return 10 + (int) FKC_DB::q( 'SELECT COALESCE(MAX(ordre),0) FROM vp_marques WHERE pack=?', array( self::pack() ) )->fetchColumn();
	}

	public static function codeLibre( $libelle ) {
		$base = fkc_lc( (string) $libelle );
		$base = strtr( $base, array(
			'à' => 'a', 'â' => 'a', 'ä' => 'a', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
			'î' => 'i', 'ï' => 'i', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c',
			'À' => 'a', 'É' => 'e', 'È' => 'e', 'Ê' => 'e', 'Ô' => 'o', 'Ç' => 'c',
		) );
		$base = trim( (string) preg_replace( '/[^a-z0-9]+/', '_', $base ), '_' );
		if ( '' === $base ) { $base = 'marque'; }
		$base = substr( $base, 0, 40 );
		$code = $base; $i = 2;
		while ( FKC_DB::q( 'SELECT 1 FROM vp_marques WHERE pack=? AND code=?', array( self::pack(), $code ) )->fetch() ) {
			$code = $base . '_' . $i; $i++;
			if ( $i > 999 ) { $code = $base . '_' . bin2hex( random_bytes( 2 ) ); break; }
		}
		return $code;
	}
}
