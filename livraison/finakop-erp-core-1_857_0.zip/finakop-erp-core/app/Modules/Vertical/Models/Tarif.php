<?php
/**
 * PRIX ET MODES DE VENTE (BAZ-003) — la couche commerciale.
 *
 * DEUX SUJETS, UNE SEULE BRIQUE, ET C'EST VOULU
 *
 * « À quel prix » et « de quelle façon » sont la même décision commerciale.
 * Un tissu vendu au mètre n'a pas le même prix qu'un rouleau entier ; un
 * article « sur mesure » n'a pas de prix au catalogue du tout. Séparer les
 * deux obligerait chaque écran de vente à interroger deux briques pour
 * répondre à une seule question : combien, pour cette quantité, à ce client.
 *
 * ── LA GRILLE ────────────────────────────────────────────────────────────
 *
 * Cinq niveaux : détail, revendeur, demi-gros, gros, promotion. Chacun peut
 * porter une quantité minimale (le demi-gros à partir de 10, le gros à partir
 * de 100) et une période (la promotion du 1er au 31 décembre). Un tarif peut
 * en outre viser UN client précis : c'est le « prix spécial client », celui
 * qu'on accorde au fidèle sans l'afficher à tout le monde.
 *
 * ORDRE DE RÉSOLUTION, du plus précis au plus général :
 *
 *   1. prix spécial pour CE client
 *   2. promotion en cours
 *   3. palier de quantité atteint (gros, puis demi-gros)
 *   4. prix revendeur
 *   5. prix détail
 *   6. à défaut, le prix de vente de la fiche article
 *
 * ── LE PRIX RÉSOLU EST UNE PROPOSITION, JAMAIS UN VERROU ─────────────────
 *
 * Dans un bazar, tout se négocie ; un logiciel qui imposerait son prix serait
 * abandonné le premier jour. Cette brique ne bloque donc aucune vente. Mais
 * elle TRACE : chaque sortie enregistre le niveau de tarif qui s'appliquait
 * et l'écart consenti. Sans cette trace, personne ne peut dire, à la fin du
 * mois, qui a bradé quoi — et la marge devient un chiffre qu'on subit.
 *
 * Une seule alerte, non bloquante : vendre sous le coût de revient (CUMP).
 * Ce n'est pas interdit — on déstocke parfois à perte, délibérément — mais
 * cela ne doit jamais arriver sans que personne ne l'ait vu.
 *
 * ── LES MODES DE VENTE ───────────────────────────────────────────────────
 *
 * Dix modes, cumulables : à l'unité, à la quantité, au poids, au mètre, au
 * m², au volume, par lot, par carton, sur commande, sur mesure. Ce ne sont
 * pas des étiquettes : deux d'entre eux changent les règles.
 *
 *   « sur commande » — l'article se vend même sans stock : la vente au
 *                      comptoir n'est plus refusée sèchement, elle renvoie
 *                      vers le cycle de commande, qui sait tenir un
 *                      engagement sans marchandise.
 *   « sur mesure »   — le prix se calcule à la vente, jamais lu au
 *                      catalogue : la résolution rend la main au vendeur au
 *                      lieu de proposer un chiffre qui serait faux.
 *
 * Et une règle de bon sens que le moteur ne pouvait pas appliquer jusqu'ici :
 * un article vendu SEULEMENT à l'unité ne se vend pas par 2,5. Le refus
 * n'est pas cosmétique — une quantité décimale sur un article indivisible
 * est presque toujours une faute de frappe qui fausse le stock.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpTarif {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_tarifs(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				niveau TEXT NOT NULL DEFAULT 'detail',
				client_id INTEGER,
				prix REAL NOT NULL DEFAULT 0,
				qte_mini REAL NOT NULL DEFAULT 0,
				date_debut TEXT,
				date_fin TEXT,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_vptar_article ON vp_tarifs(article_id, actif);
			CREATE INDEX IF NOT EXISTS idx_vptar_client ON vp_tarifs(client_id);
		" );
		// Modes de vente de l'article (jeu JSON, même principe que les capacités).
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN modes_vente TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// Traçabilité commerciale de chaque sortie : quel tarif s'appliquait,
		// et de combien on s'en est écarté.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN tarif_niveau TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN remise_pct REAL' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/* ── Niveaux de tarif ────────────────────────────────────────────────── */

	/**
	 * Les cinq niveaux, avec leur priorité de résolution : le plus grand
	 * l'emporte quand plusieurs s'appliquent en même temps.
	 */
	public static function niveaux() {
		return array(
			'detail'    => array( 'label' => 'Prix détail',       'icone' => '🏷️', 'priorite' => 10 ),
			'revendeur' => array( 'label' => 'Prix revendeur',    'icone' => '🤝', 'priorite' => 20 ),
			'demi_gros' => array( 'label' => 'Prix demi-gros',    'icone' => '📦', 'priorite' => 30 ),
			'gros'      => array( 'label' => 'Prix gros',         'icone' => '🚛', 'priorite' => 40 ),
			'promo'     => array( 'label' => 'Prix promotionnel', 'icone' => '🎉', 'priorite' => 50 ),
		);
	}

	public static function niveauValide( $n ) { return array_key_exists( (string) $n, self::niveaux() ); }

	public static function labelNiveau( $n ) {
		$n = (string) $n;
		if ( 'client' === $n )  { return 'Prix spécial client'; }
		if ( 'article' === $n ) { return 'Prix de la fiche'; }
		if ( 'mesure' === $n )  { return 'Sur mesure'; }
		$d = self::niveaux();
		return isset( $d[ $n ] ) ? $d[ $n ]['label'] : $n;
	}

	/* ── Modes de vente ──────────────────────────────────────────────────── */

	/**
	 * `decimal` : ce mode autorise-t-il une quantité fractionnaire ? Un article
	 * vendu uniquement à l'unité ou par carton se compte en entiers.
	 */
	public static function modes() {
		return array(
			'unite'    => array( 'label' => 'À l\'unité',    'icone' => '1️⃣', 'decimal' => false ),
			'quantite' => array( 'label' => 'À la quantité', 'icone' => '🔢', 'decimal' => false ),
			'poids'    => array( 'label' => 'Au poids',      'icone' => '⚖️', 'decimal' => true ),
			'metre'    => array( 'label' => 'Au mètre',      'icone' => '📏', 'decimal' => true ),
			'm2'       => array( 'label' => 'Au m²',         'icone' => '⬛', 'decimal' => true ),
			'volume'   => array( 'label' => 'Au volume',     'icone' => '🧊', 'decimal' => true ),
			'lot'      => array( 'label' => 'Par lot',       'icone' => '🧱', 'decimal' => false ),
			'carton'   => array( 'label' => 'Par carton',    'icone' => '📦', 'decimal' => false ),
			'commande' => array( 'label' => 'Sur commande',  'icone' => '📝', 'decimal' => true ),
			'mesure'   => array( 'label' => 'Sur mesure',    'icone' => '✂️', 'decimal' => true ),
		);
	}

	public static function modeExiste( $m ) { return array_key_exists( (string) $m, self::modes() ); }

	public static function labelMode( $m ) {
		$d = self::modes();
		return isset( $d[ (string) $m ] ) ? $d[ (string) $m ]['label'] : (string) $m;
	}

	/**
	 * Modes offerts par le pack. Un manifest muet ne propose que « à l'unité »
	 * et « à la quantité » : c'est ce que le moteur faisait déjà, et aucun
	 * pack existant ne doit se découvrir des modes qu'il n'a pas demandés.
	 */
	public static function modesOfferts( ?array $cfg = null ) {
		$decl = null;
		if ( is_array( $cfg ) && isset( $cfg['stock']['modes_vente'] ) ) {
			$decl = (array) $cfg['stock']['modes_vente'];
		} else {
			$p = class_exists( 'FKC_Packs' ) ? FKC_Packs::get( self::pack() ) : null;
			if ( $p && isset( $p['modes_vente'] ) ) { $decl = (array) $p['modes_vente']; }
			elseif ( $p && isset( $p['stock']['modes_vente'] ) ) { $decl = (array) $p['stock']['modes_vente']; }
		}
		if ( null === $decl ) { $decl = array( 'unite', 'quantite' ); }
		$out = array();
		foreach ( $decl as $m ) {
			$m = (string) $m;
			if ( self::modeExiste( $m ) && ! in_array( $m, $out, true ) ) { $out[] = $m; }
		}
		return $out ?: array( 'unite' );
	}

	/**
	 * Modes actifs d'un article. Sans rien de renseigné : « à l'unité » et
	 * « à la quantité » — le comportement historique, où toute quantité
	 * positive passait.
	 */
	public static function modesActifs( array $article ) {
		$brut = $article['modes_vente'] ?? null;
		if ( null === $brut || '' === $brut ) { return array( 'unite', 'quantite' ); }
		$dec = json_decode( (string) $brut, true );
		$out = array();
		foreach ( (array) ( is_array( $dec ) ? $dec : array() ) as $m ) {
			$m = (string) $m;
			if ( self::modeExiste( $m ) && ! in_array( $m, $out, true ) ) { $out[] = $m; }
		}
		return $out ?: array( 'unite', 'quantite' );
	}

	public static function modeActif( array $article, $mode ) {
		return in_array( (string) $mode, self::modesActifs( $article ), true );
	}

	/**
	 * Enregistre les modes de vente d'un article, filtrés par ce que le pack
	 * offre. Un article doit toujours se vendre d'au moins une façon : un jeu
	 * vide le rendrait invendable sans qu'aucun écran ne l'explique.
	 *
	 * @return array{bool, string}
	 */
	public static function definirModes( $articleId, array $demandes, ?array $cfg = null ) {
		self::ensure();
		$a = class_exists( 'FKC_VpStock' ) ? FKC_VpStock::article( $articleId ) : null;
		if ( ! $a ) { return array( false, 'Article introuvable.' ); }
		$offerts = self::modesOfferts( $cfg );
		$notes   = array();
		$set     = array();
		foreach ( $demandes as $m ) {
			$m = (string) $m;
			if ( ! self::modeExiste( $m ) ) { continue; }
			if ( ! in_array( $m, $offerts, true ) ) {
				$notes[] = '« ' . self::labelMode( $m ) . ' » n\'est pas proposé par ce métier — mode ignoré.';
				continue;
			}
			$set[ $m ] = true;
		}
		if ( ! $set ) {
			return array( false, 'Un article doit se vendre d\'au moins une façon — gardez au minimum « À l\'unité ».' );
		}
		$out = array();
		foreach ( array_keys( self::modes() ) as $m ) { if ( isset( $set[ $m ] ) ) { $out[] = $m; } }
		FKC_DB::q( 'UPDATE vp_articles SET modes_vente=? WHERE id=? AND pack=?', array( json_encode( $out ), (int) $a['id'], self::pack() ) );
		return array( true, $notes ? implode( ' ', $notes ) : '' );
	}

	/**
	 * La quantité demandée est-elle compatible avec les modes de vente ?
	 *
	 * Une quantité décimale sur un article vendu seulement à l'unité ou par
	 * carton est presque toujours une faute de frappe (2,5 au lieu de 25),
	 * et elle laisse un stock impossible à inventorier.
	 *
	 * @return array{bool, string}
	 */
	public static function validerQuantite( array $article, $qte ) {
		$qte = (float) $qte;
		if ( abs( $qte - round( $qte ) ) < 0.000001 ) { return array( true, '' ); }
		$actifs = self::modesActifs( $article );
		foreach ( $actifs as $m ) {
			$d = self::modes()[ $m ] ?? null;
			if ( $d && ! empty( $d['decimal'] ) ) { return array( true, '' ); }
		}
		return array( false, '« ' . $article['libelle'] . ' » se vend ' . fkc_lc( self::labelMode( $actifs[0] ) )
			. ' : la quantité doit être entière (' . fkc_money( $qte, 3 ) . ' demandé). Activez « Au mètre », « Au poids » ou « Sur mesure » sur sa fiche si cet article se coupe.' );
	}

	/** L'article se vend-il même sans stock disponible (mode « sur commande ») ? */
	public static function surCommande( array $article ) { return self::modeActif( $article, 'commande' ); }

	/** Le prix se calcule-t-il à la vente plutôt qu'au catalogue (« sur mesure ») ? */
	public static function surMesure( array $article ) { return self::modeActif( $article, 'mesure' ); }

	/* ── Grille tarifaire ────────────────────────────────────────────────── */

	public static function pourArticle( $articleId, $inclureInactifs = false ) {
		self::ensure();
		$w = 'WHERE pack=? AND article_id=?';
		$p = array( self::pack(), (int) $articleId );
		if ( ! $inclureInactifs ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_tarifs {$w} ORDER BY client_id IS NOT NULL DESC, niveau, qte_mini DESC", $p )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_tarifs WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	/** @return array{bool, string, int|null} */
	public static function creer( array $d ) {
		self::ensure();
		$articleId = (int) ( $d['article_id'] ?? 0 );
		$a = class_exists( 'FKC_VpStock' ) ? FKC_VpStock::article( $articleId ) : null;
		if ( ! $a ) { return array( false, 'Article introuvable.', null ); }

		$niveau = (string) ( $d['niveau'] ?? 'detail' );
		if ( ! self::niveauValide( $niveau ) ) { return array( false, 'Niveau de tarif inconnu.', null ); }

		$prix = (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) ( $d['prix'] ?? 0 ) );
		if ( $prix < 0 ) { return array( false, 'Un prix ne peut pas être négatif.', null ); }

		$qteMini = max( 0, (float) ( $d['qte_mini'] ?? 0 ) );
		$debut   = self::dateOuNull( $d['date_debut'] ?? '' );
		$fin     = self::dateOuNull( $d['date_fin'] ?? '' );
		if ( $debut && $fin && $fin < $debut ) {
			return array( false, 'La date de fin est antérieure à la date de début — ce tarif ne s\'appliquerait jamais.', null );
		}
		$clientId = ! empty( $d['client_id'] ) ? (int) $d['client_id'] : null;

		/*
		 * Deux fois le même niveau, pour le même client et le même palier :
		 * la résolution devrait alors départager deux prix également valables,
		 * donc choisir arbitrairement. Mieux vaut refuser et faire modifier
		 * le tarif existant.
		 */
		$doublon = FKC_DB::q(
			'SELECT id FROM vp_tarifs WHERE pack=? AND article_id=? AND niveau=? AND qte_mini=? AND actif=1 AND '
				. ( $clientId ? 'client_id=?' : 'client_id IS NULL' ),
			$clientId
				? array( self::pack(), $articleId, $niveau, $qteMini, $clientId )
				: array( self::pack(), $articleId, $niveau, $qteMini )
		)->fetch();
		if ( $doublon ) {
			return array( false, 'Ce tarif existe déjà pour cet article, à ce niveau et à partir de cette quantité — modifiez-le plutôt que d\'en créer un second.', null );
		}

		FKC_DB::q(
			'INSERT INTO vp_tarifs(pack,article_id,niveau,client_id,prix,qte_mini,date_debut,date_fin,actif) VALUES(?,?,?,?,?,?,?,?,1)',
			array( self::pack(), $articleId, $niveau, $clientId, $prix, $qteMini, $debut, $fin )
		);
		return array( true, self::labelNiveau( $clientId ? 'client' : $niveau ) . ' enregistré.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function supprimer( $id ) {
		self::ensure();
		$t = self::find( $id );
		if ( ! $t ) { return array( false, 'Tarif introuvable.' ); }
		FKC_DB::q( 'DELETE FROM vp_tarifs WHERE id=? AND pack=?', array( (int) $t['id'], self::pack() ) );
		return array( true, 'Tarif retiré.' );
	}

	/**
	 * LE PRIX APPLICABLE, et d'où il vient.
	 *
	 * Ne décide rien : propose. Le vendeur garde la main, et c'est ce qui rend
	 * l'outil utilisable dans un commerce où l'on négocie.
	 *
	 * @param array    $article
	 * @param float    $qte      quantité vendue (décide des paliers)
	 * @param int|null $clientId client identifié (prix spécial), ou null
	 * @param string   $date     date d'application (AAAA-MM-JJ), aujourd'hui par défaut
	 * @return array{prix:float|null,niveau:string,libelle:string,tarif_id:int|null}
	 */
	public static function resoudre( array $article, $qte = 1, $clientId = null, $date = null ) {
		self::ensure();
		// « Sur mesure » : aucun prix au catalogue n'aurait de sens — on rend
		// la main plutôt que de proposer un chiffre faux.
		if ( self::surMesure( $article ) ) {
			return array( 'prix' => null, 'niveau' => 'mesure', 'libelle' => self::labelNiveau( 'mesure' ), 'tarif_id' => null );
		}

		$qte  = (float) $qte;
		$date = $date ?: date( 'Y-m-d' );
		$rows = FKC_DB::q( 'SELECT * FROM vp_tarifs WHERE pack=? AND article_id=? AND actif=1',
			array( self::pack(), (int) $article['id'] ) )->fetchAll();

		$meilleur = null; $meilleurScore = -1;
		foreach ( $rows as $t ) {
			// Hors période : un tarif daté ne vaut que dans sa fenêtre.
			if ( ! empty( $t['date_debut'] ) && $date < $t['date_debut'] ) { continue; }
			if ( ! empty( $t['date_fin'] ) && $date > $t['date_fin'] ) { continue; }
			// Palier non atteint.
			if ( (float) $t['qte_mini'] > 0 && $qte < (float) $t['qte_mini'] ) { continue; }
			// Tarif nominatif : seulement pour CE client.
			if ( ! empty( $t['client_id'] ) && ( ! $clientId || (int) $t['client_id'] !== (int) $clientId ) ) { continue; }

			$score = ! empty( $t['client_id'] ) ? 100 : (int) ( self::niveaux()[ $t['niveau'] ]['priorite'] ?? 0 );
			// À priorité égale, le palier le plus exigeant gagne : « à partir
			// de 100 » est plus précis que « à partir de 10 ».
			$score = $score * 10000 + min( 9999, (int) ( $t['qte_mini'] ?? 0 ) );
			if ( $score > $meilleurScore ) { $meilleurScore = $score; $meilleur = $t; }
		}

		if ( $meilleur ) {
			$estClient = ! empty( $meilleur['client_id'] );
			return array(
				'prix'     => (float) $meilleur['prix'],
				'niveau'   => $estClient ? 'client' : (string) $meilleur['niveau'],
				'libelle'  => self::labelNiveau( $estClient ? 'client' : $meilleur['niveau'] ),
				'tarif_id' => (int) $meilleur['id'],
			);
		}
		return array(
			'prix'     => (float) ( $article['prix_vente'] ?? 0 ),
			'niveau'   => 'article',
			'libelle'  => self::labelNiveau( 'article' ),
			'tarif_id' => null,
		);
	}

	/**
	 * Écart entre le prix pratiqué et le prix de référence, en pourcentage.
	 * Positif = remise consentie, négatif = vendu au-dessus du tarif.
	 * Null si aucune référence chiffrée (article sur mesure, tarif à zéro).
	 */
	public static function remisePct( array $reference, $puPratique ) {
		$ref = $reference['prix'] ?? null;
		if ( null === $ref || (float) $ref <= 0 ) { return null; }
		return round( ( 1 - ( (float) $puPratique / (float) $ref ) ) * 100, 2 );
	}

	/**
	 * Vend-on sous le coût de revient ?
	 *
	 * Jamais bloquant — un déstockage à perte est une décision commerciale
	 * légitime. Mais elle ne doit pas passer inaperçue : c'est la seule façon
	 * de distinguer un choix d'une erreur de saisie.
	 *
	 * @return string Message d'alerte, ou chaîne vide.
	 */
	public static function alertePlancher( array $article, $puPratique ) {
		$cump = (float) ( $article['cump'] ?? 0 );
		if ( $cump <= 0 || (float) $puPratique >= $cump ) { return ''; }
		return '⚠️ Vendu sous le coût de revient : ' . fkc_money( $puPratique ) . ' F contre un CUMP de '
			. fkc_money( $cump ) . ' F, soit ' . fkc_money( $cump - (float) $puPratique ) . ' F de perte par ' . $article['unite'] . '.';
	}

	/** Trace commerciale d'une sortie : niveau appliqué et écart consenti. */
	public static function tracer( $mouvementId, array $reference, $puPratique ) {
		self::ensure();
		try {
			FKC_DB::q( 'UPDATE vp_mouvements SET tarif_niveau=?, remise_pct=? WHERE id=?', array(
				(string) ( $reference['niveau'] ?? 'article' ),
				self::remisePct( $reference, $puPratique ),
				(int) $mouvementId,
			) );
		} catch ( \Throwable $e ) { fkc_log( 'VpTarif::tracer ' . $e->getMessage(), 'ERROR' ); }
	}

	/**
	 * Remises consenties sur une période, par niveau de tarif : de quoi
	 * répondre à « qui a bradé quoi, et de combien » sans reconstituer les
	 * tickets un par un.
	 */
	public static function bilanRemises( $depuis = null, $jusqua = null ) {
		self::ensure();
		$w = "WHERE pack=? AND sens='sortie' AND tarif_niveau IS NOT NULL";
		$p = array( self::pack() );
		if ( $depuis ) { $w .= ' AND date(created_at)>=date(?)'; $p[] = $depuis; }
		if ( $jusqua ) { $w .= ' AND date(created_at)<=date(?)'; $p[] = $jusqua; }
		try {
			return FKC_DB::q(
				"SELECT tarif_niveau, COUNT(*) AS nb, SUM(montant) AS ca, AVG(remise_pct) AS remise_moy
				 FROM vp_mouvements {$w} GROUP BY tarif_niveau ORDER BY ca DESC", $p )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	protected static function dateOuNull( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return null; }
		foreach ( array( 'd/m/Y', 'd-m-Y', 'Y-m-d' ) as $fmt ) {
			$d = DateTime::createFromFormat( $fmt, $v );
			if ( $d && $d->format( $fmt ) === $v ) { return $d->format( 'Y-m-d' ); }
		}
		$d = date_create( $v );
		return $d ? $d->format( 'Y-m-d' ) : null;
	}
}
