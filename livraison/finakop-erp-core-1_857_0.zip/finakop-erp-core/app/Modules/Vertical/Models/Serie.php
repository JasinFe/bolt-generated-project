<?php
/**
 * SUIVI INDIVIDUEL (COM-010) — IMEI, numéros de série.
 *
 * Un article « sérialisé » (`vp_articles.serialise=1`) ne se vend plus comme
 * un simple nombre : chaque unité a une identité propre (l'IMEI d'un
 * téléphone), et il faut pouvoir dire EXACTEMENT quel exemplaire est entré,
 * lequel est sorti, lequel reste en stock — pas seulement combien.
 *
 * Volontairement une brique À PART de FKC_VpStock plutôt que des colonnes
 * ajoutées partout : elle ne s'active QUE pour les articles qui la
 * déclarent (Téléphonie aujourd'hui), n'entrave en rien la quantité
 * classique des 7 autres packs, et reste réutilisable par n'importe quel
 * futur pack qui vendrait du matériel sérialisé (électroménager, informatique…).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpSerie {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_series(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				numero_serie TEXT NOT NULL,
				statut TEXT NOT NULL DEFAULT 'en_stock',
				mouvement_entree_id INTEGER,
				mouvement_sortie_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, numero_serie)
			);
			CREATE INDEX IF NOT EXISTS idx_vps_article ON vp_series(article_id, statut);
		" );
		self::$ready = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/** Nettoie une liste de numéros saisis (un par ligne, ou déjà un tableau) : trim, vide écarté. */
	public static function nettoyer( $saisie ) {
		$liste = is_array( $saisie ) ? $saisie : preg_split( '/[\r\n,;]+/', (string) $saisie );
		$out = array();
		foreach ( $liste as $n ) {
			$n = trim( (string) $n );
			if ( '' !== $n ) { $out[] = $n; }
		}
		return $out;
	}

	public static function deArticle( $articleId, $statut = null ) {
		self::ensure();
		$w = 'WHERE article_id=?'; $p = array( (int) $articleId );
		if ( $statut ) { $w .= ' AND statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT * FROM vp_series {$w} ORDER BY id DESC", $p )->fetchAll();
	}

	/**
	 * Valide une liste de numéros pour une ENTRÉE (réception) : le compte
	 * doit correspondre EXACTEMENT à la quantité, aucun doublon dans la
	 * liste, et aucun numéro déjà connu dans ce commerce (un IMEI ne peut
	 * pas rentrer deux fois en stock sans être ressorti).
	 * @return array{bool, string}
	 */
	public static function validerEntree( $articleId, array $numeros, $qte ) {
		self::ensure();
		$numeros = self::nettoyer( $numeros );
		if ( count( $numeros ) !== (int) round( $qte ) ) {
			return array( false, 'Cet article se suit par numéro de série : indiquez exactement ' . (int) round( $qte ) . ' numéro(s), un par unité (' . count( $numeros ) . ' saisi(s)).' );
		}
		if ( count( $numeros ) !== count( array_unique( $numeros ) ) ) {
			return array( false, 'Deux numéros identiques ont été saisis pour cette réception.' );
		}
		foreach ( $numeros as $n ) {
			$existe = FKC_DB::q( 'SELECT 1 FROM vp_series WHERE pack=? AND numero_serie=?', array( self::pack(), $n ) )->fetch();
			if ( $existe ) { return array( false, 'Le numéro ' . $n . ' est déjà enregistré dans ce commerce.' ); }
		}
		return array( true, '' );
	}

	public static function enregistrerEntree( $articleId, array $numeros, $mouvementId ) {
		self::ensure();
		foreach ( self::nettoyer( $numeros ) as $n ) {
			FKC_DB::q(
				'INSERT INTO vp_series(pack,article_id,numero_serie,statut,mouvement_entree_id) VALUES(?,?,?,?,?)',
				array( self::pack(), (int) $articleId, $n, 'en_stock', (int) $mouvementId )
			);
		}
	}

	/**
	 * Valide une liste de numéros pour une VENTE : le compte doit
	 * correspondre à la quantité, et chaque numéro doit exister, appartenir
	 * à CET article, et être encore « en_stock ».
	 * @return array{bool, string}
	 */
	public static function validerSortie( $articleId, array $numeros, $qte ) {
		self::ensure();
		$numeros = self::nettoyer( $numeros );
		if ( count( $numeros ) !== (int) round( $qte ) ) {
			return array( false, 'Cet article se suit par numéro de série : indiquez exactement ' . (int) round( $qte ) . ' numéro(s) vendu(s) (' . count( $numeros ) . ' saisi(s)).' );
		}
		if ( count( $numeros ) !== count( array_unique( $numeros ) ) ) {
			return array( false, 'Deux numéros identiques ont été saisis pour cette vente.' );
		}
		foreach ( $numeros as $n ) {
			$r = FKC_DB::q( 'SELECT article_id, statut FROM vp_series WHERE pack=? AND numero_serie=?', array( self::pack(), $n ) )->fetch();
			if ( ! $r ) { return array( false, 'Le numéro ' . $n . ' est inconnu dans ce commerce.' ); }
			if ( (int) $r['article_id'] !== (int) $articleId ) { return array( false, 'Le numéro ' . $n . ' n\'appartient pas à cet article.' ); }
			if ( 'en_stock' !== $r['statut'] ) { return array( false, 'Le numéro ' . $n . ' n\'est plus en stock (déjà vendu ou retiré).' ); }
		}
		return array( true, '' );
	}

	public static function consommerVente( $articleId, array $numeros, $mouvementId ) {
		self::ensure();
		foreach ( self::nettoyer( $numeros ) as $n ) {
			FKC_DB::q(
				"UPDATE vp_series SET statut='vendu', mouvement_sortie_id=? WHERE pack=? AND numero_serie=? AND article_id=?",
				array( (int) $mouvementId, self::pack(), $n, (int) $articleId )
			);
		}
	}

	/** Numéros vendus par un mouvement de sortie donné (pour un retour). */
	public static function duMouvementSortie( $mouvementId ) {
		self::ensure();
		return FKC_DB::q( "SELECT * FROM vp_series WHERE mouvement_sortie_id=?", array( (int) $mouvementId ) )->fetchAll();
	}

	/** Remet en stock les numéros indiqués (retour) — délie le mouvement de sortie d'origine. */
	public static function restituer( array $numeros ) {
		self::ensure();
		foreach ( self::nettoyer( $numeros ) as $n ) {
			FKC_DB::q( "UPDATE vp_series SET statut='en_stock', mouvement_sortie_id=NULL WHERE pack=? AND numero_serie=?", array( self::pack(), $n ) );
		}
	}
}
