<?php
/**
 * CAPACITÉS ACTIVABLES PAR PRODUIT (ELM-001).
 *
 * L'EXIGENCE, TELLE QU'ELLE A ÉTÉ POSÉE
 *
 * « Je ne voudrais pas que tous les produits ajoutés au catalogue héritent
 * automatiquement de toutes les règles de l'électroménager. » C'est la bonne
 * exigence, et elle vaut bien au-delà de l'électroménager : un magasin qui
 * vend des réfrigérateurs vend aussi des rallonges. Le réfrigérateur porte un
 * numéro de série, une garantie, une livraison et une installation ; la
 * rallonge n'en porte aucune. Un pack qui imposerait les quatre à tout son
 * catalogue rendrait la saisie d'une rallonge plus lourde que sa marge.
 *
 * LE MODÈLE : LE PACK OFFRE, L'ARTICLE ACTIVE
 *
 *   1. Le PACK déclare ce qu'il sait faire (`capacites_offertes` au manifest).
 *      C'est un plafond : on ne peut pas activer sur un article une capacité
 *      que son métier ne propose pas.
 *   2. L'ARTICLE active ce dont il a besoin, et rien d'autre.
 *
 * POURQUOI UN JEU JSON PLUTÔT QUE DIX COLONNES BOOLÉENNES
 *
 * Dix colonnes, c'est dix migrations, dix `ALTER TABLE` à ne pas oublier, et
 * une onzième capacité qui coûte autant que les dix premières. Le jeu se lit
 * et s'écrit d'un bloc, et la liste des capacités connues vit dans ce fichier,
 * pas dans le schéma.
 *
 * `serialise` EST CONSERVÉE, ET C'EST DÉLIBÉRÉ
 *
 * La colonne `serialise` (COM-010) est lue directement par sept packs, par
 * FKC_VpSerie, par trois écrans et par un test. La migrer dans le jeu de
 * capacités aurait imposé de tout réécrire pour un gain nul. Cette brique la
 * traite donc comme la SOURCE DE VÉRITÉ de la capacité « série » : activer
 * la capacité met la colonne à 1, la colonne à 1 rend la capacité active.
 * Les deux ne peuvent pas diverger, et rien de ce qui existait ne bouge.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpCapacite {

	protected static $ready = false;

	/** Capacités déjà portées par le moteur avant cette brique — le socle par défaut. */
	const SOCLE = array( 'stock', 'variante', 'lot', 'serie' );

	/*
	 * ─── UNE CAPACITÉ DÉCLARÉE EST UNE CAPACITÉ QUI COMMANDE QUELQUE CHOSE ───
	 *
	 * Le catalogue en a compté onze pendant six versions, dont trois — lots,
	 * péremption, découpe — que le moteur ne consultait NULLE PART. Un
	 * commerçant pouvait les cocher sur un matelas : rien ne changeait, ni à
	 * la vente, ni à l'entrée, ni au stock. Une case qui ne commande rien est
	 * pire qu'une case absente : elle fait croire au commerçant que son besoin
	 * est couvert, et il ne découvre le contraire qu'à l'inventaire.
	 *
	 * Elles ont donc été RETIRÉES en 1.520.140, puis REMISES en 1.520.143 —
	 * avec FKC_VpLot derrière elles cette fois : saisie du lot à la réception,
	 * sortie en FEFO, refus de vendre un lot périmé, chute de découpe tracée.
	 *
	 * « Service associé » n'est pas revenu, et ne reviendra pas : il faisait
	 * DOUBLON. Un article qui est une prestation — pose, formation, mise en
	 * route — se déclare en décochant « Gestion du stock » : il se vend alors
	 * sans quantité et sans être refusé pour stock insuffisant (voir
	 * FKC_VpStock::gereStock). Deux cases pour le même besoin obligent le
	 * commerçant à deviner laquelle compte.
	 *
	 * tests/invariant_capacites.php interdit désormais qu'une capacité
	 * réapparaisse au catalogue sans que le moteur la consulte.
	 */

	public static function ensure() {
		if ( self::$ready ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN capacites TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/**
	 * Toutes les capacités connues du moteur.
	 *
	 * `defaut` : ce qu'un article porte quand rien n'a jamais été coché — la
	 * gestion de stock est la seule dans ce cas, parce que c'est ce que faisait
	 * le moteur avant cette brique et qu'une capacité par défaut à `false`
	 * aurait retiré le stock à tout le parc installé.
	 *
	 * `requiert` : capacités sans lesquelles celle-ci n'a pas de sens. Une
	 * péremption suit un lot ; un numéro de série suit une unité physique en
	 * stock. Ce ne sont pas des préférences d'écran : activer une péremption
	 * sans lot produirait une date rattachée à rien.
	 *
	 * @return array<string,array{label:string,icone:string,aide:string,defaut:bool,requiert:array}>
	 */
	public static function catalogue() {
		return array(
			'stock' => array(
				'label' => 'Gestion du stock', 'icone' => '📦', 'defaut' => true, 'requiert' => array(),
				'aide'  => 'Les quantités sont suivies et valorisées au CUMP. Décochez pour une prestation ou un article non stocké.',
			),
			'variante' => array(
				'label' => 'Variantes', 'icone' => '🎨', 'defaut' => false, 'requiert' => array( 'stock' ),
				'aide'  => 'Déclinaisons taille / couleur, chacune avec son propre stock et son propre prix.',
			),
			'lot' => array(
				'label' => 'Lots', 'icone' => '🔖', 'defaut' => false, 'requiert' => array( 'stock' ),
				'aide'  => 'Traçabilité par lot : chaque réception porte son numéro, et les sorties s\'y imputent. Indispensable pour retrouver ce qu\'on a vendu le jour d\'un rappel.',
			),
			'peremption' => array(
				'label' => 'Péremption', 'icone' => '⏳', 'defaut' => false, 'requiert' => array( 'stock', 'lot' ),
				'aide'  => 'Date limite par lot. Les sorties partent du lot qui périme le plus tôt, et un lot périmé ne se vend plus.',
			),
			'decoupe' => array(
				'label' => 'Découpe', 'icone' => '✂️', 'defaut' => false, 'requiert' => array( 'stock' ),
				'aide'  => 'L\'article se vend coupé à la demande. La chute est enregistrée comme sortie tracée — sinon l\'inventaire dérive sans explication.',
			),
			'serie' => array(
				'label' => 'Numéros de série', 'icone' => '🔢', 'defaut' => false, 'requiert' => array( 'stock' ),
				'aide'  => 'Chaque unité est identifiée individuellement (n° de série, IMEI). C\'est ce qui permet d\'adosser une garantie à une machine précise.',
			),
			'garantie' => array(
				'label' => 'Garantie', 'icone' => '🛡️', 'defaut' => false, 'requiert' => array(),
				'aide'  => 'Une garantie court à partir de la vente. Bien plus fiable si l\'article porte aussi un numéro de série.',
			),
			'sav' => array(
				'label' => 'SAV', 'icone' => '🛠️', 'defaut' => false, 'requiert' => array(),
				'aide'  => 'Interventions après-vente : sous garantie ou facturées.',
			),
			'livraison' => array(
				'label' => 'Livraison', 'icone' => '🚚', 'defaut' => false, 'requiert' => array(),
				'aide'  => 'L\'article se livre : la vente ouvre un suivi de livraison.',
			),
			'installation' => array(
				'label' => 'Installation & mise en service', 'icone' => '🔧', 'defaut' => false, 'requiert' => array(),
				'aide'  => 'Pose, raccordement ou mise en service à réaliser chez le client.',
			),
		);
	}

	public static function existe( $code ) {
		return array_key_exists( (string) $code, self::catalogue() );
	}

	public static function meta( $code ) {
		return self::catalogue()[ (string) $code ] ?? null;
	}

	public static function label( $code ) {
		$m = self::meta( $code );
		return $m ? $m['label'] : (string) $code;
	}

	/* ── Ce que le PACK offre ────────────────────────────────────────────── */

	/**
	 * Capacités proposées par le pack courant. Un manifest qui ne déclare
	 * rien reste au SOCLE : c'est exactement ce que le moteur savait déjà
	 * faire avant cette brique, donc aucun des packs existants ne se voit
	 * proposer d'un coup des cases à cocher qu'il ne sait pas honorer.
	 *
	 * @return array<int,string>
	 */
	public static function offertes( ?array $cfg = null ) {
		$decl = null;
		if ( is_array( $cfg ) && isset( $cfg['stock']['capacites'] ) ) {
			$decl = (array) $cfg['stock']['capacites'];
		} else {
			$p = class_exists( 'FKC_Packs' ) ? FKC_Packs::get( self::pack() ) : null;
			if ( $p && isset( $p['capacites_offertes'] ) ) { $decl = (array) $p['capacites_offertes']; }
			elseif ( $p && isset( $p['stock']['capacites'] ) ) { $decl = (array) $p['stock']['capacites']; }
		}
		if ( null === $decl ) { $decl = self::SOCLE; }

		$out = array();
		foreach ( $decl as $c ) {
			$c = (string) $c;
			if ( self::existe( $c ) && ! in_array( $c, $out, true ) ) { $out[] = $c; }
		}
		// La gestion de stock reste toujours proposable : c'est elle qu'on
		// décoche pour un article non stocké, et un pack qui l'oublierait
		// rendrait ce cas inatteignable.
		if ( ! in_array( 'stock', $out, true ) ) { array_unshift( $out, 'stock' ); }
		return $out;
	}

	public static function estOfferte( $code, ?array $cfg = null ) {
		return in_array( (string) $code, self::offertes( $cfg ), true );
	}

	/* ── Ce que l'ARTICLE active ─────────────────────────────────────────── */

	/**
	 * Capacités actives d'un article.
	 *
	 * Un article dont la colonne n'a jamais été renseignée (tout le parc
	 * installé, et tout article créé par une API qui ignore cette brique)
	 * reçoit les valeurs par défaut du catalogue — donc la gestion de stock,
	 * et rien d'autre. C'est le comportement d'avant, à l'identique.
	 *
	 * @return array<int,string>
	 */
	public static function actives( array $article ) {
		$brut = $article['capacites'] ?? null;
		if ( null === $brut || '' === $brut ) {
			$out = array();
			foreach ( self::catalogue() as $code => $m ) { if ( ! empty( $m['defaut'] ) ) { $out[] = $code; } }
		} else {
			$dec = json_decode( (string) $brut, true );
			$out = array();
			foreach ( (array) ( is_array( $dec ) ? $dec : array() ) as $c ) {
				$c = (string) $c;
				if ( self::existe( $c ) && ! in_array( $c, $out, true ) ) { $out[] = $c; }
			}
		}
		// `serialise` fait foi pour la capacité « série » (voir l'en-tête).
		if ( ! empty( $article['serialise'] ) && ! in_array( 'serie', $out, true ) ) { $out[] = 'serie'; }
		return $out;
	}

	/** Cette capacité est-elle active sur cet article ? */
	public static function actif( array $article, $code ) {
		$code = (string) $code;
		if ( 'serie' === $code && ! empty( $article['serialise'] ) ) { return true; }
		return in_array( $code, self::actives( $article ), true );
	}

	/**
	 * L'article est-il suivi en stock ?
	 *
	 * Question posée si souvent — et si lourde de conséquences : une vente
	 * d'article non stocké ne doit pas être refusée pour stock insuffisant —
	 * qu'elle mérite son propre nom. Le défaut est TOUJOURS oui.
	 */
	public static function gereStock( array $article ) {
		return self::actif( $article, 'stock' );
	}

	/**
	 * Normalise un jeu de capacités : filtre l'inconnu, refuse ce que le pack
	 * n'offre pas, complète les dépendances manquantes plutôt que d'échouer
	 * (cocher « Péremption » veut dire « suivre les lots », personne n'aime
	 * s'entendre répondre non sur une évidence), et retire ce qui dépend
	 * d'une capacité absente.
	 *
	 * @return array{0:array,1:array} ( capacités retenues, explications à afficher )
	 */
	public static function normaliser( array $demandees, ?array $cfg = null ) {
		$offertes = self::offertes( $cfg );
		$notes    = array();

		$set = array();
		foreach ( $demandees as $c ) {
			$c = (string) $c;
			if ( ! self::existe( $c ) ) { continue; }
			if ( ! in_array( $c, $offertes, true ) ) {
				$notes[] = '« ' . self::label( $c ) . ' » n\'est pas proposée par ce métier — capacité ignorée.';
				continue;
			}
			$set[ $c ] = true;
		}

		// Complétion des dépendances, en cascade (péremption → lot → stock).
		$boucle = 0;
		do {
			$ajout = false;
			foreach ( array_keys( $set ) as $c ) {
				foreach ( (array) self::meta( $c )['requiert'] as $dep ) {
					if ( isset( $set[ $dep ] ) ) { continue; }
					if ( ! in_array( $dep, $offertes, true ) ) {
						unset( $set[ $c ] );
						$notes[] = '« ' . self::label( $c ) . ' » a été retirée : elle a besoin de « ' . self::label( $dep ) . ' », que ce métier ne propose pas.';
						$ajout = true;
						continue 2;
					}
					$set[ $dep ] = true;
					$notes[] = '« ' . self::label( $dep ) . ' » a été activée : « ' . self::label( $c ) . ' » ne peut pas s\'en passer.';
					$ajout = true;
				}
			}
			$boucle++;
		} while ( $ajout && $boucle < 10 );

		// Ordre stable, celui du catalogue : un jeu comparable d'un article à l'autre.
		$out = array();
		foreach ( array_keys( self::catalogue() ) as $code ) {
			if ( isset( $set[ $code ] ) ) { $out[] = $code; }
		}
		return array( $out, $notes );
	}

	/**
	 * Enregistre les capacités d'un article. Maintient `serialise` en phase
	 * — c'est ce qui permet à COM-010 (FKC_VpSerie et ses trois écrans) de
	 * continuer à fonctionner sans savoir que cette brique existe.
	 *
	 * @return array{0:bool,1:string} ( ok, explications éventuelles )
	 */
	public static function definir( $articleId, array $demandees, ?array $cfg = null ) {
		self::ensure();
		$a = class_exists( 'FKC_VpStock' ) ? FKC_VpStock::article( $articleId ) : null;
		if ( ! $a ) { return array( false, 'Article introuvable.' ); }

		list( $retenues, $notes ) = self::normaliser( $demandees, $cfg );

		/*
		 * Retirer la gestion de stock à un article qui en a encore ne peut
		 * pas être un simple décochage : la quantité restante cesserait
		 * d'être suivie sans jamais être sortie, et la valeur du stock
		 * mentirait d'autant, sans trace.
		 */
		if ( ! in_array( 'stock', $retenues, true ) && abs( (float) $a['qte_stock'] ) > 0.00001 ) {
			return array( false, 'Impossible de retirer la gestion de stock : il reste ' . fkc_money( $a['qte_stock'] ) . ' ' . $a['unite']
				. ' en stock. Sortez ou régularisez cette quantité d\'abord — sinon elle disparaîtrait du suivi sans être sortie.' );
		}

		/*
		 * Retirer le suivi par numéro de série alors que des numéros sont
		 * encore en stock laisserait ces numéros dans la base sans écran
		 * pour les voir ni les sortir.
		 */
		if ( ! in_array( 'serie', $retenues, true ) && ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
			$restants = 0;
			try { $restants = count( (array) FKC_VpSerie::deArticle( (int) $a['id'], 'en_stock' ) ); }
			catch ( \Throwable $e ) { $restants = 0; }
			if ( $restants > 0 ) {
				return array( false, 'Impossible de retirer le suivi par numéro de série : ' . $restants
					. ' numéro(s) sont encore en stock pour cet article.' );
			}
		}

		try {
			FKC_DB::q( 'UPDATE vp_articles SET capacites=?, serialise=? WHERE id=? AND pack=?', array(
				json_encode( array_values( $retenues ) ),
				in_array( 'serie', $retenues, true ) ? 1 : 0,
				(int) $a['id'], self::pack(),
			) );
		} catch ( \Throwable $e ) {
			fkc_log( 'VpCapacite::definir ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Les capacités n\'ont pas pu être enregistrées.' );
		}
		return array( true, $notes ? implode( ' ', $notes ) : '' );
	}

	/** Rendu court pour une liste : « 📦 🔢 🛡️ ». */
	public static function pastilles( array $article ) {
		$out = array();
		foreach ( self::actives( $article ) as $c ) {
			$m = self::meta( $c );
			if ( $m ) { $out[] = $m['icone']; }
		}
		return implode( ' ', $out );
	}
}
