<?php
/**
 * SORTIES IMPRIMABLES DE LA BRIQUE VERTICALE (COM-050).
 *
 * CE QUI MANQUAIT, ET POURQUOI C'ÉTAIT BLOQUANT
 *
 * La brique verticale savait vendre, livrer, réparer et encaisser des
 * acomptes — sans jamais produire une seule feuille de papier. Une vente au
 * comptant, cas d'usage majoritaire des deux packs de commerce, ne laissait
 * AUCUNE trace remise au client. Un acheteur repartait avec un réfrigérateur
 * à 265 000 F et rien dans la main.
 *
 * Ce n'est pas un manque de confort : un commerçant ne peut pas vendre sans
 * remettre de justificatif, et un client qui revient en SAV sans preuve
 * d'achat n'a que la parole du vendeur pour lui.
 *
 * CE QUE CETTE BRIQUE EST — ET N'EST PAS
 *
 * Elle n'imprime rien et ne met rien en page. Elle ASSEMBLE : elle prend un
 * mouvement, une commande, une intervention ou une garantie, et en tire une
 * structure normalisée — émetteur, destinataire, lignes, totaux, mentions —
 * que la vue unique `vertical.document` sait rendre.
 *
 * Six documents, une seule mise en page. Écrire six vues aurait garanti que
 * l'en-tête de la société diverge entre elles au premier changement d'adresse,
 * et qu'un document oublie la mention légale que les cinq autres portent.
 *
 * CE QU'ELLE NE FABRIQUE PAS
 *
 * Ni facture, ni avoir, ni reçu de règlement : ceux-là existent déjà
 * (FKC_Facture, FKC_Recu) avec leurs propres écrans d'impression, leur
 * numérotation légale et, pour la facture, la certification FNE. Les
 * réimplémenter ici aurait créé un second gabarit de facture — celui que le
 * fisc ne reconnaîtrait pas.
 *
 * LA NUMÉROTATION N'EST PAS INVENTÉE
 *
 * Chaque document reprend l'identifiant de l'objet qu'il matérialise : le
 * numéro de commande pour un devis, celui de l'intervention pour une fiche
 * SAV. Un compteur propre aurait produit deux numéros pour une même chose,
 * et rendu impossible de retrouver la vente derrière un reçu.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpDocument {

	public static function pack() { return FKC_Packs::activeCode(); }

	/**
	 * Les six documents, et ce qui les distingue.
	 *
	 * `duplicata` : ce document se réimprime-t-il tel quel ? Un reçu de vente
	 * réimprimé doit porter la mention « DUPLICATA », sinon deux exemplaires
	 * du même encaissement circulent sans qu'on puisse les distinguer.
	 */
	public static function types() {
		return array(
			'vente'        => array( 'titre' => 'REÇU DE VENTE',        'icone' => '🧾', 'duplicata' => true ),
			'devis'        => array( 'titre' => 'DEVIS',                'icone' => '📄', 'duplicata' => false ),
			'livraison'    => array( 'titre' => 'BON DE LIVRAISON',     'icone' => '🚚', 'duplicata' => true ),
			'acompte'      => array( 'titre' => 'REÇU D\'ACOMPTE',      'icone' => '💰', 'duplicata' => true ),
			'intervention' => array( 'titre' => 'FICHE D\'INTERVENTION', 'icone' => '🛠️', 'duplicata' => false ),
			'garantie'     => array( 'titre' => 'BON DE GARANTIE',      'icone' => '🛡️', 'duplicata' => false ),
		);
	}

	public static function typeValide( $t ) { return array_key_exists( (string) $t, self::types() ); }

	/**
	 * Assemble un document.
	 *
	 * @param string $type Un des six types.
	 * @param int    $id   Identifiant de l'objet source (mouvement, commande…).
	 * @return array|null  Structure normalisée, ou null si l'objet est introuvable.
	 */
	public static function assembler( $type, $id, array $cfg = array() ) {
		if ( ! self::typeValide( $type ) ) { return null; }
		$methode = 'doc' . ucfirst( (string) $type );
		$doc = self::$methode( (int) $id, $cfg );
		if ( ! $doc ) { return null; }

		$meta = self::types()[ $type ];
		return array_merge( array(
			'type'      => $type,
			'titre'     => $meta['titre'],
			'duplicata' => ! empty( $meta['duplicata'] ),
			'emetteur'  => self::emetteur(),
			'devise'    => self::devise(),
			'lignes'    => array(),
			'totaux'    => array(),
			'infos'     => array(),
			'mentions'  => array(),
			'signature' => null,
		), $doc );
	}

	/* ── Émetteur ────────────────────────────────────────────────────────── */

	/**
	 * L'en-tête de la société, lu une fois et partagé par les six documents.
	 * C'est ce partage qui garantit qu'un changement d'adresse se voit
	 * partout, et pas sur cinq documents sur six.
	 */
	public static function emetteur() {
		$soc = class_exists( 'FKC_Tenant' ) ? FKC_Tenant::current() : null;
		return array(
			'nom'     => trim( (string) ( $soc['raison_sociale'] ?? '' ) ) ?: 'Votre société',
			'forme'   => trim( (string) ( $soc['forme_juridique'] ?? '' ) ),
			'ncc'     => trim( (string) ( $soc['ncc'] ?? '' ) ),
			'rccm'    => trim( (string) ( $soc['rccm'] ?? '' ) ),
			'adresse' => trim( (string) ( $soc['adresse'] ?? '' ) ),
			'ville'   => trim( (string) ( $soc['ville'] ?? '' ) ),
			'tel'     => trim( (string) ( $soc['telephone'] ?? '' ) ),
			'email'   => trim( (string) ( $soc['email'] ?? '' ) ),
			'logo'    => ( $soc && class_exists( 'FKC_Societe' ) && FKC_Societe::hasLogo( $soc ) ) ? FKC_Societe::logoUrl( $soc ) : null,
		);
	}

	public static function devise() {
		$soc = class_exists( 'FKC_Tenant' ) ? FKC_Tenant::current() : null;
		$d = trim( (string) ( $soc['devise'] ?? 'XOF' ) ) ?: 'XOF';
		return 'XOF' === $d ? 'F CFA' : $d;
	}

	/* ── Les six documents ───────────────────────────────────────────────── */

	/**
	 * REÇU DE VENTE — le document qui manquait le plus.
	 *
	 * Il matérialise UN mouvement de sortie. Le montant imprimé est celui qui
	 * a été réellement encaissé, relu dans le mouvement et non recalculé
	 * depuis le prix du catalogue : un prix négocié le jour de la vente ne
	 * doit pas se transformer en prix courant sur le reçu remis au client.
	 */
	protected static function docVente( $mouvementId, array $cfg ) {
		$m = self::mouvement( $mouvementId );
		if ( ! $m || 'sortie' !== (string) $m['sens'] ) { return null; }
		$a = FKC_VpStock::article( (int) $m['article_id'] );

		$ttc = (float) $m['montant'];
		$tva = isset( $m['tva_pct'] ) ? (float) $m['tva_pct'] : (float) ( $cfg['stock']['tva'] ?? 0 );
		$ht  = $tva > 0 ? round( $ttc / ( 1 + $tva / 100 ), 2 ) : $ttc;
		$pu  = (float) $m['qte'] > 0 ? round( $ttc / (float) $m['qte'], 2 ) : $ttc;

		$infos = array( 'Date' => self::dateLisible( $m['created_at'] ) );
		if ( ! empty( $m['motif'] ) ) { $infos['Objet'] = $m['motif']; }
		if ( ! empty( $m['tarif_niveau'] ) && class_exists( 'FKC_VpTarif' ) ) {
			$infos['Tarif appliqué'] = FKC_VpTarif::labelNiveau( $m['tarif_niveau'] );
		}
		// Les numéros de série vendus figurent sur le reçu : c'est ce qui
		// permettra de reconnaître l'appareil au SAV, même sans facture.
		if ( class_exists( 'FKC_VpSerie' ) ) {
			$nums = array();
			foreach ( (array) FKC_VpSerie::duMouvementSortie( (int) $m['id'] ) as $s ) { $nums[] = $s['numero_serie']; }
			if ( $nums ) { $infos['N° de série'] = implode( ', ', $nums ); }
		}

		return array(
			'numero'      => 'REC-' . str_pad( (string) $m['id'], 6, '0', STR_PAD_LEFT ),
			'date'        => self::dateLisible( $m['created_at'] ),
			'destinataire' => array( 'nom' => 'Client comptoir' ),
			'lignes'      => array( array(
				'designation' => $a ? $a['libelle'] : 'Article',
				'reference'   => $a['reference'] ?? '',
				'qte'         => (float) $m['qte'],
				'unite'       => $a['unite'] ?? 'u',
				'pu'          => $pu,
				'total'       => $ttc,
			) ),
			'totaux' => array(
				'Total HT'  => $ht,
				'TVA ' . fkc_money( $tva, 0 ) . ' %' => round( $ttc - $ht, 2 ),
				'NET À PAYER' => $ttc,
			),
			'infos'    => $infos,
			'mentions' => array( 'Marchandise vendue et acceptée. Conservez ce reçu : il vous sera demandé pour tout échange ou recours en garantie.' ),
		);
	}

	/** DEVIS — un engagement de prix, pas une vente. */
	protected static function docDevis( $commandeId, array $cfg ) {
		if ( ! class_exists( 'FKC_VpCommande' ) ) { return null; }
		$c = FKC_VpCommande::find( $commandeId );
		if ( ! $c ) { return null; }

		list( $lignes, $totaux ) = self::lignesCommande( $c, $cfg );
		return array(
			'numero'       => (string) $c['numero'],
			'date'         => self::dateLisible( $c['created_at'] ?? '' ),
			'destinataire' => array( 'nom' => (string) $c['client_nom'] ),
			'lignes'       => $lignes,
			'totaux'       => $totaux,
			'infos'        => array( 'Statut' => self::statutCommande( $c['statut'] ) ),
			'mentions'     => array(
				'Devis valable 30 jours, sous réserve de disponibilité des articles au moment de la commande.',
				'Ce document n\'est ni une facture ni une vente : aucune marchandise n\'est réservée avant confirmation.',
			),
			'signature'    => 'Bon pour accord — date et signature du client',
		);
	}

	/**
	 * BON DE LIVRAISON — ce que le client signe à la réception.
	 *
	 * Il porte les quantités LIVRÉES, pas les quantités commandées : c'est
	 * toute son utilité sur une commande livrée en plusieurs fois. Le reste à
	 * livrer figure en clair, pour que le client sache ce qu'il attend encore.
	 */
	protected static function docLivraison( $commandeId, array $cfg ) {
		if ( ! class_exists( 'FKC_VpCommande' ) ) { return null; }
		$c = FKC_VpCommande::find( $commandeId );
		if ( ! $c ) { return null; }

		$lignes = array(); $resteTotal = 0;
		foreach ( (array) $c['lignes'] as $l ) {
			$livre = (float) ( $l['qte_livree'] ?? 0 );
			if ( $livre <= 0 ) { continue; }
			$a = FKC_VpStock::article( (int) $l['article_id'] );
			$reste = max( 0, (float) $l['qte'] - $livre );
			$resteTotal += $reste;
			$lignes[] = array(
				'designation' => $a ? $a['libelle'] : 'Article',
				'reference'   => $a['reference'] ?? '',
				'qte'         => $livre,
				'unite'       => $a['unite'] ?? 'u',
				'commande'    => (float) $l['qte'],
				'reste'       => $reste,
			);
		}
		if ( ! $lignes ) { return null; }

		$mentions = array( 'Marchandise reçue en bon état et conforme à la commande, sauf réserves portées ci-dessus.' );
		if ( $resteTotal > 0 ) {
			$mentions[] = 'Cette livraison est PARTIELLE : ' . fkc_money( $resteTotal ) . ' unité(s) restent à livrer sur cette commande.';
		}
		return array(
			'numero'       => 'BL-' . (string) $c['numero'],
			'date'         => date( 'd/m/Y' ),
			'destinataire' => array( 'nom' => (string) $c['client_nom'] ),
			'lignes'       => $lignes,
			'infos'        => array( 'Commande' => (string) $c['numero'] ),
			'mentions'     => $mentions,
			'signature'    => 'Reçu par (nom, date et signature)',
			'sans_prix'    => true, // un bon de livraison ne porte pas de montants
		);
	}

	/**
	 * REÇU D'ACOMPTE — la preuve qu'un client a versé une avance.
	 *
	 * Le solde restant y figure : c'est la première question qu'il posera, et
	 * ne pas y répondre sur le papier garantit qu'il rappellera pour la poser.
	 */
	protected static function docAcompte( $acompteId, array $cfg ) {
		$ac = FKC_DB::q( 'SELECT * FROM vp_acomptes WHERE id=? AND pack=?', array( (int) $acompteId, self::pack() ) )->fetch();
		if ( ! $ac ) { return null; }
		$c = class_exists( 'FKC_VpCommande' ) ? FKC_VpCommande::find( (int) $ac['commande_id'] ) : null;
		if ( ! $c ) { return null; }

		$total = 0.0;
		foreach ( (array) $c['lignes'] as $l ) { $total += (float) $l['qte'] * (float) $l['pu']; }
		$verses = class_exists( 'FKC_VpCommande' ) ? FKC_VpCommande::totalAcomptes( (int) $c['id'] ) : (float) $ac['montant'];

		return array(
			'numero'       => 'ACO-' . str_pad( (string) $ac['id'], 6, '0', STR_PAD_LEFT ),
			'date'         => self::dateLisible( $ac['date_acompte'] ),
			'destinataire' => array( 'nom' => (string) $c['client_nom'] ),
			'lignes'       => array( array(
				'designation' => 'Acompte sur commande ' . $c['numero'],
				'qte'         => 1, 'unite' => '', 'pu' => (float) $ac['montant'], 'total' => (float) $ac['montant'],
			) ),
			'totaux' => array(
				'Montant reçu'          => (float) $ac['montant'],
				'Total des acomptes'    => $verses,
				'Montant de la commande' => $total,
				'RESTE À PAYER'         => max( 0, $total - $verses ),
			),
			'infos' => array(
				'Commande' => (string) $c['numero'],
				'Règlement' => ucfirst( (string) ( $ac['moyen'] ?: 'espèces' ) ),
			),
			'mentions' => array(
				'Cet acompte est une avance sur commande : il ne constitue pas une vente et sera déduit de la facture définitive.',
				'Conservez ce reçu — il vous sera demandé à la livraison.',
			),
			'signature' => 'Le caissier',
		);
	}

	/**
	 * FICHE D'INTERVENTION — ce qu'on remet au client qui dépose un appareil.
	 *
	 * Sans elle, il n'a aucune preuve de dépôt, et le magasin aucune trace de
	 * ce qu'il a reçu. C'est le document le plus utile du lot après le reçu.
	 */
	protected static function docIntervention( $interventionId, array $cfg ) {
		if ( ! class_exists( 'FKC_VpApresVente' ) ) { return null; }
		$i = FKC_VpApresVente::intervention( $interventionId );
		if ( ! $i ) { return null; }

		$infos = array(
			'Nature'  => FKC_VpApresVente::labelType( $i['type'] ),
			'Ouverte le' => self::dateLisible( $i['date_ouverture'] ),
			'Statut'  => FKC_VpApresVente::statuts()[ $i['statut'] ] ?? $i['statut'],
		);
		if ( ! empty( $i['numero_serie'] ) ) { $infos['N° de série'] = (string) $i['numero_serie']; }
		if ( ! empty( $i['technicien'] ) )   { $infos['Technicien']  = (string) $i['technicien']; }
		if ( ! empty( $i['date_prevue'] ) )  { $infos['Prévue le']   = self::dateLisible( $i['date_prevue'] ); }

		/*
		 * La couverture est écrite EN TOUTES LETTRES sur la fiche. C'est la
		 * source de discussion numéro un au comptoir : le client doit savoir,
		 * au moment où il laisse son appareil, s'il paiera ou non.
		 */
		$mentions = array();
		if ( ! empty( $i['sous_garantie'] ) ) {
			$g = FKC_VpApresVente::garantie( (int) $i['garantie_id'] );
			$mentions[] = 'APPAREIL SOUS GARANTIE' . ( $g ? ' jusqu\'au ' . self::dateLisible( $g['date_fin'] ) : '' )
				. ' — cette intervention ne sera pas facturée.';
		} else {
			$mentions[] = 'Appareil HORS GARANTIE — l\'intervention et les pièces seront facturées. Un devis vous sera présenté avant toute réparation.';
		}
		$mentions[] = 'Les appareils non retirés dans un délai de 90 jours après avis de mise à disposition pourront faire l\'objet de frais de garde.';

		return array(
			'numero'       => (string) $i['numero'],
			'date'         => self::dateLisible( $i['date_ouverture'] ),
			'destinataire' => array( 'nom' => (string) ( $i['client_nom'] ?: 'Client' ) ),
			'lignes'       => array( array(
				'designation' => (string) ( $i['article_libelle'] ?: 'Appareil' ),
				'reference'   => (string) ( $i['numero_serie'] ?: '' ),
				'qte'         => 1, 'unite' => '',
				'note'        => (string) ( $i['description'] ?: 'Panne à diagnostiquer' ),
			) ),
			'infos'     => $infos,
			'mentions'  => $mentions,
			'signature' => 'Le client (dépôt) — nom, date et signature',
			'sans_prix' => true,
		);
	}

	/** BON DE GARANTIE — la garantie existait en base sans jamais s'imprimer. */
	protected static function docGarantie( $garantieId, array $cfg ) {
		if ( ! class_exists( 'FKC_VpApresVente' ) ) { return null; }
		$g = FKC_VpApresVente::garantie( $garantieId );
		if ( ! $g ) { return null; }

		$jours = (int) floor( ( strtotime( $g['date_fin'] ) - time() ) / 86400 );
		$infos = array(
			'Type'     => FKC_VpApresVente::typesGarantie()[ $g['type'] ] ?? $g['type'],
			'Début'    => self::dateLisible( $g['date_debut'] ),
			'Échéance' => self::dateLisible( $g['date_fin'] ),
			'Durée'    => (int) $g['duree_mois'] . ' mois',
		);
		if ( ! empty( $g['numero_serie'] ) ) { $infos['N° de série'] = (string) $g['numero_serie']; }

		return array(
			'numero'       => 'GAR-' . str_pad( (string) $g['id'], 6, '0', STR_PAD_LEFT ),
			'date'         => self::dateLisible( $g['date_debut'] ),
			'destinataire' => array( 'nom' => (string) ( $g['client_nom'] ?: 'Client' ) ),
			'lignes'       => array( array(
				'designation' => (string) ( $g['article_libelle'] ?: 'Appareil' ),
				'reference'   => (string) ( $g['numero_serie'] ?: '' ),
				'qte'         => 1, 'unite' => '',
			) ),
			'infos'    => $infos,
			'mentions' => array(
				$jours > 0
					? 'Garantie EN COURS — il reste ' . $jours . ' jour(s) de couverture.'
					: 'Garantie EXPIRÉE depuis le ' . self::dateLisible( $g['date_fin'] ) . '.',
				'La garantie couvre les défauts de fabrication. Sont exclus : les dommages dus à une mauvaise utilisation, à une installation non conforme, à une surtension ou à une intervention par un tiers non agréé.',
				'Présentez ce bon et le numéro de série pour toute demande de prise en charge.',
			),
			'sans_prix' => true,
		);
	}

	/* ── Assemblages partagés ────────────────────────────────────────────── */

	/** Lignes et totaux d'une commande — communs au devis. */
	protected static function lignesCommande( array $c, array $cfg ) {
		$lignes = array(); $ht = 0.0;
		foreach ( (array) $c['lignes'] as $l ) {
			$a = FKC_VpStock::article( (int) $l['article_id'] );
			$total = (float) $l['qte'] * (float) $l['pu'];
			$ht += $total;
			$lignes[] = array(
				'designation' => $a ? $a['libelle'] : 'Article',
				'reference'   => $a['reference'] ?? '',
				'qte'         => (float) $l['qte'],
				'unite'       => $a['unite'] ?? 'u',
				'pu'          => (float) $l['pu'],
				'total'       => $total,
			);
		}
		$taux = (float) ( $cfg['stock']['tva'] ?? 0 );
		$tva  = round( $ht * $taux / 100, 2 );
		return array( $lignes, array(
			'Total HT' => $ht,
			'TVA ' . fkc_money( $taux, 0 ) . ' %' => $tva,
			'TOTAL TTC' => $ht + $tva,
		) );
	}

	protected static function mouvement( $id ) {
		try {
			$r = FKC_DB::q( 'SELECT * FROM vp_mouvements WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
			return $r ?: null;
		} catch ( \Throwable $e ) { return null; }
	}

	protected static function statutCommande( $s ) {
		$d = array( 'devis' => 'Devis', 'confirmee' => 'Commande confirmée', 'livree' => 'Livrée', 'facturee' => 'Facturée', 'annulee' => 'Annulée' );
		return $d[ (string) $s ] ?? (string) $s;
	}

	public static function dateLisible( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return date( 'd/m/Y' ); }
		$d = date_create( substr( $v, 0, 19 ) );
		return $d ? $d->format( 'd/m/Y' ) : $v;
	}

	/* ── Ticket thermique ────────────────────────────────────────────────── */

	/**
	 * Le même document, en flux ESC/POS pour une imprimante de caisse.
	 *
	 * On réutilise le pilote existant (FKC_PosImpression) plutôt que d'en
	 * écrire un second : les accents translittérés, la largeur configurable et
	 * la coupe du papier y sont déjà résolus, imprimante par imprimante.
	 *
	 * @return string|null Flux binaire, ou null si le pilote est absent.
	 */
	public static function escpos( array $doc ) {
		if ( ! class_exists( 'FKC_PosImpression' ) || ! method_exists( 'FKC_PosImpression', 'ticketLibre' ) ) { return null; }
		$em = $doc['emetteur'];
		$lignes = array();
		foreach ( (array) $doc['lignes'] as $l ) {
			$lignes[] = array(
				'libelle' => (string) $l['designation'],
				'qte'     => (float) ( $l['qte'] ?? 1 ),
				'total'   => (float) ( $l['total'] ?? 0 ),
			);
		}
		return FKC_PosImpression::ticketLibre( array(
			'titre'    => $doc['titre'],
			'numero'   => $doc['numero'],
			'date'     => $doc['date'],
			'enseigne' => $em['nom'],
			'adresse'  => trim( $em['adresse'] . ' ' . $em['ville'] ),
			'tel'      => $em['tel'],
			'lignes'   => $lignes,
			'totaux'   => (array) $doc['totaux'],
			'pied'     => (array) $doc['mentions'],
		) );
	}
}
