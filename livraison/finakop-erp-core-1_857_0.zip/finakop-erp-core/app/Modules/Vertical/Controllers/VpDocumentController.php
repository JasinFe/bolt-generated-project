<?php
/**
 * IMPRESSION DES DOCUMENTS DE LA BRIQUE VERTICALE (COM-050).
 *
 * Une route par document, toutes rendues par la même vue. Le flux ESC/POS est
 * servi en binaire, pour l'agent d'impression local qui pilote l'imprimante
 * thermique.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpDocumentController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
	}

	public function afficher( $type, $id ) {
		$doc = FKC_VpDocument::assembler( (string) $type, (int) $id, $this->cfg );
		if ( ! $doc ) {
			$_SESSION['__vp_flash'] = array( 'type' => 'err', 'msg' => 'Ce document est introuvable ou ne peut pas être édité.' );
			redirect( $this->module . '/stock' );
		}
		/*
		 * Rendu SANS layout (3e argument à null) : ces documents sont des
		 * pages autonomes, avec leur propre <html> et leurs règles
		 * @media print. Les envelopper dans la coquille de l'application
		 * imprimerait le menu latéral au milieu d'une facture.
		 */
		FKC_View::render( 'vertical.document', array(
			'title'  => $doc['titre'] . ' ' . $doc['numero'],
			'doc'    => $doc,
			'module' => $this->module,
			'retour' => $this->retourPour( (string) $type, (int) $id ),
			// Le ticket thermique n'est proposé que pour les documents qui ont
			// un sens sur 58 mm : un bon de garantie assorti de ses exclusions
			// n'est pas lisible sur un rouleau de caisse.
			'escpos' => in_array( (string) $type, array( 'vente', 'acompte' ), true )
				? $this->module . '/document/' . $type . '/' . (int) $id . '/escpos'
				: null,
		), null );
	}

	/**
	 * Flux ESC/POS brut. Servi en `application/octet-stream` : c'est l'agent
	 * d'impression local qui l'envoie au port de l'imprimante, exactement
	 * comme pour les tickets de caisse.
	 */
	public function escpos( $type, $id ) {
		$doc = FKC_VpDocument::assembler( (string) $type, (int) $id, $this->cfg );
		if ( ! $doc ) { http_response_code( 404 ); exit( 'Document introuvable.' ); }
		$flux = FKC_VpDocument::escpos( $doc );
		if ( null === $flux ) {
			http_response_code( 501 );
			exit( 'Aucun pilote d\'impression thermique n\'est disponible sur cette installation.' );
		}
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . preg_replace( '/[^A-Za-z0-9_-]/', '', $doc['numero'] ) . '.bin"' );
		header( 'Content-Length: ' . strlen( $flux ) );
		echo $flux;
		exit;
	}

	/** Où revenir après consultation — l'écran d'où l'on vient logiquement. */
	protected function retourPour( $type, $id ) {
		switch ( $type ) {
			case 'vente':        return $this->module . '/stock/mouvements';
			case 'devis':
			case 'livraison':    return $this->module . '/commandes/' . $id;
			case 'acompte':      return $this->module . '/commandes';
			case 'intervention':
			case 'garantie':     return $this->module . '/sav';
		}
		return $this->module . '/stock';
	}
}
