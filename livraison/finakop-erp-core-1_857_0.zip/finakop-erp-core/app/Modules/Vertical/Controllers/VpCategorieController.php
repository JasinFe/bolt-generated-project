<?php
/**
 * ÉCRANS DU CATALOGUE (BAZ-001) — le commerçant organise lui-même ses rayons.
 *
 * Un seul écran, volontairement : la liste EST le formulaire. Créer une
 * catégorie, la renommer, la ranger sous une autre, la désactiver ou lui
 * attacher son compte de vente se font sans quitter la page — un commerçant
 * qui réorganise son bazar enchaîne dix gestes, pas dix allers-retours.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpCategorieController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpCategorie::ensure();
		/*
		 * Semence du catalogue métier préconfiguré, puis rattrapage des
		 * articles créés avant cette brique. Les deux sont idempotents (la
		 * semence par sentinelle, le rattrapage parce qu'il ne touche que les
		 * articles encore sans catégorie), donc appelés ici sans état à tenir.
		 */
		FKC_VpCategorie::semer( (array) ( $this->cfg['stock']['categories'] ?? array() ), null, (string) ( $this->cfg['stock']['categories_origine'] ?? FKC_VpCategorie::SYSTEME ) );
		FKC_VpCategorie::rattraperArticles();
	}

	public function index() {
		FKC_View::render( 'vertical.categories', array(
			'title'   => 'Catalogue & catégories',
			'module'  => $this->module,
			'cfg'     => $this->cfg,
			'arbre'   => FKC_VpCategorie::arbre( true ),
			'racines' => FKC_VpCategorie::racines( true ),
			'compteurs' => $this->compteurs(),
			'fiscales'  => $this->fiscales(),
			'flash'   => $this->flash(),
		) );
	}

	public function store() {
		list( $ok, $msg ) = FKC_VpCategorie::creer( $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/categories' );
	}

	public function update( $id ) {
		list( $ok, $msg ) = FKC_VpCategorie::modifier( (int) $id, $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/categories' );
	}

	public function toggle( $id ) {
		list( $ok, $msg ) = FKC_VpCategorie::basculer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/categories' );
	}

	public function destroy( $id ) {
		list( $ok, $msg ) = FKC_VpCategorie::supprimer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/categories' );
	}

	/** Nombre d'articles par catégorie — affiché avant toute suppression. */
	protected function compteurs() {
		$out = array();
		foreach ( FKC_VpCategorie::toutes( true ) as $c ) {
			$out[ (int) $c['id'] ] = FKC_VpCategorie::compteArticles( (int) $c['id'] );
		}
		return $out;
	}

	/** Catégories fiscales paramétrables (COM-001), pour l'héritage par rayon. */
	protected function fiscales() {
		if ( ! class_exists( 'FKC_CategorieFiscale' ) ) { return array(); }
		try {
			$out = array();
			foreach ( FKC_CategorieFiscale::categories( true ) as $c ) {
				$out[ (int) $c['id'] ] = $c['libelle'] . ' — ' . fkc_money( $c['taux'], 2 ) . ' %';
			}
			return $out;
		} catch ( \Throwable $e ) { return array(); }
	}

	protected function flashSet( $ok, $msg ) {
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
