<?php
/**
 * ÉCRANS DE L'APRÈS-VENTE (ELM-002) — garanties et interventions.
 *
 * Un seul écran de liste, avec les interventions en cours en tête : un
 * magasin ne consulte pas son SAV pour l'archiver, il le consulte pour
 * savoir qui attend encore son appareil.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpApresVenteController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpApresVente::ensure();
	}

	public function index() {
		FKC_View::render( 'vertical.sav', array(
			'title'      => 'Après-vente',
			'module'     => $this->module,
			'cfg'        => $this->cfg,
			'ouvertes'   => $this->ouvertes(),
			'closes'     => array_slice( FKC_VpApresVente::interventions( 'cloturee' ), 0, 20 ),
			'echeances'  => FKC_VpApresVente::echeances( 60 ),
			'compteurs'  => FKC_VpApresVente::compteurs(),
			'types'      => FKC_VpApresVente::typesIntervention(),
			'statuts'    => FKC_VpApresVente::statuts(),
			'articles'   => FKC_VpStock::articles(),
			'clients'    => class_exists( 'FKC_Client' ) ? FKC_Client::all( true ) : array(),
			'flash'      => $this->flash(),
		) );
	}

	public function store() {
		list( $ok, $msg ) = FKC_VpApresVente::ouvrirIntervention( $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/sav' );
	}

	public function statut( $id ) {
		list( $ok, $msg ) = FKC_VpApresVente::changerStatut(
			(int) $id, (string) ( $_POST['statut'] ?? '' ),
			$_POST['date_prevue'] ?? null, $_POST['technicien'] ?? null
		);
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/sav' );
	}

	public function piece( $id ) {
		list( $ok, $msg ) = FKC_VpApresVente::consommerPiece(
			(int) $id, (int) ( $_POST['article_id'] ?? 0 ), (float) ( $_POST['qte'] ?? 0 ),
			$this->cfg, '' !== ( $_POST['pu'] ?? '' ) ? (float) $_POST['pu'] : null
		);
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/sav' );
	}

	public function cloturer( $id ) {
		list( $ok, $msg ) = FKC_VpApresVente::cloturer(
			(int) $id, $this->cfg, (float) ( $_POST['main_oeuvre'] ?? 0 ), ! empty( $_POST['forcer_encours'] )
		);
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/sav' );
	}

	public function annuler( $id ) {
		list( $ok, $msg ) = FKC_VpApresVente::annuler( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/sav' );
	}

	public function garantie() {
		list( $ok, $msg ) = FKC_VpApresVente::ouvrirGarantie( $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/sav' );
	}

	/** Tout ce qui n'est ni clôturé ni annulé, dans l'ordre où ça presse. */
	protected function ouvertes() {
		$out = array();
		foreach ( array( 'en_cours', 'planifiee', 'ouverte' ) as $s ) {
			foreach ( FKC_VpApresVente::interventions( $s ) as $i ) { $out[] = $i; }
		}
		return $out;
	}

	protected function flashSet( $ok, $msg ) {
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
