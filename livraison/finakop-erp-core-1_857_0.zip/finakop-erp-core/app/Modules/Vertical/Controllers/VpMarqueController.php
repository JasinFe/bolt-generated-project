<?php
/**
 * ÉCRAN DES MARQUES (ELM-004).
 *
 * Un référentiel court, qu'on consulte rarement et qu'on complète au fil des
 * arrivages : la liste EST le formulaire, comme pour le catalogue.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpMarqueController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpMarque::ensure();
		// Raccroche les libellés hérités ou importés — idempotent.
		FKC_VpMarque::rattraperArticles();
	}

	public function index() {
		$rows = FKC_VpMarque::toutes( true );
		$compteurs = array();
		foreach ( $rows as $m ) { $compteurs[ (int) $m['id'] ] = FKC_VpMarque::compteArticles( (int) $m['id'] ); }
		FKC_View::render( 'vertical.marques', array(
			'title'     => 'Marques',
			'module'    => $this->module,
			'cfg'       => $this->cfg,
			'rows'      => $rows,
			'compteurs' => $compteurs,
			'caMois'    => FKC_VpMarque::caParMarque(),
			'flash'     => $this->flash(),
		) );
	}

	public function store() {
		list( $ok, $msg ) = FKC_VpMarque::creer( $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/marques' );
	}

	public function update( $id ) {
		list( $ok, $msg ) = FKC_VpMarque::modifier( (int) $id, $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/marques' );
	}

	public function toggle( $id ) {
		list( $ok, $msg ) = FKC_VpMarque::basculer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/marques' );
	}

	public function destroy( $id ) {
		list( $ok, $msg ) = FKC_VpMarque::supprimer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/marques' );
	}

	/* ── Associations d'articles (ELM-005) ────────────────────────────────── */

	public function lier( $articleId ) {
		list( $ok, $msg ) = FKC_VpArticleLie::lier(
			(int) $articleId,
			(int) ( $_POST['lie_id'] ?? 0 ),
			(string) ( $_POST['type'] ?? 'accessoire' ),
			$_POST
		);
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/stock/article/' . (int) $articleId . '/modifier' );
	}

	public function delier( $articleId, $id ) {
		list( $ok, $msg ) = FKC_VpArticleLie::delier( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/stock/article/' . (int) $articleId . '/modifier' );
	}

	protected function flashSet( $ok, $msg ) {
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
