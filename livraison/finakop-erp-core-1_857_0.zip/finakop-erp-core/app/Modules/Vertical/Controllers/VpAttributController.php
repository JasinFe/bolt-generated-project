<?php
/**
 * ÉCRAN DES CARACTÉRISTIQUES PRODUIT (BAZ-002).
 *
 * Le commerçant décide ici de ce qu'il veut pouvoir écrire sur ses fiches :
 * la matière d'un tissu, la densité d'une mousse, la classe énergétique d'un
 * climatiseur. Chaque caractéristique s'applique à tout le catalogue, ou à un
 * rayon précis — et alors aussi à ses sous-rayons.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpAttributController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpAttribut::ensure();
		if ( class_exists( 'FKC_VpCategorie' ) ) {
			FKC_VpCategorie::ensure();
			FKC_VpCategorie::semer( (array) ( $this->cfg['stock']['categories'] ?? array() ), null, (string) ( $this->cfg['stock']['categories_origine'] ?? FKC_VpCategorie::SYSTEME ) );
		}
	}

	public function index() {
		$rows = FKC_VpAttribut::tous( true );
		$compteurs = array();
		foreach ( $rows as $a ) { $compteurs[ (int) $a['id'] ] = FKC_VpAttribut::compteValeurs( (int) $a['id'] ); }
		FKC_View::render( 'vertical.attributs', array(
			'title'      => 'Caractéristiques produit',
			'module'     => $this->module,
			'cfg'        => $this->cfg,
			'rows'       => $rows,
			'compteurs'  => $compteurs,
			'types'      => FKC_VpAttribut::types(),
			'categories' => class_exists( 'FKC_VpCategorie' ) ? FKC_VpCategorie::options( true ) : array(),
			'flash'      => $this->flash(),
		) );
	}

	public function store() {
		list( $ok, $msg ) = FKC_VpAttribut::creer( $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/attributs' );
	}

	public function update( $id ) {
		list( $ok, $msg ) = FKC_VpAttribut::modifier( (int) $id, $_POST );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/attributs' );
	}

	public function toggle( $id ) {
		list( $ok, $msg ) = FKC_VpAttribut::basculer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/attributs' );
	}

	public function destroy( $id ) {
		list( $ok, $msg ) = FKC_VpAttribut::supprimer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/attributs' );
	}

	protected function flashSet( $ok, $msg ) {
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
