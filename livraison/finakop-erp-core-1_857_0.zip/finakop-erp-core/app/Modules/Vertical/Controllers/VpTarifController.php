<?php
/**
 * ÉCRAN DES TARIFS D'UN ARTICLE (BAZ-003).
 *
 * Un écran par article, et non une grille globale : le commerçant y arrive
 * depuis la fiche, en pensant à CE produit. Une matrice « tous les articles ×
 * tous les niveaux » serait impraticable dès le trois-centième article — et un
 * bazar en compte davantage.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpTarifController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpTarif::ensure();
	}

	public function index( $articleId ) {
		$a = FKC_VpStock::article( $articleId );
		if ( ! $a ) { redirect( $this->module . '/stock' ); }
		FKC_View::render( 'vertical.tarifs', array(
			'title'    => 'Tarifs — ' . $a['libelle'],
			'module'   => $this->module,
			'cfg'      => $this->cfg,
			'article'  => $a,
			'tarifs'   => FKC_VpTarif::pourArticle( (int) $a['id'], true ),
			'niveaux'  => $this->niveauxOfferts(),
			'clients'  => $this->clients(),
			'modes'    => FKC_VpTarif::modesOfferts( $this->cfg ),
			'modesActifs' => FKC_VpTarif::modesActifs( $a ),
			'simulation' => $this->simulation( $a ),
			'flash'    => $this->flash(),
		) );
	}

	public function store( $articleId ) {
		$d = $_POST;
		$d['article_id'] = (int) $articleId;
		list( $ok, $msg ) = FKC_VpTarif::creer( $d );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/stock/article/' . (int) $articleId . '/tarifs' );
	}

	public function destroy( $articleId, $id ) {
		list( $ok, $msg ) = FKC_VpTarif::supprimer( (int) $id );
		$this->flashSet( $ok, $msg );
		redirect( $this->module . '/stock/article/' . (int) $articleId . '/tarifs' );
	}

	public function modes( $articleId ) {
		$demandes = isset( $_POST['modes'] ) && is_array( $_POST['modes'] ) ? $_POST['modes'] : array();
		list( $ok, $msg ) = FKC_VpTarif::definirModes( (int) $articleId, $demandes, $this->cfg );
		$this->flashSet( $ok, $ok ? ( 'Modes de vente enregistrés.' . ( $msg ? ' ' . $msg : '' ) ) : $msg );
		redirect( $this->module . '/stock/article/' . (int) $articleId . '/tarifs' );
	}

	/**
	 * Ce que donnerait la grille pour quelques quantités courantes. Une grille
	 * à paliers est facile à écrire et difficile à relire : montrer le prix
	 * effectif à 1, 10, 50 et 100 évite de découvrir au comptoir qu'un palier
	 * ne se déclenche jamais.
	 */
	protected function simulation( array $a ) {
		$out = array();
		foreach ( array( 1, 10, 50, 100 ) as $q ) {
			$r = FKC_VpTarif::resoudre( $a, $q );
			$out[ $q ] = $r;
		}
		return $out;
	}

	protected function niveauxOfferts() {
		$decl = $this->cfg['tarifs']['niveaux'] ?? null;
		if ( ! is_array( $decl ) || ! $decl ) { return FKC_VpTarif::niveaux(); }
		$out = array();
		foreach ( $decl as $n ) {
			if ( FKC_VpTarif::niveauValide( $n ) ) { $out[ $n ] = FKC_VpTarif::niveaux()[ $n ]; }
		}
		return $out ?: FKC_VpTarif::niveaux();
	}

	/** Clients connus, pour les prix nominatifs. */
	protected function clients() {
		if ( ! class_exists( 'FKC_Client' ) ) { return array(); }
		try {
			$out = array();
			foreach ( (array) FKC_Client::all( true ) as $c ) { $out[ (int) $c['id'] ] = (string) $c['nom']; }
			return $out;
		} catch ( \Throwable $e ) { return array(); }
	}

	protected function flashSet( $ok, $msg ) {
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
