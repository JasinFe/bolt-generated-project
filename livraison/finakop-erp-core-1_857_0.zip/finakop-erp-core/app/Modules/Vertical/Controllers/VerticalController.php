<?php
/**
 * Écrans génériques des packs déclaratifs (moteur vertical) : tableau de bord,
 * dossiers et pièces. La terminologie (FKC_Term) et le bloc « vertical » du
 * manifest pilotent tout : un pack métier n'a AUCUN écran à écrire.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VerticalController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		FKC_VpDossier::ensure();
	}

	public function dashboard() {
		$u = class_exists( 'FKC_Auth' ) ? FKC_Auth::user() : null;
		if ( class_exists( 'FKC_Warehouse' ) ) { FKC_Warehouse::capturer(); }
		FKC_View::render( 'vertical.dashboard', array(
			'title' => FKC_Term::t( 'objets', 'Dossiers' ), 'module' => $this->module, 'cfg' => $this->cfg,
			'kpi'   => FKC_VpDossier::kpi(),
			'rows'  => FKC_VpDossier::all(),
			'briefing' => class_exists( 'FKC_Assistant' ) ? FKC_Assistant::briefing( $u['nom_complet'] ?? '' ) : null,
			'flash' => $this->flash(),
			'commerce' => $this->syntheseCommerce(),
		) );
	}

	/**
	 * VENTES & STOCK SUR LE TABLEAU DE BORD (1.857.0).
	 *
	 * Le tableau de bord d'un pack de commerce ne lisait que les PIÈCES du
	 * dossier (encaissements divers) : les ventes au comptoir, qui passent
	 * par le stock, n'y apparaissaient jamais — « Ventes électroménager :
	 * 0 F » un jour de soldes. Pour un pack à stock, on y ajoute ce que le
	 * commerçant regarde en premier : ventes du jour et du mois, marge, valeur
	 * du stock (rapprochée de la comptabilité), commandes à livrer, SAV.
	 */
	protected function syntheseCommerce() {
		if ( empty( $this->cfg['stock'] ) || ! class_exists( 'FKC_VpStockPilotage' ) ) { return null; }
		try {
			$s = FKC_VpStockPilotage::synthese();
			$m = FKC_VpStockPilotage::margeMois();
			$out = array(
				'ca_jour' => $s['ca_jour'], 'ca_mois' => $s['ca_mois'], 'marge' => $m['marge'], 'taux' => $m['taux'],
				'stock_valeur' => $s['stock_valeur'], 'alertes' => $s['alertes_stock'],
				'rapprochement' => FKC_VpStock::rapprochementComptable(),
				'a_livrer' => 0, 'sav' => null, 'perimes' => null,
			);
			if ( class_exists( 'FKC_VpCommande' ) ) {
				FKC_VpCommande::ensure();
				$out['a_livrer'] = (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_commandes WHERE pack=? AND statut IN ('confirmee','livree_partielle')",
					array( FKC_VpStock::pack() ) )->fetchColumn();
			}
			$offertes = class_exists( 'FKC_VpCapacite' ) ? FKC_VpCapacite::offertes( $this->cfg ) : array();
			if ( in_array( 'sav', $offertes, true ) && class_exists( 'FKC_VpApresVente' ) ) {
				$out['sav'] = (int) FKC_VpApresVente::compteurs()['ouvertes'];
			}
			if ( in_array( 'peremption', $offertes, true ) && class_exists( 'FKC_VpLot' ) ) {
				$l = FKC_VpLot::compteurs();
				$out['perimes'] = array( 'perimes' => (int) $l['perimes'], 'proches' => (int) $l['proches'] );
			}
			return $out;
		} catch ( \Throwable $e ) { return null; }
	}

	/* ── Écrans de Business Intelligence (génériques, pilotés par hooks.php) ── */

	/** Le pack a-t-il branché des indicateurs sur les socles ? */
	protected function aBI() {
		return class_exists( 'FKC_Pilotage2' ) && FKC_Pilotage2::aDesKpis();
	}

	public function pilotage() {
		// Planificateur : évalue les règles du pack ET celles créées par
		// l'utilisateur, au plus une fois par intervalle (pas de spam, pas de
		// recalcul à chaque rafraîchissement d'écran).
		if ( class_exists( 'FKC_AutomationRules' ) ) {
			FKC_AutomationRules::tick( 30 );
		} elseif ( class_exists( 'FKC_Automation' ) ) {
			FKC_Automation::evaluer( true );
		}
		if ( class_exists( 'FKC_Warehouse' ) ) { FKC_Warehouse::capturer(); }
		FKC_View::render( 'vertical.pilotage', array(
			'title' => 'Centre de Pilotage', 'module' => $this->module, 'cfg' => $this->cfg,
			'kpisParCat' => FKC_Pilotage2::kpisParCategorie(),
			'score' => FKC_Pilotage2::score(),
			'alertes' => FKC_Pilotage2::alertes(),
			'compteurs' => FKC_Pilotage2::compteurs(),
			'flash' => $this->flash(),
		) );
	}

	public function assistant() {
		$u = class_exists( 'FKC_Auth' ) ? FKC_Auth::user() : null;
		FKC_View::render( 'vertical.assistant', array(
			'title' => 'Assistant', 'module' => $this->module, 'cfg' => $this->cfg,
			'briefing' => FKC_Assistant::briefing( $u['nom_complet'] ?? '' ),
			'flash' => $this->flash(),
		) );
	}

	public function rapports() {
		FKC_View::render( 'vertical.rapports', array(
			'title' => 'Rapports graphiques', 'module' => $this->module, 'cfg' => $this->cfg,
			'parCategorie' => class_exists( 'FKC_Reports' ) ? FKC_Reports::parCategorie() : array(),
			'flash' => $this->flash(),
		) );
	}

	public function previsions() {
		FKC_View::render( 'vertical.previsions', array(
			'title' => 'Prévisions', 'module' => $this->module, 'cfg' => $this->cfg,
			'parCategorie' => class_exists( 'FKC_Forecast' ) ? FKC_Forecast::parCategorie() : array(),
			'runRate' => null, 'cumulMois' => 0, 'magasin' => null,
			'flash' => $this->flash(),
		) );
	}

	public function scenarios() {
		$scn = class_exists( 'FKC_Scenario' ) ? FKC_Scenario::scenarios() : array();
		$cle = $scn ? array_key_first( $scn ) : null;
		$aj = array();
		if ( $cle ) {
			foreach ( array_keys( FKC_Scenario::leviers( $cle ) ) as $lk ) {
				if ( isset( $_GET[ $lk ] ) && '' !== $_GET[ $lk ] ) { $aj[ $lk ] = (float) $_GET[ $lk ]; }
			}
		}
		FKC_View::render( 'vertical.scenarios', array(
			'title' => 'Scénarios', 'module' => $this->module, 'cfg' => $this->cfg,
			'cle' => $cle,
			'libelle' => $cle ? ( FKC_Scenario::get( $cle )['libelle'] ?? 'Scénario' ) : '',
			'leviers' => $cle ? FKC_Scenario::leviers( $cle ) : array(),
			'sorties' => $cle ? FKC_Scenario::sorties( $cle ) : array(),
			'base' => $cle ? FKC_Scenario::base( $cle ) : array(),
			'preregles' => $cle ? FKC_Scenario::preregles( $cle ) : array(),
			'simulation' => ( $cle && $aj ) ? FKC_Scenario::simuler( $cle, $aj ) : null,
			'ajustements' => $aj, 'magasin' => null,
			'flash' => $this->flash(),
		) );
	}

	/** Personnalisation du cockpit : cibles, visibilité, ordre des KPI + KPI personnalisés. */
	public function personnaliser() {
		FKC_View::render( 'vertical.personnaliser', array(
			'title' => 'Personnaliser le cockpit', 'module' => $this->module, 'cfg' => $this->cfg,
			'catalogue' => FKC_Pilotage2::catalogueKpis(),
			'prefs' => class_exists( 'FKC_PilotagePrefs' ) ? FKC_PilotagePrefs::all() : array(),
			'kpisPerso' => class_exists( 'FKC_PilotagePrefs' ) ? FKC_PilotagePrefs::kpisPerso( true ) : array(),
			'metriques' => class_exists( 'FKC_Metrics' ) ? FKC_Metrics::registre() : array(),
			'operations' => class_exists( 'FKC_PilotagePrefs' ) ? FKC_PilotagePrefs::operations() : array(),
			'flash' => $this->flash(),
		) );
	}

	public function personnaliserSave() {
		if ( class_exists( 'FKC_PilotagePrefs' ) ) {
			if ( ! empty( $_POST['reinit'] ) ) {
				FKC_PilotagePrefs::reinitialiser();
				$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Cockpit réinitialisé aux réglages d\'usine.' );
				return redirect( $this->module . '/personnaliser' );
			}
			// Création / modification / suppression d'un KPI personnalisé.
			$action = $_POST['kpi_action'] ?? '';
			if ( 'creer' === $action || 'maj' === $action ) {
				$d = array(
					'libelle' => $_POST['kpi_libelle'] ?? '', 'metric' => $_POST['kpi_metric'] ?? '',
					'operation' => $_POST['kpi_operation'] ?? 'valeur',
					'operande' => $_POST['kpi_operande'] ?? null, 'metric2' => $_POST['kpi_metric2'] ?? null,
					'cible' => $_POST['kpi_cible'] ?? null, 'sens' => $_POST['kpi_sens'] ?? 'hausse',
					'unite' => $_POST['kpi_unite'] ?? '', 'format' => $_POST['kpi_format'] ?? 'nombre',
					'categorie' => $_POST['kpi_categorie'] ?? 'Mes indicateurs', 'icone' => $_POST['kpi_icone'] ?? '⭐',
				);
				$ok = 'creer' === $action ? FKC_PilotagePrefs::creerKpi( $d ) : FKC_PilotagePrefs::majKpi( (int) ( $_POST['kpi_id'] ?? 0 ), $d );
				$_SESSION['__vp_flash'] = $ok
					? array( 'type' => 'ok', 'msg' => 'creer' === $action ? 'Indicateur personnalisé créé.' : 'Indicateur personnalisé mis à jour.' )
					: array( 'type' => 'err', 'msg' => 'Indicateur incomplet : un libellé et une métrique sont requis.' );
				return redirect( $this->module . '/personnaliser' );
			}
			if ( 'supprimer' === $action ) {
				FKC_PilotagePrefs::supprimerKpi( (int) ( $_POST['kpi_id'] ?? 0 ) );
				$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Indicateur personnalisé supprimé.' );
				return redirect( $this->module . '/personnaliser' );
			}
			// Enregistrement des réglages (cibles / visibilité / ordre) — KPI pack + perso.
			$ordre = 10;
			$cles = array_keys( FKC_Pilotage2::catalogueKpis() );
			foreach ( FKC_PilotagePrefs::kpisPerso( true ) as $kp ) { $cles[] = FKC_PilotagePrefs::clePerso( $kp['id'] ); }
			foreach ( $cles as $cle ) {
				$visible = ! empty( $_POST['visible'][ $cle ] ) ? 1 : 0;
				$cible = isset( $_POST['cible'][ $cle ] ) && '' !== trim( (string) $_POST['cible'][ $cle ] ) ? (float) str_replace( array( ' ', ',' ), array( '', '.' ), $_POST['cible'][ $cle ] ) : null;
				FKC_PilotagePrefs::set( $cle, $visible, $cible, $ordre );
				$ordre += 10;
			}
			$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Cockpit personnalisé enregistré.' );
		}
		redirect( $this->module . '/personnaliser' );
	}

	public function dossiers() {
		FKC_View::render( 'vertical.dossiers', array(
			'title' => FKC_Term::t( 'objets', 'Dossiers' ), 'module' => $this->module, 'cfg' => $this->cfg,
			'rows'  => FKC_VpDossier::all(),
			'flash' => $this->flash(),
		) );
	}

	public function create() {
		FKC_View::render( 'vertical.dossier_form', array(
			'title' => FKC_Term::t( 'objet_new', 'Nouveau dossier' ), 'module' => $this->module, 'cfg' => $this->cfg,
			'row'   => null, 'code' => FKC_VpDossier::nextCode( $this->cfg['prefixe'] ?? 'DOS' ),
			'clients' => $this->clients(),
		) );
	}

	public function store() {
		list( $ok, $msg, $id ) = FKC_VpDossier::create( $_POST, $this->cfg );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $ok ? $this->module . '/dossiers/' . (int) $id : $this->module . '/dossiers/nouveau' );
	}

	public function show( $id ) {
		$d = FKC_VpDossier::find( $id );
		if ( ! $d ) { redirect( $this->module . '/dossiers' ); }
		$pieces  = FKC_VpPiece::duDossier( $id );
		$actions = array();
		foreach ( $pieces as $p ) {
			if ( empty( $p['wf_instance_id'] ) ) { continue; }
			$i = FKC_WorkflowEngine::instance( (int) $p['wf_instance_id'] );
			if ( $i ) { $actions[ (int) $p['id'] ] = FKC_WorkflowEngine::actionsDisponibles( $i ); }
		}
		FKC_View::render( 'vertical.dossier_show', array(
			'title' => $d['code'] . ' — ' . $d['libelle'], 'module' => $this->module, 'cfg' => $this->cfg,
			'row'   => $d, 'pieces' => $pieces, 'actions' => $actions,
			'cumul' => FKC_VpDossier::cumulFacture( $id ),
			'flash' => $this->flash(),
		) );
	}

	public function edit( $id ) {
		$d = FKC_VpDossier::find( $id );
		if ( ! $d ) { redirect( $this->module . '/dossiers' ); }
		FKC_View::render( 'vertical.dossier_form', array(
			'title' => 'Modifier — ' . $d['libelle'], 'module' => $this->module, 'cfg' => $this->cfg,
			'row'   => $d, 'code' => $d['code'], 'clients' => $this->clients(),
		) );
	}

	public function update( $id ) {
		list( $ok, $msg ) = FKC_VpDossier::update( (int) $id, $_POST, $this->cfg );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/dossiers/' . (int) $id );
	}

	/* ── Pièces ──────────────────────────────────────────────────────────── */

	public function pieces() {
		FKC_View::render( 'vertical.pieces', array(
			'title' => FKC_Term::t( 'pieces', 'Pièces' ), 'module' => $this->module, 'cfg' => $this->cfg,
			'rows'  => FKC_VpPiece::recentes(),
			'flash' => $this->flash(),
		) );
	}

	public function pieceCreate( $dossierId ) {
		$d = FKC_VpDossier::find( $dossierId );
		if ( ! $d ) { redirect( $this->module . '/dossiers' ); }
		FKC_View::render( 'vertical.piece_form', array(
			'title' => FKC_Term::t( 'piece', 'Nouvelle pièce' ) . ' — ' . $d['libelle'],
			'module' => $this->module, 'cfg' => $this->cfg, 'dossier' => $d,
		) );
	}

	public function pieceStore( $dossierId ) {
		list( $ok, $msg, $id ) = FKC_VpPiece::create( (int) $dossierId, $_POST, $this->cfg );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $ok ? $this->module . '/dossiers/' . (int) $dossierId : $this->module . '/dossiers/' . (int) $dossierId . '/pieces/nouvelle' );
	}

	/** Action du processus de validation (soumettre / valider / rejeter / reprendre). */
	public function pieceAction( $id ) {
		$p = FKC_VpPiece::find( $id );
		if ( ! $p ) { redirect( $this->module . '/dossiers' ); }
		if ( empty( $p['wf_instance_id'] ) ) {
			$wid = FKC_WorkflowEngine::start( FKC_VpDossier::pack() . '_validation_piece', 'vp.piece', (int) $id, FKC_VpPiece::contexte( $p, $this->cfg ) );
			FKC_DB::q( 'UPDATE vp_pieces SET wf_instance_id=? WHERE id=?', array( $wid, (int) $id ) );
			$p['wf_instance_id'] = $wid;
		}
		list( $ok, $msg ) = FKC_WorkflowEngine::transition( (int) $p['wf_instance_id'], (string) ( $_POST['action'] ?? '' ), trim( (string) ( $_POST['commentaire'] ?? '' ) ) );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/dossiers/' . (int) $p['dossier_id'] );
	}

	/* ── Utilitaires ─────────────────────────────────────────────────────── */

	protected function clients() {
		try { return FKC_DB::q( 'SELECT id, nom FROM clients ORDER BY nom ASC' )->fetchAll(); }
		catch ( \Throwable $e ) { return array(); }
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}

	/* ── Automation Engine : règles métier configurables SANS CODE ────────── */

	/**
	 * Écran « Automatisations » : le dirigeant compose ses propres règles
	 * (SI <indicateur> <opérateur> <seuil> ALORS <actions>) sans écrire une
	 * ligne de code. Les règles sont évaluées par le même moteur que celles
	 * des packs — cooldown, journal et actions identiques.
	 */
	public function automatisations() {
		if ( ! class_exists( 'FKC_AutomationRules' ) ) { return redirect( $this->module ); }
		FKC_AutomationRules::injecter();

		// Aperçu en direct des règles utilisateur : se déclencheraient-elles maintenant ?
		$regles = FKC_AutomationRules::toutes();
		foreach ( $regles as &$r ) {
			$a = FKC_AutomationRules::apercuRegle( $r['source'], $r['operateur'], $r['seuil'] );
			$r['_valeur']    = $a['valeur'];
			$r['_declenche'] = $a['declenche'];
		}
		unset( $r );

		FKC_View::render( 'vertical.automatisations', array(
			'title'    => 'Automatisations', 'module' => $this->module, 'cfg' => $this->cfg,
			'regles'   => $regles,
			'sources'  => FKC_AutomationRules::sources(),
			'handlers' => FKC_AutomationRules::handlersDeclares(),
			'reglesPack' => class_exists( 'FKC_Automation' ) ? FKC_Automation::regles() : array(),
			'journal'  => class_exists( 'FKC_Automation' ) ? FKC_Automation::journal( 15 ) : array(),
			'flash'    => $this->flash(),
		) );
	}

	/** Enregistrement d'une règle (création, modification, activation, suppression). */
	public function automatisationsSave() {
		if ( ! class_exists( 'FKC_AutomationRules' ) ) { return redirect( $this->module ); }
		$action = $_POST['action'] ?? '';
		$id     = (int) ( $_POST['id'] ?? 0 );

		try {
			if ( 'supprimer' === $action && $id ) {
				FKC_AutomationRules::supprimer( $id );
				$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Règle supprimée.' );
			} elseif ( 'basculer' === $action && $id ) {
				FKC_AutomationRules::basculer( $id );
				$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Règle mise à jour.' );
			} elseif ( 'evaluer' === $action ) {
				// Exécution immédiate à la demande (« Tester maintenant »).
				FKC_AutomationRules::injecter();
				$d = FKC_Automation::evaluer( true );
				$_SESSION['__vp_flash'] = array( 'type' => 'ok',
					'msg' => $d ? ( count( $d ) . ' règle(s) déclenchée(s) : consultez vos notifications.' )
					            : 'Aucune règle déclenchée : tous les seuils sont respectés.' );
			} elseif ( 'creer' === $action || 'maj' === $action ) {
				$d = array(
					'libelle'   => $_POST['libelle'] ?? '',
					'source'    => $_POST['source'] ?? '',
					'operateur' => $_POST['operateur'] ?? '<',
					'seuil'     => $_POST['seuil'] ?? 0,
					'niveau'    => $_POST['niveau'] ?? 'warn',
					'message'   => $_POST['message'] ?? '',
					'actions'   => (array) ( $_POST['actions'] ?? array( 'notifier_admins' ) ),
					'cooldown'  => $_POST['cooldown'] ?? 720,
					'categorie' => $_POST['categorie'] ?? 'Mes règles',
					'actif'     => isset( $_POST['actif'] ) ? 1 : 0,
				);
				if ( '' === trim( (string) $d['libelle'] ) ) {
					$_SESSION['__vp_flash'] = array( 'type' => 'err', 'msg' => 'Donnez un nom à votre règle.' );
				} elseif ( 'creer' === $action ) {
					FKC_AutomationRules::creer( $d );
					$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Règle créée : elle sera évaluée automatiquement.' );
				} else {
					FKC_AutomationRules::modifier( $id, $d );
					$_SESSION['__vp_flash'] = array( 'type' => 'ok', 'msg' => 'Règle modifiée.' );
				}
			}
		} catch ( \Throwable $e ) {
			$_SESSION['__vp_flash'] = array( 'type' => 'err', 'msg' => 'Enregistrement impossible : ' . $e->getMessage() );
		}
		return redirect( $this->module . '/automatisations' );
	}
}
