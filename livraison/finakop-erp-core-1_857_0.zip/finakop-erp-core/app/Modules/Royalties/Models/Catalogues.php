<?php
/** Modèles légers : Merchandising, Studio, Publishing, Marketing, CRM, Distribution. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Merch {
	public static function types() { return array( 'cd'=>'CD','usb'=>'Clé USB','tshirt'=>'T-shirt','casquette'=>'Casquette','autre'=>'Autre' ); }
	public static function all() {
		return FKC_DB::q( 'SELECT m.*, (SELECT COALESCE(SUM(quantite),0) FROM lbl_merch_ventes v WHERE v.merch_id=m.id) vendus,
			(SELECT COALESCE(SUM(quantite*pu),0) FROM lbl_merch_ventes v WHERE v.merch_id=m.id) ca FROM lbl_merch m ORDER BY m.libelle' )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_merch(code,libelle,type,prix_achat,prix_vente,stock) VALUES(?,?,?,?,?,?)',
			array( trim( (string) ( $d['code'] ?? '' ) ) ?: null, trim( (string) $d['libelle'] ),
				isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'autre',
				(float) ( $d['prix_achat'] ?? 0 ), (float) ( $d['prix_vente'] ?? 0 ), (float) ( $d['stock'] ?? 0 ) ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function vendre( $merchId, $qte, $pu ) {
		FKC_DB::q( 'INSERT INTO lbl_merch_ventes(merch_id,quantite,pu,date) VALUES(?,?,?,?)', array( (int) $merchId, (float) $qte, (float) $pu, date( 'Y-m-d' ) ) );
		FKC_DB::q( 'UPDATE lbl_merch SET stock=MAX(0,stock-?) WHERE id=?', array( (float) $qte, (int) $merchId ) );
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_merch_ventes WHERE merch_id=?', array( (int) $id ) ); FKC_DB::q( 'DELETE FROM lbl_merch WHERE id=?', array( (int) $id ) ); }
	public static function caTotal() { return (float) FKC_DB::q( 'SELECT COALESCE(SUM(quantite*pu),0) FROM lbl_merch_ventes' )->fetchColumn(); }
}

class FKC_Studio {
	public static function all() {
		return FKC_DB::q( 'SELECT s.*, o.titre oeuvre, a.nom_scene, (s.cout_enregistrement+s.cout_mix+s.cout_mastering) cout_total
			FROM lbl_studio s LEFT JOIN lbl_oeuvres o ON o.id=s.oeuvre_id LEFT JOIN lbl_artistes a ON a.id=s.artiste_id ORDER BY s.date DESC, s.id DESC' )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_studio(date,studio,oeuvre_id,artiste_id,beatmaker,ingenieur,cout_enregistrement,cout_mix,cout_mastering,note) VALUES(?,?,?,?,?,?,?,?,?,?)',
			array( trim( (string) ( $d['date'] ?? '' ) ) ?: null, trim( (string) ( $d['studio'] ?? '' ) ) ?: null,
				! empty( $d['oeuvre_id'] ) ? (int) $d['oeuvre_id'] : null, ! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null,
				trim( (string) ( $d['beatmaker'] ?? '' ) ) ?: null, trim( (string) ( $d['ingenieur'] ?? '' ) ) ?: null,
				(float) ( $d['cout_enregistrement'] ?? 0 ), (float) ( $d['cout_mix'] ?? 0 ), (float) ( $d['cout_mastering'] ?? 0 ), trim( (string) ( $d['note'] ?? '' ) ) ?: null ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_studio WHERE id=?', array( (int) $id ) ); }
}

class FKC_Publishing {
	public static function organismes() { return array( 'sacem'=>'SACEM','burida'=>'BURIDA','autre'=>'Autre' ); }
	public static function all() {
		return FKC_DB::q( 'SELECT p.*, o.titre oeuvre FROM lbl_publishing p LEFT JOIN lbl_oeuvres o ON o.id=p.oeuvre_id ORDER BY p.id DESC' )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_publishing(oeuvre_id,auteur,compositeur,coauteur,part,organisme) VALUES(?,?,?,?,?,?)',
			array( ! empty( $d['oeuvre_id'] ) ? (int) $d['oeuvre_id'] : null, trim( (string) ( $d['auteur'] ?? '' ) ) ?: null,
				trim( (string) ( $d['compositeur'] ?? '' ) ) ?: null, trim( (string) ( $d['coauteur'] ?? '' ) ) ?: null,
				(float) ( $d['part'] ?? 0 ), isset( self::organismes()[ $d['organisme'] ?? '' ] ) ? $d['organisme'] : 'burida' ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_publishing WHERE id=?', array( (int) $id ) ); }
}

class FKC_Marketing {
	public static function plateformes() { return array( 'facebook'=>'Facebook','instagram'=>'Instagram','tiktok'=>'TikTok','google'=>'Google','youtube'=>'YouTube','autre'=>'Autre' ); }
	public static function all() {
		return FKC_DB::q( 'SELECT m.*, a.nom_scene FROM lbl_marketing m LEFT JOIN lbl_artistes a ON a.id=m.artiste_id ORDER BY m.date DESC, m.id DESC' )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_marketing(campagne,plateforme,budget,streams,conversions,date,artiste_id) VALUES(?,?,?,?,?,?,?)',
			array( trim( (string) $d['campagne'] ), isset( self::plateformes()[ $d['plateforme'] ?? '' ] ) ? $d['plateforme'] : 'autre',
				(float) ( $d['budget'] ?? 0 ), (int) ( $d['streams'] ?? 0 ), (int) ( $d['conversions'] ?? 0 ),
				trim( (string) ( $d['date'] ?? '' ) ) ?: null, ! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_marketing WHERE id=?', array( (int) $id ) ); }
}

class FKC_Crm {
	public static function types() { return array( 'organisateur'=>'Organisateur','sponsor'=>'Sponsor','media'=>'Média' ); }
	public static function categories() { return array( 'festival'=>'Festival','concert'=>'Concert','showcase'=>'Showcase','radio'=>'Radio','tv'=>'TV','blog'=>'Blog','autre'=>'Autre' ); }
	public static function all( $type = '' ) {
		$w = ''; $p = array(); if ( '' !== $type ) { $w = ' WHERE type=?'; $p[] = $type; }
		return FKC_DB::q( "SELECT * FROM lbl_crm{$w} ORDER BY nom", $p )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_crm(nom,type,categorie,contact,note) VALUES(?,?,?,?,?)',
			array( trim( (string) $d['nom'] ), isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'organisateur',
				trim( (string) ( $d['categorie'] ?? '' ) ) ?: null, trim( (string) ( $d['contact'] ?? '' ) ) ?: null, trim( (string) ( $d['note'] ?? '' ) ) ?: null ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_crm WHERE id=?', array( (int) $id ) ); }
}

class FKC_Release {
	public static function statuts() { return array( 'programme'=>'Programmé','publie'=>'Publié','retire'=>'Retiré' ); }
	public static function all() {
		return FKC_DB::q( 'SELECT r.*, o.titre oeuvre, a.nom_scene FROM lbl_releases r LEFT JOIN lbl_oeuvres o ON o.id=r.oeuvre_id LEFT JOIN lbl_artistes a ON a.id=o.artiste_id ORDER BY r.date_sortie DESC, r.id DESC' )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_releases(oeuvre_id,date_sortie,statut,plateformes) VALUES(?,?,?,?)',
			array( ! empty( $d['oeuvre_id'] ) ? (int) $d['oeuvre_id'] : null, trim( (string) ( $d['date_sortie'] ?? '' ) ) ?: null,
				isset( self::statuts()[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'programme',
				is_array( $d['plateformes'] ?? null ) ? implode( ', ', $d['plateformes'] ) : ( trim( (string) ( $d['plateformes'] ?? '' ) ) ?: null ) ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function setStatut( $id, $statut ) { if ( isset( self::statuts()[ $statut ] ) ) { FKC_DB::q( 'UPDATE lbl_releases SET statut=? WHERE id=?', array( $statut, (int) $id ) ); } }
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_releases WHERE id=?', array( (int) $id ) ); }
}
