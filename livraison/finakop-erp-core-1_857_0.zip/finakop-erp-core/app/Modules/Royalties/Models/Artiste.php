<?php
/** Gestion des artistes (fiche, répartition royalties, historique). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Artiste {
	public static function statuts() { return array( 'actif'=>'Actif','suspendu'=>'Suspendu','archive'=>'Archivé' ); }
	public static function contrats() { return array( 'exclusif'=>'Exclusif','licence'=>'Licence','distribution'=>'Distribution','360'=>'Contrat 360','single'=>'Single deal' ); }

	public static function all( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE actif=1' : '';
		return FKC_DB::q( "SELECT * FROM lbl_artistes{$w} ORDER BY nom_scene, nom COLLATE NOCASE" )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM lbl_artistes WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function map() { $m = array(); foreach ( self::all() as $a ) { $m[ (int) $a['id'] ] = $a['nom_scene'] ?: $a['nom']; } return $m; }
	public static function codeExists( $code, $exceptId = 0 ) { return (bool) FKC_DB::q( 'SELECT 1 FROM lbl_artistes WHERE code=? AND id<>?', array( $code, (int) $exceptId ) )->fetch(); }
	public static function nomScene( $a ) { return $a ? ( $a['nom_scene'] ?: $a['nom'] ) : '—'; }

	protected static function cols() {
		return array( 'code','nom','nom_scene','telephone','email','date_naissance','nationalite','photo_url','manager',
			'genre','contrat_num','contrat_type','date_signature','date_fin_contrat','part_artiste','part_label',
			'compte_avance','compte_royalties','statut','notes','actif' );
	}
	protected static function vals( $d ) {
		$pa = max( 0, min( 100, (float) ( $d['part_artiste'] ?? 50 ) ) );
		return array(
			trim( (string) $d['code'] ), trim( (string) $d['nom'] ), trim( (string) ( $d['nom_scene'] ?? '' ) ) ?: null,
			trim( (string) ( $d['telephone'] ?? '' ) ) ?: null, trim( (string) ( $d['email'] ?? '' ) ) ?: null,
			trim( (string) ( $d['date_naissance'] ?? '' ) ) ?: null, trim( (string) ( $d['nationalite'] ?? '' ) ) ?: null,
			trim( (string) ( $d['photo_url'] ?? '' ) ) ?: null, trim( (string) ( $d['manager'] ?? '' ) ) ?: null,
			trim( (string) ( $d['genre'] ?? '' ) ) ?: null, trim( (string) ( $d['contrat_num'] ?? '' ) ) ?: null,
			trim( (string) ( $d['contrat_type'] ?? '' ) ) ?: null, trim( (string) ( $d['date_signature'] ?? '' ) ) ?: null,
			trim( (string) ( $d['date_fin_contrat'] ?? '' ) ) ?: null, $pa, 100 - $pa,
			trim( (string) ( $d['compte_avance'] ?? '409110' ) ) ?: '409110', trim( (string) ( $d['compte_royalties'] ?? '401160' ) ) ?: '401160',
			isset( self::statuts()[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'actif',
			trim( (string) ( $d['notes'] ?? '' ) ) ?: null, empty( $d['actif'] ) ? 0 : 1,
		);
	}
	public static function create( $d ) {
		$c = self::cols(); $ph = implode( ',', array_fill( 0, count( $c ), '?' ) );
		FKC_DB::q( 'INSERT INTO lbl_artistes(' . implode( ',', $c ) . ") VALUES({$ph})", self::vals( $d ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		$c = self::cols(); $v = self::vals( $d ); $v[] = (int) $id;
		FKC_DB::q( 'UPDATE lbl_artistes SET ' . implode( '=?,', $c ) . '=? WHERE id=?', $v );
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_artistes WHERE id=?', array( (int) $id ) ); }

	public static function countActifs() { return (int) FKC_DB::q( "SELECT COUNT(*) FROM lbl_artistes WHERE actif=1 AND statut='actif'" )->fetchColumn(); }
	/** Total artistes (quota de licence). */
	public static function count() { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM lbl_artistes' )->fetchColumn(); }

	/** Historique synthétique d'un artiste. */
	public static function historique( $id ) {
		return array(
			'oeuvres'   => FKC_DB::q( 'SELECT * FROM lbl_oeuvres WHERE artiste_id=? ORDER BY date_sortie DESC, id DESC', array( (int) $id ) )->fetchAll(),
			'concerts'  => FKC_DB::q( 'SELECT * FROM lbl_concerts WHERE artiste_id=? ORDER BY date DESC, id DESC', array( (int) $id ) )->fetchAll(),
			'paiements' => FKC_DB::q( 'SELECT * FROM lbl_paiements WHERE artiste_id=? ORDER BY date DESC, id DESC', array( (int) $id ) )->fetchAll(),
		);
	}
}
