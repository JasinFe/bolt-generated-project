<?php
/** Paiements artistes : royalties, cachets, avances (à payer / payé / en attente). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Paiement {
	public static function types() { return array( 'royalties'=>'Royalties','cachet'=>'Cachet','avance'=>'Avance' ); }
	public static function statuts() { return array( 'a_payer'=>'À payer','en_attente'=>'En attente','paye'=>'Payé' ); }

	public static function all( $statut = '' ) {
		$w = ''; $p = array();
		if ( '' !== $statut ) { $w = ' WHERE pa.statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT pa.*, a.nom_scene, a.nom artiste_nom FROM lbl_paiements pa JOIN lbl_artistes a ON a.id=pa.artiste_id{$w} ORDER BY pa.date DESC, pa.id DESC", $p )->fetchAll();
	}
	public static function forArtiste( $artisteId ) {
		return FKC_DB::q( 'SELECT * FROM lbl_paiements WHERE artiste_id=? ORDER BY date DESC, id DESC', array( (int) $artisteId ) )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_paiements(artiste_id,montant,type,statut,date,reference,note) VALUES(?,?,?,?,?,?,?)',
			array( (int) $d['artiste_id'], (float) ( $d['montant'] ?? 0 ),
				isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'royalties',
				isset( self::statuts()[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'a_payer',
				$d['date'] ?? date( 'Y-m-d' ), trim( (string) ( $d['reference'] ?? '' ) ) ?: null, trim( (string) ( $d['note'] ?? '' ) ) ?: null ) );
		$id = (int) FKC_DB::conn()->lastInsertId();

		/*
		 * COMPTABILISATION EXPLICITE, JAMAIS DEVINÉE.
		 *
		 * Deux chemins créent un paiement : la saisie manuelle, et l'import de
		 * décomptes de royalties. Le second passe DÉJÀ son écriture — l'import
		 * crédite la dette envers les ayants droit pour l'ensemble du décompte,
		 * puis ventile en autant de lignes de paiement. Émettre ici sans
		 * distinction doublerait la dette de tout un import.
		 *
		 * L'appelant dit donc explicitement s'il attend une écriture. On ne
		 * devine pas à partir de la référence : un jour quelqu'un changerait le
		 * texte « Import #… » et la comptabilité doublerait en silence.
		 */
		if ( ! empty( $d['comptabiliser'] ) && class_exists( 'FKC_Posting' ) ) {
			$art  = class_exists( 'FKC_Artiste' ) ? FKC_Artiste::find( $d['artiste_id'] ) : null;
			$nom  = $art ? ( $art['nom_scene'] ?: $art['nom'] ) : ( 'Artiste #' . (int) $d['artiste_id'] );
			$type = isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'royalties';
			/*
			 * BRUT ET NET NE SONT PAS LE MÊME MONTANT.
			 *
			 * Le décompte de royalties porte le brut dû à l'artiste ; l'avance
			 * déjà versée s'impute dessus, et seul le solde reste à payer.
			 * L'écriture est donc : charge au brut, dette au net, créance
			 * d'avance soldée pour la différence. Envoyer le brut des deux
			 * côtés déséquilibre l'écriture — elle est alors refusée, et
			 * l'utilisateur n'en voit aucune.
			 */
			$brut   = (float) ( $d['montant'] ?? 0 );
			$avance = max( 0.0, min( $brut, (float) ( $d['avance_recuperee'] ?? 0 ) ) );
			$ctx  = array(
				'montant'   => $brut,
				'ttc'       => $brut,
				'brut'      => $brut,
				'net'       => round( $brut - $avance, 2 ),
				'artiste'   => $nom,
				'tiers'     => $nom,
				'periode'   => (string) ( $d['periode'] ?? '' ),
				'piece'     => 'ART-' . str_pad( (string) $id, 5, '0', STR_PAD_LEFT ),
				'reference' => 'lbl.paiement#' . $id,
				'date'      => $d['date'] ?? date( 'Y-m-d' ),
			);
			try {
				if ( 'avance' === $type && FKC_Posting::has( 'creative_avance_artiste' ) ) {
					FKC_Posting::emettre( 'creative_avance_artiste', $ctx );
				} elseif ( 'royalties' === $type && FKC_Posting::has( 'creative_royalties_dues' ) ) {
					// L'avance récupérée solde la créance : sans cette ligne,
					// l'avance resterait éternellement à l'actif.
					$ctx['avance_recuperee'] = $avance;
					FKC_Posting::emettre( 'creative_royalties_dues', $ctx );
				}
			} catch ( \Throwable $e ) { fkc_log( 'Paiement::create — ' . $e->getMessage(), 'ERROR' ); }
		}
		return $id;
	}
	/**
	 * Colonnes du décaissement, ajoutées à la demande.
	 *
	 * Un règlement ne portait ni son compte de trésorerie, ni sa date réelle,
	 * ni sa référence : impossible de dire par quel canal un artiste avait été
	 * payé, ni de rapprocher le virement d'un relevé bancaire ou d'un reçu
	 * Mobile Money.
	 */
	protected static function assurerSchema() {
		static $fait = array();
		$cle = FKC_DB::file();
		if ( isset( $fait[ $cle ] ) ) { return; }
		$fait[ $cle ] = true;
		$cols = array(
			'tresorerie_id' => 'INTEGER',  // compte de trésorerie débité
			'date_reglement' => 'TEXT',    // date réelle du virement
			'reference_reglement' => 'TEXT',
			'regle_par' => 'INTEGER',      // utilisateur qui a déclenché
			'regle_le' => 'TEXT',
		);
		try {
			$ex = array();
			foreach ( FKC_DB::conn()->query( 'PRAGMA table_info(lbl_paiements)' ) as $c ) { $ex[] = $c['name']; }
			foreach ( $cols as $n => $t ) {
				if ( ! in_array( $n, $ex, true ) ) {
					try { FKC_DB::conn()->exec( "ALTER TABLE lbl_paiements ADD COLUMN {$n} {$t}" ); } catch ( \Throwable $e ) {}
				}
			}
		} catch ( \Throwable $e ) {}
	}

	/**
	 * ═══════════════════════════════════════════════════════════════════
	 *  LE RÈGLEMENT EST UN ACTE DU LABEL, PAS UNE CONSÉQUENCE DU CALCUL
	 * ═══════════════════════════════════════════════════════════════════
	 *  La répartition d'un relevé CONSTATE ce que chaque ayant droit a
	 *  gagné : elle crédite sa dette et alimente son solde. Elle ne décide
	 *  pas qu'il est payé. Le virement, lui, est une décision du label —
	 *  il choisit QUAND, DEPUIS QUEL COMPTE, et sous quelle référence.
	 *
	 *  L'ancienne version passait l'écriture à la date du jour, toujours
	 *  depuis la banque, sans référence ni trace de l'auteur. Un règlement
	 *  effectué en Mobile Money — le canal le plus courant pour payer un
	 *  artiste — sortait donc comptablement de la banque : le rapprochement
	 *  bancaire ne tombait jamais juste, et le solde Mobile Money restait
	 *  intact alors que l'argent en était parti.
	 * ═══════════════════════════════════════════════════════════════════
	 *
	 * @param array $d date, tresorerie_id, reference — tous facultatifs, mais
	 *                 c'est l'appelant (l'écran du label) qui les fournit.
	 * @return array{0:bool,1:string}
	 */
	public static function marquerPaye( $id, array $d = array() ) {
		self::assurerSchema();
		$p = FKC_DB::q( 'SELECT * FROM lbl_paiements WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $p ) { return array( false, 'Règlement introuvable.' ); }
		if ( 'paye' === $p['statut'] ) { return array( false, 'Ce règlement est déjà effectué.' ); }
		if ( (float) $p['montant'] <= 0 ) { return array( false, 'Montant nul : rien à régler.' ); }

		$date = trim( (string) ( $d['date'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) { $date = date( 'Y-m-d' ); }
		$ref = trim( (string) ( $d['reference'] ?? '' ) );
		$tresoId = ! empty( $d['tresorerie_id'] ) ? (int) $d['tresorerie_id'] : 0;

		/*
		 * Compte à créditer. Sans choix explicite, on garde le compte de
		 * banque par défaut — mais on ne DEVINE jamais un compte Mobile
		 * Money : payer depuis un compte que le label n'a pas désigné serait
		 * pire que le défaut qu'on corrige.
		 */
		$compteTresorerie = '';
		$libelleCanal = '';
		if ( $tresoId && class_exists( 'FKC_Tresorerie' ) ) {
			$t = FKC_Tresorerie::find( $tresoId );
			if ( ! $t ) { return array( false, 'Compte de trésorerie introuvable.' ); }
			if ( empty( $t['actif'] ) ) { return array( false, 'Ce compte de trésorerie est désactivé.' ); }
			$compteTresorerie = (string) $t['compte_numero'];
			$libelleCanal = ' par ' . $t['libelle'];
		}

		$artiste = class_exists( 'FKC_Artiste' ) ? FKC_Artiste::find( $p['artiste_id'] ) : null;
		$nom = $artiste ? ( $artiste['nom_scene'] ?: $artiste['nom'] ) : ( 'artiste #' . (int) $p['artiste_id'] );
		$libelle = 'Règlement ' . $nom . $libelleCanal . ( '' !== $ref ? ' — ' . $ref : '' );

		$eid = 'distribution' === FKC_Royalty::comptablePourPackActif()
			? FKC_DistributionComptable::ecriturePaiement( $p['montant'], $date, $libelle, $compteTresorerie )
			: FKC_LabelComptable::ecriturePaiement( $p['montant'], $date, $libelle, $compteTresorerie );

		/*
		 * Si la comptabilité est disponible mais que l'écriture échoue
		 * (période close, journal manquant), on NE marque PAS le règlement
		 * comme effectué : un artiste réputé payé sans décaissement au bilan
		 * est une dette qui disparaît sans contrepartie.
		 */
		$possible = 'distribution' === FKC_Royalty::comptablePourPackActif()
			? FKC_DistributionComptable::possible() : FKC_LabelComptable::possible();
		if ( $possible && ! $eid ) {
			return array( false, 'Règlement refusé — l\'écriture de décaissement n\'a pas pu être enregistrée (période close, journal ou compte manquant). Le dû reste ouvert.' );
		}

		FKC_DB::q(
			"UPDATE lbl_paiements SET statut='paye', ecriture_id=?, tresorerie_id=?, date_reglement=?, reference_reglement=?, regle_par=?, regle_le=datetime('now','localtime') WHERE id=?",
			array( $eid ? (int) $eid : null, $tresoId ?: null, $date, $ref ?: null,
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null, (int) $id )
		);
		return array( true, 'Règlement de ' . $nom . $libelleCanal . ' enregistré au ' . $date . '.' );
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_paiements WHERE id=?', array( (int) $id ) ); }

	public static function totalStatut( $statut ) { return (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant),0) FROM lbl_paiements WHERE statut=?', array( $statut ) )->fetchColumn(); }
	public static function aPayer() { return self::totalStatut( 'a_payer' ); }
	/** Solde dû à un artiste (à payer + en attente). */
	public static function soldeArtiste( $artisteId ) {
		return (float) FKC_DB::q( "SELECT COALESCE(SUM(montant),0) FROM lbl_paiements WHERE artiste_id=? AND statut IN('a_payer','en_attente')", array( (int) $artisteId ) )->fetchColumn();
	}
}
