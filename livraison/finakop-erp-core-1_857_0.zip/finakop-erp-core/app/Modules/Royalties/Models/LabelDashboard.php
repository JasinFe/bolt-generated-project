<?php
/** Tableau de bord Label musical. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_LabelDashboard {
	public static function compute() {
		$moisDebut = date( 'Y-m-01' );
		// Revenus du mois convertis relevé par relevé : un total qui mélange
		// des devises n'est pas un indicateur, c'est une addition de pommes
		// et de poires affichée en francs.
		$revenusMois = (float) FKC_Royalty::localiser( FKC_DB::q(
			'SELECT id import_id, COALESCE(total_brut,0) montant FROM lbl_royalty_imports WHERE date>=?',
			array( $moisDebut ) )->fetchAll() )['total']
			+ (float) FKC_DB::q( 'SELECT COALESCE(SUM(quantite*pu),0) FROM lbl_merch_ventes WHERE date>=?', array( $moisDebut ) )->fetchColumn();
		$streams = (int) FKC_DB::q( 'SELECT COALESCE(SUM(streams),0) FROM lbl_royalty_lignes' )->fetchColumn();
		return array(
			'revenus_mois'    => $revenusMois,
			'royalties_payer' => FKC_Paiement::aPayer(),
			'streams'         => $streams,
			'ventes'          => FKC_Merch::caTotal(),
			'concerts'        => FKC_Concert::countAvenir(),
			'artistes'        => FKC_Artiste::countActifs(),
			'top_artiste'     => self::topArtiste(),
			'top_album'       => self::topOeuvre( 'album' ),
			'top_single'      => self::topOeuvre( 'single' ),
		);
	}
	/**
	 * Meilleur artiste : le CLASSEMENT lui-même était faux, pas seulement le
	 * montant affiché. Un artiste dont les revenus viennent d'un relevé en
	 * euros passait derrière un artiste payé en francs, alors qu'il avait
	 * gagné bien davantage. On convertit avant de classer.
	 */
	protected static function topArtiste() {
		$rows = FKC_DB::q( 'SELECT l.artiste_id, l.import_id, COALESCE(SUM(l.montant_brut),0) montant, COALESCE(SUM(l.streams),0) streams
			FROM lbl_royalty_lignes l WHERE l.artiste_id IS NOT NULL GROUP BY l.artiste_id, l.import_id' )->fetchAll();
		if ( ! $rows ) { return null; }
		foreach ( $rows as &$r ) { $r['cle'] = (string) (int) $r['artiste_id']; }
		unset( $r );
		$loc = FKC_Royalty::localiser( $rows );
		if ( ! $loc['par_cle'] ) { return null; }
		$id = (int) array_key_first( $loc['par_cle'] );
		$a = FKC_DB::q( 'SELECT nom_scene, nom FROM lbl_artistes WHERE id=?', array( $id ) )->fetch();
		if ( ! $a ) { return null; }
		$streams = 0;
		foreach ( $rows as $r ) { if ( (int) $r['artiste_id'] === $id ) { $streams += (int) $r['streams']; } }
		return array( 'nom_scene' => $a['nom_scene'], 'nom' => $a['nom'],
			'brut' => (float) $loc['par_cle'][ (string) $id ], 'streams' => $streams );
	}
	protected static function topOeuvre( $type ) {
		return FKC_DB::q( 'SELECT o.titre, a.nom_scene, COALESCE(SUM(l.streams),0) streams
			FROM lbl_oeuvres o LEFT JOIN lbl_artistes a ON a.id=o.artiste_id LEFT JOIN lbl_royalty_lignes l ON l.oeuvre_id=o.id
			WHERE o.type=? GROUP BY o.id ORDER BY streams DESC LIMIT 1', array( $type ) )->fetch() ?: null;
	}
}
