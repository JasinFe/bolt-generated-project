<?php
/** Plan comptable & comptabilisation — personnalisation Industrie Musicale (SYSCOHADA). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_LabelComptable {

	/** Dernier résultat d'écriture : ( ecriture_id, brouillon_id, message ). */
	public static $dernier = array( null, null, '' );

	/**
	 * Ligne de liasse des comptes de gestion hors plan de base (1.854.0).
	 *
	 * Lue par FKC_EtatsDgi::correspondancesDeclarees(). Les 706xxx, 701xxx…
	 * sont rangés par le plan de base ; seuls les comptes qu'il ne connaît
	 * pas sont déclarés ici. 709000 reste déclaré pour les dossiers qui l'ont
	 * mouvementé avant son reclassement.
	 */
	public static function lignesLiasse() {
		return array(
			'682000' => array( 'sn' => 'RL', 'smt' => 'JG' ),  // Dotations — catalogues et masters
			'708000' => array( 'sn' => 'TC', 'smt' => 'KA' ),  // Licences synchronisation — films et séries
			'708100' => array( 'sn' => 'TC', 'smt' => 'KA' ),  // Licences synchronisation — jeux vidéo
			'709000' => array( 'sn' => 'TC', 'smt' => 'KA' ),  // Ancien compte « branding » (voir 706095)
		);
	}

	/** Comptes spécifiques « label / industrie musicale » (numéro, libellé, classe). */
	public static function comptesMusique() {
		return array(
			array( '163010', 'Avances reçues sur contrats artistes', 1 ),
			array( '261010', 'Catalogues musicaux et masters acquis', 2 ),
			array( '264000', 'Marques et licences musicales', 2 ),
			array( '265010', 'Contrats artistes capitalisés', 2 ),
			array( '213010', 'Aménagements et installations — Studio', 2 ),
			array( '281010', 'Amortissements — Aménagements studio', 2 ),
			array( '286000', 'Amortissements — Catalogues et masters', 2 ),
			array( '310010', 'Supports physiques (CD, vinyles, merch)', 3 ),
			array( '401010', 'Fournisseurs — Distributeurs', 4 ),
			array( '411010', 'Clients — Organisateurs de concerts', 4 ),
			array( '411020', 'Clients — Plateformes streaming', 4 ),
			array( '411300', 'Clients — Synchro et licences', 4 ),
			array( '409110', 'Artistes — avances récupérables sur royalties', 4 ),
			array( '401160', 'Artistes et ayants droit — royalties dues', 4 ),
			array( '425010', 'Musiciens et artistes — Cachets à payer', 4 ),
			array( '445010', 'TVA auto-liquidée sur services numériques étrangers', 4 ),
			array( '604010', 'Instruments de musique', 6 ),
			array( '612010', 'Location salles de concert', 6 ),
			array( '615100', 'Assurance événements et concerts', 6 ),
			array( '621010', 'Musiciens sessionnistes', 6 ),
			array( '624010', 'Transports et déplacements artistes', 6 ),
			array( '624020', 'Hébergement artistes et équipe', 6 ),
			array( '633200', 'Redevances de licences musicales', 6 ),
			array( '644000', 'Cachets artistes', 6 ),
			array( '644100', 'Avances sur royalties artistes', 6 ),
			array( '644200', 'Minimum garanti artistes', 6 ),
			array( '644300', 'Frais de distribution par artiste (agrégateur)', 6 ),
			array( '644400', 'Frais UPC/ISRC par artiste et par release', 6 ),
			array( '655000', 'Charges de distribution musicale', 6 ),
			array( '655100', 'Commissions plateformes streaming', 6 ),
			array( '655200', 'Frais agrégateur distribution digitale', 6 ),
			array( '655210', 'Abonnements distribution musicale — Forfaits annuels', 6 ),
			array( '655220', 'Frais UPC/ISRC et enregistrement catalogue', 6 ),
			array( '655230', 'Commissions agrégateurs sur revenus streaming', 6 ),
			array( '655300', 'Frais distribution physique', 6 ),
			array( '672010', 'Annulation concerts et événements', 6 ),
			array( '682000', 'Dotations amortissements — Catalogues et masters', 6 ),
			array( '701010', 'Ventes supports physiques (CD, vinyles)', 7 ),
			array( '702010', 'Ventes marchandises dérivées (merch)', 7 ),
			array( '703010', 'Cessions de masters et catalogues', 7 ),
			array( '704010', 'Production musicale pour tiers', 7 ),
			array( '706940', 'Services de distribution musicale', 7 ),
			array( '706980', 'Royalties streaming — Spotify, Apple, Deezer', 7 ),
			array( '706040', 'Royalties download — iTunes, Amazon', 7 ),
			// BUG CORRIGÉ (audit 1.520.39) — 706115 était aussi celui de
			// "Sessions studio facturées" déclaré par le pack Studio
			// (app/Packs/studio/ecritures.php, app/Core/PlanMetier.php).
			// Une société avec le pack Studio actif ET le secteur Royalties
			// « Studio d'enregistrement » (estMusical() couvre les deux)
			// aurait vu les deux revenus — sessions facturées et royalties
			// YouTube — se mélanger dans le même compte. Renuméroté.
			array( '706390', 'Royalties YouTube Content ID', 7 ),
			array( '706050', 'Royalties UGC et synchro web', 7 ),
			array( '706060', 'Droits voisins — Radiodiffusion et TV', 7 ),
			array( '706070', "Droits d'auteur perçus via BURIDA", 7 ),
			array( '706080', 'Revenus plateformes vidéo (YouTube, TikTok)', 7 ),
			array( '706090', 'Revenus distribution numérique — Autres plateformes', 7 ),
			array( '707010', 'Cachets de concerts et live', 7 ),
			array( '707020', 'Garanties de concerts', 7 ),
			array( '708000', 'Licences synchronisation — Films et séries', 7 ),
			array( '708100', 'Licences synchronisation — Jeux vidéo', 7 ),
			/*
			 * 706095 ET NON 709000 (1.854.0). Le 709 est, au SYSCOHADA, le
			 * compte des RABAIS ACCORDÉS — une réduction de chiffre d'affaires.
			 * Y porter des revenus de branding détournait un compte normé :
			 * un lecteur de la balance y voyait des remises. Les dossiers qui
			 * l'ont déjà mouvementé le reclassent par une OD
			 * (FKC_Reclassement, entrée « 709000 »).
			 */
			array( '706095', 'Revenus branding et partenariats artistes', 7 ),

			/*
			 * ═══════════════════════════════════════════════════════════
			 *  ADMINISTRATION DE DROITS D'ÉDITION MUSICALE (1.755.0)
			 * ═══════════════════════════════════════════════════════════
			 *  Le plan couvrait le label (master) mais pas l'ÉDITION. Or ce
			 *  sont deux métiers distincts, avec deux flux d'argent distincts :
			 *  le master rémunère l'enregistrement, l'édition rémunère l'œuvre
			 *  — auteur, compositeur, éditeur.
			 *
			 *  Administrer des droits d'édition, c'est encaisser pour le compte
			 *  d'autrui : les sommes perçues auprès des sociétés de gestion
			 *  collective ne sont PAS un produit, sauf pour la part qu'on
			 *  conserve. Tout porter en 706070 « Droits d'auteur perçus via
			 *  BURIDA » gonflait le chiffre d'affaires du montant collecté pour
			 *  les auteurs, avec les conséquences qu'on imagine sur la base
			 *  imposable et sur les ratios.
			 *
			 *  D'où la séparation :
			 *    — ce qu'on GAGNE     : la commission d'administration, et la
			 *                           part éditoriale du catalogue propre ;
			 *    — ce qu'on DOIT      : les droits revenant aux auteurs ;
			 *    — ce qu'on ATTEND    : les répartitions des SGC.
			 * ═══════════════════════════════════════════════════════════
			 */
			array( '706192', "Commissions d'administration de droits d'édition musicale", 7 ),
			array( '706193', "Droits d'édition — part éditoriale du catalogue propre", 7 ),
			array( '706194', "Droits d'édition — synchronisation et usages dérivés", 7 ),
			/*
			 * 634640 ET NON 634610 (corrigé en 1.761.0).
			 *
			 * 634610 porte déjà, dans le socle FinaKop, « Royalties artistes et
			 * producteurs versées » — un modèle d'écriture s'en sert. Le compte
			 * d'édition y était déclaré par-dessus : la validation SYSCOHADA le
			 * refusait (un numéro, un sens), l'INSERT passait donc à la trappe
			 * et le compte n'a jamais été installé chez personne. Les deux
			 * charges sont bien distinctes — l'artiste interprète d'un côté,
			 * l'auteur-compositeur de l'autre — et méritent chacune son numéro.
			 * 634620 et 634630 étant pris par les packs médias et audiovisuel,
			 * le premier libre de la branche est 634640.
			 */
			array( '634640', "Droits d'édition reversés aux auteurs et ayants droit", 6 ),
			array( '401170', "Auteurs, compositeurs et éditeurs — droits d'édition à reverser", 4 ),
			array( '418130', "Sociétés de gestion collective — droits d'édition à recevoir", 4 ),
			array( '409120', "Auteurs et éditeurs — avances récupérables sur droits d'édition", 4 ),

			/*
			 * ── CÔTÉ ACHAT : QUAND C'EST NOUS QUI FAISONS ADMINISTRER ──
			 *
			 * Les comptes ci-dessus servent au cas où la société administre
			 * les droits d'autrui. Le cas inverse est au moins aussi courant :
			 * la société confie SON catalogue d'édition à un éditeur ou à un
			 * distributeur, qui collecte auprès des SGC et retient sa
			 * commission avant de reverser.
			 *
			 * Cette commission est une CHARGE, pas une diminution du produit.
			 * La nuance n'est pas doctrinale : n'enregistrer que le net reçu
			 * minore le chiffre d'affaires du montant de la commission, fausse
			 * le taux de commission réel — celui qu'on renégocie — et rend
			 * impossible de comparer deux administrateurs.
			 *
			 * Le parent est 6322 « Commissions et courtages sur ventes » : ce
			 * qu'un administrateur retient est littéralement une commission
			 * sur les sommes encaissées pour notre compte. Ce n'est pas une
			 * redevance 634 — nous n'exploitons pas un droit d'autrui, nous
			 * rémunérons un intermédiaire sur le nôtre.
			 */
			array( '632240', "Commissions d'administration de droits d'édition musicale", 6 ),
			array( '632250', "Frais de collecte et de traitement — sociétés de gestion collective", 6 ),
			array( '401150', "Éditeurs et administrateurs de droits d'édition", 4 ),

			/*
			 * ABONNEMENT, DISTINCT DE LA COMMISSION.
			 *
			 * Un administrateur de droits d'édition facture le plus souvent
			 * DEUX choses, et il faut résister à l'envie de les fondre :
			 *
			 *   — un ABONNEMENT : somme fixe, annuelle ou mensuelle, due que
			 *     le catalogue rapporte ou non (632720) ;
			 *   — une COMMISSION : pourcentage prélevé sur ce qui est
			 *     effectivement collecté (632240).
			 *
			 * Les confondre rend le coût du service illisible. L'abonnement
			 * est un coût FIXE : c'est lui qui décide si le service est
			 * rentable pour un petit catalogue, et lui seul qu'on compare au
			 * revenu éditorial de l'année pour savoir s'il faut continuer. La
			 * commission, elle, est proportionnelle — elle ne coûte jamais
			 * plus que ce qu'elle rapporte.
			 *
			 * Parent 6327 « Rémunérations des autres prestataires de
			 * services », et non 626200 « Abonnements logiciels SaaS » : ce
			 * qu'on paie n'est pas un logiciel mais une prestation de gestion
			 * de droits, même quand elle s'achète sur un site et se renouvelle
			 * comme un abonnement. Le rester sous 632 garde l'abonnement et la
			 * commission dans la même rubrique, donc additionnables : le coût
			 * total de l'administrateur se lit d'un coup d'œil.
			 */
			array( '632720', "Abonnement — administration de droits d'édition musicale", 6 ),
		);
	}

	/** Combien de comptes musicaux sont déjà présents. */
	/*
	 * Comptes déjà présents / à installer — validés au passage.
	 *
	 * BUG CORRIGÉ (audit 1.520.46) — seed() insérait chaque compte par un
	 * INSERT OR IGNORE direct, SANS passer par FKC_PlanMetier::valider() ni
	 * FKC_GenerateurPlan (le chemin qu'empruntent tous les autres packs).
	 * Conséquence concrète : 28 des 133 comptes déclarés ici (163000,
	 * 411100 « Clients — Organisateurs de concerts », 706100, 758000…)
	 * étaient en réalité des numéros RÉSERVÉS par le référentiel OHADA —
	 * l'INSERT échouait en silence (déjà présent sous un autre libellé), le
	 * bouton « Installer les comptes manquants » annonçait un succès, et le
	 * compte promis n'apparaissait jamais dans le plan comptable. Les 28
	 * comptes ont été renumérotés vers de vraies subdivisions ; ce filtre
	 * reste en place pour qu'un futur ajout à comptesMusique()/
	 * comptesCreatifBase()/comptesSecteur() ne puisse plus reproduire
	 * silencieusement le même défaut — il sera refusé et journalisé.
	 */
	protected static function comptesValides( $secteur = null ) {
		$assoc = array();
		foreach ( self::comptesPlan( $secteur ) as $c ) { $assoc[ $c[0] ] = $c; }
		if ( ! class_exists( 'FKC_PlanMetier' ) ) { return array_values( $assoc ); }
		$r = FKC_PlanMetier::valider( array_map( function ( $c ) { return $c[1]; }, $assoc ) );
		if ( ! empty( $r['refus'] ) && function_exists( 'fkc_log' ) ) {
			fkc_log( 'LabelComptable — ' . count( $r['refus'] ) . ' compte(s) refusé(s) faute de rattachement SYSCOHADA : '
				. implode( ', ', array_keys( $r['refus'] ) ), 'WARN' );
		}
		$out = array();
		foreach ( $assoc as $num => $c ) { if ( isset( $r['ok'][ $num ] ) ) { $out[] = $c; } }
		return $out;
	}

	public static function presents( $secteur = null ) {
		$n = 0;
		foreach ( self::comptesValides( $secteur ) as $c ) { if ( FKC_DB::q( 'SELECT 1 FROM comptes WHERE numero=?', array( $c[0] ) )->fetch() ) { $n++; } }
		return $n;
	}
	/** Installe les comptes VALIDÉS du secteur actif, manquants (idempotent). */
	public static function seed( $secteur = null ) {
		$ins = FKC_DB::conn()->prepare( 'INSERT OR IGNORE INTO comptes(numero,libelle,classe,type) VALUES(?,?,?,?)' );
		$n = 0;
		foreach ( self::comptesValides( $secteur ) as $c ) {
			$ins->execute( array( $c[0], $c[1], $c[2], 'detail' ) );
			$n += $ins->rowCount();
		}
		return $n;
	}

	/** Socle de comptes communs aux industries créatives. */
	public static function comptesCreatifBase() {
		return array(
			array( '626010', 'Hébergements web (hosting, VPS, serveurs)', 6 ),
			array( '626200', 'Abonnements logiciels SaaS et cloud', 6 ),
			array( '626300', 'Noms de domaine — renouvellements', 6 ),
			array( '626400', 'CDN, stockage cloud et bande passante', 6 ),
			array( '604020', 'Sous-traitance créative et freelances', 6 ),
			array( '622010', 'Honoraires et prestations intellectuelles', 6 ),
			array( '651010', "Redevances de droits d'auteur et licences versées", 6 ),
			array( '706720', 'Prestations de création et services créatifs', 7 ),
			array( '706870', 'Honoraires et conseil', 7 ),
			array( '758010', "Subventions d'exploitation reçues", 7 ),
		);
	}

	/** Comptes spécifiques au secteur d'activité. */
	/*
	 * UNIFICATION (suite au chantier Créatif & Médias) : ces comptes
	 * n'étaient PAS ceux des vrais Packs Métier dédiés créés depuis —
	 * chaque secteur avait sa propre numérotation ici, indépendante de
	 * FKC_PlanMetier::pourPack(), qui est la source canonique utilisée par
	 * TOUS les autres packs de l'application. Deux conséquences : une
	 * société qui active « Agence de communication » comme secteur Royalties
	 * proposait des comptes différents de celle qui active le pack dédié
	 * FinaKop Communication pour le même métier ; et plusieurs de ces
	 * numéros (706184, 706185, 706140, 706170…) étaient de VRAIS doublons
	 * déjà utilisés par d'autres packs sans rapport (École, etc.) — restés
	 * inoffensifs tant qu'un seul pack pouvait être actif à la fois, mais
	 * devenus un risque réel avec le vrai multi-pack (1.520.42). On délègue
	 * donc à FKC_PlanMetier::pourPack() : chaque secteur reçoit désormais
	 * EXACTEMENT les comptes de son Pack Métier dédié quand il en existe un
	 * (audiovisuel/medias restent groupés, faute de pack 1-pour-1 par
	 * secteur — un seul pack 'audiovisuel' pour les 3, un seul 'medias'
	 * pour les 4).
	 */
	public static function comptesSecteur( $secteur ) {
		$map = array(
			/*
			 * `studio_enr` manquait à cette table (corrigé 1.649.0) : le
			 * studio d'enregistrement était le seul secteur doté d'un pack
			 * dédié à ne pas y être rattaché, et n'obtenait donc jamais les
			 * comptes de son métier. Le label, lui, n'a volontairement pas
			 * d'entrée : ses comptes sont ceux de comptesMusique().
			 */
			'studio_enr' => array( 'studio' ),
			'studio_video' => array( 'audiovisuel' ), 'prod_audiovisuelle' => array( 'audiovisuel' ), 'prod_cinema' => array( 'audiovisuel' ),
			'television' => array( 'audiovisuel', 'medias' ), 'webtv' => array( 'audiovisuel', 'medias' ),
			'radio' => array( 'medias' ), 'media_online' => array( 'medias' ),
			'agence_com' => array( 'agence_com' ), 'agence_digitale' => array( 'agence_digitale' ), 'studio_graphique' => array( 'studio_graphique' ),
			'createur_contenu' => array( 'createur_contenu' ), 'influenceur' => array( 'influenceur' ),
			'maison_edition' => array( 'maison_edition' ), 'evenementiel' => array( 'evenementiel' ), 'structure_culturelle' => array( 'structure_culturelle' ),
		);
		$out = array();
		$vus = array();
		foreach ( (array) ( $map[ $secteur ] ?? array() ) as $pk ) {
			foreach ( self::comptesDuPackDedie( $pk ) as $tuple ) {
				if ( isset( $vus[ $tuple[0] ] ) ) { continue; } // 'television'/'webtv' fusionnent 2 packs : jamais de doublon
				$vus[ $tuple[0] ] = true;
				$out[] = $tuple;
			}
		}
		return $out;
	}

	/** Comptes d'un Pack Métier dédié (FKC_PlanMetier::pourPack), au format tuple (numéro, libellé, classe) attendu ici — classe déduite du premier chiffre SYSCOHADA. */
	protected static function comptesDuPackDedie( $pack ) {
		if ( ! class_exists( 'FKC_PlanMetier' ) ) { return array(); }
		$out = array();
		foreach ( FKC_PlanMetier::pourPack( $pack ) as $numero => $libelle ) {
			$out[] = array( (string) $numero, (string) $libelle, (int) substr( (string) $numero, 0, 1 ) );
		}
		return $out;
	}

	/** Plan comptable effectif — union des secteurs demandés (dédupliqué).
	 * Accepte un code unique (compat), un tableau de codes, ou rien (tous
	 * les secteurs ACTIFS de la société — voir FKC_Secteur::actifs()). */
	public static function comptesPlan( $secteur = null ) {
		if ( null === $secteur ) {
			$codes = class_exists( 'FKC_Secteur' ) ? FKC_Secteur::actifs() : array( 'labelmusical' );
		} else {
			$codes = is_array( $secteur ) ? $secteur : array( $secteur );
		}
		$liste = self::comptesCreatifBase();
		foreach ( $codes as $code ) {
			/*
			 * SECTEURS MUSICAUX — le raccourci était trop court pour le
			 * studio (1.649.0).
			 *
			 * La règle était : musical → comptes MUSIQUE, sinon → comptes du
			 * pack dédié. `estMusical()` couvrant `labelmusical` ET
			 * `studio_enr`, un studio d'enregistrement recevait les comptes
			 * du LABEL — royalties streaming, droits BURIDA, cachets de
			 * concerts, ventes de vinyles — et AUCUN des siens : sessions
			 * facturées, location de studio, mixage et mastering, matériel,
			 * techniciens, acomptes sur projets.
			 *
			 * Le raccourci valait pour le label, dont le métier EST la
			 * musique enregistrée. Il ne valait pas pour le studio, qui
			 * partage le vocabulaire musical sans partager les recettes :
			 * un studio vend des HEURES de cabine, pas des royalties. Le
			 * secteur voisin `studio_graphique` recevait bien les comptes
			 * de son pack ; le studio d'enregistrement était le seul à
			 * tomber entre les deux branches.
			 *
			 * Le studio reçoit donc les DEUX ensembles : les comptes
			 * musicaux communs — il perçoit aussi des droits voisins — ET
			 * ceux de son pack dédié. La déduplication en fin de méthode
			 * absorbe le recouvrement.
			 */
			if ( class_exists( 'FKC_Secteur' ) && FKC_Secteur::estMusical( $code ) ) {
				$liste = array_merge( $liste, self::comptesMusique() );
			}
			$liste = array_merge( $liste, self::comptesSecteur( $code ) );
		}
		$vus = array(); $out = array();
		foreach ( $liste as $c ) { if ( ! isset( $vus[ $c[0] ] ) ) { $vus[ $c[0] ] = 1; $out[] = $c; } }
		usort( $out, function ( $a, $b ) { return strcmp( $a[0], $b[0] ); } );
		return $out;
	}

	/* Comptes de comptabilisation (paramétrables par locataire). */
	public static function compte( $cle, $defaut ) {
		return class_exists( 'FKC_License' ) ? FKC_License::param( 'lbl_' . $cle, $defaut ) : $defaut;
	}
	public static function possible() {
		return class_exists( 'FKC_Ecriture' ) && class_exists( 'FKC_Compte' ) && class_exists( 'FKC_Journal' )
			&& class_exists( 'FKC_License' ) && FKC_License::moduleEnabled( 'comptabilite' );
	}
	protected static function journal() {
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		$all = FKC_Journal::all(); return $all ? (int) $all[0]['id'] : 0;
	}
	public static function compteId( $numero, $libelle ) {
		$numero = trim( (string) $numero ); if ( '' === $numero ) { return 0; }
		$c = FKC_Compte::byNumero( $numero );
		if ( ! $c ) { FKC_Compte::create( str_pad( $numero, 6, '0' ), $libelle ); $c = FKC_Compte::byNumero( $numero ); }
		return $c ? (int) $c['id'] : 0;
	}

	/**
	 * Comptabilise un relevé de royalties : reconnaissance du revenu + dette artiste.
	 * @return int|null ecriture_id
	 */
	/**
	 * Écriture de royalties. Les montants reçus sont DÉJÀ convertis dans la
	 * devise de tenue des comptes par l'appelant ; `$fx` conserve la devise
	 * d'origine et le cours retenu, portés sur les lignes pour permettre la
	 * revalorisation de clôture et la justification devant un contrôle.
	 *
	 * @param array $fx array{devise,taux,brut_devise,ayants_devise} ou vide.
	 */
	public static function ecritureRoyalties( $compteRevenu, $totalBrut, $totalArtiste, $date, $libelle, $fx = array(), $opts = array() ) {
		if ( ! self::possible() ) { return null; }
		$totalBrut = round( (float) $totalBrut, 0 ); $totalArtiste = round( (float) $totalArtiste, 0 );
		if ( $totalBrut <= 0 ) { return null; }
		$jr = self::journal(); if ( ! $jr ) { return null; }
		/*
		 * ═══════════════════════════════════════════════════════════════
		 *  LE RELEVÉ CRÉE UNE CRÉANCE, PAS UN ENCAISSEMENT (1.751.0)
		 * ═══════════════════════════════════════════════════════════════
		 *  Un distributeur met ses rapports à disposition sans virer quoi que
		 *  ce soit : c'est le label qui demande le versement quand il le
		 *  décide, parfois des semaines ou des mois plus tard.
		 *
		 *  Débiter 521000 Banque à la comptabilisation du relevé affirmait
		 *  donc un encaissement qui n'avait pas eu lieu. Trois conséquences,
		 *  toutes silencieuses : la trésorerie du cockpit annonçait de
		 *  l'argent absent du compte, le rapprochement bancaire ne tombait
		 *  jamais juste, et la créance sur le distributeur — un actif réel,
		 *  parfois important — n'apparaissait nulle part au bilan.
		 *
		 *  Le produit reste acquis dès le rapport (il est gagné), mais sa
		 *  contrepartie est une CRÉANCE, soldée à l'encaissement effectif par
		 *  FKC_RoyaltyEncaissement.
		 * ═══════════════════════════════════════════════════════════════
		 */
		/*
		 * 418140, ET NON 418100 (corrigé en 1.755.0).
		 *
		 * 418100 est la forme normalisée de « 4181 Clients, factures à
		 * établir » : un numéro RÉSERVÉ par le référentiel OHADA. Le lui
		 * donner un autre intitulé écrasait un compte réglementaire — la
		 * faute exacte que FKC_PlanMetier::valider() refuse, et que ce
		 * chemin contournait faute de passer par lui.
		 */
		$cCreance  = self::compteId( self::compte( 'creance_distributeur', '418140' ), 'Distributeurs — royalties à encaisser' );
		$cRevenu   = self::compteId( $compteRevenu ?: '706510', 'Streaming musical en ligne' );
		/*
		 * 634610, ET NON 644100 (corrigé en 1.779.0).
		 *
		 * 644100 n'a aucun parent au référentiel sinon la classe 64 — « Impôts
		 * et taxes ». La part des artistes remontait donc dans les impôts et
		 * taxes de la liasse, et le taux de charges fiscales du label en
		 * paraissait multiplié. Une royaltie versée est une redevance pour
		 * droits (compte 634) : le socle porte déjà 634610 « Royalties
		 * artistes et producteurs versées », que le modèle d'écriture de
		 * reversement employait depuis longtemps. Le paramètre de société
		 * lbl_charge_royalties reste prioritaire.
		 */
		$cCharge   = self::compteId( self::compte( 'charge_royalties', '634610' ), 'Royalties artistes et producteurs versées' );
		$cDette    = self::compteId( self::compte( 'royalties_dues', '401160' ), 'Artistes et ayants droit — royalties dues' );
		if ( ! $cCreance || ! $cRevenu || ! $cCharge || ! $cDette ) { return null; }

		$dev       = isset( $fx['devise'] ) ? strtoupper( (string) $fx['devise'] ) : null;
		$taux      = isset( $fx['taux'] ) ? (float) $fx['taux'] : null;
		$brutDev   = isset( $fx['brut_devise'] ) ? (float) $fx['brut_devise'] : null;
		$ayantsDev = isset( $fx['ayants_devise'] ) ? (float) $fx['ayants_devise'] : null;

		// La devise n'est portée que si elle diffère de celle des comptes : une
		// ligne « XOF dans une compta XOF » n'a rien à revaloriser.
		$pivot = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';
		$trace = ( $dev && $dev !== $pivot && $taux > 0 );
		// La créance est un poste monétaire en devise : c'est elle qui portera
		// l'écart de change jusqu'à l'encaissement, et qui se revalorisera à
		// la clôture si le distributeur n'a pas encore versé.
		$fxCreance = $trace ? array( 'devise' => $dev, 'montant_devise' => $brutDev, 'taux_change' => $taux ) : array();
		// La dette envers les artistes est un poste monétaire : c'est elle qui se
		// revalorisera à la clôture si elle reste due. Solde créditeur, donc
		// montant en devise négatif dans la convention de FKC_DeviseRevalorisation.
		$fxDette = $trace ? array( 'devise' => $dev, 'montant_devise' => -1 * (float) $ayantsDev, 'taux_change' => $taux ) : array();

		$lignes = array(
			array_merge( array( 'compte_id' => $cCreance, 'libelle' => $libelle, 'debit' => $totalBrut, 'credit' => 0 ), $fxCreance ),
			array( 'compte_id' => $cRevenu, 'libelle' => $libelle, 'debit' => 0, 'credit' => $totalBrut ),
		);
		if ( $totalArtiste > 0 ) {
			$lignes[] = array( 'compte_id' => $cCharge, 'libelle' => 'Part artiste', 'debit' => $totalArtiste, 'credit' => 0 );
			$lignes[] = array_merge( array( 'compte_id' => $cDette, 'libelle' => 'Part artiste', 'debit' => 0, 'credit' => $totalArtiste ), $fxDette );
		}
		$entete = array( 'journal_id' => $jr, 'date_ecriture' => $date, 'piece' => 'ROY',
			'libelle' => $libelle, 'reference' => 'Royalties', 'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null );
		// 1.779.0 — écriture de rattachement (cut-off) : datée du dernier jour
		// de l'exercice de la période économique, elle franchit le verrou
		// mensuel comme une dotation (voir FKC_RnPeriode::dateComptable).
		if ( ! empty( $opts['inventaire'] ) ) { $entete['inventaire'] = 1; }
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, array( 'source' => 'royalties' ) );
		self::$dernier = array( $ok ? $eid : null, $ok ? $bid : null, (string) $msg );
		return $ok ? ( $eid ?: $bid ) : null;
	}

	/** Comptabilise un paiement à un artiste : D 401160 / C 521000. */
	/**
	 * Décaissement au profit d'un ayant droit.
	 *
	 * Le compte de trésorerie est désormais CHOISI par le label ($compteTresorerie).
	 * Créditer systématiquement la banque envoyait comptablement hors banque
	 * un règlement fait en Mobile Money : le rapprochement bancaire ne tombait
	 * jamais juste, et le solde Mobile Money restait intact alors que l'argent
	 * en était sorti. Sans choix explicite, la banque reste le défaut.
	 */
	/**
	 * ÉCRITURE D'ENCAISSEMENT — le distributeur verse ce que le label a demandé.
	 *
	 *   D  Trésorerie            montant réellement reçu
	 *   D  631 Frais bancaires   retenue du distributeur (le cas échéant)
	 *   D  676 Pertes de change  si le cours a baissé depuis le relevé
	 *      C  418140 Créance     au cours d'origine — la créance se solde pour
	 *                            sa valeur d'inscription, pas pour ce qu'on reçoit
	 *      C  776 Gains de change  si le cours a monté
	 *
	 * L'écart de change est RÉALISÉ : il va droit au résultat, pas au bilan.
	 * L'opération est dénouée, il n'y a plus rien à revaloriser à la clôture.
	 *
	 * @param array $d date, creance_local, recu_local, frais_local, ecart_local,
	 *                 tresorerie, libelle, devise, montant_devise, taux
	 * @return int|null
	 */
	public static function ecritureEncaissement( array $d ) {
		if ( ! self::possible() ) { return null; }
		$jr = self::journal(); if ( ! $jr ) { return null; }
		$creance = round( (float) ( $d['creance_local'] ?? 0 ), 0 );
		$recu    = round( (float) ( $d['recu_local'] ?? 0 ), 0 );
		$frais   = round( (float) ( $d['frais_local'] ?? 0 ), 0 );
		$ecart   = round( (float) ( $d['ecart_local'] ?? 0 ), 0 );
		if ( $creance <= 0 || $recu <= 0 ) { return null; }

		$numTreso  = trim( (string) ( $d['tresorerie'] ?? '' ) ) ?: self::compte( 'banque', '521100' );
		$cTreso    = self::compteId( $numTreso, 'Trésorerie' );
		$cCreance  = self::compteId( self::compte( 'creance_distributeur', '418140' ), 'Distributeurs — royalties à encaisser' );
		if ( ! $cTreso || ! $cCreance ) { return null; }

		$libelle = trim( (string) ( $d['libelle'] ?? '' ) ) ?: 'Encaissement royalties';
		$dev     = strtoupper( (string) ( $d['devise'] ?? '' ) );
		$pivot   = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';
		$taux    = (float) ( $d['taux'] ?? 0 );
		$trace   = ( $dev && $dev !== $pivot && $taux > 0 );
		// La créance SORT du bilan : montant en devise positif, sens débiteur
		// inversé — convention de FKC_DeviseRevalorisation pour un solde qui
		// s'éteint.
		$fxCreance = $trace ? array( 'devise' => $dev, 'montant_devise' => -1 * (float) ( $d['montant_devise'] ?? 0 ), 'taux_change' => $taux ) : array();

		$lignes = array( array( 'compte_id' => $cTreso, 'libelle' => $libelle, 'debit' => $recu, 'credit' => 0 ) );
		if ( $frais > 0 ) {
			$cFrais = self::compteId( self::compte( 'frais_distributeur', '631000' ), 'Frais bancaires' );
			if ( ! $cFrais ) { return null; }
			$lignes[] = array( 'compte_id' => $cFrais, 'libelle' => 'Retenue du distributeur', 'debit' => $frais, 'credit' => 0 );
		}
		if ( $ecart < 0 ) {
			$cPerte = self::compteId( self::compte( 'perte_change', '676000' ), 'Pertes de change' );
			if ( ! $cPerte ) { return null; }
			$lignes[] = array( 'compte_id' => $cPerte, 'libelle' => 'Écart de change réalisé', 'debit' => abs( $ecart ), 'credit' => 0 );
		}
		$lignes[] = array_merge( array( 'compte_id' => $cCreance, 'libelle' => $libelle, 'debit' => 0, 'credit' => $creance ), $fxCreance );
		if ( $ecart > 0 ) {
			$cGain = self::compteId( self::compte( 'gain_change', '776000' ), 'Gains de change' );
			if ( ! $cGain ) { return null; }
			$lignes[] = array( 'compte_id' => $cGain, 'libelle' => 'Écart de change réalisé', 'debit' => 0, 'credit' => $ecart );
		}

		$entete = array( 'journal_id' => $jr, 'date_ecriture' => $d['date'], 'piece' => 'ENC-ROY',
			'libelle' => $libelle, 'reference' => 'Encaissement royalties',
			'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null );
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, array( 'source' => 'royalties' ) );
		return $ok ? ( $eid ?: $bid ) : null;
	}

	public static function ecriturePaiement( $montant, $date, $libelle, $compteTresorerie = '' ) {
		if ( ! self::possible() ) { return null; }
		$montant = round( (float) $montant, 0 ); if ( $montant <= 0 ) { return null; }
		$jr = self::journal(); if ( ! $jr ) { return null; }
		$cDette  = self::compteId( self::compte( 'royalties_dues', '401160' ), 'Artistes et ayants droit — royalties dues' );
		$numTreso = trim( (string) $compteTresorerie ) ?: self::compte( 'banque', '521100' );
		$cBanque = self::compteId( $numTreso, 'Trésorerie' );
		if ( ! $cDette || ! $cBanque ) { return null; }
		$entete = array( 'journal_id' => $jr, 'date_ecriture' => $date, 'piece' => 'PAY-ART',
			'libelle' => $libelle, 'reference' => 'Paiement artiste', 'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null );
		$lignes = array(
			array( 'compte_id' => $cDette, 'libelle' => $libelle, 'debit' => $montant, 'credit' => 0 ),
			array( 'compte_id' => $cBanque, 'libelle' => $libelle, 'debit' => 0, 'credit' => $montant ),
		);
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, array( 'source' => 'royalties' ) );
		return $ok ? ( $eid ?: $bid ) : null;
	}
}
