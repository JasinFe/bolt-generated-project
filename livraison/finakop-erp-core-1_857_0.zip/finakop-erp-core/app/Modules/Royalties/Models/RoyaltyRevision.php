<?php
/**
 * ÉTAT DE CONTRÔLE DES ATTRIBUTIONS PASSÉES.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * POURQUOI CET ÉTAT EXISTE
 *
 * Jusqu'à la 1.787.0, une ligne de relevé pouvait être attribuée sur une
 * simple RESSEMBLANCE de titre : il suffisait que « TITRE (Deluxe Version) »
 * se réduise au titre d'une œuvre du catalogue pour que la ligne prenne
 * l'artiste de cette œuvre — sans que l'ISRC le confirme, sans que le nom
 * crédité soit reconnu, parfois sans qu'aucun nom soit crédité.
 *
 * La 1.787.0 exige désormais une corroboration. Mais elle ne répare que
 * l'avenir : les relevés DÉJÀ COMPTABILISÉS ont versé ce qu'ils ont versé, et
 * rien, dans les comptes, ne signale une part partie au mauvais ayant droit.
 * Une correction de règle qui ne regarde pas en arrière laisse le dossier
 * croire que le problème n'a jamais existé chez lui.
 *
 * Cet état relit donc chaque ligne déjà attribuée et repose la question
 * d'aujourd'hui : **le logiciel l'attribuerait-il encore ?**
 *
 * ═════════════════════════════════════════════════════════════════════════
 * IL NE CORRIGE RIEN
 *
 * Aucune écriture, aucune ligne, aucun paiement n'est touché. Un relevé
 * comptabilisé est un fait : les sommes sont parties, le dû est constaté,
 * l'écriture est passée. Le rattraper d'office produirait des mouvements que
 * personne n'a décidés, sur des exercices peut-être clôturés.
 *
 * L'état NOMME, CHIFFRE et LAISSE DÉCIDER — la même règle que la checklist de
 * clôture. Ce qui suit est un dossier de travail pour le label, pas une
 * correction automatique.
 *
 * ═════════════════════════════════════════════════════════════════════════
 * CE QU'IL SAIT, ET CE QU'IL NE SAIT PAS
 *
 * Il rejoue la cascade de rattachement sur le catalogue d'AUJOURD'HUI. Trois
 * conséquences, qu'il faut dire plutôt que laisser deviner :
 *
 *  — une ligne rattachée autrefois par ressemblance mais dont l'ISRC a depuis
 *    été enregistré au catalogue se rattache aujourd'hui par le CODE : elle ne
 *    ressort pas, et c'est juste — elle est confirmée ;
 *  — une attribution faite à la main AVANT la 1.788.0 ne portait aucune marque
 *    (voir `FKC_Royalty::attribuer`). Si son ISRC n'a pas pu être mémorisé,
 *    elle peut ressortir ici alors qu'un humain l'avait décidée. L'état le
 *    signale au lieu de la présenter comme une erreur ;
 *  — le catalogue a pu changer pour d'autres raisons. Une ligne qui pointerait
 *    aujourd'hui vers une AUTRE œuvre est signalée à part : ce n'est pas le
 *    même problème, et cela mérite un autre regard.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RoyaltyRevision {

	/** La ligne ne serait plus attribuée du tout aujourd'hui. */
	const PERDUE = 'non_attribuable';
	/** Elle serait attribuée, mais à quelqu'un d'autre. */
	const AUTRE  = 'divergente';

	/**
	 * Relit les relevés et liste les lignes que le logiciel n'attribuerait plus.
	 *
	 * @param array $opts comptabilises_seuls (bool, défaut true), import_id (int)
	 * @return array{
	 *   releves:array, lignes:array, nb:int, montant:float, montant_artiste:float,
	 *   montant_label:float, nb_divergentes:int, nb_releves:int, examinees:int,
	 *   devise:string, incertaines:int
	 * }
	 */
	public static function auditer( array $opts = array() ) {
		$out = array(
			'releves' => array(), 'lignes' => array(), 'nb' => 0, 'montant' => 0.0,
			'montant_artiste' => 0.0, 'montant_label' => 0.0, 'nb_divergentes' => 0,
			'nb_releves' => 0, 'examinees' => 0, 'devise' => '', 'incertaines' => 0,
			// Un état qui ne peut pas se calculer est une ANOMALIE, jamais un
			// « rien à signaler » — la règle tenue dans toute la checklist de
			// clôture. La première rédaction avalait l'erreur SQL et annonçait
			// un dossier sain : le pire des deux résultats possibles.
			'panne' => '',
		);
		if ( ! class_exists( 'FKC_Royalty' ) ) {
			$out['panne'] = 'Le module Royalties n\'est pas chargé : l\'état ne peut pas être établi.';
			return $out;
		}

		$où = array(); $args = array();
		if ( ! isset( $opts['comptabilises_seuls'] ) || $opts['comptabilises_seuls'] ) {
			$où[] = "i.statut='comptabilise'";
		}
		if ( ! empty( $opts['import_id'] ) ) { $où[] = 'i.id=?'; $args[] = (int) $opts['import_id']; }
		$sql = 'SELECT l.*, i.id AS imp_id, i.source AS imp_source, i.periode AS imp_periode,
					i.statut AS imp_statut, i.devise AS imp_devise, i.date AS imp_date
				FROM lbl_royalty_lignes l JOIN lbl_royalty_imports i ON i.id=l.import_id'
			. ( $où ? ' WHERE ' . implode( ' AND ', $où ) : '' )
			. ' ORDER BY i.periode DESC, l.id';

		try { $rows = FKC_DB::q( $sql, $args )->fetchAll(); }
		catch ( \Throwable $e ) {
			$out['panne'] = 'L\'état n\'a pas pu être établi : ' . $e->getMessage()
				. ' — ne concluez pas que le dossier est sain.';
			return $out;
		}

		$releves = array();
		foreach ( $rows as $l ) {
			$oeuvre  = (int) ( $l['oeuvre_id'] ?? 0 );
			$artiste = (int) ( $l['artiste_id'] ?? 0 );
			$attrib  = (string) ( $l['attribution'] ?? '' );

			// Rien n'a été attribué : il n'y a rien à remettre en cause.
			if ( ! $oeuvre && ! $artiste ) { continue; }
			// Décisions humaines : le label a tranché, on ne le contredit pas.
			if ( 'label' === $attrib || 'manuelle' === $attrib ) { continue; }

			$out['examinees']++;

			$e = FKC_Royalty::etapeRattachement(
				(string) ( $l['isrc'] ?? '' ), '',
				(string) ( $l['titre_source'] ?? '' ),
				(string) ( $l['artiste_source'] ?? '' )
			);
			$nOeuvre  = (int) ( $e['oeuvre_id'] ?? 0 );
			$nArtiste = (int) ( $e['artiste_id'] ?? 0 );

			// Aujourd'hui le logiciel dirait la même chose : rien à signaler.
			if ( $nOeuvre === $oeuvre && $nArtiste === $artiste ) { continue; }

			$cas = ( ! $nOeuvre && ! $nArtiste ) ? self::PERDUE : self::AUTRE;

			/*
			 * Une attribution humaine d'avant la 1.788.0 ne portait aucune
			 * marque. Faute de pouvoir l'exclure, on la SIGNALE : présenter la
			 * décision de quelqu'un comme une erreur de la machine ferait
			 * perdre confiance dans tout le reste de l'état.
			 */
			$incertaine = ( self::PERDUE === $cas && $oeuvre && '' === $attrib
				&& '' === trim( (string) ( $l['isrc'] ?? '' ) ) );
			if ( $incertaine ) { $out['incertaines']++; }

			$mA = round( (float) ( $l['montant_artiste'] ?? 0 ), 2 );
			$mL = round( (float) ( $l['montant_label'] ?? 0 ), 2 );

			$out['lignes'][] = array(
				'id' => (int) $l['id'], 'import_id' => (int) $l['imp_id'],
				'periode' => (string) $l['imp_periode'], 'source' => (string) $l['imp_source'],
				'statut' => (string) $l['imp_statut'], 'devise' => (string) ( $l['imp_devise'] ?? '' ),
				'titre' => (string) ( $l['titre_source'] ?? '' ),
				'credit' => (string) ( $l['artiste_source'] ?? '' ),
				'isrc' => (string) ( $l['isrc'] ?? '' ),
				'plateforme' => (string) ( $l['plateforme'] ?? '' ),
				'oeuvre_id' => $oeuvre ?: null, 'artiste_id' => $artiste ?: null,
				'oeuvre' => self::nomOeuvre( $oeuvre ), 'beneficiaire' => self::nomArtiste( $artiste ),
				'montant_brut' => round( (float) ( $l['montant_brut'] ?? 0 ), 2 ),
				'montant_artiste' => $mA, 'montant_label' => $mL,
				'cas' => $cas, 'etape' => (string) $e['etape'], 'incertaine' => $incertaine,
				'devient_oeuvre' => $nOeuvre ? self::nomOeuvre( $nOeuvre ) : '',
				'devient_artiste' => $nArtiste ? self::nomArtiste( $nArtiste ) : '',
				'explication' => self::expliquer( $cas, $e, $l, $incertaine ),
			);

			$out['nb']++;
			$out['montant'] += $mA + $mL;
			$out['montant_artiste'] += $mA;
			$out['montant_label'] += $mL;
			if ( self::AUTRE === $cas ) { $out['nb_divergentes']++; }
			if ( '' === $out['devise'] ) { $out['devise'] = (string) ( $l['imp_devise'] ?? '' ); }

			$k = (int) $l['imp_id'];
			if ( ! isset( $releves[ $k ] ) ) {
				$releves[ $k ] = array( 'id' => $k, 'periode' => (string) $l['imp_periode'],
					'source' => (string) $l['imp_source'], 'statut' => (string) $l['imp_statut'],
					'devise' => (string) ( $l['imp_devise'] ?? '' ),
					'nb' => 0, 'montant' => 0.0 );
			}
			$releves[ $k ]['nb']++;
			$releves[ $k ]['montant'] += $mA + $mL;
		}

		foreach ( $releves as $r ) { $out['releves'][] = $r; }
		$out['nb_releves'] = count( $out['releves'] );
		$out['montant'] = round( $out['montant'], 2 );
		$out['montant_artiste'] = round( $out['montant_artiste'], 2 );
		$out['montant_label'] = round( $out['montant_label'], 2 );
		return $out;
	}

	/**
	 * Une phrase par ligne : ce qui s'est passé, et ce qu'il faut regarder.
	 *
	 * Un tableau de lignes suspectes sans explication oblige le lecteur à
	 * refaire le raisonnement pour chacune. Il ne le fait pas, et l'état finit
	 * classé sans suite.
	 */
	protected static function expliquer( $cas, array $e, array $l, $incertaine ) {
		$titre  = trim( (string) ( $l['titre_source'] ?? '' ) );
		$credit = trim( (string) ( $l['artiste_source'] ?? '' ) );
		$isrc   = trim( (string) ( $l['isrc'] ?? '' ) );

		if ( self::AUTRE === $cas ) {
			return 'Le catalogue a changé depuis : cette ligne pointerait aujourd\'hui ailleurs. '
				. 'À vérifier — le versement passé a pu être juste, ou non.';
		}
		if ( $incertaine ) {
			return 'Ligne sans ISRC attribuée à une œuvre. Le relevé ne portait pas de code, et les '
				. 'attributions faites à la main avant cette version ne laissaient pas de trace : '
				. 'il peut s\'agir d\'une décision prise par quelqu\'un. À confirmer avant toute conclusion.';
		}
		if ( 'base_refusee' === ( $e['etape'] ?? '' ) ) {
			return 'Attribuée sur la seule RESSEMBLANCE du titre « ' . $titre . ' » avec une œuvre du '
				. 'catalogue, sans que rien ne le confirme : '
				. ( '' === $isrc ? 'aucun ISRC au relevé' : 'l\'ISRC ' . $isrc . ' est inconnu du catalogue' )
				. ( '' === $credit ? ', aucun nom crédité' : ', et « ' . $credit . ' » n\'est reconnu par personne' )
				. '. Vérifiez à qui ce revenu revient réellement.';
		}
		return 'Le logiciel ne saurait plus attribuer cette ligne aujourd\'hui : '
			. ( '' === $isrc ? 'pas d\'ISRC, ' : 'ISRC « ' . $isrc .' » inconnu du catalogue, ' )
			. 'titre « ' . $titre . ' » sans correspondance sûre'
			. ( '' === $credit ? '' : ', nom crédité « ' . $credit . ' » non reconnu' ) . '.';
	}

	/**
	 * Le geste qui éteint une ligne pour de bon : enregistrer l'ISRC du relevé
	 * sur l'œuvre à laquelle elle a été rattachée.
	 *
	 * Ce n'est pas une correction du passé — rien n'est repayé, rien n'est
	 * contre-passé. C'est la CONFIRMATION de ce qui a été fait : à partir de
	 * là, la ligne se rattache par le code, les relevés suivants aussi, et
	 * l'état cesse de la signaler parce qu'elle n'est plus un pari.
	 *
	 * L'œuvre qui porte déjà un ISRC n'est jamais écrasée : ce serait échanger
	 * une incertitude contre une autre.
	 */
	public static function confirmer( $ligneId ) {
		if ( ! class_exists( 'FKC_Royalty' ) ) { return array( false, 'Module indisponible.' ); }
		try {
			$l = FKC_DB::q( 'SELECT * FROM lbl_royalty_lignes WHERE id=?', array( (int) $ligneId ) )->fetch();
		} catch ( \Throwable $e ) { $l = null; }
		if ( ! $l ) { return array( false, 'Ligne introuvable.' ); }

		$oid  = (int) ( $l['oeuvre_id'] ?? 0 );
		$isrc = trim( (string) ( $l['isrc'] ?? '' ) );
		if ( ! $oid )  { return array( false, 'Cette ligne n\'est rattachée à aucune œuvre : il n\'y a rien à confirmer. '
			. 'Attribuez-la depuis l\'écran du relevé.' ); }
		if ( '' === $isrc ) { return array( false, 'Le relevé ne porte aucun ISRC pour cette ligne : il n\'y a pas de '
			. 'code à enregistrer. Le rattachement restera à vérifier à chaque relevé tant que le distributeur n\'en fournira pas.' ); }

		$o = FKC_Oeuvre::find( $oid );
		if ( ! $o ) { return array( false, 'Œuvre introuvable.' ); }
		if ( trim( (string) ( $o['isrc'] ?? '' ) ) !== '' ) {
			return array( false, 'L\'œuvre « ' . $o['titre'] . ' » porte déjà l\'ISRC ' . $o['isrc']
				. ', différent de celui du relevé. Deux codes pour une œuvre : c\'est au catalogue de trancher, pas à cet écran.' );
		}

		FKC_DB::q( 'UPDATE lbl_oeuvres SET isrc=? WHERE id=?', array( $isrc, $oid ) );
		FKC_DB::q( "UPDATE lbl_royalty_lignes SET attribution='manuelle' WHERE id=?", array( (int) $l['id'] ) );
		FKC_Royalty::oublierCatalogue();
		return array( true, 'ISRC ' . $isrc . ' enregistré sur « ' . $o['titre'] . ' ». Cette ligne et les relevés '
			. 'suivants se rattacheront désormais par le code. Aucun montant n\'a été modifié.' );
	}

	/**
	 * Écarter une ligne : elle a été vérifiée, le versement était le bon.
	 *
	 * Sans ce geste, l'état redirait la même chose chaque mois et finirait par
	 * n'être plus lu — le sort de tout rapport qui ne décroît jamais.
	 */
	public static function ecarter( $ligneId, $motif = '' ) {
		$motif = trim( (string) $motif );
		if ( mb_strlen( $motif ) < 5 ) {
			return array( false, 'Indiquez en quelques mots pourquoi ce versement était le bon : '
				. 'sans motif, l\'écart disparaît de l\'écran sans que personne ne sache pourquoi.' );
		}
		try {
			$n = (int) FKC_DB::q( "UPDATE lbl_royalty_lignes SET attribution='manuelle' WHERE id=? AND COALESCE(attribution,'')=''",
				array( (int) $ligneId ) )->rowCount();
		} catch ( \Throwable $e ) { return array( false, 'Enregistrement impossible.' ); }
		if ( ! $n ) { return array( false, 'Ligne introuvable, ou déjà tranchée.' ); }
		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			try {
				FKC_ClotureJournal::tracer( array(
					'exercice' => (int) date( 'Y' ), 'operation' => 'royalty_attribution_ecartee', 'issue' => 'ok',
					'libelle' => 'Attribution de royalties vérifiée et maintenue (ligne #' . (int) $ligneId . ')',
					'motif' => $motif,
				) );
			} catch ( \Throwable $e ) { /* le journal ne bloque jamais le métier */ }
		}
		return array( true, 'Ligne écartée de l\'état : le versement est réputé vérifié.' );
	}

	/* ── Libellés ─────────────────────────────────────────────────────────── */

	protected static function nomOeuvre( $id ) {
		if ( ! (int) $id ) { return ''; }
		try { $o = FKC_Oeuvre::find( (int) $id ); } catch ( \Throwable $e ) { return ''; }
		return $o ? (string) $o['titre'] : '';
	}

	protected static function nomArtiste( $id ) {
		if ( ! (int) $id ) { return ''; }
		try { $a = FKC_Artiste::find( (int) $id ); } catch ( \Throwable $e ) { return ''; }
		return $a ? (string) ( $a['nom_scene'] ?? $a['nom'] ?? '' ) : '';
	}

	/** Résumé d'une ligne, pour le tableau de bord du label. */
	public static function resume() {
		$a = self::auditer();
		if ( '' !== (string) $a['panne'] ) { return 'Attributions de royalties : ' . $a['panne']; }
		if ( 0 === $a['nb'] ) { return ''; }
		return $a['nb'] . ' ligne(s) de royalties attribuée(s) sans confirmation sur '
			. $a['nb_releves'] . ' relevé(s) comptabilisé(s), pour '
			. fkc_money( $a['montant'] ) . ' ' . ( $a['devise'] ?: '' ) . ' versés.';
	}
}
