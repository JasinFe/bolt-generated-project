<?php
/**
 * Contrats artistes (édition CREATIVE SUITE).
 * Table « lbl_contrats » dans la base de l'entité active.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Contrat {

	public static function types() {
		return array(
			'licence'      => 'Licence',
			'distribution' => 'Distribution',
			'edition'      => 'Édition / publishing',
			'360'          => 'Contrat 360',
			'featuring'    => 'Featuring',
			'autre'        => 'Autre',
		);
	}

	public static function statuts() {
		return array(
			'actif'     => 'Actif',
			'expire'    => 'Expiré',
			'resilie'   => 'Résilié',
			'brouillon' => 'Brouillon',
		);
	}

	public static function all() {
		return FKC_DB::q(
			'SELECT c.*, a.nom_scene, a.nom artiste_nom
			 FROM lbl_contrats c LEFT JOIN lbl_artistes a ON a.id=c.artiste_id
			 ORDER BY c.created_at DESC, c.id DESC'
		)->fetchAll();
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM lbl_contrats WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/** Nombre total de contrats (quota de licence). */
	public static function count() {
		return (int) FKC_DB::q( 'SELECT COUNT(*) FROM lbl_contrats' )->fetchColumn();
	}

	public static function create( $d ) {
		$types   = self::types();
		$statuts = self::statuts();
		FKC_DB::q(
			'INSERT INTO lbl_contrats(reference,artiste_id,type,date_debut,date_fin,taux_artiste,statut,note) VALUES(?,?,?,?,?,?,?,?)',
			array(
				trim( (string) ( $d['reference'] ?? '' ) ) ?: null,
				! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null,
				isset( $types[ $d['type'] ?? '' ] ) ? $d['type'] : 'licence',
				trim( (string) ( $d['date_debut'] ?? '' ) ) ?: null,
				trim( (string) ( $d['date_fin'] ?? '' ) ) ?: null,
				(float) ( $d['taux_artiste'] ?? 0 ),
				isset( $statuts[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'actif',
				trim( (string) ( $d['note'] ?? '' ) ) ?: null,
			)
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM lbl_contrats WHERE id=?', array( (int) $id ) );
	}
}
