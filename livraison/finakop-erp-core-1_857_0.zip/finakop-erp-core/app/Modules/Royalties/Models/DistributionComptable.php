<?php
/**
 * Comptabilisation Distribution Musicale — jeu de comptes VOLONTAIREMENT
 * SÉPARÉ de FKC_LabelComptable (choix de l'utilisateur, chantier
 * « Distribution », 1.520.66) : le pack Label et le pack Distribution ne
 * partagent aucun compte, même si les deux réutilisent le MÊME moteur
 * d'import/répartition (FKC_Royalty) — seule la comptabilisation diverge.
 *
 * DIFFÉRENCE DE MÉTHODE, PAS SEULEMENT DE COMPTES — un Label possède le
 * revenu brut et paie l'artiste comme une CHARGE (méthode brute, voir
 * FKC_LabelComptable::ecritureRoyalties() : 706100 D banque / C revenu,
 * 644100 charge / 401160 dette). Un distributeur ne possède PAS la
 * musique : il encaisse pour le compte de l'artiste et ne reconnaît EN
 * REVENU que sa commission — le reste de la somme reçue transite
 * directement au bilan (créance plateforme soldée par une dette artiste),
 * jamais par le compte de résultat. C'est le modèle déjà déclaré dans
 * app/Packs/distribution_musicale/ecritures.php depuis 1.520.41 (pièces
 * « commission » et « part_artiste » distinctes) — cette classe le rend
 * RÉELLEMENT utilisable par le moteur d'import de royalties, plutôt que
 * de rester un schéma jamais déclenché.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_DistributionComptable {

	/** Dernier résultat d'écriture : ( ecriture_id, brouillon_id, message ). */
	public static $dernier = array( null, null, '' );

	/** Comptes surchargeables par société (paramètre « posting_compte_dist_{clé} »), jamais partagés avec le Label (préfixe « dist_ », pas « lbl_ »). */
	public static function compte( $cle, $defaut ) {
		return class_exists( 'FKC_License' ) ? FKC_License::param( 'dist_' . $cle, $defaut ) : $defaut;
	}

	public static function possible() {
		return class_exists( 'FKC_Ecriture' ) && class_exists( 'FKC_Compte' ) && class_exists( 'FKC_Journal' )
			&& class_exists( 'FKC_License' ) && FKC_License::moduleEnabled( 'comptabilite' );
	}

	protected static function journal() {
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		$all = FKC_Journal::all(); return $all ? (int) $all[0]['id'] : 0;
	}

	public static function compteId( $numero, $libelle ) {
		$numero = trim( (string) $numero ); if ( '' === $numero ) { return 0; }
		$c = FKC_Compte::byNumero( $numero );
		if ( ! $c ) { FKC_Compte::create( str_pad( $numero, 6, '0' ), $libelle ); $c = FKC_Compte::byNumero( $numero ); }
		return $c ? (int) $c['id'] : 0;
	}

	/** Compte de créance sur la plateforme/le distributeur amont — même compte que audiovisuel/pack.php ecritures.php (411122), pour rester cohérent avec le pack déjà livré. */
	public static function compteCreance() {
		return self::compte( 'creance', '411122' );
	}

	/**
	 * Écriture de royalties — méthode NETTE. Contrairement à
	 * FKC_LabelComptable::ecritureRoyalties() (méthode brute, D banque /
	 * C revenu total, puis charge/dette séparées), une seule créance est
	 * posée (le total brut reçu de la plateforme), soldée par DEUX
	 * crédits : la commission (revenu réel du distributeur) et la dette
	 * envers l'artiste (le reste, jamais reconnu en revenu).
	 *
	 * @param float $totalBrut    Montant total reçu de la plateforme (créance).
	 * @param float $totalArtiste Part revenant à l'artiste (dette, jamais un revenu).
	 * @return int|null ecriture_id
	 */
	public static function ecritureRoyalties( $totalBrut, $totalArtiste, $date, $libelle, $fx = array(), $opts = array() ) {
		if ( ! self::possible() ) { return null; }
		$totalBrut = round( (float) $totalBrut, 0 ); $totalArtiste = round( (float) $totalArtiste, 0 );
		if ( $totalBrut <= 0 || $totalArtiste > $totalBrut ) { return null; }
		$commission = round( $totalBrut - $totalArtiste, 0 );
		$jr = self::journal(); if ( ! $jr ) { return null; }

		$cCreance     = self::compteId( self::compteCreance(), 'Plateformes — revenus à recevoir' );
		$cCommission  = self::compteId( self::compte( 'commission', '706176' ), 'Commissions de distribution musicale' );
		$cDetteArtiste = self::compteId( self::compte( 'dette_artiste', '467400' ), 'Artistes — parts à reverser' );
		if ( ! $cCreance || ! $cCommission || ! $cDetteArtiste ) { return null; }

		$dev  = isset( $fx['devise'] ) ? strtoupper( (string) $fx['devise'] ) : null;
		$taux = isset( $fx['taux'] ) ? (float) $fx['taux'] : null;
		$pivot = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';
		$trace = ( $dev && $dev !== $pivot && $taux > 0 );
		$fxCreance = $trace ? array( 'devise' => $dev, 'montant_devise' => isset( $fx['brut_devise'] ) ? (float) $fx['brut_devise'] : null, 'taux_change' => $taux ) : array();
		// Poste créditeur (dette) : montant en devise négatif, même convention que FKC_LabelComptable.
		$fxDette = $trace ? array( 'devise' => $dev, 'montant_devise' => -1 * ( isset( $fx['ayants_devise'] ) ? (float) $fx['ayants_devise'] : 0 ), 'taux_change' => $taux ) : array();

		$lignes = array(
			array_merge( array( 'compte_id' => $cCreance, 'libelle' => $libelle, 'debit' => $totalBrut, 'credit' => 0 ), $fxCreance ),
			array( 'compte_id' => $cCommission, 'libelle' => 'Commission de distribution', 'debit' => 0, 'credit' => $commission ),
		);
		if ( $totalArtiste > 0 ) {
			$lignes[] = array_merge( array( 'compte_id' => $cDetteArtiste, 'libelle' => 'Part artiste à reverser', 'debit' => 0, 'credit' => $totalArtiste ), $fxDette );
		}

		$entete = array( 'journal_id' => $jr, 'date_ecriture' => $date, 'piece' => 'DST',
			'libelle' => $libelle, 'reference' => 'Distribution musicale', 'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null );
		if ( ! empty( $opts['inventaire'] ) ) { $entete['inventaire'] = 1; }
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, array( 'source' => 'distribution_musicale' ) );
		self::$dernier = array( $ok ? $eid : null, $ok ? $bid : null, (string) $msg );
		return $ok ? ( $eid ?: $bid ) : null;
	}

	/** Comptabilise un règlement à un artiste : D 467400 / C 521000 — jamais confondu avec 401160 (Label), même principe que FKC_LabelComptable::ecriturePaiement(). */
	/**
	 * Décaissement au profit d'un ayant droit.
	 *
	 * Le compte de trésorerie est désormais CHOISI par le label ($compteTresorerie).
	 * Créditer systématiquement la banque envoyait comptablement hors banque
	 * un règlement fait en Mobile Money : le rapprochement bancaire ne tombait
	 * jamais juste, et le solde Mobile Money restait intact alors que l'argent
	 * en était sorti. Sans choix explicite, la banque reste le défaut.
	 */
	public static function ecriturePaiement( $montant, $date, $libelle, $compteTresorerie = '' ) {
		if ( ! self::possible() ) { return null; }
		$montant = round( (float) $montant, 0 ); if ( $montant <= 0 ) { return null; }
		$jr = self::journal(); if ( ! $jr ) { return null; }
		$cDette  = self::compteId( self::compte( 'dette_artiste', '467400' ), 'Artistes — parts à reverser' );
		$numTreso = trim( (string) $compteTresorerie ) ?: self::compte( 'banque', '521100' );
		$cBanque = self::compteId( $numTreso, 'Trésorerie' );
		if ( ! $cDette || ! $cBanque ) { return null; }
		$entete = array( 'journal_id' => $jr, 'date_ecriture' => $date, 'piece' => 'PAY-ART',
			'libelle' => $libelle, 'reference' => 'Règlement artiste', 'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null );
		$lignes = array(
			array( 'compte_id' => $cDette, 'libelle' => $libelle, 'debit' => $montant, 'credit' => 0 ),
			array( 'compte_id' => $cBanque, 'libelle' => $libelle, 'debit' => 0, 'credit' => $montant ),
		);
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, $lignes, array( 'source' => 'distribution_musicale' ) );
		return $ok ? ( $eid ?: $bid ) : null;
	}
}
