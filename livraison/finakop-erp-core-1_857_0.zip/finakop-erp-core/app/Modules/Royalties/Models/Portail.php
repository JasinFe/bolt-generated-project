<?php
/** Portail artiste : accès en lecture (streams, royalties, paiements, contrats). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Portail {
	public static function token( $artisteId ) {
		$r = FKC_DB::q( 'SELECT token FROM lbl_portail_tokens WHERE artiste_id=?', array( (int) $artisteId ) )->fetch();
		if ( $r ) { return $r['token']; }
		$tok = substr( bin2hex( random_bytes( 16 ) ), 0, 24 );
		FKC_DB::q( 'INSERT INTO lbl_portail_tokens(artiste_id,token,actif) VALUES(?,?,1)', array( (int) $artisteId, $tok ) );
		return $tok;
	}
	public static function artisteParToken( $token ) {
		$r = FKC_DB::q( 'SELECT artiste_id FROM lbl_portail_tokens WHERE token=? AND actif=1', array( (string) $token ) )->fetch();
		return $r ? FKC_Artiste::find( $r['artiste_id'] ) : null;
	}
	/** Données visibles par l'artiste. */
	public static function donnees( $artisteId ) {
		$streams = (int) FKC_DB::q( 'SELECT COALESCE(SUM(streams),0) FROM lbl_royalty_lignes WHERE artiste_id=?', array( (int) $artisteId ) )->fetchColumn();
		/*
		 * Total EN DEVISE DES COMPTES, relevé par relevé.
		 *
		 * Le SUM() direct additionnait les montants bruts des relevés — des
		 * euros, des dollars — et l'écran les affichait au format du franc.
		 * L'artiste lisait donc environ 650 fois moins que son dû réel, sur
		 * l'écran même qui lui sert à vérifier ce qu'il a gagné.
		 */
		$loc = FKC_Royalty::localiser( FKC_DB::q(
			'SELECT import_id, COALESCE(SUM(montant_artiste),0) montant FROM lbl_royalty_lignes WHERE artiste_id=? GROUP BY import_id',
			array( (int) $artisteId ) )->fetchAll() );
		$royaltiesTotal = (float) $loc['total'];
		return array(
			'artiste'   => FKC_Artiste::find( $artisteId ),
			'streams'   => $streams,
			'royalties' => $royaltiesTotal,
			'solde'     => FKC_Paiement::soldeArtiste( $artisteId ),
			'paiements' => FKC_Paiement::forArtiste( $artisteId ),
			'oeuvres'   => FKC_DB::q( 'SELECT * FROM lbl_oeuvres WHERE artiste_id=? ORDER BY date_sortie DESC', array( (int) $artisteId ) )->fetchAll(),
		);
	}
}
