<?php
/** Événements & concerts : lieu, date, cachet, billetterie. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Concert {
	public static function statuts() { return array( 'planifie'=>'Planifié','confirme'=>'Confirmé','realise'=>'Réalisé','annule'=>'Annulé' ); }
	public static function types() { return array( 'concert'=>'Concert','tournee'=>'Tournée','showcase'=>'Showcase','festival'=>'Festival' ); }

	public static function all() {
		return FKC_DB::q( 'SELECT c.*, a.nom_scene, a.nom artiste_nom,
			(c.billets_vendus*c.billet_prix) recettes FROM lbl_concerts c LEFT JOIN lbl_artistes a ON a.id=c.artiste_id ORDER BY c.date DESC, c.id DESC' )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM lbl_concerts WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_concerts(titre,lieu,date,cachet,billets_vendus,billet_prix,artiste_id,statut,type,note) VALUES(?,?,?,?,?,?,?,?,?,?)',
			array( trim( (string) $d['titre'] ), trim( (string) ( $d['lieu'] ?? '' ) ) ?: null, trim( (string) ( $d['date'] ?? '' ) ) ?: null,
				(float) ( $d['cachet'] ?? 0 ), (int) ( $d['billets_vendus'] ?? 0 ), (float) ( $d['billet_prix'] ?? 0 ),
				! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null,
				isset( self::statuts()[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'planifie',
				isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'concert', trim( (string) ( $d['note'] ?? '' ) ) ?: null ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_concerts WHERE id=?', array( (int) $id ) ); }
	public static function countAvenir() { return (int) FKC_DB::q( "SELECT COUNT(*) FROM lbl_concerts WHERE statut IN('planifie','confirme')" )->fetchColumn(); }
	public static function resultat( $c ) { return (float) $c['billets_vendus'] * (float) $c['billet_prix'] - (float) $c['cachet']; }
}
