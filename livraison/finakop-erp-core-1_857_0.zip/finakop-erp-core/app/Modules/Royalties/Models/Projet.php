<?php
/** Projets musicaux : budget (production, marketing, distribution), coût, revenus, profit. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Projet {
	public static function statuts() { return array( 'en_cours'=>'En cours','termine'=>'Terminé','annule'=>'Annulé' ); }
	public static function all() {
		return FKC_DB::q( 'SELECT p.*, a.nom_scene, a.nom artiste_nom,
			(p.budget_production+p.budget_marketing+p.budget_distribution+p.budget_autre) budget_total
			FROM lbl_projets p LEFT JOIN lbl_artistes a ON a.id=p.artiste_id ORDER BY p.created_at DESC, p.id DESC' )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM lbl_projets WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	/** Total projets (quota de licence). */
	public static function count() { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM lbl_projets' )->fetchColumn(); }
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO lbl_projets(code,titre,artiste_id,budget_production,budget_marketing,budget_distribution,budget_autre,cout,revenus,statut,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
			array( trim( (string) ( $d['code'] ?? '' ) ) ?: null, trim( (string) $d['titre'] ),
				! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null,
				(float) ( $d['budget_production'] ?? 0 ), (float) ( $d['budget_marketing'] ?? 0 ),
				(float) ( $d['budget_distribution'] ?? 0 ), (float) ( $d['budget_autre'] ?? 0 ),
				(float) ( $d['cout'] ?? 0 ), (float) ( $d['revenus'] ?? 0 ),
				isset( self::statuts()[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'en_cours', trim( (string) ( $d['note'] ?? '' ) ) ?: null ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		FKC_DB::q( 'UPDATE lbl_projets SET titre=?,artiste_id=?,budget_production=?,budget_marketing=?,budget_distribution=?,budget_autre=?,cout=?,revenus=?,statut=?,note=? WHERE id=?',
			array( trim( (string) $d['titre'] ), ! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null,
				(float) ( $d['budget_production'] ?? 0 ), (float) ( $d['budget_marketing'] ?? 0 ),
				(float) ( $d['budget_distribution'] ?? 0 ), (float) ( $d['budget_autre'] ?? 0 ),
				(float) ( $d['cout'] ?? 0 ), (float) ( $d['revenus'] ?? 0 ),
				isset( self::statuts()[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'en_cours', trim( (string) ( $d['note'] ?? '' ) ) ?: null, (int) $id ) );
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM lbl_projets WHERE id=?', array( (int) $id ) ); }
	public static function profit( $p ) { return (float) $p['revenus'] - (float) $p['cout']; }
}
