<?php
/**
 * Royalties : import des relevés de DISTRIBUTEURS (TuneCore, DistroKid, Ditto…),
 * répartition automatique par ayant droit, comptabilisation.
 *
 * IMPORTANT — modèle métier réel : un label ne reçoit pas ses relevés des
 * plateformes de streaming (Spotify, Apple, YouTube) mais de son DISTRIBUTEUR,
 * qui agrège toutes les plateformes dans un seul rapport. La « source » d'un
 * relevé est donc un distributeur ; la « plateforme » (le magasin) est une
 * colonne de chaque ligne. L'imputation à une œuvre se fait par l'ISRC (ou
 * l'UPC), identifiants universels présents dans les rapports.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Royalty {

	/**
	 * Quelle comptabilisation utiliser — Label (FKC_LabelComptable,
	 * méthode brute, comptes 706100/644100/401160) ou Distribution
	 * (FKC_DistributionComptable, méthode nette, comptes séparés
	 * 411122/706176/467400) ?
	 *
	 * Choix de l'utilisateur (chantier « Distribution », 1.520.66) : les
	 * deux jeux de comptes restent VOLONTAIREMENT séparés, jamais
	 * fusionnés — le pack actif décide lequel s'applique. Le principal
	 * l'emporte en multi-pack (même convention que FKC_Term pour un
	 * module que personne ne revendique explicitement) ; par défaut,
	 * c'est toujours Label — aucun pack existant avant ce chantier n'a
	 * pu changer de comportement.
	 */
	public static function comptablePourPackActif() {
		if ( class_exists( 'FKC_Packs' ) && 'distribution_musicale' === FKC_Packs::activeCode() ) { return 'distribution'; }
		return 'label';
	}

	/** Distributeurs (la SOURCE d'un relevé). */
	public static function sources() {
		return array(
			'tunecore'  => 'TuneCore',
			'distrokid' => 'DistroKid',
			'ditto'     => 'Ditto Music',
			'cdbaby'    => 'CD Baby',
			'believe'   => 'Believe / TuneCore',
			'onerpm'    => 'ONErpm',
			'amuse'     => 'Amuse',
			'awal'      => 'AWAL',
			'symphonic' => 'Symphonic',
			'autre'     => 'Autre distributeur',
		);
	}

	/** Plateformes / magasins (une COLONNE de chaque ligne, agrégée par le distributeur). */
	public static function plateformes() {
		return array( 'Spotify', 'Apple/iTunes', 'YouTube', 'Amazon', 'Deezer', 'Boomplay', 'Audiomack', 'TikTok', 'Tidal', 'Napster', 'Anghami', 'Autre' );
	}

	/**
	 * Compte de revenu. Le distributeur mélange les plateformes dans un seul
	 * versement : on comptabilise en revenus de distribution numérique (706100
	 * pour le Label, 706176 — la commission seule — pour Distribution
	 * musicale), la ventilation par plateforme restant analytique.
	 */
	public static function compteSource( $source ) {
		/*
		 * 706510 « Streaming musical en ligne » (1.794.0) et non 706100, qui est
		 * 7061 « Services vendus dans la Région » du référentiel : un revenu de
		 * plateforme est un service vendu SUR INTERNET (7065). Le label garde
		 * son suivi ligne à ligne, la liasse agrège au bon poste.
		 */
		return 'distribution' === self::comptablePourPackActif() ? '706176' : '706510';
	}

	/**
	 * Migration additive idempotente : colonnes nées du support des rapports
	 * distributeurs réels (ISRC, pays, plateforme déjà présente, devise
	 * d'origine). Appelée à chaque usage — ne fait rien si déjà en place.
	 */
	public static function ensureSchema() {
				/*
		 * Sentinelle indexée par BASE DE DONNÉES, et non un simple booléen.
		 *
		 * Un cabinet qui enchaîne deux dossiers dans la même requête — clôture
		 * de portefeuille, tâche planifiée, appel API — voyait la seconde
		 * société privée de ces tables : la sentinelle était déjà levée par la
		 * première, et le schéma n'était jamais créé. Les écritures échouaient
		 * alors sans que la cause soit lisible.
		 */
		static $faits = array();
		$cle = FKC_DB::file();
		if ( isset( $faits[ $cle ] ) ) { return; }
		$faits[ $cle ] = true;
		$add = function ( $table, $cols ) {
			$existing = array();
			foreach ( FKC_DB::conn()->query( "PRAGMA table_info({$table})" ) as $c ) { $existing[] = $c['name']; }
			foreach ( $cols as $name => $def ) {
				if ( ! in_array( $name, $existing, true ) ) {
					try { FKC_DB::conn()->exec( "ALTER TABLE {$table} ADD COLUMN {$name} {$def}" ); } catch ( \Throwable $e ) { /* course bénigne */ }
				}
			}
		};
		$add( 'lbl_oeuvres', array( 'isrc' => 'TEXT' ) );
		$add( 'lbl_royalty_lignes', array(
			'isrc'          => 'TEXT',
			'pays'          => 'TEXT',
			'unites'        => 'INTEGER DEFAULT 0',
			'devise_source' => 'TEXT',
			/*
			 * 1.744.0 — ce que le distributeur a ÉCRIT, conservé tel quel.
			 * Sans le titre et l'artiste d'origine, une ligne non rattachée
			 * n'était plus qu'un montant : impossible de dire à quelle
			 * chanson il revenait, donc impossible de l'attribuer.
			 */
			'titre_source'   => 'TEXT',
			'artiste_source' => 'TEXT',
			// 'label' quand l'utilisateur a DÉCIDÉ que ce revenu est au label.
			'attribution'    => 'TEXT',
			/*
			 * 1.746.0 — VENTILATION MULTI-ARTISTES.
			 *
			 * Une ligne du relevé créditant « A feat. B » produit désormais
			 * une ligne PAR artiste. On garde la fraction qui lui a été
			 * attribuée, la règle qui l'a décidée et le rôle tenu, faute de
			 * quoi un décompte contesté serait invérifiable : on verrait un
			 * montant sans savoir pourquoi il vaut la moitié du relevé.
			 */
			// fraction     : part de la ligne d'origine (1 = seul crédité)
			// regle_ventil : bareme_titre | bareme_collab | bareme_incomplet | collab_auto | aucun
			// role_ligne   : interprete | featuring
			/*
			 * CRÉDIT D'ORIGINE (1.750.0) — la chaîne exacte écrite par le
			 * distributeur, « Didi B feat. Suspect 95 », AVANT éclatement.
			 *
			 * Sans elle, un barème créé après l'import restait lettre morte :
			 * les lignes portaient déjà leur fraction, et plus rien ne disait
			 * de quel crédit elles étaient issues ni comment les regrouper
			 * pour les répartir autrement. Il fallait réimporter le fichier —
			 * que l'ERP ne conserve pas.
			 */
			'credit_source' => 'TEXT',
			/*
			 * 1.779.0 — MOIS DE CONSOMMATION de la ligne (« AAAA-MM »), lu
			 * dans la colonne « Sales Period » / « Période » du fichier. C'est
			 * lui, et non la date du relevé, qui rattache le revenu à son
			 * exercice (FKC_RnPeriode).
			 */
			'periode'      => 'TEXT',
			'fraction'     => 'REAL',
			'regle_ventil' => 'TEXT',
			'role_ligne'   => 'TEXT',
		) );
		$add( 'lbl_royalty_imports', array(
			'devise'        => "TEXT DEFAULT 'EUR'",
			'total_unites'  => 'INTEGER DEFAULT 0',
			'nb_lignes'     => 'INTEGER DEFAULT 0',
			// Cours figé à la comptabilisation (écrit par comptabiliser()
			// depuis 1.520 sans que la colonne soit déclarée ici).
			'taux_change'   => 'REAL',
		) );
		/*
		 * RÉPARTITION FIGÉE (1.744.0). Un relevé comptabilisé a donné lieu à
		 * une écriture et à des dus : son décompte ne doit plus bouger si l'on
		 * modifie ensuite un split ou la part d'une fiche artiste. On garde
		 * donc ce qui a été réparti, ligne par ligne, avec sa contre-valeur.
		 */
		try {
			FKC_DB::conn()->exec( "CREATE TABLE IF NOT EXISTS lbl_royalty_repartition(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				import_id INTEGER NOT NULL, oeuvre_id INTEGER, titre TEXT,
				ayant_droit TEXT NOT NULL, artiste_id INTEGER, role TEXT, part REAL,
				montant REAL NOT NULL DEFAULT 0, montant_local REAL NOT NULL DEFAULT 0
			)" );
			FKC_DB::conn()->exec( 'CREATE INDEX IF NOT EXISTS idx_lrr_imp ON lbl_royalty_repartition(import_id)' );
		} catch ( \Throwable $e ) {}
	}

	public static function imports() {
		self::ensureSchema();
		return FKC_DB::q( 'SELECT * FROM lbl_royalty_imports ORDER BY created_at DESC, id DESC' )->fetchAll();
	}
	/** Nombre de lignes de calcul de royalties enregistrées le mois courant (quota mensuel). */
	public static function countMois( $ym = null ) {
		$ym = $ym ?: date( 'Y-m' );
		return (int) FKC_DB::q(
			'SELECT COUNT(*) FROM lbl_royalty_lignes l JOIN lbl_royalty_imports i ON i.id=l.import_id WHERE substr(i.date,1,7)=?',
			array( $ym )
		)->fetchColumn();
	}

	public static function createImport( $source, $periode, $date = null, $devise = 'EUR' ) {
		self::ensureSchema();
		if ( ! array_key_exists( $source, self::sources() ) ) { $source = 'autre'; }
		$devise = strtoupper( trim( (string) $devise ) ) ?: 'EUR';
		FKC_DB::q( 'INSERT INTO lbl_royalty_imports(source,periode,statut,date,devise) VALUES(?,?,?,?,?)',
			array( $source, trim( (string) $periode ) ?: null, 'importe', $date ?: date( 'Y-m-d' ), $devise ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/** Mois « AAAA-MM » d'une ligne de relevé, ou null (jamais deviné). */
	public static function moisLigne( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return null; }
		return class_exists( 'FKC_RnPeriode' ) ? FKC_RnPeriode::moisDe( $v ) : ( preg_match( '/^\d{4}-\d{2}$/', $v ) ? $v : null );
	}

	/** En-têtes qui désignent la période de CONSOMMATION (jamais la date de paiement). */
	public static function entetesPeriode() {
		return array( 'sales period', 'sale period', 'sales month', 'sale month', 'reporting period', 'usage period',
			'accounting period', 'period', 'période', 'periode', 'mois', 'month' );
	}

	/** Part de l'artiste selon SA FICHE, lue au moment où on la demande. */
	public static function partFiche( $artisteId ) {
		if ( ! $artisteId ) { return 0.0; }
		$a = FKC_Artiste::find( (int) $artisteId );
		return $a ? max( 0.0, min( 100.0, (float) $a['part_artiste'] ) ) : 0.0;
	}

	/**
	 * Ajoute une ligne et calcule la répartition selon la part de l'artiste.
	 *
	 * Une ligne SANS artiste ni œuvre n'est plus versée au label (1.744.0) :
	 * elle reste « non attribuée » et bloque la comptabilisation jusqu'à ce
	 * qu'on dise à qui elle revient. Donner au label un revenu dont on ne
	 * connaît pas le titulaire, c'était retirer à un artiste ce qu'il a gagné.
	 */
	public static function addLigne( $importId, $d ) {
		self::ensureSchema();
		$artisteId = ! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null;
		$oeuvreId  = ! empty( $d['oeuvre_id'] ) ? (int) $d['oeuvre_id'] : null;
		if ( ! $artisteId && $oeuvreId ) {
			$o = FKC_Oeuvre::find( $oeuvreId );
			$artisteId = $o && $o['artiste_id'] ? (int) $o['artiste_id'] : null;
		}
		$part = self::partFiche( $artisteId );
		$brut = round( (float) ( $d['montant_brut'] ?? 0 ), 2 );
		$mArtiste = $artisteId ? round( $brut * $part / 100, 2 ) : 0.0;
		$mLabel   = $artisteId ? round( $brut - $mArtiste, 2 ) : 0.0;
		$devise = trim( (string) ( $d['devise_source'] ?? '' ) );
		if ( '' === $devise ) {
			$devise = (string) FKC_DB::q( 'SELECT devise FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetchColumn();
		}
		/*
		 * Une ligne issue d'une ventilation multi-artistes porte la part du
		 * relevé qui lui revient (« fraction ») et la règle qui l'a décidée.
		 * Une ligne ordinaire vaut 1 : elle est seule créditée.
		 */
		$fraction = isset( $d['fraction'] ) ? max( 0.0, min( 1.0, (float) $d['fraction'] ) ) : 1.0;
		FKC_DB::q( 'INSERT INTO lbl_royalty_lignes(import_id,artiste_id,oeuvre_id,plateforme,isrc,pays,streams,unites,montant_brut,devise_source,part_artiste,montant_artiste,montant_label,titre_source,artiste_source,credit_source,fraction,regle_ventil,role_ligne,attribution,periode) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array( (int) $importId, $artisteId, $oeuvreId, trim( (string) ( $d['plateforme'] ?? '' ) ) ?: null,
				trim( (string) ( $d['isrc'] ?? '' ) ) ?: null, trim( (string) ( $d['pays'] ?? '' ) ) ?: null,
				(int) ( $d['streams'] ?? 0 ), (int) ( $d['unites'] ?? $d['streams'] ?? 0 ), $brut,
				strtoupper( $devise ) ?: null, $artisteId ? $part : 0.0, $mArtiste, $mLabel,
				trim( (string) ( $d['titre'] ?? '' ) ) ?: null, trim( (string) ( $d['artiste_nom'] ?? '' ) ) ?: null,
				trim( (string) ( $d['credit_source'] ?? '' ) ) ?: null,
				$fraction, trim( (string) ( $d['regle_ventil'] ?? '' ) ) ?: null,
				trim( (string) ( $d['role_ligne'] ?? '' ) ) ?: null,
				trim( (string) ( $d['attribution'] ?? '' ) ) ?: null,
				self::moisLigne( $d['periode'] ?? '' ) ) );
		$lid = (int) FKC_DB::conn()->lastInsertId();
		self::recomputeTotal( $importId );
		return $lid;
	}

	/**
	 * VENTILE une ligne de relevé en une ou plusieurs entrées d'agrégat.
	 *
	 * Point d'entrée unique des deux importeurs : un rapport crédite
	 * « Didi B feat. Suspect 95 », et il faut en sortir deux lignes, chacune
	 * avec sa fraction du montant. Sans ce passage, la chaîne entière était
	 * cherchée telle quelle dans le roster, jamais trouvée, et la ligne
	 * partait en « non attribué » — à ré-attribuer à chaque relevé.
	 *
	 * @return array<int, array{artiste_id:?int, nom:string, fraction:float,
	 *                          role:string, regle:string, label:bool}>
	 *         Une entrée par bénéficiaire ; la part du label sort en entrée
	 *         marquée `label` pour rester visible plutôt que de disparaître.
	 */
	public static function ventilerLigne( $artisteBrut, $isrc = '' ) {
		$artisteBrut = trim( (string) $artisteBrut );
		if ( '' === $artisteBrut || ! class_exists( 'FKC_LabelBareme' ) ) {
			return array( array( 'artiste_id' => null, 'nom' => $artisteBrut, 'fraction' => 1.0,
				'role' => 'interprete', 'regle' => 'aucun', 'label' => false ) );
		}
		$v = FKC_LabelBareme::ventiler( $artisteBrut, $isrc );
		// Mémorise chaque nom crédité : c'est ce qui alimente l'écran de
		// rattachement, et ce qui rend le relevé suivant automatique.
		foreach ( $v['noms'] as $nom ) { FKC_LabelBareme::apprendreNom( $nom ); }

		$out = array();
		foreach ( $v['parts'] as $p ) {
			$out[] = array( 'artiste_id' => $p['artiste_id'], 'nom' => $p['nom'], 'fraction' => (float) $p['fraction'],
				'role' => $p['role'], 'regle' => $v['regle'], 'label' => false );
		}
		if ( $v['fraction_label'] > 0.0001 ) {
			$out[] = array( 'artiste_id' => null, 'nom' => 'Label', 'fraction' => (float) $v['fraction_label'],
				'role' => 'label', 'regle' => $v['regle'], 'label' => true );
		}
		if ( ! $out ) {
			$out[] = array( 'artiste_id' => null, 'nom' => $artisteBrut, 'fraction' => 1.0,
				'role' => 'interprete', 'regle' => $v['regle'], 'label' => false );
		}
		return $out;
	}

	/**
	 * Devises présentes dans un fichier de relevé (colonne Currency/Devise).
	 *
	 * Un relevé = une devise. Un fichier qui en mêle plusieurs ne peut pas
	 * être additionné tel quel — c'était le cas : 10 USD + 10 EUR faisaient
	 * « 20 EUR ». On le détecte AVANT de créer quoi que ce soit.
	 *
	 * @return string[]
	 */
	public static function devisesDuFichier( $csv ) {
		$rows = self::parseCsv( $csv );
		if ( count( $rows ) < 2 ) { return array(); }
		$header = array_map( fn( $c ) => strtolower( trim( (string) $c ) ), $rows[0] );
		$i = false;
		foreach ( array( 'currency', 'devise', 'currency code' ) as $n ) {
			$i = array_search( $n, $header, true );
			if ( false !== $i ) { break; }
		}
		if ( false === $i ) { return array(); }
		$out = array();
		for ( $r = 1; $r < count( $rows ); $r++ ) {
			$c = strtoupper( trim( (string) ( $rows[ $r ][ $i ] ?? '' ) ) );
			if ( '' !== $c ) { $out[ $c ] = true; }
		}
		return array_keys( $out );
	}

	/**
	 * Rattache une œuvre à partir d'un ISRC / UPC / titre, et remonte l'artiste.
	 * @return array{int|null, int|null} ( oeuvre_id|null, artiste_id|null )
	 */
	/** Code identifiant réduit à ses caractères significatifs (ISRC, UPC). */
	public static function cleCode( $code ) {
		return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $code ) );
	}

	/** Table de repli des lettres accentuées, partagée par les deux clés. */
	protected static function sansAccents() {
		return array(
			'à'=>'a','á'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a',
			'è'=>'e','é'=>'e','ê'=>'e','ë'=>'e',
			'ì'=>'i','í'=>'i','î'=>'i','ï'=>'i',
			'ò'=>'o','ó'=>'o','ô'=>'o','ö'=>'o','õ'=>'o',
			'ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u',
			'ç'=>'c','ñ'=>'n','ý'=>'y','ÿ'=>'y','œ'=>'oe','æ'=>'ae',
			'’'=>"'", '‘'=>"'", '`'=>"'", '´'=>"'", '–'=>'-', '—'=>'-',
		);
	}

	/**
	 * ═══════════════════════════════════════════════════════════════════
	 *  CLÉ DE RAPPROCHEMENT D'UN TITRE
	 * ═══════════════════════════════════════════════════════════════════
	 *  Le rapprochement se faisait par `titre = ? COLLATE NOCASE`. Deux
	 *  pièges s'y cachaient :
	 *
	 *   — `NOCASE` de SQLite ne replie QUE les lettres ASCII. « Éternel » et
	 *     « éternel » y sont deux titres différents. Sur un catalogue
	 *     francophone, cela concerne la plupart des titres accentués ;
	 *   — l'apostrophe du distributeur est typographique (’), celle saisie
	 *     au clavier est droite ('). « L'Aîné » ne rencontrait jamais
	 *     « L’Aîné ».
	 *
	 *  La clé retire donc les accents, unifie les apostrophes, réduit toute
	 *  ponctuation à un espace et replie la casse. « L'AÎNÉ (Radio Edit) »
	 *  et « l’aine (radio edit) » deviennent la même chaîne.
	 * ═══════════════════════════════════════════════════════════════════
	 */
	public static function cleTitreOeuvre( $titre ) {
		$t = (string) $titre;
		$t = function_exists( 'mb_strtolower' ) ? mb_strtolower( $t, 'UTF-8' ) : strtolower( $t );
		$t = strtr( $t, self::sansAccents() );
		$t = preg_replace( '/[^a-z0-9]+/u', ' ', $t );
		return trim( preg_replace( '/\s+/', ' ', (string) $t ) );
	}

	/**
	 * Titre débarrassé de sa mention de version : « (Deluxe) », « [Remix] »,
	 * « - Radio Edit », « feat. X ».
	 *
	 * Un distributeur écrit « TITRE (Deluxe Version) » là où le catalogue
	 * porte « TITRE ». C'est la même œuvre, et le dernier essai de la cascade
	 * la retrouve — mais seulement APRÈS l'essai exact, pour ne jamais
	 * confondre deux versions réellement distinctes du catalogue.
	 */
	public static function cleTitreBase( $titre ) {
		$t = (string) $titre;
		$t = preg_replace( '/\s*[\(\[][^\)\]]*[\)\]]\s*/u', ' ', $t );
		$p = preg_split( '/\s+-\s+|\s+(?:feat\.?|ft\.?|featuring|with)\s+/iu', $t );
		return self::cleTitreOeuvre( $p[0] ?? $t );
	}

	/**
	 * Index du catalogue, construit une fois par requête.
	 *
	 * L'ancienne version lançait jusqu'à trois SELECT par ligne de relevé —
	 * plusieurs milliers sur un rapport mensuel. Un index en mémoire coûte
	 * une requête, et rend la comparaison possible en PHP : c'est la seule
	 * façon de replier correctement les accents, ce que SQLite ne sait pas
	 * faire sur des caractères non ASCII.
	 *
	 * @return array{isrc: array, upc: array, titre: array, base: array}
	 */
	protected static function indexCatalogue( $vider = false ) {
		static $idx = null;
		if ( $vider ) { $idx = null; return array( 'isrc' => array(), 'upc' => array(), 'titre' => array(), 'base' => array() ); }
		if ( null !== $idx ) { return $idx; }
		$idx = array( 'isrc' => array(), 'upc' => array(), 'titre' => array(), 'base' => array() );
		try { $rows = FKC_DB::q( 'SELECT id, titre, isrc, upc, artiste_id FROM lbl_oeuvres' )->fetchAll(); }
		catch ( \Throwable $e ) { return $idx; }
		foreach ( $rows as $o ) {
			$k = self::cleCode( $o['isrc'] ?? '' );
			if ( '' !== $k && ! isset( $idx['isrc'][ $k ] ) ) { $idx['isrc'][ $k ] = $o; }
			$k = self::cleCode( $o['upc'] ?? '' );
			if ( '' !== $k && ! isset( $idx['upc'][ $k ] ) ) { $idx['upc'][ $k ] = $o; }
			$k = self::cleTitreOeuvre( $o['titre'] ?? '' );
			if ( '' !== $k && ! isset( $idx['titre'][ $k ] ) ) { $idx['titre'][ $k ] = $o; }
			/*
			 * Le repli « sans mention de version » n'est retenu que s'il est
			 * NON AMBIGU : si deux œuvres du catalogue se réduisent à la même
			 * base, on ne devine pas laquelle. Mieux vaut une ligne non
			 * rattachée, qui se voit, qu'une ligne attribuée au mauvais titre,
			 * qui ne se voit pas.
			 */
			$k = self::cleTitreBase( $o['titre'] ?? '' );
			if ( '' !== $k ) {
				if ( array_key_exists( $k, $idx['base'] ) ) { $idx['base'][ $k ] = false; }
				else { $idx['base'][ $k ] = $o; }
			}
		}
		return $idx;
	}

	/** À appeler après création, modification ou suppression d'une œuvre. */
	public static function oublierCatalogue() { self::indexCatalogue( true ); }

	/**
	 * Le nom crédité sur la ligne désigne-t-il l'artiste de cette œuvre ?
	 *
	 * Le seul témoin dont on dispose quand le titre ne concorde qu'« à peu
	 * près ». La résolution passe par la table des noms du distributeur, si
	 * bien qu'un nom rattaché une fois à la main vaut corroboration pour tous
	 * les relevés suivants : le geste humain ne se redemande pas.
	 *
	 * Une œuvre SANS artiste au catalogue ne peut rien corroborer — il n'y a
	 * personne à reconnaître. La ligne reste alors non attribuée, ce qui est
	 * la description exacte de la situation : on ne sait ni de quelle œuvre il
	 * s'agit, ni à qui elle revient.
	 */
	protected static function corrobore( $oeuvre, $nom ) {
		$aOeuvre = (int) ( $oeuvre['artiste_id'] ?? 0 );
		$nom     = trim( (string) $nom );
		if ( ! $aOeuvre || '' === $nom ) { return false; }
		$aNom = null;
		try {
			if ( class_exists( 'FKC_LabelBareme' ) ) {
				$r    = FKC_LabelBareme::resoudre( $nom );
				$aNom = $r['artiste_id'] ?? null;
			} else {
				$a = FKC_DB::q( 'SELECT id FROM lbl_artistes WHERE nom_scene=? COLLATE NOCASE OR nom=? COLLATE NOCASE LIMIT 1',
					array( $nom, $nom ) )->fetch();
				$aNom = $a ? (int) $a['id'] : null;
			}
		} catch ( \Throwable $e ) { return false; }
		return $aNom && (int) $aNom === $aOeuvre;
	}

	/**
	 * LE DERNIER ESSAI DE LA CASCADE DEVAIT ÊTRE CORROBORÉ (1.787.0).
	 *
	 * ═══════════════════════════════════════════════════════════════════
	 * Le rapprochement par TITRE DE BASE — celui qui retire « (Radio Edit) »,
	 * « (Deluxe) » ou « - Remix » — attribuait une ligne à lui tout seul, sans
	 * qu'aucun autre élément ne le confirme. Il suffisait qu'un titre de relevé
	 * se réduise au titre d'une œuvre du catalogue pour que la ligne prenne
	 * l'artiste de cette œuvre, même lorsque :
	 *
	 *   — l'ISRC du relevé était ABSENT du catalogue, donc ne confirmait rien ;
	 *   — le nom crédité par le distributeur n'était RECONNU PAR PERSONNE —
	 *     « M. Drick » quand la fiche porte « Mdrick », ce qui peut être la
	 *     même personne comme un homonyme approximatif ;
	 *   — aucun nom n'était crédité du tout.
	 *
	 * Un titre de base est une ressemblance, pas une identité : deux artistes
	 * peuvent sortir « Renaissance », et un distributeur écrit rarement les
	 * noms comme le catalogue. Attribuer sur cette seule base, c'est verser de
	 * l'argent à quelqu'un parce que son titre y ressemble — et une part versée
	 * au mauvais ayant droit ne se rattrape pas : elle se réclame.
	 *
	 * C'est aussi l'exact contraire de la règle posée par le lot 1.744.0,
	 * « rien ne part au label par défaut », dont tout le propos est que le
	 * logiciel BLOQUE et DEMANDE plutôt que de deviner.
	 *
	 * ═══════════════════════════════════════════════════════════════════
	 * CE QUI CHANGE, ET CE QUI NE CHANGE PAS
	 *
	 * Le rapprochement par titre de base reste — il répond à un vrai besoin,
	 * « TITRE (Deluxe Version) » chez le distributeur pour « TITRE » au
	 * catalogue —, mais il exige désormais d'être CORROBORÉ : le nom crédité
	 * sur la ligne doit désigner l'artiste de l'œuvre candidate. Le même relevé
	 * signé « Mdrick » s'attribue donc toujours tout seul.
	 *
	 * Les autres essais de la cascade ne bougent pas d'un iota : un ISRC, un
	 * UPC ou un titre EXACT identifient une œuvre sans avoir besoin de témoin.
	 * Seule la ressemblance en demande un.
	 *
	 * Une ligne laissée non attribuée n'est pas perdue : elle s'affiche sur
	 * l'écran des titres non rattachés, une attribution manuelle MÉMORISE son
	 * ISRC au catalogue, et le relevé suivant se rattache alors par le code —
	 * sans ressemblance et sans témoin.
	 *
	 * @param string $isrc
	 * @param string $upc
	 * @param string $titre
	 * @param string $artisteNom Nom du bénéficiaire de cette part.
	 * @param string $credit     Nom crédité par le distributeur sur la LIGNE,
	 *                           quand il diffère — la part label n'a pas de
	 *                           bénéficiaire nommé, mais la ligne, elle, en a
	 *                           un, et c'est lui qui corrobore.
	 */
	public static function rattacher( $isrc, $upc, $titre, $artisteNom = '', $credit = null ) {
		$e = self::etapeRattachement( $isrc, $upc, $titre, $artisteNom, $credit );
		return array( $e['oeuvre_id'], $e['artiste_id'] );
	}

	/**
	 * Le rattachement, ET l'étape de la cascade qui l'a produit (1.788.0).
	 *
	 * `rattacher()` rendait deux identifiants sans dire d'où ils venaient. On
	 * ne pouvait donc pas répondre à la question que pose l'état de contrôle
	 * des attributions : « cette ligne a-t-elle été attribuée par un CODE, ou
	 * par une simple ressemblance de titre ? » — alors que c'est toute la
	 * différence entre une certitude et un pari.
	 *
	 * Recalculer l'étape ailleurs aurait créé une seconde implémentation de la
	 * cascade, et donc, tôt ou tard, deux réponses différentes à la même
	 * question. `rattacher()` délègue ici et n'est plus qu'un raccourci.
	 *
	 * `etape` vaut : isrc | upc | titre | base | base_refusee | nom | aucune.
	 *
	 * @return array{oeuvre_id:?int, artiste_id:?int, etape:string, candidat:?int}
	 */
	public static function etapeRattachement( $isrc, $upc, $titre, $artisteNom = '', $credit = null ) {
		self::ensureSchema();
		$oeuvre = null;
		$etape = 'aucune';
		$candidat = null;
		$isrc = trim( (string) $isrc );
		$upc = trim( (string) $upc );
		$titre = trim( (string) $titre );
		$idx = self::indexCatalogue();

		/*
		 * Cascade, du plus sûr au plus tolérant. Les codes d'abord : un ISRC
		 * identifie une œuvre sans ambiguïté, un titre non.
		 *
		 * Les codes sont comparés SANS leurs séparateurs : un ISRC s'écrit
		 * « CI-A1B-26-00001 » chez l'un et « CIA1B2600001 » chez l'autre,
		 * c'est le même code. L'égalité stricte les tenait pour différents.
		 */
		if ( '' !== $isrc ) {
			$k = self::cleCode( $isrc );
			if ( '' !== $k && isset( $idx['isrc'][ $k ] ) ) { $oeuvre = $idx['isrc'][ $k ]; $etape = 'isrc'; }
		}
		if ( ! $oeuvre && '' !== $upc ) {
			$k = self::cleCode( $upc );
			if ( '' !== $k && isset( $idx['upc'][ $k ] ) ) { $oeuvre = $idx['upc'][ $k ]; $etape = 'upc'; }
		}
		if ( ! $oeuvre && '' !== $titre ) {
			$k = self::cleTitreOeuvre( $titre );
			if ( '' !== $k && isset( $idx['titre'][ $k ] ) ) { $oeuvre = $idx['titre'][ $k ]; $etape = 'titre'; }
		}
		/*
		 * Ressemblance de titre : elle ne vaut que corroborée. Voir l'en-tête.
		 *
		 * Et lorsqu'elle est REFUSÉE, la cascade s'arrête là. Une ressemblance
		 * qu'on ne peut pas confirmer n'est pas une absence d'information :
		 * c'est un DOUTE. Retomber ensuite sur le nom crédité pour payer
		 * l'artiste qu'il désigne reviendrait à deviner deux fois — d'abord
		 * que ce n'est pas l'œuvre qui lui ressemble, ensuite que c'est bien
		 * la personne nommée. La ligne part sur l'écran des titres non
		 * rattachés, où un humain tranche en un geste.
		 */
		$doute = false;
		if ( ! $oeuvre && '' !== $titre ) {
			$k = self::cleTitreBase( $titre );
			if ( '' !== $k && ! empty( $idx['base'][ $k ] ) ) {
				$temoin = null !== $credit ? $credit : $artisteNom;
				$candidat = (int) $idx['base'][ $k ]['id'];
				if ( self::corrobore( $idx['base'][ $k ], $temoin ) ) { $oeuvre = $idx['base'][ $k ]; $etape = 'base'; }
				else { $doute = true; $etape = 'base_refusee'; }
			}
		}
		$oeuvreId = $oeuvre ? (int) $oeuvre['id'] : null;
		$artisteId = $oeuvre && $oeuvre['artiste_id'] ? (int) $oeuvre['artiste_id'] : null;
		/*
		 * À défaut, l'artiste par son nom — en passant par la TABLE DES NOMS
		 * DU DISTRIBUTEUR (1.746.0). L'égalité stricte échouait sur tout ce
		 * qui n'était pas écrit exactement comme la fiche : « DIDI B »,
		 * « Didi-B », ou un nom déjà rattaché à la main au relevé précédent.
		 */
		if ( ! $artisteId && ! $doute && '' !== trim( (string) $artisteNom ) ) {
			if ( class_exists( 'FKC_LabelBareme' ) ) {
				$r = FKC_LabelBareme::resoudre( trim( (string) $artisteNom ) );
				$artisteId = $r['artiste_id'];
			} else {
				$a = FKC_DB::q( 'SELECT id FROM lbl_artistes WHERE nom_scene=? COLLATE NOCASE OR nom=? COLLATE NOCASE LIMIT 1',
					array( trim( $artisteNom ), trim( $artisteNom ) ) )->fetch();
				$artisteId = $a ? (int) $a['id'] : null;
			}
			if ( $artisteId ) { $etape = 'nom'; }
		}
		return array( 'oeuvre_id' => $oeuvreId, 'artiste_id' => $artisteId,
			'etape' => $etape, 'candidat' => $candidat );
	}

	/**
	 * IMPORT NATIF TUNECORE — parse le rapport « Music Sales » réel.
	 * Colonnes utiles : Store Name (plateforme), Country Of Sale, Artist,
	 * Release Title / Song Title, UPC, Optional ISRC / TC Song ID,
	 * # Units Sold, Total Earned, Currency.
	 *
	 * Agrège par (œuvre|artiste|plateforme) et conserve les unités négatives
	 * (retours/ajustements) telles quelles — le net doit tomber juste.
	 *
	 * @return array{int|null, mixed, mixed, array} ( nb_lignes_creees, total_brut, total_unites, array $nonRattaches )
	 */
	public static function importerTuneCore( $importId, $csv ) {
		self::ensureSchema();
		$rows = self::parseCsv( $csv );
		if ( ! $rows ) { return array( 0, 0.0, 0, array() ); }
		$header = array_map( fn( $c ) => strtolower( trim( $c ) ), $rows[0] );
		$idx = fn( $name ) => array_search( strtolower( $name ), $header, true );
		/*
		 * TOLÉRANCE AUX VARIANTES D'EN-TÊTE (1.760.0).
		 *
		 * La correspondance était STRICTE : « Store Name » et rien d'autre. Or
		 * les distributeurs renomment leurs colonnes d'une refonte à l'autre,
		 * et l'export diffère parfois selon la langue du compte. Une colonne
		 * non reconnue ne provoquait aucune erreur — elle laissait simplement
		 * le champ vide. Une plateforme manquante ne se voyait donc qu'au
		 * camembert, des semaines plus tard, et sans indice sur la cause.
		 *
		 * Le parseur générique acceptait déjà des alias ; celui-ci fait de
		 * même. Le premier en-tête reconnu gagne, dans l'ordre donné.
		 */
		$idxAny = function ( array $noms ) use ( $header ) {
			foreach ( $noms as $n ) {
				$i = array_search( strtolower( $n ), $header, true );
				if ( false !== $i ) { return $i; }
			}
			return false;
		};

		$iStore = $idxAny( array( 'Store Name', 'Store', 'Platform', 'Plateforme', 'DSP', 'Retailer', 'Service' ) );
		$iPays  = $idxAny( array( 'Country Of Sale', 'Country', 'Territory', 'Pays' ) );
		$iArt   = $idxAny( array( 'Artist', 'Artist Name', 'Artiste' ) );
		$iRel   = $idxAny( array( 'Release Title', 'Album', 'Album Title' ) );
		$iSong  = $idxAny( array( 'Song Title', 'Track Title', 'Title', 'Titre' ) );
		$iUpc   = $idxAny( array( 'UPC', 'Barcode', 'EAN' ) );
		$iUpc2  = $idx( 'Optional UPC' );
		$iIsrc  = $idxAny( array( 'Optional ISRC', 'ISRC' ) );
		$iTcId  = $idx( 'TC Song ID' );
		$iUnits = $idxAny( array( '# Units Sold', 'Units Sold', 'Units', 'Quantity', 'Streams' ) );
		$iEarn  = $idxAny( array( 'Total Earned', 'Earnings', 'Net Revenue', 'Revenue', 'Amount' ) );
		$iCur   = $idx( 'Currency' );
		$iPer   = $idxAny( self::entetesPeriode() );

		if ( false === $iStore || false === $iEarn ) {
			// Pas un rapport TuneCore reconnaissable.
			return array( -1, 0.0, 0, array() );
		}

		// Agrégat par clé (œuvre rattachée, bénéficiaire, plateforme, rôle).
		$agg = array();
		$devise = (string) FKC_DB::q( 'SELECT devise FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetchColumn() ?: 'EUR';
		$nonRattaches = array();
		// Totaux du FICHIER, cumulés avant ventilation : ils doivent rester
		// ceux du relevé, quel que soit le nombre de lignes produites.
		$totalBrut = 0.0; $totalUnites = 0;
		for ( $r = 1; $r < count( $rows ); $r++ ) {
			$row = $rows[ $r ];
			if ( count( $row ) < count( $header ) ) { continue; }
			$store = trim( (string) ( $row[ $iStore ] ?? '' ) );
			$pays  = false !== $iPays ? trim( (string) ( $row[ $iPays ] ?? '' ) ) : '';
			$artNom = false !== $iArt ? trim( (string) ( $row[ $iArt ] ?? '' ) ) : '';
			$release = false !== $iRel ? trim( (string) ( $row[ $iRel ] ?? '' ) ) : '';
			$song = false !== $iSong ? trim( (string) ( $row[ $iSong ] ?? '' ) ) : '';
			$upc = false !== $iUpc ? trim( (string) ( $row[ $iUpc ] ?? '' ) ) : '';
			if ( '' === $upc && false !== $iUpc2 ) { $upc = trim( (string) ( $row[ $iUpc2 ] ?? '' ) ); }
			$isrc = false !== $iIsrc ? trim( (string) ( $row[ $iIsrc ] ?? '' ) ) : '';
			if ( '' === $isrc && false !== $iTcId ) { $isrc = trim( (string) ( $row[ $iTcId ] ?? '' ) ); }
			$units = false !== $iUnits ? (int) round( self::nombre( $row[ $iUnits ] ?? 0 ) ) : 0;
			$earn = self::nombre( $row[ $iEarn ] ?? 0 );
			if ( false !== $iCur ) { $c = strtoupper( trim( (string) ( $row[ $iCur ] ?? '' ) ) ); if ( '' !== $c ) { $devise = $c; } }

			$titre = '' !== $song ? $song : $release;
			$mois = false !== $iPer ? (string) self::moisLigne( $row[ $iPer ] ?? '' ) : '';
			$totalBrut += $earn; $totalUnites += $units;

			/*
			 * VENTILATION (1.746.0) — la ligne est éclatée entre les artistes
			 * qu'elle crédite AVANT toute agrégation, chacun avec sa fraction.
			 * Les fractions somment à 1 : le relevé garde son total.
			 */
			foreach ( self::ventilerLigne( $artNom, $isrc ) as $part ) {
				$fr = (float) $part['fraction'];
				if ( $fr <= 0 ) { continue; }
				$nomPart = $part['label'] ? $artNom : $part['nom'];
				list( $oeuvreId, $artisteId ) = self::rattacher( $isrc, $upc, $titre, $part['label'] ? '' : $part['nom'], $artNom );
				if ( $part['label'] ) { $artisteId = null; }
				if ( ! $part['label'] && ! $oeuvreId && ! $artisteId ) {
					$cle = $titre . '|' . $part['nom'];
					$nonRattaches[ $cle ] = ( $nonRattaches[ $cle ] ?? 0 ) + ( $earn * $fr );
				}

				// Clé d'agrégation : œuvre (ou titre brut), bénéficiaire, plateforme.
				$k = ( $oeuvreId ?: 't:' . $titre ) . '|' . ( $artisteId ? 'a:' . $artisteId : 'n:' . $nomPart )
					. '|' . $store . '|' . $part['role'] . '|' . $mois;
				if ( ! isset( $agg[ $k ] ) ) {
					$agg[ $k ] = array(
						'oeuvre_id' => $oeuvreId, 'artiste_id' => $artisteId, 'plateforme' => $store,
						'isrc' => $isrc, 'pays' => $pays, 'titre' => $titre, 'artiste_nom' => $nomPart,
						'role' => $part['role'], 'regle' => $part['regle'], 'label' => $part['label'], 'credit' => $artNom,
						'fraction' => $fr, 'unites' => 0, 'montant' => 0.0, 'periode' => $mois,
					);
				}
				/*
				 * Les unités suivent la même fraction que le montant. Les
				 * laisser entières sur chaque part afficherait deux fois les
				 * streams d'un featuring — un chiffre que l'artiste compare à
				 * son propre tableau de bord Spotify.
				 */
				$agg[ $k ]['unites'] += (int) round( $units * $fr );
				$agg[ $k ]['montant'] += $earn * $fr;
				if ( $agg[ $k ]['pays'] !== $pays ) { $agg[ $k ]['pays'] = '—'; }
			}
		}

		// Écrit les lignes agrégées.
		$n = 0;
		foreach ( $agg as $a ) {
			self::addLigne( $importId, array(
				'artiste_id' => $a['artiste_id'], 'oeuvre_id' => $a['oeuvre_id'],
				'plateforme' => $a['plateforme'], 'isrc' => $a['isrc'], 'pays' => $a['pays'],
				'streams' => $a['unites'], 'unites' => $a['unites'],
				'montant_brut' => round( $a['montant'], 2 ), 'devise_source' => $devise,
				'titre' => $a['titre'], 'artiste_nom' => $a['artiste_nom'], 'credit_source' => $a['credit'],
				'fraction' => $a['fraction'], 'regle_ventil' => $a['regle'], 'role_ligne' => $a['role'],
				// La part du label est ATTRIBUÉE, pas « non attribuée » :
				// elle ne doit pas bloquer la comptabilisation.
				'attribution' => $a['label'] ? 'label' : '',
				'periode' => $a['periode'],
			) );
			$n++;
		}
		FKC_DB::q( 'UPDATE lbl_royalty_imports SET devise=? WHERE id=?', array( $devise, (int) $importId ) );
		self::recomputeTotal( $importId );
		arsort( $nonRattaches );
		return array( $n, round( $totalBrut, 2 ), $totalUnites, $nonRattaches );
	}

	/**
	 * Import GÉNÉRIQUE tolérant — pour les autres distributeurs exportés en CSV.
	 * Accepte des en-têtes variés : isrc/upc, artist/artiste, title/titre/song,
	 * store/platform/plateforme, units/streams/quantity, earnings/net/montant.
	 * @return array{int|null, mixed, mixed, array} ( nb, total_brut, total_unites, array $nonRattaches )
	 */
	public static function importerGenerique( $importId, $csv ) {
		self::ensureSchema();
		$rows = self::parseCsv( $csv );
		if ( ! $rows ) { return array( 0, 0.0, 0, array() ); }
		$header = array_map( fn( $c ) => strtolower( trim( $c ) ), $rows[0] );
		$pick = function ( $row, $names ) use ( $header ) {
			foreach ( $names as $name ) {
				$i = array_search( $name, $header, true );
				if ( false !== $i && isset( $row[ $i ] ) && '' !== trim( (string) $row[ $i ] ) ) { return trim( (string) $row[ $i ] ); }
			}
			return '';
		};
		$n = 0; $totalBrut = 0.0; $totalUnites = 0; $nonRattaches = array();
		/*
		 * LA DEVISE DU FICHIER FAIT FOI (1.744.0). Ce parseur lisait la devise
		 * de chaque ligne mais ne la reportait jamais sur le relevé, qui
		 * restait à « EUR » : un rapport DistroKid en dollars était converti
		 * au cours de l'euro.
		 */
		$deviseReleve = (string) FKC_DB::q( 'SELECT devise FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetchColumn() ?: 'EUR';
		$devisesFichier = self::devisesDuFichier( $csv );
		if ( 1 === count( $devisesFichier ) ) {
			$deviseReleve = $devisesFichier[0];
			FKC_DB::q( 'UPDATE lbl_royalty_imports SET devise=? WHERE id=?', array( $deviseReleve, (int) $importId ) );
		}
		for ( $r = 1; $r < count( $rows ); $r++ ) {
			$row = $rows[ $r ];
			if ( ! array_filter( $row, fn( $v ) => '' !== trim( (string) $v ) ) ) { continue; }
			$isrc = $pick( $row, array( 'isrc', 'optional isrc' ) );
			$upc  = $pick( $row, array( 'upc', 'optional upc', 'ean' ) );
			$titre = $pick( $row, array( 'song title', 'title', 'titre', 'track', 'song', 'release title' ) );
			$artNom = $pick( $row, array( 'artist', 'artiste', 'artist name' ) );
			$store = $pick( $row, array( 'store name', 'store', 'platform', 'plateforme', 'dsp', 'retailer' ) );
			$units = (int) round( self::nombre( $pick( $row, array( '# units sold', 'units', 'streams', 'quantity', 'quantite', 'plays' ) ) ) );
			$earn = self::nombre( $pick( $row, array( 'total earned', 'earnings', 'net', 'net sales', 'earnings (usd)', 'montant_brut', 'montant', 'revenue', 'amount' ) ) );
			$cur = strtoupper( $pick( $row, array( 'currency', 'devise' ) ) ) ?: $deviseReleve;
			$mois = $pick( $row, self::entetesPeriode() );

			$totalBrut += $earn; $totalUnites += $units;
			// Même ventilation que le parseur TuneCore : « A feat. B » donne
			// une ligne par artiste, chacune avec sa fraction du montant.
			foreach ( self::ventilerLigne( $artNom, $isrc ) as $part ) {
				$fr = (float) $part['fraction'];
				if ( $fr <= 0 ) { continue; }
				list( $oeuvreId, $artisteId ) = self::rattacher( $isrc, $upc, $titre, $part['label'] ? '' : $part['nom'], $artNom );
				if ( $part['label'] ) { $artisteId = null; }
				if ( ! $part['label'] && ! $oeuvreId && ! $artisteId ) {
					$cle = $titre . '|' . $part['nom'];
					$nonRattaches[ $cle ] = ( $nonRattaches[ $cle ] ?? 0 ) + ( $earn * $fr );
				}
				self::addLigne( $importId, array(
					'artiste_id' => $artisteId, 'oeuvre_id' => $oeuvreId, 'plateforme' => $store ?: null,
					'isrc' => $isrc, 'streams' => (int) round( $units * $fr ), 'unites' => (int) round( $units * $fr ),
					'montant_brut' => round( $earn * $fr, 2 ), 'devise_source' => $cur,
					'titre' => $titre, 'artiste_nom' => $part['label'] ? $artNom : $part['nom'], 'credit_source' => $artNom,
					'fraction' => $fr, 'regle_ventil' => $part['regle'], 'role_ligne' => $part['role'],
					'attribution' => $part['label'] ? 'label' : '',
					'periode' => $mois,
				) );
				$n++;
			}
		}
		self::recomputeTotal( $importId );
		arsort( $nonRattaches );
		return array( $n, round( $totalBrut, 2 ), $totalUnites, $nonRattaches );
	}

	/** Aiguille selon la source : TuneCore/Believe → parseur natif, sinon générique. */
	public static function importer( $importId, $csv, $source = '' ) {
		self::ensureSchema();
		$imp = FKC_DB::q( 'SELECT source FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetch();
		$source = $source ?: ( $imp['source'] ?? '' );
		// Détection : si l'en-tête ressemble à TuneCore, on prend le parseur natif quel que soit le distributeur.
		$rows = self::parseCsv( $csv );
		$header = $rows ? array_map( fn( $c ) => strtolower( trim( $c ) ), $rows[0] ) : array();
		$estTuneCore = in_array( 'store name', $header, true ) && in_array( 'total earned', $header, true );
		if ( $estTuneCore ) {
			$res = self::importerTuneCore( $importId, $csv );
			if ( is_array( $res ) && ( $res[0] ?? 0 ) >= 0 ) { return $res; }
		}
		return self::importerGenerique( $importId, $csv );
	}

	/**
	 * Lit un nombre tel que l'écrivent les distributeurs : « 1234.56 »,
	 * « 1,234.56 », « 1 234,56 », « 0,0042 ». L'ancienne lecture remplaçait
	 * toute virgule par un point : « 1,234.56 » devenait 1.234 (1.744.0).
	 */
	public static function nombre( $v ) {
		$v = str_replace( array( ' ', "\xC2\xA0", '$', '€' ), '', trim( (string) $v ) );
		if ( '' === $v ) { return 0.0; }
		$pv = strrpos( $v, ',' ); $pp = strrpos( $v, '.' );
		if ( false !== $pv && false !== $pp ) {
			// Le séparateur le plus à droite est le séparateur décimal.
			$v = $pp > $pv ? str_replace( ',', '', $v ) : str_replace( array( '.', ',' ), array( '', '.' ), $v );
		} elseif ( false !== $pv ) {
			$v = str_replace( ',', '.', $v );
		}
		return (float) $v;
	}

	/**
	 * Détecte le séparateur d'un CSV d'après sa première ligne (en-tête) :
	 * virgule, point-virgule (exports Excel européens) ou tabulation (TSV).
	 */
	public static function detecterDelimiteur( $premiereLigne ) {
		$cands = array( ',' => 0, ';' => 0, "\t" => 0 );
		foreach ( $cands as $d => $_ ) { $cands[ $d ] = substr_count( (string) $premiereLigne, $d ); }
		arsort( $cands );
		$best = array_key_first( $cands );
		return $cands[ $best ] > 0 ? $best : ',';
	}

	/** Parse un CSV multi-lignes en tableau de tableaux (BOM et séparateur gérés). */
	/**
	 * ═══════════════════════════════════════════════════════════════════
	 *  RAMÈNE LE FICHIER EN UTF-8 AVANT TOUTE LECTURE
	 * ═══════════════════════════════════════════════════════════════════
	 *  Le contenu était lu tel quel, en supposant l'UTF-8. Or un rapport
	 *  distributeur ouvert puis réenregistré dans Excel sort en
	 *  Windows-1252, et « Éternel », « L'Aîné » ou « Kophi's » y sont codés
	 *  sur un octet là où l'UTF-8 en demande deux.
	 *
	 *  Ces octets isolés ne sont pas de l'UTF-8 valide. Ils traversaient
	 *  l'import sans provoquer la moindre erreur, se rangeaient tels quels
	 *  en base, et ressortaient en losanges noirs. Pire : un titre ainsi
	 *  abîmé ne correspond plus à celui du catalogue, donc la ligne ne se
	 *  rattache plus — le défaut d'encodage se transformait en revenus
	 *  « non attribués », qui n'atteignent jamais le cockpit.
	 *
	 *  Trois familles sont traitées : UTF-16 (l'export « Texte Unicode »
	 *  d'Excel, reconnu à sa marque d'ordre), Windows-1252 (le cas
	 *  courant), et l'UTF-8 déjà valide, qu'on ne touche pas.
	 *
	 *  Windows-1252 plutôt qu'ISO-8859-1 : les deux ne diffèrent que sur la
	 *  plage 0x80-0x9F, où Windows loge précisément l'apostrophe
	 *  typographique « ’ », le tiret cadratin et les guillemets — ceux-là
	 *  mêmes qu'on retrouve dans les titres.
	 * ═══════════════════════════════════════════════════════════════════
	 */
	public static function versUtf8( $texte ) {
		$t = (string) $texte;
		if ( '' === $t ) { return $t; }

		// UTF-16 : reconnu à sa marque d'ordre, converti puis débarrassé du BOM.
		if ( 0 === strncmp( $t, "\xFF\xFE", 2 ) || 0 === strncmp( $t, "\xFE\xFF", 2 ) ) {
			$de = ( "\xFF\xFE" === substr( $t, 0, 2 ) ) ? 'UTF-16LE' : 'UTF-16BE';
			if ( function_exists( 'mb_convert_encoding' ) ) {
				$c = @mb_convert_encoding( substr( $t, 2 ), 'UTF-8', $de );
				if ( false !== $c && '' !== $c ) { return $c; }
			} elseif ( function_exists( 'iconv' ) ) {
				$c = @iconv( $de, 'UTF-8//TRANSLIT', substr( $t, 2 ) );
				if ( false !== $c && '' !== $c ) { return $c; }
			}
		}

		// BOM UTF-8 (fréquent sur les exports Excel).
		if ( 0 === strncmp( $t, "\xEF\xBB\xBF", 3 ) ) { $t = substr( $t, 3 ); }

		// Déjà valide : on n'y touche pas. Reconvertir de l'UTF-8 « depuis »
		// du Windows-1252 produirait deux caractères (un A tilde majuscule suivi d'un signe copyright) là où il y avait « é ».
		if ( preg_match( '//u', $t ) ) { return $t; }

		if ( function_exists( 'mb_convert_encoding' ) ) {
			$c = @mb_convert_encoding( $t, 'UTF-8', 'Windows-1252' );
			if ( false !== $c && '' !== $c ) { return $c; }
		}
		if ( function_exists( 'iconv' ) ) {
			$c = @iconv( 'Windows-1252', 'UTF-8//TRANSLIT', $t );
			if ( false !== $c && '' !== $c ) { return $c; }
		}
		// Dernier recours : retirer les octets invalides plutôt que de laisser
		// une chaîne qui casse l'affichage de toute la page.
		return preg_replace( '/[\x80-\xFF]/', '', $t );
	}

	public static function parseCsv( $csv ) {
		$csv = self::versUtf8( $csv );
		$csv = trim( $csv );
		if ( '' === $csv ) { return array(); }
		$premiere = substr( $csv, 0, strcspn( $csv, "\r\n" ) );
		$delim = self::detecterDelimiteur( $premiere );
		$out = array();
		$fh = fopen( 'php://temp', 'r+' );
		fwrite( $fh, $csv );
		rewind( $fh );
		while ( ( $cells = fgetcsv( $fh, 0, $delim, '"' ) ) !== false ) {
			if ( array( null ) === $cells ) { continue; }
			$out[] = $cells;
		}
		fclose( $fh );
		return $out;
	}

	public static function recomputeTotal( $importId ) {
		self::ensureSchema();
		$row = FKC_DB::q( 'SELECT COALESCE(SUM(montant_brut),0) b, COALESCE(SUM(unites),0) u, COUNT(*) n FROM lbl_royalty_lignes WHERE import_id=?', array( (int) $importId ) )->fetch();
		FKC_DB::q( 'UPDATE lbl_royalty_imports SET total_brut=?, total_unites=?, nb_lignes=? WHERE id=?',
			array( round( (float) $row['b'], 2 ), (int) $row['u'], (int) $row['n'], (int) $importId ) );
	}
	public static function totalArtiste( $importId ) {
		return (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant_artiste),0) FROM lbl_royalty_lignes WHERE import_id=?', array( (int) $importId ) )->fetchColumn();
	}
	/** Répartition agrégée par artiste, selon les parts des fiches (hors splits). */
	public static function parArtiste( $importId ) {
		return FKC_DB::q( 'SELECT l.artiste_id, a.nom_scene, a.nom artiste_nom,
			COALESCE(SUM(l.unites),0) streams, COALESCE(SUM(l.montant_brut),0) brut,
			COALESCE(SUM(l.montant_artiste),0) artiste, COALESCE(SUM(l.montant_label),0) label
			FROM lbl_royalty_lignes l LEFT JOIN lbl_artistes a ON a.id=l.artiste_id
			WHERE l.import_id=? GROUP BY l.artiste_id ORDER BY artiste DESC', array( (int) $importId ) )->fetchAll();
	}
	/** Répartition agrégée par plateforme (analytique). */
	public static function parPlateforme( $importId ) {
		return FKC_DB::q( 'SELECT COALESCE(l.plateforme,\'—\') plateforme,
			COALESCE(SUM(l.unites),0) streams, COALESCE(SUM(l.montant_brut),0) brut
			FROM lbl_royalty_lignes l WHERE l.import_id=? GROUP BY l.plateforme ORDER BY brut DESC', array( (int) $importId ) )->fetchAll();
	}

	/** Nom d'affichage d'un artiste du roster. */
	protected static function nomArtiste( $id ) {
		$a = FKC_DB::q( 'SELECT nom_scene, nom FROM lbl_artistes WHERE id=?', array( (int) $id ) )->fetch();
		return $a ? ( $a['nom_scene'] ?: $a['nom'] ) : ( 'Artiste #' . (int) $id );
	}

	/* ══════════════════════════════════════════════════════════════════════
	   CONVERSION EN MONNAIE LOCALE (1.744.0)
	   ══════════════════════════════════════════════════════════════════════
	 *
	 * Le relevé n'était converti qu'AU MOMENT de la comptabilisation, et nulle
	 * part ailleurs : l'écran d'import, la liste des relevés, la répartition et
	 * les décomptes affichaient des dollars ou des euros sous le format du
	 * franc, et le décompte additionnait des relevés de devises différentes.
	 *
	 * Le cours retenu est celui de la DATE DU RELEVÉ (jamais un cours
	 * postérieur, règle de FKC_Devise::taux()). Une fois le relevé
	 * comptabilisé, c'est le cours FIGÉ qui fait foi : le décompte remis à
	 * l'artiste doit dire exactement ce que la comptabilité a enregistré.
	 */
	public static function conversion( array $imp ) {
		$devise = strtoupper( trim( (string) ( $imp['devise'] ?? '' ) ) ) ?: 'EUR';
		$pivot  = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';
		$brut   = (float) ( $imp['total_brut'] ?? 0 );
		$out = array( 'ok' => false, 'devise' => $devise, 'pivot' => $pivot, 'taux' => null, 'date' => $imp['date'] ?? null,
			'source' => null, 'fixe' => false, 'total_devise' => round( $brut, 2 ), 'total_local' => null, 'message' => '' );
		if ( $devise === $pivot ) {
			$out['ok'] = true; $out['taux'] = 1.0; $out['source'] = 'devise des comptes'; $out['fixe'] = true;
		} elseif ( 'comptabilise' === ( $imp['statut'] ?? '' ) && (float) ( $imp['taux_change'] ?? 0 ) > 0 ) {
			$out['ok'] = true; $out['taux'] = (float) $imp['taux_change']; $out['source'] = 'figé à la comptabilisation';
		} elseif ( class_exists( 'FKC_Devise' ) ) {
			$t = FKC_Devise::taux( $devise, $imp['date'] ?? null );
			if ( null !== $t['taux'] ) {
				$out['ok'] = true; $out['taux'] = (float) $t['taux']; $out['date'] = $t['date'];
				$out['source'] = $t['source']; $out['fixe'] = (bool) $t['fixe'];
			} else {
				$out['message'] = 'Aucun cours ' . $devise . '/' . $pivot . ' connu au ' . ( $imp['date'] ?? date( 'Y-m-d' ) )
					. ' : les montants ne peuvent pas être convertis en ' . $pivot . '.';
			}
		} else {
			$out['message'] = 'Conversion indisponible.';
		}
		if ( $out['ok'] ) { $out['total_local'] = self::local( $brut, $out ); }
		return $out;
	}

	/**
	 * ═══════════════════════════════════════════════════════════════════
	 *  CONVERTIT UNE AGRÉGATION QUI TRAVERSE PLUSIEURS RELEVÉS
	 * ═══════════════════════════════════════════════════════════════════
	 *  La conversion se fait par relevé, au cours de SA date. Tout écran qui
	 *  additionne plusieurs relevés d'un coup en SQL additionne donc des
	 *  devises différentes, puis affiche le résultat au format du franc.
	 *
	 *  C'était le cas du portail artiste, du tableau de bord Label et du
	 *  module Analyse. Le portail est le plus gênant : l'artiste y lit ce
	 *  qu'il a gagné, et un total en euros présenté en francs lui annonce
	 *  environ 650 fois moins que son dû.
	 *
	 *  On passe donc par PHP, relevé par relevé. Un peu plus lent qu'un
	 *  SUM() — mais sur des dizaines de relevés, pas des millions de lignes,
	 *  et c'est le prix d'un chiffre juste.
	 *
	 * @param array $rows Lignes portant 'import_id', 'montant', et
	 *                    facultativement 'cle' pour un regroupement.
	 * @return array{total: float, par_cle: array<string,float>,
	 *               non_converti: float, releves_non_convertis: int}
	 */
	public static function localiser( array $rows ) {
		static $cache = array();
		$out = array( 'total' => 0.0, 'par_cle' => array(), 'non_converti' => 0.0, 'releves_non_convertis' => 0 );
		$manquants = array();
		foreach ( $rows as $r ) {
			$iid = (int) ( $r['import_id'] ?? 0 );
			$m   = (float) ( $r['montant'] ?? 0 );
			if ( ! isset( $cache[ $iid ] ) ) {
				$imp = $iid ? self::find( $iid ) : null;
				$cache[ $iid ] = $imp ? self::conversion( $imp ) : array( 'ok' => false );
			}
			$conv = $cache[ $iid ];
			if ( empty( $conv['ok'] ) ) {
				/*
				 * Relevé sans cours connu. On ne le convertit pas au taux 1 —
				 * ce serait rendre l'erreur invisible — mais on ne l'écarte
				 * pas non plus du total en silence : il y est compté dans sa
				 * devise d'origine ET signalé, pour que l'écran puisse dire
				 * que le chiffre est approché.
				 */
				$manquants[ $iid ] = true;
				$v = $m;
			} else {
				$v = (float) self::local( $m, $conv );
			}
			$out['total'] += $v;
			if ( isset( $r['cle'] ) ) {
				$k = (string) $r['cle'];
				$out['par_cle'][ $k ] = ( $out['par_cle'][ $k ] ?? 0 ) + $v;
				if ( empty( $conv['ok'] ) ) { $out['non_converti'] += $v; }
			} elseif ( empty( $conv['ok'] ) ) {
				$out['non_converti'] += $v;
			}
		}
		$out['releves_non_convertis'] = count( $manquants );
		arsort( $out['par_cle'] );
		return $out;
	}

	/** Contre-valeur locale d'un montant, arrondie à la subdivision de la devise des comptes. */
	public static function local( $montant, array $conv ) {
		if ( empty( $conv['ok'] ) ) { return null; }
		$v = (float) $montant * (float) $conv['taux'];
		return class_exists( 'FKC_Devise' ) ? FKC_Devise::arrondir( $v, $conv['pivot'] ) : round( $v, 0 );
	}

	/**
	 * Enregistre le cours d'un relevé (celui que la banque a appliqué au
	 * versement du distributeur, typiquement), à la date du relevé.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function enregistrerCours( $importId, $taux ) {
		$imp = self::find( $importId );
		if ( ! $imp ) { return array( false, 'Relevé introuvable.' ); }
		if ( 'comptabilise' === $imp['statut'] ) { return array( false, 'Relevé déjà comptabilisé : son cours est figé.' ); }
		if ( ! class_exists( 'FKC_Devise' ) ) { return array( false, 'Gestion des devises indisponible.' ); }
		$taux = self::nombre( $taux );
		return FKC_Devise::enregistrerTaux( $imp['devise'], $taux, $imp['date'], 'relevé royalties', 'Relevé #' . (int) $importId );
	}

	/* ══════════════════════════════════════════════════════════════════════
	   PARTS : LA RÈGLE QUI S'APPLIQUE À CHAQUE LIGNE (1.744.0)
	   ══════════════════════════════════════════════════════════════════════
	 *
	 *   1. L'œuvre a un SPLIT (featuring, part propre au titre…) → le split,
	 *      et seulement s'il fait 100 %.
	 *   2. Sinon, l'œuvre ou la ligne a un artiste → la part de SA FICHE, lue
	 *      au moment du calcul (elle était figée à l'import : modifier la
	 *      fiche avant de comptabiliser ne changeait rien).
	 *   3. Sinon → NON ATTRIBUÉ : bloque la comptabilisation, jusqu'à ce que
	 *      l'utilisateur rattache la ligne à une œuvre, à un artiste, ou
	 *      décide qu'elle revient au label.
	 */

	/**
	 * Remet les lignes d'un relevé non comptabilisé d'accord avec le
	 * catalogue et les fiches d'aujourd'hui.
	 */
	/**
	 * ═══════════════════════════════════════════════════════════════════
	 *  RE-VENTILE UN RELEVÉ APRÈS CHANGEMENT DE BARÈME
	 * ═══════════════════════════════════════════════════════════════════
	 *  Créer un barème ne servait à rien sur un relevé déjà importé : les
	 *  lignes portaient leur fraction, figée à l'import, et la seule issue
	 *  était de réimporter le fichier — que l'ERP ne conserve pas.
	 *
	 *  On reconstitue donc le montant d'origine en regroupant les lignes par
	 *  leur CRÉDIT (« Didi B feat. Suspect 95 »), leur titre et leur
	 *  plateforme, puis on rejoue la ventilation avec le barème en vigueur.
	 *
	 *  Ce qui n'est PAS retouché, et pourquoi :
	 *   — un relevé comptabilisé : sa répartition est figée par son écriture ;
	 *   — une ligne attribuée à la main au label : c'est une décision de
	 *     l'utilisateur, un barème n'a pas à la défaire ;
	 *   — une ligne importée avant 1.750.0 : son crédit d'origine n'a pas été
	 *     conservé. Deviner à partir du nom éclaté reviendrait à inventer.
	 *     Elles sont comptées et annoncées, pas modifiées en silence.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function reventiler( $importId ) {
		self::ensureSchema();
		$importId = (int) $importId;
		$imp = FKC_DB::q( 'SELECT * FROM lbl_royalty_imports WHERE id=?', array( $importId ) )->fetch();
		if ( ! $imp ) { return array( false, 'Relevé introuvable.' ); }
		if ( 'comptabilise' === $imp['statut'] ) {
			return array( false, 'Relevé comptabilisé : sa répartition est figée par son écriture. Contrepassez avant de la refaire.' );
		}
		if ( ! class_exists( 'FKC_LabelBareme' ) ) { return array( false, 'Moteur de barèmes indisponible.' ); }

		$lignes = FKC_DB::q( 'SELECT * FROM lbl_royalty_lignes WHERE import_id=?', array( $importId ) )->fetchAll();
		if ( ! $lignes ) { return array( false, 'Ce relevé n\'a aucune ligne.' ); }

		$groupes = array(); $sansCredit = 0; $intouchees = 0;
		foreach ( $lignes as $l ) {
			$credit = trim( (string) ( $l['credit_source'] ?? '' ) );
			if ( 'label' === ( $l['attribution'] ?? '' ) && 'label' !== ( $l['role_ligne'] ?? '' ) ) { $intouchees++; continue; }
			if ( '' === $credit ) { $sansCredit++; continue; }
			// Clé de regroupement : ce qui était UNE ligne du rapport.
			$k = $credit . "\x1f" . (string) $l['titre_source'] . "\x1f" . (string) $l['isrc']
				. "\x1f" . (string) $l['plateforme'] . "\x1f" . (string) $l['pays'];
			if ( ! isset( $groupes[ $k ] ) ) {
				$groupes[ $k ] = array( 'credit' => $credit, 'titre' => $l['titre_source'], 'isrc' => $l['isrc'],
					'plateforme' => $l['plateforme'], 'pays' => $l['pays'], 'devise' => $l['devise_source'],
					'montant' => 0.0, 'unites' => 0, 'ids' => array() );
			}
			$groupes[ $k ]['montant'] += (float) $l['montant_brut'];
			$groupes[ $k ]['unites']  += (int) $l['unites'];
			$groupes[ $k ]['ids'][]   = (int) $l['id'];
		}
		if ( ! $groupes ) {
			return array( false, 'Aucune ligne re-ventilable : ' . $sansCredit
				. ' ligne(s) ont été importées avant que le crédit d\'origine soit conservé. Réimportez le relevé pour en bénéficier.' );
		}

		$recrees = 0; $modifies = 0;
		foreach ( $groupes as $g ) {
			$avant = count( $g['ids'] );
			$nouvelles = 0;
			FKC_DB::q( 'DELETE FROM lbl_royalty_lignes WHERE id IN (' . implode( ',', array_map( 'intval', $g['ids'] ) ) . ')' );
			foreach ( self::ventilerLigne( $g['credit'], $g['isrc'] ) as $part ) {
				$fr = (float) $part['fraction'];
				if ( $fr <= 0 ) { continue; }
				list( $oeuvreId, $artisteId ) = self::rattacher( $g['isrc'], '', $g['titre'], $part['label'] ? '' : $part['nom'], $g['credit'] );
				if ( $part['label'] ) { $artisteId = null; }
				self::addLigne( $importId, array(
					'artiste_id' => $artisteId, 'oeuvre_id' => $oeuvreId, 'plateforme' => $g['plateforme'],
					'isrc' => $g['isrc'], 'pays' => $g['pays'],
					'streams' => (int) round( $g['unites'] * $fr ), 'unites' => (int) round( $g['unites'] * $fr ),
					'montant_brut' => round( $g['montant'] * $fr, 2 ), 'devise_source' => $g['devise'],
					'titre' => $g['titre'], 'artiste_nom' => $part['label'] ? $g['credit'] : $part['nom'],
					'credit_source' => $g['credit'],
					'fraction' => $fr, 'regle_ventil' => $part['regle'], 'role_ligne' => $part['role'],
					'attribution' => $part['label'] ? 'label' : '',
				) );
				$recrees++; $nouvelles++;
			}
			// Comparaison PAR GROUPE : un compteur cumulé aurait déclaré
			// « modifié » tous les crédits dès le second.
			if ( $nouvelles !== $avant ) { $modifies++; }
		}
		self::recomputeTotal( $importId );

		$msg = count( $groupes ) . ' crédit(s) re-ventilés en ' . $recrees . ' ligne(s)'
			. ( $modifies ? ', dont ' . $modifies . ' dont la répartition a changé' : ' — aucune répartition n\'a changé' ) . '.';
		if ( $intouchees ) { $msg .= ' ' . $intouchees . ' ligne(s) attribuées à la main au label ont été laissées intactes.'; }
		if ( $sansCredit ) {
			$msg .= ' ' . $sansCredit . ' ligne(s) importées avant 1.750.0 n\'ont pas de crédit d\'origine : réimportez le relevé pour les inclure.';
		}
		return array( true, $msg );
	}

	public static function recalculer( $importId ) {
		self::ensureSchema();
		$imp = FKC_DB::q( 'SELECT statut FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetch();
		if ( ! $imp || 'comptabilise' === $imp['statut'] ) { return; }
		$lignes = FKC_DB::q( 'SELECT * FROM lbl_royalty_lignes WHERE import_id=?', array( (int) $importId ) )->fetchAll();
		$parts = array();
		foreach ( $lignes as $l ) {
			$oeuvreId  = $l['oeuvre_id'] ? (int) $l['oeuvre_id'] : null;
			$artisteId = $l['artiste_id'] ? (int) $l['artiste_id'] : null;
			// Un ISRC ou un titre renseigné au catalogue APRÈS l'import suffit
			// désormais à rattacher la ligne — sans réimporter le fichier.
			if ( ! $oeuvreId && ! $artisteId && 'label' !== $l['attribution'] ) {
				list( $oeuvreId, $artisteId ) = self::rattacher( $l['isrc'], '', $l['titre_source'], $l['artiste_source'] );
			}
			// L'artiste de l'œuvre a pu être renseigné après coup.
			if ( $oeuvreId && ! $artisteId ) {
				$o = FKC_Oeuvre::find( $oeuvreId );
				$artisteId = $o && $o['artiste_id'] ? (int) $o['artiste_id'] : null;
			}
			$brut = (float) $l['montant_brut'];
			if ( $artisteId ) {
				if ( ! isset( $parts[ $artisteId ] ) ) { $parts[ $artisteId ] = self::partFiche( $artisteId ); }
				$part = $parts[ $artisteId ];
				$mA = round( $brut * $part / 100, 2 ); $mL = round( $brut - $mA, 2 );
			} elseif ( 'label' === $l['attribution'] ) {
				$part = 0.0; $mA = 0.0; $mL = round( $brut, 2 );
			} else {
				$part = 0.0; $mA = 0.0; $mL = 0.0;
			}
			if ( (int) $l['oeuvre_id'] !== (int) $oeuvreId || (int) $l['artiste_id'] !== (int) $artisteId
				|| abs( (float) $l['part_artiste'] - $part ) > 0.0001 || abs( (float) $l['montant_artiste'] - $mA ) > 0.001
				|| abs( (float) $l['montant_label'] - $mL ) > 0.001 ) {
				FKC_DB::q( 'UPDATE lbl_royalty_lignes SET oeuvre_id=?, artiste_id=?, part_artiste=?, montant_artiste=?, montant_label=? WHERE id=?',
					array( $oeuvreId, $artisteId, $part, $mA, $mL, (int) $l['id'] ) );
			}
		}
	}

	/** Règle appliquée à une ligne : split | split_incomplet | fiche | label | non_attribue | sans_ayant_droit. */
	public static function regleLigne( array $l, array &$cache = array() ) {
		$oid = (int) ( $l['oeuvre_id'] ?? 0 );
		if ( $oid && class_exists( 'FKC_CreativeSplits' ) ) {
			if ( ! isset( $cache[ $oid ] ) ) { $cache[ $oid ] = FKC_CreativeSplits::etat( $oid ); }
			if ( $cache[ $oid ]['nb'] > 0 ) { return $cache[ $oid ]['complet'] ? 'split' : 'split_incomplet'; }
		}
		if ( ! empty( $l['artiste_id'] ) ) {
			/*
			 * NIVEAU DE VENTILATION AFFICHÉ (1.746.0). « Fiche artiste » seul
			 * ne disait pas si la ligne portait déjà la moitié d'un featuring :
			 * deux lignes au même taux de fiche, l'une entière et l'autre à
			 * 50 %, se ressemblaient à l'écran.
			 */
			$rv = (string) ( $l['regle_ventil'] ?? '' );
			if ( 'bareme_titre' === $rv )     { return 'bareme_titre'; }
			if ( 'bareme_collab' === $rv )    { return 'bareme_collab'; }
			if ( 'bareme_incomplet' === $rv ) { return 'bareme_incomplet'; }
			if ( 'collab_auto' === $rv )      { return 'collab_auto'; }
			return 'fiche';
		}
		if ( 'label' === ( $l['attribution'] ?? '' ) ) { return 'label'; }
		return $oid ? 'sans_ayant_droit' : 'non_attribue';
	}

	/** Libellés des règles, pour l'écran — du plus précis au plus général. */
	public static function regles() {
		return array(
			'split'            => 'Split du titre',
			'split_incomplet'  => 'Split incomplet',
			'bareme_titre'     => 'Barème du titre',
			'bareme_collab'    => 'Barème de collaboration',
			'bareme_incomplet' => 'Barème incomplet → équitable',
			'collab_auto'      => 'Collaboration (équitable)',
			'groupe'           => 'Nom de groupe',
			'fiche'            => 'Fiche artiste',
			'label'            => 'Attribué au label',
			'non_attribue'     => 'Non attribué',
			'sans_ayant_droit' => 'Œuvre sans artiste',
		);
	}

	public static function find( $id ) {
		self::ensureSchema();
		self::recalculer( (int) $id );
		$r = FKC_DB::q( 'SELECT * FROM lbl_royalty_imports WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		$r['lignes'] = FKC_DB::q( 'SELECT l.*, a.nom_scene, a.nom artiste_nom, o.titre oeuvre FROM lbl_royalty_lignes l
			LEFT JOIN lbl_artistes a ON a.id=l.artiste_id LEFT JOIN lbl_oeuvres o ON o.id=l.oeuvre_id WHERE l.import_id=? ORDER BY l.montant_brut DESC, l.id', array( (int) $id ) )->fetchAll();
		$cache = array();
		foreach ( $r['lignes'] as $k => $l ) { $r['lignes'][ $k ]['regle'] = self::regleLigne( $l, $cache ); }
		return $r;
	}

	/**
	 * Lignes NON ATTRIBUÉES d'un relevé, regroupées comme le distributeur les
	 * a nommées (titre + artiste), pour les attribuer d'un geste.
	 */
	public static function nonAttribues( $importId ) {
		self::ensureSchema();
		return FKC_DB::q(
			"SELECT COALESCE(titre_source,'') titre, COALESCE(artiste_source,'') artiste, MAX(isrc) isrc,
				COUNT(*) nb, COALESCE(SUM(unites),0) unites, ROUND(COALESCE(SUM(montant_brut),0),2) montant
			 FROM lbl_royalty_lignes
			 WHERE import_id=? AND oeuvre_id IS NULL AND artiste_id IS NULL AND COALESCE(attribution,'')<>'label'
			 GROUP BY COALESCE(titre_source,''), COALESCE(artiste_source,'') ORDER BY montant DESC",
			array( (int) $importId )
		)->fetchAll();
	}

	/**
	 * Attribue les lignes non rattachées d'un même titre.
	 *
	 * @param string $cible 'o:{id}' une œuvre du catalogue, 'a:{id}' un artiste
	 *                      (titre absent du catalogue), 'label' le label.
	 * @param bool   $memoriserIsrc Reporte l'ISRC du relevé sur l'œuvre si
	 *                      elle n'en a pas : le prochain relevé se rattachera seul.
	 * @return array{0:bool,1:string}
	 */
	public static function attribuer( $importId, $titre, $artiste, $cible, $memoriserIsrc = true ) {
		self::ensureSchema();
		$imp = FKC_DB::q( 'SELECT statut FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetch();
		if ( ! $imp ) { return array( false, 'Relevé introuvable.' ); }
		if ( 'comptabilise' === $imp['statut'] ) { return array( false, 'Relevé déjà comptabilisé.' ); }
		$cible = (string) $cible;
		$oeuvreId = null; $artisteId = null; $attribution = null;
		if ( 0 === strpos( $cible, 'o:' ) ) {
			$o = FKC_Oeuvre::find( (int) substr( $cible, 2 ) );
			if ( ! $o ) { return array( false, 'Œuvre introuvable.' ); }
			$oeuvreId = (int) $o['id'];
			$artisteId = $o['artiste_id'] ? (int) $o['artiste_id'] : null;
		} elseif ( 0 === strpos( $cible, 'a:' ) ) {
			$a = FKC_Artiste::find( (int) substr( $cible, 2 ) );
			if ( ! $a ) { return array( false, 'Artiste introuvable.' ); }
			$artisteId = (int) $a['id'];
		} elseif ( 'label' === $cible ) {
			$attribution = 'label';
		} else {
			return array( false, 'Choisissez à qui revient ce revenu.' );
		}
		/*
		 * UNE ATTRIBUTION HUMAINE SE SIGNE (1.788.0).
		 *
		 * Elle ne laissait aucune trace : la ligne portait une œuvre et un
		 * artiste, exactement comme si le logiciel les avait devinés. L'état de
		 * contrôle des attributions ne pouvait donc pas distinguer une décision
		 * prise par quelqu'un d'une déduction prise par la machine — et
		 * relisait les deux avec la même suspicion.
		 *
		 * « manuelle » n'est comparé nulle part ailleurs : tous les autres
		 * lecteurs de cette colonne testent l'égalité à « label », qui reste
		 * fausse. Le marquage ne change donc aucun comportement existant.
		 */
		if ( null === $attribution ) { $attribution = 'manuelle'; }
		$where = "import_id=? AND oeuvre_id IS NULL AND artiste_id IS NULL AND COALESCE(attribution,'')<>'label'
			AND COALESCE(titre_source,'')=? AND COALESCE(artiste_source,'')=?";
		$p = array( (int) $importId, (string) $titre, (string) $artiste );
		$n = (int) FKC_DB::q( "SELECT COUNT(*) FROM lbl_royalty_lignes WHERE {$where}", $p )->fetchColumn();
		if ( ! $n ) { return array( false, 'Aucune ligne à attribuer pour ce titre.' ); }
		$isrc = (string) FKC_DB::q( "SELECT MAX(isrc) FROM lbl_royalty_lignes WHERE {$where}", $p )->fetchColumn();
		FKC_DB::q( "UPDATE lbl_royalty_lignes SET oeuvre_id=?, artiste_id=?, attribution=? WHERE {$where}",
			array_merge( array( $oeuvreId, $artisteId, $attribution ), $p ) );
		$memo = '';
		if ( $oeuvreId && $memoriserIsrc && '' !== $isrc && empty( $o['isrc'] ) ) {
			FKC_DB::q( 'UPDATE lbl_oeuvres SET isrc=? WHERE id=?', array( $isrc, $oeuvreId ) );
			$memo = ' ISRC ' . $isrc . ' enregistré sur l\'œuvre : les prochains relevés se rattacheront seuls.';
		}
		self::recalculer( $importId );
		return array( true, $n . ' ligne(s) attribuée(s).' . $memo );
	}

	/* ══════════════════════════════════════════════════════════════════════
	   RÉPARTITION
	   ══════════════════════════════════════════════════════════════════════ */

	/**
	 * RÉPARTITION DÉTAILLÉE d'un relevé : une ligne par (œuvre, ayant droit).
	 * Source unique de vérité — les vues agrégées, les décomptes et la
	 * comptabilisation en dérivent.
	 *
	 * Chaque ligne porte son montant dans la devise du relevé ET sa
	 * contre-valeur locale (null si aucun cours n'est connu).
	 *
	 * Un relevé comptabilisé est relu depuis sa répartition FIGÉE.
	 *
	 * @return array{lignes: array, bloque: array, base_splits: float, base_fallback: float, conversion: array}
	 */
	public static function repartitionDetaillee( $importId ) {
		self::ensureSchema();
		$importId = (int) $importId;
		$imp = FKC_DB::q( 'SELECT * FROM lbl_royalty_imports WHERE id=?', array( $importId ) )->fetch();
		if ( ! $imp ) { return array( 'lignes' => array(), 'bloque' => array(), 'base_splits' => 0.0, 'base_fallback' => 0.0, 'conversion' => array( 'ok' => false ) ); }
		$conv = self::conversion( $imp );

		if ( 'comptabilise' === $imp['statut'] ) {
			$figees = FKC_DB::q( 'SELECT * FROM lbl_royalty_repartition WHERE import_id=? ORDER BY id', array( $importId ) )->fetchAll();
			if ( $figees ) {
				$lignes = array();
				foreach ( $figees as $f ) {
					$lignes[] = array( 'oeuvre_id' => $f['oeuvre_id'] ? (int) $f['oeuvre_id'] : null, 'titre' => $f['titre'],
						'ayant_droit' => $f['ayant_droit'], 'artiste_id' => $f['artiste_id'] ? (int) $f['artiste_id'] : null,
						'role' => $f['role'], 'part' => null !== $f['part'] ? (float) $f['part'] : null,
						'montant' => (float) $f['montant'], 'montant_local' => (float) $f['montant_local'] );
				}
				return array( 'lignes' => $lignes, 'bloque' => array(), 'base_splits' => 0.0, 'base_fallback' => 0.0, 'conversion' => $conv, 'figee' => true );
			}
		}

		self::recalculer( $importId );
		$splitsActif = class_exists( 'FKC_CreativeSplits' );
		$lignes = array(); $bloque = array(); $baseSplits = 0.0; $baseFallback = 0.0;
		$ajout = function ( $oid, $titre, $nom, $aid, $role, $part, $montant ) use ( &$lignes, $conv ) {
			$lignes[] = array( 'oeuvre_id' => $oid, 'titre' => $titre, 'ayant_droit' => $nom,
				'artiste_id' => $aid ? (int) $aid : null, 'role' => $role, 'part' => $part,
				'montant' => round( (float) $montant, 2 ), 'montant_local' => self::local( $montant, $conv ) );
		};
		$bloquer = function ( $motif, $oid, $titre, $montant, $extra = array() ) use ( &$bloque, $conv ) {
			$bloque[] = array_merge( array( 'motif' => $motif, 'oeuvre_id' => $oid, 'titre' => $titre,
				'montant' => round( (float) $montant, 2 ), 'montant_local' => self::local( $montant, $conv ),
				'total' => null, 'ecart' => null ), $extra );
		};

		// Œuvres identifiées : une ligne de groupe par (œuvre, artiste).
		$groupes = FKC_DB::q(
			'SELECT l.oeuvre_id, l.artiste_id, o.titre,
					COALESCE(SUM(l.montant_brut),0) brut, COALESCE(SUM(l.montant_artiste),0) art,
					COALESCE(SUM(l.montant_label),0) lab, MAX(l.part_artiste) part
			 FROM lbl_royalty_lignes l LEFT JOIN lbl_oeuvres o ON o.id=l.oeuvre_id
			 WHERE l.import_id=? AND l.oeuvre_id IS NOT NULL GROUP BY l.oeuvre_id, l.artiste_id ORDER BY l.oeuvre_id', array( $importId )
		)->fetchAll();
		$parOeuvre = array();
		foreach ( $groupes as $g ) { $parOeuvre[ (int) $g['oeuvre_id'] ][] = $g; }
		foreach ( $parOeuvre as $oid => $gs ) {
			$titre = $gs[0]['titre'] ?: ( '(œuvre #' . $oid . ')' );
			$brut = 0.0; foreach ( $gs as $g ) { $brut += (float) $g['brut']; }
			$etat = $splitsActif ? FKC_CreativeSplits::etat( $oid ) : array( 'nb' => 0, 'complet' => false, 'total' => 0.0, 'ecart' => 100.0 );
			if ( $etat['nb'] > 0 && $etat['complet'] ) {
				foreach ( FKC_CreativeSplits::repartir( $oid, $brut ) as $r ) {
					$ajout( $oid, $titre, $r['ayant_droit'], $r['artiste_id'], $r['role'], (float) $r['part'], $r['montant'] );
				}
				$baseSplits += $brut;
				continue;
			}
			if ( $etat['nb'] > 0 ) {
				$bloquer( 'split_incomplet', $oid, $titre, $brut, array( 'total' => $etat['total'], 'ecart' => $etat['ecart'] ) );
				continue;
			}
			foreach ( $gs as $g ) {
				if ( ! $g['artiste_id'] ) {
					$bloquer( 'sans_ayant_droit', $oid, $titre, $g['brut'] );
					continue;
				}
				if ( 0.0 !== (float) $g['art'] ) {
					$ajout( $oid, $titre, self::nomArtiste( (int) $g['artiste_id'] ), (int) $g['artiste_id'], 'interprete', (float) $g['part'], $g['art'] );
				}
				if ( 0.0 !== (float) $g['lab'] ) {
					$ajout( $oid, $titre, 'Label', null, 'label', 100 - (float) $g['part'], $g['lab'] );
				}
				$baseFallback += (float) $g['brut'];
			}
		}

		// Sans œuvre : artiste connu (fiche), attribué au label, ou non attribué.
		$sansOeuvre = FKC_DB::q(
			"SELECT l.artiste_id, COALESCE(l.attribution,'') attribution, MAX(l.part_artiste) part,
				COALESCE(SUM(l.montant_artiste),0) art, COALESCE(SUM(l.montant_label),0) lab, COALESCE(SUM(l.montant_brut),0) brut
			 FROM lbl_royalty_lignes l WHERE l.import_id=? AND l.oeuvre_id IS NULL
			 GROUP BY l.artiste_id, COALESCE(l.attribution,'')", array( $importId )
		)->fetchAll();
		foreach ( $sansOeuvre as $r ) {
			if ( $r['artiste_id'] ) {
				if ( 0.0 !== (float) $r['art'] ) {
					$ajout( null, '(sans œuvre identifiée)', self::nomArtiste( (int) $r['artiste_id'] ), (int) $r['artiste_id'], 'interprete', (float) $r['part'], $r['art'] );
				}
				if ( 0.0 !== (float) $r['lab'] ) {
					$ajout( null, '(sans œuvre identifiée)', 'Label', null, 'label', 100 - (float) $r['part'], $r['lab'] );
				}
				$baseFallback += (float) $r['brut'];
			} elseif ( 'label' === $r['attribution'] ) {
				$ajout( null, '(attribué au label)', 'Label', null, 'label', 100.0, $r['brut'] );
				$baseFallback += (float) $r['brut'];
			}
		}
		foreach ( self::nonAttribues( $importId ) as $na ) {
			$bloquer( 'non_attribue', null, '' !== $na['titre'] ? $na['titre'] : '(titre non fourni)', $na['montant'],
				array( 'artiste_source' => $na['artiste'], 'isrc' => $na['isrc'] ) );
		}

		return array( 'lignes' => $lignes, 'bloque' => $bloque, 'base_splits' => round( $baseSplits, 2 ),
			'base_fallback' => round( $baseFallback, 2 ), 'conversion' => $conv );
	}

	/**
	 * RÉPARTITION PAR AYANT DROIT — agrège la répartition détaillée par ayant
	 * droit (roster ou externe), avec le label à part.
	 *
	 * Conservation : Σ(par_ayant_droit) + label + Σ(bloqué) = total brut.
	 */
	public static function repartitionAyantsDroit( $importId ) {
		$det = self::repartitionDetaillee( $importId );
		$ayants = array(); $labelTotal = 0.0; $labelLocal = 0.0; $convOk = ! empty( $det['conversion']['ok'] );
		foreach ( $det['lignes'] as $r ) {
			if ( 'label' === $r['role'] && ! $r['artiste_id'] ) {
				$labelTotal = round( $labelTotal + (float) $r['montant'], 2 );
				$labelLocal += (float) $r['montant_local'];
				continue;
			}
			$cle = $r['artiste_id'] ? 'a:' . (int) $r['artiste_id'] : 'x:' . mb_strtolower( $r['ayant_droit'] );
			if ( ! isset( $ayants[ $cle ] ) ) {
				$ayants[ $cle ] = array( 'ayant_droit' => $r['ayant_droit'], 'artiste_id' => $r['artiste_id'], 'montant' => 0.0, 'montant_local' => $convOk ? 0.0 : null, 'titres' => array() );
			}
			$ayants[ $cle ]['montant'] = round( $ayants[ $cle ]['montant'] + (float) $r['montant'], 2 );
			if ( $convOk ) { $ayants[ $cle ]['montant_local'] += (float) $r['montant_local']; }
			$ayants[ $cle ]['titres'][ (string) $r['titre'] ] = true;
		}
		foreach ( $ayants as $k => $a ) {
			if ( abs( (float) $a['montant'] ) < 0.005 ) { unset( $ayants[ $k ] ); continue; }
			$ayants[ $k ]['titres'] = count( $a['titres'] );
		}
		uasort( $ayants, fn( $a, $b ) => $b['montant'] <=> $a['montant'] );
		return array(
			'par_ayant_droit' => array_values( $ayants ),
			'label' => round( $labelTotal, 2 ),
			'label_local' => $convOk ? $labelLocal : null,
			'bloque' => $det['bloque'],
			'base_splits' => $det['base_splits'],
			'base_fallback' => $det['base_fallback'],
			'conversion' => $det['conversion'],
		);
	}

	/** Relevés dont la période tombe dans la fourchette. */
	protected static function relevesDansPeriode( $periodeDebut, $periodeFin ) {
		$out = array();
		foreach ( self::imports() as $imp ) {
			$per = $imp['periode'] ?: substr( (string) $imp['date'], 0, 7 );
			if ( $periodeDebut && $per < $periodeDebut ) { continue; }
			if ( $periodeFin && $per > $periodeFin ) { continue; }
			$imp['_periode'] = $per;
			$out[] = $imp;
		}
		return $out;
	}

	/**
	 * DÉCOMPTE CONSOLIDÉ PAR AYANT DROIT sur une fourchette de périodes, EN
	 * MONNAIE LOCALE (1.744.0).
	 *
	 * Il additionnait les montants de relevés de devises différentes et
	 * affichait la devise la plus fréquente. Chaque relevé est désormais
	 * converti à SON cours ; un relevé sans cours est écarté et signalé.
	 *
	 * @return array{ayants: array, label: float, bloque_total: float, periodes: array,
	 *               nb_releves: int, total: float, devise: string, sans_cours: array}
	 */
	public static function decompteParAyantDroit( $periodeDebut = null, $periodeFin = null ) {
		self::ensureSchema();
		$periodeDebut = trim( (string) $periodeDebut ) ?: null;
		$periodeFin = trim( (string) $periodeFin ) ?: null;
		$pivot = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';

		$ayants = array(); $labelTotal = 0.0; $bloqueTotal = 0.0; $periodes = array(); $sansCours = array(); $nb = 0;
		foreach ( self::relevesDansPeriode( $periodeDebut, $periodeFin ) as $imp ) {
			$per = $imp['_periode'];
			$rep = self::repartitionAyantsDroit( (int) $imp['id'] );
			if ( empty( $rep['conversion']['ok'] ) ) {
				$sansCours[] = array( 'id' => (int) $imp['id'], 'periode' => $per, 'devise' => $rep['conversion']['devise'], 'montant' => (float) $imp['total_brut'] );
				continue;
			}
			$nb++;
			$periodes[ $per ] = true;
			foreach ( $rep['par_ayant_droit'] as $r ) {
				$cle = $r['artiste_id'] ? 'a:' . (int) $r['artiste_id'] : 'x:' . mb_strtolower( $r['ayant_droit'] );
				if ( ! isset( $ayants[ $cle ] ) ) {
					$ayants[ $cle ] = array( 'ayant_droit' => $r['ayant_droit'], 'artiste_id' => $r['artiste_id'], 'total' => 0.0, 'par_periode' => array() );
				}
				$ayants[ $cle ]['total'] += (float) $r['montant_local'];
				$ayants[ $cle ]['par_periode'][ $per ] = ( $ayants[ $cle ]['par_periode'][ $per ] ?? 0 ) + (float) $r['montant_local'];
			}
			$labelTotal += (float) $rep['label_local'];
			foreach ( $rep['bloque'] as $b ) { $bloqueTotal += (float) $b['montant_local']; }
		}

		uasort( $ayants, fn( $a, $b ) => $b['total'] <=> $a['total'] );
		ksort( $periodes );
		return array(
			'ayants' => array_values( $ayants ),
			'label' => $labelTotal,
			'bloque_total' => $bloqueTotal,
			'periodes' => array_keys( $periodes ),
			'nb_releves' => $nb,
			'total' => array_sum( array_map( fn( $a ) => $a['total'], $ayants ) ),
			'devise' => $pivot,
			'sans_cours' => $sansCours,
		);
	}

	/** Bornes de période disponibles (min/max) sur l'ensemble des relevés. */
	public static function periodesBornes() {
		self::ensureSchema();
		$rows = self::imports();
		$pers = array();
		foreach ( $rows as $imp ) { $pers[] = $imp['periode'] ?: substr( (string) $imp['date'], 0, 7 ); }
		$pers = array_values( array_filter( array_unique( $pers ) ) );
		sort( $pers );
		return array( 'min' => $pers[0] ?? null, 'max' => $pers ? $pers[ count( $pers ) - 1 ] : null, 'toutes' => $pers );
	}

	/**
	 * DÉCOMPTE INDIVIDUEL d'un ayant droit, en monnaie locale, ventilé par
	 * œuvre et par période. Cohérent au franc près avec le décompte
	 * consolidé et, pour les relevés comptabilisés, avec les dus.
	 *
	 * @param string $ref 'a:{id}' roster, 'x:{nom en minuscules}' externe.
	 */
	public static function decompteIndividuel( $ref, $periodeDebut = null, $periodeFin = null ) {
		self::ensureSchema();
		$ref = (string) $ref;
		$estRoster = 0 === strpos( $ref, 'a:' );
		$artisteId = $estRoster ? (int) substr( $ref, 2 ) : null;
		$cleExterne = $estRoster ? null : mb_strtolower( substr( $ref, 2 ) );
		$periodeDebut = trim( (string) $periodeDebut ) ?: null;
		$periodeFin = trim( (string) $periodeFin ) ?: null;
		$pivot = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';

		$nom = $estRoster ? self::nomArtiste( $artisteId ) : null;
		$parOeuvre = array(); $parPeriode = array(); $total = 0.0; $periodes = array(); $nbReleves = 0; $sansCours = array();

		foreach ( self::relevesDansPeriode( $periodeDebut, $periodeFin ) as $imp ) {
			$per = $imp['_periode'];
			$det = self::repartitionDetaillee( (int) $imp['id'] );
			$convOk = ! empty( $det['conversion']['ok'] );
			$trouve = false;
			foreach ( $det['lignes'] as $r ) {
				$match = $estRoster
					? ( null !== $r['artiste_id'] && (int) $r['artiste_id'] === $artisteId )
					: ( null === $r['artiste_id'] && 'label' !== $r['role'] && mb_strtolower( $r['ayant_droit'] ) === $cleExterne );
				if ( ! $match ) { continue; }
				if ( null === $nom ) { $nom = $r['ayant_droit']; }
				if ( ! $convOk ) { $trouve = 'sans_cours'; continue; }
				$trouve = true;
				$m = (float) $r['montant_local'];
				$keyO = null !== $r['oeuvre_id'] ? 'o:' . (int) $r['oeuvre_id'] : 't:' . $r['titre'];
				if ( ! isset( $parOeuvre[ $keyO ] ) ) {
					$parOeuvre[ $keyO ] = array( 'oeuvre_id' => $r['oeuvre_id'], 'titre' => $r['titre'], 'role' => $r['role'], 'part' => $r['part'], 'montant' => 0.0 );
				}
				$parOeuvre[ $keyO ]['montant'] += $m;
				$parPeriode[ $per ] = ( $parPeriode[ $per ] ?? 0 ) + $m;
				$total += $m;
			}
			if ( true === $trouve ) { $periodes[ $per ] = true; $nbReleves++; }
			if ( 'sans_cours' === $trouve ) { $sansCours[] = array( 'id' => (int) $imp['id'], 'periode' => $per, 'devise' => $det['conversion']['devise'] ); }
		}
		uasort( $parOeuvre, fn( $a, $b ) => $b['montant'] <=> $a['montant'] );
		ksort( $parPeriode );
		return array(
			'ref' => $ref, 'ayant_droit' => $nom ?: '—', 'artiste_id' => $artisteId, 'roster' => $estRoster,
			'total' => $total,
			'par_oeuvre' => array_values( $parOeuvre ),
			'par_periode' => $parPeriode,
			'periodes' => array_keys( $periodes ),
			'nb_releves' => $nbReleves,
			'devise' => $pivot,
			'sans_cours' => $sansCours,
		);
	}

	/**
	 * Comptabilise un relevé : écriture (produit, part des ayants droit),
	 * dus par artiste du roster, répartition figée.
	 *
	 * Refus — sans rien écrire — tant que :
	 *   • aucun cours n'est connu (jamais de conversion « au taux 1 ») ;
	 *   • une partie du relevé n'a pas de titulaire (split incomplet, ligne
	 *     non attribuée, œuvre sans artiste). Auparavant, ces montants
	 *     partaient en produit du label ; le message invitait à « corriger
	 *     puis re-comptabiliser » — ce que le statut interdisait ensuite ;
	 *   • l'écriture elle-même est refusée par la comptabilité.
	 *
	 * La dette envers les ayants droit est la SOMME des dus arrondis : le
	 * compte 401160 se solde exactement quand chaque dû est payé.
	 *
	 * @return array{0:?int,1:int,2:array} ecriture_id, nb de dus créés, détail (clé 'erreur' si refus)
	 */
	public static function comptabiliser( $importId ) {
		$refus = function ( $msg ) { return array( null, 0, array( 'externes' => array(), 'bloque' => array(), 'erreur' => $msg ) ); };
		$imp = self::find( $importId );
		if ( ! $imp ) { return $refus( 'Relevé introuvable.' ); }
		if ( 'comptabilise' === $imp['statut'] ) { return $refus( 'Ce relevé est déjà comptabilisé.' ); }

		$conv = self::conversion( $imp );
		if ( ! $conv['ok'] ) { return $refus( 'Comptabilisation refusée — ' . $conv['message'] . ' Saisissez le cours sur le relevé.' ); }

		$rep = self::repartitionAyantsDroit( $importId );
		if ( $rep['bloque'] ) {
			$motifs = array();
			foreach ( $rep['bloque'] as $b ) { $motifs[ $b['motif'] ] = ( $motifs[ $b['motif'] ] ?? 0 ) + 1; }
			$lib = self::regles();
			$txt = array();
			foreach ( $motifs as $m => $n ) { $txt[] = $n . ' × ' . mb_strtolower( $lib[ $m ] ?? $m ); }
			$montant = array_sum( array_column( $rep['bloque'], 'montant' ) );
			return $refus( 'Comptabilisation refusée — ' . number_format( $montant, 2, ',', ' ' ) . ' ' . $conv['devise']
				. ' sans titulaire (' . implode( ', ', $txt ) . '). Attribuez ces revenus ou complétez les splits : ils ne peuvent pas partir en produit du label par défaut.' );
		}

		$pivot = $conv['pivot']; $devise = $conv['devise']; $taux = (float) $conv['taux'];
		$brutDevise = (float) $imp['total_brut'];
		$brutLocal  = (float) $conv['total_local'];
		if ( $brutLocal <= 0 ) { return $refus( 'Comptabilisation refusée — le relevé est nul ou négatif.' ); }
		$ayantsDevise = 0.0; $ayantsLocal = 0.0;
		foreach ( $rep['par_ayant_droit'] as $r ) { $ayantsDevise += (float) $r['montant']; $ayantsLocal += (float) $r['montant_local']; }
		if ( $ayantsLocal > $brutLocal + 0.5 ) { return $refus( 'Comptabilisation refusée — la part des ayants droit dépasse le relevé.' ); }

		$compteRevenu = self::compteSource( $imp['source'] );
		$libelle = 'Royalties ' . ( self::sources()[ $imp['source'] ] ?? ucfirst( (string) $imp['source'] ) ) . ( $imp['periode'] ? ' ' . $imp['periode'] : '' );
		$dec = class_exists( 'FKC_Devise' ) ? FKC_Devise::decimales( $devise ) : 2;
		$libelle .= ' — ' . number_format( $brutDevise, $dec, ',', ' ' ) . ' ' . $devise;
		if ( $devise !== $pivot ) { $libelle .= ' au cours de ' . $taux; }
		$fx = array( 'devise' => $devise, 'taux' => $taux, 'brut_devise' => $brutDevise, 'ayants_devise' => $ayantsDevise );

		$distribution = 'distribution' === self::comptablePourPackActif();
		$possible = $distribution ? FKC_DistributionComptable::possible() : FKC_LabelComptable::possible();

		/*
		 * ═══════════════════════════════════════════════════════════════════
		 *  LA DATE DU RELEVÉ NE DATE PLUS LE CHIFFRE D'AFFAIRES (1.779.0)
		 * ═══════════════════════════════════════════════════════════════════
		 *  L'écriture était datée de `$imp['date']` : un relevé de novembre
		 *  reçu en février tombait dans l'exercice suivant. La période
		 *  économique — mois des lignes du fichier, sinon période déclarée
		 *  sur le relevé — décide désormais de l'exercice ; le moteur commun
		 *  des revenus numériques (FKC_RnPeriode) décide de la date, et
		 *  ventile un relevé à cheval sur deux exercices en deux écritures.
		 */
		$plan = self::planComptable( $imp );
		$fracs = array_column( $plan['tranches'], 'fraction' );
		$brutsT  = FKC_RevenuNumerique::repartir( $brutLocal, $fracs, 0 );
		$ayantsT = FKC_RevenuNumerique::repartir( $ayantsLocal, $fracs, 0 );
		$brutDT  = FKC_RevenuNumerique::repartir( $brutDevise, $fracs, 4 );
		$ayDT    = FKC_RevenuNumerique::repartir( $ayantsDevise, $fracs, 4 );
		if ( $possible ) {
			// Vérification préalable de TOUTES les dates : un relevé ventilé ne
			// doit jamais être à moitié comptabilisé.
			foreach ( $plan['tranches'] as $t ) {
				if ( empty( $t['inventaire'] ) && class_exists( 'FKC_Cloture' ) && FKC_Cloture::isLocked( $t['date'] ) ) {
					$motif = method_exists( 'FKC_Cloture', 'motifBlocage' ) ? FKC_Cloture::motifBlocage( $t['date'] ) : '';
					return $refus( 'Comptabilisation refusée — la tranche de l\'exercice ' . $t['exercice'] . ' tombe le '
						. date( 'd/m/Y', strtotime( $t['date'] ) ) . ' dans une période clôturée. ' . $motif . ' Rien n\'a été créé.' );
				}
			}
		}
		/*
		 * ═══════════════════════════════════════════════════════════════════
		 *  UNE SEULE TRANSACTION : ÉCRITURES + DUS + REGISTRE RN (1.793.0)
		 * ═══════════════════════════════════════════════════════════════════
		 *  Le registre commun des revenus numériques était alimenté APRÈS la
		 *  comptabilisation, et une panne de consignation n'était que
		 *  journalisée : on pouvait obtenir un relevé comptabilisé sans son
		 *  dossier RN — donc invisible du cut-off, des produits à recevoir, du
		 *  rapprochement et de la clôture. Tout se passe désormais dans une
		 *  seule transaction : écritures de chaque tranche, dus artistes,
		 *  répartition figée, statut du relevé ET consignation au registre.
		 *  Un échec, quel qu'il soit, annule le tout — « rien n'a été créé »
		 *  est enfin vrai pour la deuxième tranche aussi.
		 */
		$ctx = array();
		try {
			FKC_Tx::executer( function () use ( &$ctx, $plan, $libelle, $devise, $taux, $brutDT, $ayDT, $brutsT, $ayantsT, $distribution, $compteRevenu,
				$possible, $rep, $importId, $imp, $dec, $brutDevise, $brutLocal, $ayantsLocal ) {
				$eid = null; $trancheInfos = array();
				foreach ( $plan['tranches'] as $i => $t ) {
					$libT = $libelle . ( count( $plan['tranches'] ) > 1 ? ' — part ' . FKC_RnPeriode::libelle( $t['debut'], $t['fin'] ) : '' );
					$fxT = array( 'devise' => $devise, 'taux' => $taux, 'brut_devise' => $brutDT[ $i ], 'ayants_devise' => $ayDT[ $i ] );
					$o = array( 'inventaire' => ! empty( $t['inventaire'] ) );
					$id1 = $distribution
						? FKC_DistributionComptable::ecritureRoyalties( $brutsT[ $i ], $ayantsT[ $i ], $t['date'], $libT, $fxT, $o )
						: FKC_LabelComptable::ecritureRoyalties( $compteRevenu, $brutsT[ $i ], $ayantsT[ $i ], $t['date'], $libT, $fxT, $o );
					if ( $possible && ! $id1 ) {
						$der = $distribution ? FKC_DistributionComptable::$dernier : FKC_LabelComptable::$dernier;
						throw new \RuntimeException( 'Comptabilisation refusée — l\'écriture ' . ( $i ? 'de la tranche ' . $t['exercice'] . ' ' : '' )
							. 'n\'a pas pu être enregistrée' . ( ! empty( $der[2] ) ? ' : ' . $der[2] : ' (période close, journal ou compte manquant)' ) . '. Rien n\'a été créé.' );
					}
					$der = $distribution ? FKC_DistributionComptable::$dernier : FKC_LabelComptable::$dernier;
					if ( ! $eid ) { $eid = $id1; }
					$trancheInfos[] = array_merge( $t, array( 'brut' => $brutsT[ $i ], 'part_ayants' => $ayantsT[ $i ],
						'ecriture_id' => $der[0], 'brouillon_id' => $der[1], 'statut' => $der[0] ? 'comptabilise' : ( $der[1] ? 'depose' : 'echec' ) ) );
				}

				$nb = 0; $externes = array();
				foreach ( $rep['par_ayant_droit'] as $r ) {
					if ( (float) $r['montant_local'] <= 0 ) { continue; }
					if ( $r['artiste_id'] ) {
						FKC_Paiement::create( array(
							'artiste_id' => (int) $r['artiste_id'],
							'montant'    => (float) $r['montant_local'],
							'type' => 'royalties', 'statut' => 'a_payer',
							'date' => $imp['date'], 'reference' => 'Import #' . (int) $importId,
							'note' => $libelle . ' — ' . number_format( (float) $r['montant'], $dec, ',', ' ' ) . ' ' . $devise,
						) );
						$nb++;
					} else {
						$externes[] = $r;
					}
				}
				// Fige la répartition : le décompte de ce relevé ne bougera plus.
				$det = self::repartitionDetaillee( $importId );
				FKC_DB::q( 'DELETE FROM lbl_royalty_repartition WHERE import_id=?', array( (int) $importId ) );
				foreach ( $det['lignes'] as $l ) {
					FKC_DB::q( 'INSERT INTO lbl_royalty_repartition(import_id,oeuvre_id,titre,ayant_droit,artiste_id,role,part,montant,montant_local) VALUES(?,?,?,?,?,?,?,?,?)',
						array( (int) $importId, $l['oeuvre_id'], $l['titre'], $l['ayant_droit'], $l['artiste_id'], $l['role'], $l['part'], $l['montant'], (float) $l['montant_local'] ) );
				}
				FKC_DB::q(
					"UPDATE lbl_royalty_imports SET statut='comptabilise', ecriture_id=?, taux_change=? WHERE id=?",
					array( $eid ? (int) $eid : null, $taux, (int) $importId )
				);
				// Registre commun : OBLIGATOIRE. Sans dossier RN, pas de comptabilisation.
				if ( $possible ) {
					$lignesMois = FKC_DB::q( "SELECT COALESCE(periode,'') mois, plateforme, titre_source contenu, SUM(unites) unites, SUM(montant_brut) montant FROM lbl_royalty_lignes WHERE import_id=? GROUP BY 1,2,3", array( (int) $importId ) )->fetchAll();
					$rnId = FKC_RevenuNumerique::consigner( array(
						'origine' => 'royalties', 'origine_id' => (int) $importId, 'source_code' => (string) $imp['source'],
						'periode_texte' => (string) $imp['periode'], 'periode_debut' => $plan['debut'], 'periode_fin' => $plan['fin'],
						'periode_deduite' => $plan['deduite'], 'date_rapport' => (string) $imp['date'], 'devise' => $devise, 'taux' => $taux,
						'montant_devise' => $brutDevise, 'brut' => $brutLocal, 'part_ayants' => $ayantsLocal, 'lignes' => $lignesMois,
					), $trancheInfos );
					if ( ! $rnId ) { throw new \RuntimeException( 'Comptabilisation refusée — le dossier « Revenus numériques » du relevé n\'a pas pu être créé. Rien n\'a été enregistré.' ); }
				}
				$ctx = array( 'eid' => $eid, 'nb' => $nb, 'externes' => $externes, 'tranches' => $trancheInfos );
			} );
		} catch ( \Throwable $e ) {
			$m = $e->getMessage();
			return $refus( 0 === strpos( $m, 'Comptabilisation refusée' ) ? $m : 'Comptabilisation refusée — ' . $m . ' Rien n\'a été créé.' );
		}
		$eid = $ctx['eid']; $nb = $ctx['nb']; $externes = $ctx['externes']; $trancheInfos = $ctx['tranches'];
		return array( $eid, $nb, array(
			'externes' => $externes, 'bloque' => array(),
			'devise' => $devise, 'taux' => $taux,
			'brut_devise' => $brutDevise, 'brut_pivot' => $brutLocal, 'ayants_pivot' => $ayantsLocal, 'pivot' => $pivot,
			'tranches' => $trancheInfos, 'periode_deduite' => $plan['deduite'],
		) );
	}

	/**
	 * Plan de rattachement d'un relevé : période économique (mois des lignes,
	 * sinon période déclarée, sinon mois précédant le relevé — marqué
	 * « déduit ») et tranches datées par exercice.
	 *
	 * @return array{debut:string, fin:string, deduite:int, tranches:array}
	 */
	public static function planComptable( array $imp ) {
		$poids = array();
		try {
			foreach ( FKC_DB::q( "SELECT periode, SUM(montant_brut) m FROM lbl_royalty_lignes WHERE import_id=? AND periode IS NOT NULL AND periode<>'' GROUP BY periode", array( (int) $imp['id'] ) )->fetchAll() as $r ) {
				$poids[ $r['periode'] ] = (float) $r['m'];
			}
		} catch ( \Throwable $e ) {}
		list( $deb, $fin, $deduite, $poids ) = FKC_RevenuNumerique::resoudrePeriode(
			array( 'periode' => (string) ( $imp['periode'] ?? '' ), 'date_rapport' => (string) $imp['date'] ), $poids );
		$tr = FKC_RnPeriode::plan( $deb, $fin, (string) $imp['date'], $poids ?: null );
		return array( 'debut' => $deb, 'fin' => $fin, 'deduite' => $deduite, 'tranches' => $tr );
	}

	/**
	 * Supprime un relevé NON comptabilisé et lève son empreinte (sinon le
	 * fichier corrigé ne pourrait plus jamais être réimporté).
	 *
	 * Un relevé comptabilisé ne se supprime pas : son écriture et ses dus
	 * resteraient orphelins.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function delete( $importId ) {
		self::ensureSchema();
		$imp = FKC_DB::q( 'SELECT statut FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) )->fetch();
		if ( ! $imp ) { return array( false, 'Relevé introuvable.' ); }
		if ( 'comptabilise' === $imp['statut'] ) {
			return array( false, 'Relevé comptabilisé : il ne peut pas être supprimé (son écriture et les dus artistes en dépendent). Contre-passez l\'écriture si le relevé était faux.' );
		}
		FKC_DB::q( 'DELETE FROM lbl_royalty_lignes WHERE import_id=?', array( (int) $importId ) );
		FKC_DB::q( 'DELETE FROM lbl_royalty_repartition WHERE import_id=?', array( (int) $importId ) );
		FKC_DB::q( 'DELETE FROM lbl_royalty_imports WHERE id=?', array( (int) $importId ) );
		try {
			FKC_DB::q( "DELETE FROM imp_empreintes WHERE origine='module:royalties' AND reference=?", array( 'relevé n°' . (int) $importId ) );
		} catch ( \Throwable $e ) {}
		return array( true, 'Relevé supprimé.' );
	}
}
