<?php
/**
 * ENCAISSEMENT D'UN RELEVÉ DE ROYALTIES (1.751.0).
 *
 * ── LE CYCLE RÉEL ────────────────────────────────────────────────────────
 *
 *   1. Le distributeur publie le rapport. Rien n'est versé.
 *      → le relevé est comptabilisé : PRODUIT acquis, CRÉANCE sur le
 *        distributeur, DETTE envers les ayants droit.
 *
 *   2. Le label demande le virement, quand il le décide.
 *      → c'est ici. La créance est soldée, la trésorerie augmente.
 *
 *   3. Le label reverse les artistes. → FKC_Paiement::marquerPaye()
 *
 * Les trois étapes sont désormais distinctes. Elles étaient auparavant
 * confondues : la comptabilisation du relevé débitait la banque comme si le
 * distributeur avait payé le jour même.
 *
 * ── CE QUI SE JOUE ENTRE L'ÉTAPE 1 ET L'ÉTAPE 2 ──────────────────────────
 *
 * Le délai n'est pas neutre. Entre le rapport et le virement :
 *
 *   — le cours de la devise a bougé. La créance a été enregistrée au cours
 *     du relevé ; la banque crédite au cours du jour du virement. La
 *     différence est un ÉCART DE CHANGE RÉALISÉ, qui va directement en
 *     résultat (676 perte / 776 gain), et non au bilan : l'opération est
 *     dénouée, il n'y a plus rien à revaloriser ;
 *
 *   — le distributeur a pu retenir des frais. Ils sont une charge, pas une
 *     diminution du produit : la créance est soldée pour son montant plein,
 *     et les frais passent en 631.
 *
 * Un encaissement PARTIEL est admis : un label retire rarement la totalité
 * d'un coup. Le solde restant dû reste en créance.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RoyaltyEncaissement {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		self::$ready = true;
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS lbl_royalty_encaissements(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				import_id INTEGER NOT NULL,
				date TEXT NOT NULL,
				montant_devise REAL NOT NULL DEFAULT 0,   -- créance soldée, dans la devise du relevé
				frais_devise REAL NOT NULL DEFAULT 0,     -- retenue du distributeur, même devise
				taux REAL,                                -- cours du jour du virement
				montant_local REAL NOT NULL DEFAULT 0,    -- effectivement crédité en trésorerie
				ecart_local REAL NOT NULL DEFAULT 0,      -- écart de change réalisé (+ gain / - perte)
				tresorerie_id INTEGER,
				reference TEXT,
				ecriture_id INTEGER,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_renc_imp ON lbl_royalty_encaissements(import_id);
		" );
	}

	public static function parImport( $importId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM lbl_royalty_encaissements WHERE import_id=? ORDER BY date, id', array( (int) $importId ) )->fetchAll();
	}

	/**
	 * État de l'encaissement d'un relevé.
	 *
	 * Le suivi se fait DANS LA DEVISE DU RELEVÉ, pas en devise des comptes :
	 * c'est en dollars ou en euros que le distributeur doit, et c'est ce
	 * montant-là qu'on rapproche de son espace partenaire. Le suivre en
	 * francs le ferait bouger à chaque variation de cours sans qu'un centime
	 * ait été versé.
	 *
	 * @return array{du: float, encaisse: float, reste: float, devise: string,
	 *               nb: int, solde: bool, local: float}
	 */
	public static function etat( array $imp ) {
		self::ensure();
		$devise = strtoupper( (string) ( $imp['devise'] ?? 'EUR' ) );
		$du     = round( (float) ( $imp['total_brut'] ?? 0 ), 2 );
		$rows   = self::parImport( $imp['id'] ?? 0 );
		$enc = 0.0; $local = 0.0;
		foreach ( $rows as $r ) { $enc += (float) $r['montant_devise']; $local += (float) $r['montant_local']; }
		$enc = round( $enc, 2 );
		return array(
			'du' => $du, 'encaisse' => $enc, 'reste' => round( $du - $enc, 2 ),
			'devise' => $devise, 'nb' => count( $rows ), 'local' => $local,
			// Tolérance d'un centime : les arrondis successifs ne doivent pas
			// laisser un relevé éternellement « presque encaissé ».
			'solde' => ( abs( $du - $enc ) < 0.01 ),
		);
	}

	/**
	 * Enregistre un encaissement demandé par le label.
	 *
	 * @param array $d date, montant_devise, frais_devise, taux, tresorerie_id, reference
	 * @return array{0:bool,1:string}
	 */
	public static function enregistrer( $importId, array $d ) {
		self::ensure();
		$imp = FKC_Royalty::find( $importId );
		if ( ! $imp ) { return array( false, 'Relevé introuvable.' ); }

		/*
		 * Le relevé doit être comptabilisé : sans son écriture, la créance
		 * n'existe pas au bilan et il n'y aurait rien à solder. Encaisser
		 * d'abord créerait une trésorerie sans contrepartie.
		 */
		if ( 'comptabilise' !== ( $imp['statut'] ?? '' ) ) {
			return array( false, 'Comptabilisez le relevé avant d\'enregistrer son encaissement : la créance sur le distributeur n\'existe pas encore.' );
		}

		$etat = self::etat( $imp );
		if ( $etat['solde'] ) { return array( false, 'Ce relevé est déjà intégralement encaissé.' ); }

		$date = trim( (string) ( $d['date'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) { $date = date( 'Y-m-d' ); }
		if ( $date < (string) $imp['date'] ) {
			return array( false, 'L\'encaissement ne peut pas précéder le relevé (' . $imp['date'] . ').' );
		}

		$montant = FKC_Royalty::nombre( $d['montant_devise'] ?? 0 );
		$frais   = max( 0.0, FKC_Royalty::nombre( $d['frais_devise'] ?? 0 ) );
		if ( $montant <= 0 ) { return array( false, 'Montant encaissé nul.' ); }
		if ( $montant > $etat['reste'] + 0.01 ) {
			return array( false, 'Montant supérieur au reste dû (' . number_format( $etat['reste'], 2, ',', ' ' ) . ' ' . $etat['devise'] . ').' );
		}
		if ( $frais >= $montant ) { return array( false, 'Les frais ne peuvent pas atteindre le montant encaissé.' ); }

		$pivot = class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF';
		$devise = $etat['devise'];

		/*
		 * Cours du jour du VIREMENT, pas celui du relevé. Le label peut le
		 * saisir — c'est celui que sa banque a réellement appliqué, et il
		 * prime sur toute table de cours. À défaut, on prend le référentiel
		 * à la date de l'encaissement.
		 */
		$taux = FKC_Royalty::nombre( $d['taux'] ?? 0 );
		if ( $taux <= 0 ) {
			if ( $devise === $pivot ) { $taux = 1.0; }
			elseif ( class_exists( 'FKC_Devise' ) ) {
				$t = FKC_Devise::taux( $devise, $date );
				if ( null === $t['taux'] ) {
					return array( false, 'Aucun cours ' . $devise . '/' . $pivot . ' connu au ' . $date
						. '. Saisissez le cours appliqué par votre banque.' );
				}
				$taux = (float) $t['taux'];
			} else { return array( false, 'Gestion des devises indisponible.' ); }
		}

		$tauxOrigine = (float) ( $imp['taux_change'] ?? 0 );
		if ( $tauxOrigine <= 0 ) { $tauxOrigine = $taux; }

		$arr = fn( $v ) => class_exists( 'FKC_Devise' ) ? FKC_Devise::arrondir( $v, $pivot ) : round( $v, 0 );
		// Créance soldée : au cours d'ORIGINE, celui auquel elle est inscrite.
		$creanceLocal = $arr( $montant * $tauxOrigine );
		// Valeur réellement reçue : au cours du jour, frais déduits.
		$recuLocal   = $arr( ( $montant - $frais ) * $taux );
		$fraisLocal  = $arr( $frais * $taux );
		// Ce qui ne s'explique ni par la créance ni par les frais est un écart
		// de change réalisé : il va droit au résultat, l'opération est dénouée.
		$ecart = round( ( $recuLocal + $fraisLocal ) - $creanceLocal, 2 );

		$eid = FKC_LabelComptable::ecritureEncaissement( array(
			'date' => $date, 'creance_local' => $creanceLocal, 'recu_local' => $recuLocal,
			'frais_local' => $fraisLocal, 'ecart_local' => $ecart,
			'tresorerie' => self::numeroTresorerie( $d['tresorerie_id'] ?? 0 ),
			'libelle' => 'Encaissement royalties ' . ( $imp['periode'] ?: $imp['date'] )
				. ( ! empty( $d['reference'] ) ? ' — ' . trim( (string) $d['reference'] ) : '' ),
			'devise' => $devise, 'montant_devise' => $montant, 'taux' => $taux,
		) );

		/*
		 * Si la comptabilité est disponible et que l'écriture échoue, on
		 * n'enregistre PAS l'encaissement : une créance réputée soldée sans
		 * mouvement de trésorerie se retrouverait introuvable au bilan.
		 */
		if ( FKC_LabelComptable::possible() && ! $eid ) {
			return array( false, 'Encaissement refusé — l\'écriture n\'a pas pu être enregistrée (période close, journal ou compte manquant).' );
		}

		FKC_DB::q( 'INSERT INTO lbl_royalty_encaissements(import_id,date,montant_devise,frais_devise,taux,montant_local,ecart_local,tresorerie_id,reference,ecriture_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
			array( (int) $importId, $date, $montant, $frais, $taux, $recuLocal, $ecart,
				! empty( $d['tresorerie_id'] ) ? (int) $d['tresorerie_id'] : null,
				trim( (string) ( $d['reference'] ?? '' ) ) ?: null,
				$eid ? (int) $eid : null, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null ) );

		$apres = self::etat( FKC_Royalty::find( $importId ) );
		$msg = 'Encaissement de ' . number_format( $montant, 2, ',', ' ' ) . ' ' . $devise . ' enregistré au ' . $date . '.';
		if ( $frais > 0 ) { $msg .= ' Frais retenus : ' . number_format( $frais, 2, ',', ' ' ) . ' ' . $devise . '.'; }
		if ( abs( $ecart ) >= 1 ) {
			$msg .= ' Écart de change ' . ( $ecart > 0 ? 'favorable' : 'défavorable' ) . ' de '
				. number_format( abs( $ecart ), 0, ',', ' ' ) . ' ' . $pivot . ' porté au résultat.';
		}
		$msg .= $apres['solde']
			? ' Le relevé est intégralement encaissé.'
			: ' Reste à encaisser : ' . number_format( $apres['reste'], 2, ',', ' ' ) . ' ' . $devise . '.';
		return array( true, $msg );
	}

	/** Numéro du compte de trésorerie choisi, vide si le label n'en a pas désigné. */
	protected static function numeroTresorerie( $id ) {
		if ( ! $id || ! class_exists( 'FKC_Tresorerie' ) ) { return ''; }
		$t = FKC_Tresorerie::find( (int) $id );
		return $t && ! empty( $t['actif'] ) ? (string) $t['compte_numero'] : '';
	}

	/**
	 * Supprime un encaissement saisi par erreur. L'écriture n'est PAS
	 * contrepassée automatiquement : défaire une écriture comptable est une
	 * décision qui appartient au comptable, et la contrepasser en silence
	 * depuis cet écran laisserait deux mouvements inexpliqués au journal.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function supprimer( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM lbl_royalty_encaissements WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return array( false, 'Encaissement introuvable.' ); }
		FKC_DB::q( 'DELETE FROM lbl_royalty_encaissements WHERE id=?', array( (int) $id ) );
		$msg = 'Encaissement retiré du suivi.';
		if ( $r['ecriture_id'] ) {
			$msg .= ' L\'écriture #' . (int) $r['ecriture_id'] . ' reste au journal : contrepassez-la depuis la comptabilité si elle n\'a pas lieu d\'être.';
		}
		return array( true, $msg );
	}

	/** Relevés comptabilisés dont la créance n'est pas soldée — le suivi du label. */
	public static function enAttente() {
		self::ensure();
		$out = array();
		foreach ( FKC_Royalty::imports() as $imp ) {
			if ( 'comptabilise' !== $imp['statut'] ) { continue; }
			$e = self::etat( $imp );
			if ( $e['solde'] ) { continue; }
			$e['import'] = $imp;
			$out[] = $e;
		}
		return $out;
	}
}
