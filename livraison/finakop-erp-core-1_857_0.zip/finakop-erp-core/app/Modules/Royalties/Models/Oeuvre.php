<?php
/** Catalogue musical : singles (ISRC), albums (UPC), EP. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Oeuvre {
	public static function types() { return array( 'single'=>'Single','album'=>'Album','ep'=>'EP' ); }
	public static function all( $type = '' ) {
		$w = ''; $p = array();
		if ( '' !== $type ) { $w = ' WHERE o.type=?'; $p[] = $type; }
		return FKC_DB::q( "SELECT o.*, a.nom_scene, a.nom artiste_nom FROM lbl_oeuvres o LEFT JOIN lbl_artistes a ON a.id=o.artiste_id{$w} ORDER BY o.date_sortie DESC, o.id DESC", $p )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM lbl_oeuvres WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function map() { $m = array(); foreach ( self::all() as $o ) { $m[ (int) $o['id'] ] = $o['titre']; } return $m; }
	public static function create( $d ) {
		// Le catalogue change : l'index de rapprochement des relevés doit être
		// reconstruit, sinon un titre tout juste créé resterait introuvable.
		if ( method_exists( 'FKC_Royalty', 'oublierCatalogue' ) ) { FKC_Royalty::oublierCatalogue(); }
		if ( class_exists( 'FKC_Royalty' ) ) { FKC_Royalty::ensureSchema(); } // garantit la colonne isrc
		$hasIsrc = false;
		foreach ( FKC_DB::conn()->query( 'PRAGMA table_info(lbl_oeuvres)' ) as $c ) { if ( 'isrc' === $c['name'] ) { $hasIsrc = true; break; } }
		if ( $hasIsrc ) {
			FKC_DB::q( 'INSERT INTO lbl_oeuvres(type,titre,code,duree,date_sortie,upc,isrc,artiste_id,projet_id,actif) VALUES(?,?,?,?,?,?,?,?,?,1)',
				array( isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'single', trim( (string) $d['titre'] ),
					trim( (string) ( $d['code'] ?? '' ) ) ?: null, trim( (string) ( $d['duree'] ?? '' ) ) ?: null,
					trim( (string) ( $d['date_sortie'] ?? '' ) ) ?: null, trim( (string) ( $d['upc'] ?? '' ) ) ?: null,
					trim( (string) ( $d['isrc'] ?? '' ) ) ?: null,
					! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null, ! empty( $d['projet_id'] ) ? (int) $d['projet_id'] : null ) );
		} else {
			FKC_DB::q( 'INSERT INTO lbl_oeuvres(type,titre,code,duree,date_sortie,upc,artiste_id,projet_id,actif) VALUES(?,?,?,?,?,?,?,?,1)',
				array( isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'single', trim( (string) $d['titre'] ),
					trim( (string) ( $d['code'] ?? '' ) ) ?: null, trim( (string) ( $d['duree'] ?? '' ) ) ?: null,
					trim( (string) ( $d['date_sortie'] ?? '' ) ) ?: null, trim( (string) ( $d['upc'] ?? '' ) ) ?: null,
					! empty( $d['artiste_id'] ) ? (int) $d['artiste_id'] : null, ! empty( $d['projet_id'] ) ? (int) $d['projet_id'] : null ) );
		}
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) {
		// Le catalogue change : l'index de rapprochement des relevés doit être
		// reconstruit, sinon un titre tout juste créé resterait introuvable.
		if ( method_exists( 'FKC_Royalty', 'oublierCatalogue' ) ) { FKC_Royalty::oublierCatalogue(); } FKC_DB::q( 'DELETE FROM lbl_oeuvres WHERE id=?', array( (int) $id ) ); }
	public static function count( $type = '' ) {
		if ( '' === $type ) { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM lbl_oeuvres' )->fetchColumn(); }
		return (int) FKC_DB::q( 'SELECT COUNT(*) FROM lbl_oeuvres WHERE type=?', array( $type ) )->fetchColumn();
	}
}
