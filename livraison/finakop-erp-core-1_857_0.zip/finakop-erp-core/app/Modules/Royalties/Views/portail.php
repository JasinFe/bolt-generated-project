<?php /** @var array $artistes @var array|null $sel @var string $token @var array $statuts @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'portail' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Aperçu de l'espace que chaque artiste consulte (streams, royalties, paiements, contrats).</span></div>
<div class="card"><div class="card-body">
	<form method="get" action="<?= e( url( 'royalties/portail' ) ) ?>" style="display:flex;gap:10px;align-items:end">
		<label class="fld" style="flex:1"><span>Choisir un artiste</span>
			<select name="a" onchange="this.form.submit()"><option value="">—</option>
			<?php foreach ( $artistes as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= ($sel && (int)$sel['artiste']['id']===(int)$a['id'])?'selected':'' ?>><?= e( $a['nom_scene'] ?: $a['nom'] ) ?></option><?php endforeach; ?>
			</select></label>
	</form>
</div>

<?php if ( $sel && $sel['artiste'] ) : $ar = $sel['artiste']; ?>
<div class="launch-hero" style="margin-top:6px">
	<div class="launch-ico">🎤</div>
	<div><h1 class="launch-title"><?= e( $ar['nom_scene'] ?: $ar['nom'] ) ?></h1>
		<p class="launch-sub">Code <?= e( $ar['code'] ) ?> · <?= e( $ar['genre'] ?: 'Artiste' ) ?> · part artiste <?= e( fkc_money( $ar['part_artiste'], 0 ) ) ?>%</p></div>
</div>
<div class="form-grid">
	<div class="card"><div class="card-body"><span class="muted">Streams cumulés</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $sel['streams'], 0 ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Royalties générées</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $sel['royalties'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Solde à percevoir</span><div style="font-size:1.5em;font-weight:700;color:<?= $sel['solde']>0?'var(--orange)':'var(--ok)' ?>"><?= e( fkc_money( $sel['solde'] ) ) ?></div></div></div>
</div>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Paiements</h2></div>
		<table class="table"><thead><tr><th>Date</th><th>Type</th><th class="num">Montant</th><th>Statut</th></tr></thead><tbody>
		<?php if ( ! $sel['paiements'] ) : ?><tr><td colspan="4" class="empty">Aucun paiement.</td></tr>
		<?php else : foreach ( $sel['paiements'] as $p ) : ?><tr><td><?= e( $p['date'] ) ?></td><td><?= e( $p['type'] ) ?></td><td class="num"><?= e( fkc_money( $p['montant'] ) ) ?></td><td><span class="modbadge <?= $p['statut']==='paye'?'b-on':'b-off' ?>"><?= e( $statuts[ $p['statut'] ] ?? $p['statut'] ) ?></span></td></tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
	<div class="card card-flush"><div class="card-head"><h2>Catalogue & contrat</h2></div><div class="card-body">
		<p class="help">Contrat n° <strong><?= e( $ar['contrat_num'] ?: '—' ) ?></strong> (<?= e( $ar['contrat_type'] ?: '—' ) ?>) — signé le <?= e( $ar['date_signature'] ?: '—' ) ?>.</p>
		<table class="table"><tbody>
		<?php if ( ! $sel['oeuvres'] ) : ?><tr><td class="empty">Aucune œuvre.</td></tr>
		<?php else : foreach ( $sel['oeuvres'] as $o ) : ?><tr><td><?= e( $o['titre'] ) ?> <span class="muted">(<?= e( $o['type'] ) ?>)</span></td></tr><?php endforeach; endif; ?>
		</tbody></table>
		<div class="actions"><a class="btn btn-ghost btn-sm" href="#" onclick="window.print();return false">⬇ Relevé (impression)</a></div>
	</div></div>
</div>
<div class="card"><div class="card-body">
	<span class="muted">Lien d'accès personnel de l'artiste (jeton)</span>
	<div style="margin-top:6px"><code style="font-size:.9em"><?= e( url( 'royalties/portail?a=' . (int) $ar['id'] ) ) ?></code> · jeton <code><?= e( $token ) ?></code></div>
</div></div>
<?php endif; ?>
