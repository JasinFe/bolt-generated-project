<?php /** @var array $concerts @var array $statuts @var array $types @var array $artistes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'concerts' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouvel événement</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/concerts' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Titre *</span><input name="titre" required></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Artiste</span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $id => $nom ) : ?><option value="<?= (int) $id ?>"><?= e( $nom ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Lieu</span><input name="lieu"></label>
			<label class="fld"><span>Date</span><input type="date" name="date"></label>
			<label class="fld"><span>Cachet</span><input type="number" step="any" name="cachet" value="0"></label>
			<label class="fld"><span>Billets vendus</span><input type="number" name="billets_vendus" value="0"></label>
			<label class="fld"><span>Prix du billet</span><input type="number" step="any" name="billet_prix" value="0"></label>
			<label class="fld"><span>Statut</span><select name="statut"><?php foreach ( $statuts as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<div class="actions"><button class="btn btn-primary">Ajouter</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2><?= e( FKC_Term::t('evenements','Événements') ) ?> (<?= count( $concerts ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Événement</th><th>Artiste</th><th>Lieu</th><th>Date</th><th class="num">Recettes</th><th class="num">Résultat</th><th>Statut</th><th></th></tr></thead><tbody>
		<?php if ( ! $concerts ) : ?><tr><td colspan="8" class="empty">Aucun événement.</td></tr>
		<?php else : foreach ( $concerts as $c ) : $res = FKC_Concert::resultat( $c ); ?><tr>
			<td><strong><?= e( $c['titre'] ) ?></strong><br><span class="muted" style="font-size:.85em"><?= e( $types[ $c['type'] ] ?? $c['type'] ) ?></span></td>
			<td><?= e( $c['nom_scene'] ?: $c['artiste_nom'] ?: '—' ) ?></td><td><?= e( $c['lieu'] ?: '—' ) ?></td><td><?= e( $c['date'] ?: '—' ) ?></td>
			<td class="num"><?= e( fkc_money( $c['recettes'] ) ) ?></td>
			<td class="num" style="color:<?= $res>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $res ) ) ?></td>
			<td><span class="modbadge <?= in_array($c['statut'],array('realise','confirme'),true)?'b-on':'b-off' ?>"><?= e( $statuts[ $c['statut'] ] ?? $c['statut'] ) ?></span></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/concerts/' . (int) $c['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
