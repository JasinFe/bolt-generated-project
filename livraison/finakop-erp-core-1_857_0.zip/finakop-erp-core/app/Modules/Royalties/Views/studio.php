<?php /** @var array $sessions @var array $oeuvres @var array $artistes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'studio' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouvelle session</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/studio' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Date</span><input type="date" name="date"></label>
			<label class="fld"><span>Studio</span><input name="studio"></label>
			<label class="fld"><span>Œuvre</span><select name="oeuvre_id"><option value="">—</option><?php foreach ( $oeuvres as $id => $t ) : ?><option value="<?= (int) $id ?>"><?= e( $t ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Artiste</span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $id => $n ) : ?><option value="<?= (int) $id ?>"><?= e( $n ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Beatmaker</span><input name="beatmaker"></label>
			<label class="fld"><span>Ingénieur son</span><input name="ingenieur"></label>
			<label class="fld"><span>Coût enregistrement</span><input type="number" step="any" name="cout_enregistrement" value="0"></label>
			<label class="fld"><span>Coût mix</span><input type="number" step="any" name="cout_mix" value="0"></label>
			<label class="fld"><span>Coût mastering</span><input type="number" step="any" name="cout_mastering" value="0"></label>
			<div class="actions"><button class="btn btn-primary">Enregistrer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Sessions (<?= count( $sessions ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Date</th><th>Studio</th><th>Œuvre</th><th>Participants</th><th class="num">Coût total</th><th></th></tr></thead><tbody>
		<?php if ( ! $sessions ) : ?><tr><td colspan="6" class="empty">Aucune session.</td></tr>
		<?php else : foreach ( $sessions as $s ) : ?><tr>
			<td><?= e( $s['date'] ?: '—' ) ?></td><td><?= e( $s['studio'] ?: '—' ) ?></td><td><?= e( $s['oeuvre'] ?: '—' ) ?></td>
			<td class="muted" style="font-size:.9em"><?= e( trim( ( $s['beatmaker'] ? 'Beat: ' . $s['beatmaker'] : '' ) . ' ' . ( $s['ingenieur'] ? '· Ing: ' . $s['ingenieur'] : '' ) ) ?: '—' ) ?></td>
			<td class="num"><?= e( fkc_money( $s['cout_total'] ) ) ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/studio/' . (int) $s['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
