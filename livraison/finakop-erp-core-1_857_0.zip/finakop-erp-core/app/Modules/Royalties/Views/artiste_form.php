<?php /** @var array|null $a @var array $statuts @var array $contrats @var array|null $hist @var float $solde @var string $token @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$v = function ( $k, $def = '' ) use ( $a ) { return e( $a[ $k ] ?? $def ); };
$action = $a ? url( 'royalties/artistes/' . (int) $a['id'] ) : url( 'royalties/artistes' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'artistes' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span><a href="<?= e( url( 'royalties/artistes' ) ) ?>">← Artistes</a> &nbsp; <strong><?= $a ? e( FKC_Artiste::nomScene( $a ) ) : FKC_Term::t('talent_new','Nouveau talent') ?></strong></span>
	<?php if ( $a ) : ?><form method="post" action="<?= e( url( 'royalties/artistes/' . (int) $a['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer cet artiste ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Supprimer</button></form><?php endif; ?>
</div>
<form method="post" action="<?= e( $action ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-rows">
		<div class="card"><div class="card-head"><h2>Fiche <?= e( fkc_lc( FKC_Term::t('talent','talent') ) ) ?></h2></div><div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Code ID *</span><input name="code" value="<?= $v( 'code' ) ?>" required></label>
				<label class="fld"><span>Nom *</span><input name="nom" value="<?= $v( 'nom' ) ?>" required></label>
				<label class="fld"><span><?= e( FKC_Term::t('talent_alias','Alias') ) ?></span><input name="nom_scene" value="<?= $v( 'nom_scene' ) ?>"></label>
				<label class="fld"><span><?= e( FKC_Term::t('talent_domaine','Domaine') ) ?></span><input name="genre" value="<?= $v( 'genre' ) ?>"></label>
				<label class="fld"><span>Téléphone</span><input name="telephone" value="<?= $v( 'telephone' ) ?>"></label>
				<label class="fld"><span>Email</span><input name="email" value="<?= $v( 'email' ) ?>"></label>
				<label class="fld"><span>Date de naissance</span><input type="date" name="date_naissance" value="<?= $v( 'date_naissance' ) ?>"></label>
				<label class="fld"><span>Nationalité</span><input name="nationalite" value="<?= $v( 'nationalite' ) ?>"></label>
				<label class="fld"><span>Manager</span><input name="manager" value="<?= $v( 'manager' ) ?>"></label>
				<label class="fld"><span>Photo (URL)</span><input name="photo_url" value="<?= $v( 'photo_url' ) ?>"></label>
			</div>
		</div></div>
		<div class="card"><div class="card-head"><h2>Contrat & répartition</h2></div><div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>N° de contrat</span><input name="contrat_num" value="<?= $v( 'contrat_num' ) ?>"></label>
				<label class="fld"><span>Type de contrat</span><select name="contrat_type"><option value="">—</option><?php foreach ( $contrats as $k => $lbl ) : ?><option value="<?= e( $k ) ?>" <?= ($a['contrat_type']??'')===$k?'selected':'' ?>><?= e( $lbl ) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Date signature</span><input type="date" name="date_signature" value="<?= $v( 'date_signature' ) ?>"></label>
				<label class="fld"><span>Date fin de contrat</span><input type="date" name="date_fin_contrat" value="<?= $v( 'date_fin_contrat' ) ?>"></label>
				<label class="fld"><span>Part artiste (%)</span><input type="number" step="0.1" min="0" max="100" name="part_artiste" value="<?= $v( 'part_artiste', '50' ) ?>"></label>
				<label class="fld"><span>Statut</span><select name="statut"><?php foreach ( $statuts as $k => $lbl ) : ?><option value="<?= e( $k ) ?>" <?= ($a['statut']??'actif')===$k?'selected':'' ?>><?= e( $lbl ) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Compte avances</span><input name="compte_avance" value="<?= $v( 'compte_avance', '409110' ) ?>"></label>
				<label class="fld"><span>Compte royalties dues</span><input name="compte_royalties" value="<?= $v( 'compte_royalties', '401160' ) ?>"></label>
				<label class="fld-check"><input type="checkbox" name="actif" value="1" <?= (!$a||!empty($a['actif']))?'checked':'' ?>> <span>Actif</span></label>
			</div>
			<p class="help" style="margin:6px 0 0">La part <?= e( fkc_lc( FKC_Term::t('talent','talent') ) ) ?> sert de base au calcul automatique des reversements (le reste revient à la structure).</p>
			<label class="fld" style="margin-top:8px"><span>Notes</span><textarea name="notes" rows="2"><?= $v( 'notes' ) ?></textarea></label>
		</div></div>
	</div>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $a ? 'Enregistrer' : 'Créer' ?></button></div>
</form>

<?php if ( $a && $hist ) : ?>
<div class="form-grid">
	<div class="card"><div class="card-body"><span class="muted">Solde dû à l'artiste</span><div style="font-size:1.4em;font-weight:700;color:<?= $solde>0?'var(--orange)':'var(--ok)' ?>"><?= e( fkc_money( $solde ) ) ?></div>
		<div class="help" style="margin-top:8px">Lien portail : <code style="font-size:.85em"><?= e( url( 'royalties/portail?a=' . (int) $a['id'] ) ) ?></code></div></div></div>
	<div class="card card-flush"><div class="card-head"><h2>Catalogue</h2></div><table class="table"><tbody>
		<?php if ( ! $hist['oeuvres'] ) : ?><tr><td class="empty">Aucune œuvre.</td></tr>
		<?php else : foreach ( $hist['oeuvres'] as $o ) : ?><tr><td><?= e( $o['titre'] ) ?> <span class="muted">(<?= e( $o['type'] ) ?>)</span></td></tr><?php endforeach; endif; ?>
	</tbody></table></div>
</div>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Concerts</h2></div><table class="table"><tbody>
		<?php if ( ! $hist['concerts'] ) : ?><tr><td class="empty">Aucun concert.</td></tr>
		<?php else : foreach ( $hist['concerts'] as $c ) : ?><tr><td><?= e( $c['titre'] ) ?></td><td class="num"><?= e( $c['date'] ) ?></td></tr><?php endforeach; endif; ?>
	</tbody></table></div>
	<div class="card card-flush"><div class="card-head"><h2>Paiements</h2></div><table class="table"><tbody>
		<?php if ( ! $hist['paiements'] ) : ?><tr><td class="empty">Aucun paiement.</td></tr>
		<?php else : foreach ( $hist['paiements'] as $p ) : ?><tr><td><?= e( $p['type'] ) ?></td><td class="num"><?= e( fkc_money( $p['montant'] ) ) ?></td><td><span class="modbadge <?= $p['statut']==='paye'?'b-on':'b-off' ?>"><?= e( $p['statut'] ) ?></span></td></tr><?php endforeach; endif; ?>
	</tbody></table></div>
</div>
<?php endif; ?>
