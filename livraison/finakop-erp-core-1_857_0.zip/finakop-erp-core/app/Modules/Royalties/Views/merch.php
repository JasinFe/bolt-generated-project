<?php /** @var array $produits @var array $types @var float $ca @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'merch' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Chiffre d'affaires merch : <strong style="color:var(--ok)"><?= e( fkc_money( $ca ) ) ?></strong></span></div>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouveau produit</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/merch' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Libellé *</span><input name="libelle" required></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Prix d'achat</span><input type="number" step="any" name="prix_achat" value="0"></label>
			<label class="fld"><span>Prix de vente</span><input type="number" step="any" name="prix_vente" value="0"></label>
			<label class="fld"><span>Stock initial</span><input type="number" step="any" name="stock" value="0"></label>
			<div class="actions"><button class="btn btn-primary">Ajouter</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Produits (<?= count( $produits ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Produit</th><th>Type</th><th class="num">PV</th><th class="num">Stock</th><th class="num">Vendus</th><th class="num">CA</th><th>Vente</th><th></th></tr></thead><tbody>
		<?php if ( ! $produits ) : ?><tr><td colspan="8" class="empty">Aucun produit.</td></tr>
		<?php else : foreach ( $produits as $m ) : $benef = ( (float) $m['prix_vente'] - (float) $m['prix_achat'] ) * (float) $m['vendus']; ?><tr>
			<td><strong><?= e( $m['libelle'] ) ?></strong></td><td><?= e( $types[ $m['type'] ] ?? $m['type'] ) ?></td>
			<td class="num"><?= e( fkc_money( $m['prix_vente'] ) ) ?></td><td class="num"><?= e( fkc_money( $m['stock'], 0 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $m['vendus'], 0 ) ) ?></td><td class="num"><?= e( fkc_money( $m['ca'] ) ) ?> <span class="muted">(bén. <?= e( fkc_money( $benef ) ) ?>)</span></td>
			<td><form method="post" action="<?= e( url( 'royalties/merch/' . (int) $m['id'] . '/vente' ) ) ?>" style="display:flex;gap:4px"><?= FKC_Csrf::field() ?><input type="number" name="quantite" placeholder="Qté" style="width:60px"><input type="number" step="any" name="pu" value="<?= e( $m['prix_vente'] ) ?>" style="width:80px"><button class="btn btn-primary btn-sm">+</button></form></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/merch/' . (int) $m['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
