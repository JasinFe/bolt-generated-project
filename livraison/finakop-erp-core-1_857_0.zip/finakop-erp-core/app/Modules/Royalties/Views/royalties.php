<?php /** @var array $imports @var array $conversions @var array|null $sel @var array $sources @var array $artistes @var array $oeuvres @var array $parPlateforme @var array|null $repartition @var array $nonAttribues @var array $devises @var string $pivot @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$parPlateforme = $parPlateforme ?? array();
$repartition   = $repartition ?? null;
$conversions   = $conversions ?? array();
$nonAttribues  = $nonAttribues ?? array();
$oeuvres       = $oeuvres ?? array();
$devises       = $devises ?? array( 'USD', 'EUR' );
$pivot         = $pivot ?? 'XOF';
$regles        = FKC_Royalty::regles();
/* Montant en devise du relevé (2 décimales) et en monnaie locale (sans décimale en XOF). */
$mDev = function ( $v, $dev ) { return number_format( (float) $v, 2, ',', ' ' ) . ' ' . $dev; };
$mLoc = function ( $v, $dev ) { return null === $v ? '—' : number_format( (float) $v, class_exists( 'FKC_Devise' ) ? FKC_Devise::decimales( $dev ) : 0, ',', ' ' ) . ' ' . $dev; };
$regleCls = array( 'split' => 'b-on', 'fiche' => 'b-on', 'bareme_titre' => 'b-on', 'bareme_collab' => 'b-on',
	'collab_auto' => 'b-on', 'label' => 'b-off', 'bareme_incomplet' => 'b-off',
	'split_incomplet' => 'b-err', 'non_attribue' => 'b-err', 'sans_ayant_droit' => 'b-err' );
// Règles issues d'une ventilation multi-artistes : la ligne ne porte qu'une
// fraction du montant du relevé, et il faut le dire — sinon deux lignes au
// même taux, l'une entière et l'autre à moitié, se ressemblent à l'écran.
$regleVentilee = array( 'bareme_titre', 'bareme_collab', 'bareme_incomplet', 'collab_auto' );
?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'royalties' ) ); ?>
<?php if ( $flash ) : ?><div class="alert <?= false !== strpos( (string) $flash, '⚠️' ) ? 'alert-warn' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2><?= e( FKC_Term::t('releve','Importer un rapport') ) ?></h2></div><div class="card-body">
		<form method="post" enctype="multipart/form-data" action="<?= e( url( 'royalties/royalties/import' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid">
				<label class="fld"><span>Distributeur <span class="muted">(source du relevé)</span></span><select name="source"><?php foreach ( $sources as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Période</span><input name="periode" placeholder="2026-03"></label>
				<label class="fld"><span>Date du relevé <span class="muted">(date du cours)</span></span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld"><span>Devise du relevé</span><select name="devise"><?php foreach ( $devises as $d ) : if ( $d === $pivot ) { continue; } ?><option value="<?= e( $d ) ?>"><?= e( $d ) ?></option><?php endforeach; ?><option value="<?= e( $pivot ) ?>"><?= e( $pivot ) ?> (monnaie locale)</option></select></label>
				<label class="fld"><span>Cours appliqué <span class="muted">(1 unité = … <?= e( $pivot ) ?>, facultatif)</span></span><input name="cours" inputmode="decimal" placeholder="ex. 605,50"></label>
			</div>
			<label class="fld"><span>Fichier du relevé <span class="muted">(CSV / TSV, 8 Mo max)</span></span><input type="file" name="fichier" accept=".csv,.tsv,.txt,text/csv,text/tab-separated-values"></label>
			<label class="fld"><span>…ou collez le contenu</span><textarea name="csv" rows="3" placeholder="Collez ici le rapport exporté (ex. TuneCore « Music Sales »).&#10;Le format natif est reconnu automatiquement : Store Name, ISRC, # Units Sold, Total Earned…"></textarea></label>
			<p class="help">La <strong>devise lue dans le fichier</strong> (colonne Currency) l'emporte sur celle indiquée ici. Le montant est converti en <?= e( $pivot ) ?> au cours de la <strong>date du relevé</strong> : saisissez celui que votre banque a appliqué au versement, ou laissez vide pour reprendre le cours enregistré dans Comptabilité → Devises. L'imputation aux titres se fait par <strong>ISRC</strong> ; les titres inconnus sont à attribuer avant la comptabilisation.</p>
			<div class="actions"><button class="btn btn-primary">Créer le relevé</button></div>
		</form>
	</div></div>
	<div class="card card-flush"><div class="card-head"><h2>Relevés (<?= count( $imports ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Date</th><th>Source</th><th>Période</th><th class="num">Montant relevé</th><th class="num">En <?= e( $pivot ) ?></th><th>Statut</th><th></th></tr></thead><tbody>
		<?php if ( ! $imports ) : ?><tr><td colspan="7" class="empty">Aucun relevé importé.</td></tr>
		<?php else : foreach ( $imports as $im ) : $cv = $conversions[ (int) $im['id'] ] ?? FKC_Royalty::conversion( $im ); ?><tr>
			<td><?= e( $im['date'] ) ?></td><td><strong><?= e( $sources[ $im['source'] ] ?? $im['source'] ) ?></strong></td>
			<td><?= e( $im['periode'] ?: '—' ) ?></td>
			<td class="num"><?= e( $mDev( $im['total_brut'], $cv['devise'] ) ) ?></td>
			<td class="num"><?php if ( $cv['ok'] ) : ?><strong><?= e( $mLoc( $cv['total_local'], $cv['pivot'] ) ) ?></strong><?php else : ?><span class="modbadge b-err" title="<?= e( $cv['message'] ) ?>">cours manquant</span><?php endif; ?></td>
			<td><span class="modbadge <?= $im['statut']==='comptabilise'?'b-on':'b-off' ?>"><?= 'comptabilise' === $im['statut'] ? 'Comptabilisé' : 'À comptabiliser' ?></span></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/royalties?i=' . (int) $im['id'] ) ) ?>">Ouvrir</a></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>

<?php if ( $sel ) :
	$conv = $repartition['conversion'] ?? FKC_Royalty::conversion( $sel );
	$dev = $conv['devise'];
	$ouvert = 'comptabilise' !== $sel['statut'];
	$bloque = $repartition['bloque'] ?? array();
?>
<div class="card card-flush"><div class="card-head"><h2>Relevé <?= e( $sources[ $sel['source'] ] ?? $sel['source'] ) ?> · <?= e( $sel['periode'] ?: $sel['date'] ) ?></h2>
	<div class="actions" style="margin:0">
		<?php if ( $ouvert ) : ?>
			<?php /* Rejoue la ventilation avec les barèmes en vigueur : un barème créé après l'import restait sans effet. */ ?>
			<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/reventiler' ) ) ?>" onsubmit="return confirm('Rejouer la ventilation de ce relevé avec les barèmes en vigueur ? Les lignes seront recalculées.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" title="Applique les barèmes et rattachements créés depuis l'import">↻ Re-ventiler</button></form>
			<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/comptabiliser' ) ) ?>" onsubmit="return confirm('Comptabiliser ce relevé et générer les dus des artistes ?')"><?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" <?= ( $bloque || ! $conv['ok'] ) ? 'disabled title="Attribuez les revenus sans titulaire et renseignez le cours d\'abord"' : '' ?>>Comptabiliser</button></form>
			<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ce relevé ? Vous pourrez réimporter le fichier.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" title="Supprimer ce relevé">🗑</button></form>
		<?php else : ?><span class="modbadge b-on">Comptabilisé<?= $sel['ecriture_id'] ? ' · écriture #' . (int) $sel['ecriture_id'] : '' ?></span><?php endif; ?>
	</div>
<?php
/*
 * ENCAISSEMENT — le distributeur publie le rapport, il ne vire rien.
 * C'est le label qui demande le versement quand il le décide. Le relevé
 * constate le produit et la créance ; ce bloc solde la créance.
 */
$enc = $encaissement ?? null;
$encs = $encaissements ?? array();
$treso = $tresorerie ?? array();
$icoT = array( 'caisse' => '💵', 'banque' => '🏦', 'mobile_money' => '📱' );
?>
<?php if ( $enc && 'comptabilise' === $sel['statut'] ) : ?>
<div class="card" style="margin:12px 0">
	<div class="card-head"><h2>Encaissement du distributeur</h2></div>
	<div class="card-body">
		<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:center;margin-bottom:12px">
			<div><div class="muted" style="font-size:11px">Créance sur le distributeur</div><strong style="font-size:16px"><?= e( number_format( $enc['du'], 2, ',', ' ' ) ) ?> <?= e( $enc['devise'] ) ?></strong></div>
			<div><div class="muted" style="font-size:11px">Déjà encaissé</div><strong style="font-size:16px;color:var(--ok)"><?= e( number_format( $enc['encaisse'], 2, ',', ' ' ) ) ?> <?= e( $enc['devise'] ) ?></strong></div>
			<div><div class="muted" style="font-size:11px">Reste à demander</div><strong style="font-size:16px;color:<?= $enc['solde'] ? 'var(--muted)' : 'var(--orange)' ?>"><?= e( number_format( $enc['reste'], 2, ',', ' ' ) ) ?> <?= e( $enc['devise'] ) ?></strong></div>
			<?php if ( $enc['solde'] ) : ?><span class="modbadge b-on">Intégralement encaissé</span><?php endif; ?>
		</div>

		<?php if ( $encs ) : ?>
			<table class="table" style="margin-bottom:12px"><thead><tr><th>Date</th><th class="num">Encaissé</th><th class="num">Frais</th><th class="num">Cours</th><th class="num">Reçu</th><th>Réf.</th><th></th></tr></thead><tbody>
			<?php foreach ( $encs as $x ) : ?><tr>
				<td><?= e( $x['date'] ) ?></td>
				<td class="num"><?= e( number_format( (float) $x['montant_devise'], 2, ',', ' ' ) ) ?> <?= e( $enc['devise'] ) ?></td>
				<td class="num muted"><?= (float) $x['frais_devise'] > 0 ? e( number_format( (float) $x['frais_devise'], 2, ',', ' ' ) ) : '—' ?></td>
				<td class="num muted"><?= e( str_replace( '.', ',', (string) (float) $x['taux'] ) ) ?></td>
				<td class="num"><strong><?= e( fkc_money( $x['montant_local'] ) ) ?></strong>
					<?php if ( abs( (float) $x['ecart_local'] ) >= 1 ) : ?><br><span class="muted" style="font-size:11px" title="Écart de change réalisé, porté au résultat"><?= (float) $x['ecart_local'] > 0 ? '+' : '' ?><?= e( fkc_money( $x['ecart_local'] ) ) ?> change</span><?php endif; ?></td>
				<td class="muted" style="font-size:12px"><?= e( $x['reference'] ?: '—' ) ?></td>
				<td class="right"><form method="post" action="<?= e( url( 'royalties/encaissements/' . (int) $x['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Retirer cet encaissement du suivi ? L\'écriture comptable restera au journal.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
			</tr><?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>

		<?php if ( ! $enc['solde'] ) : ?>
			<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/encaisser' ) ) ?>" class="form-grid" style="grid-template-columns:repeat(6,1fr);align-items:end;gap:8px">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Date du virement</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>" required></label>
				<label class="fld"><span>Montant (<?= e( $enc['devise'] ) ?>)</span><input name="montant_devise" value="<?= e( number_format( $enc['reste'], 2, '.', '' ) ) ?>" required></label>
				<label class="fld"><span>Frais retenus</span><input name="frais_devise" value="0" title="Retenue du distributeur — passe en charge, ne réduit pas la créance"></label>
				<label class="fld"><span>Cours appliqué <span class="muted">(vide = référentiel)</span></span><input name="taux" placeholder="auto"></label>
				<label class="fld"><span>Compte crédité</span>
					<select name="tresorerie_id"><option value="">Banque (défaut)</option>
					<?php foreach ( $treso as $t ) : ?><option value="<?= (int) $t['id'] ?>"><?= e( $icoT[ $t['type'] ] ?? '' ) ?> <?= e( $t['libelle'] ) ?></option><?php endforeach; ?></select>
				</label>
				<label class="fld"><span>Référence</span><input name="reference" placeholder="Réf. virement"></label>
				<div class="actions" style="grid-column:1/-1"><button class="btn btn-primary btn-sm">Enregistrer l'encaissement</button></div>
			</form>
			<p class="help" style="margin-top:6px">Le cours saisi est celui que votre banque a réellement appliqué : il prime sur le référentiel. La différence avec le cours du relevé est portée en écart de change réalisé (676 / 776). Les encaissements partiels sont admis.</p>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

</div>
	<div class="card-body" style="border-bottom:1px solid var(--line)">
		<div class="cards-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
			<div class="stat"><span class="stat-label">Montant du relevé</span><span class="stat-value" style="font-size:20px"><?= e( $mDev( $sel['total_brut'], $dev ) ) ?></span></div>
			<div class="stat"><span class="stat-label">Contre-valeur</span><span class="stat-value" style="font-size:20px"><?= $conv['ok'] ? e( $mLoc( $conv['total_local'], $conv['pivot'] ) ) : '—' ?></span></div>
			<div class="stat"><span class="stat-label">Cours</span><span class="stat-value" style="font-size:20px"><?= $conv['ok'] ? e( '1 ' . $dev . ' = ' . rtrim( rtrim( number_format( (float) $conv['taux'], 4, ',', ' ' ), '0' ), ',' ) . ' ' . $conv['pivot'] ) : '—' ?></span>
				<?php if ( $conv['ok'] ) : ?><small class="muted"><?= e( $conv['source'] . ( $conv['date'] && ! $conv['fixe'] ? ' · ' . $conv['date'] : '' ) ) ?></small><?php endif; ?></div>
		</div>
		<?php if ( ! $conv['ok'] ) : ?>
			<div class="alert alert-warn" style="margin:12px 0 0">⚠️ <?= e( $conv['message'] ) ?></div>
		<?php endif; ?>
		<?php if ( $ouvert && $dev !== $conv['pivot'] ) : ?>
			<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/cours' ) ) ?>" class="form-grid form-compact" style="align-items:end;margin-top:12px">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span><?= $conv['ok'] ? 'Corriger le cours' : 'Saisir le cours' ?> du <?= e( $sel['date'] ) ?> (1 <?= e( $dev ) ?> = … <?= e( $conv['pivot'] ) ?>)</span><input name="cours" inputmode="decimal" required placeholder="ex. 605,50"></label>
				<button class="btn btn-ghost btn-sm">Enregistrer le cours</button>
			</form>
			<p class="help" style="margin-bottom:0">Le cours est enregistré dans Comptabilité → Devises à la date du relevé ; il vaut pour toute opération en <?= e( $dev ) ?> de ce jour.</p>
		<?php endif; ?>
	</div>

	<?php if ( $ouvert && $nonAttribues ) : ?>
	<div class="card-body" style="border-bottom:1px solid var(--line)">
		<h3 style="margin:0 0 6px">⚠️ Titres non rattachés au catalogue (<?= count( $nonAttribues ) ?>)</h3>
		<p class="help" style="margin-top:0">Le distributeur les a payés, mais aucune œuvre du catalogue ne correspond à leur ISRC ni à leur titre. Dites à qui ils reviennent : ils ne partent plus en revenu du label par défaut. En choisissant une œuvre, son ISRC est retenu pour les prochains relevés.</p>
		<table class="table"><thead><tr><th>Titre (distributeur)</th><th>Artiste (distributeur)</th><th>ISRC</th><th class="num">Montant</th><th>Attribuer à</th></tr></thead><tbody>
		<?php foreach ( $nonAttribues as $na ) : ?><tr>
			<td><strong><?= e( '' !== $na['titre'] ? $na['titre'] : '(sans titre)' ) ?></strong></td>
			<td><?= e( '' !== $na['artiste'] ? $na['artiste'] : '—' ) ?></td>
			<td class="code"><?= e( $na['isrc'] ?: '—' ) ?></td>
			<td class="num"><?= e( $mDev( $na['montant'], $dev ) ) ?></td>
			<td>
				<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/attribuer' ) ) ?>" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
					<?= FKC_Csrf::field() ?>
					<input type="hidden" name="titre" value="<?= e( $na['titre'] ) ?>">
					<input type="hidden" name="artiste" value="<?= e( $na['artiste'] ) ?>">
					<input type="hidden" name="memoriser" value="1">
					<select name="cible" required style="min-width:220px">
						<option value="">Choisir…</option>
						<optgroup label="Œuvre du catalogue">
							<?php foreach ( $oeuvres as $o ) : ?><option value="o:<?= (int) $o['id'] ?>" <?= 0 === strcasecmp( (string) $o['titre'], (string) $na['titre'] ) ? 'selected' : '' ?>><?= e( $o['titre'] . ( ( $o['nom_scene'] ?? '' ) || ( $o['artiste_nom'] ?? '' ) ? ' — ' . ( $o['nom_scene'] ?: $o['artiste_nom'] ) : '' ) ) ?></option><?php endforeach; ?>
						</optgroup>
						<optgroup label="Artiste (titre hors catalogue)">
							<?php foreach ( $artistes as $a ) : ?><option value="a:<?= (int) $a['id'] ?>"><?= e( ( $a['nom_scene'] ?: $a['nom'] ) . ' (' . (float) $a['part_artiste'] . ' %)' ) ?></option><?php endforeach; ?>
						</optgroup>
						<option value="label">Revenu du label (aucun ayant droit)</option>
					</select>
					<button class="btn btn-primary btn-sm">Attribuer</button>
				</form>
			</td>
		</tr><?php endforeach; ?>
		</tbody></table>
	</div>
	<?php endif; ?>

	<?php if ( $ouvert ) : ?>
	<div class="card-body" style="border-bottom:1px solid var(--line)">
		<form method="post" action="<?= e( url( 'royalties/royalties/' . (int) $sel['id'] . '/ligne' ) ) ?>" class="form-grid" style="align-items:end">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Œuvre</span><select name="oeuvre_id"><option value="">— hors catalogue —</option><?php foreach ( $oeuvres as $o ) : ?><option value="<?= (int) $o['id'] ?>"><?= e( $o['titre'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Artiste <span class="muted">(si hors catalogue)</span></span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['nom_scene'] ?: $a['nom'] ) ?> (<?= e( (string) (float) $a['part_artiste'] ) ?> %)</option><?php endforeach; ?></select></label>
			<label class="fld"><span>Plateforme</span><input name="plateforme"></label>
			<label class="fld"><span>Unités / streams</span><input type="number" name="streams" value="0"></label>
			<label class="fld"><span>Montant (<?= e( $dev ) ?>)</span><input type="number" step="any" name="montant_brut" value="0"></label>
			<button class="btn btn-primary btn-sm">+ Ligne</button>
		</form>
	</div>
	<?php endif; ?>
	<table class="table"><thead><tr><th>Titre</th><th>Artiste</th><th>Plateforme</th><th class="num">Unités</th><th class="num">Montant</th><th class="num">En <?= e( $conv['pivot'] ) ?></th><th>Règle de partage</th></tr></thead><tbody>
	<?php if ( ! $sel['lignes'] ) : ?><tr><td colspan="7" class="empty">Aucune ligne.</td></tr>
	<?php else : foreach ( $sel['lignes'] as $l ) : $rg = $l['regle'] ?? 'fiche'; ?><tr>
		<td><?= e( $l['oeuvre'] ?: ( $l['titre_source'] ?: '—' ) ) ?><?php if ( ! $l['oeuvre'] && $l['isrc'] ) : ?> <span class="muted code" style="font-size:11px"><?= e( $l['isrc'] ) ?></span><?php endif; ?></td>
		<td><?= e( $l['nom_scene'] ?: $l['artiste_nom'] ?: ( $l['artiste_source'] ?: '—' ) ) ?></td>
		<td><?= e( $l['plateforme'] ?: '—' ) ?></td>
		<td class="num"><?= e( number_format( (int) $l['unites'], 0, ',', ' ' ) ) ?></td>
		<td class="num"><?= e( $mDev( $l['montant_brut'], $dev ) ) ?></td>
		<td class="num"><?= e( $mLoc( FKC_Royalty::local( $l['montant_brut'], $conv ), $conv['pivot'] ) ) ?></td>
		<td><span class="modbadge <?= $regleCls[ $rg ] ?? 'b-off' ?>"><?= e( $regles[ $rg ] ?? $rg ) ?></span>
			<?php if ( in_array( $rg, $regleVentilee, true ) && (float) ( $l['fraction'] ?? 1 ) < 0.9999 ) : ?>
				<span class="muted" style="font-size:12px">— <?= e( str_replace( '.', ',', (string) round( (float) $l['fraction'] * 100, 2 ) ) ) ?> % du titre<?= 'featuring' === ( $l['role_ligne'] ?? '' ) ? ' (featuring)' : '' ?></span>
			<?php endif; ?>
			<?php if ( in_array( $rg, array( 'fiche', 'bareme_titre', 'bareme_collab', 'bareme_incomplet', 'collab_auto' ), true ) ) : ?>
				<span class="muted" style="font-size:12px">· artiste <?= e( (string) (float) $l['part_artiste'] ) ?> % · label <?= e( (string) ( 100 - (float) $l['part_artiste'] ) ) ?> %</span>
			<?php endif; ?></td>
	</tr><?php endforeach; endif; ?>
	</tbody></table>
</div>

<?php if ( $repartition ) :
	$estDistribution = class_exists( 'FKC_Packs' ) && 'distribution_musicale' === FKC_Packs::activeCode();
	$motifs = array( 'split_incomplet' => 'split incomplet', 'non_attribue' => 'titre non rattaché', 'sans_ayant_droit' => 'œuvre sans artiste ni split' );
?>
<div class="card card-flush"><div class="card-head"><h2>Répartition par ayant droit<?= ! empty( $repartition['conversion']['ok'] ) ? '' : ' <span class="muted">(en ' . e( $dev ) . ', faute de cours)</span>' ?></h2>
	<?php if ( ! $ouvert ) : ?><span class="muted" style="margin-left:auto;font-size:12px">figée à la comptabilisation</span><?php endif; ?></div>
	<?php if ( $bloque ) : ?>
		<div class="alert alert-warn" style="margin:12px 16px">⚠️ <?= e( $mDev( array_sum( array_column( $bloque, 'montant' ) ), $dev ) ) ?> sans titulaire — la comptabilisation attend qu'ils soient attribués :
			<?php foreach ( array_slice( $bloque, 0, 8 ) as $b ) : ?>
				<div style="font-size:13px">
					<?php if ( $b['oeuvre_id'] ) : ?><a href="<?= e( url( 'royalties/catalogue/' . (int) $b['oeuvre_id'] . '/splits' ) ) ?>"><?= e( $b['titre'] ) ?></a><?php else : ?><?= e( $b['titre'] ) ?><?php endif; ?>
					— <?= e( $mDev( $b['montant'], $dev ) ) ?> · <?= e( $motifs[ $b['motif'] ] ?? $b['motif'] ) ?><?= 'split_incomplet' === $b['motif'] ? ' (' . e( str_replace( '.', ',', (string) $b['total'] ) ) . ' %)' : '' ?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<table class="table"><thead><tr><th>Ayant droit</th><th></th><th class="num">Titres</th><th class="num">Montant (<?= e( $dev ) ?>)</th><th class="num">Dû en <?= e( $conv['pivot'] ) ?></th></tr></thead><tbody>
	<?php if ( ! $repartition['par_ayant_droit'] && $repartition['label'] <= 0 ) : ?><tr><td colspan="5" class="empty">Rien à répartir pour l'instant.</td></tr><?php endif; ?>
	<?php foreach ( $repartition['par_ayant_droit'] as $r ) : ?><tr>
		<td><strong><?= e( $r['ayant_droit'] ) ?></strong></td>
		<td><?= $r['artiste_id'] ? '<span class="modbadge b-on">roster</span>' : '<span class="muted" style="font-size:11px">externe</span>' ?></td>
		<td class="num muted"><?= (int) $r['titres'] ?></td>
		<td class="num"><?= e( $mDev( $r['montant'], $dev ) ) ?></td>
		<td class="num" style="color:var(--orange)"><strong><?= e( $mLoc( $r['montant_local'], $conv['pivot'] ) ) ?></strong></td>
	</tr><?php endforeach; ?>
	<?php if ( $estDistribution && ! empty( $repartition['par_ayant_droit'] ) ) : ?>
		<tr style="border-top:2px solid var(--line)"><td><strong>Total fonds de tiers</strong> <span class="muted" style="font-size:11px">(à reverser — jamais du CA propre)</span></td><td></td><td></td>
			<td class="num"><?= e( $mDev( array_sum( array_column( $repartition['par_ayant_droit'], 'montant' ) ), $dev ) ) ?></td>
			<td class="num" style="color:var(--orange)"><strong><?= e( $mLoc( ! empty( $repartition['conversion']['ok'] ) ? array_sum( array_column( $repartition['par_ayant_droit'], 'montant_local' ) ) : null, $conv['pivot'] ) ) ?></strong></td></tr>
	<?php endif; ?>
	<?php if ( $repartition['label'] > 0 ) : ?><tr><td><strong><?= $estDistribution ? 'Commission de distribution' : 'Label' ?></strong> <span class="muted" style="font-size:11px">(<?= $estDistribution ? 'CA propre' : 'part restante' ?>)</span></td><td></td><td></td>
		<td class="num"><?= e( $mDev( $repartition['label'], $dev ) ) ?></td>
		<td class="num" style="color:var(--ok)"><strong><?= e( $mLoc( $repartition['label_local'], $conv['pivot'] ) ) ?></strong></td></tr><?php endif; ?>
	</tbody></table>
	<p class="help" style="margin:8px 16px 14px">Un titre dont le <strong>split</strong> est défini (featuring, part propre au titre) est partagé selon ce split, qui doit faire 100 % ; sinon, selon la part de la <strong>fiche artiste</strong>, relue au moment du calcul. Définissez les splits depuis le <a href="<?= e( url( 'royalties/catalogue' ) ) ?>">catalogue</a>.</p>
</div>
<?php endif; ?>
	<?php if ( $parPlateforme ) : ?>
	<div class="card card-flush"><div class="card-head"><h2>Répartition par plateforme <span class="muted">(agrégée par le distributeur)</span></h2></div>
		<table class="table"><thead><tr><th>Plateforme</th><th class="num">Unités / streams</th><th class="num">Montant (<?= e( $dev ) ?>)</th><th class="num">En <?= e( $conv['pivot'] ) ?></th></tr></thead><tbody>
		<?php foreach ( $parPlateforme as $p ) : ?><tr>
			<td><strong><?= e( $p['plateforme'] ?: '—' ) ?></strong></td>
			<td class="num"><?= e( number_format( (int) $p['streams'], 0, ',', ' ' ) ) ?></td>
			<td class="num"><?= e( $mDev( $p['brut'], $dev ) ) ?></td>
			<td class="num"><?= e( $mLoc( FKC_Royalty::local( $p['brut'], $conv ), $conv['pivot'] ) ) ?></td>
		</tr><?php endforeach; ?>
		</tbody></table>
	</div>
	<?php endif; ?>
<?php endif; ?>
