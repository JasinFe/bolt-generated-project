<?php /** @var array $campagnes @var array $plateformes @var array $artistes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'marketing' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouvelle campagne</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/marketing' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Campagne *</span><input name="campagne" required></label>
			<label class="fld"><span>Plateforme</span><select name="plateforme"><?php foreach ( $plateformes as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Artiste</span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $id => $n ) : ?><option value="<?= (int) $id ?>"><?= e( $n ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Budget</span><input type="number" step="any" name="budget" value="0"></label>
			<label class="fld"><span>Streams générés</span><input type="number" name="streams" value="0"></label>
			<label class="fld"><span>Conversions</span><input type="number" name="conversions" value="0"></label>
			<label class="fld"><span>Date</span><input type="date" name="date"></label>
			<div class="actions"><button class="btn btn-primary">Créer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Campagnes (<?= count( $campagnes ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Campagne</th><th>Plateforme</th><th>Artiste</th><th class="num">Budget</th><th class="num">Streams</th><th class="num">Conv.</th><th class="num">Coût/conv.</th><th></th></tr></thead><tbody>
		<?php if ( ! $campagnes ) : ?><tr><td colspan="8" class="empty">Aucune campagne.</td></tr>
		<?php else : foreach ( $campagnes as $c ) : $cpc = (int) $c['conversions'] > 0 ? (float) $c['budget'] / (int) $c['conversions'] : 0; ?><tr>
			<td><strong><?= e( $c['campagne'] ) ?></strong></td><td><?= e( $plateformes[ $c['plateforme'] ] ?? $c['plateforme'] ) ?></td>
			<td><?= e( $c['nom_scene'] ?: '—' ) ?></td><td class="num"><?= e( fkc_money( $c['budget'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $c['streams'], 0 ) ) ?></td><td class="num"><?= e( fkc_money( $c['conversions'], 0 ) ) ?></td>
			<td class="num"><?= $cpc ? e( fkc_money( $cpc ) ) : '—' ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/marketing/' . (int) $c['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
