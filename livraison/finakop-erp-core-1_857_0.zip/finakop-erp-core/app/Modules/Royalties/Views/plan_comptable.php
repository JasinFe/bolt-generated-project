<?php /** @var array $comptes @var int $presents @var int $total @var array $secteurs @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$classes = array( 1=>'Ressources durables',2=>'Actif immobilisé',3=>'Stocks',4=>'Tiers',5=>'Trésorerie',6=>'Charges',7=>'Produits',8=>'Autres' );
$libSecteurs = implode( ' + ', array_map( function ( $s ) { return $s[0] . ' ' . $s[1]; }, $secteurs ) ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'plan' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Plan comptable <?= e( $libSecteurs ) ?> (SYSCOHADA) · <strong><?= (int) $presents ?>/<?= (int) $total ?></strong> comptes installés</span>
	<form method="post" action="<?= e( url( 'royalties/plan-comptable/installer' ) ) ?>"><?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm"><?= $presents >= $total ? 'Réinstaller les comptes manquants' : 'Installer le plan comptable du secteur' ?></button></form>
</div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Compte</th><th>Libellé</th><th>Classe</th><th>État</th></tr></thead><tbody>
	<?php foreach ( $comptes as $c ) : $present = (bool) FKC_DB::q( 'SELECT 1 FROM comptes WHERE numero=?', array( $c[0] ) )->fetch(); ?><tr>
		<td class="code"><strong><?= e( $c[0] ) ?></strong></td><td><?= e( $c[1] ) ?></td>
		<td class="muted" style="font-size:.9em"><?= (int) $c[2] ?> · <?= e( $classes[ $c[2] ] ?? '' ) ?></td>
		<td><span class="modbadge <?= $present?'b-on':'b-off' ?>"><?= $present ? 'Présent' : 'Absent' ?></span></td>
	</tr><?php endforeach; ?>
	</tbody>
</table></div>
