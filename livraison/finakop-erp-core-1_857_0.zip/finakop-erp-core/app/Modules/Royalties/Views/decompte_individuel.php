<?php /** @var array $d @var string|null $debut @var string|null $fin @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'royalties' ) );
$periodes = $d['periodes'];
$multiPer = count( $periodes ) > 1;
$roles = class_exists( 'FKC_CreativeSplits' ) ? FKC_CreativeSplits::roles() : array();
// Suffixe de filtre pour conserver la fourchette dans le lien retour.
$q = array();
if ( $debut ) { $q['debut'] = $debut; }
if ( $fin ) { $q['fin'] = $fin; }
$suf = $q ? ( '?' . http_build_query( $q ) ) : '';
?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:4px">
	<h1 style="font-size:20px"><?= e( $d['ayant_droit'] ) ?> <?= $d['roster'] ? '<span class="modbadge b-on">roster</span>' : '<span class="muted" style="font-size:13px">(intervenant externe)</span>' ?></h1>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/decompte' . $suf ) ) ?>">← Décompte consolidé</a>
</div>
<p class="muted" style="font-size:13px;margin-bottom:16px">Relevé de droits détaillé, tous relevés distributeurs confondus<?= $periodes ? ' — ' . e( $periodes[0] ) . ( $multiPer ? ' → ' . e( $periodes[ count( $periodes ) - 1 ] ) : '' ) : '' ?>. Montants en <?= e( $d['devise'] ) ?>, convertis au cours de chaque relevé, selon le split de chaque titre ou, à défaut, la part de la fiche artiste.</p>
<?php if ( ! empty( $d['sans_cours'] ) ) : ?>
	<div class="alert alert-warn" style="margin-bottom:16px">⚠️ <?= count( $d['sans_cours'] ) ?> relevé(s) non inclus faute de cours de change :
		<?php foreach ( $d['sans_cours'] as $sc ) : ?><a href="<?= e( url( 'royalties/royalties?i=' . (int) $sc['id'] ) ) ?>"><?= e( $sc['periode'] . ' (' . $sc['devise'] . ')' ) ?></a> <?php endforeach; ?></div>
<?php endif; ?>

<?php if ( $d['nb_releves'] <= 0 ) : ?>
	<div class="card"><div class="card-body empty">Aucun revenu pour cet ayant droit sur la période sélectionnée.</div></div>
<?php else : ?>
	<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
		<div class="card"><div class="card-body" style="text-align:center"><div class="muted" style="font-size:11px">Total dû</div><strong style="font-size:20px;color:var(--orange)"><?= e( fkc_money( $d['total'] ) ) ?></strong> <span class="muted" style="font-size:12px"><?= e( $d['devise'] ) ?></span></div></div>
		<div class="card"><div class="card-body" style="text-align:center"><div class="muted" style="font-size:11px">Œuvres génératrices</div><strong style="font-size:20px"><?= count( $d['par_oeuvre'] ) ?></strong></div></div>
		<div class="card"><div class="card-body" style="text-align:center"><div class="muted" style="font-size:11px">Relevés couverts</div><strong style="font-size:20px"><?= (int) $d['nb_releves'] ?></strong></div></div>
	</div>

	<div style="display:grid;grid-template-columns:<?= $multiPer ? '1fr 300px' : '1fr' ?>;gap:16px;align-items:start">
		<div class="card card-flush">
			<div class="card-head"><h2>Par œuvre</h2></div>
			<table class="table"><thead><tr><th>Œuvre</th><th>Rôle</th><th class="num">Montant</th></tr></thead><tbody>
			<?php foreach ( $d['par_oeuvre'] as $o ) : ?><tr>
				<td><strong><?= e( $o['titre'] ) ?></strong><?php if ( $o['oeuvre_id'] ) : ?> <a class="muted" style="font-size:11px" href="<?= e( url( 'royalties/catalogue/' . (int) $o['oeuvre_id'] . '/splits' ) ) ?>">splits ↗</a><?php endif; ?></td>
				<td class="muted"><?= e( $roles[ $o['role'] ] ?? $o['role'] ) ?><?= isset( $o['part'] ) && null !== $o['part'] ? ' · ' . e( str_replace( '.', ',', (string) round( (float) $o['part'], 2 ) ) ) . ' %' : '' ?></td>
				<td class="num"><strong><?= e( fkc_money( $o['montant'] ) ) ?></strong></td>
			</tr><?php endforeach; ?>
			</tbody>
			<tfoot><tr style="border-top:2px solid var(--line)"><td colspan="2" style="text-align:right"><strong>Total</strong></td><td class="num"><strong style="color:var(--orange)"><?= e( fkc_money( $d['total'] ) ) ?></strong></td></tr></tfoot>
			</table>
		</div>

		<?php if ( $multiPer ) : ?>
		<div class="card card-flush">
			<div class="card-head"><h2>Par période</h2></div>
			<table class="table"><thead><tr><th>Période</th><th class="num">Montant</th></tr></thead><tbody>
			<?php foreach ( $d['par_periode'] as $per => $montant ) : ?><tr>
				<td><strong><?= e( $per ) ?></strong></td><td class="num"><?= e( fkc_money( $montant ) ) ?></td>
			</tr><?php endforeach; ?>
			</tbody></table>
		</div>
		<?php endif; ?>
	</div>
<?php endif; ?>
