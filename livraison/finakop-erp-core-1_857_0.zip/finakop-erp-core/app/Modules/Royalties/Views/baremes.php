<?php /** @var array $noms @var array $baremes @var array $collabs @var array $modes @var array $artistes @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'royalties' ) );
$pct = fn( $v ) => str_replace( '.', ',', (string) round( (float) $v, 2 ) );
$nonRattaches = array_values( array_filter( $noms, fn( $n ) => ! $n['artiste_id'] && ! $n['est_label'] ) );
?>
<?php if ( $flash ) : ?><div class="alert <?= false !== strpos( (string) $flash, '⚠️' ) ? 'alert-warn' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:4px">
	<h1 style="font-size:20px">Barèmes de répartition</h1>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/royalties' ) ) ?>">← Relevés</a>
</div>
<p class="muted" style="font-size:13px;margin-bottom:16px">
	Un distributeur crédite ce qui figure sur la pochette — « Artiste A feat. Artiste B ». Cet écran dit
	<strong>qui est qui</strong> et <strong>comment se partage</strong> un titre à plusieurs. Ce qui est réglé ici
	s'applique tout seul aux relevés suivants.
</p>

<?php /* L'ordre d'application, rappelé là où on le règle : sinon on croit qu'un barème l'emporte sur un split. */ ?>
<div class="card" style="margin-bottom:16px"><div class="card-body">
	<strong style="font-size:13px">Ordre d'application — le premier niveau renseigné l'emporte</strong>
	<ol style="margin:8px 0 0;padding-left:20px;font-size:13px;line-height:1.7">
		<li><strong>Split du titre</strong> <span class="muted">(catalogue → Splits)</span> — somme des parts à 100 %, label compris. Seul niveau qui nomme des ayants droit externes (beatmaker, auteur, éditeur).</li>
		<li><strong>Barème du titre</strong> <span class="muted">(par ISRC)</span> — pourcentages pour ce titre précis.</li>
		<li><strong>Barème de collaboration</strong> — vaut pour <em>tous</em> les titres du même groupe d'artistes.</li>
		<li><strong>Fiche artiste</strong> — le taux du contrat général.</li>
	</ol>
</div></div>

<?php if ( $nonRattaches ) : ?>
<div class="alert alert-warn" style="margin-bottom:16px">
	⚠️ <?= count( $nonRattaches ) ?> nom(s) vu(s) sur vos relevés ne correspondent à aucune fiche artiste.
	Tant qu'ils ne sont pas rattachés, leurs revenus restent « non attribués » et bloquent la comptabilisation.
</div>
<?php endif; ?>

<div class="card card-flush" style="margin-bottom:16px">
	<div class="card-head"><h2>Noms écrits par les distributeurs (<?= count( $noms ) ?>)</h2></div>
	<table class="table"><thead><tr><th>Nom sur le relevé</th><th class="num">Vu</th><th>Rattaché à</th><th style="width:320px">Rattacher</th></tr></thead><tbody>
	<?php if ( ! $noms ) : ?><tr><td colspan="4" class="empty">Aucun nom mémorisé — importez un relevé, les noms crédités apparaîtront ici.</td></tr>
	<?php else : foreach ( $noms as $n ) : ?><tr>
		<td><strong><?= e( $n['nom'] ) ?></strong></td>
		<td class="num muted"><?= (int) $n['nb_vues'] ?>×</td>
		<td>
			<?php if ( $n['est_label'] ) : ?><span class="modbadge b-on">🏷️ le label</span>
			<?php elseif ( $n['artiste_id'] ) : ?><span class="modbadge b-on"><?= e( $n['nom_scene'] ?: $n['artiste_nom'] ) ?></span>
			<?php else : ?><span class="modbadge b-off">non rattaché</span><?php endif; ?>
		</td>
		<td>
			<form method="post" action="<?= e( url( 'royalties/baremes/nom' ) ) ?>" style="display:flex;gap:6px">
				<?= FKC_Csrf::field() ?>
				<input type="hidden" name="nom_id" value="<?= (int) $n['id'] ?>">
				<select name="cible" style="flex:1">
					<option value="">— détacher —</option>
					<?php /* « C'est le label » évite de créer une fiche artiste fantôme quand le label est crédité en co-artiste. */ ?>
					<option value="label"<?= $n['est_label'] ? ' selected' : '' ?>>🏷️ C'est le label lui-même</option>
					<?php foreach ( $artistes as $a ) : ?>
						<option value="a:<?= (int) $a['id'] ?>"<?= (int) $n['artiste_id'] === (int) $a['id'] ? ' selected' : '' ?>><?= e( $a['nom_scene'] ?: $a['nom'] ) ?></option>
					<?php endforeach; ?>
				</select>
				<button class="btn btn-ghost btn-sm">✓</button>
			</form>
		</td>
	</tr><?php endforeach; endif; ?>
	</tbody></table>
</div>

<?php if ( $collabs ) : ?>
<div class="card card-flush" style="margin-bottom:16px">
	<div class="card-head"><h2>Collaborations sans barème (<?= count( $collabs ) ?>)</h2></div>
	<table class="table"><thead><tr><th>Crédit du relevé</th><th>Artistes détectés</th><th class="num">Lignes</th><th class="num">Montant</th><th></th></tr></thead><tbody>
	<?php foreach ( array_slice( $collabs, 0, 30 ) as $c ) : ?><tr>
		<td><strong><?= e( $c['brut'] ) ?></strong></td>
		<td class="muted"><?= e( implode( ' · ', $c['noms'] ) ) ?></td>
		<td class="num"><?= (int) $c['nb'] ?></td>
		<td class="num"><?= e( fkc_money( $c['montant'], 2 ) ) ?></td>
		<td class="right"><span class="muted" style="font-size:11px">partage équitable (<?= e( $pct( 100 / max( 1, count( $c['noms'] ) ) ) ) ?> % chacun)</span></td>
	</tr><?php endforeach; ?>
	</tbody></table>
	<div class="card-body" style="padding-top:0"><p class="help" style="margin:0">Sans barème, une collaboration est partagée <strong>à parts égales</strong> entre les artistes détectés, puis le taux de chaque fiche s'applique à sa part. Créez un barème ci-dessous si ce n'est pas votre accord.</p></div>
</div>
<?php endif; ?>

<div class="form-rows">
	<div class="card" style="grid-column:span 2"><div class="card-head"><h2>＋ Nouveau barème</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/baremes/enregistrer' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Portée</span>
				<select name="portee">
					<option value="collaboration">Collaboration — tous les titres de ce groupe d'artistes</option>
					<option value="titre">Titre — un ISRC précis</option>
				</select>
			</label>
			<label class="fld"><span>Clé *</span><input name="cle" required placeholder="Artiste A feat. Artiste B — ou isrc:CIXXX2600001"></label>
			<p class="help" style="margin-top:-4px">Pour une collaboration, recopiez le crédit <em>exactement comme le distributeur l'écrit</em> (colonne ci-dessus). Pour un titre, préfixez l'ISRC par <code>isrc:</code>.</p>
			<label class="fld"><span>Libellé</span><input name="libelle" placeholder="Nom lisible du barème"></label>
			<label class="fld"><span>Mode</span>
				<select name="mode">
					<?php foreach ( $modes as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Part du label (%) <span class="muted">(mode personnalisé)</span></span><input type="number" step="0.01" min="0" max="100" name="part_label" value="0"></label>

			<div style="margin:12px 0 4px"><strong style="font-size:13px">Parts par artiste</strong> <span class="muted" style="font-size:12px">— mode personnalisé uniquement ; avec la part du label, le total doit faire 100 %</span></div>
			<?php for ( $i = 0; $i < 4; $i++ ) : ?>
				<div style="display:flex;gap:8px;margin-bottom:6px">
					<input name="part_nom[]" placeholder="Nom tel qu'écrit par le distributeur" style="flex:2">
					<select name="part_artiste[]" style="flex:1"><option value="">— hors roster —</option><?php foreach ( $artistes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['nom_scene'] ?: $a['nom'] ) ?></option><?php endforeach; ?></select>
					<input type="number" step="0.01" min="0" max="100" name="part_pct[]" placeholder="%" style="width:90px">
				</div>
			<?php endfor; ?>
			<div class="actions"><button class="btn btn-primary">Enregistrer le barème</button></div>
		</form>
	</div></div>
</div>

<div class="card card-flush" style="margin-top:16px">
	<div class="card-head"><h2>Barèmes en vigueur (<?= count( $baremes ) ?>)</h2></div>
	<table class="table"><thead><tr><th>Portée</th><th>Clé</th><th>Mode</th><th>Parts</th><th class="num">Total</th><th></th></tr></thead><tbody>
	<?php if ( ! $baremes ) : ?><tr><td colspan="6" class="empty">Aucun barème — les collaborations sont partagées à parts égales.</td></tr>
	<?php else : foreach ( $baremes as $b ) : ?><tr>
		<td><span class="modbadge b-on"><?= 'titre' === $b['portee'] ? 'Titre' : 'Collaboration' ?></span></td>
		<td><strong><?= e( $b['libelle'] ?: $b['cle'] ) ?></strong><br><span class="muted" style="font-size:11px"><?= e( $b['cle'] ) ?></span></td>
		<td><?= e( FKC_LabelBareme::modeCourt( $b['mode'] ) ) ?></td>
		<td style="font-size:12px">
			<?php if ( 'personnalise' === $b['mode'] ) : ?>
				<?php foreach ( $b['parts'] as $p ) : ?>
					<?= e( $p['nom_scene'] ?: $p['artiste_nom'] ?: $p['nom'] ) ?> <strong><?= e( $pct( $p['part'] ) ) ?> %</strong><?= $p['artiste_id'] ? '' : ' <span class="muted">(hors roster)</span>' ?><br>
				<?php endforeach; ?>
				<span class="muted">Label <strong><?= e( $pct( $b['part_label'] ) ) ?> %</strong></span>
			<?php elseif ( 'principal' === $b['mode'] ) : ?>
				<span class="muted">Tout au premier artiste nommé ; les featurings ne reçoivent rien de ce relevé.</span>
			<?php else : ?>
				<span class="muted">Parts égales entre les artistes détectés.</span>
			<?php endif; ?>
		</td>
		<td class="num"><?php if ( 'personnalise' === $b['mode'] ) : ?><strong style="color:<?= abs( (float) $b['total'] - 100 ) < 0.01 ? 'var(--ok)' : 'var(--warn)' ?>"><?= e( $pct( $b['total'] ) ) ?> %</strong><?php else : ?><span class="muted">—</span><?php endif; ?></td>
		<td class="right"><form method="post" action="<?= e( url( 'royalties/baremes/' . (int) $b['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ce barème ? Les titres concernés repasseront au taux de la fiche artiste.')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
	</tr><?php endforeach; endif; ?>
	</tbody></table>
</div>
