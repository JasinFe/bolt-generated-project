<?php /** @var array $decompte @var array $bornes @var string|null $debut @var string|null $fin @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'royalties' ) );
$d = $decompte;
$periodes = $d['periodes'];
$multiPer = count( $periodes ) > 1;
?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:4px">
	<h1 style="font-size:20px">Décompte par ayant droit</h1>
	<span class="muted" style="font-size:13px"><?= (int) $d['nb_releves'] ?> relevé(s) · <?= $periodes ? e( $periodes[0] ) . ( $multiPer ? ' → ' . e( $periodes[ count( $periodes ) - 1 ] ) : '' ) : '—' ?></span>
</div>
<p class="muted" style="font-size:13px;margin-bottom:16px">Ce que chaque artiste et intervenant a gagné, tous relevés distributeurs confondus, converti en <?= e( $d['devise'] ) ?> au cours de chaque relevé, selon le split de chaque titre ou, à défaut, la part de la fiche artiste. C'est le décompte à remettre aux ayants droit.</p>

<form method="get" class="card" style="margin-bottom:16px"><div class="card-body" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">
	<label class="fld" style="margin:0"><span>Période de début</span><input name="debut" placeholder="<?= e( $bornes['min'] ?: '2026-01' ) ?>" value="<?= e( $debut ?? '' ) ?>" style="width:130px"></label>
	<label class="fld" style="margin:0"><span>Période de fin</span><input name="fin" placeholder="<?= e( $bornes['max'] ?: '2026-12' ) ?>" value="<?= e( $fin ?? '' ) ?>" style="width:130px"></label>
	<button class="btn btn-primary btn-sm" type="submit">Filtrer</button>
	<?php if ( $debut || $fin ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/decompte' ) ) ?>">Tout</a><?php endif; ?>
	<span class="muted" style="font-size:11px;margin-left:auto">Format AAAA-MM (ex. 2026-03)</span>
</div></form>

<?php if ( ! $d['ayants'] && $d['label'] <= 0 && $d['bloque_total'] <= 0 ) : ?>
	<div class="card"><div class="card-body empty">Aucun revenu sur cette période. Importez des relevés distributeurs et définissez les splits des œuvres.</div></div>
<?php else : ?>
	<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
		<div class="card"><div class="card-body" style="text-align:center"><div class="muted" style="font-size:11px">Total ayants droit</div><strong style="font-size:18px;color:var(--orange)"><?= e( fkc_money( $d['total'] ) ) ?></strong></div></div>
		<div class="card"><div class="card-body" style="text-align:center"><div class="muted" style="font-size:11px">Part label</div><strong style="font-size:18px;color:var(--ok)"><?= e( fkc_money( $d['label'] ) ) ?></strong></div></div>
		<div class="card"><div class="card-body" style="text-align:center"><div class="muted" style="font-size:11px">Sans titulaire (à attribuer)</div><strong style="font-size:18px;color:<?= $d['bloque_total'] > 0 ? 'var(--warn)' : 'var(--muted)' ?>"><?= e( fkc_money( $d['bloque_total'] ) ) ?></strong></div></div>
	</div>

	<?php if ( $d['bloque_total'] > 0 ) : ?>
		<div class="alert alert-warn" style="margin-bottom:16px">⚠️ <?= e( fkc_money( $d['bloque_total'] ) ) ?> <?= e( $d['devise'] ) ?> de revenus n'ont pas de titulaire : split incomplet, titre non rattaché ou œuvre sans artiste. Corrigez-les depuis les <a href="<?= e( url( 'royalties/royalties' ) ) ?>">relevés</a> ou le <a href="<?= e( url( 'royalties/catalogue' ) ) ?>">catalogue</a>.</div>
	<?php endif; ?>
	<?php if ( ! empty( $d['sans_cours'] ) ) : ?>
		<div class="alert alert-warn" style="margin-bottom:16px">⚠️ <?= count( $d['sans_cours'] ) ?> relevé(s) écarté(s) faute de cours de change :
			<?php foreach ( $d['sans_cours'] as $sc ) : ?><a href="<?= e( url( 'royalties/royalties?i=' . (int) $sc['id'] ) ) ?>"><?= e( $sc['periode'] . ' (' . $sc['devise'] . ')' ) ?></a> <?php endforeach; ?>
			— un décompte ne peut pas additionner des devises différentes.</div>
	<?php endif; ?>

	<div class="card card-flush">
		<div class="card-head"><h2>Répartition consolidée <span class="muted">(<?= e( $d['devise'] ) ?>)</span></h2></div>
		<table class="table"><thead><tr>
			<th>Ayant droit</th><th></th>
			<?php if ( $multiPer ) : foreach ( $periodes as $p ) : ?><th class="num"><?= e( $p ) ?></th><?php endforeach; endif; ?>
			<th class="num">Total dû</th>
		</tr></thead><tbody>
		<?php
		$flt = array();
		if ( $debut ) { $flt['debut'] = $debut; }
		if ( $fin ) { $flt['fin'] = $fin; }
		?>
		<?php foreach ( $d['ayants'] as $a ) : ?><tr>
			<?php $ref = $a['artiste_id'] ? 'a:' . (int) $a['artiste_id'] : 'x:' . mb_strtolower( $a['ayant_droit'] ); $lien = url( 'royalties/decompte/ayant-droit?' . http_build_query( array_merge( array( 'ref' => $ref ), $flt ) ) ); ?>
			<td><a href="<?= e( $lien ) ?>"><strong><?= e( $a['ayant_droit'] ) ?></strong></a></td>
			<td><?= $a['artiste_id'] ? '<span class="modbadge b-on">roster</span>' : '<span class="muted" style="font-size:11px">externe</span>' ?></td>
			<?php if ( $multiPer ) : foreach ( $periodes as $p ) : ?><td class="num muted"><?= isset( $a['par_periode'][ $p ] ) ? e( fkc_money( $a['par_periode'][ $p ] ) ) : '—' ?></td><?php endforeach; endif; ?>
			<td class="num"><strong style="color:var(--orange)"><?= e( fkc_money( $a['total'] ) ) ?></strong></td>
		</tr><?php endforeach; ?>
		<?php if ( $d['label'] > 0 ) : ?><tr>
			<td><strong>Label</strong> <span class="muted" style="font-size:11px">(part restante)</span></td><td></td>
			<?php if ( $multiPer ) : foreach ( $periodes as $p ) : ?><td class="num muted">—</td><?php endforeach; endif; ?>
			<td class="num"><strong style="color:var(--ok)"><?= e( fkc_money( $d['label'] ) ) ?></strong></td>
		</tr><?php endif; ?>
		</tbody></table>
	</div>
<?php endif; ?>
