<?php
/**
 * ATTRIBUTIONS À VÉRIFIER — la relecture des relevés déjà comptabilisés.
 *
 * L'écran ne corrige rien et ne peut rien corriger : les sommes sont parties.
 * Il nomme, il chiffre, et il laisse décider — comme la checklist de clôture.
 * Chaque ligne porte sa PHRASE d'explication, parce qu'un tableau de lignes
 * suspectes sans explication oblige le lecteur à refaire le raisonnement pour
 * chacune. Il ne le fait pas, et l'état finit classé sans suite.
 *
 * @var array $audit @var bool $tous @var mixed $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

$dev = $audit['devise'] ?: '';
?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'royalties' ) ); ?>

<style>
.rv-l{border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:12px 14px;margin-bottom:10px;background:rgba(255,255,255,.02)}
.rv-l.perdue{border-color:rgba(255,107,107,.32)}
.rv-l.divergente{border-color:rgba(255,176,32,.32)}
.rv-l.incertaine{border-color:rgba(106,169,255,.32)}
.rv-h{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}
.rv-t{font-size:14.5px;font-weight:700;flex:1;min-width:180px}
.rv-m{font-variant-numeric:tabular-nums;font-weight:700;white-space:nowrap}
.rv-x{font-size:12.5px;color:#9aa3b5;line-height:1.55;margin:6px 0 0}
.rv-k{font-size:12px;color:#c3cadb;margin-top:5px}
.rv-a{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:9px}
.rv-a input[type=text]{flex:1;min-width:170px}
@media(max-width:700px){.rv-t{min-width:100%}}
</style>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert"><?= e( (string) $flash ) ?></div>
<?php endif; ?>

<div class="card"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
	<h2 style="margin:0">Attributions à vérifier</h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/revision' . ( $tous ? '' : '?tous=1' ) ) ) ?>">
		<?= $tous ? 'Relevés comptabilisés seuls' : 'Inclure les relevés non comptabilisés' ?>
	</a>
</div><div class="card-body">
	<p class="rv-x" style="margin:0 0 10px">
		Jusqu'à la version 1.787.0, une ligne de relevé pouvait être attribuée sur la seule
		<strong>ressemblance</strong> de son titre avec une œuvre du catalogue — sans que l'ISRC le confirme,
		sans que le nom crédité soit reconnu. La règle est corrigée, mais elle ne répare que l'avenir : les
		relevés déjà comptabilisés ont versé ce qu'ils ont versé, et rien dans les comptes ne signale une part
		partie au mauvais ayant droit.
	</p>
	<p class="rv-x" style="margin:0 0 10px">
		Cet écran relit chaque ligne attribuée et repose la question d'aujourd'hui : <strong>le logiciel
		l'attribuerait-il encore&nbsp;?</strong> Il ne corrige rien — aucune écriture, aucun paiement n'est touché.
	</p>

	<?php if ( '' !== (string) ( $audit['panne'] ?? '' ) ) : ?>
		<p style="margin:0;color:#ff6b6b"><strong>État non calculable.</strong>
			<?= e( (string) $audit['panne'] ) ?></p>
	<?php elseif ( 0 === (int) $audit['nb'] ) : ?>
		<p style="margin:0;color:#3ddc84"><strong>Rien à signaler.</strong>
			<?= (int) $audit['examinees'] ?> ligne(s) relue(s) : toutes seraient attribuées de la même façon
			aujourd'hui.</p>
	<?php else : ?>
		<p style="margin:0">
			<strong style="color:#ff6b6b"><?= (int) $audit['nb'] ?> ligne(s)</strong> sur
			<?= (int) $audit['examinees'] ?> relue(s), réparties sur <?= (int) $audit['nb_releves'] ?> relevé(s),
			pour <strong><?= fkc_money( $audit['montant'] ) ?> <?= e( $dev ) ?></strong> versés
			(<?= fkc_money( $audit['montant_artiste'] ) ?> aux artistes,
			<?= fkc_money( $audit['montant_label'] ) ?> au label).
		</p>
		<?php if ( (int) $audit['nb_divergentes'] ) : ?>
			<p style="margin:6px 0 0;color:#ffb020"><?= (int) $audit['nb_divergentes'] ?> d'entre elles pointeraient
				aujourd'hui vers une <strong>autre</strong> œuvre : le catalogue a changé depuis.</p>
		<?php endif; ?>
		<?php if ( (int) $audit['incertaines'] ) : ?>
			<p style="margin:6px 0 0;color:#6aa9ff"><?= (int) $audit['incertaines'] ?> pourraient être des
				<strong>décisions prises à la main</strong> avant cette version, qui ne laissaient pas de trace.
				Elles sont marquées.</p>
		<?php endif; ?>
	<?php endif; ?>
</div></div>

<?php if ( $audit['lignes'] ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h3 style="margin:0">Deux gestes, et rien d'autre</h3></div>
<div class="card-body">
	<p class="rv-x" style="margin:0">
		<strong>Confirmer</strong> enregistre l'ISRC du relevé sur l'œuvre : le rattachement cesse d'être un pari,
		la ligne et les relevés suivants passent par le code. Aucun montant n'est modifié.<br>
		<strong>Écarter</strong> dit que le versement a été vérifié et qu'il était le bon. Sans ce geste, l'état
		redirait la même chose chaque mois et finirait par n'être plus lu.<br>
		Si le versement était <em>faux</em>, la régularisation se fait au décompte de l'artiste concerné : elle
		relève d'une décision du label, pas d'un bouton.
	</p>
</div></div>
<?php endif; ?>

<?php foreach ( $audit['lignes'] as $l ) :
	$cls = $l['incertaine'] ? 'incertaine' : ( 'divergente' === $l['cas'] ? 'divergente' : 'perdue' ); ?>
	<div class="rv-l <?= $cls ?>">
		<div class="rv-h">
			<span class="rv-t"><?= e( $l['titre'] ?: '(titre non fourni)' ) ?></span>
			<span class="rv-m"><?= fkc_money( $l['montant_artiste'] + $l['montant_label'] ) ?> <?= e( $l['devise'] ) ?></span>
		</div>
		<div class="rv-k">
			Relevé <?= e( $l['source'] ) ?> <?= e( $l['periode'] ) ?>
			<?= '' !== $l['plateforme'] ? ' · ' . e( $l['plateforme'] ) : '' ?>
			<?= '' !== $l['isrc'] ? ' · ISRC ' . e( $l['isrc'] ) : ' · sans ISRC' ?>
			<?= '' !== $l['credit'] ? ' · crédité « ' . e( $l['credit'] ) . ' »' : '' ?>
		</div>
		<div class="rv-k">
			Versé à <strong><?= e( $l['beneficiaire'] ?: 'le label' ) ?></strong>
			<?= '' !== $l['oeuvre'] ? ' pour l\'œuvre « ' . e( $l['oeuvre'] ) . ' »' : '' ?>
			— <?= fkc_money( $l['montant_artiste'] ) ?> à l'artiste, <?= fkc_money( $l['montant_label'] ) ?> au label.
			<?php if ( 'divergente' === $l['cas'] ) : ?>
				<br>Aujourd'hui : <?= e( $l['devient_oeuvre'] ?: '—' ) ?>
					<?= '' !== $l['devient_artiste'] ? ' / ' . e( $l['devient_artiste'] ) : '' ?>
			<?php endif; ?>
		</div>
		<p class="rv-x"><?= e( $l['explication'] ) ?></p>

		<div class="rv-a">
			<?php if ( '' !== $l['isrc'] && $l['oeuvre_id'] ) : ?>
				<form method="post" action="<?= e( url( 'royalties/revision/' . (int) $l['id'] . '/confirmer' ) ) ?>" style="margin:0">
					<?php if ( $tous ) : ?><input type="hidden" name="tous" value="1"><?php endif; ?>
					<button class="btn btn-sm">Confirmer ce rattachement</button>
				</form>
			<?php endif; ?>
			<form method="post" action="<?= e( url( 'royalties/revision/' . (int) $l['id'] . '/ecarter' ) ) ?>" class="rv-a" style="margin:0;flex:1">
				<?php if ( $tous ) : ?><input type="hidden" name="tous" value="1"><?php endif; ?>
				<input type="text" name="motif" placeholder="Pourquoi ce versement était le bon (5 caractères au moins)">
				<button class="btn btn-ghost btn-sm">Écarter</button>
			</form>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/royalties?i=' . (int) $l['import_id'] ) ) ?>">Ouvrir le relevé</a>
		</div>
	</div>
<?php endforeach; ?>
