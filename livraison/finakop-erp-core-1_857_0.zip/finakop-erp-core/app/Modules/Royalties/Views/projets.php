<?php /** @var array $projets @var array $statuts @var array $artistes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'projets' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouveau projet</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/projets' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Titre *</span><input name="titre" required></label>
			<label class="fld"><span>Artiste</span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $id => $nom ) : ?><option value="<?= (int) $id ?>"><?= e( $nom ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Budget production</span><input type="number" step="any" name="budget_production" value="0"></label>
			<label class="fld"><span>Budget marketing</span><input type="number" step="any" name="budget_marketing" value="0"></label>
			<label class="fld"><span>Budget distribution</span><input type="number" step="any" name="budget_distribution" value="0"></label>
			<label class="fld"><span>Autre budget</span><input type="number" step="any" name="budget_autre" value="0"></label>
			<label class="fld"><span>Coût réel engagé</span><input type="number" step="any" name="cout" value="0"></label>
			<label class="fld"><span>Revenus réalisés</span><input type="number" step="any" name="revenus" value="0"></label>
			<div class="actions"><button class="btn btn-primary">Créer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Projets (<?= count( $projets ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Projet</th><th>Artiste</th><th class="num">Budget</th><th class="num">Coût</th><th class="num">Revenus</th><th class="num">Profit</th><th></th></tr></thead><tbody>
		<?php if ( ! $projets ) : ?><tr><td colspan="7" class="empty">Aucun projet.</td></tr>
		<?php else : foreach ( $projets as $p ) : $profit = FKC_Projet::profit( $p ); ?><tr>
			<td><strong><?= e( $p['titre'] ) ?></strong></td><td><?= e( $p['nom_scene'] ?: $p['artiste_nom'] ?: '—' ) ?></td>
			<td class="num"><?= e( fkc_money( $p['budget_total'] ) ) ?></td><td class="num"><?= e( fkc_money( $p['cout'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $p['revenus'] ) ) ?></td>
			<td class="num" style="color:<?= $profit>=0?'var(--ok)':'var(--danger)' ?>"><?= e( fkc_money( $profit ) ) ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/projets/' . (int) $p['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
