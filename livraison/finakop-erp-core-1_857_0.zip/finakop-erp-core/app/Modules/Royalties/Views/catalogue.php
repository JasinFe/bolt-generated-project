<?php /** @var array $oeuvres @var array $types @var array $artistes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'catalogue' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2><?= e( FKC_Term::t('oeuvre_new','Ajouter une production') ) ?></h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/catalogue' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Titre *</span><input name="titre" required></label>
			<label class="fld"><span>ISRC <span class="muted">(clé de rattachement des royalties)</span></span><input name="isrc" placeholder="CI-XXX-YY-NNNNN"></label>
			<label class="fld"><span>Code interne</span><input name="code" placeholder="réf. label"></label>
			<label class="fld"><span>UPC (album)</span><input name="upc"></label>
			<label class="fld"><span>Durée</span><input name="duree" placeholder="3:45"></label>
			<label class="fld"><span>Date de sortie</span><input type="date" name="date_sortie"></label>
			<label class="fld"><span>Artiste</span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $id => $nom ) : ?><option value="<?= (int) $id ?>"><?= e( $nom ) ?></option><?php endforeach; ?></select></label>
			<div class="actions"><button class="btn btn-primary">Ajouter</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2><?= e( FKC_Term::t('oeuvres','Productions') ) ?> (<?= count( $oeuvres ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Type</th><th>Titre</th><th>Code</th><th>Artiste</th><th>Sortie</th><th></th></tr></thead><tbody>
		<?php if ( ! $oeuvres ) : ?><tr><td colspan="6" class="empty">Catalogue vide.</td></tr>
		<?php else : foreach ( $oeuvres as $o ) : ?><tr>
			<td><span class="modbadge b-on"><?= e( $types[ $o['type'] ] ?? $o['type'] ) ?></span></td>
			<td><strong><?= e( $o['titre'] ) ?></strong></td><td class="code"><?= e( $o['code'] ?: $o['upc'] ?: '—' ) ?></td>
			<td><?= e( $o['nom_scene'] ?: $o['artiste_nom'] ?: '—' ) ?></td><td><?= e( $o['date_sortie'] ?: '—' ) ?></td>
			<td class="right"><?php if ( ! empty( $splitsDispo ) ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/catalogue/' . (int) $o['id'] . '/splits' ) ) ?>">Splits</a> <?php endif; ?><form method="post" action="<?= e( url( 'royalties/catalogue/' . (int) $o['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
