<?php /** @var array $oeuvre @var array $splits @var array $etat @var array $roles @var array $artistes @var array|null $artistePrincipal @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'catalogue' ) );
?>
<?php if ( $flash ) : ?><div class="alert <?= false !== strpos( (string) $flash, '⚠️' ) ? 'alert-warn' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>
<?php $artistePrincipal = $artistePrincipal ?? null; $base = url( 'royalties/catalogue/' . (int) $oeuvre['id'] . '/splits' ); ?>

<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:12px">
	<h1 style="font-size:20px">Splits · <?= e( $oeuvre['titre'] ) ?> <span class="muted" style="font-size:14px"><?= $oeuvre['isrc'] ? 'ISRC ' . e( $oeuvre['isrc'] ) : ( $oeuvre['upc'] ? 'UPC ' . e( $oeuvre['upc'] ) : '' ) ?></span></h1>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/catalogue' ) ) ?>">← Catalogue</a>
</div>

<?php $c = $etat['complet']; ?>
<p class="muted" style="font-size:13px;margin:0 0 12px">
	<?php if ( $artistePrincipal ) : ?>
		Sans split, ce titre est partagé selon la fiche de <strong><?= e( $artistePrincipal['nom_scene'] ?: $artistePrincipal['nom'] ) ?></strong> :
		artiste <?= e( (string) (float) $artistePrincipal['part_artiste'] ) ?> %, label <?= e( (string) ( 100 - (float) $artistePrincipal['part_artiste'] ) ) ?> %.
		Définissez un split quand ce titre fait exception (featuring, part négociée pour ce titre).
	<?php else : ?>
		Ce titre n'a pas d'artiste principal : sans split, ses revenus n'ont pas de titulaire et bloquent la comptabilisation du relevé.
	<?php endif; ?>
</p>
<?php if ( ! $splits && $artistePrincipal ) : ?>
<form method="post" action="<?= e( $base . '/amorcer' ) ?>" style="margin-bottom:12px"><?= FKC_Csrf::field() ?>
	<button class="btn btn-primary btn-sm" type="submit">Partir de la fiche artiste (<?= e( (string) (float) $artistePrincipal['part_artiste'] ) ?> % / <?= e( (string) ( 100 - (float) $artistePrincipal['part_artiste'] ) ) ?> %)</button>
	<span class="muted" style="font-size:12px">puis ajoutez le featuring et ajustez les parts.</span>
</form>
<?php endif; ?>
<div class="alert <?= $c || ! $splits ? 'alert-ok' : 'alert-warn' ?>" style="margin-bottom:16px">
	<?php if ( $c ) : ?>
		✓ Répartition complète — la somme des parts fait 100 %. Les revenus de cette œuvre peuvent être répartis automatiquement.
	<?php elseif ( $splits ) : ?>
		⚠️ Répartition incomplète : <strong><?= e( str_replace( '.', ',', (string) $etat['total'] ) ) ?> %</strong> affectés, il <?= $etat['ecart'] > 0 ? 'manque' : 'dépasse de' ?> <strong><?= e( str_replace( '.', ',', (string) abs( $etat['ecart'] ) ) ) ?> %</strong>. Tant que le split ne fait pas 100 %, les revenus de cette œuvre bloquent la comptabilisation.
		<form method="post" action="<?= e( $base . '/equilibrer' ) ?>" style="display:inline;margin-left:8px"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit"><?= $etat['ecart'] > 0 ? 'Attribuer les ' . e( str_replace( '.', ',', (string) $etat['ecart'] ) ) . ' % restants au label' : 'Réduire la part du label de ' . e( str_replace( '.', ',', (string) abs( $etat['ecart'] ) ) ) . ' %' ?></button></form>
	<?php else : ?>
		Aucun split : la fiche artiste s'applique.
	<?php endif; ?>
</div>

<div class="form-rows" style="gap:16px">
	<div class="card card-flush">
		<div class="card-head"><h2>Ayants droit</h2></div>
		<table class="table"><thead><tr><th>Ayant droit</th><th>Rôle</th><th class="num">Part</th><th></th></tr></thead><tbody>
		<?php if ( ! $splits ) : ?><tr><td colspan="4" class="empty">Aucun ayant droit. Ajoutez-les ci-contre — la somme doit faire 100 %.</td></tr>
		<?php else : foreach ( $splits as $s ) : ?>
			<tr><td><strong><?= e( $s['ayant_droit'] ) ?></strong><?= $s['artiste_id'] ? ' <span class="muted" style="font-size:11px">(roster)</span>' : ' <span class="muted" style="font-size:11px">(externe)</span>' ?></td>
			<td class="muted"><?= e( $roles[ $s['role'] ] ?? $s['role'] ) ?></td>
			<td class="num"><form method="post" action="<?= e( $base . '/' . (int) $s['id'] . '/part' ) ?>" style="display:inline-flex;gap:4px;align-items:center;justify-content:flex-end"><?= FKC_Csrf::field() ?>
				<input name="part" inputmode="decimal" value="<?= e( str_replace( '.', ',', (string) (float) $s['part'] ) ) ?>" style="width:70px;text-align:right" aria-label="Part en %"> %
				<button class="btn btn-ghost btn-sm" type="submit" title="Enregistrer la part">✓</button></form></td>
			<td><form method="post" action="<?= e( url( 'royalties/catalogue/' . (int) $oeuvre['id'] . '/splits/' . (int) $s['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Retirer cet ayant droit ?');"><?= FKC_Csrf::field() ?><button class="btn btn-sm">✕</button></form></td></tr>
		<?php endforeach; endif; ?>
		</tbody>
		<?php if ( $splits ) : ?><tfoot><tr style="border-top:2px solid var(--line)"><td colspan="2" style="text-align:right"><strong>Total</strong></td><td class="num"><strong style="color:<?= $c ? 'var(--ok)' : 'var(--warn)' ?>"><?= e( str_replace( '.', ',', (string) $etat['total'] ) ) ?> %</strong></td><td></td></tr></tfoot><?php endif; ?>
		</table>
	</div>
	<div class="card">
		<div class="card-head"><h2>＋ Ajouter un ayant droit</h2></div>
		<div class="card-body"><form method="post" action="<?= e( url( 'royalties/catalogue/' . (int) $oeuvre['id'] . '/splits' ) ) ?>"><?= FKC_Csrf::field() ?>
			<label class="fld"><span>Depuis le roster</span><select name="artiste_id" onchange="if(this.value){this.form.ayant_droit.placeholder=this.options[this.selectedIndex].text}"><option value="">— externe (saisir le nom) —</option><?php foreach ( $artistes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['nom_scene'] ?: $a['nom'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Nom (si externe)</span><input name="ayant_droit" placeholder="Nom de l'ayant droit"></label>
			<label class="fld"><span>Rôle</span><select name="role"><?php foreach ( $roles as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Part (%)</span><input type="number" step="0.01" name="part" placeholder="ex. 50" required></label>
			<button class="btn btn-primary" type="submit">Ajouter</button>
			<p class="help" style="margin-top:8px">Laissez le nom vide si vous choisissez un artiste du roster. La somme de toutes les parts doit atteindre 100 %.</p>
		</form></div>
	</div>
</div>
