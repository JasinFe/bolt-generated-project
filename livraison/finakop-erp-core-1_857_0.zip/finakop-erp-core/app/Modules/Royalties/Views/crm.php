<?php /** @var array $contacts @var array $types @var array $categories @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'crm' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouveau contact</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/crm' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Nom *</span><input name="nom" required></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Catégorie</span><select name="categorie"><option value="">—</option><?php foreach ( $categories as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Contact</span><input name="contact" placeholder="Tél / email"></label>
			<label class="fld"><span>Note</span><textarea name="note" rows="2"></textarea></label>
			<div class="actions"><button class="btn btn-primary">Ajouter</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Contacts (<?= count( $contacts ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Nom</th><th>Type</th><th>Catégorie</th><th>Contact</th><th></th></tr></thead><tbody>
		<?php if ( ! $contacts ) : ?><tr><td colspan="5" class="empty">Aucun contact (organisateurs, sponsors, médias).</td></tr>
		<?php else : foreach ( $contacts as $c ) : ?><tr>
			<td><strong><?= e( $c['nom'] ) ?></strong></td><td><span class="modbadge b-on"><?= e( $types[ $c['type'] ] ?? $c['type'] ) ?></span></td>
			<td><?= e( $categories[ $c['categorie'] ] ?? ( $c['categorie'] ?: '—' ) ) ?></td><td><?= e( $c['contact'] ?: '—' ) ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/crm/' . (int) $c['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
