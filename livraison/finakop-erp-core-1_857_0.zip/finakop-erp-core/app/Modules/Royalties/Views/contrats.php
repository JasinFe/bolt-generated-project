<?php /** @var array $contrats @var array $artistes @var array $types @var array $statuts @var int $conso @var int $limit @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'contrats' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouveau contrat</h2></div><div class="card-body">
		<?php if ( (int) $limit >= 0 ) : ?><p class="help">Quota du palier : <strong><?= (int) $conso ?> / <?= (int) $limit ?></strong> contrat(s).</p><?php endif; ?>
		<form method="post" action="<?= e( url( 'royalties/contrats' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Référence</span><input name="reference" placeholder="CTR-2026-001"></label>
			<label class="fld"><span>Artiste</span><select name="artiste_id"><option value="">—</option><?php foreach ( $artistes as $id => $nom ) : ?><option value="<?= (int) $id ?>"><?= e( $nom ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $lab ) : ?><option value="<?= e( $k ) ?>"><?= e( $lab ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Début</span><input type="date" name="date_debut"></label>
			<label class="fld"><span>Fin</span><input type="date" name="date_fin"></label>
			<label class="fld"><span>Taux artiste (%)</span><input type="number" step="any" name="taux_artiste" value="0"></label>
			<label class="fld"><span>Statut</span><select name="statut"><?php foreach ( $statuts as $k => $lab ) : ?><option value="<?= e( $k ) ?>"><?= e( $lab ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Note</span><input name="note"></label>
			<div class="actions"><button class="btn btn-primary">Enregistrer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Contrats (<?= count( $contrats ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Référence</th><th>Artiste</th><th>Type</th><th>Période</th><th class="num">Taux</th><th>Statut</th><th></th></tr></thead><tbody>
		<?php if ( ! $contrats ) : ?><tr><td colspan="7" class="empty">Aucun contrat.</td></tr>
		<?php else : foreach ( $contrats as $c ) : ?><tr>
			<td><strong><?= e( $c['reference'] ?: '—' ) ?></strong></td>
			<td><?= e( $c['nom_scene'] ?: $c['artiste_nom'] ?: '—' ) ?></td>
			<td><?= e( $types[ $c['type'] ] ?? $c['type'] ) ?></td>
			<td><?= e( ( $c['date_debut'] ?: '?' ) . ' → ' . ( $c['date_fin'] ?: '…' ) ) ?></td>
			<td class="num"><?= e( rtrim( rtrim( number_format( (float) $c['taux_artiste'], 2, ',', ' ' ), '0' ), ',' ) ) ?> %</td>
			<td><?= e( $statuts[ $c['statut'] ] ?? $c['statut'] ) ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/contrats/' . (int) $c['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
