<?php /** @var array $droits @var array $organismes @var array $oeuvres @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'publishing' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouveau droit d'édition</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/publishing' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Œuvre</span><select name="oeuvre_id"><option value="">—</option><?php foreach ( $oeuvres as $id => $t ) : ?><option value="<?= (int) $id ?>"><?= e( $t ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Auteur</span><input name="auteur"></label>
			<label class="fld"><span>Compositeur</span><input name="compositeur"></label>
			<label class="fld"><span>Co-auteur</span><input name="coauteur"></label>
			<label class="fld"><span>Part (%)</span><input type="number" step="0.1" name="part" value="0"></label>
			<label class="fld"><span>Organisme</span><select name="organisme"><?php foreach ( $organismes as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<div class="actions"><button class="btn btn-primary">Enregistrer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Droits (<?= count( $droits ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Œuvre</th><th>Auteur</th><th>Compositeur</th><th>Co-auteur</th><th class="num">Part</th><th>Organisme</th><th></th></tr></thead><tbody>
		<?php if ( ! $droits ) : ?><tr><td colspan="7" class="empty">Aucun droit enregistré.</td></tr>
		<?php else : foreach ( $droits as $d ) : ?><tr>
			<td><strong><?= e( $d['oeuvre'] ?: '—' ) ?></strong></td><td><?= e( $d['auteur'] ?: '—' ) ?></td><td><?= e( $d['compositeur'] ?: '—' ) ?></td>
			<td><?= e( $d['coauteur'] ?: '—' ) ?></td><td class="num"><?= e( fkc_money( $d['part'], 0 ) ) ?>%</td>
			<td><span class="modbadge b-on"><?= e( $organismes[ $d['organisme'] ] ?? $d['organisme'] ) ?></span></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/publishing/' . (int) $d['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
