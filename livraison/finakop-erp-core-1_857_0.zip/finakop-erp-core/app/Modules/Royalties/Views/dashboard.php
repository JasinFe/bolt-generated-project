<?php /** @var array $d @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'dashboard' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Revenus du mois</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $d['revenus_mois'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted"><?= e( FKC_Term::t('paiements','Reversements') ) ?> à payer</span><div style="font-size:1.5em;font-weight:700;color:<?= $d['royalties_payer']>0?'var(--orange)':'var(--ok)' ?>"><?= e( fkc_money( $d['royalties_payer'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted"><?= e( FKC_Term::t('audience','Audience cumulée') ) ?></span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $d['streams'], 0 ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Ventes (merch)</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $d['ventes'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted"><?= e( FKC_Term::t('evenement','Événement') ) ?>s à venir</span><div style="font-size:1.5em;font-weight:700"><?= (int) $d['concerts'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted"><?= e( FKC_Term::t('talents','Talents') ) ?> actifs</span><div style="font-size:1.5em;font-weight:700"><?= (int) $d['artistes'] ?></div></div></div>
</div>
<div class="form-grid">
	<div class="card"><div class="card-body"><span class="muted">🏆 Top <?= e( fkc_lc( FKC_Term::t('talent','talent') ) ) ?></span><div style="font-size:1.2em;font-weight:700"><?= $d['top_artiste'] ? e( $d['top_artiste']['nom_scene'] ?: $d['top_artiste']['nom'] ) : '—' ?></div><?php if ( $d['top_artiste'] ) : ?><span class="help"><?= e( fkc_money( $d['top_artiste']['brut'] ) ) ?> · <?= e( fkc_money( $d['top_artiste']['streams'], 0 ) ) ?> streams</span><?php endif; ?></div></div>
	<div class="card"><div class="card-body"><span class="muted">💿 Top <?= e( fkc_lc( FKC_Term::t('type_collection','album') ) ) ?></span><div style="font-size:1.2em;font-weight:700"><?= $d['top_album'] ? e( $d['top_album']['titre'] ) : '—' ?></div><?php if ( $d['top_album'] ) : ?><span class="help"><?= e( $d['top_album']['nom_scene'] ?: '' ) ?> · <?= e( fkc_money( $d['top_album']['streams'], 0 ) ) ?> streams</span><?php endif; ?></div></div>
	<div class="card"><div class="card-body"><span class="muted">🎵 Top <?= e( fkc_lc( FKC_Term::t('type_unit','single') ) ) ?></span><div style="font-size:1.2em;font-weight:700"><?= $d['top_single'] ? e( $d['top_single']['titre'] ) : '—' ?></div><?php if ( $d['top_single'] ) : ?><span class="help"><?= e( $d['top_single']['nom_scene'] ?: '' ) ?> · <?= e( fkc_money( $d['top_single']['streams'], 0 ) ) ?> streams</span><?php endif; ?></div></div>
</div>
