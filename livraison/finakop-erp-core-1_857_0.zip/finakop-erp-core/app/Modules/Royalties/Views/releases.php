<?php /** @var array $releases @var array $statuts @var array $oeuvres @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'releases' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Programmer une release</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/releases' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Œuvre</span><select name="oeuvre_id"><option value="">—</option><?php foreach ( $oeuvres as $id => $t ) : ?><option value="<?= (int) $id ?>"><?= e( $t ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Date de sortie</span><input type="date" name="date_sortie"></label>
			<label class="fld"><span>Statut</span><select name="statut"><?php foreach ( $statuts as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Plateformes</span><input name="plateformes" placeholder="Spotify, Apple, Deezer, Boomplay, TikTok…"></label>
			<div class="actions"><button class="btn btn-primary">Programmer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Distribution digitale (<?= count( $releases ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Œuvre</th><th>Artiste</th><th>Sortie</th><th>Plateformes</th><th>Statut</th><th>Validation</th><th></th></tr></thead><tbody>
		<?php if ( ! $releases ) : ?><tr><td colspan="7" class="empty">Aucune release.</td></tr>
		<?php else : foreach ( $releases as $r ) : ?><tr>
			<td><strong><?= e( $r['oeuvre'] ?: '—' ) ?></strong></td><td><?= e( $r['nom_scene'] ?: '—' ) ?></td><td><?= e( $r['date_sortie'] ?: '—' ) ?></td>
			<td class="muted" style="font-size:.9em"><?= e( $r['plateformes'] ?: '—' ) ?></td>
			<td><span class="modbadge <?= $r['statut']==='publie'?'b-on':'b-off' ?>"><?= e( $statuts[ $r['statut'] ] ?? $r['statut'] ) ?></span></td>
			<td><form method="post" action="<?= e( url( 'royalties/releases/' . (int) $r['id'] . '/statut' ) ) ?>" style="display:flex;gap:4px"><?= FKC_Csrf::field() ?><select name="statut" onchange="this.form.submit()"><?php foreach ( $statuts as $k => $l ) : ?><option value="<?= e( $k ) ?>" <?= $r['statut']===$k?'selected':'' ?>><?= e( $l ) ?></option><?php endforeach; ?></select></form></td>
			<td class="right"><form method="post" action="<?= e( url( 'royalties/releases/' . (int) $r['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
