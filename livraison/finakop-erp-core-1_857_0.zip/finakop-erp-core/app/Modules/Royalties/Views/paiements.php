<?php /** @var array $paiements @var array $statuts @var array $types @var array $artistes @var float $a_payer @var array $tresorerie @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$tresorerie = $tresorerie ?? array();
$icone = array( 'caisse' => '💵', 'banque' => '🏦', 'mobile_money' => '📱' );
?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'paiements' ) ); ?>
<?php if ( $flash ) : ?><div class="alert <?= false !== strpos( (string) $flash, '⚠️' ) ? 'alert-warn' : 'alert-ok' ?>"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Total à payer : <strong style="color:var(--orange)"><?= e( fkc_money( $a_payer ) ) ?></strong></span></div>
<?php /* La distinction que l'écran ne faisait pas : une part constatée n'est pas un virement effectué. */ ?>
<p class="muted" style="font-size:13px;margin-bottom:12px">
	Les montants ci-dessous sont les parts <strong>constatées</strong> au profit de chaque ayant droit : elles alimentent son solde
	et figurent au bilan comme une dette. <strong>Aucun virement n'est déclenché par la répartition d'un relevé.</strong>
	Le règlement est un acte du label : c'est ici, et seulement ici, qu'il désigne le compte débité, la date réelle et la référence.
</p>
<?php if ( ! $tresorerie ) : ?>
	<div class="alert alert-warn" style="margin-bottom:12px">⚠️ Aucun compte de trésorerie actif n'est déclaré : les règlements partiront du compte de banque par défaut. Déclarez vos comptes (banque, Mobile Money, caisse) dans <a href="<?= e( url( 'comptabilite/tresorerie' ) ) ?>">Comptabilité → Trésorerie</a> pour choisir d'où sort l'argent.</div>
<?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Constater une part</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'royalties/paiements' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Artiste *</span><select name="artiste_id" required><option value="">—</option><?php foreach ( $artistes as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['nom_scene'] ?: $a['nom'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k => $l ) : ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Montant *</span><input type="number" step="any" name="montant" required></label>
			<?php /* « Payé » n'est pas proposé : une part se constate, puis se règle. */ ?>
			<label class="fld"><span>Statut</span><select name="statut"><?php foreach ( $statuts as $k => $l ) : if ( 'paye' === $k ) { continue; } ?><option value="<?= e( $k ) ?>"><?= e( $l ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Date</span><input type="date" name="date" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
			<div class="actions"><button class="btn btn-primary">Constater</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Paiements (<?= count( $paiements ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Constaté le</th><th>Ayant droit</th><th>Type</th><th class="num">Montant</th><th>Statut</th><th>Réglé</th><th style="width:360px">Déclencher le règlement</th></tr></thead><tbody>
		<?php if ( ! $paiements ) : ?><tr><td colspan="7" class="empty">Aucune part constatée.</td></tr>
		<?php else : foreach ( $paiements as $p ) : $paye = 'paye' === $p['statut']; ?><tr>
			<td><?= e( $p['date'] ) ?></td><td><strong><?= e( $p['nom_scene'] ?: $p['artiste_nom'] ) ?></strong></td>
			<td><?= e( $types[ $p['type'] ] ?? $p['type'] ) ?></td><td class="num"><?= e( fkc_money( $p['montant'] ) ) ?></td>
			<td><span class="modbadge <?= $paye ? 'b-on' : 'b-off' ?>"><?= e( $paye ? 'Réglé' : 'Constaté — non réglé' ) ?></span></td>
			<td style="font-size:12px">
				<?php if ( $paye ) : ?>
					<?= e( $p['date_reglement'] ?: '—' ) ?>
					<?php if ( ! empty( $p['tresorerie_id'] ) ) : foreach ( $tresorerie as $t ) : if ( (int) $t['id'] === (int) $p['tresorerie_id'] ) : ?>
						<br><span class="muted"><?= e( $icone[ $t['type'] ] ?? '' ) ?> <?= e( $t['libelle'] ) ?></span>
					<?php endif; endforeach; endif; ?>
					<?php if ( ! empty( $p['reference_reglement'] ) ) : ?><br><span class="muted code"><?= e( $p['reference_reglement'] ) ?></span><?php endif; ?>
				<?php else : ?><span class="muted">—</span><?php endif; ?>
			</td>
			<td class="right">
				<?php if ( ! $paye ) : ?>
					<?php /* Le label choisit d'où part l'argent : un règlement Mobile Money ne doit plus sortir comptablement de la banque. */ ?>
					<form method="post" action="<?= e( url( 'royalties/paiements/' . (int) $p['id'] . '/payer' ) ) ?>" style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end" onsubmit="return confirm('Déclencher le virement de <?= e( fkc_money( $p['montant'] ) ) ?> ? Cette opération passe l\'écriture de décaissement.')">
						<?= FKC_Csrf::field() ?>
						<select name="tresorerie_id" style="width:150px" title="Compte débité">
							<option value="">Banque (défaut)</option>
							<?php foreach ( $tresorerie as $t ) : ?><option value="<?= (int) $t['id'] ?>"><?= e( $icone[ $t['type'] ] ?? '' ) ?> <?= e( $t['libelle'] ) ?></option><?php endforeach; ?>
						</select>
						<input type="date" name="date_reglement" value="<?= e( date( 'Y-m-d' ) ) ?>" style="width:135px" title="Date réelle du virement">
						<input name="reference_reglement" placeholder="Réf." style="width:90px" title="Référence du virement ou du reçu Mobile Money">
						<button class="btn btn-primary btn-sm">Régler</button>
					</form>
				<?php endif; ?>
				<form method="post" action="<?= e( url( 'royalties/paiements/' . (int) $p['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form>
			</td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
