<?php /** @var array $familles @var string $actif @var array $actifs @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'secteur' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico">🎬</div>
	<div><h1 class="launch-title">Secteur d'activité</h1>
		<p class="launch-sub">Cochez tous les métiers que vous exercez réellement — leurs comptes sont tous proposés au plan comptable. Un seul, marqué « Terminologie », pilote les libellés affichés dans toute l'interface.</p></div>
</div>
<form method="post" action="<?= e( url( 'royalties/secteur' ) ) ?>">
	<?= FKC_Csrf::field() ?>
	<?php foreach ( $familles as $famille => $secteurs ) : ?>
		<div class="card" style="margin-bottom:14px"><div class="card-head"><h2><?= e( $famille ) ?></h2></div>
			<div class="card-body"><div class="fkc-cta-grid">
			<?php foreach ( $secteurs as $code => $m ) : $on = in_array( $code, $actifs, true ); $pr = ( $code === $actif ); ?>
				<label class="fkc-cta" style="cursor:pointer;<?= $on ? 'border-color:var(--ok);background:var(--ok-bg)' : 'background:var(--panel2);border-color:var(--line)' ?>">
					<span class="fkc-cta-label"><?= e( $m[0] ) ?> <?= e( $m[1] ) ?>
						<?php if ( $on ) : ?><span class="modbadge b-on" style="margin-left:6px">Actif</span><?php endif; ?>
						<?php if ( $pr ) : ?><span class="modbadge b-on" style="margin-left:4px">★ Terminologie</span><?php endif; ?>
					</span>
					<span style="margin-top:6px;display:flex;gap:14px;align-items:center">
						<label style="display:flex;gap:4px;align-items:center;cursor:pointer"><input type="checkbox" name="secteurs[]" value="<?= e( $code ) ?>" <?= $on ? 'checked' : '' ?>> <span class="muted">Actif</span></label>
						<label style="display:flex;gap:4px;align-items:center;cursor:pointer"><input type="radio" name="principal" value="<?= e( $code ) ?>" <?= $pr ? 'checked' : '' ?>> <span class="muted">Terminologie</span></label>
					</span>
				</label>
			<?php endforeach; ?>
			</div></div>
		</div>
	<?php endforeach; ?>
	<div class="actions"><button class="btn btn-primary" type="submit">Appliquer</button></div>
</form>
