<?php /** @var array $artistes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$st = FKC_Artiste::statuts(); ?>
<?php FKC_View::partial( 'royalties::_subnav', array( 'tab' => 'artistes' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted"><?= count( $artistes ) ?> <?= e( fkc_lc( FKC_Term::t('talents','talents') ) ) ?></span>
	<a class="btn btn-primary btn-sm" href="<?= e( url( 'royalties/artistes/nouveau' ) ) ?>">+ <?= e( FKC_Term::t('talent_new','Nouveau talent') ) ?></a></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th><?= e( FKC_Term::t('talent_alias','Alias') ) ?></th><th><?= e( FKC_Term::t('talent_domaine','Domaine') ) ?></th><th>Contrat</th><th class="num">Part <?= e( fkc_lc( FKC_Term::t('talent','talent') ) ) ?></th><th class="num">Solde dû</th><th>Statut</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $artistes ) : ?><tr><td colspan="8" class="empty">Aucun élément. Créez votre première fiche.</td></tr>
	<?php else : foreach ( $artistes as $a ) : ?><tr>
		<td class="code"><a href="<?= e( url( 'royalties/artistes/' . (int) $a['id'] . '/modifier' ) ) ?>"><strong><?= e( $a['code'] ) ?></strong></a></td>
		<td><strong><?= e( $a['nom_scene'] ?: $a['nom'] ) ?></strong><br><span class="muted" style="font-size:.85em"><?= e( $a['nom'] ) ?></span></td>
		<td><?= e( $a['genre'] ?: '—' ) ?></td><td><?= e( $a['contrat_type'] ?: '—' ) ?></td>
		<td class="num"><?= e( fkc_money( $a['part_artiste'], 0 ) ) ?>%</td>
		<td class="num"><?= e( fkc_money( FKC_Paiement::soldeArtiste( $a['id'] ) ) ) ?></td>
		<td><span class="modbadge <?= $a['statut']==='actif'?'b-on':'b-off' ?>"><?= e( $st[ $a['statut'] ] ?? $a['statut'] ) ?></span></td>
		<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'royalties/artistes/' . (int) $a['id'] . '/modifier' ) ) ?>">Fiche</a></td>
	</tr><?php endforeach; endif; ?>
	</tbody>
</table></div>
