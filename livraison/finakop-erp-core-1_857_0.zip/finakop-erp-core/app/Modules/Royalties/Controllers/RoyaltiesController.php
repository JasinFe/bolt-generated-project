<?php
/** Module Label musical (édition Creative) : artistes, catalogue, royalties, concerts, portail… @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RoyaltiesController {

	/** Garde-fou : fonction activée pour la sous-édition courante ? Sinon, écran « verrou ». */
	protected function gate( $feature ) {
		if ( FKC_Modules::featureEnabled( $feature ) ) { return true; }
		FKC_View::render( 'royalties::verrou', array(
			'title' => 'Label musical', 'tab' => '',
			'label' => FKC_Modules::featureLabel( $feature ), 'min' => FKC_Modules::featureMinLabel( $feature ),
		) );
		return false;
	}

	/* ── Tableau de bord ── */
	public function index() {
		if ( ! $this->gate( 'label.dashboard' ) ) { return; }
		FKC_View::render( 'royalties::dashboard', array(
			'title' => 'Label · Tableau de bord', 'tab' => 'dashboard',
			'd' => FKC_LabelDashboard::compute(), 'flash' => $this->flash(),
		) );
	}

	/* ── Artistes ── */
	public function artistes() {
		if ( ! $this->gate( 'label.artistes' ) ) { return; }
		FKC_View::render( 'royalties::artistes', array(
			'title' => 'Label · Artistes', 'tab' => 'artistes',
			'artistes' => FKC_Artiste::all(), 'flash' => $this->flash(),
		) );
	}
	public function artisteNew() { $this->artisteForm( null ); }
	public function artisteEdit( $id ) { $this->artisteForm( FKC_Artiste::find( $id ) ); }
	protected function artisteForm( $a ) {
		FKC_View::render( 'royalties::artiste_form', array(
			'title' => 'Label · ' . ( $a ? 'Fiche artiste' : 'Nouvel artiste' ), 'tab' => 'artistes', 'a' => $a,
			'statuts' => FKC_Artiste::statuts(), 'contrats' => FKC_Artiste::contrats(),
			'hist' => $a ? FKC_Artiste::historique( $a['id'] ) : null,
			'solde' => $a ? FKC_Paiement::soldeArtiste( $a['id'] ) : 0,
			'token' => $a ? FKC_Portail::token( $a['id'] ) : '', 'flash' => $this->flash(),
		) );
	}
	public function artisteSave( $id = 0 ) {
		$code = trim( (string) ( $_POST['code'] ?? '' ) );
		if ( '' === $code || '' === trim( (string) ( $_POST['nom'] ?? '' ) ) ) { $this->setFlash( 'Code et nom requis.' ); redirect( $id ? 'royalties/artistes/' . (int) $id . '/modifier' : 'royalties/artistes/nouveau' ); }
		if ( FKC_Artiste::codeExists( $code, (int) $id ) ) { $this->setFlash( 'Ce code existe déjà.' ); redirect( $id ? 'royalties/artistes/' . (int) $id . '/modifier' : 'royalties/artistes/nouveau' ); }
		if ( $id ) { FKC_Artiste::update( $id, $_POST ); $this->setFlash( 'Artiste mis à jour.' ); }
		else {
			if ( ! FKC_License::within( 'artistes', FKC_Artiste::count() ) ) { $this->setFlash( FKC_License::quotaMessage( 'artistes', 'artiste(s)' ) ); redirect( 'royalties/artistes/nouveau' ); }
			$id = FKC_Artiste::create( $_POST ); $this->setFlash( 'Artiste créé.' );
		}
		redirect( 'royalties/artistes/' . (int) $id . '/modifier' );
	}
	public function artisteDelete( $id ) { FKC_Artiste::delete( $id ); $this->setFlash( 'Artiste supprimé.' ); redirect( 'royalties/artistes' ); }

	/* ── Catalogue ── */
	public function catalogue() {
		if ( ! $this->gate( 'label.catalogue' ) ) { return; }
		FKC_View::render( 'royalties::catalogue', array(
			'title' => 'Catalogue', 'tab' => 'catalogue',
			'oeuvres' => FKC_Oeuvre::all(), 'types' => FKC_Term::oeuvreTypes(), 'artistes' => FKC_Artiste::map(),
			'splitsDispo' => class_exists( 'FKC_CreativeSplits' ), 'flash' => $this->flash(),
		) );
	}
	public function catalogueStore() {
		if ( '' !== trim( (string) ( $_POST['titre'] ?? '' ) ) ) {
			if ( ! FKC_License::within( 'oeuvres', FKC_Oeuvre::count() ) ) { $this->setFlash( FKC_License::quotaMessage( 'oeuvres', 'œuvre(s)' ) ); redirect( 'royalties/catalogue' ); }
			FKC_Oeuvre::create( $_POST ); $this->setFlash( 'Œuvre ajoutée au catalogue.' );
		}
		redirect( 'royalties/catalogue' );
	}
	public function catalogueDelete( $id ) { FKC_Oeuvre::delete( $id ); $this->setFlash( 'Œuvre supprimée.' ); redirect( 'royalties/catalogue' ); }

	/* ── Décompte consolidé par ayant droit (multi-périodes) ─────────────── */

	/* ── Barèmes de répartition (noms distributeurs + collaborations) ───── */

	public function baremes() {
		if ( ! $this->gate( 'label.royalties' ) ) { return; }
		if ( ! class_exists( 'FKC_LabelBareme' ) ) { $this->setFlash( 'Les barèmes nécessitent la Creative Suite.' ); redirect( 'royalties/royalties' ); }
		FKC_View::render( 'royalties::baremes', array(
			'title' => 'Label · Barèmes de répartition', 'tab' => 'royalties',
			'noms'      => FKC_LabelBareme::noms(),
			'baremes'   => FKC_LabelBareme::tous(),
			'collabs'   => FKC_LabelBareme::collaborationsSansBareme(),
			'modes'     => FKC_LabelBareme::modes(),
			'artistes'  => FKC_Artiste::all( true ),
			'flash'     => $this->flash(),
		) );
	}

	/** Rattache un nom écrit par le distributeur à une fiche, ou au label. */
	public function baremeNom() {
		if ( ! class_exists( 'FKC_LabelBareme' ) ) { redirect( 'royalties/royalties' ); }
		list( $ok, $msg ) = FKC_LabelBareme::definirNom( (int) ( $_POST['nom_id'] ?? 0 ), $_POST['cible'] ?? '' );
		/*
		 * Un rattachement change QUI est payé : les relevés encore ouverts
		 * sont recalculés tout de suite. Sans cela, le nom serait reconnu au
		 * prochain import seulement, et le relevé en cours resterait faux.
		 */
		if ( $ok ) {
			foreach ( FKC_Royalty::imports() as $imp ) {
				if ( 'comptabilise' !== $imp['statut'] ) { FKC_Royalty::recalculer( (int) $imp['id'] ); }
			}
		}
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'royalties/baremes' );
	}

	public function baremeStore() {
		if ( ! class_exists( 'FKC_LabelBareme' ) ) { redirect( 'royalties/royalties' ); }
		// Les parts arrivent en tableaux parallèles (nom[], artiste_id[], part[]).
		$parts = array();
		$noms = (array) ( $_POST['part_nom'] ?? array() );
		$arts = (array) ( $_POST['part_artiste'] ?? array() );
		$pcts = (array) ( $_POST['part_pct'] ?? array() );
		foreach ( $noms as $i => $nom ) {
			if ( '' === trim( (string) $nom ) ) { continue; }
			$parts[] = array( 'nom' => $nom, 'artiste_id' => $arts[ $i ] ?? null, 'part' => $pcts[ $i ] ?? 0 );
		}
		list( $ok, $msg ) = FKC_LabelBareme::enregistrer(
			$_POST['portee'] ?? 'collaboration', $_POST['cle'] ?? '', $_POST['libelle'] ?? '',
			$_POST['mode'] ?? 'equitable', $_POST['part_label'] ?? 0, $parts
		);
		$this->setFlash( $ok ? $msg . ' Utilisez « Re-ventiler » sur les relevés non comptabilisés pour l\'appliquer aux lignes déjà importées.' : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'royalties/baremes' );
	}

	public function baremeDelete( $id ) {
		if ( ! class_exists( 'FKC_LabelBareme' ) ) { redirect( 'royalties/royalties' ); }
		list( , $msg ) = FKC_LabelBareme::supprimer( (int) $id );
		$this->setFlash( $msg );
		redirect( 'royalties/baremes' );
	}

	public function decompte() {
		$bornes = FKC_Royalty::periodesBornes();
		$debut = trim( (string) ( $_GET['debut'] ?? '' ) ) ?: null;
		$fin = trim( (string) ( $_GET['fin'] ?? '' ) ) ?: null;
		FKC_View::render( 'royalties::decompte', array(
			'title' => 'Décompte par ayant droit', 'tab' => 'royalties',
			'decompte' => FKC_Royalty::decompteParAyantDroit( $debut, $fin ),
			'bornes' => $bornes,
			'debut' => $debut, 'fin' => $fin,
			'flash' => $this->flash(),
		) );
	}

	public function decompteIndividuel() {
		$ref = trim( (string) ( $_GET['ref'] ?? '' ) );
		if ( '' === $ref ) { redirect( 'royalties/decompte' ); }
		$debut = trim( (string) ( $_GET['debut'] ?? '' ) ) ?: null;
		$fin = trim( (string) ( $_GET['fin'] ?? '' ) ) ?: null;
		FKC_View::render( 'royalties::decompte_individuel', array(
			'title' => 'Décompte individuel', 'tab' => 'royalties',
			'd' => FKC_Royalty::decompteIndividuel( $ref, $debut, $fin ),
			'debut' => $debut, 'fin' => $fin, 'flash' => $this->flash(),
		) );
	}

	/* ── Splits multi-ayants droit (Creative Suite) ──────────────────────── */

	/** Vrai si le moteur de splits (pack creative actif) est disponible. */
	protected function splitsDispo() {
		return class_exists( 'FKC_CreativeSplits' );
	}

	public function oeuvreSplits( $id ) {
		if ( ! $this->splitsDispo() ) { $this->setFlash( 'Les splits nécessitent la Creative Suite.' ); redirect( 'royalties/catalogue' ); }
		$oeuvre = FKC_Oeuvre::find( $id );
		if ( ! $oeuvre ) { $this->setFlash( 'Œuvre introuvable.' ); redirect( 'royalties/catalogue' ); }
		FKC_View::render( 'royalties::splits', array(
			'title' => 'Splits · ' . $oeuvre['titre'], 'tab' => 'catalogue',
			'oeuvre' => $oeuvre,
			'artistePrincipal' => ! empty( $oeuvre['artiste_id'] ) ? FKC_Artiste::find( (int) $oeuvre['artiste_id'] ) : null,
			'splits' => FKC_CreativeSplits::splits( (int) $id ),
			'etat' => FKC_CreativeSplits::etat( (int) $id ),
			'roles' => FKC_CreativeSplits::roles(),
			'artistes' => FKC_Artiste::all( true ),
			'flash' => $this->flash(),
		) );
	}

	public function oeuvreSplitAdd( $id ) {
		if ( ! $this->splitsDispo() ) { redirect( 'royalties/catalogue' ); }
		list( , $msg ) = FKC_CreativeSplits::ajouter( (int) $id, $_POST );
		$this->setFlash( $msg );
		redirect( 'royalties/catalogue/' . (int) $id . '/splits' );
	}

	public function oeuvreSplitAmorcer( $id ) {
		if ( ! $this->splitsDispo() ) { redirect( 'royalties/catalogue' ); }
		list( , $msg ) = FKC_CreativeSplits::initialiserDepuisFiche( (int) $id );
		$this->setFlash( $msg );
		redirect( 'royalties/catalogue/' . (int) $id . '/splits' );
	}

	public function oeuvreSplitEquilibrer( $id ) {
		if ( ! $this->splitsDispo() ) { redirect( 'royalties/catalogue' ); }
		list( $ok, $msg ) = FKC_CreativeSplits::equilibrerLabel( (int) $id );
		$this->setFlash( ( $ok ? '' : '⚠️ ' ) . $msg );
		redirect( 'royalties/catalogue/' . (int) $id . '/splits' );
	}

	public function oeuvreSplitPart( $id, $splitId ) {
		if ( ! $this->splitsDispo() ) { redirect( 'royalties/catalogue' ); }
		// Le split doit appartenir à l'œuvre de l'adresse.
		$s = FKC_DB::q( 'SELECT oeuvre_id FROM cr_splits WHERE id=?', array( (int) $splitId ) )->fetch();
		if ( $s && (int) $s['oeuvre_id'] === (int) $id ) {
			list( , $msg ) = FKC_CreativeSplits::modifierPart( (int) $splitId, FKC_Royalty::nombre( $_POST['part'] ?? 0 ) );
			$this->setFlash( $msg );
		}
		redirect( 'royalties/catalogue/' . (int) $id . '/splits' );
	}

	public function oeuvreSplitDelete( $id, $splitId ) {
		if ( ! $this->splitsDispo() ) { redirect( 'royalties/catalogue' ); }
		FKC_CreativeSplits::retirer( (int) $splitId );
		$this->setFlash( 'Ayant droit retiré.' );
		redirect( 'royalties/catalogue/' . (int) $id . '/splits' );
	}

	/* ── Projets ── */
	public function projets() {
		if ( ! $this->gate( 'label.projets' ) ) { return; }
		FKC_View::render( 'royalties::projets', array(
			'title' => 'Label · Projets', 'tab' => 'projets',
			'projets' => FKC_Projet::all(), 'statuts' => FKC_Projet::statuts(), 'artistes' => FKC_Artiste::map(), 'flash' => $this->flash(),
		) );
	}
	public function projetStore() {
		if ( '' !== trim( (string) ( $_POST['titre'] ?? '' ) ) ) {
			if ( ! FKC_License::within( 'projets', FKC_Projet::count() ) ) { $this->setFlash( FKC_License::quotaMessage( 'projets', 'projet(s)' ) ); redirect( 'royalties/projets' ); }
			FKC_Projet::create( $_POST ); $this->setFlash( 'Projet créé.' );
		}
		redirect( 'royalties/projets' );
	}
	public function projetDelete( $id ) { FKC_Projet::delete( $id ); $this->setFlash( 'Projet supprimé.' ); redirect( 'royalties/projets' ); }

	/* ── Royalties ── */
	public function royalties() {
		if ( ! $this->gate( 'label.royalties' ) ) { return; }
		$sel = isset( $_GET['i'] ) ? FKC_Royalty::find( (int) $_GET['i'] ) : null;
		$imports = FKC_Royalty::imports();
		$conversions = array();
		foreach ( $imports as $im ) { $conversions[ (int) $im['id'] ] = FKC_Royalty::conversion( $im ); }
		FKC_View::render( 'royalties::royalties', array(
			'title' => 'Label · Royalties', 'tab' => 'royalties',
			'imports' => $imports, 'conversions' => $conversions, 'sel' => $sel, 'sources' => FKC_Royalty::sources(),
			'artistes' => FKC_Artiste::all( true ),
			'oeuvres' => FKC_Oeuvre::all(),
			'parPlateforme' => $sel ? FKC_Royalty::parPlateforme( $sel['id'] ) : array(),
			'repartition' => $sel ? FKC_Royalty::repartitionAyantsDroit( $sel['id'] ) : null,
			'nonAttribues' => $sel ? FKC_Royalty::nonAttribues( $sel['id'] ) : array(),
			'devises' => array_values( array_unique( array_merge( array( 'USD', 'EUR', 'GBP' ),
				class_exists( 'FKC_Devise' ) ? array_keys( (array) FKC_Devise::catalogue() ) : array() ) ) ),
			'pivot' => class_exists( 'FKC_Devise' ) ? FKC_Devise::pivot() : 'XOF',
			'encaissement' => $sel ? FKC_RoyaltyEncaissement::etat( $sel ) : null,
			'encaissements' => $sel ? FKC_RoyaltyEncaissement::parImport( $sel['id'] ) : array(),
			'tresorerie' => class_exists( 'FKC_Tresorerie' ) ? FKC_Tresorerie::comptes( true ) : array(),
			'flash' => $this->flash(),
		) );
	}
	public function royaltyImport() {
		$src = $_POST['source'] ?? 'tunecore';
		if ( ! FKC_License::within( 'royalties', FKC_Royalty::countMois() ) ) { $this->setFlash( FKC_License::quotaMessage( 'royalties', 'calculs de royalties ce mois-ci' ) ); redirect( 'royalties/royalties' ); }

		// Contenu du releve : fichier televerse prioritaire, sinon texte colle.
		$csv = ''; $nomFichier = '';
		$aFichier = ! empty( $_FILES['fichier']['name'] ) && UPLOAD_ERR_NO_FILE !== (int) ( $_FILES['fichier']['error'] ?? UPLOAD_ERR_NO_FILE );
		if ( $aFichier ) {
			list( $csv, $err, $nomFichier ) = $this->lireRapportUploade( $_FILES['fichier'] );
			if ( '' !== $err ) { $this->setFlash( "\xE2\x9A\xA0\xEF\xB8\x8F " . $err ); redirect( 'royalties/royalties' ); }
		} elseif ( ! empty( $_POST['csv'] ) ) {
			$csv = (string) $_POST['csv'];
		}
		/*
		 * ═══════════════════════════════════════════════════════════════
		 *  GARDE-FOU ANTI DOUBLE COMPTAGE (1.665.0)
		 * ═══════════════════════════════════════════════════════════════
		 *  Un label qui possède ce module ET le pack Artiste peut importer
		 *  le même rapport de distributeur deux fois, une fois de chaque
		 *  côté. Les deux se comptabilisent, le chiffre d'affaires double,
		 *  et RIEN ne le signale — c'est le défaut le plus coûteux que la
		 *  coexistence des deux moteurs rendait possible.
		 *
		 *  L'empreinte — source, période, contenu du fichier — vit dans une
		 *  table du noyau que les deux moteurs consultent. Le refus est
		 *  volontairement précoce : avant même de créer le relevé, pour ne
		 *  pas laisser derrière soi un import vide à nettoyer.
		 * ═══════════════════════════════════════════════════════════════
		 */
		if ( '' !== trim( $csv ) && class_exists( 'FKC_ImportRun' ) ) {
			$emp  = FKC_ImportRun::empreinte( $src, (string) ( $_POST['periode'] ?? '' ), $csv );
			$deja = FKC_ImportRun::dejaImporte( $emp );
			if ( $deja ) {
				$this->setFlash( "\xE2\x9A\xA0\xEF\xB8\x8F Ce rapport a déjà été importé le "
					. substr( (string) $deja['at'], 0, 10 ) . ' (' . ( $deja['reference'] ?: $deja['origine'] )
					. '). L\'importer une seconde fois compterait ces revenus en double.' );
				redirect( 'royalties/royalties' );
			}
		}

		/*
		 * UNE DEVISE PAR RELEVÉ (1.744.0). Un fichier qui en mêle plusieurs
		 * s'additionnait tel quel. Refus AVANT toute création.
		 */
		$devise = strtoupper( trim( (string) ( $_POST['devise'] ?? 'USD' ) ) ) ?: 'USD';
		$avisDevise = '';
		if ( '' !== trim( $csv ) ) {
			$devs = FKC_Royalty::devisesDuFichier( $csv );
			if ( count( $devs ) > 1 ) {
				$this->setFlash( "\xE2\x9A\xA0\xEF\xB8\x8F Ce fichier mélange plusieurs devises (" . implode( ', ', $devs )
					. ') : exportez un fichier par devise depuis votre distributeur. Rien n\'a été importé.' );
				redirect( 'royalties/royalties' );
			}
			if ( 1 === count( $devs ) && $devs[0] !== $devise ) {
				$avisDevise = ' Devise lue dans le fichier : ' . $devs[0] . ' (vous aviez indiqué ' . $devise . ').';
				$devise = $devs[0];
			}
		}
		$id = FKC_Royalty::createImport( $src, $_POST['periode'] ?? '', $_POST['date'] ?? null, $devise );
		$avisCours = '';
		if ( '' !== trim( (string) ( $_POST['cours'] ?? '' ) ) ) {
			list( $okC, $msgC ) = FKC_Royalty::enregistrerCours( $id, $_POST['cours'] );
			$avisCours = ' ' . ( $okC ? '' : '⚠️ ' ) . $msgC;
		}
		if ( '' !== trim( $csv ) ) {
			if ( class_exists( 'FKC_ImportRun' ) ) {
				FKC_ImportRun::poserEmpreinte(
					FKC_ImportRun::empreinte( $src, (string) ( $_POST['periode'] ?? '' ), $csv ),
					'module:royalties', 'relevé n°' . (int) $id
				);
			}
			// Aiguillage automatique : rapport TuneCore natif détecté, sinon format générique.
			list( $n, $brut, $unites, $nonRattaches ) = FKC_Royalty::importer( $id, $csv, $src );
			$imp  = FKC_Royalty::find( $id );
			$conv = FKC_Royalty::conversion( $imp );
			$msg = $n . ' ligne(s) importée(s)';
			$msg .= $nomFichier ? ' depuis « ' . $nomFichier . ' » — ' : ' — ';
			$msg .= number_format( (int) $unites, 0, ',', ' ' ) . ' unités, '
				. number_format( (float) $brut, 2, ',', ' ' ) . ' ' . $conv['devise'];
			$msg .= $conv['ok']
				? ' soit ' . number_format( (float) $conv['total_local'], 0, ',', ' ' ) . ' ' . $conv['pivot'] . ' (cours ' . $conv['taux'] . ').'
				: '. ⚠️ ' . $conv['message'] . ' Saisissez le cours sur le relevé.';
			$msg .= $avisDevise . $avisCours;
			if ( ! empty( $nonRattaches ) ) {
				$msg .= ' ⚠️ ' . count( $nonRattaches ) . ' titre(s) non rattaché(s) au catalogue : attribuez-les avant de comptabiliser.';
			}
			$this->setFlash( $msg );
		} else { $this->setFlash( 'Relevé créé. Téléversez le fichier du distributeur ou collez le CSV, ou ajoutez des lignes manuellement.' . $avisCours ); }
		redirect( 'royalties/royalties?i=' . $id );
	}
	public function royaltyLigne( $id ) {
		if ( ! FKC_License::within( 'royalties', FKC_Royalty::countMois() ) ) { $this->setFlash( FKC_License::quotaMessage( 'royalties', 'calculs de royalties ce mois-ci' ) ); redirect( 'royalties/royalties?i=' . (int) $id ); }
		FKC_Royalty::addLigne( $id, $_POST ); $this->setFlash( 'Ligne ajoutée et répartie.' );
		redirect( 'royalties/royalties?i=' . (int) $id );
	}
	/**
	 * Lit un rapport televerse de facon sure.
	 * @return array{string, mixed, mixed} ( contenu, message_erreur, nom_fichier )
	 */
	protected function lireRapportUploade( array $f ) {
		$err = (int) ( $f['error'] ?? UPLOAD_ERR_NO_FILE );
		if ( UPLOAD_ERR_INI_SIZE === $err || UPLOAD_ERR_FORM_SIZE === $err ) { return array( '', 'Fichier trop volumineux.', '' ); }
		if ( UPLOAD_ERR_OK !== $err ) { return array( '', "\xC3\x89chec du t\xC3\xA9l\xC3\xA9versement, r\xC3\xA9essayez.", '' ); }
		$tmp = (string) ( $f['tmp_name'] ?? '' );
		if ( '' === $tmp || ! is_uploaded_file( $tmp ) ) { return array( '', 'Fichier invalide.', '' ); }
		if ( (int) ( $f['size'] ?? 0 ) > 8 * 1024 * 1024 ) { return array( '', 'Fichier trop volumineux (8 Mo maximum).', '' ); }
		$nom = basename( (string) ( $f['name'] ?? 'rapport.csv' ) );
		$ext = strtolower( pathinfo( $nom, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'xlsx', 'xls' ), true ) ) {
			return array( '', "Les fichiers Excel (.xlsx) ne sont pas encore pris en charge \xE2\x80\x94 exportez le rapport en CSV depuis votre distributeur, puis t\xC3\xA9l\xC3\xA9versez-le.", '' );
		}
		if ( '' !== $ext && ! in_array( $ext, array( 'csv', 'tsv', 'txt' ), true ) ) {
			return array( '', 'Format non reconnu : deposez un fichier CSV, TSV ou texte exporte par votre distributeur.', '' );
		}
		$contenu = file_get_contents( $tmp );
		if ( false === $contenu ) { return array( '', 'Lecture du fichier impossible.', '' ); }
		return array( $contenu, '', $nom );
	}

	public function royaltyCours( $id ) {
		list( $ok, $msg ) = FKC_Royalty::enregistrerCours( (int) $id, $_POST['cours'] ?? '' );
		$this->setFlash( ( $ok ? '' : '⚠️ ' ) . $msg );
		redirect( 'royalties/royalties?i=' . (int) $id );
	}

	public function royaltyAttribuer( $id ) {
		list( $ok, $msg ) = FKC_Royalty::attribuer( (int) $id, (string) ( $_POST['titre'] ?? '' ),
			(string) ( $_POST['artiste'] ?? '' ), (string) ( $_POST['cible'] ?? '' ), ! empty( $_POST['memoriser'] ) );
		$this->setFlash( ( $ok ? '' : '⚠️ ' ) . $msg );
		redirect( 'royalties/royalties?i=' . (int) $id );
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * ÉTAT DE CONTRÔLE DES ATTRIBUTIONS PASSÉES
	 * ══════════════════════════════════════════════════════════════════════ */

	/**
	 * L'écran de relecture des relevés déjà comptabilisés.
	 *
	 * Il vit dans les Royalties et non dans un menu d'administration : c'est le
	 * label qui sait à qui revient un titre, et c'est lui qui doit trancher.
	 */
	public function royaltyRevision() {
		FKC_View::render( 'royalties::revision', array(
			'title'  => 'Label · Attributions à vérifier',
			'tab'    => 'royalties',
			'audit'  => FKC_RoyaltyRevision::auditer( array( 'comptabilises_seuls' => empty( $_GET['tous'] ) ) ),
			'tous'   => ! empty( $_GET['tous'] ),
			'flash'  => $this->flash(),
		) );
	}

	public function royaltyConfirmer( $id ) {
		list( $ok, $msg ) = FKC_RoyaltyRevision::confirmer( (int) $id );
		$this->setFlash( ( $ok ? '' : "\xE2\x9A\xA0\xEF\xB8\x8F " ) . $msg );
		redirect( 'royalties/revision' . ( empty( $_POST['tous'] ) ? '' : '?tous=1' ) );
	}

	public function royaltyEcarter( $id ) {
		list( $ok, $msg ) = FKC_RoyaltyRevision::ecarter( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( ( $ok ? '' : "\xE2\x9A\xA0\xEF\xB8\x8F " ) . $msg );
		redirect( 'royalties/revision' . ( empty( $_POST['tous'] ) ? '' : '?tous=1' ) );
	}

	/**
	 * Rejoue la ventilation d'un relevé avec les barèmes en vigueur —
	 * l'action qui manquait après la création d'un barème.
	 */
	public function royaltyReventiler( $id ) {
		list( $ok, $msg ) = FKC_Royalty::reventiler( $id );
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'royalties/royalties?i=' . (int) $id );
	}

	/**
	 * Enregistre le versement demandé par le label au distributeur.
	 * Le relevé constate le produit ; c'est ici que l'argent arrive.
	 */
	public function royaltyEncaisser( $id ) {
		list( $ok, $msg ) = FKC_RoyaltyEncaissement::enregistrer( $id, array(
			'date'           => $_POST['date'] ?? '',
			'montant_devise' => $_POST['montant_devise'] ?? 0,
			'frais_devise'   => $_POST['frais_devise'] ?? 0,
			'taux'           => $_POST['taux'] ?? 0,
			'tresorerie_id'  => $_POST['tresorerie_id'] ?? 0,
			'reference'      => $_POST['reference'] ?? '',
		) );
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'royalties/royalties?i=' . (int) $id );
	}

	public function encaissementDelete( $id ) {
		$e = FKC_DB::q( 'SELECT import_id FROM lbl_royalty_encaissements WHERE id=?', array( (int) $id ) )->fetch();
		list( $ok, $msg ) = FKC_RoyaltyEncaissement::supprimer( $id );
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'royalties/royalties' . ( $e ? '?i=' . (int) $e['import_id'] : '' ) );
	}

	public function royaltyComptabiliser( $id ) {
		list( $eid, $nb, $extra ) = FKC_Royalty::comptabiliser( $id );
		/*
		 * Un refus s'affiche comme un refus (1.744.0). Le message affirmait
		 * « Répartition enregistrée (comptabilité indisponible) » alors que
		 * rien n'avait été fait — l'absence de cours passait inaperçue.
		 */
		if ( ! empty( $extra['erreur'] ) ) {
			$this->setFlash( '⚠️ ' . $extra['erreur'] );
			redirect( 'royalties/royalties?i=' . (int) $id );
		}
		$msg = $eid ? 'Relevé comptabilisé' : 'Répartition enregistrée (module Comptabilité inactif)';
		if ( ! empty( $extra['pivot'] ) ) {
			$msg .= ' : ' . number_format( (float) $extra['brut_pivot'], 0, ',', ' ' ) . ' ' . $extra['pivot']
				. ' dont ' . number_format( (float) $extra['ayants_pivot'], 0, ',', ' ' ) . ' ' . $extra['pivot'] . ' dus aux ayants droit';
		}
		$msg .= ' ; ' . $nb . ' dû(s) artiste créé(s).';
		$externes = $extra['externes'] ?? array();
		$bloque = $extra['bloque'] ?? array();
		if ( $externes ) {
			$totalExt = array_sum( array_map( fn( $e ) => (float) $e['montant_local'], $externes ) );
			$msg .= ' ⚠️ ' . count( $externes ) . ' ayant(s) droit externe(s) (' . number_format( $totalExt, 0, ',', ' ' ) . ' ' . ( $extra['pivot'] ?? '' ) . ') à régler hors roster.';
		}
		$this->setFlash( $msg );
		redirect( 'royalties/royalties?i=' . (int) $id );
	}
	public function royaltyDelete( $id ) {
		list( $ok, $msg ) = FKC_Royalty::delete( $id );
		$this->setFlash( ( $ok ? '' : '⚠️ ' ) . $msg );
		redirect( $ok ? 'royalties/royalties' : 'royalties/royalties?i=' . (int) $id );
	}

	/* ── Paiements ── */
	public function paiements() {
		if ( ! $this->gate( 'label.paiements' ) ) { return; }
		FKC_View::render( 'royalties::paiements', array(
			'title' => 'Label · Paiements', 'tab' => 'paiements',
			'paiements' => FKC_Paiement::all(), 'statuts' => FKC_Paiement::statuts(), 'types' => FKC_Paiement::types(),
			'artistes' => FKC_Artiste::all( true ), 'a_payer' => FKC_Paiement::aPayer(),
			// Comptes de trésorerie disponibles : c'est le label qui désigne
			// celui d'où part le virement (banque, Mobile Money, caisse).
			'tresorerie' => class_exists( 'FKC_Tresorerie' ) ? FKC_Tresorerie::comptes( true ) : array(),
			'flash' => $this->flash(),
		) );
	}
	public function paiementStore() {
		if ( ! empty( $_POST['artiste_id'] ) && (float) ( $_POST['montant'] ?? 0 ) > 0 ) {
			// Saisie manuelle : c'est le seul chemin qui doive produire
			// l'écriture de constatation, l'import de décomptes passant déjà la sienne.
			$d = $_POST + array( 'comptabiliser' => true );
			/*
			 * ON NE CRÉE JAMAIS UNE PART DÉJÀ « RÉGLÉE ».
			 *
			 * Le formulaire proposait le statut « Payé » : la part naissait
			 * alors soldée SANS la moindre écriture de décaissement. L'argent
			 * était réputé sorti sans que la trésorerie bouge, et la dette
			 * disparaissait du bilan sans contrepartie. Une part se constate
			 * d'abord, puis le label déclenche le virement.
			 */
			if ( 'paye' === ( $d['statut'] ?? '' ) ) { $d['statut'] = 'a_payer'; }
			FKC_Paiement::create( $d );
			$this->setFlash( 'Part constatée. Déclenchez le règlement depuis la liste quand le virement est fait.' );
		}
		redirect( 'royalties/paiements' );
	}
	/**
	 * Déclenche le règlement — acte du label, jamais une conséquence
	 * automatique de la répartition. Le compte débité, la date réelle et la
	 * référence viennent du formulaire ; rien n'est deviné.
	 */
	public function paiementPayer( $id ) {
		list( $ok, $msg ) = FKC_Paiement::marquerPaye( $id, array(
			'tresorerie_id' => $_POST['tresorerie_id'] ?? 0,
			'date'          => $_POST['date_reglement'] ?? '',
			'reference'     => $_POST['reference_reglement'] ?? '',
		) );
		$this->setFlash( $ok ? $msg : "\xE2\x9A\xA0\xEF\xB8\x8F " . $msg );
		redirect( 'royalties/paiements' );
	}
	public function paiementDelete( $id ) { FKC_Paiement::delete( $id ); $this->setFlash( 'Paiement supprimé.' ); redirect( 'royalties/paiements' ); }

	/* ── Concerts ── */
	public function concerts() {
		if ( ! $this->gate( 'label.concerts' ) ) { return; }
		FKC_View::render( 'royalties::concerts', array(
			'title' => 'Label · Concerts', 'tab' => 'concerts',
			'concerts' => FKC_Concert::all(), 'statuts' => FKC_Concert::statuts(), 'types' => FKC_Concert::types(),
			'artistes' => FKC_Artiste::map(), 'flash' => $this->flash(),
		) );
	}
	public function concertStore() {
		if ( '' !== trim( (string) ( $_POST['titre'] ?? '' ) ) ) { FKC_Concert::create( $_POST ); $this->setFlash( 'Concert ajouté.' ); }
		redirect( 'royalties/concerts' );
	}
	public function concertDelete( $id ) { FKC_Concert::delete( $id ); $this->setFlash( 'Concert supprimé.' ); redirect( 'royalties/concerts' ); }

	/* ── Merchandising ── */
	public function merch() {
		if ( ! $this->gate( 'label.merch' ) ) { return; }
		FKC_View::render( 'royalties::merch', array(
			'title' => 'Label · Merchandising', 'tab' => 'merch',
			'produits' => FKC_Merch::all(), 'types' => FKC_Merch::types(), 'ca' => FKC_Merch::caTotal(), 'flash' => $this->flash(),
		) );
	}
	public function merchStore() {
		if ( '' !== trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { FKC_Merch::create( $_POST ); $this->setFlash( 'Produit ajouté.' ); }
		redirect( 'royalties/merch' );
	}
	public function merchVente( $id ) {
		FKC_Merch::vendre( $id, (float) ( $_POST['quantite'] ?? 0 ), (float) ( $_POST['pu'] ?? 0 ) ); $this->setFlash( 'Vente enregistrée.' );
		redirect( 'royalties/merch' );
	}
	public function merchDelete( $id ) { FKC_Merch::delete( $id ); $this->setFlash( 'Produit supprimé.' ); redirect( 'royalties/merch' ); }

	/* ── Production & Studio ── */
	public function studio() {
		if ( ! $this->gate( 'label.studio' ) ) { return; }
		FKC_View::render( 'royalties::studio', array(
			'title' => 'Label · Production & Studio', 'tab' => 'studio',
			'sessions' => FKC_Studio::all(), 'oeuvres' => FKC_Oeuvre::map(), 'artistes' => FKC_Artiste::map(), 'flash' => $this->flash(),
		) );
	}
	public function studioStore() { FKC_Studio::create( $_POST ); $this->setFlash( 'Session enregistrée.' ); redirect( 'royalties/studio' ); }
	public function studioDelete( $id ) { FKC_Studio::delete( $id ); $this->setFlash( 'Session supprimée.' ); redirect( 'royalties/studio' ); }

	/* ── Publishing ── */
	public function publishing() {
		if ( ! $this->gate( 'label.publishing' ) ) { return; }
		FKC_View::render( 'royalties::publishing', array(
			'title' => 'Label · Publishing', 'tab' => 'publishing',
			'droits' => FKC_Publishing::all(), 'organismes' => FKC_Publishing::organismes(), 'oeuvres' => FKC_Oeuvre::map(), 'flash' => $this->flash(),
		) );
	}
	public function publishingStore() { FKC_Publishing::create( $_POST ); $this->setFlash( 'Droit enregistré.' ); redirect( 'royalties/publishing' ); }
	public function publishingDelete( $id ) { FKC_Publishing::delete( $id ); $this->setFlash( 'Supprimé.' ); redirect( 'royalties/publishing' ); }

	/* ── Marketing ── */
	public function marketing() {
		if ( ! $this->gate( 'label.marketing' ) ) { return; }
		FKC_View::render( 'royalties::marketing', array(
			'title' => 'Label · Marketing', 'tab' => 'marketing',
			'campagnes' => FKC_Marketing::all(), 'plateformes' => FKC_Marketing::plateformes(), 'artistes' => FKC_Artiste::map(), 'flash' => $this->flash(),
		) );
	}
	public function marketingStore() {
		if ( '' !== trim( (string) ( $_POST['campagne'] ?? '' ) ) ) { FKC_Marketing::create( $_POST ); $this->setFlash( 'Campagne créée.' ); }
		redirect( 'royalties/marketing' );
	}
	public function marketingDelete( $id ) { FKC_Marketing::delete( $id ); $this->setFlash( 'Campagne supprimée.' ); redirect( 'royalties/marketing' ); }

	/* ── CRM ── */
	public function crm() {
		if ( ! $this->gate( 'label.crm' ) ) { return; }
		FKC_View::render( 'royalties::crm', array(
			'title' => 'Label · CRM', 'tab' => 'crm',
			'contacts' => FKC_Crm::all(), 'types' => FKC_Crm::types(), 'categories' => FKC_Crm::categories(), 'flash' => $this->flash(),
		) );
	}
	public function crmStore() {
		if ( '' !== trim( (string) ( $_POST['nom'] ?? '' ) ) ) { FKC_Crm::create( $_POST ); $this->setFlash( 'Contact ajouté.' ); }
		redirect( 'royalties/crm' );
	}
	public function crmDelete( $id ) { FKC_Crm::delete( $id ); $this->setFlash( 'Contact supprimé.' ); redirect( 'royalties/crm' ); }

	/* ── Distribution digitale ── */
	public function releases() {
		if ( ! $this->gate( 'label.releases' ) ) { return; }
		FKC_View::render( 'royalties::releases', array(
			'title' => 'Label · Distribution', 'tab' => 'releases',
			'releases' => FKC_Release::all(), 'statuts' => FKC_Release::statuts(), 'oeuvres' => FKC_Oeuvre::map(), 'flash' => $this->flash(),
		) );
	}
	public function releaseStore() { FKC_Release::create( $_POST ); $this->setFlash( 'Release programmée.' ); redirect( 'royalties/releases' ); }
	public function releaseStatut( $id ) { FKC_Release::setStatut( $id, $_POST['statut'] ?? '' ); $this->setFlash( 'Statut mis à jour.' ); redirect( 'royalties/releases' ); }
	public function releaseDelete( $id ) { FKC_Release::delete( $id ); $this->setFlash( 'Release supprimée.' ); redirect( 'royalties/releases' ); }

	/* ── Plan comptable du secteur ── */
	public function planComptable() {
		if ( ! $this->gate( 'label.plan' ) ) { return; }
		$comptes = FKC_LabelComptable::comptesPlan();
		$secteurs = array_map( array( 'FKC_Secteur', 'meta' ), FKC_Secteur::actifs() );
		FKC_View::render( 'royalties::plan_comptable', array(
			'title' => 'Plan comptable', 'tab' => 'plan',
			'comptes' => $comptes, 'presents' => FKC_LabelComptable::presents(),
			'total' => count( $comptes ), 'secteurs' => $secteurs, 'flash' => $this->flash(),
		) );
	}
	public function planComptableSeed() {
		$n = FKC_LabelComptable::seed();
		$this->setFlash( $n > 0 ? $n . ' compte(s) installé(s) dans le plan comptable.' : 'Le plan comptable du secteur est déjà installé.' );
		redirect( 'royalties/plan-comptable' );
	}

	/* ── Secteur d'activité (terminologie + plan comptable) ── */
	public function secteur() {
		if ( ! $this->gate( 'label.secteur' ) ) { return; }
		FKC_View::render( 'royalties::secteur', array(
			'title' => "Secteur d'activité", 'tab' => 'secteur',
			'familles' => FKC_Secteur::parFamille(), 'actif' => FKC_Secteur::active(),
			'actifs' => FKC_Secteur::actifs(), 'flash' => $this->flash(),
		) );
	}
	public function secteurSave() {
		// Plusieurs secteurs peuvent être cochés (une société cumule
		// souvent plusieurs métiers réels) ; un seul pilote la terminologie.
		$codes = array_map( 'strval', (array) ( $_POST['secteurs'] ?? array() ) );
		$codes = array_values( array_filter( $codes, array( 'FKC_Secteur', 'existe' ) ) );
		$principal = trim( (string) ( $_POST['principal'] ?? '' ) );
		if ( ! $codes && FKC_Secteur::existe( $principal ) ) { $codes = array( $principal ); }
		if ( ! $codes ) { $this->setFlash( 'Choisissez au moins un secteur.' ); redirect( 'royalties/secteur' ); return; }
		if ( ! FKC_Secteur::existe( $principal ) || ! in_array( $principal, $codes, true ) ) {
			// Le principal doit être coché ; à défaut, le premier secteur
			// coché en tient lieu plutôt que de rejeter la sauvegarde.
			$principal = $codes[0];
		}
		FKC_Secteur::setActifs( $codes );
		FKC_Secteur::setActive( $principal );
		$m = FKC_Secteur::meta( $principal );
		$n = count( $codes );
		$this->setFlash(
			1 === $n
				? 'Secteur « ' . $m[1] . " » activé. L'interface et le plan comptable sont adaptés."
				: $n . ' secteurs activés, terminologie sur « ' . $m[1] . ' ». Les comptes des ' . $n . ' secteurs sont proposés au plan comptable.'
		);
		redirect( 'royalties/secteur' );
	}

	/* ── Portail artiste ── */
	public function portail() {
		if ( ! $this->gate( 'label.portail' ) ) { return; }
		$id = (int) ( $_GET['a'] ?? 0 );
		FKC_View::render( 'royalties::portail', array(
			'title' => 'Label · Portail artiste', 'tab' => 'portail',
			'artistes' => FKC_Artiste::all( true ), 'sel' => $id ? FKC_Portail::donnees( $id ) : null,
			'token' => $id ? FKC_Portail::token( $id ) : '', 'statuts' => FKC_Paiement::statuts(), 'flash' => $this->flash(),
		) );
	}

	/* ── helpers ── */
	/* ── Contrats ── */
	public function contrats() {
		if ( ! $this->gate( 'label.artistes' ) ) { return; }
		FKC_View::render( 'royalties::contrats', array(
			'title' => 'Label · Contrats', 'tab' => 'contrats',
			'contrats' => FKC_Contrat::all(), 'artistes' => FKC_Artiste::map(),
			'types' => FKC_Contrat::types(), 'statuts' => FKC_Contrat::statuts(),
			'conso' => FKC_Contrat::count(), 'limit' => FKC_License::limit( 'contrats' ),
			'flash' => $this->flash(),
		) );
	}
	public function contratStore() {
		if ( '' === trim( (string) ( $_POST['reference'] ?? '' ) ) && empty( $_POST['artiste_id'] ) ) { $this->setFlash( 'Indiquez au moins une référence ou un artiste.' ); redirect( 'royalties/contrats' ); }
		if ( ! FKC_License::within( 'contrats', FKC_Contrat::count() ) ) { $this->setFlash( FKC_License::quotaMessage( 'contrats', 'contrat(s)' ) ); redirect( 'royalties/contrats' ); }
		FKC_Contrat::create( $_POST ); $this->setFlash( 'Contrat enregistré.' );
		redirect( 'royalties/contrats' );
	}
	public function contratDelete( $id ) { FKC_Contrat::delete( $id ); $this->setFlash( 'Contrat supprimé.' ); redirect( 'royalties/contrats' ); }

	protected function setFlash( $m ) { $_SESSION['__flash_lbl'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_lbl'] ?? null; unset( $_SESSION['__flash_lbl'] ); return $m; }
}
