<?php
/** Centre de notifications. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_NotificationController {

	public function index() {
		$uid = (int) FKC_Auth::id();
		FKC_View::render( 'notifications::index', array(
			'title'  => 'Notifications',
			'items'  => FKC_Notification::forUser( $uid ),
			'unread' => FKC_Notification::unreadCount( $uid ),
		) );
	}

	/** Marque comme lue puis redirige vers le lien de la notification (ou le centre). */
	public function open( $id ) {
		$uid = (int) FKC_Auth::id();
		$row = FKC_DB::q( 'SELECT * FROM notifications WHERE id=? AND user_id=?', array( (int) $id, $uid ) )->fetch();
		FKC_Notification::markRead( (int) $id, $uid );
		if ( $row && ! empty( $row['url'] ) ) { redirect( ltrim( (string) $row['url'], '/' ) ); }
		redirect( 'notifications' );
	}

	public function markRead( $id ) {
		FKC_Notification::markRead( (int) $id, (int) FKC_Auth::id() );
		redirect( 'notifications' );
	}

	public function markAllRead() {
		FKC_Notification::markAllRead( (int) FKC_Auth::id() );
		redirect( 'notifications' );
	}

	public function delete( $id ) {
		FKC_Notification::delete( (int) $id, (int) FKC_Auth::id() );
		redirect( 'notifications' );
	}
}
