<?php
/**
 * Notifications in-app (centre de notifications). Table « notifications »
 * dans la base de l'entité active, ciblées par utilisateur (cabinet_users.id).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Notification {

	public static function types() {
		return array(
			'info'    => 'Information',
			'succes'  => 'Succès',
			'alerte'  => 'Alerte',
			'tache'   => 'Tâche',
			'validation' => 'Validation',
		);
	}

	/**
	 * Crée une notification pour un utilisateur.
	 *
	 * DEUX PARAMÈTRES AJOUTÉS EN 1.700.0, tous deux optionnels — les dix-neuf
	 * appels existants continuent de fonctionner sans être touchés :
	 *
	 *   $canal  — d'où vient la notification : 'erp' (défaut), 'connect',
	 *             'maestro'. C'est ce qui permet de filtrer sans deviner
	 *             d'après le libellé.
	 *
	 *   $groupe — clé de REGROUPEMENT. Sans elle, dix messages dans le même
	 *             fil donnent dix lignes dans la cloche, et la cloche devient
	 *             un objet qu'on apprend à ignorer. Avec elle, la ligne non
	 *             lue existante est RÉUTILISÉE : son titre est mis à jour et
	 *             elle remonte. Une notification déjà LUE n'est jamais
	 *             recyclée — ce serait faire disparaître l'information que
	 *             l'utilisateur avait justement fini de traiter.
	 */
	public static function create( $userId, $titre, $message = '', $type = 'info', $url = null, $canal = 'erp', $groupe = null ) {
		$userId = (int) $userId;
		if ( $userId <= 0 ) { return 0; }
		$groupe = $groupe ? substr( (string) $groupe, 0, 120 ) : null;
		if ( $groupe ) {
			try {
				$deja = FKC_DB::q(
					'SELECT id FROM notifications WHERE user_id=? AND groupe=? AND lu=0 ORDER BY id DESC LIMIT 1',
					array( $userId, $groupe )
				)->fetchColumn();
				if ( $deja ) {
					FKC_DB::q(
						"UPDATE notifications SET titre=?, message=?, url=?, type=?, created_at=datetime('now','localtime') WHERE id=?",
						array( (string) $titre, (string) $message ?: null, $url ?: null, (string) $type, (int) $deja )
					);
					return (int) $deja;
				}
			} catch ( \Throwable $e ) { /* colonne absente : on insère normalement */ }
		}
		try {
			FKC_DB::q(
				'INSERT INTO notifications(user_id,type,titre,message,url,lu,canal,groupe) VALUES(?,?,?,?,?,0,?,?)',
				array( $userId, (string) $type, (string) $titre, (string) $message ?: null, $url ?: null, (string) $canal, $groupe )
			);
		} catch ( \Throwable $e ) {
			// Base antérieure à la migration : la notification vaut mieux que
			// rien, et le canal se perd sans conséquence fonctionnelle.
			FKC_DB::q(
				'INSERT INTO notifications(user_id,type,titre,message,url,lu) VALUES(?,?,?,?,?,0)',
				array( $userId, (string) $type, (string) $titre, (string) $message ?: null, $url ?: null )
			);
		}
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/** Non-lues d'un canal donné (cloche filtrée, diagnostic). */
	public static function unreadCountCanal( $userId, $canal ) {
		try {
			return (int) FKC_DB::q(
				'SELECT COUNT(*) FROM notifications WHERE user_id=? AND canal=? AND lu=0',
				array( (int) $userId, (string) $canal )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/** Notifie tous les utilisateurs actifs du cabinet (option : exclure un id). */
	public static function notifyAll( $titre, $message = '', $type = 'info', $url = null, $exceptUserId = 0 ) {
		$n = 0;
		if ( ! class_exists( 'FKC_User' ) ) { return 0; }
		foreach ( FKC_User::all() as $u ) {
			if ( empty( $u['actif'] ) ) { continue; }
			if ( $exceptUserId && (int) $u['id'] === (int) $exceptUserId ) { continue; }
			self::create( (int) $u['id'], $titre, $message, $type, $url );
			$n++;
		}
		return $n;
	}

	/** Notifie uniquement les administrateurs actifs. */
	public static function notifyAdmins( $titre, $message = '', $type = 'info', $url = null ) {
		$n = 0;
		if ( ! class_exists( 'FKC_User' ) ) { return 0; }
		foreach ( FKC_User::all() as $u ) {
			if ( empty( $u['actif'] ) || 'admin' !== ( $u['role'] ?? '' ) ) { continue; }
			self::create( (int) $u['id'], $titre, $message, $type, $url );
			$n++;
		}
		return $n;
	}

	public static function forUser( $userId, $limit = 60, $onlyUnread = false ) {
		$limit = (int) $limit;
		$w = $onlyUnread ? ' AND lu=0' : '';
		return FKC_DB::q(
			"SELECT * FROM notifications WHERE user_id=?{$w} ORDER BY id DESC LIMIT {$limit}",
			array( (int) $userId )
		)->fetchAll();
	}

	public static function unreadCount( $userId ) {
		return (int) FKC_DB::q( 'SELECT COUNT(*) FROM notifications WHERE user_id=? AND lu=0', array( (int) $userId ) )->fetchColumn();
	}

	public static function markRead( $id, $userId ) {
		FKC_DB::q( 'UPDATE notifications SET lu=1 WHERE id=? AND user_id=?', array( (int) $id, (int) $userId ) );
	}

	public static function markAllRead( $userId ) {
		FKC_DB::q( 'UPDATE notifications SET lu=1 WHERE user_id=? AND lu=0', array( (int) $userId ) );
	}

	public static function delete( $id, $userId ) {
		FKC_DB::q( 'DELETE FROM notifications WHERE id=? AND user_id=?', array( (int) $id, (int) $userId ) );
	}
}
