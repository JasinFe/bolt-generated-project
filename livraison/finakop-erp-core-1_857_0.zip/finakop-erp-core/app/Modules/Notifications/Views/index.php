<?php /** @var array $items @var int $unread */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ico = array( 'info' => 'ℹ️', 'succes' => '✅', 'alerte' => '⚠️', 'tache' => '📌', 'validation' => '🔑' );
?>
<div class="card card-flush">
	<div class="card-head">
		<h2>Notifications<?= $unread ? ' <span class="tag" style="background:var(--orange);color:#241500">' . (int) $unread . ' non lue(s)</span>' : '' ?></h2>
		<?php if ( $unread ) : ?>
		<form method="post" action="<?= e( url( 'notifications/lu-tout' ) ) ?>" style="margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Tout marquer comme lu</button></form>
		<?php endif; ?>
	</div>
	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer les notifications…' ) ); ?>
	<table class="table"><tbody>
	<?php if ( ! $items ) : ?>
		<tr><td class="empty">Aucune notification.</td></tr>
	<?php else : foreach ( $items as $n ) : ?>
		<tr<?= $n['lu'] ? '' : ' style="background:rgba(243,154,18,.06)"' ?>>
			<td style="width:34px;font-size:18px"><?= $ico[ $n['type'] ] ?? 'ℹ️' ?></td>
			<td>
				<?php if ( ! empty( $n['url'] ) ) : ?>
					<a href="<?= e( url( 'notifications/' . (int) $n['id'] . '/ouvrir' ) ) ?>"><strong><?= e( $n['titre'] ) ?></strong></a>
				<?php else : ?>
					<strong><?= e( $n['titre'] ) ?></strong>
				<?php endif; ?>
				<?php if ( ! empty( $n['message'] ) ) : ?><div class="muted" style="font-size:12.5px"><?= e( $n['message'] ) ?></div><?php endif; ?>
				<div class="muted" style="font-size:11px"><?= e( $n['created_at'] ) ?><?= $n['lu'] ? '' : ' · <span style="color:var(--orange)">non lue</span>' ?></div>
			</td>
			<td class="right" style="white-space:nowrap">
				<?php if ( ! $n['lu'] ) : ?><form method="post" action="<?= e( url( 'notifications/' . (int) $n['id'] . '/lu' ) ) ?>" style="display:inline;margin:0"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" title="Marquer comme lu">✓</button></form><?php endif; ?>
				<form method="post" action="<?= e( url( 'notifications/' . (int) $n['id'] . '/supprimer' ) ) ?>" style="display:inline;margin:0" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" title="Supprimer">&#10005;</button></form>
			</td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody></table>
</div>
