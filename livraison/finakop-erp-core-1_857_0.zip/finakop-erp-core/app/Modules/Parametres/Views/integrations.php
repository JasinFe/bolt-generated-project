<?php /** @var string $title @var string $tab @var array $rapport @var mixed $flash */
/** Audit des intégrations : règles comptables des packs et leurs déclencheurs. */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres', 'backLabel' => 'Paramètres' ) );
$r = $rapport ?? null;
?>
<div class="bar"><span><strong>Audit des intégrations</strong></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres' ) ) ?>">← Paramètres</a></div>

<?php if ( ! empty( $flash ) ) : ?><div class="flash"><?= e( $flash ) ?></div><?php endif; ?>

<?php if ( ! $r ) : ?>
	<div class="card"><div class="card-body"><p class="muted">Audit indisponible sur cette installation.</p></div></div>
<?php else : $pct = $r['total'] ? round( 100 * $r['raccordes'] / $r['total'] ) : 0; ?>

<div class="card"><div class="card-body">
	<p>Chaque pack métier déclare ses règles d'écritures comptables. Une règle n'est utile que si un
	<strong>déclencheur</strong> l'émet : un appel dans le code, ou une action enregistrée. Une règle sans
	déclencheur est correcte et chargée en mémoire, mais ne produira jamais d'écriture.</p>
	<div style="display:flex;gap:24px;flex-wrap:wrap;margin:14px 0">
		<div><div class="muted" style="font-size:12px">Règles déclarées</div><div style="font-size:26px;font-weight:700"><?= (int) $r['total'] ?></div></div>
		<div><div class="muted" style="font-size:12px">Raccordées</div><div style="font-size:26px;font-weight:700;color:#3ddc84"><?= (int) $r['raccordes'] ?></div></div>
		<div><div class="muted" style="font-size:12px">Déjà couvertes</div><div style="font-size:26px;font-weight:700;color:#5aa9ff"><?= (int) $r['couvertes'] ?></div></div>
		<div><div class="muted" style="font-size:12px">Packs sans écran</div><div style="font-size:26px;font-weight:700;color:#9aa7bd"><?= (int) ( $r['sans_ecran'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">À câbler</div><div style="font-size:26px;font-weight:700;color:<?= $r['a_cabler'] ? '#ffb020' : '#3ddc84' ?>"><?= (int) $r['a_cabler'] ?></div></div>
	</div>
	<p style="font-size:13px"><strong>Cinq états, et un seul est un chantier.</strong></p>
	<ul style="font-size:13px;margin:6px 0 10px;padding-left:18px">
		<li><em style="color:#3ddc84">câblée</em> — un déclencheur l'émet. Soit en clair dans le code, soit par la
			<strong>configuration du pack</strong> (clés <code>evt_entree</code> / <code>evt_sortie</code>, émises par le moteur
			de stock commun). Ce second cas échappait à l'analyse : douze règles parfaitement raccordées étaient
			signalées à tort comme du travail restant.</li>
		<li><em style="color:#5aa9ff">déjà couverte</em> — la règle reproduit la forme d'une facture (41x débit TTC,
			7xx crédit HT, TVA). Le module Facturation la produit déjà : la câbler compterait le chiffre d'affaires
			et la TVA en double.</li>
		<li><em style="color:#5aa9ff">doublon</em> — la règle meut exactement les mêmes comptes qu'une autre règle du
			même pack, déjà câblée. Même conséquence : une seconde écriture pour une seule opération.</li>
		<li><em style="color:#9aa7bd">pack sans écran</em> — le pack ne déclare que des schémas comptables : ni
			contrôleur, ni modèle, ni route. Il n'existe rien pour déclencher la règle. Ce n'est pas un câblage oublié,
			c'est un module métier qui reste à écrire — les ranger ensemble donnait une liste de travaux trompeuse,
			où un oubli de deux lignes voisinait avec un chantier entier.</li>
		<li><em style="color:#ffb020">à câbler</em> — le pack est implémenté, la règle décrit une opération qu'aucun
			moteur générique ne produit, et rien ne l'émet. C'est le seul vrai chantier.</li>
	</ul>
	<p class="muted" style="font-size:12px;margin:0">Écran en lecture seule : aucune écriture n'est générée, aucune donnée modifiée.
	Les packs ayant de vraies règles à câbler apparaissent en premier.</p>
</div></div>

<?php if ( ! empty( $r['familles'] ) ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Chantiers par famille métier</h2></div><div class="card-body">
	<p class="muted" style="font-size:13px">Les métiers d'une même famille partagent leurs moments de déclenchement — une officine
	et un cabinet médical encaissent de façon comparable. Câbler famille par famille est donc plus sûr que pack par pack.</p>
	<table class="table"><thead><tr><th>Famille</th><th>Packs</th><th>À câbler</th><th>Sans écran</th><th>Déjà couvertes</th><th>Total</th></tr></thead><tbody>
	<?php foreach ( $r['familles'] as $f ) : $c = $f['total'] ? round( 100 * $f['raccordes'] / $f['total'] ) : 0; ?>
		<tr>
			<td><strong><?= e( $f['label'] ) ?></strong></td>
			<td class="muted"><?= count( $f['packs'] ) ?></td>
			<td style="color:<?= $f['a_cabler'] ? '#ffb020' : '#3ddc84' ?>;font-weight:700"><?= (int) $f['a_cabler'] ?></td>
			<td class="muted" style="color:#9aa7bd"><?= (int) ( $f['sans_ecran'] ?? 0 ) ?></td>
			<td class="muted" style="color:#5aa9ff"><?= (int) $f['couvertes'] ?></td>
			<td class="muted"><?= (int) $f['total'] ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody></table>
</div></div>
<?php endif; ?>

<?php foreach ( $r['packs'] as $pack => $d ) :
	$couleur = 0 === $d['a_cabler'] ? '#3ddc84' : '#ffb020'; ?>
	<div class="card" style="margin-top:12px"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
		<h2 style="margin:0"><?= e( $pack ) ?></h2>
		<span style="color:<?= $couleur ?>;font-weight:600"><?= (int) $d['a_cabler'] ?> à câbler · <?= (int) $d['couvertes'] ?> couverte(s) · <?= (int) $d['raccordes'] ?> câblée(s)</span>
	</div><div class="card-body">
		<table class="table"><thead><tr>
			<th>Événement comptable</th><th>État</th><th>Déclencheur</th><th>Déjà observé</th>
		</tr></thead><tbody>
		<?php foreach ( $d['lignes'] as $l ) : ?>
			<tr>
				<td><code><?= e( $l['evenement'] ) ?></code></td>
				<td><?php
					switch ( $l['statut'] ) {
						case 'cablee':     echo '<span style="color:#3ddc84">✔ câblée</span>'; break;
						case 'couverte':   echo '<span style="color:#5aa9ff">↩ déjà couverte</span>'; break;
						case 'doublon':    echo '<span style="color:#5aa9ff">⧉ doublon</span>'; break;
						case 'sans_ecran': echo '<span style="color:#9aa7bd">◌ pack sans écran</span>'; break;
						case 'manuelle':   echo '<span style="color:#5aa9ff">✎ saisie assistée</span>'; break;
						default:           echo '<span style="color:#ffb020">⏸ à câbler</span>';
					}
				?></td>
				<td class="muted" style="font-size:12px">
					<?php if ( 'code' === $l['origine'] ) : ?>
						<?= e( implode( ', ', array_slice( $l['fichiers'], 0, 2 ) ) ) ?>
					<?php elseif ( 'action' === $l['origine'] ) : ?>
						action enregistrée
					<?php elseif ( 'configuration' === $l['origine'] ) : ?>
						<?= e( implode( ', ', array_slice( $l['fichiers'], 0, 1 ) ) ) ?> <em>(evt_* du pack)</em>
					<?php elseif ( 'couverte' === $l['statut'] ) : ?>
						<em>module Facturation (compte porté par la ligne)</em>
					<?php elseif ( 'doublon' === $l['statut'] ) : ?>
						<em>même écriture que <code><?= e( (string) $l['doublon'] ) ?></code>, déjà câblée</em>
					<?php elseif ( 'manuelle' === $l['statut'] ) : ?>
						<em>règle générique : les modules Facturation, Règlements et Paie produisent déjà ces écritures.
						Disponible à la main pour ce qu'ils ne couvrent pas.</em>
					<?php elseif ( 'sans_ecran' === $l['statut'] ) : ?>
						<em>pack déclaré sans module métier — rien pour la déclencher</em>
					<?php else : ?>
						<em>aucun — opération non exprimable par une facture</em>
					<?php endif; ?>
				</td>
				<td class="muted" style="font-size:12px"><?= $l['observe'] ? 'oui' : '—' ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody></table>
	</div></div>
<?php endforeach; ?>
<?php endif; ?>
