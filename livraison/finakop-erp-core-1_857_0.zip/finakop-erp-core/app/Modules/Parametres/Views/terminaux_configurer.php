<?php
/**
 * PARAMÈTRES → TERMINAUX → CONFIGURER UNE BORNE (Phase 3, lot 3 — 1.820.0).
 *
 * Horaires d'ouverture, rubriques affichées, et l'APERÇU de la borne telle
 * qu'elle s'affiche — sans l'appairer, sans rien envoyer.
 *
 * @var array $t @var array $horaires @var array $ouverture @var array $jours
 * @var array $rubriquesPack [rubrique => nb] @var array $rubriques @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcBase = 'parametres/terminaux/' . (int) $t['id'];
$fkcClient = ! in_array( (string) $t['type'], array( 'affichage', 'cuisine', 'preparation' ), true );
?>
<div class="page-stack" style="max-width:1300px">

<p style="margin:0"><a href="<?= e( url( 'parametres/terminaux' ) ) ?>">← Terminaux</a></p>

<?php if ( $flash ) : ?>
	<div class="alert alert-<?= 'ok' === $flash['type'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:minmax(320px,440px) 1fr;gap:16px;align-items:start">
<div style="display:grid;gap:16px">

	<div class="card">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px">
			<h2>🕘 Horaires · <?= e( $t['nom'] ) ?></h2>
			<span class="tag" style="<?= $ouverture['ouvert'] ? 'color:var(--ok)' : 'color:var(--danger)' ?>"><?= $ouverture['ouvert'] ? 'ouverte' : 'fermée' ?></span>
		</div>
		<div class="card-body">
			<p class="help" style="margin-top:0">Hors de ces plages, la borne affiche <strong>« Fermé — nous rouvrons … »</strong> et le serveur refuse toute commande. Sans horaires, elle est toujours ouverte. Une plage qui finit avant de commencer (18:00 → 02:00) passe minuit.</p>
			<form method="post" action="<?= e( url( $fkcBase . '/configurer' ) ) ?>" style="display:grid;gap:10px"><?= FKC_Csrf::field() ?>
				<input type="hidden" name="action" value="horaires">
				<label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" name="horaires_actifs" value="1" style="width:auto;flex:none;margin:0" <?= $horaires['actif'] ? 'checked' : '' ?>> Appliquer ces horaires</label>
				<div style="display:grid;gap:6px">
				<?php foreach ( $jours as $j => $lib ) : $p = $horaires['jours'][ $j ] ?? null; ?>
					<div style="display:grid;grid-template-columns:104px minmax(0,1fr) 14px minmax(0,1fr);gap:6px;align-items:center">
						<label style="display:flex;gap:6px;align-items:center;margin:0"><input type="checkbox" name="jours[<?= (int) $j ?>][ouvert]" value="1" style="width:auto;flex:none;margin:0" <?= $p ? 'checked' : '' ?>> <?= e( $lib ) ?></label>
						<input type="time" name="jours[<?= (int) $j ?>][de]" value="<?= e( $p['de'] ?? '08:00' ) ?>" aria-label="<?= e( $lib ) ?> : ouverture" style="width:100%;min-width:0">
						<span class="muted" style="text-align:center">→</span>
						<input type="time" name="jours[<?= (int) $j ?>][a]" value="<?= e( $p['a'] ?? '22:00' ) ?>" aria-label="<?= e( $lib ) ?> : fermeture" style="width:100%;min-width:0">
					</div>
				<?php endforeach; ?>
				</div>
				<?php if ( '' !== (string) $ouverture['libelle'] ) : ?><p class="muted" style="margin:0;font-size:12px">Maintenant : <?= e( $ouverture['libelle'] ) ?></p><?php endif; ?>
				<button class="btn btn-primary">Enregistrer les horaires</button>
			</form>
		</div>
	</div>

	<?php if ( $fkcClient ) : ?>
	<div class="card">
		<div class="card-head"><h2>🗂️ Rubriques affichées</h2></div>
		<div class="card-body">
			<?php if ( ! $rubriquesPack ) : ?>
				<p class="muted" style="margin:0">Le catalogue de ce métier n'a pas encore de rubriques.</p>
			<?php else : ?>
				<p class="help" style="margin-top:0">Une borne du bar ne montre que les boissons, celle de la terrasse toute la carte… Seules les rubriques cochées s'affichent — et <strong>se commandent</strong> : le serveur refuse le reste. Tout cocher = tout le catalogue, y compris les rubriques ajoutées plus tard.</p>
				<form method="post" action="<?= e( url( $fkcBase . '/configurer' ) ) ?>" style="display:grid;gap:8px"><?= FKC_Csrf::field() ?>
					<input type="hidden" name="action" value="rubriques">
					<?php foreach ( $rubriquesPack as $r => $n ) : ?>
						<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="rubriques[]" value="<?= e( $r ) ?>" style="width:auto;flex:none;margin:0" <?= ! $rubriques || in_array( $r, $rubriques, true ) ? 'checked' : '' ?>>
							<?= e( $r ) ?> <span class="muted" style="font-size:12px">(<?= (int) $n ?>)</span></label>
					<?php endforeach; ?>
					<button class="btn btn-primary" style="margin-top:6px">Enregistrer les rubriques</button>
				</form>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>

	<div class="card"><div class="card-body" style="display:flex;gap:8px;flex-wrap:wrap">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/terminaux/apparence' ) ) ?>">🎨 Apparence des bornes</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/terminaux/promos' ) ) ?>">📣 Contenus promotionnels</a>
	</div></div>
</div>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
		<h2>👁️ Aperçu de la borne</h2>
		<?php if ( $fkcClient ) : ?>
		<span style="display:flex;gap:6px;flex-wrap:wrap">
			<button type="button" class="btn btn-ghost btn-sm" data-fmt="1280x800">Tablette paysage</button>
			<button type="button" class="btn btn-ghost btn-sm" data-fmt="800x1280">Tablette portrait</button>
			<button type="button" class="btn btn-ghost btn-sm" data-fmt="390x844">Téléphone</button>
			<a class="btn btn-ghost btn-sm" id="fkc-ap-ferme" href="#">Voir « Fermé »</a>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( $fkcBase . '/apercu' ) ) ?>" target="_blank" rel="noopener">Plein écran ↗</a>
		</span>
		<?php endif; ?>
	</div>
	<?php if ( $fkcClient ) : ?>
		<div id="fkc-ap-cadre" style="padding:14px;background:var(--panel2);overflow:hidden;display:flex;justify-content:center">
			<div id="fkc-ap-boite" style="position:relative;overflow:hidden;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.35)">
				<iframe id="fkc-ap" title="Aperçu de la borne" src="<?= e( url( $fkcBase . '/apercu' ) ) ?>" style="border:0;display:block;transform-origin:0 0"></iframe>
			</div>
		</div>
		<p class="help" style="padding:0 16px 14px;margin:0">L'aperçu est la page réelle de la borne, avec vos réglages enregistrés. Le parcours se teste jusqu'au bout ; <strong>rien n'est envoyé</strong>.</p>
	<?php else : ?>
		<div class="card-body"><p class="muted" style="margin:0">L'aperçu est proposé pour les bornes client. Cet écran (<?= e( FKC_Terminal::typeLabel( $t['type'] ) ) ?>) n'affiche pas de carte.</p></div>
	<?php endif; ?>
</div>
</div>
</div>
<?php if ( $fkcClient ) : ?>
<script>
/* Aperçu à l'échelle : la borne est rendue à sa taille réelle, puis réduite pour tenir dans la colonne. */
(function () {
	var cadre = document.getElementById('fkc-ap-cadre'), boite = document.getElementById('fkc-ap-boite'), fr = document.getElementById('fkc-ap');
	var base = fr.getAttribute('src'), fmt = [1280, 800];
	function ajuster() {
		var dispo = cadre.clientWidth - 28, k = Math.min(1, dispo / fmt[0], 720 / fmt[1]);
		fr.style.width = fmt[0] + 'px'; fr.style.height = fmt[1] + 'px'; fr.style.transform = 'scale(' + k + ')';
		boite.style.width = Math.round(fmt[0] * k) + 'px'; boite.style.height = Math.round(fmt[1] * k) + 'px';
	}
	document.querySelectorAll('[data-fmt]').forEach(function (b) {
		b.addEventListener('click', function () { fmt = b.getAttribute('data-fmt').split('x').map(Number); ajuster(); });
	});
	var f = document.getElementById('fkc-ap-ferme'), ferme = false;
	f.addEventListener('click', function (e) {
		e.preventDefault(); ferme = !ferme;
		fr.setAttribute('src', base + (ferme ? '?etat=ferme' : ''));
		f.textContent = ferme ? 'Voir « Ouvert »' : 'Voir « Fermé »';
	});
	window.addEventListener('resize', ajuster);
	ajuster();
}());
</script>
<?php endif; ?>
