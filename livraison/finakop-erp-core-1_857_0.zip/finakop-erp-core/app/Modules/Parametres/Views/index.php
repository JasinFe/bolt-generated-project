<?php /** @var array $groups @var array $license @var array|null $societe @var array $masques */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'backLabel' => 'Accueil' ) ); // cet écran n'avait aucune sortie hors bouton du navigateur
 ?>

<div class="dash-head">
	<div class="dash-head-main">
		<span class="dash-head-ico">⚙️</span>
		<div>
			<h1 class="dash-title">Paramètres</h1>
			<p class="dash-sub">Réglages et personnalisations<?php if ( $societe ) : ?> — <strong><?= e( $societe['raison_sociale'] ) ?></strong><?php endif; ?> · Édition <?= e( $license['profile_label'] ?: '—' ) ?></p>
		</div>
	</div>
</div>

<?php
/* ── Modules retirés du menu ──────────────────────────────────────────────
   Un module masqué disparaît de la barre latérale — et avec lui le réglage qui
   permet de le rétablir, puisqu'il vivait à l'intérieur. On ne pouvait y revenir
   qu'en saisissant l'adresse de mémoire. Le voici dans un écran qui, lui, ne se
   masque jamais. */
$masques = isset( $masques ) && is_array( $masques ) ? $masques : array();
?>
<?php if ( $masques ) : ?>
<div class="param-group">
	<div class="nav-sep" style="margin:0 0 10px">Modules retirés du menu</div>
	<div class="card"><div class="card-body">
		<p class="help" style="margin-top:0">
			Ces modules sont volontairement absents de la barre latérale. Leurs données sont intactes et continuent
			d'être alimentées : seul l'accès direct au menu a été retiré.
		</p>
		<?php foreach ( $masques as $code => $m ) : ?>
			<div style="display:flex;gap:12px;align-items:flex-start;padding:12px 0;border-top:1px solid var(--line)">
				<span style="font-size:22px"><?= e( $m['icon'] ) ?></span>
				<div style="flex:1">
					<strong><?= e( $m['label'] ) ?></strong>
					<div class="muted" style="font-size:13px;margin-top:2px"><?= e( $m['raison'] ) ?></div>
				</div>
				<form method="post" action="<?= e( $m['action'] ) ?>">
					<?= FKC_Csrf::field() ?>
					<button class="btn btn-primary btn-sm">Réafficher dans le menu</button>
				</form>
			</div>
		<?php endforeach; ?>
	</div></div>
</div>
<?php endif; ?>

<?php foreach ( $groups as $titre => $items ) : ?>
	<div class="param-group">
		<div class="nav-sep" style="margin:0 0 10px"><?= e( $titre ) ?></div>
		<div class="param-grid">
			<?php foreach ( $items as $it ) : ?>
				<a class="param-card" href="<?= e( $it['url'] ) ?>">
					<span class="param-ico"><?= e( $it['icon'] ) ?></span>
					<span class="param-body">
						<span class="param-titre"><?= e( $it['titre'] ) ?></span>
						<span class="param-desc"><?= e( $it['desc'] ) ?></span>
					</span>
					<span class="param-arrow">→</span>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
<?php endforeach; ?>

<style>
.param-group{margin-bottom:22px}
.param-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:13px}
.param-card{display:flex;align-items:flex-start;gap:13px;background:var(--panel);border:1px solid var(--line);border-radius:13px;padding:16px 17px;transition:.12s}
.param-card:hover{border-color:var(--orange);transform:translateY(-2px)}
.param-ico{font-size:22px;flex-shrink:0;width:42px;height:42px;border-radius:11px;background:var(--bg2);border:1px solid var(--line2);display:flex;align-items:center;justify-content:center}
.param-body{flex:1;min-width:0;display:flex;flex-direction:column}
.param-titre{font-family:Syne,sans-serif;font-weight:800;font-size:15px}
.param-desc{font-size:12.5px;color:var(--muted);margin-top:4px;line-height:1.4}
.param-arrow{color:var(--muted2);font-size:18px;align-self:center}
.param-card:hover .param-arrow{color:var(--orange)}
</style>
