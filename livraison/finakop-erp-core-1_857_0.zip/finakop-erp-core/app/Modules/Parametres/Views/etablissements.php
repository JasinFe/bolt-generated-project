<?php /** @var array $etablissements @var int $conso @var int $limit @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( '_modnav', array( 'module' => '', 'back' => 'parametres', 'backLabel' => 'Paramètres' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-rows">
	<div class="card"><div class="card-head"><h2>Nouvel établissement</h2></div><div class="card-body">
		<?php if ( (int) $limit >= 0 ) : ?><p class="help">Quota du palier : <strong><?= (int) $conso ?> / <?= (int) $limit ?></strong> établissement(s).</p><?php endif; ?>
		<form method="post" action="<?= e( url( 'parametres/etablissements' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Code *</span><input name="code" required maxlength="20" placeholder="ETB-ABJ"></label>
			<label class="fld"><span>Libellé *</span><input name="libelle" required placeholder="Agence Abidjan-Plateau"></label>
			<label class="fld"><span>Adresse</span><input name="adresse"></label>
			<label class="fld"><input type="checkbox" name="principal" value="1"> Établissement principal (siège)</label>
			<div class="actions"><button class="btn btn-primary">Créer</button></div>
		</form>
	</div></div>
	<div class="card card-flush" style="grid-column:span 2"><div class="card-head"><h2>Établissements (<?= count( $etablissements ) ?>)</h2></div>
		<table class="table"><thead><tr><th>Code</th><th>Libellé</th><th>Adresse</th><th>Type</th><th></th></tr></thead><tbody>
		<?php if ( ! $etablissements ) : ?><tr><td colspan="5" class="empty">Aucun établissement.</td></tr>
		<?php else : foreach ( $etablissements as $x ) : ?><tr>
			<td><strong><?= e( $x['code'] ) ?></strong></td><td><?= e( $x['libelle'] ) ?></td><td><?= e( $x['adresse'] ?: '—' ) ?></td>
			<td><?php if ( $x['principal'] ) : ?><span class="tag">Principal</span><?php else : ?>Secondaire<?php endif; ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'parametres/etablissements/' . (int) $x['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button></form></td>
		</tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
