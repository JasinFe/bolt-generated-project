<?php /** @var string $title @var array $terminaux @var array $types @var array $modes @var array $themes @var array $packsEquipes @var string $packActif @var array|null $flash @var int $nouveau */ ?>
<div class="page-stack" style="max-width:1000px">

<?php if ( $flash ) : ?>
	<div class="alert alert-<?= 'ok' === $flash['type'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div>
<?php endif; ?>

<?php
/*
 * LE CODE EST AFFICHÉ EN GRAND, UNE FOIS, JUSTE APRÈS SA CRÉATION.
 * Il se dicte à voix haute à quelqu'un qui tient une tablette à l'autre bout
 * de la salle : le cacher derrière un clic ou le composer en petits
 * caractères ferait rater l'appairage une fois sur deux.
 */
$vedette = null;
foreach ( $terminaux as $t ) { if ( (int) $t['id'] === (int) $nouveau ) { $vedette = $t; } }
if ( $vedette && FKC_Terminal::codeValide( $vedette ) ) : ?>
	<div class="card">
		<div class="card-head"><h2>Code d'appairage · <?= e( $vedette['nom'] ) ?></h2></div>
		<div class="card-body" style="text-align:center">
			<?php
			/*
			 * L'ADRESSE EST DONNÉE EN ENTIER, ET AVEC SON QR.
			 *
			 * Première question posée en découvrant l'écran : « comment
			 * j'ouvre ça sur la tablette ? ». `url()` rend un chemin relatif,
			 * inutilisable sur un autre appareil : il faut l'adresse ABSOLUE,
			 * celle qu'on tape dans un navigateur à l'autre bout de la salle.
			 * Et comme personne n'aime taper une adresse sur une tablette,
			 * le QR la porte — appairage compris, ce qui évite aussi de
			 * saisir le code.
			 */
			$fkcUrlTerm = function_exists( 'abs_url' ) ? abs_url( 'terminal' ) : url( 'terminal' );
			$fkcUrlApp  = $fkcUrlTerm . '?c=' . rawurlencode( FKC_Terminal::codeComplet( $vedette ) );
			$fkcQr = '';
			if ( class_exists( 'FKC_Barcode' ) ) {
				try { $fkcQr = FKC_Barcode::qr( $fkcUrlApp, array( 'taille' => 180 ) ); } catch ( \Throwable $e ) {}
			}
			?>
			<p class="help" style="margin-top:0">Sur la tablette, ouvrez cette adresse dans le navigateur :</p>
			<p style="font-size:17px;margin:8px 0 18px"><code><?= e( $fkcUrlTerm ) ?></code></p>

			<?php if ( $fkcQr ) : ?>
				<div style="margin:0 auto 14px;width:180px"><?= $fkcQr /* SVG généré localement */ ?></div>
				<p class="help" style="margin-top:0">
					Ou scannez ce code avec l'appareil photo de la tablette : il ouvre l'adresse
					<strong>et saisit le code</strong> — rien à taper.
				</p>
			<?php endif; ?>

			<p class="help" style="margin-bottom:4px">Si vous préférez le dicter :</p>
			<p style="font-family:ui-monospace,Menlo,Consolas,monospace;font-size:34px;letter-spacing:.1em;margin:6px 0 14px">
				<?= e( FKC_Terminal::codeComplet( $vedette ) ) ?>
			</p>
			<?php if ( ! empty( $vedette['code_auto'] ) ) : ?>
				<script>
				/*
				 * LA PAGE SE RECHARGE JUSTE AVANT L'EXPIRATION (1.727.0), ce
				 * qui fait réattribuer un code côté serveur. On recharge une
				 * minute AVANT la fin, jamais après : un code affiché mais
				 * déjà mort est pire qu'un code absent, car on le saisit.
				 */
				setTimeout(function () { location.reload(); },
					<?= (int) max( 60, FKC_Terminal::CODE_MINUTES * 60 - 60 ) ?> * 1000);
				</script>
			<?php endif; ?>
			<p class="help" style="margin-bottom:0">
				Valable <?= (int) FKC_Terminal::CODE_MINUTES ?> minutes, pour autant d'appareils que le terminal a de places libres
				(<?= (int) FKC_Terminal::maxAppareils( $vedette ) ?> au plus).
				Le numéro en tête est celui de votre établissement : sans lui, l'appareil ne saurait pas où se connecter.
				<br>La tablette doit être sur le <strong>même réseau ou sur Internet</strong>, comme pour n'importe quel site :
				c'est votre serveur qui répond, pas la tablette.
			</p>
		</div>
	</div>
<?php endif; ?>

<div class="card">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><h2>Terminaux déclarés</h2>
		<?php /* Phase 3 (1.814.0) : ce que les bornes mettent en avant. */ ?>
		<span style="display:flex;gap:6px;flex-wrap:wrap">
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/terminaux/apparence' ) ) ?>">🎨 Apparence des bornes</a>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/terminaux/promos' ) ) ?>">📣 Contenus promotionnels<?php $fkcNP = class_exists( 'FKC_TerminalPromo' ) ? count( array_filter( FKC_TerminalPromo::tous(), array( 'FKC_TerminalPromo', 'enCours' ) ) ) : 0; ?><?= $fkcNP ? ' · ' . $fkcNP . ' à l\'écran' : '' ?></a>
		</span>
	</div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Un terminal est un appareil — tablette de comptoir, borne, écran d'atelier — associé à cet établissement
			par un code. <strong>Il ne voit jamais votre gestion :</strong> selon son type, il n'a accès qu'au catalogue
			public, aux demandes qu'il ouvre lui-même et à leur avancement. Une demande venue d'un terminal arrive
			<strong>en brouillon</strong> : c'est vous qui l'acceptez, et c'est votre geste qui produit la pièce.
		</p>
		<?php if ( ! $terminaux ) : ?>
			<p class="muted">Aucun terminal déclaré.</p>
		<?php else : ?>
		<table class="table">
			<thead><tr><th>Nom</th><th>Type</th><th>Pack</th><th>Emplacement</th><th>Appareils</th><th>État</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $terminaux as $t ) : ?>
				<tr>
					<td><?= e( $t['nom'] ) ?><?php if ( 'lecture' === (string) $t['mode'] ) : ?> <span class="tag">lecture seule</span><?php endif; ?></td>
					<td><?= e( FKC_Terminal::typeLabel( $t['type'] ) ) ?></td>
					<td class="code"><?= e( $t['pack'] ) ?></td>
					<td><?= e( (string) ( $t['emplacement'] ?? '' ) ) ?></td>
					<?php
					/*
					 * COMBIEN D'ÉCRANS, ET LESQUELS (1.736.0).
					 *
					 * Un terminal ne servait qu'un appareil : la colonne
					 * « État » disait « associé », et c'était tout ce qu'il y
					 * avait à dire. Maintenant qu'une même configuration peut
					 * équiper une salle entière, l'exploitant a besoin de
					 * savoir combien d'écrans en vivent, lesquels répondent
					 * encore, et d'en débrancher UN sans couper les autres.
					 */
					$fkcSess = FKC_Terminal::sessions( (int) $t['id'] );
					$fkcMax  = (int) ( $t['max_appareils'] ?? FKC_Terminal::MAX_APPAREILS_DEFAUT );
					$fkcHerite = ( ! $fkcSess && ! empty( $t['jeton'] ) ); // appairé avant 1.736.0
					?>
					<td>
						<form method="post" action="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/appareils' ) ) ?>"
							style="display:flex;gap:6px;align-items:center">
							<?= FKC_Csrf::field() ?>
							<strong><?= count( $fkcSess ) + ( $fkcHerite ? 1 : 0 ) ?></strong>
							<span class="muted">/</span>
							<input type="number" name="max" min="0" max="999" value="<?= $fkcMax ?>"
								style="width:68px" title="0 = sans limite">
							<button class="btn btn-ghost btn-sm">OK</button>
						</form>
						<?php if ( $fkcSess ) : ?>
							<ul style="margin:6px 0 0;padding-left:16px;font-size:13px">
							<?php foreach ( $fkcSess as $fkcS ) : ?>
								<li>
									<?= e( (string) ( $fkcS['appareil'] ?? 'Appareil' ) ) ?>
									<?php if ( ! empty( $fkcS['dernier_contact'] ) ) : ?>
										<span class="muted">· <?= e( date( 'd/m H:i', strtotime( (string) $fkcS['dernier_contact'] ) ) ) ?></span>
									<?php endif; ?>
									<form method="post" style="display:inline"
										action="<?= e( url( 'parametres/terminaux/appareil/' . (int) $fkcS['id'] . '/revoquer' ) ) ?>"
										onsubmit="return confirm('Déconnecter cet appareil ? Les autres écrans de ce terminal ne sont pas touchés.')">
										<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">✕</button>
									</form>
								</li>
							<?php endforeach; ?>
							</ul>
						<?php elseif ( $fkcHerite ) : ?>
							<span class="muted" style="font-size:13px">1 appareil associé avant la mise à jour</span>
						<?php endif; ?>
					</td>
					<td>
						<?php if ( empty( $t['actif'] ) ) : ?>
							<span class="muted">révoqué</span>
						<?php elseif ( $fkcSess || $fkcHerite ) : ?>
							associé<?php if ( ! empty( $t['dernier_contact'] ) ) : ?>
								<span class="muted">· vu le <?= e( date( 'd/m/Y H:i', strtotime( (string) $t['dernier_contact'] ) ) ) ?></span>
							<?php endif; ?>
						<?php elseif ( FKC_Terminal::codeValide( $t ) ) : ?>
							<span class="muted">code en attente</span>
						<?php else : ?>
							<span class="muted">à associer</span>
						<?php endif; ?>
					</td>
					<td style="text-align:right;white-space:nowrap">
						<?php if ( ! empty( $t['actif'] ) ) : ?>
							<?php
							/*
							 * L'INTERRUPTEUR S'AFFICHE TANT QU'IL RESTE UNE
							 * PLACE (1.736.0).
							 *
							 * On le masquait dès qu'un appareil était associé,
							 * parce qu'il n'avait alors plus d'effet. Ce n'est
							 * plus vrai : une salle de cinq écrans à qui l'on
							 * veut en ajouter un sixième a besoin d'un code
									 * frais. Sur un terminal COMPLET, en revanche, le
							 * réglage ne ferait toujours rien — et on ne
							 * propose pas un réglage qui ne fait rien.
							 */
							if ( count( $fkcSess ) + ( $fkcHerite ? 1 : 0 ) < FKC_Terminal::maxAppareils( $t ) ) : ?>
								<form method="post" action="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/code-auto' ) ) ?>" style="display:inline">
									<?= FKC_Csrf::field() ?>
									<input type="hidden" name="actif" value="<?= empty( $t['code_auto'] ) ? 1 : 0 ?>">
									<button class="btn btn-ghost btn-sm" title="Un code valable reste affiché tant que l'appareil n'est pas associé">
										<?= empty( $t['code_auto'] ) ? 'Renouvellement auto : off' : 'Renouvellement auto : on' ?>
									</button>
								</form>
							<?php endif; ?>
							<form method="post" action="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/code' ) ) ?>" style="display:inline">
								<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Nouveau code</button>
							</form>
							<form method="post" action="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/revoquer' ) ) ?>" style="display:inline"
								onsubmit="return confirm('Révoquer ce terminal ? TOUS ses appareils seront déconnectés immédiatement.')">
								<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Révoquer</button>
							</form>
							<?php /* RÉGLAGES (1.806.0) — tout ce qui se corrige sans réappairer la salle. */ ?>
							<?php $fkcR = FKC_Terminal::reglages( $t ); ?>
							<?php /* 1.820.0 : horaires, rubriques et aperçu de la borne. */ ?>
							<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/configurer' ) ) ?>">Configurer</a>
							<details style="display:inline-block;position:relative;text-align:left;vertical-align:top">
								<summary class="btn btn-ghost btn-sm" style="list-style:none">Réglages</summary>
								<form method="post" action="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/reglages' ) ) ?>"
									style="position:absolute;right:0;z-index:5;background:var(--surface,#fff);border:1px solid rgba(0,0,0,.12);
									border-radius:10px;padding:16px;margin-top:6px;width:min(460px,90vw);box-shadow:0 12px 30px rgba(0,0,0,.14);white-space:normal">
									<?= FKC_Csrf::field() ?>
									<div class="form-grid">
										<label class="fld"><span>Nom</span>
											<input type="text" name="nom" value="<?= e( $t['nom'] ) ?>" required maxlength="80"></label>
										<label class="fld"><span>Emplacement</span>
											<input type="text" name="emplacement" value="<?= e( (string) ( $t['emplacement'] ?? '' ) ) ?>"></label>
										<label class="fld"><span>Mode</span>
											<select name="mode">
												<?php foreach ( $modes as $code => $lib ) : ?>
													<option value="<?= e( $code ) ?>" <?= (string) $t['mode'] === $code ? 'selected' : '' ?>><?= e( $lib ) ?></option>
												<?php endforeach; ?>
											</select></label>
										<label class="fld"><span>Thème</span>
											<select name="theme">
												<?php foreach ( $themes as $code => $lib ) : ?>
													<option value="<?= e( $code ) ?>" <?= $fkcR['theme'] === $code ? 'selected' : '' ?>><?= e( $lib ) ?></option>
												<?php endforeach; ?>
											</select></label>
										<label class="fld"><span>Couleur de l'établissement</span>
											<input type="color" name="accent" value="<?= e( $fkcR['accent'] ?: FKC_TerminalTheme::ACCENT_DEFAUT ) ?>"></label>
										<label class="fld-check">
											<input type="checkbox" name="accent_perso" value="1" <?= $fkcR['accent'] ? 'checked' : '' ?>>
											<span>Remplacer l'orange FinaKop par cette couleur (le bleu roi FinaKop reste)</span></label>
										<label class="fld"><span>Remise à zéro après inactivité (s, 0 = jamais)</span>
											<input type="number" name="delai_inactivite" min="0" max="<?= (int) FKC_Terminal::DELAI_INACTIVITE_MAX ?>"
												value="<?= (int) $fkcR['delai_inactivite'] ?>"></label>
										<label class="fld-check">
											<input type="checkbox" name="attract" value="1" <?= $fkcR['attract'] ? 'checked' : '' ?>>
											<span>Écran d'attente après inactivité</span></label>
										<label class="fld" style="grid-column:1/-1"><span>Message de l'écran d'attente</span>
											<input type="text" name="message_accueil" maxlength="140" value="<?= e( $fkcR['message_accueil'] ) ?>"
												placeholder="Bienvenue — touchez l'écran pour commencer"></label>
									</div>
									<p class="help" style="margin:8px 0">Le type et le pack ne se changent pas ici : ils fixent les droits du jeton déjà distribué.
									Pour les modifier, révoquez puis déclarez un nouveau terminal.</p>
									<button class="btn btn-primary btn-sm">Enregistrer</button>
								</form>
							</details>
						<?php else : ?>
							<form method="post" action="<?= e( url( 'parametres/terminaux/' . (int) $t['id'] . '/reactiver' ) ) ?>" style="display:inline">
								<?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Réactiver</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Ajouter un terminal</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'parametres/terminaux' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid">
				<label class="fld"><span>Nom</span>
					<input type="text" name="nom" placeholder="Accueil Studio" required></label>
				<label class="fld"><span>Type</span>
					<select name="type">
						<?php foreach ( $types as $code => $d ) : ?>
							<option value="<?= e( $code ) ?>"><?= e( $d['label'] ) ?></option>
						<?php endforeach; ?>
					</select></label>
				<?php $__caisses = array(); try { $__caisses = FKC_DB::q( 'SELECT id, libelle FROM caisses WHERE actif=1 ORDER BY libelle' )->fetchAll(); } catch ( \Throwable $e ) {} ?>
				<?php if ( $__caisses ) : ?>
				<label class="fld"><span>Poste de caisse (écran client de caisse)</span>
					<select name="caisse_id"><option value="">—</option>
						<?php foreach ( $__caisses as $__c ) : ?><option value="<?= (int) $__c['id'] ?>"><?= e( $__c['libelle'] ) ?></option><?php endforeach; ?>
					</select></label>
				<?php endif; ?>
				<label class="fld"><span>Pack métier</span>
					<input type="text" name="pack" value="<?= e( $packActif ) ?>"></label>
				<label class="fld"><span>Emplacement</span>
					<input type="text" name="emplacement" placeholder="Hall d'entrée"></label>
				<label class="fld"><span>Mode</span>
					<select name="mode">
						<?php foreach ( $modes as $code => $lib ) : ?>
							<option value="<?= e( $code ) ?>"><?= e( $lib ) ?></option>
						<?php endforeach; ?>
					</select></label>
				<label class="fld"><span>Thème</span>
					<select name="theme">
						<?php foreach ( $themes as $code => $lib ) : ?>
							<option value="<?= e( $code ) ?>"><?= e( $lib ) ?></option>
						<?php endforeach; ?>
					</select></label>
			</div>
			<p class="help">
				Packs disposant d'une expérience client : <strong><?= e( implode( ', ', $packsEquipes ) ) ?></strong>.
				Les autres métiers viendront par adaptateurs successifs — le moteur, lui, est commun et déjà posé.
			</p>
			<button class="btn btn-primary">Déclarer le terminal</button>
		</form>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Ce que chaque type a le droit de faire</h2></div>
	<div class="card-body">
		<table class="table">
			<thead><tr><th>Type</th><th>Usage</th><th>Capacités</th></tr></thead>
			<tbody>
			<?php foreach ( $types as $code => $d ) : ?>
				<tr>
					<td><?= e( $d['label'] ) ?></td>
					<td class="muted"><?= e( $d['aide'] ) ?></td>
					<td><?php foreach ( $d['capacites'] as $c ) : ?><span class="tag"><?= e( $c ) ?></span> <?php endforeach; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="help" style="margin-bottom:0">
			Cette liste est <strong>blanche</strong> : ce qui n'y figure pas est refusé par le serveur, quelle que soit
			la page affichée sur l'appareil. Aucune capacité n'ouvre la comptabilité, les clients, la paie ou les états.
		</p>
	</div>
</div>

</div>
