<?php /** Barre Retour / Fermer (remplace l'ancienne rangée d'onglets), harmonisée avec les autres modules.
 * @var string $tab (conservé pour compatibilité, ignoré) @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<div class="modbar">
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres' ) ) ?>"><span aria-hidden="true">←</span> Paramètres</a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( '' ) ) ?>">Fermer <span aria-hidden="true">✕</span></a>
</div>
