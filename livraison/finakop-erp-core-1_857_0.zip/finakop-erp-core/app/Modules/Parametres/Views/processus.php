<?php /** @var string $title @var string $tab @var array $etat @var array $evenements @var array $frequences @var array $attente @var array $echouees @var array $traitements @var mixed $prochain @var bool $cronCoupe @var array|null $sante @var string $type @var mixed $docId @var array $chaine @var mixed $flash */
/** Supervision du socle BPE : journal des événements et chaîne documentaire. */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres', 'backLabel' => 'Paramètres' ) );
$e = $etat ?? array();
?>
<div class="bar"><span><strong>Processus & événements métier</strong></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/integrations' ) ) ?>">Audit des intégrations</a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres' ) ) ?>">← Paramètres</a></div>

<div class="card"><div class="card-body">
	<p>Chaque opération métier de FinaKop émet un <strong>événement</strong> : une vente encaissée, une réception validée,
	une facture émise. Cet écran montre ce qui circule réellement dans votre système. C'est la base de l'architecture
	pilotée par les processus : avant d'automatiser une chaîne, il faut voir ce qu'elle contient.</p>
	<div style="display:flex;gap:24px;flex-wrap:wrap;margin:14px 0">
		<div><div class="muted" style="font-size:12px">Événements journalisés</div><div style="font-size:26px;font-weight:700"><?= (int) ( $e['evenements'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">En échec</div><div style="font-size:26px;font-weight:700;color:<?= ! empty( $e['echecs'] ) ? '#ff6b6b' : '#3ddc84' ?>"><?= (int) ( $e['echecs'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">Liens documentaires</div><div style="font-size:26px;font-weight:700"><?= (int) ( $e['liens'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">Actions auditées</div><div style="font-size:26px;font-weight:700"><?= (int) ( $e['audit'] ?? 0 ) ?></div></div>
	</div>
	<p class="muted" style="font-size:12px;margin:0">Le socle est <strong>observateur</strong> :
	il enregistre et relie, sans décider d'aucune écriture ni modifier aucun stock.</p>
</div></div>

<?php
/*
 * FILE DES TRAITEMENTS DIFFÉRÉS (1.620.0).
 *
 * Cette section n'existait pas, et pour cause : jusqu'à cette version, la
 * file n'avait aucun consommateur. Montrer une file que personne ne vide
 * aurait été trompeur ; la montrer maintenant est le seul moyen de voir si le
 * worker tourne réellement.
 */
$bloquees = (int) ( $e['file_bloquee'] ?? 0 );
?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>File des traitements différés</h2></div><div class="card-body">
	<p class="muted" style="font-size:13px;margin-top:0">Une chaîne longue — valorisation, écriture, alerte, tableau de bord —
	ne doit jamais retarder un encaissement. L'écran métier émet, la file finit le travail.</p>

	<div style="display:flex;gap:24px;flex-wrap:wrap;margin:14px 0">
		<div><div class="muted" style="font-size:12px">En attente</div><div style="font-size:26px;font-weight:700"><?= (int) ( $e['file_attente'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">En traitement</div><div style="font-size:26px;font-weight:700"><?= (int) ( $e['file_encours'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">Terminées</div><div style="font-size:26px;font-weight:700"><?= (int) ( $e['file_faites'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">Abandonnées</div><div style="font-size:26px;font-weight:700;color:<?= ! empty( $e['file_echec'] ) ? '#ffb020' : '#3ddc84' ?>"><?= (int) ( $e['file_echec'] ?? 0 ) ?></div></div>
		<div><div class="muted" style="font-size:12px">Bloquées</div><div style="font-size:26px;font-weight:700;color:<?= $bloquees ? '#ff6b6b' : '#3ddc84' ?>"><?= $bloquees ?></div></div>
	</div>

	<?php if ( $bloquees ) : ?>
		<p style="color:#ff6b6b;font-size:13px"><strong><?= $bloquees ?> tâche(s) retenue(s) par un worker qui n'a jamais rendu de réponse.</strong>
		C'est le seul chiffre de cet écran qui ne se résorbe pas tout seul : le processus qui les avait prises est mort en cours de route.</p>
	<?php endif; ?>

	<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:10px 0">
		<form method="post" action="<?= e( url( 'parametres/processus/traiter' ) ) ?>"><?= FKC_Csrf::field() ?>
			<button class="btn btn-primary" type="submit">Traiter maintenant</button></form>
		<form method="post" action="<?= e( url( 'parametres/processus/recuperer' ) ) ?>"><?= FKC_Csrf::field() ?>
			<button class="btn btn-ghost btn-sm" type="submit">Récupérer les tâches bloquées</button></form>
		<span class="muted" style="font-size:12px">
			<?php if ( ! empty( $prochain ) ) : ?>
				Prochain passage automatique : <?= e( date( 'd/m/Y H:i', (int) $prochain ) ) ?>
			<?php else : ?>
				Aucun passage automatique planifié.
			<?php endif; ?>
		</span>
	</div>

	<?php
	/*
	 * BATTEMENT DU MOTEUR.
	 *
	 * Les compteurs ci-dessus disent ce qu'il y a dans la file ; ils ne disent
	 * pas si quelque chose la vide. Une file vide et un moteur mort se
	 * ressemblent — c'est ce qui a permis à la planification du balayeur de
	 * rester inactive pendant des dizaines de versions.
	 *
	 * Le bandeau n'est ALARMANT que si le moteur est muet ALORS QUE du travail
	 * attend ; un dossier peu fréquenté qui dort avec une file vide reçoit une
	 * simple mention grise, parce qu'il n'y a rien à corriger.
	 */
	if ( is_array( $sante ) ) :
		$sc = array( 'muet' => '#ff6b6b', 'jamais' => '#ff6b6b', 'dormant' => '#9fb0c0', 'neuf' => '#9fb0c0', 'ok' => '#7fd1a8' );
		$sg = $sc[ $sante['etat'] ] ?? '#9fb0c0';
		$alarme = in_array( $sante['etat'], array( 'muet', 'jamais' ), true );
	?>
		<p style="color:<?= e( $sg ) ?>;font-size:13px;margin:6px 0<?= $alarme ? ';padding:8px 10px;border-left:3px solid ' . e( $sg ) : '' ?>">
			<?php if ( $alarme ) : ?><strong>Le moteur d'événements ne tourne plus.</strong> <?php endif; ?>
			<?= e( $sante['message'] ) ?>
			<?php if ( $sante['passages'] ) : ?>
				<span class="muted">(<?= (int) $sante['passages'] ?> passage(s), <?= (int) $sante['cumul_traite'] ?> tâche(s) traitée(s)<?= $sante['cumul_echec'] ? ', ' . (int) $sante['cumul_echec'] . ' en échec' : '' ?><?= $sante['declencheur'] ? ' · dernier déclencheur : ' . e( $sante['declencheur'] ) : '' ?>)</span>
			<?php endif; ?>
		</p>
	<?php endif; ?>

	<?php if ( ! empty( $cronCoupe ) ) : ?>
		<p style="color:#ffb020;font-size:13px;margin:6px 0"><strong>WP-Cron est désactivé sur cette installation</strong>
		(<code>DISABLE_WP_CRON</code>). Le passage automatique n'aura donc pas lieu. Programmez un cron système :
		<code>*/5 * * * * cd /chemin/du/site &amp;&amp; wp finakop bpe --quiet</code>. Sans cela, seul le bouton ci-dessus
		vide la file — c'est-à-dire un traitement différé qui dépend d'un humain.</p>
	<?php endif; ?>

	<p class="muted" style="font-size:12px;margin:6px 0 0">Traitements déclarés :
		<?php if ( empty( $traitements ) ) : ?>aucun<?php else : ?>
			<?php foreach ( (array) $traitements as $t ) : ?><code><?= e( $t ) ?></code> <?php endforeach; ?>
		<?php endif; ?>
	</p>

	<?php if ( ! empty( $attente ) ) : ?>
		<h3 style="font-size:14px;margin:16px 0 6px">Prochaines tâches</h3>
		<table class="table"><thead><tr><th>#</th><th>Tâche</th><th>Tentatives</th><th>Disponible à</th><th>Dernière erreur</th></tr></thead><tbody>
		<?php foreach ( $attente as $t ) : ?>
			<tr><td class="muted"><?= (int) $t['id'] ?></td>
				<td><code><?= e( $t['tache'] ) ?></code></td>
				<td><?= (int) ( $t['tentatives'] ?? 0 ) ?></td>
				<td class="muted" style="font-size:12px;white-space:nowrap"><?= e( (string) ( $t['disponible_a'] ?? '' ) ) ?></td>
				<td class="muted" style="font-size:12px"><?= e( (string) ( $t['derniere_erreur'] ?? '' ) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
	<?php endif; ?>

	<?php if ( ! empty( $echouees ) ) : ?>
		<h3 style="font-size:14px;margin:16px 0 6px">Tâches abandonnées</h3>
		<p class="muted" style="font-size:12px;margin-top:0">Une tâche est abandonnée après cinq tentatives, ou dès la première
		lorsque le rejeu ne peut rien changer. Si la cause a été corrigée depuis, remettez-la en file.</p>
		<table class="table"><thead><tr><th>#</th><th>Tâche</th><th>Tentatives</th><th>Motif</th><th></th></tr></thead><tbody>
		<?php foreach ( $echouees as $t ) : ?>
			<tr><td class="muted"><?= (int) $t['id'] ?></td>
				<td><code><?= e( $t['tache'] ) ?></code></td>
				<td><?= (int) ( $t['tentatives'] ?? 0 ) ?></td>
				<td class="muted" style="font-size:12px"><?= e( (string) ( $t['derniere_erreur'] ?? '' ) ) ?></td>
				<td><form method="post" action="<?= e( url( 'parametres/processus/' . (int) $t['id'] . '/rejouer' ) ) ?>"><?= FKC_Csrf::field() ?>
					<button class="btn btn-ghost btn-sm" type="submit">Rejouer</button></form></td></tr>
		<?php endforeach; ?>
		</tbody></table>
	<?php endif; ?>
</div></div>

<?php if ( ! empty( $frequences ) ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Événements les plus fréquents</h2></div><div class="card-body">
	<table class="table"><thead><tr><th>Événement</th><th>Occurrences</th><th>Dernier</th></tr></thead><tbody>
	<?php foreach ( $frequences as $f ) : ?>
		<tr><td><code><?= e( $f['evenement'] ) ?></code></td>
			<td><?= (int) $f['n'] ?></td>
			<td class="muted"><?= e( $f['dernier'] ) ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
</div></div>
<?php endif; ?>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Derniers événements</h2></div><div class="card-body">
	<?php if ( empty( $evenements ) ) : ?>
		<p class="muted">Aucun événement pour l'instant. Réalisez une vente, une réception ou une facture :
		elle apparaîtra ici, ainsi que toute la chaîne qu'elle déclenche.</p>
	<?php else : ?>
		<table class="table"><thead><tr>
			<th>Horodatage</th><th>Événement</th><th>Objet</th><th>État</th><th>Détail</th>
		</tr></thead><tbody>
		<?php foreach ( $evenements as $ev ) :
			// Le registre d'exécution (1.620.0) a trois issues négatives et un
			// état intermédiaire : les traiter toutes comme « en attente »
			// aurait rendu les échecs invisibles au moment même où on les rend.
			$st   = (string) $ev['statut'];
			$coul = in_array( $st, array( 'echec', 'echec_retryable', 'echec_definitif' ), true ) ? '#ff6b6b'
				: ( 'traite' === $st ? '#3ddc84' : '#ffb020' ); ?>
			<tr>
				<td class="muted" style="font-size:12px;white-space:nowrap"><?= e( $ev['created_at'] ) ?></td>
				<td><code><?= e( $ev['evenement'] ) ?></code></td>
				<td class="muted" style="font-size:12px">
					<?php if ( ! empty( $ev['objet_type'] ) ) : ?>
						<?= e( $ev['objet_type'] ) ?> #<?= (int) $ev['objet_id'] ?>
					<?php else : ?>—<?php endif; ?>
				</td>
				<td style="color:<?= $coul ?>"><?= e( $ev['statut'] ) ?></td>
				<td class="muted" style="font-size:12px"><?= e( (string) ( $ev['message'] ?? '' ) ) ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody></table>
	<?php endif; ?>
</div></div>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Chaîne documentaire</h2></div><div class="card-body">
	<p class="muted" style="font-size:13px;margin-top:0">Remontez d'un document à toute sa chaîne — commande, réception,
	facture, paiement. C'est ce qui permet de retrouver la pièce d'origine derrière une écriture comptable.</p>
	<form method="get" action="<?= e( url( 'parametres/processus' ) ) ?>">
		<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
			<label class="fld" style="max-width:200px"><span>Type de document</span>
				<input name="type" value="<?= e( $type ?? '' ) ?>" placeholder="ex. facture, caisse_ticket"></label>
			<label class="fld" style="max-width:130px"><span>Identifiant</span>
				<input name="id" value="<?= e( (string) ( $docId ?? '' ) ) ?>" placeholder="ex. 42"></label>
			<button class="btn btn-primary" type="submit">Afficher la chaîne</button>
		</div>
	</form>
	<?php if ( ! empty( $type ) && ! empty( $docId ) ) : ?>
		<?php $ch = $chaine ?? array( 'amont' => array(), 'aval' => array() ); ?>
		<?php if ( empty( $ch['amont'] ) && empty( $ch['aval'] ) ) : ?>
			<p class="muted" style="margin-top:14px">Aucun lien enregistré pour <code><?= e( $type ) ?> #<?= (int) $docId ?></code>.
			Les liens se créent au fil des opérations réalisées après cette mise à jour.</p>
		<?php else : ?>
			<div style="margin-top:14px">
				<?php if ( ! empty( $ch['amont'] ) ) : ?>
					<p style="margin-bottom:6px"><strong>En amont</strong></p>
					<?php foreach ( $ch['amont'] as $d ) : ?>
						<div class="muted" style="font-size:13px">↑ <?= e( $d['type'] ) ?> #<?= (int) $d['id'] ?> <span style="opacity:.6">(<?= e( $d['relation'] ) ?>, niveau <?= (int) $d['niveau'] ?>)</span></div>
					<?php endforeach; ?>
				<?php endif; ?>
				<p style="margin:10px 0 6px"><strong><?= e( $type ) ?> #<?= (int) $docId ?></strong></p>
				<?php if ( ! empty( $ch['aval'] ) ) : ?>
					<?php foreach ( $ch['aval'] as $d ) : ?>
						<div class="muted" style="font-size:13px">↓ <?= e( $d['type'] ) ?> #<?= (int) $d['id'] ?> <span style="opacity:.6">(<?= e( $d['relation'] ) ?>, niveau <?= (int) $d['niveau'] ?>)</span></div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div></div>
