<?php /** @var string $tab @var array $comptes @var array $types @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'parametres::_adminnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="max-width:760px"><div class="card-head"><h2>Ajouter un compte de trésorerie</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">Le compte est rattaché à un compte comptable de <strong>classe 5</strong> (banque 52x, caisse 57x, monnaie électronique 55x). S'il n'existe pas encore au plan comptable, il sera créé automatiquement.</p>
	<form method="post" action="<?= e( url( 'parametres/tresorerie/ajouter' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:2fr 1fr">
			<label class="fld"><span>Libellé *</span><input name="libelle" placeholder="ex. Banque NSIA, Caisse agence Cocody…" required></label>
			<label class="fld"><span>Type</span><select name="type"><?php foreach ( $types as $k=>$lbl ) : ?><option value="<?= e($k) ?>"><?= e($lbl) ?></option><?php endforeach; ?></select></label>
		</div>
		<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
			<label class="fld"><span>N° compte (classe 5) *</span><input name="numero" placeholder="ex. 521300" required inputmode="numeric"></label>
			<label class="fld"><span>Libellé du compte</span><input name="compte_libelle" placeholder="(repris du libellé si vide)"></label>
			<label class="fld"><span>Opérateur (optionnel)</span><input name="operateur" placeholder="ex. NSIA, Wave, Orange…"></label>
		</div>
		<div class="actions"><button class="btn btn-primary" type="submit">Ajouter le compte</button></div>
	</form>
</div></div>

<div class="card card-flush" style="margin-top:16px"><div class="card-head"><h2>Comptes de trésorerie</h2></div>
	<table class="table">
		<thead><tr><th>Libellé</th><th>Type</th><th>Compte</th><th class="right">Solde</th><th>Statut</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $comptes ) : ?>
			<tr><td colspan="6" class="muted" style="text-align:center;padding:22px">Aucun compte de trésorerie.</td></tr>
		<?php else : foreach ( $comptes as $c ) : ?>
			<tr<?= $c['actif'] ? '' : ' style="opacity:.55"' ?>>
				<td><strong><?= e( $c['libelle'] ) ?></strong><?= $c['operateur'] ? ' <span class="muted">· '.e($c['operateur']).'</span>' : '' ?></td>
				<td><span class="treso-badge"><?= e( strtoupper( str_replace('_',' ',$c['type']) ) ) ?></span></td>
				<td class="mono"><?= e( $c['numero'] ) ?></td>
				<td class="right mono"><?= e( fkc_money( $c['solde'] ) ) ?> F CFA</td>
				<td><span class="modbadge <?= $c['actif']?'b-on':'b-off' ?>"><?= $c['actif']?'Actif':'Inactif' ?></span></td>
				<td class="right">
					<form method="post" action="<?= e( url( 'parametres/tresorerie/'.$c['id'].'/basculer' ) ) ?>" style="display:inline">
						<?= FKC_Csrf::field() ?>
						<button class="btn btn-ghost btn-sm" type="submit"><?= $c['actif']?'Désactiver':'Activer' ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
<style>.treso-badge{display:inline-block;font-size:10px;font-weight:700;letter-spacing:.5px;padding:3px 9px;border-radius:20px;background:var(--panel2);border:1px solid var(--line2);color:var(--orange-l)}</style>
