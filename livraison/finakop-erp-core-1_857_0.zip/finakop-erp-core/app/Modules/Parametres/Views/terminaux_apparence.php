<?php
/**
 * PARAMÈTRES → TERMINAUX → APPARENCE DES BORNES (Phase 3, lot 2 — 1.815.0).
 *
 * Réglages COMMUNS à toutes les bornes de l'établissement, avec un APERÇU EN
 * DIRECT : une mini-borne dessinée avec les vraies feuilles de style du
 * Terminal, isolée dans un cadre (elles ne touchent pas l'administration).
 *
 * @var array $r @var bool $fond @var array $themes @var array $polices @var array $arrondis
 * @var array $ambiances @var array $marque @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$fkcAccent = $r['accent'] ?: FKC_TerminalTheme::ACCENT_DEFAUT;
$fkcNom = (string) ( $marque['nom'] ?? 'Votre établissement' );
$fkcIni = (string) ( $marque['initiales'] ?? '' ) ?: mb_strtoupper( mb_substr( $fkcNom, 0, 1 ) );
$fkcFondUrl = $fond ? url( 'parametres/terminaux/apparence/fond' ) . '?v=' . substr( md5( (string) $r['fond'] ), 0, 8 ) : '';

/*
 * LA MINI-BORNE : les quatre feuilles du Design System, et un balisage réduit
 * aux composants du Terminal. Rendue dans un <iframe srcdoc> : ses règles
 * globales (body, h1…) restent chez elle.
 */
ob_start(); ?>
<!DOCTYPE html><html lang="fr" data-theme="premium"><head><meta charset="utf-8">
<?= FKC_TerminalTheme::feuilles() ?>
<style id="v"></style>
<style>
	body { min-height: 100vh; overflow: hidden; }
	.apercu { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: 18px; }
	.apercu__col { display: grid; gap: 14px; align-content: start; }
	.mini-attract { position: relative; overflow: hidden; border-radius: var(--t-r-xl); min-height: 300px; display: grid; place-items: center; background: var(--t-bg); }
	.mini-attract .fkt-attract__inner { gap: 12px; }
	.mini-attract .fkt-attract__mark { width: 84px; font-size: 34px; }
	.mini-attract .fkt-attract__name { font-size: 26px; }
	.mini-attract .fkt-attract__msg { font-size: 15px; }
	.mini-attract .fkt-attract__touch { font-size: 14px; padding: 10px 18px; margin-top: 4px; }
	.fkt-card { animation: none; }
</style></head><body>
<div class="apercu">
	<div class="apercu__col">
		<header class="fkt-header" style="position:relative;border-radius:var(--t-r-lg)"><div class="fkt-brand"><div class="fkt-brand__mark"><?= e( $fkcIni ) ?></div><div class="fkt-brand__txt"><span class="fkt-brand__name"><?= e( $fkcNom ) ?></span></div></div></header>
		<h1 class="fkt-hero__title" style="font-size:30px">Notre carte</h1>
		<article class="fkt-card is-selected"><div class="fkt-card__media">🍛</div>
			<div class="fkt-card__body"><span class="fkt-card__cat">Plats</span><h3 class="fkt-card__title">Poulet braisé</h3></div>
			<div class="fkt-card__foot"><div class="fkt-price"><span class="fkt-price__value">6 000 F</span></div>
				<div class="fkt-card__action"><button type="button" class="fkt-btn fkt-btn--primary fkt-btn--add">＋ Ajouter</button></div></div></article>
		<button type="button" class="fkt-btn fkt-btn--primary fkt-btn--xl" style="width:100%">Envoyer ma commande ✓</button>
	</div>
	<div class="apercu__col">
		<div class="fkt-attract mini-attract" id="mini-attract">
			<img class="fkt-attract__fond" id="mini-fond" alt="" hidden>
			<div class="fkt-attract__orb fkt-attract__orb--a"></div><div class="fkt-attract__orb fkt-attract__orb--b"></div>
			<div class="fkt-attract__inner">
				<div class="fkt-attract__mark"><?= e( $fkcIni ) ?></div>
				<h2 class="fkt-attract__name"><?= e( $fkcNom ) ?></h2>
				<p class="fkt-attract__msg">Composez votre commande, sur place ou à emporter.</p>
				<span class="fkt-attract__touch">Touchez l'écran pour commander</span>
			</div>
		</div>
	</div>
</div>
</body></html>
<?php $fkcSrcdoc = (string) ob_get_clean(); ?>
<div class="page-stack" style="max-width:1200px">

<p style="margin:0"><a href="<?= e( url( 'parametres/terminaux' ) ) ?>">← Terminaux</a></p>

<?php if ( $flash ) : ?>
	<div class="alert alert-<?= 'ok' === $flash['type'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:minmax(300px,420px) 1fr;gap:16px;align-items:start">
<div class="card">
	<div class="card-head"><h2>🎨 Apparence des bornes</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">Ces réglages valent pour <strong>toutes les bornes</strong> de l'établissement. Un terminal peut encore forcer son thème ou sa couleur dans ses propres réglages. Le bleu FinaKop et la signature « Propulsé par FinaKop » restent fixes.</p>
		<form method="post" enctype="multipart/form-data" id="fkc-app-form" style="display:grid;gap:14px"><?= FKC_Csrf::field() ?>
			<input type="hidden" name="action" value="enregistrer">
			<label>Thème
				<select name="theme" style="width:100%">
					<option value="">Selon le métier (recommandé)</option>
					<?php foreach ( $themes as $k => $t ) : ?><option value="<?= e( $k ) ?>" <?= $k === $r['theme'] ? 'selected' : '' ?>><?= e( $t['label'] ) ?></option><?php endforeach; ?>
				</select></label>
			<div>
				<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="accent_perso" value="1" id="fkc-accent-perso" style="width:auto;flex:none;margin:0" <?= $r['accent'] ? 'checked' : '' ?>> Couleur d'accent de l'établissement</label>
				<div style="display:flex;gap:8px;align-items:center;margin-top:6px">
					<input type="color" name="accent" id="fkc-accent" value="<?= e( $fkcAccent ) ?>" style="width:56px;height:36px;padding:0;border:0;background:none">
					<span class="muted" style="font-size:12px">Sinon : l'orange FinaKop. Le texte des boutons prend automatiquement la couleur la plus lisible.</span>
				</div>
			</div>
			<label>Police des titres
				<select name="police" style="width:100%">
					<?php foreach ( $polices as $k => $p ) : ?><option value="<?= e( $k ) ?>" <?= $k === $r['police'] ? 'selected' : '' ?>><?= e( $p['label'] ) ?></option><?php endforeach; ?>
				</select></label>
			<label>Arrondis
				<select name="arrondis" style="width:100%">
					<?php foreach ( $arrondis as $k => $a ) : ?><option value="<?= e( $k ) ?>" <?= $k === $r['arrondis'] ? 'selected' : '' ?>><?= e( $a['label'] ) ?></option><?php endforeach; ?>
				</select></label>
			<label>Écran d'attente
				<select name="ambiance" style="width:100%">
					<?php foreach ( $ambiances as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $k === ( $r['ambiance'] ?: 'halos' ) ? 'selected' : '' ?>><?= e( $lib ) ?></option><?php endforeach; ?>
				</select></label>
			<div>
				<label>Photo de fond de l'écran d'attente <span class="muted">(paysage · PNG, JPEG ou WebP · 3 Mo max)</span>
					<input type="file" name="fond" id="fkc-fond" accept="image/png,image/jpeg,image/webp" style="width:100%"></label>
				<?php if ( $fond ) : ?><p class="muted" style="font-size:12px;margin:4px 0 0">Une photo est enregistrée.</p><?php endif; ?>
			</div>
			<button class="btn btn-primary">Enregistrer</button>
		</form>
		<?php if ( $fond ) : ?>
			<form method="post" style="margin-top:8px"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" name="action" value="fond_retirer">Retirer la photo de fond</button></form>
		<?php endif; ?>
	</div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Aperçu en direct</h2></div>
	<iframe id="fkc-apercu" title="Aperçu d'une borne" srcdoc="<?= e( $fkcSrcdoc ) ?>" style="width:100%;height:560px;border:0;display:block;border-radius:0 0 12px 12px"></iframe>
</div>
</div>
</div>
<script>
/*
 * APERÇU : les mêmes traductions que le serveur (FKC_TerminalMarque::css,
 * FKC_TerminalTheme::encreSur), appliquées à la mini-borne à chaque changement.
 * Rien n'est enregistré avant « Enregistrer ».
 */
(function () {
	var POLICES = <?= json_encode( array_map( function ( $p ) { return $p['css']; }, $polices ), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP ) ?>;
	var ARRONDIS = <?= json_encode( array_map( function ( $a ) { return $a['r']; }, $arrondis ), JSON_HEX_TAG ) ?>;
	var DEFAUT = <?= json_encode( FKC_TerminalTheme::ACCENT_DEFAUT ) ?>, ENCRE = <?= json_encode( FKC_TerminalTheme::ENCRE_SOMBRE ) ?>;
	var FOND = <?= json_encode( $fkcFondUrl, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) ?>;
	var form = document.getElementById('fkc-app-form'), frame = document.getElementById('fkc-apercu');
	var fondLocal = '';
	function lum(h) {
		return [1, 3, 5].map(function (i) { var c = parseInt(h.substr(i, 2), 16) / 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); })
			.reduce(function (s, c, i) { return s + c * [0.2126, 0.7152, 0.0722][i]; }, 0);
	}
	function contraste(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
	function maj() {
		var doc = frame.contentDocument;
		if (!doc || !doc.getElementById('v')) { return; }
		var f = new FormData(form);
		var acc = f.get('accent_perso') ? (f.get('accent') || DEFAUT) : DEFAUT;
		var encre = contraste(acc, '#ffffff') >= contraste(acc, ENCRE) ? '#ffffff' : ENCRE;
		var rgb = [1, 3, 5].map(function (i) { return parseInt(acc.substr(i, 2), 16); }).join(', ');
		var r = ARRONDIS[f.get('arrondis')] || ARRONDIS.standard;
		doc.getElementById('v').textContent = ':root{--t-accent:' + acc + ';--t-accent-ink:' + encre + ';--t-accent-rgb:' + rgb
			+ ';--t-font-display:' + (POLICES[f.get('police')] || POLICES.syne)
			+ ';--t-r-xs:' + r[0] + 'px;--t-r-sm:' + r[1] + 'px;--t-r-md:' + r[2] + 'px;--t-r-lg:' + r[3] + 'px;--t-r-xl:' + r[4] + 'px}';
		doc.documentElement.setAttribute('data-theme', f.get('theme') || 'premium');
		var amb = f.get('ambiance'), att = doc.getElementById('mini-attract'), img = doc.getElementById('mini-fond');
		var src = fondLocal || FOND;
		if ('photo' === amb && !src) { amb = 'halos'; }
		att.className = 'fkt-attract mini-attract fkt-attract--' + amb;
		img.hidden = 'photo' !== amb;
		if ('photo' === amb && img.getAttribute('src') !== src) { img.setAttribute('src', src); }
		Array.prototype.forEach.call(att.querySelectorAll('.fkt-attract__orb'), function (o) { o.style.display = 'sobre' === amb ? 'none' : ''; });
	}
	frame.addEventListener('load', maj);
	form.addEventListener('input', maj);
	form.addEventListener('change', maj);
	var file = document.getElementById('fkc-fond');
	if (file) {
		file.addEventListener('change', function () {
			if (fondLocal) { URL.revokeObjectURL(fondLocal); }
			fondLocal = file.files && file.files[0] ? URL.createObjectURL(file.files[0]) : '';
			if (fondLocal) { form.ambiance.value = 'photo'; }
			maj();
		});
	}
	var acc = document.getElementById('fkc-accent'), perso = document.getElementById('fkc-accent-perso');
	if (acc && perso) { acc.addEventListener('input', function () { perso.checked = true; }); }
	maj();
}());
</script>
