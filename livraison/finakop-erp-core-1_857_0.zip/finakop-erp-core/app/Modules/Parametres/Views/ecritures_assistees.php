<?php /** @var string $title @var string $tab @var array $regles @var mixed $flash */
/** Écritures métier assistées : le comptable choisit la règle, la base et le traitement. */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres', 'backLabel' => 'Paramètres' ) );
?>
<div class="bar"><span><strong>Écritures métier assistées</strong></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/integrations' ) ) ?>">Audit des intégrations</a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres' ) ) ?>">← Paramètres</a></div>

<?php if ( ! empty( $flash ) ) : ?><div class="flash"><?= e( $flash ) ?></div><?php endif; ?>

<div class="card"><div class="card-body">
	<p>Ces règles comptables sont déclarées par les packs métier mais n'ont <strong>volontairement</strong> aucun déclencheur
	automatique : leur fait générateur — le moment où l'écriture part et la base sur laquelle elle se calcule — relève d'une
	décision comptable, parfois actuarielle. Une provision pour primes non acquises se calcule à l'inventaire ; une dîme
	n'est pas une vente. Les déclencher d'office produirait des écritures justes dans leur forme et fausses dans leur moment.</p>
	<p class="muted" style="font-size:13px;margin-bottom:0">Vous choisissez la règle, saisissez la base, puis décidez du traitement :
	<strong>dépôt au brouillard</strong> pour contrôle avant validation (recommandé), ou comptabilisation directe.
	Le schéma SYSCOHADA du pack est utilisé tel quel. Seules les règles qu'aucun autre moteur ne produit sont proposées ici,
	afin qu'aucune opération ne soit comptabilisée deux fois.</p>
</div></div>

<?php if ( empty( $regles ) ) : ?>
	<div class="card" style="margin-top:12px"><div class="card-body">
		<p class="muted">Aucune règle en attente sur cette société : toutes les écritures des packs actifs sont déjà produites automatiquement.</p>
	</div></div>
<?php else : ?>
	<?php foreach ( $regles as $evt => $r ) : $champs = FKC_EcritureAssistee::champsAttendus( $r['schema'] ); ?>
	<div class="card" style="margin-top:12px"><div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
		<h2 style="margin:0"><?= e( $r['pack'] ) ?> · <code style="font-size:13px"><?= e( $evt ) ?></code></h2>
		<span class="muted">journal <strong><?= e( $r['journal'] ) ?></strong></span>
	</div><div class="card-body">
		<p class="muted" style="font-size:13px;margin-top:0"><?= e( $r['libelle'] ) ?></p>
		<form method="post" action="<?= e( url( 'parametres/ecritures-assistees/generer' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<input type="hidden" name="evenement" value="<?= e( $evt ) ?>">
			<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
				<?php foreach ( $champs as $c ) : ?>
					<label class="fld" style="max-width:150px"><span><?= e( ucfirst( str_replace( '_', ' ', $c ) ) ) ?> (F)</span>
						<input type="number" step="0.01" name="ctx[<?= e( $c ) ?>]" value="0" required></label>
				<?php endforeach; ?>
				<label class="fld" style="max-width:170px"><span>Date</span>
					<input type="date" name="ctx[date]" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld" style="max-width:190px"><span>Tiers / libellé</span>
					<input name="libelle_tiers" placeholder="ex. Assuré, paroissien…"></label>
				<label class="fld" style="max-width:190px"><span>Dossier / référence</span>
					<input name="dossier" placeholder="ex. Police n°…"></label>
				<label class="fld" style="max-width:230px"><span>Traitement</span>
					<select name="mode">
						<option value="brouillard">Déposer au brouillard (contrôle avant validation)</option>
						<option value="direct">Comptabiliser directement</option>
					</select></label>
				<button class="btn btn-primary" type="submit">Générer l'écriture</button>
			</div>
		</form>
	</div></div>
	<?php endforeach; ?>
<?php endif; ?>
