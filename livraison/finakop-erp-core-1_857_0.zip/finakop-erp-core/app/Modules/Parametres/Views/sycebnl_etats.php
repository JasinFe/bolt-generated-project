<?php /** @var array $ressources @var array|null $execution @var array $fonds @var array $conventions @var int $convention_id @var bool $valide @var mixed $flash @var string $tab */
/** Les trois états spécifiques du SYCEBNL — logique conforme, maquette à caler. */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres/referentiel', 'backLabel' => 'Référentiel' ) );
$r = $ressources;
?>
<div class="bar"><span><strong>États spécifiques SYCEBNL</strong></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/referentiel' ) ) ?>">← Référentiel</a></div>

<?php if ( ! $valide ) : ?>
<div class="card" style="border-left:3px solid #ffb020"><div class="card-body">
	<strong style="color:#ffb020">Plan non validé par un professionnel</strong>
	<p style="font-size:13px;margin:8px 0 0">Ces états sont produits, mais ils portent la réserve du plan sur lequel ils
	s'appuient. Faites relire le plan de comptes du dossier avant d'en tirer une liasse.</p>
</div></div>
<?php endif; ?>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Tableau ressources-emplois</h2></div><div class="card-body">
	<form method="get" action="<?= e( url( 'parametres/referentiel/etats' ) ) ?>" style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">
		<input type="date" name="du" value="<?= e( $r['du'] ) ?>">
		<input type="date" name="au" value="<?= e( $r['au'] ) ?>">
		<input type="hidden" name="convention_id" value="<?= (int) $convention_id ?>">
		<button class="btn btn-ghost btn-sm" type="submit">Actualiser</button>
	</form>
	<?php if ( ! empty( $r['en_attente'] ) ) : ?>
		<div class="alert alert-err" style="margin-bottom:12px"><?= (int) $r['en_attente'] ?> pièce(s) encore au brouillard
		ne figurent PAS dans ces états. Un état financier ne se lit que dans le grand livre : les y inclure donnerait des
		chiffres qui changent après relecture du comptable.</div>
	<?php endif; ?>
	<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px">
		<div>
			<h3 style="font-size:14px;color:var(--muted);text-transform:uppercase">Ressources</h3>
			<table class="table"><tbody>
			<?php if ( ! $r['ressources'] ) : ?><tr><td class="empty">Aucune ressource sur la période.</td></tr>
			<?php else : foreach ( $r['ressources'] as $l ) : ?>
				<tr><td class="code muted"><?= e( $l['numero'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="num"><?= e( fkc_money( $l['montant'] ) ) ?></td></tr>
			<?php endforeach; endif; ?>
			</tbody><tfoot><tr><th colspan="2">Total ressources</th><th class="num"><?= e( fkc_money( $r['total_ressources'] ) ) ?></th></tr></tfoot></table>
		</div>
		<div>
			<h3 style="font-size:14px;color:var(--muted);text-transform:uppercase">Emplois</h3>
			<table class="table"><tbody>
			<?php if ( ! $r['emplois'] ) : ?><tr><td class="empty">Aucun emploi sur la période.</td></tr>
			<?php else : foreach ( $r['emplois'] as $l ) : ?>
				<tr><td class="code muted"><?= e( $l['numero'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="num"><?= e( fkc_money( $l['montant'] ) ) ?></td></tr>
			<?php endforeach; endif; ?>
			</tbody><tfoot><tr><th colspan="2">Total emplois</th><th class="num"><?= e( fkc_money( $r['total_emplois'] ) ) ?></th></tr></tfoot></table>
		</div>
	</div>
	<div style="margin-top:14px;border-top:1px solid var(--line);padding-top:12px">
		<span class="muted" style="font-size:12px">Résultat de l'exercice</span>
		<div style="font-size:24px;font-weight:700;color:<?= 'surplus' === $r['sens'] ? '#3ddc84' : '#ff6b6b' ?>">
			<?= e( fkc_money( abs( $r['resultat'] ) ) ) ?> — <?= e( $r['sens'] ) ?></div>
		<p class="help" style="margin:8px 0 0">Le SYCEBNL ne connaît ni bénéfice ni perte : une entité à but non lucratif
		dégage un <strong>surplus</strong> ou un <strong>déficit</strong>.</p>
	</div>
	<?php if ( $r['nature'] ) : ?>
	<div style="margin-top:14px;border-top:1px solid var(--line);padding-top:12px">
		<h3 style="font-size:14px;color:var(--muted);text-transform:uppercase">Contributions volontaires en nature</h3>
		<table class="table"><tbody>
		<?php foreach ( $r['nature'] as $l ) : ?>
			<tr><td class="code muted"><?= e( $l['numero'] ) ?></td><td><?= e( $l['libelle'] ) ?></td><td class="num"><?= e( fkc_money( $l['montant'] ) ) ?></td></tr>
		<?php endforeach; ?>
		</tbody></table>
		<p class="help" style="margin:8px 0 0">Présentées à part : bénévolat et mises à disposition ne touchent pas le
		résultat. Les mêler aux ressources gonflerait le tableau d'un argent qui n'a jamais existé.</p>
	</div>
	<?php endif; ?>
</div></div>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Relevé d'exécution budgétaire</h2></div><div class="card-body">
	<?php if ( ! $conventions ) : ?>
		<p class="muted" style="margin:0">Aucune convention enregistrée.</p>
	<?php else : ?>
	<form method="get" action="<?= e( url( 'parametres/referentiel/etats' ) ) ?>" style="margin-bottom:12px">
		<input type="hidden" name="du" value="<?= e( $r['du'] ) ?>"><input type="hidden" name="au" value="<?= e( $r['au'] ) ?>">
		<select name="convention_id" onchange="this.form.submit()">
			<?php foreach ( $conventions as $c ) : ?>
				<option value="<?= (int) $c['id'] ?>"<?= (int) $c['id'] === (int) $convention_id ? ' selected' : '' ?>><?= e( $c['reference'] . ' — ' . $c['intitule'] ) ?></option>
			<?php endforeach; ?>
		</select>
	</form>
	<?php if ( $execution ) : ?>
	<table class="table">
		<thead><tr><th>Ligne budgétaire</th><th>Catégorie</th><th class="num">Budget accepté</th><th class="num">Réalisé</th><th class="num">Disponible</th><th class="num">Taux</th></tr></thead>
		<tbody>
		<?php foreach ( $execution['lignes'] as $l ) : ?>
			<tr>
				<td><?= e( $l['libelle'] ) ?></td>
				<td class="muted"><?= e( $l['categorie'] ) ?></td>
				<td class="num"><?= e( fkc_money( (float) $l['budget_ligne'] ) ) ?></td>
				<?php /* La clé est `engage` — même défaut que celui corrigé dans le
				         moteur au lot 7, resté ici : la colonne « Réalisé » du
				         relevé d'exécution plantait la page entière. */ ?>
				<td class="num"><?= e( fkc_money( (float) ( $l['engage'] ?? 0 ) ) ) ?></td>
				<td class="num"><?= e( fkc_money( (float) $l['disponible'] ) ) ?></td>
				<td class="num"><?= null === $l['taux'] ? '—' : (int) $l['taux'] . ' %' ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
		<tfoot><tr>
			<th colspan="2">Total</th>
			<th class="num"><?= e( fkc_money( $execution['budget'] ) ) ?></th>
			<th class="num"><?= e( fkc_money( $execution['realise'] ) ) ?></th>
			<th class="num"><?= e( fkc_money( $execution['disponible'] ) ) ?></th>
			<th class="num"><?= null === $execution['taux'] ? '—' : (int) $execution['taux'] . ' %' ?></th>
		</tr></tfoot>
	</table>
	<?php endif; ?>
	<?php endif; ?>
</div></div>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Tableau de rapprochement des fonds</h2></div><div class="card-body">
	<table class="table">
		<thead><tr><th>Convention</th><th>Bailleur</th><th class="num">Reçu</th><th class="num">Employé</th><th class="num">À reporter</th><th class="num">Préfinancé</th></tr></thead>
		<tbody>
		<?php if ( ! $fonds['lignes'] ) : ?><tr><td colspan="6" class="empty">Aucune convention.</td></tr>
		<?php else : foreach ( $fonds['lignes'] as $l ) : ?>
			<tr>
				<td><?= e( $l['reference'] ) ?><br><span class="muted" style="font-size:.85em"><?= e( $l['intitule'] ) ?></span></td>
				<td class="muted"><?= e( $l['bailleur'] ) ?></td>
				<td class="num"><?= e( fkc_money( $l['recu'] ) ) ?></td>
				<td class="num"><?= e( fkc_money( $l['employe'] ) ) ?></td>
				<td class="num" style="color:#ffb020"><?= e( fkc_money( $l['a_reporter'] ) ) ?></td>
				<td class="num" style="color:<?= $l['prefinance'] > 0 ? '#ff6b6b' : 'inherit' ?>"><?= e( fkc_money( $l['prefinance'] ) ) ?></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
		<tfoot><tr>
			<th colspan="2">Total</th>
			<th class="num"><?= e( fkc_money( $fonds['total_recu'] ?? 0 ) ) ?></th>
			<th class="num"><?= e( fkc_money( $fonds['total_employe'] ?? 0 ) ) ?></th>
			<th class="num"><?= e( fkc_money( $fonds['total_reporter'] ?? 0 ) ) ?></th>
			<th class="num"><?= e( fkc_money( $fonds['total_prefinance'] ?? 0 ) ) ?></th>
		</tr></tfoot>
	</table>
	<p class="help" style="margin:10px 0 0">Un solde négatif n'est pas un report : c'est un <strong>préfinancement sur fonds
	propres</strong>, affiché dans sa propre colonne parce qu'il dit l'inverse du premier.</p>
</div></div>

<div class="card" style="margin-top:12px"><div class="card-body">
	<p class="help" style="margin:0">Ces états sont conformes dans leur <strong>logique</strong> et produits depuis les
	écritures et le suivi des conventions. Leur mise en forme normalisée — maquettes officielles, ordre des rubriques,
	totaux réglementaires — reste à caler sur le guide d'application du SYCEBNL. Les présenter comme la liasse officielle
	avant cette étape serait un faux confort.</p>
</div></div>
