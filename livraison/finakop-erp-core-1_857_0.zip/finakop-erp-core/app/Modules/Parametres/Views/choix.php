<?php /** @var bool $libre @var string $actif @var array $options @var array $catalogue @var array $autorises @var bool $packs_nommes @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( 'parametres::_adminnav', array( 'tab' => 'pack' ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="max-width:760px">
	<div class="card-head"><h2>🧩 Pack métier (Vertical Pack)</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0; padding:8px 10px; background:var(--panel2); border-left:3px solid var(--line)">
			<strong>Seule votre licence active un Pack Métier.</strong>
			Les packs listés ci-dessous sont ceux que votre clé couvre
			(<?= count( $autorises ?? array() ) ?>)&nbsp;; les autres verticaux de la gamme FinaKop
			ne sont pas proposés tant qu'ils ne figurent pas dans votre jeton.
			<?php if ( isset( $packs_nommes ) && ! $packs_nommes && ( $libre ?? false ) ) : ?>
				<br><span class="muted">Votre clé a été émise avant la liste nominative de packs&nbsp;:
				elle ouvre encore l'ensemble du catalogue. Une clé renouvelée précisera les packs souscrits.</span>
			<?php endif; ?>
		</p>
		<p class="help" style="margin-top:0">
			Le pack métier adapte FinaKop à votre secteur : il ajoute l'objet central de votre activité
			(chantier, véhicule, patient, élève, projet…), ses pièces facturables et sa comptabilité SYSCOHADA
			automatique. Le vertical actif est <strong><?= e( ( $catalogue ?? array() )[ $actif ] ?? $options[ $actif ] ?? $actif ) ?></strong>.
		</p>

		<?php if ( $libre ) : ?>
			<form method="post" action="<?= e( url( 'parametres/pack' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<label class="fld" style="max-width:420px"><span>Pack métier de l'entité</span>
					<select name="pack">
						<?php foreach ( ( $familles ?? array() ) as $g ) : ?>
							<optgroup label="<?= e( $g['label'] ) ?>">
								<?php foreach ( $g['options'] as $code => $label ) : ?>
									<option value="<?= e( $code ) ?>" <?= $actif === $code ? 'selected' : '' ?>><?= e( $label ) ?></option>
								<?php endforeach; ?>
							</optgroup>
						<?php endforeach; ?>
					</select>
				</label>
				<div class="actions" style="margin-top:14px"><button class="btn btn-primary" type="submit">Activer ce pack</button></div>
				<p class="help">Le changement prend effet au rechargement de l'application. Les données déjà saisies dans un autre pack restent en base mais ne sont visibles que lorsque ce pack est actif.</p>
			</form>
		<?php else : ?>
			<div class="alert alert-ok" style="margin-bottom:0">
				Votre licence fixe le pack métier <strong><?= e( ( $catalogue ?? array() )[ $actif ] ?? $options[ $actif ] ?? $actif ) ?></strong>.
				Pour changer de vertical ou activer d'autres Packs Métier, contactez votre partenaire FinaKop
				(une nouvelle clé sera délivrée&nbsp;: les packs sont inscrits dans la charge signée du jeton).
			</div>
		<?php endif; ?>
	</div>
</div>

<?php if ( $libre ) : ?>
<div class="card" style="max-width:760px;margin-top:16px">
	<div class="card-head"><h2>🧩🧩 Packs complémentaires (multi-pack)</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			En plus du pack principal, activez ici d'autres packs qui doivent tourner <strong>réellement</strong>
			pour cette entité (leurs propres dossiers, comptes, workflows) — pas seulement une terminologie.
			Chacun garde ses propres écrans et son propre vocabulaire ; le principal reste seul à piloter
			le reste de l'application.
		</p>
		<?php if ( 0 === ( $complementaires_max ?? -1 ) ) : ?>
			<div class="alert alert-err" style="margin-bottom:14px">
				Votre palier de licence n'inclut pas le multi-pack (0 complémentaire autorisé).
				Passez à un palier Business ou supérieur pour combiner plusieurs Packs Métier sur la même entité.
			</div>
		<?php elseif ( ( $complementaires_max ?? -1 ) >= 0 ) : ?>
			<p class="help" style="margin-top:0">
				Votre licence autorise <strong><?= (int) $complementaires_max ?></strong> pack(s) complémentaire(s)
				— <?= count( $complementaires ?? array() ) ?> actuellement actif(s).
			</p>
		<?php endif; ?>
		<form method="post" action="<?= e( url( 'parametres/pack/complementaires' ) ) ?>">
			<?= FKC_Csrf::field() ?>
			<?php foreach ( ( $familles ?? array() ) as $g ) : ?>
				<div class="card" style="margin-bottom:10px"><div class="card-head"><h3 style="margin:0"><?= e( $g['label'] ) ?></h3></div>
					<div class="card-body"><div class="fkc-cta-grid">
					<?php foreach ( $g['options'] as $code => $label ) :
						if ( $code === $actif ) { continue; } // déjà actif de fait comme principal
						$on = in_array( $code, $complementaires ?? array(), true );
					?>
						<label class="fkc-cta" style="cursor:pointer;<?= $on ? 'border-color:var(--ok);background:var(--ok-bg)' : 'background:var(--panel2);border-color:var(--line)' ?>">
							<span class="fkc-cta-label"><?= e( $label ) ?>
								<?php if ( $on ) : ?><span class="modbadge b-on" style="margin-left:6px">Actif</span><?php endif; ?>
							</span>
							<span style="margin-top:6px;display:flex;gap:14px;align-items:center">
								<label style="display:flex;gap:4px;align-items:center;cursor:pointer"><input type="checkbox" name="complementaires[]" value="<?= e( $code ) ?>" <?= $on ? 'checked' : '' ?>> <span class="muted">Actif</span></label>
							</span>
						</label>
					<?php endforeach; ?>
					</div></div>
				</div>
			<?php endforeach; ?>
			<div class="actions"><button class="btn btn-primary" type="submit">Appliquer les packs complémentaires</button></div>
			<p class="help">Le changement prend effet immédiatement. Désactiver un complémentaire ne supprime rien : ses dossiers et écritures déjà saisis restent en base, simplement hors du menu tant qu'il n'est pas réactivé.</p>
		</form>
	</div>
</div>
<?php endif; ?>
