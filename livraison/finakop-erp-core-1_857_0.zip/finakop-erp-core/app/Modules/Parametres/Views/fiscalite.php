<?php
/**
 * Paramètres · Fiscalité & règles du pack.
 *
 * Rend atteignables deux moteurs qui ne l'étaient qu'en code :
 *   — la fiscalité dynamique (1.520.80) : quel taux pour quelle nature ;
 *   — le barème d'annulation (1.520.72) : quels frais suggérer, et quand.
 *
 * @var string     $tab
 * @var string     $pack       code du pack actif
 * @var string     $packLabel  son libellé
 * @var array      $categories catégories fiscales (actives et inactives)
 * @var array      $codesTaxe
 * @var array      $natures    natures du pack + catégorie associée + taux résultant
 * @var array      $bareme     paliers d'annulation du pack
 * @var array|null $flash
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'parametres::_adminnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= e( in_array( $flash['type'], array( 'ok', 'err', 'warn' ), true ) ? $flash['type'] : 'ok' ) ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="max-width:900px"><div class="card-head"><h2>Catégories fiscales</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">
		Un taux de taxe est une <strong>donnée</strong>, pas du code : il dépend de la nature exacte du
		produit, du régime de la société et d'une réglementation qui change sans prévenir. Modifier un
		taux ici prend effet sur les prochaines opérations ; <strong>les lignes déjà facturées gardent
		le leur</strong> — c'est ce qui rend une facture passée relisible des années après.
	</p>

	<?php if ( ! $categories ) : ?>
		<div class="alert alert-warn" style="margin-bottom:12px">
			Aucune catégorie fiscale. Tant que le référentiel est vide, tout est facturé au taux normal (18 %).
			<form method="post" action="<?= e( url( 'parametres/fiscalite/defauts' ) ) ?>" style="margin-top:8px"><?= FKC_Csrf::field() ?>
				<button class="btn btn-sm btn-primary">Créer les trois catégories standard (18 %, 9 %, 0 %)</button>
			</form>
		</div>
	<?php endif; ?>

	<table class="table">
		<thead><tr><th>Code</th><th>Libellé</th><th>Taxe</th><th class="right">Taux</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $categories ) : ?>
			<tr><td colspan="5" class="muted" style="text-align:center;padding:18px">Référentiel vide.</td></tr>
		<?php else : foreach ( $categories as $c ) : ?>
			<tr<?= empty( $c['actif'] ) ? ' style="opacity:.55"' : '' ?>>
				<td class="mono"><strong><?= e( $c['code'] ) ?></strong></td>
				<td><?= e( $c['libelle'] ) ?><?php if ( ! empty( $c['note'] ) ) : ?><br><span class="muted" style="font-size:11px"><?= e( $c['note'] ) ?></span><?php endif; ?></td>
				<td><?= e( $c['code_taxe'] ) ?></td>
				<td class="right">
					<form method="post" action="<?= e( url( 'parametres/fiscalite/taux' ) ) ?>" style="display:flex;gap:4px;justify-content:flex-end;align-items:center"><?= FKC_Csrf::field() ?>
						<input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
						<input class="num" name="taux" value="<?= e( $c['taux'] ) ?>" style="width:70px" inputmode="decimal"> %
						<button class="btn btn-ghost btn-sm">Modifier</button>
					</form>
				</td>
				<td class="right">
					<form method="post" action="<?= e( url( 'parametres/fiscalite/' . (int) $c['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer la catégorie « <?= e( $c['code'] ) ?> » ? Les articles qui la référencent retomberont sur le taux normal.')"><?= FKC_Csrf::field() ?>
						<button class="btn btn-ghost btn-sm">Supprimer</button>
					</form>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>

	<form method="post" action="<?= e( url( 'parametres/fiscalite/categorie' ) ) ?>" style="margin-top:14px;border-top:1px solid var(--line);padding-top:12px"><?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:1fr 2fr 1fr 1fr">
			<label class="fld"><span>Code *</span><input name="code" placeholder="ex. REDUIT" required></label>
			<label class="fld"><span>Libellé *</span><input name="libelle" placeholder="ex. Taux réduit restauration" required></label>
			<label class="fld"><span>Taxe</span><select name="code_taxe"><?php foreach ( $codesTaxe as $k => $lbl ) : ?><option value="<?= e( $k ) ?>"><?= e( $lbl ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Taux (%)</span><input class="num" name="taux" value="18" inputmode="decimal"></label>
		</div>
		<div class="actions"><button class="btn btn-primary">Ajouter la catégorie</button></div>
	</form>
</div></div>

<?php if ( $natures ) : ?>
<div class="card" style="max-width:900px;margin-top:16px"><div class="card-head"><h2>Régime fiscal par prestation — <?= e( $packLabel ) ?></h2></div><div class="card-body">
	<p class="help" style="margin-top:0">
		Chaque nature de prestation peut relever d'un régime différent : l'hébergement, la restauration,
		une taxe de séjour et une prestation exonérée cohabitent sur la même note.
		<strong>Laissé sur « taux normal », rien ne change</strong> — c'est le comportement par défaut.
		Un article qui porte lui-même une catégorie fiscale garde le dernier mot sur la sienne.
	</p>
	<form method="post" action="<?= e( url( 'parametres/fiscalite/natures' ) ) ?>"><?= FKC_Csrf::field() ?>
		<table class="table">
			<thead><tr><th>Prestation</th><th>Catégorie fiscale</th><th class="right">Taux appliqué</th></tr></thead>
			<tbody>
			<?php foreach ( $natures as $n ) : ?>
				<tr>
					<td><?= e( $n['libelle'] ) ?> <span class="muted mono" style="font-size:11px"><?= e( $n['code'] ) ?></span></td>
					<td>
						<select name="nature[<?= e( $n['code'] ) ?>]">
							<option value="0"<?= $n['categorie_id'] ? '' : ' selected' ?>>— taux normal (défaut) —</option>
							<?php foreach ( $categories as $c ) : ?>
								<option value="<?= (int) $c['id'] ?>"<?= (int) $c['id'] === (int) $n['categorie_id'] ? ' selected' : '' ?>><?= e( $c['code'] . ' — ' . $c['libelle'] . ' (' . $c['taux'] . ' %)' ) ?></option>
							<?php endforeach; ?>
						</select>
					</td>
					<td class="right mono"><?= e( rtrim( rtrim( number_format( (float) $n['taux'], 2, ',', ' ' ), '0' ), ',' ) ) ?> %<?php if ( $n['herite'] ) : ?> <span class="muted" style="font-size:11px">(hérité)</span><?php endif; ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<div class="actions"><button class="btn btn-primary">Enregistrer les régimes</button></div>
	</form>
</div></div>
<?php endif; ?>

<div class="card" style="max-width:900px;margin-top:16px"><div class="card-head"><h2>Barème d'annulation — <?= e( $packLabel ) ?></h2></div><div class="card-body">
	<p class="help" style="margin-top:0">
		Combien retenir quand un client annule, selon le délai qui reste avant le début de la prestation.
		<strong>Ce barème ne prélève rien de lui-même</strong> : il fait une suggestion, que la réception
		applique ou non. Laissé vide, aucune suggestion n'apparaît et le montant reste entièrement à la
		main du collaborateur — le fonctionnement d'origine.
	</p>
	<form method="post" action="<?= e( url( 'parametres/fiscalite/bareme' ) ) ?>"><?= FKC_Csrf::field() ?>
		<table class="table">
			<thead><tr><th>À partir de… (heures avant le début)</th><th>Retenue (%)</th></tr></thead>
			<tbody>
			<?php
			/*
			 * Les paliers existants, puis TROIS lignes vides pour en ajouter.
			 * Une ligne laissée vide est simplement ignorée à l'enregistrement.
			 *
			 * LA BORNE EST CALCULÉE AVANT LA BOUCLE, ET C'EST LE CORRECTIF.
			 * La condition s'écrivait « $i < count( $lignes ) + 3 » alors que le
			 * corps de boucle ajoutait un élément à $lignes : PHP réévalue la
			 * condition à chaque tour, l'écart restait donc de trois pour
			 * toujours et la boucle ne se terminait jamais. L'écran mourait sur
			 * un épuisement de mémoire — c'est-à-dire que le paramétrage de la
			 * fiscalité et du barème d'annulation était inatteignable, pour
			 * tous les packs, sans qu'aucun test ne le voie.
			 */
			$lignes = array_slice( array_values( (array) $bareme ), 0, 6 );
			for ( $i = 0; $i < 3; $i++ ) { $lignes[] = array( 'heures' => '', 'retenue_pct' => '' ); }
			foreach ( $lignes as $l ) : ?>
				<tr>
					<td><input class="num" name="palier_heures[]" value="<?= e( $l['heures'] ) ?>" placeholder="ex. 48" inputmode="numeric" style="width:110px"> h</td>
					<td><input class="num" name="palier_pct[]" value="<?= e( $l['retenue_pct'] ) ?>" placeholder="ex. 30" inputmode="decimal" style="width:90px"> %</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="help">
			Exemple lu de haut en bas : « 168 h → 0 % », « 48 h → 30 % », « 0 h → 100 % » signifie
			<em>rien retenu à plus d'une semaine, 30 % entre 48 h et une semaine, la totalité en deçà</em>.
		</p>
		<div class="actions"><button class="btn btn-primary">Enregistrer le barème</button></div>
	</form>
</div></div>
