<?php /** @var string $tab @var array $exercices @var array $clotures @var array $types @var string $annee @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$mois = array( 1=>'Janvier',2=>'Février',3=>'Mars',4=>'Avril',5=>'Mai',6=>'Juin',7=>'Juillet',8=>'Août',9=>'Septembre',10=>'Octobre',11=>'Novembre',12=>'Décembre' ); ?>
<style>.chk{display:flex;align-items:center;gap:8px;font-size:13.5px}.chk input{width:auto}</style>
<?php FKC_View::partial( 'parametres::_adminnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card" style="max-width:760px"><div class="card-head"><h2>Ouvrir un exercice</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">L'ouverture déclare l'exercice et génère l'écriture d'<strong>à-nouveaux</strong> :
		report des soldes de bilan (classes 1 à 5) au premier jour de l'exercice, depuis le dernier jour du précédent.
		<strong>Clôturez d'abord N-1</strong> : sans détermination du résultat, les à-nouveaux ne peuvent pas s'équilibrer,
		et FinaKop refuse désormais de combler l'écart en report à nouveau — ce serait affecter un résultat que
		personne n'a décidé d'affecter.<br>
		Pour prévisualiser les à-nouveaux avant de les écrire, passez par
		<a href="<?= e( url( 'comptabilite/cloture/anouveaux' ) ) ?>">Comptabilité → Clôture → À-nouveaux</a>.</p>
	<p class="help" style="color:#ffb020">Décocher « générer les à-nouveaux » ouvre l'exercice sur une <strong>balance vide</strong> :
		ni capital, ni immobilisations, ni créances, ni trésorerie. Ne le faites que pour un premier exercice
		ou une reprise de bilan par le module de migration.</p>
	<form method="post" action="<?= e( url( 'parametres/exercices/ouvrir' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:1fr 2fr">
			<label class="fld"><span>Année (exercice)</span><input type="number" name="annee" value="<?= e($annee) ?>" min="2000" max="2100" required></label>
			<label class="chk" style="align-self:end;padding-bottom:10px"><input type="checkbox" name="report_an" value="1" checked> Générer les à-nouveaux (report des soldes de bilan N-1)</label>
		</div>
		<div class="actions"><button class="btn btn-primary" type="submit">Ouvrir l'exercice</button></div>
	</form>

	<?php if ( ! empty( $exercices ) ) : ?>
	<table class="table" style="margin-top:14px">
		<thead><tr><th>Exercice</th><th>Ouvert le</th><th>À-nouveaux</th><th>Statut</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $exercices as $ex ) : ?>
			<tr>
				<td><strong><?= e( $ex['annee'] ) ?></strong></td>
				<td class="muted"><?= e( date('d/m/Y', strtotime($ex['date_ouverture'])) ) ?></td>
				<td><?= ! empty( $ex['an_ecriture_id'] ) ? '<span class="modbadge b-on">Générés</span>' : '<span class="muted">—</span>' ?></td>
				<td><?= ! empty( $ex['cloture_annuelle'] ) ? '<span class="modbadge b-off">Clôturé</span>' : '<span class="modbadge b-on">Ouvert</span>' ?></td>
				<td class="right">
					<?php if ( empty( $ex['cloture_annuelle'] ) ) : ?>
					<form method="post" action="<?= e( url( 'parametres/exercices/'.$ex['annee'].'/annuler-ouverture' ) ) ?>" style="display:flex;gap:6px;justify-content:flex-end" onsubmit="return confirm('Annuler l\'ouverture de <?= e($ex['annee']) ?> ? Les à-nouveaux seront supprimés et l\'exercice n\'aura plus de soldes d\'ouverture.')">
						<?= FKC_Csrf::field() ?>
						<input type="text" name="motif" required minlength="10" style="max-width:220px" placeholder="Motif (≥ 10 car.)">
						<button class="btn btn-ghost btn-sm" type="submit">Annuler l'ouverture</button>
					</form>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php endif; ?>
</div></div>

<div class="card" style="max-width:760px;margin-top:16px"><div class="card-head"><h2>Clôturer une période</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">La clôture <strong>verrouille</strong> la période : plus aucune écriture ne peut y être saisie ou modifiée.
		Seules les clôtures <strong>infra-annuelles</strong> se posent ici — la clôture annuelle détermine le résultat,
		exige ses contrôles et engage l'affectation puis l'ouverture de N+1 : elle se fait depuis
		<a href="<?= e( url( 'comptabilite/cloture' ) ) ?>">Comptabilité → Clôture</a>, qui en montre l'état.</p>
	<form method="post" action="<?= e( url( 'parametres/exercices/cloturer' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
			<label class="fld"><span>Type</span>
				<select name="type" id="clType" onchange="document.getElementById('subWrap').style.display=this.value==='annuelle'?'none':'block'">
					<?php foreach ( $types as $k=>$lbl ) : ?><option value="<?= e($k) ?>"><?= e($lbl) ?></option><?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Année (exercice)</span><input type="number" name="annee" value="<?= e($annee) ?>" min="2000" max="2100" required></label>
			<label class="fld" id="subWrap"><span>Période</span>
				<select name="sub">
					<?php for ( $i=1;$i<=12;$i++ ) : ?><option value="<?= $i ?>"><?= e($mois[$i]) ?> (mois <?= $i ?>) · T<?= (int)ceil($i/3) ?> · S<?= $i<=6?1:2 ?></option><?php endfor; ?>
				</select>
			</label>
		</div>
		<p class="help">Pour une clôture trimestrielle/semestrielle, le numéro de période est déduit du mois choisi (T1=1, S1=1…).</p>
		<div class="actions"><button class="btn btn-primary" type="submit" onclick="return confirm('Clôturer et verrouiller cette période ?')">Clôturer la période</button></div>
	</form>
</div></div>

<div class="card card-flush" style="margin-top:16px"><div class="card-head"><h2>Périodes clôturées</h2></div>
	<table class="table">
		<thead><tr><th>Type</th><th>Période</th><th class="right">Résultat</th><th>Clôturée le</th><th></th></tr></thead>
		<tbody>
		<?php if ( ! $clotures ) : ?>
			<tr><td colspan="5" class="muted" style="text-align:center;padding:22px">Aucune période clôturée. Tous les exercices sont ouverts.</td></tr>
		<?php else : foreach ( $clotures as $c ) : ?>
			<tr>
				<td><span class="modbadge b-on"><?= e( $types[ $c['type'] ] ?? $c['type'] ) ?></span></td>
				<td><strong><?= e( $c['libelle'] ) ?></strong><br><span class="muted" style="font-size:12px"><?= e( date('d/m/Y',strtotime($c['periode_debut'])) ) ?> → <?= e( date('d/m/Y',strtotime($c['periode_fin'])) ) ?></span></td>
				<td class="right mono"><?= null!==$c['resultat'] ? e( fkc_money( $c['resultat'] ) ).' F CFA' : '—' ?></td>
				<td class="muted"><?= e( date('d/m/Y',strtotime($c['date_cloture'])) ) ?></td>
				<td class="right">
					<?php if ( ! empty( $c['definitive'] ) ) : ?>
						<span class="modbadge b-off" title="Clôture rendue définitive : elle ne se rouvre plus.">Définitive</span>
					<?php else : ?>
					<form method="post" action="<?= e( url( 'parametres/exercices/'.$c['id'].'/rouvrir' ) ) ?>" style="display:flex;gap:6px;justify-content:flex-end" onsubmit="return confirm('Rouvrir cette période ? La clôture<?= 'annuelle'===$c['type']?' et son écriture de résultat':'' ?> sera supprimée, et la réouverture consignée au journal de clôture.')">
						<?= FKC_Csrf::field() ?>
						<input type="text" name="motif" required minlength="20" style="max-width:260px" placeholder="Motif de la réouverture (≥ 20 car.)">
						<button class="btn btn-ghost btn-sm" type="submit">Rouvrir</button>
					</form>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>
