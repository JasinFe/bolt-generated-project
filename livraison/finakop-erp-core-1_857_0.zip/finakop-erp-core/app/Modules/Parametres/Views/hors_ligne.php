<?php /** @var string $title @var string $poste @var array $blocs @var array $types @var array $series @var array|null $flash */ ?>
<div class="card" style="max-width:960px">
	<div class="card-head"><h2>Mode hors ligne</h2></div>
	<div class="card-body">

		<?php if ( $flash ) : ?>
			<p class="<?= 'ok' === $flash['type'] ? 'msg-ok' : 'msg-err' ?>"><?= e( $flash['msg'] ) ?></p>
		<?php endif; ?>

		<p class="help" style="margin-top:0">
			La caisse peut continuer d'encaisser sans réseau. Les ventes sont conservées sur l'appareil
			puis remontées dès le retour de la connexion.
			<strong>Le reste de FinaKop exige le réseau</strong> — comptabilité, stock, états :
			ces écrans ne fonctionnent pas hors ligne, et c'est délibéré, une saisie comptable
			sans contrôle vaudrait moins que pas de saisie du tout.
		</p>

		<h3 style="font-size:14px;margin:18px 0 6px">Ce poste</h3>
		<p>Identifiant : <code><?= e( $poste ) ?></code></p>
		<p class="help" style="margin-top:0">
			Le poste est rattaché à l'APPAREIL, pas à l'utilisateur : un même caissier peut travailler
			sur deux tablettes, et deux caissiers se relayer sur la même. C'est le matériel qui détient
			un bloc de numéros, sans quoi une relève d'équipe en changerait en pleine session.
		</p>

		<h3 style="font-size:14px;margin:18px 0 6px">Opérations autorisées hors ligne</h3>
		<p>
			<?php foreach ( $types as $t ) : ?><span class="tag"><?= e( $t ) ?></span> <?php endforeach; ?>
			<?php if ( ! $types ) : ?><span class="muted">aucune</span><?php endif; ?>
		</p>
		<p class="help" style="margin-top:0">
			Aucune facture normalisée n'est émise hors ligne : sa certification par la DGI exige un appel
			en ligne. Une vente saisie sans réseau produit un <strong>ticket de caisse</strong> ;
			la facture, si elle est demandée, s'établit à la reconnexion.
		</p>

		<h3 style="font-size:14px;margin:18px 0 6px">Blocs de numéros</h3>
		<p class="help" style="margin-top:0">
			Un poste ne peut créer de pièce hors ligne que dans une plage de numéros qui lui a été
			<strong>réservée à l'avance, en ligne</strong>. Aucun autre poste ne peut recevoir ces
			numéros : deux caisses coupées du réseau ne peuvent donc pas produire la même pièce.
			Pensez à réserver avant une coupure prévue.
		</p>

		<form method="post" action="<?= e( url( 'parametres/hors-ligne/reserver' ) ) ?>" class="row" style="gap:8px;align-items:flex-end;margin:10px 0">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Série</span>
				<select name="serie">
					<?php foreach ( $series as $code => $def ) : ?>
						<option value="<?= e( $code ) ?>"><?= e( $def['label'] ) ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label class="fld"><span>Poste</span><input name="poste" value="<?= e( $poste ) ?>"></label>
			<label class="fld"><span>Nombre</span><input name="taille" type="number" value="100" min="1" max="1000" style="width:90px"></label>
			<button class="btn">Réserver un bloc</button>
		</form>

		<?php if ( $blocs ) : ?>
			<table class="tbl">
				<thead><tr><th>Série</th><th>Poste</th><th>Plage</th><th>Consommé</th><th>Restant</th><th>État</th><th>Réservé le</th></tr></thead>
				<tbody>
				<?php foreach ( $blocs as $b ) :
					$restant = max( 0, (int) $b['rang_fin'] - max( (int) $b['rang_consomme'], (int) $b['rang_debut'] - 1 ) );
					$coul = array( 'ouvert' => 'var(--ok)', 'epuise' => 'var(--muted)', 'perime' => 'var(--warn)' );
				?>
					<tr>
						<td><?= e( $b['serie'] ) ?> <span class="muted"><?= (int) $b['annee'] ?></span></td>
						<td><code><?= e( $b['poste'] ) ?></code></td>
						<td><?= (int) $b['rang_debut'] ?> – <?= (int) $b['rang_fin'] ?></td>
						<td><?= (int) $b['rang_consomme'] >= (int) $b['rang_debut'] ? (int) $b['rang_consomme'] : '—' ?></td>
						<td><strong><?= $restant ?></strong></td>
						<td><span style="color:<?= e( $coul[ $b['statut'] ] ?? 'inherit' ) ?>"><?= e( $b['statut'] ) ?></span></td>
						<td class="muted"><?= e( $b['created_at'] ) ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="help">
				Un bloc partiellement consommé n'est jamais libéré, même ancien : ses numéros servis
				existent déjà en base, et rouvrir la plage produirait deux pièces portant le même numéro.
				Seul un bloc resté vierge plus de 30 jours est récupéré — appareil remplacé, navigateur vidé.
				Les numéros non utilisés d'un bloc laissent un trou dans la séquence : c'est assumé,
				un trou se constate et s'explique, un doublon se subit.
			</p>
		<?php else : ?>
			<p class="muted">Aucun bloc réservé. Sans bloc, ce poste ne peut pas créer de pièce hors ligne.</p>
		<?php endif; ?>

		<h3 style="font-size:14px;margin:18px 0 6px">File d'attente de cet appareil</h3>
		<div id="fkcFileHorsLigne"><p class="muted">Lecture…</p></div>
	</div>
</div>

<script src="<?= e( fkc_asset( 'js/hors-ligne.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>"></script>
<script>
/*
 * La file vit dans le navigateur DE CET APPAREIL : le serveur ne peut pas
 * l'afficher, il ne la voit pas. Cet écran la lit donc côté client — et c'est
 * précisément l'information qui manque le plus après une coupure : ce qui
 * n'est pas encore parti.
 */
(function () {
	var cible = document.getElementById('fkcFileHorsLigne');
	if (!window.FKCHorsLigne || !window.indexedDB) {
		cible.innerHTML = '<p class="muted">Ce navigateur ne prend pas en charge le stockage hors ligne.</p>';
		return;
	}
	function rendre() {
		window.FKCHorsLigne.liste().then(function (ops) {
			if (!ops.length) { cible.innerHTML = '<p class="muted">Rien en attente : tout a été remonté.</p>'; return; }
			var h = '<table class="tbl"><thead><tr><th>Type</th><th>Numéro</th><th>Date</th><th>État</th><th>Motif</th></tr></thead><tbody>';
			ops.forEach(function (o) {
				h += '<tr><td>' + o.type + '</td><td>' + (o.numero || '—') + '</td><td>' + o.date + '</td>'
				   + '<td>' + o.etat + (o.tentatives ? ' (' + o.tentatives + ')' : '') + '</td>'
				   + '<td class="muted">' + (o.motif || '') + '</td></tr>';
			});
			cible.innerHTML = h + '</tbody></table>';
		}).catch(function () {
			cible.innerHTML = '<p class="muted">File illisible sur cet appareil.</p>';
		});
	}
	rendre();
	window.addEventListener('fkc:hors-ligne', rendre);
})();
</script>
