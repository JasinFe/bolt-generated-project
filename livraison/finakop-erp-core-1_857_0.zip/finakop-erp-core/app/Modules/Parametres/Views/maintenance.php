<?php /** @var string $tab @var array $environnement @var array $coherence @var array $sequences @var array $annees @var string $annee @var string $recherche @var array $resultats @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'parametres::_adminnav', array( 'tab' => $tab ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<?php
/*
 * ÉTAT DU SERVEUR (1.772.0) — en tête d'écran, avant les opérations.
 *
 * Une panne sur trois ne vient pas du code mais de la configuration : une
 * extension décochée après un changement de version de PHP, un plafond
 * d'envoi trop bas, l'affichage des erreurs resté actif. Rien ne permettait
 * de le lire depuis l'application ; il fallait ouvrir le cPanel et savoir
 * quoi y chercher.
 */
$envEtats = array( 'ok' => array( 'b-on', '✓' ), 'attention' => array( 'b-warn', '!' ), 'alerte' => array( 'b-err', '✕' ) );
$envAlertes = 0;
foreach ( $environnement as $pt ) { if ( 'ok' !== $pt['etat'] ) { $envAlertes++; } }
?>
<details class="card" <?= $envAlertes ? 'open' : '' ?>>
	<summary class="card-head" style="cursor:pointer"><h2>État du serveur
		<?php if ( $envAlertes ) : ?><span class="modbadge b-warn"><?= (int) $envAlertes ?> point(s) à voir</span>
		<?php else : ?><span class="modbadge b-on">Rien à signaler</span><?php endif; ?></h2></summary>
	<div class="card-body">
		<table class="table">
			<tbody>
			<?php foreach ( $environnement as $pt ) : $b = $envEtats[ $pt['etat'] ] ?? $envEtats['ok']; ?>
				<tr>
					<td style="width:240px"><?= e( $pt['libelle'] ) ?></td>
					<td class="code"><?= e( $pt['valeur'] ) ?></td>
					<td style="width:90px"><span class="modbadge <?= e( $b[0] ) ?>"><?= e( $b[1] ) ?></span></td>
					<td class="muted"><?= e( $pt['conseil'] ) ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="help">Ces réglages appartiennent à l'hébergement : FinaKop les lit, il ne les modifie pas.</p>
	</div>
</details>

<div class="alert alert-warn">⚠️ Ces opérations sont <strong>définitives et irréversibles</strong>. Sauvegardez vos données avant toute suppression. Réservé à l'administrateur.</div>

<?php /* ── Annuler UNE écriture désignée par son numéro ───────────────────── */ ?>
<div class="card maint-card maint-one"><div class="card-head"><h2>🎯 Annuler une écriture précise</h2></div><div class="card-body">

	<form method="post" action="<?= e( url( 'parametres/maintenance/ecriture/rechercher' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:2fr auto">
			<label class="fld"><span>Numéro de pièce, référence ou n° d'écriture</span>
				<input name="numero" value="<?= e( $recherche ?? '' ) ?>" placeholder="ex. VE-2026-0148, FA0032, ou 1274" required autocomplete="off"></label>
			<div class="actions" style="align-self:end"><button class="btn btn-primary" type="submit">Rechercher</button></div>
		</div>
		<p class="help">Pour corriger <strong>une seule</strong> écriture, sans toucher aux autres pièces de la même journée. Le numéro de pièce n'étant pas unique d'un journal ou d'un exercice à l'autre, toutes les correspondances sont listées : désignez celle à traiter.</p>
	</form>

	<?php if ( ! empty( $resultats ) ) : ?>
	<hr class="maint-hr">
	<div class="table-wrap"><table class="table">
		<thead><tr><th>N°</th><th>Date</th><th>Jrnl</th><th>Pièce</th><th>Libellé</th><th style="text-align:right">Montant</th><th>État</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $resultats as $r ) : $a = $r['analyse']; ?>
			<tr>
				<?php /* Numéro comptable si l'écriture en porte un ; l'id technique
				   sinon, en attendant la reprise de numérotation. */ ?>
				<td class="code"><?= ! empty( $r['numero'] ) ? e( $r['numero'] ) : '<span class="muted">#' . (int) $r['id'] . '</span>' ?></td>
				<td><?= e( date( 'd/m/Y', strtotime( $r['date_ecriture'] ) ) ) ?></td>
				<td><?= e( $r['journal_code'] ?? '—' ) ?></td>
				<td><?= e( $r['piece'] ?? '—' ) ?></td>
				<td><?= e( $r['libelle'] ) ?></td>
				<td style="text-align:right;white-space:nowrap"><?= e( fkc_money( (float) $r['total'] ) ) ?></td>
				<td>
					<?php if ( null !== $a['deja_annulee'] ) : ?>
						<span class="pill pill-expired">Déjà annulée (n°<?= (int) $a['deja_annulee'] ?>)</span>
					<?php elseif ( $a['supprimable'] ) : ?>
						<span class="pill">Libre</span>
					<?php else : ?>
						<span class="pill pill-invalid" title="<?= e( implode( ' ', $a['raisons'] ) ) ?>">Rattachée</span>
					<?php endif; ?>
				</td>
				<td style="white-space:nowrap">
					<?php
					/* Revenir sur une contre-passation passée par erreur : proposé
					   uniquement sur les contre-passations, et seulement si elles
					   n'ont pas encore servi. Supprime l'écriture inverse et
					   rebranche les pièces déliées. */
					if ( FKC_EcritureAnnulation::estContrepassation( $r['id'] ) ) : ?>
					<form method="post" action="<?= e( url( 'parametres/maintenance/ecriture/annuler-contrepassation' ) ) ?>" style="display:inline"
					      onsubmit="return confirm('Annuler la contre-passation n°<?= (int) $r['id'] ?> ?\n\nElle sera supprimée et l\'écriture d\'origine redeviendra en vigueur, avec ses pièces rebranchées.')">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
						<input type="hidden" name="q" value="<?= e( $recherche ?? '' ) ?>">
						<button class="btn btn-sm btn-ghost" type="submit" title="Supprime la contre-passation et remet l'écriture d'origine en vigueur">↩ Revenir en arrière</button>
					</form>
					<?php endif; ?>

					<?php if ( $a['contrepassable'] ) : ?>
					<form method="post" action="<?= e( url( 'parametres/maintenance/ecriture/contrepasser' ) ) ?>" style="display:inline"
					      onsubmit="return confirm('Générer l\'écriture inverse de la n°<?= (int) $r['id'] ?> ? L\'écriture d\'origine sera conservée.')">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
						<input type="date" name="date_annulation" value="<?= e( date( 'Y-m-d' ) ) ?>" class="inp-mini" title="Date de la contre-passation">
						<button class="btn btn-sm btn-primary" type="submit">Contre-passer</button>
					</form>
					<?php endif; ?>

					<?php if ( $a['supprimable'] ) : ?>
					<form method="post" action="<?= e( url( 'parametres/maintenance/ecriture/supprimer' ) ) ?>" style="display:inline"
					      onsubmit="return confirm('Effacer DÉFINITIVEMENT l\'écriture n°<?= (int) $r['id'] ?> ? Elle ne laissera aucune trace au grand livre.')">
						<?= FKC_Csrf::field() ?>
						<input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
						<input name="confirm" placeholder="SUPPRIMER" class="inp-mini" autocomplete="off" required>
						<button class="btn btn-sm btn-danger" type="submit">Supprimer</button>
					</form>
					<?php endif; ?>
				</td>
			</tr>
			<?php if ( ! empty( $a['raisons'] ) ) : ?>
			<tr class="row-note"><td colspan="8"><span class="help">⛔ Suppression indisponible : <?= e( implode( ' ', $a['raisons'] ) ) ?> La contre-passation reste possible et laisse l'histoire lisible.</span></td></tr>
			<?php endif; ?>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<p class="help"><strong>Contre-passer</strong> génère une écriture inverse à la date choisie : le solde revient à sa valeur d'avant et la correction reste visible en cas de contrôle. C'est la voie normale.<br>
	<strong>Supprimer</strong> efface la ligne et n'est proposé que si rien ne la référence — ni lettrage, ni facture, ni justificatif, ni période clôturée.</p>
	<?php elseif ( '' !== ( $recherche ?? '' ) ) : ?>
	<hr class="maint-hr">
	<p class="help">Aucune écriture ne correspond à « <?= e( $recherche ) ?> ».</p>
	<?php endif; ?>

</div></div>

<?php
/* ── Cohérence pièces ↔ écritures ─────────────────────────────────────────
   Contrairement au reste de cet écran, cette opération ne supprime rien : elle
   remet en accord les pièces et leurs écritures. Deux divergences sont
   possibles — une pièce comptabilisée dont l'écriture a disparu (purge ou
   suppression d'une version antérieure), et une pièce comptabilisée dont
   l'écriture a été contre-passée. Dans les deux cas la pièce se déclare passée
   alors qu'elle ne l'est plus : elle n'apparaît ni dans « à comptabiliser », ni
   dans les états. */
$coh   = isset( $coherence ) && is_array( $coherence ) ? $coherence : array( 'orphelines' => 0, 'contrepassees' => 0, 'lettrages' => 0, 'detail' => array() );
$cohTotal = (int) $coh['orphelines'] + (int) $coh['contrepassees'] + (int) $coh['lettrages'];
?>
<div class="card maint-card<?= $cohTotal ? ' maint-one' : '' ?>"><div class="card-head"><h2>🧮 Cohérence pièces ↔ écritures</h2></div><div class="card-body">

	<?php if ( 0 === $cohTotal ) : ?>
		<p class="help" style="margin:0">
			<strong style="color:#0a7f3f">✔ Aucune divergence.</strong>
			Chaque facture, reçu, dotation, déclaration ou mouvement marqué « comptabilisé » pointe bien
			vers une écriture existante et non annulée.
		</p>
	<?php else : ?>
		<div class="alert alert-warn" style="margin-top:0">
			<strong><?= (int) $cohTotal ?> divergence(s) détectée(s).</strong>
			Des pièces se déclarent comptabilisées alors que leur écriture a disparu ou a été contre-passée.
			Elles n'apparaissent donc ni dans les listes « à comptabiliser », ni dans les états — et ne peuvent
			pas être repassées.
		</div>
		<table class="table" style="margin-bottom:12px">
			<tbody>
			<?php if ( $coh['orphelines'] ) : ?>
				<tr><td>Références vers une écriture supprimée</td><td class="num"><strong><?= (int) $coh['orphelines'] ?></strong></td></tr>
			<?php endif; ?>
			<?php if ( $coh['contrepassees'] ) : ?>
				<tr><td>Pièces rattachées à une écriture contre-passée</td><td class="num"><strong><?= (int) $coh['contrepassees'] ?></strong></td></tr>
			<?php endif; ?>
			<?php if ( $coh['lettrages'] ) : ?>
				<tr><td>Lettrages portant sur une écriture annulée</td><td class="num"><strong><?= (int) $coh['lettrages'] ?></strong></td></tr>
			<?php endif; ?>
			</tbody>
		</table>
		<?php if ( ! empty( $coh['detail'] ) ) : ?>
			<p class="help">Détail : <?= e( implode( ' · ', $coh['detail'] ) ) ?>.</p>
		<?php endif; ?>
		<form method="post" action="<?= e( url( 'parametres/maintenance/coherence' ) ) ?>"
			onsubmit="return confirm('Remettre ces pièces à comptabiliser et retirer les lettrages devenus vides ?\n\nAucune écriture ne sera supprimée.')">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-primary btn-sm">Corriger les <?= (int) $cohTotal ?> divergence(s)</button>
		</form>
		<p class="help" style="margin-top:8px">
			Les pièces reviennent à leur statut d'avant comptabilisation et redeviennent repassables.
			<strong>Aucune écriture n'est supprimée.</strong> L'opération est journalisée et peut être relancée sans risque.
		</p>
	<?php endif; ?>

</div></div>

<?php
/* ── Numérotation des écritures ───────────────────────────────────────────
   Format AAnnnnnn, propre à chaque journal et à chaque exercice : la première
   écriture du journal des achats de 2026 porte 26000001, et celle du journal
   des opérations diverses porte AUSSI 26000001. Une suite doit être continue :
   ce bloc signale les trous plutôt que de les masquer. */
$seq = isset( $sequences ) && is_array( $sequences ) ? $sequences : array( 'series' => array(), 'trous' => 0, 'doublons' => 0, 'desordres' => 0, 'sans_numero' => 0 );
$seqAnomalies = (int) $seq['trous'] + (int) $seq['doublons'] + (int) $seq['desordres'];
?>
<div class="card maint-card<?= ( $seq['sans_numero'] || $seqAnomalies ) ? ' maint-one' : '' ?>">
	<div class="card-head"><h2>🔢 Numérotation des écritures</h2>
		<span class="muted" style="margin-left:auto">format <code>AAnnnnnn</code> — ex. <code>26000001</code></span>
	</div>
	<div class="card-body">

		<?php if ( $seq['sans_numero'] ) : ?>
			<div class="alert alert-warn" style="margin-top:0">
				<strong><?= (int) $seq['sans_numero'] ?> écriture(s) sans numéro.</strong>
				Elles datent d'avant la numérotation par journal. La reprise leur attribue un numéro
				<strong>dans l'ordre chronologique</strong>, journal par journal et exercice par exercice.
			</div>
			<form method="post" action="<?= e( url( 'parametres/maintenance/numeroter' ) ) ?>"
				onsubmit="return confirm('Numéroter les écritures existantes ?\n\nAucune écriture n\'est modifiée par ailleurs, et l\'opération peut être relancée sans risque.')">
				<?= FKC_Csrf::field() ?>
				<button class="btn btn-primary btn-sm">Numéroter les <?= (int) $seq['sans_numero'] ?> écriture(s)</button>
			</form>
		<?php elseif ( ! $seq['series'] ) : ?>
			<p class="muted" style="margin:0">Aucune écriture comptabilisée pour le moment.</p>
		<?php else : ?>
			<p class="help" style="margin-top:0">
				<?php if ( 0 === $seqAnomalies ) : ?>
					<strong style="color:#0a7f3f">✔ Toutes les suites sont continues</strong> et suivent l'ordre des dates.
				<?php else : ?>
					<strong style="color:#b32d2e">⚠ <?= (int) $seqAnomalies ?> anomalie(s)</strong> —
					<?= (int) $seq['trous'] ?> trou(s), <?= (int) $seq['doublons'] ?> doublon(s), <?= (int) $seq['desordres'] ?> rupture(s) de chronologie.
				<?php endif; ?>
			</p>
			<table class="table" style="margin-top:10px">
				<thead><tr><th>Journal</th><th>Exercice</th><th class="num">Écritures</th><th>Premier</th><th>Dernier</th><th>État</th></tr></thead>
				<tbody>
				<?php foreach ( $seq['series'] as $s ) : ?>
					<tr>
						<td><span class="code"><?= e( $s['journal'] ) ?></span></td>
						<td><?= e( $s['annee'] ) ?></td>
						<td class="num"><?= (int) $s['nombre'] ?></td>
						<td class="code"><?= e( $s['premier'] ) ?></td>
						<td class="code"><?= e( $s['dernier'] ) ?></td>
						<td>
						<?php if ( ! $s['trous'] && ! $s['doublons'] && ! $s['desordres'] ) : ?>
							<span style="color:#0a7f3f">continue</span>
						<?php else : ?>
							<span style="color:#b32d2e">
							<?php if ( $s['trous'] ) : ?><?= (int) $s['trous'] ?> trou(s)<?php endif; ?>
							<?php if ( $s['doublons'] ) : ?> · <?= (int) $s['doublons'] ?> doublon(s)<?php endif; ?>
							<?php if ( $s['desordres'] ) : ?> · <?= (int) $s['desordres'] ?> hors chronologie<?php endif; ?>
							</span>
							<?php if ( ! empty( $s['exemples'] ) ) : ?>
								<span class="muted"> (<?= e( implode( ', ', $s['exemples'] ) ) ?><?= $s['trous'] > count( $s['exemples'] ) ? '…' : '' ?>)</span>
							<?php endif; ?>
						<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<?php if ( $seq['trous'] ) : ?>
				<p class="help">
					Un trou provient d'une écriture supprimée ou d'une période purgée. Il n'est pas rebouché :
					réattribuer un numéro déjà utilisé serait plus grave que le trou lui-même. Ces suppressions
					sont tracées dans le journal de sécurité.
				</p>
			<?php endif; ?>
			<form method="post" action="<?= e( url( 'parametres/maintenance/recaler-sequences' ) ) ?>" style="margin-top:8px">
				<?= FKC_Csrf::field() ?>
				<button class="btn btn-ghost btn-sm" title="Aligne les compteurs sur le plus haut numéro réellement attribué">Recaler les compteurs</button>
			</form>
		<?php endif; ?>
	</div>
</div>

<div class="maint-grid">

	<div class="card maint-card"><div class="card-head"><h2>🗑️ Supprimer les écritures d'une période</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'parametres/maintenance/ecritures' ) ) ?>" onsubmit="return confirm('Supprimer définitivement toutes les écritures de cette période ?')">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Du</span><input type="date" name="debut" required></label>
				<label class="fld"><span>Au</span><input type="date" name="fin" required></label>
			</div>
			<p class="help">Supprime les écritures comptables (et leurs lignes) sur la plage. Les pièces liées (factures, règlements) sont conservées mais leur lien comptable est retiré.</p>
			<div class="actions"><button class="btn btn-danger" type="submit">Supprimer les écritures</button></div>
		</form>
	</div></div>

	<div class="card maint-card"><div class="card-head"><h2>🧾 Supprimer les factures d'une période</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'parametres/maintenance/factures' ) ) ?>" onsubmit="return confirm('Supprimer définitivement les factures clients de cette période ?')">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Du</span><input type="date" name="debut" required></label>
				<label class="fld"><span>Au</span><input type="date" name="fin" required></label>
			</div>
			<label class="chk"><input type="checkbox" name="aussi_ecritures" value="1"> Supprimer aussi les écritures comptables liées</label>
			<div class="actions"><button class="btn btn-danger" type="submit">Supprimer les factures clients</button></div>
		</form>
		<hr class="maint-hr">
		<form method="post" action="<?= e( url( 'parametres/maintenance/achats' ) ) ?>" onsubmit="return confirm('Supprimer définitivement les factures fournisseurs de cette période ?')">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Du</span><input type="date" name="debut" required></label>
				<label class="fld"><span>Au</span><input type="date" name="fin" required></label>
			</div>
			<label class="chk"><input type="checkbox" name="aussi_ecritures" value="1"> Supprimer aussi les écritures liées</label>
			<div class="actions"><button class="btn btn-danger" type="submit">Supprimer les factures fournisseurs</button></div>
		</form>
	</div></div>

	<div class="card maint-card"><div class="card-head"><h2>♻️ Réinitialiser un exercice complet</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'parametres/maintenance/reset-exercice' ) ) ?>" onsubmit="return confirm('Réinitialiser TOUT l\'exercice sélectionné ? Cette action est irréversible.')">
			<?= FKC_Csrf::field() ?>
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Exercice</span><select name="annee" id="resetYear"><?php foreach ( $annees as $y ) : ?><option value="<?= e($y) ?>"><?= e($y) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Confirmer (saisir l'année)</span><input name="confirm" placeholder="ex. <?= e($annee) ?>" required></label>
			</div>
			<p class="help">Supprime <strong>toutes les pièces de l'année</strong> : écritures, factures clients &amp; fournisseurs, règlements, clôtures, bulletins de paie et dotations. <strong>Conserve</strong> le plan comptable, les journaux, les divisions, les comptes de trésorerie, les tiers et les paramètres.</p>
			<div class="actions"><button class="btn btn-danger" type="submit">Réinitialiser l'exercice</button></div>
		</form>
	</div></div>

	<div class="card maint-card maint-danger"><div class="card-head"><h2>💣 Purge totale des transactions</h2></div><div class="card-body">
		<form method="post" action="<?= e( url( 'parametres/maintenance/purge-tout' ) ) ?>" onsubmit="return confirm('SUPPRIMER TOUTES LES TRANSACTIONS de cette entité, toutes années confondues ?')">
			<?= FKC_Csrf::field() ?>
			<p class="help" style="margin-top:0">Efface <strong>toutes les transactions</strong> de l'entité active (toutes années). Le paramétrage (plan comptable, journaux, divisions, trésorerie, clients, fournisseurs, employés) est conservé. À utiliser pour repartir d'une comptabilité vierge.</p>
			<label class="fld"><span>Confirmer en saisissant <strong>SUPPRIMER</strong></span><input name="confirm" placeholder="SUPPRIMER" required></label>
			<div class="actions"><button class="btn btn-danger" type="submit">Tout supprimer</button></div>
		</form>
	</div></div>

</div>
<style>
.maint-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start}
.maint-card .card-head h2{font-size:15px}
.maint-danger{border-color:var(--danger)}
.maint-hr{border:none;border-top:1px solid var(--line);margin:16px 0}
.chk{display:flex;align-items:center;gap:8px;font-size:13.5px;margin:4px 0}.chk input{width:auto}
.btn-danger{background:var(--danger);border-color:var(--danger);color:#fff}
.btn-danger:hover{filter:brightness(1.08)}
.maint-one{margin-bottom:16px}
.maint-one .table td{vertical-align:middle}
.inp-mini{width:auto;display:inline-block;padding:4px 8px;font-size:12.5px;margin-right:4px}
.row-note td{padding-top:0;border-top:none}
@media(max-width:900px){.maint-grid{grid-template-columns:1fr}}
</style>
