<?php
/**
 * PARAMÈTRES → TERMINAUX → CONTENUS PROMOTIONNELS (Phase 3, 1.814.0).
 *
 * L'établissement choisit CE QU'IL MET EN AVANT ; la borne décide COMMENT
 * (mise en page, couleurs, animation). Du texte et une photo, jamais de
 * mise en forme libre.
 *
 * @var array $promos @var array|null $edit @var array $emplacements @var array $packsEquipes
 * @var array $articles [pack => [ {id, libelle, categorie} ]] @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$edit = $edit ?: null;
$v = function ( $k, $def = '' ) use ( $edit ) { return $edit ? (string) ( $edit[ $k ] ?? $def ) : $def; };
$packEdit = $v( 'pack' );
$libPack = function ( $p ) {
	$g = class_exists( 'FKC_Packs' ) ? FKC_Packs::get( (string) $p ) : null;
	return is_array( $g ) && ! empty( $g['label'] ) ? (string) $g['label'] : ucfirst( (string) $p );
};
$couleursEtat = array( 'à l\'écran' => 'var(--ok)', 'programmé' => 'var(--warn)', 'terminé' => 'var(--muted)', 'désactivé' => 'var(--muted)' );
?>
<div class="page-stack" style="max-width:1000px">

<p style="margin:0"><a href="<?= e( url( 'parametres/terminaux' ) ) ?>">← Terminaux</a></p>

<?php if ( $flash ) : ?>
	<div class="alert alert-<?= 'ok' === $flash['type'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>📣 Contenus promotionnels des bornes</h2></div>
	<div class="card-body">
		<p class="help" style="margin-top:0">
			Le plat du jour, l'offre de la semaine, une nouveauté : chaque contenu défile sur <strong>l'écran d'attente</strong>
			des bornes et/ou <strong>en haut de la carte</strong>. S'il est lié à un article, le client le touche pour le commander
			directement. <?= (int) FKC_TerminalPromo::MAX_AFFICHES ?> contenus au plus sont montrés à la fois, dans l'ordre ci-dessous.
		</p>
		<?php if ( ! $promos ) : ?>
			<p class="muted">Aucun contenu pour le moment. Créez le premier ci-dessous.</p>
		<?php else : ?>
		<table class="table">
			<thead><tr><th style="width:74px"></th><th>Contenu</th><th>Bornes</th><th>Période</th><th>État</th><th style="text-align:right">Actions</th></tr></thead>
			<tbody>
			<?php foreach ( $promos as $i => $p ) : $etat = FKC_TerminalPromo::etat( $p ); ?>
				<tr<?= $edit && (int) $edit['id'] === (int) $p['id'] ? ' style="background:var(--panel2)"' : '' ?>>
					<td>
						<?php if ( FKC_TerminalPromo::imageChemin( $p ) ) : ?>
							<img src="<?= e( url( 'parametres/terminaux/promos/' . (int) $p['id'] . '/image' ) ) ?>?v=<?= e( substr( md5( (string) $p['image'] ), 0, 8 ) ) ?>" alt="" style="width:64px;height:40px;object-fit:cover;border-radius:6px;display:block">
						<?php else : ?><span style="display:grid;place-items:center;width:64px;height:40px;border-radius:6px;background:var(--panel2)">📣</span><?php endif; ?>
					</td>
					<td><strong><?= e( $p['titre'] ) ?></strong>
						<?php if ( '' !== (string) $p['texte'] ) : ?><div class="muted" style="font-size:12px"><?= e( $p['texte'] ) ?></div><?php endif; ?>
						<?php if ( ! empty( $p['article_id'] ) && ! empty( $p['pack'] ) ) :
							$fkcLib = '';
							foreach ( (array) ( $articles[ $p['pack'] ] ?? array() ) as $a ) { if ( (int) $a['id'] === (int) $p['article_id'] ) { $fkcLib = $a['libelle']; } } ?>
							<div style="font-size:12px"><?= '' !== $fkcLib ? '→ ' . e( $fkcLib ) : '<span style="color:var(--warn)">→ article retiré du catalogue : le contenu s\'affiche sans bouton</span>' ?></div>
						<?php endif; ?>
					</td>
					<td style="font-size:13px"><?= e( ! empty( $p['pack'] ) ? $libPack( $p['pack'] ) : 'Toutes' ) ?><div class="muted" style="font-size:12px"><?= e( $emplacements[ $p['emplacement'] ] ?? '' ) ?></div></td>
					<td style="font-size:13px;white-space:nowrap">
						<?php if ( empty( $p['debut'] ) && empty( $p['fin'] ) ) : ?><span class="muted">permanente</span>
						<?php else : ?><?= ! empty( $p['debut'] ) ? 'du ' . e( date( 'd/m/Y', strtotime( $p['debut'] ) ) ) : '' ?><?= ! empty( $p['fin'] ) ? '<br>au ' . e( date( 'd/m/Y', strtotime( $p['fin'] ) ) ) : '' ?><?php endif; ?>
					</td>
					<td><span style="font-size:12px;font-weight:600;color:<?= $couleursEtat[ $etat ] ?? 'inherit' ?>"><?= e( $etat ) ?></span></td>
					<td style="text-align:right;white-space:nowrap">
						<form method="post" style="display:inline"><?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
							<button class="btn btn-ghost btn-sm" name="action" value="monter" title="Monter" <?= 0 === $i ? 'disabled' : '' ?>>↑</button>
							<button class="btn btn-ghost btn-sm" name="action" value="descendre" title="Descendre" <?= count( $promos ) - 1 === $i ? 'disabled' : '' ?>>↓</button>
							<button class="btn btn-ghost btn-sm" name="action" value="basculer"><?= ! empty( $p['actif'] ) ? 'Désactiver' : 'Activer' ?></button>
						</form>
						<a class="btn btn-ghost btn-sm" href="?edit=<?= (int) $p['id'] ?>#fkc-promo-form">Modifier</a>
						<form method="post" style="display:inline" onsubmit="return confirm('Supprimer ce contenu ? Il quitte immédiatement les bornes.')"><?= FKC_Csrf::field() ?>
							<input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><button class="btn btn-ghost btn-sm" name="action" value="supprimer">✕</button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php endif; ?>
	</div>
</div>

<div class="card" id="fkc-promo-form">
	<div class="card-head"><h2><?= $edit ? 'Modifier « ' . e( $edit['titre'] ) . ' »' : 'Nouveau contenu' ?></h2></div>
	<div class="card-body">
		<form method="post" enctype="multipart/form-data" style="display:grid;gap:12px"><?= FKC_Csrf::field() ?>
			<input type="hidden" name="action" value="enregistrer"><input type="hidden" name="id" value="<?= $edit ? (int) $edit['id'] : 0 ?>">
			<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
				<label>Titre <span class="muted">(<?= (int) FKC_TerminalPromo::TITRE_MAX ?> car. max)</span>
					<input name="titre" required maxlength="<?= (int) FKC_TerminalPromo::TITRE_MAX ?>" value="<?= e( $v( 'titre' ) ) ?>" placeholder="Ex. Plat du jour : poulet braisé" style="width:100%"></label>
				<label>Texte <span class="muted">(<?= (int) FKC_TerminalPromo::TEXTE_MAX ?> car. max)</span>
					<input name="texte" maxlength="<?= (int) FKC_TerminalPromo::TEXTE_MAX ?>" value="<?= e( $v( 'texte' ) ) ?>" placeholder="Ex. Servi avec attiéké, jusqu'à épuisement" style="width:100%"></label>
			</div>
			<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
				<label>Bornes
					<select name="pack" id="fkc-promo-pack" style="width:100%">
						<option value="">Toutes les bornes</option>
						<?php foreach ( $packsEquipes as $pk ) : ?><option value="<?= e( $pk ) ?>" <?= $pk === $packEdit ? 'selected' : '' ?>><?= e( $libPack( $pk ) ) ?> seulement</option><?php endforeach; ?>
					</select></label>
				<label>Emplacement
					<select name="emplacement" style="width:100%">
						<?php foreach ( $emplacements as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $k === $v( 'emplacement', 'partout' ) ? 'selected' : '' ?>><?= e( $lib ) ?></option><?php endforeach; ?>
					</select></label>
				<label>Article mis en avant
					<?php foreach ( $packsEquipes as $pk ) : ?>
						<select name="article_<?= e( $pk ) ?>" class="fkc-promo-art" data-pack="<?= e( $pk ) ?>" style="width:100%<?= $pk === $packEdit ? '' : ';display:none' ?>">
							<option value="">— aucun (information seule) —</option>
							<?php $fkcCat = null; foreach ( (array) ( $articles[ $pk ] ?? array() ) as $a ) :
								if ( $a['categorie'] !== $fkcCat ) { if ( null !== $fkcCat ) { echo '</optgroup>'; } $fkcCat = $a['categorie']; echo '<optgroup label="' . e( '' !== $fkcCat ? $fkcCat : 'Catalogue' ) . '">'; } ?>
								<option value="<?= (int) $a['id'] ?>" <?= $pk === $packEdit && (int) $a['id'] === (int) $v( 'article_id', '0' ) ? 'selected' : '' ?>><?= e( $a['libelle'] ) ?></option>
							<?php endforeach; if ( null !== $fkcCat ) { echo '</optgroup>'; } ?>
						</select>
					<?php endforeach; ?>
					<span class="muted fkc-promo-art-aide" style="font-size:12px<?= '' === $packEdit ? '' : ';display:none' ?>">Choisissez d'abord les bornes d'un métier pour lier un article.</span>
				</label>
			</div>
			<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;align-items:end">
				<label>Du <span class="muted">(facultatif)</span><input type="date" name="debut" value="<?= e( $v( 'debut' ) ) ?>" style="width:100%"></label>
				<label>Au <span class="muted">(inclus, facultatif)</span><input type="date" name="fin" value="<?= e( $v( 'fin' ) ) ?>" style="width:100%"></label>
				<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="actif" value="1" style="width:auto;flex:none;margin:0" <?= ! $edit || ! empty( $edit['actif'] ) ? 'checked' : '' ?>> Afficher sur les bornes</label>
			</div>
			<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
				<?php if ( $edit && FKC_TerminalPromo::imageChemin( $edit ) ) : ?>
					<img src="<?= e( url( 'parametres/terminaux/promos/' . (int) $edit['id'] . '/image' ) ) ?>?v=<?= e( substr( md5( (string) $edit['image'] ), 0, 8 ) ) ?>" alt="" style="width:160px;height:90px;object-fit:cover;border-radius:8px">
				<?php endif; ?>
				<label style="flex:1;min-width:240px">Photo <span class="muted">(paysage conseillé · PNG, JPEG ou WebP · 3 Mo max)</span>
					<input type="file" name="image" accept="image/png,image/jpeg,image/webp" style="width:100%"></label>
			</div>
			<div style="display:flex;gap:8px">
				<button class="btn btn-primary"><?= $edit ? 'Enregistrer' : 'Créer le contenu' ?></button>
				<?php if ( $edit ) : ?><a class="btn btn-ghost" href="<?= e( url( 'parametres/terminaux/promos' ) ) ?>">Annuler</a><?php endif; ?>
			</div>
		</form>
		<?php if ( $edit && FKC_TerminalPromo::imageChemin( $edit ) ) : ?>
			<form method="post" style="margin-top:8px"><?= FKC_Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">
				<button class="btn btn-ghost btn-sm" name="action" value="image_retirer">Retirer la photo</button></form>
		<?php endif; ?>
	</div>
</div>
</div>
<script>
/* Un sélecteur d'articles par métier : on montre celui des bornes visées. */
(function () {
	var sel = document.getElementById('fkc-promo-pack');
	if (!sel) { return; }
	function maj() {
		document.querySelectorAll('.fkc-promo-art').forEach(function (s) { s.style.display = s.getAttribute('data-pack') === sel.value ? '' : 'none'; });
		var aide = document.querySelector('.fkc-promo-art-aide');
		if (aide) { aide.style.display = sel.value ? 'none' : ''; }
	}
	sel.addEventListener('change', maj);
	maj();
}());
</script>
