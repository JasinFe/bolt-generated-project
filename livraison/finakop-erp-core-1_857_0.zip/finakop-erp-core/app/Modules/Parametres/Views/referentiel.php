<?php /** @var string $title @var string $tab @var array|null $etat @var array $referentiels @var array $parPack @var array $packs @var mixed $flash */
/** Référentiel comptable du dossier : SYSCOHADA révisé ou SYCEBNL (entités à but non lucratif). */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres', 'backLabel' => 'Paramètres' ) );
$e = $etat ?? null;
?>
<div class="bar"><span><strong>Référentiel comptable</strong></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres' ) ) ?>">← Paramètres</a></div>

<?php if ( ! empty( $flash ) ) : ?><div class="flash"><?= e( is_array( $flash ) ? ( $flash['message'] ?? '' ) : $flash ) ?></div><?php endif; ?>

<?php if ( ! $e ) : ?>
	<div class="card"><div class="card-body"><p class="muted">Moteur de référentiel indisponible sur cette installation.</p></div></div>
<?php else : $r = $e['referentiel']; ?>

<div class="card"><div class="card-body">
	<div style="display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start">
		<div style="flex:1;min-width:280px">
			<div class="muted" style="font-size:12px">Référentiel appliqué à ce dossier</div>
			<div style="font-size:22px;font-weight:700;margin:2px 0 6px"><?= e( $r['icone'] . ' ' . $r['label'] ) ?></div>
			<p style="font-size:13px;margin:0"><?= e( $r['texte'] ) ?></p>
		</div>
		<div style="min-width:220px">
			<div class="muted" style="font-size:12px">Origine du choix</div>
			<div style="font-size:15px;font-weight:600;margin-bottom:8px">
				<?php if ( 'societe' === $e['source'] ) : ?>Fixé pour ce dossier
				<?php elseif ( 'pack' === $e['source'] ) : ?>Déclaré par le pack métier
				<?php else : ?>Valeur par défaut<?php endif; ?>
			</div>
			<div class="muted" style="font-size:12px">Pack actif</div>
			<div style="font-size:14px"><?= e( $e['pack'] ?: '—' ) ?> → <?= e( $e['pack_ref'] ) ?></div>
		</div>
	</div>
</div></div>

<?php if ( ! $e['complet'] ) : ?>
<div class="card" style="margin-top:12px;border-left:3px solid #ffb020"><div class="card-body">
	<strong style="color:#ffb020">Couverture partielle — plan et états attendus au lot 7</strong>
	<p style="font-size:13px;margin:8px 0 0">
		Ce dossier relève du <?= e( $r['label'] ) ?>, mais FinaKop ne tient pas encore ce référentiel ligne à ligne :
		le plan de comptes, les états financiers spécifiques (tableau ressources-emplois, relevé d'exécution
		budgétaire, tableau de rapprochement des fonds) et le système minimal de trésorerie restent à livrer.
	</p>
	<p style="font-size:13px;margin:8px 0 0">
		En attendant, <strong>les écritures continuent d'être émises sur le plan SYSCOHADA</strong> déclaré par les
		schémas des packs. Aucune correspondance n'est inventée à la volée : une traduction approximative
		produirait des liasses fausses sans que personne ne s'en aperçoive. Les comptes concernés sont
		relevés ci-dessous, et devront être repris lors de la bascule.
	</p>
</div></div>
<?php endif; ?>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Choisir le référentiel de ce dossier</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">Par défaut, le dossier suit le référentiel déclaré par son pack métier.
	La surcharge sert aux cas réels où la forme juridique ne suit pas le métier — une structure de développement
	constituée en société, une association qui exerce une activité commerciale accessoire.</p>
	<form method="post" action="<?= e( url( 'parametres/referentiel' ) ) ?>" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
		<?= FKC_Csrf::field() ?>
		<select name="referentiel" class="input" style="max-width:320px">
			<option value=""<?= 'societe' === $e['source'] ? '' : ' selected' ?>>Suivre le pack métier (<?= e( $e['pack_ref'] ) ?>)</option>
			<?php foreach ( $referentiels as $code => $d ) : ?>
				<option value="<?= e( $code ) ?>"<?= ( 'societe' === $e['source'] && $code === $e['code'] ) ? ' selected' : '' ?>>
					<?= e( $d['icone'] . ' ' . $d['label'] ) ?><?= empty( $d['complet'] ) ? ' — couverture partielle' : '' ?>
				</option>
			<?php endforeach; ?>
		</select>
		<button class="btn btn-primary btn-sm" type="submit">Appliquer</button>
	</form>
</div></div>

<?php if ( FKC_Referentiel::estEbnl() ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Plan de comptes SYCEBNL</h2></div><div class="card-body">
	<?php if ( empty( $plan_installe ) ) : ?>
		<p class="help" style="margin-top:0">Le socle de comptes SYCEBNL n'est pas installé sur ce dossier : les écritures
		partent encore sur le plan SYSCOHADA et sont relevées ci-dessous. L'installation pose <?= (int) $plan_total ?> comptes
		et <strong>traduit automatiquement</strong> les comptes émis par les moteurs (cotisations, dons, subventions,
		bailleurs). Aucun compte existant n'est écrasé.</p>
		<form method="post" action="<?= e( url( 'parametres/referentiel/plan' ) ) ?>">
			<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="installer">
			<button class="btn btn-primary btn-sm" type="submit">Installer le plan SYCEBNL</button>
		</form>
	<?php else : ?>
		<p style="margin-top:0"><strong style="color:#3ddc84">Plan installé.</strong>
		<?= (int) $plan_manquants ?> compte(s) du socle absent(s) sur <?= (int) $plan_total ?>.
		Les comptes émis par les moteurs sont désormais traduits vers le SYCEBNL.</p>
		<form method="post" action="<?= e( url( 'parametres/referentiel/plan' ) ) ?>" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="valider">
			<label class="inline"><input type="checkbox" name="valide" value="1"<?= ! empty( $plan_valide ) ? ' checked' : '' ?>>
				Ce plan a été relu et validé par un professionnel</label>
			<button class="btn btn-ghost btn-sm" type="submit">Enregistrer</button>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( 'parametres/referentiel/etats' ) ) ?>">📄 États SYCEBNL</a>
		</form>
		<?php $conflits = FKC_PlanSycebnl::conflits(); if ( $conflits ) : ?>
		<div class="alert alert-err" style="margin-top:12px">
			<strong><?= count( $conflits ) ?> compte(s) déjà mouvementé(s) portent un autre sens en SYCEBNL.</strong>
			Ils n'ont PAS été renommés : changer le libellé d'un compte qui porte des écritures changerait le sens de ce qui
			est déjà passé. C'est une reprise de balance, le travail d'un comptable.
			<table class="table" style="margin-top:8px"><thead><tr><th>Compte</th><th>Libellé actuel</th><th>Sens SYCEBNL</th></tr></thead><tbody>
			<?php foreach ( $conflits as $num => $c ) : ?>
				<tr><td class="code"><?= e( (string) $num ) ?></td><td class="muted"><?= e( $c['actuel'] ) ?></td><td><?= e( $c['sycebnl'] ) ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
		</div>
		<?php endif; ?>
		<p class="help" style="margin:10px 0 0"><strong>Pourquoi cette case.</strong> Le socle livré couvre ce dont les
		moteurs ont besoin ; le plan officiel compte plus de mille comptes, et les subdivisions d'un dossier réel
		appartiennent à son comptable. Tant que la case n'est pas cochée, FinaKop ne présente pas ce dossier comme tenu en
		SYCEBNL — un plan livré par l'éditeur mais jamais vérifié ne rend pas une liasse conforme.</p>
	<?php endif; ?>
</div></div>
<?php endif; ?>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Ce que le SYCEBNL change, poste par poste</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">Repères de lecture, pas une table de conversion : le plan définitif sera
	posé depuis l'Acte uniforme lui-même.</p>
	<table class="table"><thead><tr><th style="width:80px">Racine</th><th>Sens SYSCOHADA</th><th>Ce qu'en dit le SYCEBNL</th></tr></thead><tbody>
	<?php foreach ( $e['reperes'] as $racine => $d ) : ?>
		<tr><td><code><?= e( $racine ) ?></code></td><td class="muted"><?= e( $d[0] ) ?></td><td><?= e( $d[1] ) ?></td></tr>
	<?php endforeach; ?>
	</tbody></table>
</div></div>

<?php if ( $e['anomalies'] ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Comptes à reprendre — <?= (int) $e['occurrences'] ?> occurrence(s)</h2></div><div class="card-body">
	<p class="help" style="margin-top:0">Comptes employés par ce dossier alors qu'ils relèvent du secteur lucratif.
	Chaque ligne est une écriture qui devra être reprise à la bascule.</p>
	<table class="table"><thead><tr><th>Compte</th><th>Occurrences</th><th>Dernière</th><th>Motif</th></tr></thead><tbody>
	<?php foreach ( $e['anomalies'] as $num => $a ) : ?>
		<tr>
			<td><code><?= e( (string) $num ) ?></code></td>
			<td><?= (int) ( $a['n'] ?? 0 ) ?></td>
			<td class="muted"><?= e( (string) ( $a['dernier'] ?? '' ) ) ?></td>
			<td class="muted" style="font-size:13px"><?= e( (string) ( $a['motif'] ?? '' ) ) ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody></table>
	<form method="post" action="<?= e( url( 'parametres/referentiel/oublier' ) ) ?>" style="margin-top:10px"
		onsubmit="return confirm('Remettre le relevé à zéro ? Les écritures déjà passées ne sont pas modifiées.')">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-ghost btn-sm" type="submit">Remettre le relevé à zéro</button>
	</form>
</div></div>
<?php elseif ( ! $e['complet'] ) : ?>
<div class="card" style="margin-top:12px"><div class="card-body">
	<p class="muted" style="margin:0">Aucun compte inadapté relevé pour l'instant sur ce dossier.</p>
</div></div>
<?php endif; ?>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>Référentiel déclaré par les packs métier</h2></div><div class="card-body">
	<?php
	$groupes = array();
	foreach ( $parPack as $code => $ref ) { $groupes[ $ref ][] = $code; }
	ksort( $groupes );
	?>
	<?php foreach ( $groupes as $ref => $codes ) : $d = $referentiels[ $ref ] ?? array( 'icone' => '', 'label' => $ref ); ?>
		<div style="padding:10px 0;border-top:1px solid var(--line)">
			<strong><?= e( $d['icone'] . ' ' . $d['label'] ) ?></strong>
			<span class="muted" style="font-size:13px"> — <?= count( $codes ) ?> pack(s)</span>
			<div class="muted" style="font-size:13px;margin-top:4px">
				<?php
				$labels = array();
				foreach ( $codes as $c ) { $labels[] = $packs[ $c ]['label'] ?? $c; }
				sort( $labels );
				echo e( implode( ' · ', array_slice( $labels, 0, 60 ) ) );
				?>
			</div>
		</div>
	<?php endforeach; ?>
</div></div>

<?php endif; ?>
