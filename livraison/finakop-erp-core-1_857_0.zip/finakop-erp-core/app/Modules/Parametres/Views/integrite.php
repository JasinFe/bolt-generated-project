<?php /** @var string $title @var string $tab @var array $etat @var mixed $flash */ ?>
<?php
/*
 * CENTRE D'INTÉGRITÉ.
 *
 * Deux familles, et une seule allume une pastille — voir FKC_Integrite. La
 * maquette d'origine de cet écran montrait douze contrôles dont huit en
 * orange ou en rouge sur un dossier NEUF. Un écran qui s'allume à moitié dès
 * l'installation n'enseigne qu'une chose : l'ignorer.
 */
$ctls  = (array) ( $etat['controles'] ?? array() );
$anos  = array_values( array_filter( $ctls, function ( $c ) { return 'anomalie' === $c['niveau']; } ) );
$infos = array_values( array_filter( $ctls, function ( $c ) { return 'anomalie' !== $c['niveau']; } ) );
$nbA   = (int) ( $etat['anomalies'] ?? 0 );
?>

<?php if ( ! empty( $flash ) ) : ?>
	<div class="alert <?= 'ok' === ( $flash['type'] ?? '' ) ? 'alert-ok' : 'alert-err' ?>"><?= e( (string) ( $flash['msg'] ?? '' ) ) ?></div>
<?php endif; ?>

<div class="card"><div class="card-head"><h2>Intégrité ERP</h2></div><div class="card-body">
	<?php if ( ! $ctls ) : ?>
		<p class="muted">Aucun contrôle disponible dans ce dossier.</p>
	<?php elseif ( 0 === $nbA ) : ?>
		<p style="font-size:15px;color:#3ddc84;margin-top:0"><strong>Rien à signaler.</strong>
		Les <?= count( $anos ) ?> contrôles bloquants sont à zéro.</p>
	<?php else : ?>
		<p style="font-size:15px;color:#ff6b6b;margin-top:0"><strong><?= $nbA ?> contrôle<?= $nbA > 1 ? 's' : '' ?>
		à traiter</strong> — <?= (int) ( $etat['total_anomalies'] ?? 0 ) ?> cas au total.</p>
	<?php endif; ?>
	<p class="muted" style="font-size:12.5px;margin-bottom:0">
		Un contrôle n'entre ici que s'il vaut <strong>zéro dans un dossier tenu</strong> et se corrige
		en un geste. Les autres sont plus bas, sans pastille : ce sont des états des lieux, pas des
		fautes. Un contrôle dont le module n'est pas installé n'apparaît pas — afficher « 0 prestation
		d'hôtel perdue » dans une supérette rassurerait sur une question qui ne se pose pas.
	</p>
</div></div>

<div class="card" style="margin-top:12px"><div class="card-head"><h2>À traiter</h2></div><div class="card-body">
	<table class="table">
		<thead><tr><th style="width:44px"></th><th>Contrôle</th><th style="width:80px">Cas</th><th style="width:120px"></th></tr></thead>
		<tbody>
		<?php foreach ( $anos as $c ) :
			$n   = $c['n'];
			$err = '' !== (string) $c['erreur'];
			$col = $err ? '#ffb020' : ( $n > 0 ? '#ff6b6b' : '#3ddc84' ); ?>
			<tr>
				<td style="text-align:center;font-size:18px;color:<?= $col ?>">●</td>
				<td>
					<div><?= e( (string) $c['libelle'] ) ?></div>
					<div class="muted" style="font-size:12px"><?= e( (string) $c['note'] ) ?></div>
					<?php if ( $err ) : ?>
						<div style="font-size:12px;color:#ffb020">Contrôle indisponible : <?= e( (string) $c['erreur'] ) ?></div>
					<?php endif; ?>
				</td>
				<td style="font-weight:700;color:<?= $col ?>"><?= $err ? '—' : (int) $n ?></td>
				<td><?php if ( ! $err && $n > 0 ) : ?>
					<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $c['ou'] ) ) ?>">Voir</a>
				<?php endif; ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div></div>

<?php if ( $infos ) : ?>
<div class="card" style="margin-top:12px"><div class="card-head"><h2>Pour information</h2></div><div class="card-body">
	<p class="muted" style="font-size:12.5px;margin-top:0">
		Ces chiffres ne descendent pas d'un geste, et parfois ne doivent pas descendre du tout : un
		arriéré que seule une reprise d'historique réduirait, une limite connue du moteur, ou une
		décision de gestion assumée. Ils sont ici pour être <em>connus</em>, pas pour être éteints.
	</p>
	<table class="table">
		<thead><tr><th>Constat</th><th style="width:80px">Cas</th><th style="width:120px"></th></tr></thead>
		<tbody>
		<?php foreach ( $infos as $c ) : $err = '' !== (string) $c['erreur']; ?>
			<tr>
				<td>
					<div><?= e( (string) $c['libelle'] ) ?></div>
					<div class="muted" style="font-size:12px"><?= e( (string) $c['note'] ) ?></div>
					<?php if ( $err ) : ?>
						<div style="font-size:12px;color:#ffb020">Contrôle indisponible : <?= e( (string) $c['erreur'] ) ?></div>
					<?php endif; ?>
				</td>
				<td style="font-weight:700"><?= $err ? '—' : (int) $c['n'] ?></td>
				<td><?php if ( ! $err && (int) $c['n'] > 0 ) : ?>
					<a class="btn btn-ghost btn-sm" href="<?= e( url( (string) $c['ou'] ) ) ?>">Voir</a>
				<?php endif; ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div></div>
<?php endif; ?>
