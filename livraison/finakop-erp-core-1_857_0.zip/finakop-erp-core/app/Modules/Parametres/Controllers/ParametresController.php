<?php
/** Hub Paramètres : regroupe réglages et personnalisations. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ParametresController {

	public function index() {
		$lic     = FKC_License::resolve();
		$mods    = $lic['modules'] ?? array();
		$isAdmin = FKC_Auth::isAdmin();
		$soc     = FKC_Tenant::current();

		/*
		 * Modules volontairement masqués de la navigation.
		 *
		 * Le masquage de l'Inventaire ne se réglait QUE depuis l'Inventaire
		 * lui-même — c'est-à-dire depuis l'écran qui venait de disparaître. Le
		 * message d'alors conseillait de « saisir directement l'adresse », ce
		 * qui suppose que l'utilisateur l'ait notée. Le réglage se retrouve donc
		 * ici, dans un écran qui ne se masque jamais.
		 */
		$masques = array();
		if ( $isAdmin && class_exists( 'FKC_ArticleBridge' ) && FKC_ArticleBridge::inventaireMasque() ) {
			$masques['inventaire'] = array(
				'label'  => 'Inventaire',
				'icon'   => '📦',
				'raison' => 'Masqué parce qu\'un pack métier couvre le catalogue. Les données et la synchronisation sont intactes : seul l\'accès au menu est retiré.',
				'action' => url( 'inventaire/articles/masquage' ),
			);
		}

		$has = function ( $m ) use ( $mods ) { return in_array( $m, $mods, true ); };

		// Chaque entrée : titre, description, icône, url, dispo.
		$groups = array();

		$groups['Entité & personnalisation'] = array_filter( array(
			$isAdmin && $soc ? array(
				'icon' => '🏢', 'titre' => 'Informations de l\'entité',
				'desc' => 'Raison sociale, sigle, NCC, forme juridique, régime, devise et logo de l\'entité active.',
				'url'  => url( 'societes/' . $soc['id'] . '/modifier' ),
			) : null,
			array(
				'icon' => '🔁', 'titre' => 'Changer d\'entité',
				'desc' => 'Basculer entre les entités gérées par le cabinet.',
				'url'  => url( 'societes' ),
			),
			$isAdmin && $soc ? array(
				'icon' => '🏬', 'titre' => 'Établissements',
				'desc' => 'Succursales et points d\'exploitation de l\'entité active (selon le palier de licence).',
				'url'  => url( 'parametres/etablissements' ),
			) : null,
			$soc ? array(
				'icon' => '📁', 'titre' => 'Documents (GED)',
				'desc' => 'Bibliothèque de documents de l\'entité : contrats, juridique, RH, fiscal…',
				'url'  => url( 'ged' ),
			) : null,
			$isAdmin && class_exists( 'FKC_Packs' ) ? array(
				'icon' => FKC_Packs::active()['icone'] ?? '🧩',
				'titre' => 'Pack métier',
				'desc' => ( 'multi' === ( class_exists( 'FKC_License' ) ? FKC_License::packCode() : '' ) )
					? 'Choisir le vertical métier de l\'entité (BTP, Garage, Clinique, École…).'
					: 'Vertical métier actif : ' . ( FKC_Packs::active()['label'] ?? 'Gestion générale' ) . '.',
				'url'  => url( 'parametres/pack' ),
			) : null,
		) );

		$groups['Facturation & fiscalité'] = array_filter( array(
			$has( 'facturation' ) ? array(
				'icon' => '🧾', 'titre' => 'Facturation électronique (FNE)',
				'desc' => 'Paramètres FNE / DGI : NCC, établissement, point de vente, TVA, message commercial et pied de facture.',
				'url'  => url( 'facturation/fne' ),
			) : null,
			$has( 'fiscalite' ) ? array(
				'icon' => '📊', 'titre' => 'Régime fiscal',
				'desc' => 'Régime d\'imposition de l\'entité (RNI, RSI, microentreprise…) et paramètres associés.',
				'url'  => url( 'fiscalite/regime' ),
			) : null,
		) );

		$groups['Comptabilité'] = array_filter( array(
			$isAdmin && class_exists( 'FKC_Referentiel' ) ? array(
				'icon'  => FKC_Referentiel::get()['icone'],
				'titre' => 'Référentiel comptable',
				'desc'  => 'Corps de règles applicable au dossier : ' . FKC_Referentiel::get()['label']
					. ( FKC_Referentiel::complet() ? '.' : ' — couverture partielle, comptes à reprendre.' ),
				'url'   => url( 'parametres/referentiel' ),
			) : null,
			$has( 'comptabilite' ) ? array(
				'icon' => '📚', 'titre' => 'Plan comptable',
				'desc' => 'Comptes SYSCOHADA : consultation, ajout et personnalisation du plan de comptes.',
				'url'  => url( 'comptabilite/comptes' ),
			) : null,
			$has( 'analytique' ) ? array(
				'icon' => '🧮', 'titre' => 'Divisions analytiques',
				'desc' => 'Sections analytiques (business units, centres de coûts, projets) pour le contrôle de gestion.',
				'url'  => url( 'analytique/divisions' ),
			) : null,
		) );

		$groups['Administration'] = array_filter( array(
			$isAdmin ? array(
				'icon' => '📅', 'titre' => 'Exercices comptables',
				'desc' => 'Ouvrir et clôturer les exercices mensuels, trimestriels, semestriels et annuels.',
				'url'  => url( 'parametres/exercices' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🏦', 'titre' => 'Comptes de trésorerie',
				'desc' => 'Ajouter et gérer les comptes banque, caisse et mobile money.',
				'url'  => url( 'parametres/tresorerie' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🧾', 'titre' => 'Fiscalité & règles du pack',
				'desc' => 'Taux de taxe par catégorie et par prestation, barème d\'annulation. Le taux devient une donnée, plus du code.',
				'url'  => url( 'parametres/fiscalite' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🩺', 'titre' => 'Intégrité ERP',
				'desc' => 'Ce qui ne va pas, en un écran : écritures sans pièce, marchandise livrée non facturée, argent encaissé non rattaché, tâches bloquées.',
				'url'  => url( 'parametres/integrite' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🔄', 'titre' => 'Processus & événements métier',
				'desc' => 'Voir ce qui circule réellement dans FinaKop : événements, chaînes documentaires, file de traitement.',
				'url'  => url( 'parametres/processus' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🧮', 'titre' => 'Écritures métier assistées',
				'desc' => 'Générer les écritures dont le fait générateur relève d\'une décision comptable : provisions, débours, recettes sans facture.',
				'url'  => url( 'parametres/ecritures-assistees' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🔌', 'titre' => 'Audit des intégrations',
				'desc' => 'Voir quelles règles comptables des packs métier sont raccordées à un déclencheur, et lesquelles dorment.',
				'url'  => url( 'parametres/integrations' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🖥️', 'titre' => 'Terminaux',
				'desc' => 'Tablettes, bornes et écrans d\'atelier associés à cet établissement. Ils voient le catalogue public, jamais votre gestion.',
				'url'  => url( 'parametres/terminaux' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🧰', 'titre' => 'Maintenance des données',
				'desc' => 'Supprimer les écritures ou factures d\'une période, réinitialiser un exercice complet.',
				'url'  => url( 'parametres/maintenance' ),
			) : null,
			$isAdmin ? array(
				'icon' => '👤', 'titre' => 'Utilisateurs & accès',
				'desc' => 'Comptes du cabinet, rôles, droits par module et par entité.',
				'url'  => url( 'utilisateurs' ),
			) : null,
			$isAdmin ? array(
				'icon' => '🔑', 'titre' => 'Licence',
				'desc' => 'Édition active, modules inclus et installation d\'une nouvelle clé de licence.',
				'url'  => url( 'licence' ),
			) : null,
		) );

		// Retire les groupes vides.
		$groups = array_filter( $groups, function ( $g ) { return ! empty( $g ); } );

		FKC_View::render( 'parametres::index', array(
			'masques' => $masques,
			'title'   => 'Paramètres',
			'groups'  => $groups,
			'license' => $lic,
			'societe' => $soc,
		) );
	}

	/* ── Établissements de l'entité ── */
	public function etablissements() {
		FKC_View::render( 'parametres::etablissements', array(
			'title'          => 'Établissements',
			'etablissements' => FKC_Etablissement::all(),
			'conso'          => FKC_Etablissement::count(),
			'limit'          => FKC_License::limit( 'etablissements' ),
			'flash'          => $this->flashEtab(),
		) );
	}
	public function etablissementStore() {
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		if ( '' === $code || '' === trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { $this->setFlashEtab( 'Code et libellé requis.' ); }
		elseif ( FKC_Etablissement::codeExists( $code ) ) { $this->setFlashEtab( 'Ce code existe déjà.' ); }
		elseif ( ! FKC_License::within( 'etablissements', FKC_Etablissement::count() ) ) { $this->setFlashEtab( FKC_License::quotaMessage( 'etablissements', 'établissement(s)' ) ); }
		else { FKC_Etablissement::create( $_POST ); $this->setFlashEtab( 'Établissement créé.' ); }
		redirect( 'parametres/etablissements' );
	}
	public function etablissementDelete( $id ) { FKC_Etablissement::delete( $id ); $this->setFlashEtab( 'Établissement supprimé.' ); redirect( 'parametres/etablissements' ); }
	protected function setFlashEtab( $m ) { $_SESSION['__flash_etab'] = $m; }
	protected function flashEtab() { $m = $_SESSION['__flash_etab'] ?? null; unset( $_SESSION['__flash_etab'] ); return $m; }
}
