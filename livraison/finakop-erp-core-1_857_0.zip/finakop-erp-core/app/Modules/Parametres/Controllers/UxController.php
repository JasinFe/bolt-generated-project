<?php
/**
 * BARRE TRANSVERSALE — « + ACTION · 🔎 RECHERCHE · 🔔 ALERTES · 🤖 COPILOT ».
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CE CONTRÔLEUR NE CALCULE RIEN
 *
 * Les quatre moteurs existaient déjà et travaillaient bien — ils n'avaient
 * simplement aucune porte commune :
 *
 *   + ACTION   → FKC_Ux::actionsRapides() + FKC_Actions (registre d'actions)
 *   RECHERCHE  → FKC_ScanContexte::candidats() + le menu résolu
 *   ALERTES    → FKC_Pilotage2::alertes()
 *   COPILOT    → FKC_Assistant::briefing()
 *
 * Ce fichier est du CÂBLAGE : il expose ces quatre moteurs en JSON, sous les
 * mêmes gardes que le reste de l'application. Aucune règle métier n'y vit, et
 * c'est volontaire — une règle écrite ici échapperait aux tests des moteurs.
 *
 * DEUX CHOIX DE CONCEPTION QUI MÉRITENT D'ÊTRE DITS
 *
 * 1. La recherche passe par `FKC_ScanContexte::candidats()` et NON par
 *    `scan/chercher`. La différence est invisible à l'écran et importante
 *    en base : `chercher()` appelle `FKC_Scan::resoudre()`, qui JOURNALISE
 *    une lecture de code. Chaque frappe dans une barre de recherche aurait
 *    donc écrit une ligne dans le journal de scan, rendant celui-ci
 *    inexploitable pour ce à quoi il sert — la traçabilité des gestes réels.
 *
 * 2. Aucun endpoint de cette barre n'ÉCRIT. Les actions d'exécution restent
 *    servies par `cockpit/action` (POST + CSRF + rôle + journal). Dupliquer
 *    ce chemin ici aurait dupliqué ses gardes, donc créé l'occasion d'en
 *    oublier une.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_UxController {

	/**
	 * Garde de capacité — appliquée à CHAQUE point d'entrée.
	 *
	 * L'interface masque déjà les boutons fermés ; cela ne suffit pas. Un
	 * point d'entrée JSON reste appelable à la main, et une capacité qui ne
	 * se défend que dans le gabarit n'est pas une capacité fermée : c'est un
	 * bouton caché. On renvoie donc une réponse honnête — pas une erreur, qui
	 * ferait croire à une panne, mais un refus nommé.
	 */
	protected function exigerCapacite( $code ) {
		if ( class_exists( 'FKC_Ux' ) && ! FKC_Ux::capacite( $code ) ) {
			$this->json( array(
				'ok' => false, 'capacite' => $code,
				'message' => 'Cette fonction n\'est pas activée pour votre licence. Contactez votre partenaire FinaKop.',
			) );
		}
	}

	/* ═══════════════ + ACTION ═══════════════ */

	/** Ce que l'utilisateur peut faire tout de suite. */
	public function actions() {
		$this->exigerCapacite( 'ux.actions' );
		return $this->json( $this->chargeActions() );
	}

	/**
	 * La charge utile, séparée de son envoi.
	 *
	 * `json()` termine la requête — c'est ce qu'on attend d'un point d'entrée,
	 * et c'est ce qui le rendait intestable : un harnais qui l'appelle meurt
	 * avec lui. Construire la charge à part se teste sans sous-processus, et
	 * laisse le point d'entrée pour ce qu'il doit être : trois lignes.
	 */
	public function chargeActions() {
		$out = array();
		foreach ( FKC_Ux::actionsRapides( 8 ) as $a ) {
			$out[] = array(
				'cle'    => (string) ( $a['cle'] ?? '' ),
				'label'  => (string) ( $a['label'] ?? '' ),
				'icone'  => (string) ( $a['icone'] ?? '▸' ),
				'sous'   => (string) ( $a['sous'] ?? '' ),
				'raison' => (string) ( $a['raison'] ?? '' ),
				'source' => (string) ( $a['source'] ?? 'menu' ),
				'url'    => url( (string) ( $a['route'] ?? '' ) ),
			);
		}
		return array( 'ok' => true, 'actions' => $out );
	}

	/* ═══════════════ 🔎 RECHERCHE ═══════════════ */

	/**
	 * Recherche universelle : des ÉCRANS et des ENTITÉS, dans cet ordre.
	 *
	 * L'ordre n'est pas neutre. Quelqu'un qui tape « stock » cherche presque
	 * toujours l'écran ; quelqu'un qui tape « 6154789 » ou « KOUAME » cherche
	 * une entité. Les écrans sont peu nombreux et se filtrent en mémoire :
	 * les proposer d'abord ne coûte rien et évite une requête inutile dans la
	 * moitié des cas.
	 */
	public function recherche() {
		$this->exigerCapacite( 'ux.recherche' );
		return $this->json( $this->chargeRecherche( (string) ( $_GET['q'] ?? '' ) ) );
	}

	/** @see chargeActions() pour la raison de cette séparation. */
	public function chargeRecherche( $requete ) {
		$q = trim( (string) $requete );
		$out = array( 'ok' => true, 'q' => $q, 'ecrans' => array(), 'entites' => array(), 'message' => '' );
		if ( '' === $q ) {
			$out['message'] = 'Tapez un nom, un code, ou le début d\'un écran.';
			return $out;
		}
		if ( function_exists( 'mb_strlen' ) ? mb_strlen( $q ) > 80 : strlen( $q ) > 80 ) {
			$q = function_exists( 'mb_substr' ) ? mb_substr( $q, 0, 80 ) : substr( $q, 0, 80 );
		}

		/* 1. Les écrans du profil UX — palette de commandes. */
		$vus = array();
		$norme = function ( $s ) {
			$s = function_exists( 'fkc_sans_accents' ) ? fkc_sans_accents( (string) $s ) : (string) $s;
			return function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
		};
		$qn = $norme( $q );
		foreach ( array( 'simple', 'pro', 'expert' ) as $mode ) {
			foreach ( FKC_Ux::menu( $mode ) as $e ) {
				if ( isset( $vus[ $e['route'] ] ) ) { continue; }
				$foin = $norme( $e['label'] . ' ' . $e['sous'] . ' ' . $e['route'] );
				if ( false === strpos( $foin, $qn ) ) { continue; }
				$vus[ $e['route'] ] = true;
				$out['ecrans'][] = array(
					'label' => $e['label'], 'icone' => $e['icone'],
					'sous' => $e['sous'], 'url' => url( $e['route'] ),
				);
				if ( count( $out['ecrans'] ) >= 6 ) { break 2; }
			}
		}

		/* 2. Les entités — articles, tiers, pièces… selon ce que les modules
		   ont déclaré comme chercheurs. Aucune écriture, aucun journal. */
		if ( class_exists( 'FKC_ScanContexte' ) ) {
			try {
				foreach ( FKC_ScanContexte::candidats( $q, array(), 8 ) as $c ) {
					$out['entites'][] = array(
						'type'    => (string) ( $c['entite_type'] ?? '' ),
						'id'      => (int) ( $c['id'] ?? 0 ),
						'libelle' => (string) ( $c['libelle'] ?? '' ),
						'sous'    => (string) ( $c['sous_titre'] ?? '' ),
						'code'    => (string) ( $c['code'] ?? '' ),
						'url'     => $this->porteEntite( $c ),
					);
				}
			} catch ( \Throwable $e ) { /* aucun chercheur déclaré : on reste sur les écrans */ }
		}

		/*
		 * 3. LES CONVERSATIONS FINAKOP CONNECT (1.720.0).
		 *
		 * `FKC_ConnectController::recherche()` se documentait depuis sa
		 * livraison comme « alimente aussi la barre transversale » — et la
		 * barre ne l'a jamais appelée. Le moteur de recherche de Connect
		 * était donc construit, routé, et joint par personne : on cherchait
		 * « acompte Konan » dans la barre et l'on ne trouvait pas la
		 * discussion où il en avait été question la veille.
		 *
		 * LE FILTRE D'ACCÈS RESTE CELUI DE CONNECT, jamais un nôtre :
		 * `rechercher()` ne parcourt que les conversations de l'utilisateur,
		 * et une conversation de pièce se juge sur le droit à la pièce. On ne
		 * refait pas ce contrôle ici — le redoubler, c'est le faire diverger.
		 *
		 * TROIS CARACTÈRES AU MINIMUM, ET QUATRE RÉSULTATS AU PLUS : les
		 * conversations de niveau 2 se fouillent en DÉCHIFFRANT message par
		 * message. Lancer cela à la deuxième lettre, à chaque frappe, ferait
		 * payer à tous les dossiers le prix du chiffrement de quelques-uns.
		 */
		if ( class_exists( 'FKC_Connect' ) && class_exists( 'FKC_Connect_Droits' )
			&& FKC_Connect_Droits::serviceActif()
			&& ( function_exists( 'mb_strlen' ) ? mb_strlen( $q ) : strlen( $q ) ) >= 3 ) {
			try {
				foreach ( FKC_Connect::rechercher( $q, null, 4 ) as $c ) {
					$extrait = (string) ( $c['texte'] ?? '' );
					if ( function_exists( 'mb_substr' ) && mb_strlen( $extrait ) > 90 ) {
						$extrait = mb_substr( $extrait, 0, 90 ) . '…';
					} elseif ( strlen( $extrait ) > 90 ) {
						$extrait = substr( $extrait, 0, 90 ) . '…';
					}
					$out['entites'][] = array(
						'type'    => 'connect',
						'id'      => (int) ( $c['conversation_id'] ?? 0 ),
						'libelle' => (string) ( $c['conversation'] ?? 'Conversation' ),
						'sous'    => trim( ( $c['auteur'] ? $c['auteur'] . ' — ' : '' ) . $extrait ),
						'code'    => '',
						'url'     => url( 'connect/conversation/' . (int) ( $c['conversation_id'] ?? 0 ) ),
					);
				}
			} catch ( \Throwable $e ) { /* service indisponible : la barre garde le reste */ }
		}

		if ( ! $out['ecrans'] && ! $out['entites'] ) {
			$out['message'] = 'Rien ne correspond à « ' . $q .' ».';
		}
		return $out;
	}

	/**
	 * Où mène un résultat d'entité.
	 *
	 * On réutilise les portes déclarées par les modules (FKC_ScanNavigation) :
	 * ce sont exactement celles qu'un scan ouvrirait, ce qui garantit qu'un
	 * même objet mène au même écran qu'on l'ait scanné ou cherché. Sans porte
	 * déclarée, on n'invente pas d'adresse — on rend une chaîne vide et
	 * l'interface affiche le résultat sans lien.
	 */
	protected function porteEntite( array $c ) {
		if ( ! class_exists( 'FKC_ScanNavigation' ) ) { return ''; }
		try {
			$p = FKC_ScanNavigation::principale( array(
				'entite_type' => $c['entite_type'] ?? '',
				'entite_id'   => $c['id'] ?? 0,
				'libelle'     => $c['libelle'] ?? '',
			) );
			return $p ? (string) $p['url'] : '';
		} catch ( \Throwable $e ) { return ''; }
	}

	/* ═══════════════ 🔔 ALERTES ═══════════════ */

	/** Les alertes du pack actif, triées par gravité (le moteur s'en charge). */
	public function alertes() {
		$this->exigerCapacite( 'ux.alertes' );
		return $this->json( $this->chargeAlertes() );
	}

	/**
	 * ALERTES ET « À FAIRE », dans le même panneau.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * POURQUOI PAS UN CINQUIÈME BOUTON
	 *
	 * Une barre de quatre gestes se lit d'un coup d'œil ; à cinq, elle devient
	 * une barre d'outils, et l'on cesse de la voir. Surtout, « à faire » et
	 * « alerte » répondent à la même question — QU'EST-CE QUI RÉCLAME MON
	 * ATTENTION ? — et les séparer obligerait à regarder deux endroits pour y
	 * répondre.
	 *
	 * Trois rangs, du plus contraignant au plus informatif :
	 *
	 *   🔴 URGENT       — un seuil franchi, une échéance dépassée. Subi.
	 *   🟠 À FAIRE      — une décision ou un geste qui attend. Choisi.
	 *   🔵 INFORMATION  — bon à savoir, rien à faire.
	 *
	 * La distinction n'est pas cosmétique : l'urgent vient des MOTEURS
	 * (Pilotage2, validations), tandis que l'à-faire vient de ce que
	 * l'utilisateur a laissé ouvert et de l'étape où en est son métier. Mélanger
	 * les deux ferait qu'on ignorerait les deux.
	 */
	public function chargeAlertes() {
		$out = array();
		/* Les règles d'« Alertes intelligentes » sont évaluées au passage (au plus
		   toutes les quinze minutes) : un seuil franchi rejoint la cloche (1.837.0). */
		if ( class_exists( 'FKC_Alerte' ) && FKC_Modules::featureEnabled( 'analyse.alertes' ) ) {
			try { FKC_Alerte::notifierSiDu(); } catch ( \Throwable $e ) {}
		}
		foreach ( FKC_UxContexte::alertes( 12 ) as $a ) {
			$action = $a['action'] ?? null;
			// « action » vaut tantôt une route, tantôt un libellé de bouton
			// selon les packs. On ne fabrique un lien que si c'est une route
			// réellement servie — sinon l'alerte reste informative.
			$url = '';
			if ( is_string( $action ) && '' !== $action && class_exists( 'FKC_Router' ) && FKC_Router::connue( $action ) ) {
				$url = url( $action );
			}
			$out[] = array(
				'cle'     => (string) ( $a['cle'] ?? '' ),
				'niveau'  => (string) ( $a['niveau'] ?? 'warn' ),
				'libelle' => (string) ( $a['libelle'] ?? '' ),
				'message' => (string) ( $a['message'] ?? '' ),
				'url'     => $url,
			);
		}
		return array(
			'ok' => true,
			'alertes' => $out,
			'afaire' => $this->chargeAFaire(),
			'compteurs' => FKC_UxContexte::compteurAlertes(),
			'validations' => (int) ( FKC_UxContexte::workflows()['validations'] ?? 0 ),
		);
	}

	/**
	 * Ce qui attend un geste — le rang « À FAIRE ».
	 *
	 * Trois sources, et rien d'autre : ce qui attend une DÉCISION (validations),
	 * ce que le contexte a repéré (une caisse restée ouverte le soir), et
	 * l'étape suivante du workflow métier.
	 *
	 * On ne fabrique pas de tâches. Une liste « à faire » qui invente des
	 * choses à faire devient un bruit qu'on apprend à ignorer, et elle emporte
	 * avec elle la crédibilité des alertes qui, elles, comptent.
	 */
	public function chargeAFaire() {
		$out = array();
		if ( class_exists( 'FKC_Ux' ) && ! FKC_Ux::capacite( 'ux.afaire' ) ) { return $out; }

		$wf = FKC_UxContexte::workflows();
		if ( ! empty( $wf['validations'] ) ) {
			$out[] = array(
				'cle' => 'validations', 'icone' => '✔️',
				'label' => (int) $wf['validations'] . ' élément(s) à valider',
				'sous' => 'En attente de votre décision',
				'url' => FKC_Router::connue( 'validations' ) ? url( 'validations' ) : '',
			);
		}

		foreach ( FKC_UxContexte::suggestions() as $s ) {
			if ( ! FKC_Router::connue( $s['route'] ) ) { continue; }
			$out[] = array(
				'cle' => (string) $s['cle'], 'icone' => (string) $s['icone'],
				'label' => (string) $s['label'], 'sous' => (string) $s['raison'],
				'url' => url( (string) $s['route'] ),
			);
		}

		return $out;
	}

	/* ═══════════════ 🤖 COPILOT ═══════════════ */

	/**
	 * Le briefing de l'Assistant, enrichi du contexte.
	 *
	 * L'Assistant sait déjà composer un résumé et une recommandation à partir
	 * des faits du pack. Ce qui lui manquait, c'est le MOMENT : « votre caisse
	 * est encore ouverte » n'a de sens qu'à dix-neuf heures.
	 */
	public function copilot() {
		$this->exigerCapacite( 'ux.copilot' );
		return $this->json( $this->chargeCopilot() );
	}

	/** @see chargeActions() pour la raison de cette séparation. */
	public function chargeCopilot() {
		$u = FKC_Auth::user();
		$nom = trim( (string) ( $u['nom_complet'] ?? '' ) );
		$prenom = trim( (string) strtok( $nom, ' ' ) );

		$brief = null;
		if ( class_exists( 'FKC_Assistant' ) ) {
			try { $brief = FKC_Assistant::briefing( $prenom ); }
			catch ( \Throwable $e ) { $brief = null; }
		}
		if ( ! $brief ) {
			$brief = array(
				'salutation' => 'Bonjour' . ( $prenom ? ' ' . $prenom : '' ),
				'date' => '', 'resume' => "Le copilote n'a pas de données à analyser pour le moment.",
				'points' => array(), 'recommandation' => '', 'score' => null, 'humeur' => 'serein',
			);
		}

		$sugg = array();
		foreach ( FKC_UxContexte::suggestions() as $s ) {
			if ( class_exists( 'FKC_Router' ) && ! FKC_Router::connue( $s['route'] ) ) { continue; }
			$sugg[] = array(
				'label' => (string) $s['label'], 'icone' => (string) $s['icone'],
				'raison' => (string) $s['raison'], 'url' => url( (string) $s['route'] ),
			);
		}

		$points = array();
		foreach ( (array) ( $brief['points'] ?? array() ) as $pt ) {
			$points[] = array(
				'niveau' => (string) ( $pt['niveau'] ?? 'info' ),
				'texte'  => (string) ( $pt['texte'] ?? '' ),
				'url'    => ! empty( $pt['url'] ) ? url( (string) $pt['url'] ) : '',
			);
		}

		$kpis = array();
		if ( class_exists( 'FKC_UxKpi' ) ) {
			foreach ( FKC_UxKpi::resolus( true ) as $k ) {
				$kpis[] = array(
					'libelle' => (string) $k['libelle'],
					'valeur'  => $k['valeur'],
					'unite'   => (string) $k['unite'],
				);
				if ( count( $kpis ) >= 4 ) { break; }
			}
		}

		$ctx = FKC_UxContexte::moment();

		/*
		 * LES PRIORITÉS DE MAESTRO — le pont annoncé et jamais posé (1.722.0).
		 *
		 * `MaestroController::priorites()` porte en commentaire, depuis sa
		 * livraison : « pour la barre transversale et le mobile ». La barre ne
		 * l'a jamais appelé. Vingt Experts calculaient donc, à chaque passage,
		 * un classement de ce qui mérite l'attention du dirigeant — et ce
		 * classement n'était visible que par celui qui pensait à ouvrir l'écran
		 * Maestro.
		 *
		 * ON APPELLE LE MOTEUR, PAS LA ROUTE : le copilote répond déjà côté
		 * serveur, un second aller-retour HTTP pour se répondre à soi-même
		 * n'apporterait qu'une latence. Même arbitrage que pour la recherche
		 * Connect en 1.720.0.
		 *
		 * TROIS AU PLUS, et après les suggestions de contexte : la barre est un
		 * coup d'œil, pas un tableau de bord. Une liste qui déborde se ferme
		 * sans être lue.
		 */
		$prio = array();
		if ( class_exists( 'FKC_Maestro' ) && class_exists( 'FKC_Auth' ) && FKC_Auth::can( 'analyse' ) ) {
			try {
				foreach ( FKC_Maestro::priorites( 3 ) as $p ) {
					$titre = trim( (string) ( $p['titre'] ?? '' ) );
					if ( '' === $titre ) { continue; }
					$prio[] = array(
						'gravite' => (string) ( $p['gravite'] ?? 'info' ),
						'titre'   => $titre,
						'message' => (string) ( $p['recommandation'] ?? $p['message'] ?? '' ),
						'url'     => FKC_Router::connue( 'analyse/maestro' ) ? url( 'analyse/maestro' ) : '',
					);
				}
			} catch ( \Throwable $e ) { $prio = array(); }
		}

		return array(
			'ok' => true,
			'salutation' => (string) $brief['salutation'],
			'date' => (string) ( $brief['date'] ?? '' ),
			'moment' => $ctx['label'] . ' ' . $ctx['icone'],
			'resume' => (string) ( $brief['resume'] ?? '' ),
			'recommandation' => (string) ( $brief['recommandation'] ?? '' ),
			'humeur' => (string) ( $brief['humeur'] ?? 'serein' ),
			'score' => $brief['score'],
			'points' => array_slice( $points, 0, 6 ),
			'priorites' => $prio,
			'suggestions' => $sugg,
			'kpis' => $kpis,
			'metier' => FKC_Ux::pack()['label'] ?? '',
		);
	}

	/* ═══════════════ Aperçu du profil UX ═══════════════ */

	/**
	 * Écran de diagnostic : les six couches, résolues, pour cette session.
	 *
	 * Il n'est pas décoratif. La question « pourquoi cet utilisateur ne voit-il
	 * pas cet écran ? » revient à chaque déploiement, et sans cet écran elle se
	 * traite en lisant du code à distance. Ici, la réponse tient en un regard :
	 * on voit le mode, la famille, le pack, le rôle, et ce que le moteur en a
	 * déduit — y compris les KPI déclarés mais pas encore branchés.
	 */
	public function apercu() {
		if ( class_exists( 'FKC_Ux' ) && ! FKC_Ux::capacite( 'ux.profil' ) ) {
			http_response_code( 403 );
			$f = class_exists( 'FKC_Modules' ) ? FKC_Modules::features() : array();
			FKC_View::render( 'errors.capacite', array(
				'title'  => 'Non activé', 'module' => '',
				'code'   => 'ux.profil',
				'label'  => (string) ( $f['ux.profil']['label'] ?? 'Écran « Profil UX »' ),
			) );
			return;
		}
		FKC_View::render( 'ux_apercu', array(
			'title'  => 'Profil UX',
			'module' => '',
			'profil' => FKC_Ux::profil(),
			'couverture' => class_exists( 'FKC_UxKpi' ) ? FKC_UxKpi::couverture() : 0,
		) );
	}

	/* ═══════════════ Utilitaire ═══════════════ */

	protected function json( $data ) {
		if ( ! headers_sent() ) {
			header( 'Content-Type: application/json; charset=utf-8' );
			header( 'Cache-Control: no-store' );
		}
		echo json_encode( $data, JSON_UNESCAPED_UNICODE );
		exit;
	}
}
