<?php
/**
 * Mode UI — écran d'accueil du Mode Simple, « Mon activité », et le réglage
 * du mode (choix explicite de l'utilisateur).
 *
 * L'accueil Simple n'invente aucune donnée : les tuiles sont résolues par
 * FKC_ModeUI::tuiles() contre les modules réellement couverts par la licence
 * et les droits de l'utilisateur, et « Mon activité » se contente de rendre
 * ce que les moteurs existants produisent déjà (FKC_Assistant pour le
 * briefing, FKC_Pilotage2 pour les KPI et les alertes du pack métier).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ModeController {

	/** Écran d'accueil du Mode Simple : les grandes actions, et rien d'autre. */
	public function accueil() {
		$u   = FKC_Auth::user();
		$nom = trim( (string) ( $u['nom_complet'] ?? '' ) );
		if ( '' === $nom ) { $nom = (string) ( $u['login'] ?? '' ); }
		// Prénom seul : « Bonjour KOFFI » plutôt que « Bonjour KOFFI YAO Jean ».
		$prenom = trim( (string) strtok( $nom, ' ' ) );

		FKC_View::render( 'accueil_simple', array(
			'title'   => 'Accueil',
			'module'  => '',
			'prenom'  => $prenom,
			'jour'    => self::dateFr(),
			// Les tuiles viennent du moteur UX : elles portent le métier
			// (« Tables », « Réservations », « Collecte ») et non plus les six
			// verbes du commerce pour tout le monde. Repli automatique sur
			// FKC_ModeUI::tuiles() si aucun profil ne résout — voir FKC_Ux::tuiles().
			'tuiles'  => class_exists( 'FKC_Ux' ) ? FKC_Ux::tuiles() : FKC_ModeUI::tuiles(),
			'devise'  => class_exists( 'FKC_Ux' ) ? FKC_Ux::devise() : '',
			'suggestions' => class_exists( 'FKC_UxContexte' ) ? FKC_UxContexte::suggestions() : array(),
			// La frise du métier : elle rappelle où l'on est dans le cycle,
			// sans rien imposer. C'est le seul élément de l'accueil qui parle
			// du TEMPS plutôt que des écrans.
			'workflow' => class_exists( 'FKC_Ux' ) ? FKC_Ux::workflow() : array( 'etapes' => array() ),
			'alertes' => self::alertes( 3 ),
			'societe' => FKC_Tenant::current(),
		) );
	}

	/** « Mon activité » : la synthèse du Mode Simple, sans graphique ni jargon. */
	public function activite() {
		$u   = FKC_Auth::user();
		$nom = trim( (string) ( $u['nom_complet'] ?? '' ) );
		$brief = null;
		if ( class_exists( 'FKC_Assistant' ) ) {
			try { $brief = FKC_Assistant::briefing( trim( (string) strtok( $nom, ' ' ) ) ); }
			catch ( \Throwable $e ) { $brief = null; }
		}
		$kpis = array();
		if ( class_exists( 'FKC_Pilotage2' ) ) {
			try { $kpis = array_slice( (array) FKC_Pilotage2::kpis(), 0, 6 ); }
			catch ( \Throwable $e ) { $kpis = array(); }
		}
		FKC_View::render( 'mon_activite', array(
			'title'    => 'Mon activité',
			'module'   => '',
			'briefing' => $brief,
			'kpis'     => $kpis,
			'alertes'  => self::alertes( 8 ),
		) );
	}

	/** Écran de réglage du mode (accessible depuis la barre du haut). */
	public function reglage() {
		$flash = $_SESSION['__mode_flash'] ?? null;
		unset( $_SESSION['__mode_flash'] );
		FKC_View::render( 'mode_reglage', array(
			'title'   => 'Mode d\'affichage',
			'module'  => '',
			'modes'   => FKC_ModeUI::modes(),
			'actif'   => FKC_ModeUI::actif(),
			'choix'   => FKC_ModeUI::choixUtilisateur(),
			'source'  => FKC_ModeUI::source(),
			'sourceTexte' => FKC_ModeUI::sourceTexte(),
			'defautSociete' => FKC_ModeUI::defautSociete(),
			'roleMode' => FKC_ModeUI::modeDeduitDesRoles(),
			'flash'   => $flash,
		) );
	}

	/**
	 * Bascule de mode. POST uniquement : changer l'affichage écrit une
	 * préférence en base — un GET l'aurait rendu déclenchable par un simple
	 * lien, y compris préchargé par le navigateur.
	 */
	public function basculer() {
		$code = (string) ( $_POST['mode'] ?? '' );
		$ok   = FKC_ModeUI::choisir( $code );
		$_SESSION['__mode_flash'] = $ok
			? array( 'type' => 'ok', 'msg' => 'auto' === strtolower( trim( $code ) ) || '' === trim( $code )
				? 'Choix effacé : le mode suit de nouveau votre rôle et les réglages de l\'entité.'
				: 'Affichage basculé en ' . FKC_ModeUI::label( FKC_ModeUI::normaliser( $code ) ) . '.' )
			: array( 'type' => 'err', 'msg' => 'Mode inconnu : rien n\'a été modifié.' );

		// Retour à l'écran d'où l'on vient quand il est interne, sinon accueil.
		$retour = (string) ( $_POST['retour'] ?? '' );
		$retour = FKC_ModeUI::normaliserRoute( preg_replace( '#^https?://[^/]+#i', '', $retour ) );
		$base   = FKC_ModeUI::normaliserRoute( parse_url( FKC_BASE_URL, PHP_URL_PATH ) ?: '' );
		if ( '' !== $base && 0 === strpos( $retour, $base ) ) { $retour = trim( substr( $retour, strlen( $base ) ), '/' ); }
		// Un écran devenu invisible dans le nouveau mode renverrait l'utilisateur
		// dans un cul-de-sac : on le ramène alors à l'accueil.
		if ( '' === $retour || ! FKC_ModeUI::routeVisible( $retour ) ) { $retour = ''; }
		redirect( $retour );
	}

	/* ── Helpers ─────────────────────────────────────────────────────────── */

	/** Alertes du pack métier actif, limitées et sans jamais faire tomber l'écran. */
	protected static function alertes( $max ) {
		if ( ! class_exists( 'FKC_Pilotage2' ) ) { return array(); }
		try { $a = (array) FKC_Pilotage2::alertes(); }
		catch ( \Throwable $e ) { return array(); }
		return array_slice( $a, 0, (int) $max );
	}

	/** « mardi 18 août » — même formulation que l'Assistant, sans dépendre de lui. */
	public static function dateFr() {
		$jours = array( 'dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi' );
		$mois  = array( '', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet',
			'août', 'septembre', 'octobre', 'novembre', 'décembre' );
		return $jours[ (int) date( 'w' ) ] . ' ' . (int) date( 'j' ) . ' ' . $mois[ (int) date( 'n' ) ];
	}
}
