<?php
/** Outils d'administration (Paramètres) : exercices, trésorerie, maintenance. Admin uniquement. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ParamAdminController {

	/* ════════ Exercices comptables (ouverture / clôture) ════════ */

	public function exercices() {
		$this->guard();
		FKC_View::render( 'parametres::exercices', array(
			'title'     => 'Paramètres · Exercices comptables',
			'tab'       => 'exercices',
			'exercices' => FKC_Exercice::all(),
			'clotures'  => FKC_Cloture::all(),
			'types'     => FKC_Cloture::types(),
			'annee'     => date( 'Y' ),
			'flash'     => $this->flash(),
		) );
	}

	/**
	 * Ouvre un exercice, avec ses à-nouveaux.
	 *
	 * L'échec des à-nouveaux REFUSE désormais l'ouverture (voir
	 * FKC_Exercice::ouvrir). La case « générer les à-nouveaux » n'est plus un
	 * confort : la décocher revient à ouvrir sur une balance vide, et l'écran
	 * le dit maintenant en toutes lettres.
	 */
	public function ouvrirExercice() {
		$this->guard();
		$annee   = (int) ( $_POST['annee'] ?? date( 'Y' ) );
		$reportAN = ! empty( $_POST['report_an'] );
		list( $ok, $msg ) = FKC_Exercice::ouvrir( $annee, $reportAN, array(
			'forcer' => ! empty( $_POST['forcer'] ),
			'motif'  => (string) ( $_POST['motif'] ?? '' ),
		) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/exercices' );
	}

	/** Annule l'ouverture d'un exercice — motif obligatoire, à-nouveaux compris. */
	public function annulerOuverture( $annee ) {
		$this->guard();
		list( $ok, $msg ) = FKC_Exercice::annulerOuverture( (int) $annee, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/exercices' );
	}

	/**
	 * Clôture une période infra-annuelle.
	 *
	 * L'ANNUELLE est renvoyée vers l'assistant : elle détermine le résultat,
	 * exige ses contrôles et engage l'affectation puis l'ouverture de N+1. Un
	 * formulaire de Paramètres qui ne montre ni l'état de l'exercice ni les
	 * anomalies ne peut pas porter ce geste.
	 */
	public function cloturer() {
		$this->guard();
		$type  = $_POST['type'] ?? 'mensuelle';
		$annee = (int) ( $_POST['annee'] ?? date( 'Y' ) );
		$sub   = (int) ( $_POST['sub'] ?? 1 );
		if ( 'annuelle' === $type ) {
			redirect( 'comptabilite/cloture?annee=' . $annee );
		}
		list( $ok, $msg ) = FKC_Cloture::create( $type, $annee, $sub );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/exercices' );
	}

	/** Rouvre une période clôturée — motif obligatoire, consigné au journal. */
	public function rouvrir( $id ) {
		$this->guard();
		list( $ok, $msg ) = FKC_Cloture::reopen( (int) $id, (string) ( $_POST['motif'] ?? '' ) );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/exercices' );
	}

	/* ════════ Comptes de trésorerie ════════ */

	public function tresorerie() {
		$this->guard();
		FKC_View::render( 'parametres::tresorerie', array(
			'title'   => 'Paramètres · Comptes de trésorerie',
			'tab'     => 'tresorerie',
			'comptes' => FKC_TresorerieCompte::all(),
			'types'   => FKC_TresorerieCompte::types(),
			'flash'   => $this->flash(),
		) );
	}

	public function tresorerieAdd() {
		$this->guard();
		list( $ok, $msg ) = FKC_TresorerieCompte::add( $_POST );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/tresorerie' );
	}

	public function tresorerieToggle( $id ) {
		$this->guard();
		FKC_TresorerieCompte::toggle( $id );
		$this->setFlash( 'Compte de trésorerie mis à jour.' );
		redirect( 'parametres/tresorerie' );
	}

	/* ════════ Fiscalité & règles du pack ════════
	 *
	 * Ajouté en 1.520.82. Les moteurs de fiscalité dynamique (1.520.80) et
	 * d'annulation (1.520.72) étaient complets et testés, mais atteignables
	 * uniquement EN CODE : régler un taux de blanchisserie ou un barème
	 * d'annulation demandait d'écrire du PHP. Une fonctionnalité que
	 * l'exploitant ne peut pas déclencher n'en est pas une — c'est
	 * précisément le reproche que l'audit adressait au reste.
	 */

	public function fiscalite() {
		$this->guard();
		FKC_CategorieFiscale::ensure();
		$pack = class_exists( 'FKC_Packs' ) ? (string) FKC_Packs::activeCode() : '';
		FKC_View::render( 'parametres::fiscalite', array(
			'title'      => 'Paramètres · Fiscalité & règles',
			'tab'        => 'fiscalite',
			'pack'       => $pack,
			'packLabel'  => $this->packLabel( $pack ),
			'categories' => FKC_CategorieFiscale::categories( false ),
			'codesTaxe'  => FKC_CategorieFiscale::codesTaxe(),
			'natures'    => FKC_CategorieFiscale::tableauNatures( $pack ),
			'bareme'     => class_exists( 'FKC_HospitalityAnnulation' ) ? FKC_HospitalityAnnulation::bareme( $pack ) : array(),
			'flash'      => $this->flash(),
		) );
	}

	protected function packLabel( $pack ) {
		if ( '' === $pack ) { return ''; }
		$p = class_exists( 'FKC_Packs' ) ? FKC_Packs::get( $pack ) : null;
		return is_array( $p ) && ! empty( $p['label'] ) ? (string) $p['label'] : (string) $pack;
	}

	public function fiscaliteDefauts() {
		$this->guard();
		$fait = FKC_CategorieFiscale::assurerDefauts();
		$this->setFlash( $fait
			? 'Catégories standard créées : taux normal (18 %), taux réduit (9 %), exonéré (0 %).'
			: 'Le référentiel contient déjà des catégories — rien n\'a été ajouté.', $fait ? 'ok' : 'warn' );
		redirect( 'parametres/fiscalite' );
	}

	public function fiscaliteCategorieAdd() {
		$this->guard();
		list( $ok, $msg ) = FKC_CategorieFiscale::creer( $_POST );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/fiscalite' );
	}

	public function fiscaliteTaux() {
		$this->guard();
		list( $ok, $msg ) = FKC_CategorieFiscale::modifierTaux( $_POST['id'] ?? 0, $_POST['taux'] ?? 0, $_POST['note'] ?? null );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/fiscalite' );
	}

	public function fiscaliteCategorieDel( $id ) {
		$this->guard();
		list( $ok, $msg ) = FKC_CategorieFiscale::supprimer( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/fiscalite' );
	}

	/** Associe chaque nature de prestation du pack actif à une catégorie fiscale. */
	public function fiscaliteNatures() {
		$this->guard();
		$pack = class_exists( 'FKC_Packs' ) ? (string) FKC_Packs::activeCode() : '';
		$n = 0;
		foreach ( (array) ( $_POST['nature'] ?? array() ) as $code => $catId ) {
			if ( FKC_CategorieFiscale::definirNature( $pack, $code, (int) $catId ) ) { $n++; }
		}
		$this->setFlash( $n . ' nature(s) mise(s) à jour. Les prochaines lignes utiliseront ces taux ; les lignes déjà facturées gardent le leur.' );
		redirect( 'parametres/fiscalite' );
	}

	/**
	 * Enregistre le barème d'annulation du pack actif.
	 *
	 * Un barème VIDE est un choix légitime — c'est le comportement par défaut :
	 * aucune suggestion de frais, la réception saisit ce qu'elle décide.
	 */
	public function fiscaliteBareme() {
		$this->guard();
		if ( ! class_exists( 'FKC_HospitalityAnnulation' ) ) {
			$this->setFlash( 'Moteur d\'annulation indisponible.', 'err' );
			redirect( 'parametres/fiscalite' );
		}
		$pack = class_exists( 'FKC_Packs' ) ? (string) FKC_Packs::activeCode() : '';
		$paliers = array();
		$heures = (array) ( $_POST['palier_heures'] ?? array() );
		$pcts   = (array) ( $_POST['palier_pct'] ?? array() );
		foreach ( $heures as $i => $h ) {
			if ( '' === trim( (string) $h ) ) { continue; }
			$paliers[] = array( 'heures' => (int) $h, 'retenue_pct' => (float) ( $pcts[ $i ] ?? 0 ) );
		}
		FKC_HospitalityAnnulation::definirBareme( $pack, $paliers );
		$this->setFlash( $paliers
			? count( $paliers ) . ' palier(s) enregistré(s). Les frais restent une SUGGESTION : la réception applique ou non.'
			: 'Barème effacé — aucune suggestion de frais ne sera proposée.' );
		redirect( 'parametres/fiscalite' );
	}

	/* ════════ Maintenance (opérations destructives) ════════ */

	/**
	 * Audit des intégrations : quelles règles comptables des packs sont
	 * réellement raccordées à un déclencheur, et lesquelles dorment.
	 * Écran en lecture seule : il ne produit ni écriture ni modification.
	 */
	public function integrations() {
		$this->guard();
		FKC_View::render( 'parametres::integrations', array(
			'title'   => 'Paramètres · Audit des intégrations',
			'tab'     => 'integrations',
			'rapport' => class_exists( 'FKC_IntegrationAudit' ) ? FKC_IntegrationAudit::rapport() : null,
			'flash'   => $this->flash(),
		) );
	}

	/* ════════ Référentiel comptable (SYSCOHADA / SYCEBNL) ════════ */

	/**
	 * Quel corps de règles s'applique à ce dossier — et ce qu'il en coûte.
	 *
	 * L'écran est délibérément bavard sur UN point : lorsque le dossier relève
	 * du SYCEBNL, FinaKop ne sait pas encore le tenir (plan et états au lot 7).
	 * Le taire produirait des liasses fausses présentées comme conformes.
	 */
	public function referentiel() {
		$this->guard();
		FKC_View::render( 'parametres::referentiel', array(
			'title'        => 'Paramètres · Référentiel comptable',
			'tab'          => 'referentiel',
			'etat'         => class_exists( 'FKC_Referentiel' ) ? FKC_Referentiel::etat() : null,
			'referentiels' => class_exists( 'FKC_Referentiel' ) ? FKC_Referentiel::toutes() : array(),
			'plan_installe' => class_exists( 'FKC_PlanSycebnl' ) ? FKC_PlanSycebnl::estInstalle() : false,
			'plan_valide'   => class_exists( 'FKC_PlanSycebnl' ) ? FKC_PlanSycebnl::estValide() : false,
			'plan_manquants'=> class_exists( 'FKC_PlanSycebnl' ) ? count( FKC_PlanSycebnl::manquants() ) : 0,
			'plan_total'    => class_exists( 'FKC_PlanSycebnl' ) ? count( FKC_PlanSycebnl::comptes() ) : 0,
			'parPack'      => class_exists( 'FKC_Referentiel' ) ? FKC_Referentiel::parPack() : array(),
			'packs'        => class_exists( 'FKC_Packs' ) ? FKC_Packs::all() : array(),
			'flash'        => $this->flash(),
		) );
	}

	/** Fixe la surcharge de société (chaîne vide = suivre le pack métier). */
	public function referentielDefinir() {
		$this->guard();
		$code = trim( (string) ( $_POST['referentiel'] ?? '' ) );
		$ok   = class_exists( 'FKC_Referentiel' ) ? FKC_Referentiel::definir( $code ) : false;
		$this->setFlash(
			$ok
				? ( '' === $code
					? 'Le dossier suit désormais le référentiel déclaré par son pack métier.'
					: 'Référentiel du dossier : ' . FKC_Referentiel::get( $code )['label'] . '.' )
				: 'Référentiel inconnu — aucun changement.',
			$ok ? 'ok' : 'err'
		);
		redirect( 'parametres/referentiel' );
	}

	/** Installe le plan SYCEBNL, ou enregistre sa validation par un professionnel. */
	public function referentielPlan() {
		$this->guard();
		$action = (string) ( $_POST['action'] ?? 'installer' );
		if ( 'valider' === $action ) {
			list( $ok, $msg ) = FKC_PlanSycebnl::valider( ! empty( $_POST['valide'] ) );
		} else {
			list( $ok, $msg ) = FKC_PlanSycebnl::installer();
		}
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/referentiel' );
	}

	/** Les trois états spécifiques du SYCEBNL. */
	public function referentielEtats() {
		$this->guard();
		$conv = (int) ( $_GET['convention_id'] ?? 0 );
		$conventions = class_exists( 'FKC_OngConventions' ) ? FKC_OngConventions::conventions() : array();
		if ( ! $conv && $conventions ) { $conv = (int) $conventions[0]['id']; }
		FKC_View::render( 'parametres::sycebnl_etats', array(
			'title'       => 'SYCEBNL · États spécifiques',
			'tab'         => 'referentiel',
			'ressources'  => FKC_EtatsSycebnl::ressourcesEmplois( $_GET['du'] ?? '', $_GET['au'] ?? '' ),
			'execution'   => $conv ? FKC_EtatsSycebnl::executionBudgetaire( $conv ) : null,
			'fonds'       => FKC_EtatsSycebnl::rapprochementFonds(),
			'conventions' => $conventions,
			'convention_id' => $conv,
			'valide'      => FKC_PlanSycebnl::estValide(),
			'flash'       => $this->flash(),
		) );
	}

	/** Vide le relevé d'anomalies (après reprise des écritures concernées). */
	public function referentielOublier() {
		$this->guard();
		if ( class_exists( 'FKC_Referentiel' ) ) { FKC_Referentiel::oublierAnomalies(); }
		$this->setFlash( 'Relevé remis à zéro. Il se reconstituera à la prochaine écriture concernée.' );
		redirect( 'parametres/referentiel' );
	}

	/** Écritures métier assistées : le comptable choisit, saisit et valide. */
	public function ecrituresAssistees() {
		$this->guard();
		FKC_View::render( 'parametres::ecritures_assistees', array(
			'title'  => 'Paramètres · Écritures métier assistées',
			'tab'    => 'ecritures_assistees',
			'regles' => class_exists( 'FKC_EcritureAssistee' ) ? FKC_EcritureAssistee::reglesDisponibles() : array(),
			'flash'  => $this->flash(),
		) );
	}

	/** Génère l'écriture choisie, au brouillard par défaut. */
	public function ecritureAssisteeGenerer() {
		$this->guard();
		$evt  = trim( (string) ( $_POST['evenement'] ?? '' ) );
		$mode = 'direct' === ( $_POST['mode'] ?? '' ) ? 'direct' : 'brouillard';
		$ctx  = array();
		foreach ( (array) ( $_POST['ctx'] ?? array() ) as $k => $v ) {
			$k = preg_replace( '/[^a-z0-9_]/i', '', (string) $k );
			if ( '' !== $k ) { $ctx[ $k ] = is_numeric( $v ) ? (float) $v : trim( (string) $v ); }
		}
		if ( ! empty( $_POST['libelle_tiers'] ) ) { $ctx['tiers'] = trim( (string) $_POST['libelle_tiers'] ); }
		if ( ! empty( $_POST['dossier'] ) ) { $ctx['dossier'] = trim( (string) $_POST['dossier'] ); }
		list( $ok, $msg ) = class_exists( 'FKC_EcritureAssistee' )
			? FKC_EcritureAssistee::generer( $evt, $ctx, $mode )
			: array( false, 'Module indisponible.' );
		$this->setFlash( $msg );
		redirect( 'parametres/ecritures-assistees' );
	}

	/**
	 * Centre d'intégrité : tous les contrôles, sur un seul écran.
	 *
	 * Aucun calcul ici — FKC_Integrite rassemble ce que chaque module sait
	 * déjà mesurer. Un contrôle vit là où vit la donnée qu'il examine ; cet
	 * écran ne fait que les réunir sous les yeux de celui qui cherche « ce
	 * qui ne va pas », et qui n'irait pas le chercher dans sept modules.
	 */
	public function integrite() {
		$this->guard();
		FKC_View::render( 'parametres::integrite', array(
			'title' => 'Paramètres · Intégrité ERP',
			'tab'   => 'integrite',
			'etat'  => class_exists( 'FKC_Integrite' ) ? FKC_Integrite::etat() : array( 'controles' => array() ),
			'flash' => $this->flash(),
		) );
	}

	/** Supervision du socle BPE : ce qui circule réellement dans FinaKop. */
	public function processus() {
		$this->guard();
		$type  = trim( (string) ( $_GET['type'] ?? '' ) );
		$docId = (int) ( $_GET['id'] ?? 0 );
		$bpe   = class_exists( 'FKC_BPE' );
		$wk    = class_exists( 'FKC_BPEWorker' );
		FKC_View::render( 'parametres::processus', array(
			'title'      => 'Paramètres · Processus & événements métier',
			'tab'        => 'processus',
			'etat'       => $bpe ? FKC_BPE::etat() : array(),
			'evenements' => $bpe ? FKC_BPE::evenements( 60 ) : array(),
			'frequences' => $bpe ? FKC_BPE::frequences( 15 ) : array(),
			'attente'    => $bpe ? FKC_BPE::aTraiter( 25 ) : array(),
			'echouees'   => $bpe ? FKC_BPE::tachesEnEchec( 25 ) : array(),
			'traitements' => $wk ? FKC_BPEWorker::traitements() : array(),
			'prochain'   => $wk ? FKC_BPEWorker::prochainPassage() : null,
			'cronCoupe'  => $wk ? FKC_BPEWorker::cronDesactive() : false,
			// Le battement répond à la seule question que l'écran ne posait
			// pas : le moteur tourne-t-il encore ?
			'sante'      => class_exists( 'FKC_BPESante' ) ? FKC_BPESante::synthese() : null,
			'type'       => $type,
			'docId'      => $docId ?: null,
			'chaine'     => ( $bpe && $type && $docId ) ? FKC_BPE::chaine( $type, $docId ) : null,
			'flash'      => $this->flash(),
		) );
	}

	/**
	 * Traite la file différée de la société courante, à la demande.
	 *
	 * Volontairement limité à la SOCIÉTÉ COURANTE, alors que le crochet
	 * planifié balaie toutes les sociétés : un administrateur connecté sur un
	 * dossier n'a aucune raison de déclencher des traitements comptables chez
	 * les autres, et le bouton doit faire ce que son écran laisse attendre.
	 */
	public function bpeTraiter() {
		$this->guard();
		if ( ! class_exists( 'FKC_BPEWorker' ) ) {
			$this->setFlash( 'Worker indisponible.', 'err' );
			redirect( 'parametres/processus' );
			return;
		}
		$r   = FKC_BPEWorker::run( 50 );
		$msg = sprintf(
			'%d tâche(s) traitée(s) : %d réussie(s), %d en échec, %d abandonnée(s).',
			$r['traitees'], $r['succes'], $r['echecs'], $r['abandons']
		);
		if ( $r['recuperees'] ) {
			$msg .= ' ' . $r['recuperees'] . ' tâche(s) récupérée(s) d\'un worker interrompu.';
		}
		if ( ! $r['traitees'] && ! $r['recuperees'] ) { $msg = 'Rien à traiter : la file est vide.'; }
		foreach ( array_slice( (array) $r['messages'], 0, 3 ) as $m ) { $msg .= ' — ' . $m; }
		$this->setFlash( $msg, ( $r['echecs'] || $r['abandons'] ) ? 'err' : 'ok' );
		redirect( 'parametres/processus' );
	}

	/** Remet une tâche abandonnée en file (bouton « Rejouer »). */
	public function bpeRejouer( $id ) {
		$this->guard();
		$ok = class_exists( 'FKC_BPE' ) && FKC_BPE::rejouerTache( (int) $id );
		$this->setFlash(
			$ok ? 'Tâche #' . (int) $id . ' remise en file. Elle repartira au prochain passage du worker.'
				: 'Tâche #' . (int) $id . ' introuvable ou déjà en file.',
			$ok ? 'ok' : 'err'
		);
		redirect( 'parametres/processus' );
	}

	/** Rend à la file les tâches retenues par un worker disparu. */
	public function bpeRecuperer() {
		$this->guard();
		$n = class_exists( 'FKC_BPE' ) ? FKC_BPE::recupererOrphelines() : 0;
		$this->setFlash(
			$n ? $n . ' tâche(s) rendue(s) à la file.' : 'Aucune tâche bloquée : rien à récupérer.',
			'ok'
		);
		redirect( 'parametres/processus' );
	}

	public function maintenance() {
		$this->guard();
		// Recherche d'écriture : le terme survit à la redirection le temps d'un
		// affichage, pour garder le schéma POST → redirect → GET du reste de l'écran.
		$terme = (string) ( $_SESSION['__padm_recherche'] ?? '' );
		unset( $_SESSION['__padm_recherche'] );
		FKC_View::render( 'parametres::maintenance', array(
			'title'      => 'Paramètres · Maintenance des données',
			'tab'        => 'maintenance',
			'annees'     => FKC_Maintenance::annees(),
			'annee'      => date( 'Y' ),
			'recherche'  => $terme,
			'resultats'  => '' !== $terme ? FKC_EcritureAnnulation::rechercher( $terme ) : array(),
			// Aperçu (sans modification) des divergences entre pièces et écritures.
			'coherence'  => FKC_Maintenance::coherenceEcritures( true ),
			// État des suites de numéros, par journal et par exercice.
			'sequences'  => FKC_EcritureNumero::verifierSequences(),
			// État du serveur (1.772.0) : version de PHP, extensions, limites
			// d'envoi — ce qui explique les pannes qui ne viennent pas du code.
			'environnement' => fkc_environnement(),
			'flash'      => $this->flash(),
		) );
	}

	/**
	 * Lance le rattrapage des divergences entre pièces et écritures.
	 *
	 * Remet « à comptabiliser » les pièces dont l'écriture a disparu ou a été
	 * contre-passée, et retire les lettrages devenus vides. Idempotent : on peut
	 * la relancer sans risque.
	 */
	public function coherenceEcritures() {
		$this->guard();
		$r = FKC_Maintenance::coherenceEcritures( false );
		$total = (int) $r['orphelines'] + (int) $r['contrepassees'] + (int) $r['lettrages'];
		if ( 0 === $total ) {
			$this->setFlash( 'Aucune divergence : chaque pièce comptabilisée pointe bien vers une écriture existante et non annulée.' );
		} else {
			$this->setFlash(
				$total . ' divergence(s) corrigée(s) — '
				. (int) $r['orphelines'] . ' référence(s) orpheline(s), '
				. (int) $r['contrepassees'] . ' pièce(s) rattachée(s) à une écriture annulée, '
				. (int) $r['lettrages'] . ' lettrage(s) retiré(s). '
				. ( $r['detail'] ? 'Détail : ' . implode( ' · ', $r['detail'] ) . '.' : '' )
			);
		}
		redirect( 'parametres/maintenance' );
	}

	public function purgeEcritures() {
		$this->guard();
		list( $deb, $fin ) = $this->plage();
		if ( ! $deb ) { $this->setFlash( 'Plage de dates invalide.', 'err' ); redirect( 'parametres/maintenance' ); }
		$n = FKC_Maintenance::purgeEcritures( $deb, $fin );
		$this->setFlash( $n . ' écriture(s) supprimée(s) entre le ' . $this->fr( $deb ) . ' et le ' . $this->fr( $fin ) . '.' );
		redirect( 'parametres/maintenance' );
	}

	public function purgeFactures() {
		$this->guard();
		list( $deb, $fin ) = $this->plage();
		if ( ! $deb ) { $this->setFlash( 'Plage de dates invalide.', 'err' ); redirect( 'parametres/maintenance' ); }
		$aussi = ! empty( $_POST['aussi_ecritures'] );
		$n = FKC_Maintenance::purgeFactures( $deb, $fin, $aussi );
		$this->setFlash( $n . ' facture(s) client(s) supprimée(s)' . ( $aussi ? ' avec leurs écritures' : '' ) . '.' );
		redirect( 'parametres/maintenance' );
	}

	public function purgeAchats() {
		$this->guard();
		list( $deb, $fin ) = $this->plage();
		if ( ! $deb ) { $this->setFlash( 'Plage de dates invalide.', 'err' ); redirect( 'parametres/maintenance' ); }
		$aussi = ! empty( $_POST['aussi_ecritures'] );
		$n = FKC_Maintenance::purgeAchats( $deb, $fin, $aussi );
		$this->setFlash( $n . ' facture(s) fournisseur(s) supprimée(s)' . ( $aussi ? ' avec leurs écritures' : '' ) . '.' );
		redirect( 'parametres/maintenance' );
	}

	public function resetExercice() {
		$this->guard();
		$annee = (int) ( $_POST['annee'] ?? 0 );
		$confirm = trim( (string) ( $_POST['confirm'] ?? '' ) );
		if ( $confirm !== (string) $annee ) {
			$this->setFlash( 'Confirmation incorrecte : saisissez l\'année exacte pour réinitialiser l\'exercice.', 'err' );
			redirect( 'parametres/maintenance' );
		}
		$c = FKC_Maintenance::resetExercice( $annee );
		$this->setFlash( 'Exercice ' . $annee . ' réinitialisé : ' . (int) $c['ecritures'] . ' écritures, ' . (int) $c['factures'] . ' factures, ' . (int) $c['achats'] . ' achats, ' . (int) $c['reglements'] . ' règlements supprimés. Plan comptable et paramètres conservés.' );
		redirect( 'parametres/maintenance' );
	}

	public function purgeTout() {
		$this->guard();
		if ( trim( (string) ( $_POST['confirm'] ?? '' ) ) !== 'SUPPRIMER' ) {
			$this->setFlash( 'Confirmation incorrecte : saisissez SUPPRIMER pour vider toutes les transactions.', 'err' );
			redirect( 'parametres/maintenance' );
		}
		FKC_Maintenance::purgeTout();
		$this->setFlash( 'Toutes les transactions de l\'entité ont été supprimées. Le paramétrage (plan comptable, journaux, divisions, trésorerie, tiers) est conservé.' );
		redirect( 'parametres/maintenance' );
	}

	/* ════════ Annulation d'UNE écriture désignée ════════ */

	/** Recherche par numéro de pièce, référence ou identifiant. */
	public function ecritureRechercher() {
		$this->guard();
		$n = trim( (string) ( $_POST['numero'] ?? '' ) );
		if ( '' === $n ) {
			$this->setFlash( 'Saisissez un numéro de pièce, une référence ou un identifiant d\'écriture.', 'err' );
			redirect( 'parametres/maintenance' );
		}
		$_SESSION['__padm_recherche'] = mb_substr( $n, 0, 60 );
		$res = FKC_EcritureAnnulation::rechercher( $n );
		if ( ! $res ) { $this->setFlash( 'Aucune écriture ne correspond à « ' . $n .' ».', 'err' ); }
		redirect( 'parametres/maintenance' );
	}

	/** Voie normale : génère l'écriture inverse. */
	public function ecritureContrepasser() {
		$this->guard();
		$id   = (int) ( $_POST['id'] ?? 0 );
		$date = trim( (string) ( $_POST['date_annulation'] ?? '' ) );
		list( $ok, $msg ) = FKC_EcritureAnnulation::contrepasser( $id, $date ?: null );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/maintenance' );
	}

	/** Voie exceptionnelle : efface l'écriture. Refusée dès qu'un élément la référence. */
	public function ecritureSupprimer() {
		$this->guard();
		$id = (int) ( $_POST['id'] ?? 0 );
		if ( trim( (string) ( $_POST['confirm'] ?? '' ) ) !== 'SUPPRIMER' ) {
			$this->setFlash( 'Confirmation incorrecte : saisissez SUPPRIMER pour effacer définitivement cette écriture.', 'err' );
			redirect( 'parametres/maintenance' );
		}
		list( $ok, $msg ) = FKC_EcritureAnnulation::supprimer( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/maintenance' );
	}

	/* ════════ helpers ════════ */

	/** Sécurité : réservé à l'administrateur (double contrôle au-delà du routeur). */
	protected function guard() {
		if ( ! FKC_Auth::isAdmin() ) {
			http_response_code( 403 );
			FKC_View::render( 'errors.denied', array( 'reason' => 'admin' ) );
			exit;
		}
	}

	/** Plage de dates depuis le POST (mode période ou exercice). */
	protected function plage() {
		if ( ! empty( $_POST['annee_plage'] ) ) {
			$y = (int) $_POST['annee_plage'];
			return array( sprintf( '%04d-01-01', $y ), sprintf( '%04d-12-31', $y ) );
		}
		$deb = trim( (string) ( $_POST['debut'] ?? '' ) );
		$fin = trim( (string) ( $_POST['fin'] ?? '' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deb ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fin ) || $deb > $fin ) {
			return array( null, null );
		}
		return array( $deb, $fin );
	}

	protected function fr( $d ) { return date( 'd/m/Y', strtotime( $d ) ); }
	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_padm'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_padm'] ?? null; unset( $_SESSION['__flash_padm'] ); return $m; }

	/**
	 * Revient sur une contre-passation passée par erreur.
	 *
	 * Supprime la contre-passation et rebranche les pièces qu'elle avait
	 * déliées. Refusé dès qu'elle a servi à quelque chose ou qu'une période est
	 * clôturée — les motifs sont détaillés dans le message.
	 */
	public function ecritureAnnulerContrepassation() {
		$this->guard();
		$id = (int) ( $_POST['id'] ?? 0 );
		list( $ok, $msg ) = FKC_EcritureAnnulation::annulerContrepassation( $id );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/maintenance?q=' . urlencode( (string) ( $_POST['q'] ?? '' ) ) );
	}

	/** Numérote les écritures antérieures à la numérotation. */
	public function numeroterEcritures() {
		$this->guard();
		$r = FKC_EcritureNumero::reprendreExistant( false );
		if ( 0 === (int) $r['numerotees'] ) {
			$this->setFlash( 'Toutes les écritures portent déjà un numéro.' );
		} else {
			$this->setFlash(
				(int) $r['numerotees'] . ' écriture(s) numérotée(s) sur ' . (int) $r['journaux'] . ' série(s), '
				. 'dans l\'ordre chronologique. ' . ( $r['detail'] ? implode( ' · ', array_slice( $r['detail'], 0, 8 ) ) . '.' : '' )
			);
		}
		redirect( 'parametres/maintenance' );
	}

	/** Recale les compteurs sur les numéros réellement attribués. */
	public function recalerSequences() {
		$this->guard();
		$n = FKC_EcritureNumero::recalerCompteurs();
		$this->setFlash( $n . ' compteur(s) recalé(s) sur le plus haut numéro attribué.' );
		redirect( 'parametres/maintenance' );
	}
}
