<?php
/**
 * PARAMÈTRES → TERMINAUX — le registre des appareils de l'établissement.
 *
 * Côté professionnel, donc derrière l'authentification et réservé à
 * l'administration : déclarer un appareil, c'est ouvrir une porte publique sur
 * une partie de ses données. Ce n'est pas un réglage d'affichage.
 *
 * @package FinaKop_ERP_Core
 */

defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_TerminalController {

	protected function flash( $m = null, $t = 'ok' ) {
		if ( null !== $m ) { $_SESSION['__flash_term'] = array( 'type' => $t, 'msg' => (string) $m ); return; }
		$f = $_SESSION['__flash_term'] ?? null;
		unset( $_SESSION['__flash_term'] );
		return $f;
	}

	public function index() {
		/*
		 * LES CODES SE RENOUVELLENT À L'OUVERTURE DE L'ÉCRAN (1.727.0), et la
		 * page se recharge d'elle-même : un exploitant qui laisse l'écran
		 * ouvert en installant sa tablette ne trouve plus un code expiré au
		 * moment de le saisir. Aucun appareil déjà associé n'est touché.
		 */
		FKC_Terminal::rafraichirCodes();
		FKC_View::render( 'parametres::terminaux', array(
			'title' => 'Paramètres · Terminaux',
			'terminaux' => FKC_Terminal::tous(),
			'types' => FKC_Terminal::types(),
			'modes' => FKC_Terminal::modes(),
			'themes' => FKC_Terminal::themes(),
			'packsEquipes' => FKC_TerminalAdapter::packsEquipes(),
			'packActif' => class_exists( 'FKC_Packs' ) ? (string) FKC_Packs::activeCode() : '',
			'flash' => $this->flash(),
			'nouveau' => isset( $_GET['nouveau'] ) ? (int) $_GET['nouveau'] : 0,
		) );
	}

	public function store() {
		list( $ok, $msg, $id ) = FKC_Terminal::creer( array(
			'nom' => $_POST['nom'] ?? '', 'type' => $_POST['type'] ?? '', 'caisse_id' => (int) ( $_POST['caisse_id'] ?? 0 ),
			'pack' => $_POST['pack'] ?? '', 'emplacement' => $_POST['emplacement'] ?? '',
			'mode' => $_POST['mode'] ?? 'libre',
			'theme' => $_POST['theme'] ?? 'auto',
		) );
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux' . ( $ok ? '?nouveau=' . (int) $id : '' ) );
	}

	public function codeAuto( $id ) {
		list( $ok, $msg ) = FKC_Terminal::basculerCodeAuto( $id, ! empty( $_POST['actif'] ) );
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux' );
	}

	public function code( $id ) {
		list( $ok, $msg ) = FKC_Terminal::regenererCode( $id );
		// Le message disait que l'appareil en place était déconnecté : ce
		// n'est plus vrai depuis 1.736.0, et le dire encore inquiéterait pour rien.
		$this->flash( $ok ? 'Nouveau code attribué. Les appareils déjà associés restent connectés.' : $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux?nouveau=' . (int) $id );
	}

	/** Combien d'écrans peuvent vivre sur cette même configuration (1.736.0). */
	public function appareils( $id ) {
		list( $ok, $msg ) = FKC_Terminal::definirMaxAppareils( $id, $_POST['max'] ?? FKC_Terminal::MAX_APPAREILS_DEFAUT );
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux' );
	}

	/**
	 * Déconnecte UN appareil.
	 *
	 * Le geste de tous les jours — une tablette égarée, un écran remplacé — et
	 * il ne doit pas obliger à couper toute la salle pour autant. « Révoquer »
	 * reste là pour cela, et porte son nom.
	 */
	public function revoquerAppareil( $sessionId ) {
		list( $ok, $msg ) = FKC_Terminal::revoquerAppareil( $sessionId );
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux' );
	}

	public function revoquer( $id ) {
		list( $ok, $msg ) = FKC_Terminal::revoquer( $id );
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux' );
	}

	/**
	 * Réglages d'un terminal déjà déclaré (1.806.0) : nom, emplacement, mode,
	 * thème, couleur d'accent, inactivité, écran d'attente.
	 *
	 * Le type et le pack n'y figurent pas, et c'est voulu : ils décident des
	 * capacités du jeton déjà distribué — les changer reste un geste de
	 * révocation, pas un réglage.
	 */
	public function reglages( $id ) {
		list( $ok, $msg ) = FKC_Terminal::mettreAJour( $id, array(
			'nom'              => $_POST['nom'] ?? '',
			'emplacement'      => $_POST['emplacement'] ?? '',
			'mode'             => $_POST['mode'] ?? 'libre',
			'theme'            => $_POST['theme'] ?? 'auto',
			'accent'           => ! empty( $_POST['accent_perso'] ) ? ( $_POST['accent'] ?? '' ) : '',
			'delai_inactivite' => $_POST['delai_inactivite'] ?? FKC_Terminal::DELAI_INACTIVITE_DEFAUT,
			'attract'          => ! empty( $_POST['attract'] ),
			'message_accueil'  => $_POST['message_accueil'] ?? '',
		) );
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux' );
	}

	public function reactiver( $id ) {
		list( $ok, $msg ) = FKC_Terminal::reactiver( $id );
		$this->flash( $ok ? 'Terminal réactivé. Un nouveau code d\'appairage est affiché.' : $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux?nouveau=' . (int) $id );
	}

	/* ── Contenus promotionnels (Phase 3, 1.814.0) ─────────────────────────── */

	/**
	 * Les articles qu'un contenu peut mettre en avant : le catalogue PUBLIC de
	 * chaque métier équipé d'une borne — exactement ce que la borne affiche.
	 */
	protected function articlesParPack() {
		$out = array();
		foreach ( FKC_TerminalAdapter::packsEquipes() as $pack ) {
			$adapt = FKC_TerminalAdapter::pour( $pack );
			try { $cat = $adapt ? (array) $adapt::catalogue( $pack ) : array(); } catch ( \Throwable $e ) { $cat = array(); }
			if ( $cat ) {
				$out[ $pack ] = array_map( function ( $a ) {
					return array( 'id' => (int) $a['id'], 'libelle' => (string) $a['libelle'], 'categorie' => (string) ( $a['categorie'] ?? '' ) );
				}, $cat );
			}
		}
		return $out;
	}

	public function promos() {
		$edit = isset( $_GET['edit'] ) ? FKC_TerminalPromo::trouver( (int) $_GET['edit'] ) : null;
		FKC_View::render( 'parametres::terminaux_promos', array(
			'title' => 'Paramètres · Terminaux · Contenus promotionnels',
			'promos' => FKC_TerminalPromo::tous(),
			'edit' => $edit,
			'emplacements' => FKC_TerminalPromo::emplacements(),
			'packsEquipes' => FKC_TerminalAdapter::packsEquipes(),
			'articles' => $this->articlesParPack(),
			'flash' => $this->flash(),
		) );
	}

	public function promosAction() {
		$id = (int) ( $_POST['id'] ?? 0 );
		$suite = 'parametres/terminaux/promos';
		switch ( (string) ( $_POST['action'] ?? '' ) ) {
			case 'enregistrer':
				/* L'article est choisi dans la liste du métier visé (un sélecteur par métier). */
				$pack = (string) ( $_POST['pack'] ?? '' );
				$art = '' !== $pack ? ( $_POST['article_' . preg_replace( '/[^a-z0-9_]/', '', $pack )] ?? '' ) : ( $_POST['article_tous'] ?? '' );
				list( $ok, $msg, $pid ) = FKC_TerminalPromo::enregistrer( array(
					'titre' => $_POST['titre'] ?? '', 'texte' => $_POST['texte'] ?? '', 'pack' => $pack,
					'emplacement' => $_POST['emplacement'] ?? 'partout', 'debut' => $_POST['debut'] ?? '', 'fin' => $_POST['fin'] ?? '',
					'article_id' => $art, 'actif' => ! empty( $_POST['actif'] ),
				), $id ?: null );
				if ( $ok && $pid && ! empty( $_FILES['image']['name'] ) ) {
					list( $okI, $msgI ) = FKC_TerminalPromo::enregistrerImage( $pid, $_FILES['image'] );
					$msg .= ' ' . $msgI; $ok = $ok && $okI;
				}
				$this->flash( trim( $msg ), $ok ? 'ok' : 'err' );
				if ( ! $ok && $id ) { $suite .= '?edit=' . $id; }
				break;
			case 'image_retirer':
				list( $ok, $msg ) = FKC_TerminalPromo::retirerImage( $id );
				$this->flash( $msg, $ok ? 'ok' : 'err' );
				$suite .= '?edit=' . $id;
				break;
			case 'basculer':
				list( $ok, $msg ) = FKC_TerminalPromo::basculer( $id );
				$this->flash( $msg, $ok ? 'ok' : 'err' );
				break;
			case 'monter':
			case 'descendre':
				list( $ok, $msg ) = FKC_TerminalPromo::deplacer( $id, 'monter' === $_POST['action'] ? -1 : 1 );
				$this->flash( $msg, $ok ? 'ok' : 'err' );
				break;
			case 'supprimer':
				list( $ok, $msg ) = FKC_TerminalPromo::supprimer( $id );
				$this->flash( $msg, $ok ? 'ok' : 'err' );
				break;
			default:
				$this->flash( 'Action inconnue.', 'err' );
		}
		redirect( $suite );
	}

	/** Aperçu de la photo d'un contenu, pour l'administration (session, pas le jeton d'une borne). */
	public function promoImage( $id ) {
		$c = FKC_TerminalPromo::imageChemin( FKC_TerminalPromo::trouver( (int) $id ) );
		if ( ! $c ) { http_response_code( 404 ); return; }
		FKC_TerminalMedia::servir( $c );
	}

	/* ── Apparence des bornes de l'établissement (Phase 3, 1.815.0) ────────── */

	public function apparence() {
		FKC_View::render( 'parametres::terminaux_apparence', array(
			'title' => 'Paramètres · Terminaux · Apparence des bornes',
			'r' => FKC_TerminalMarque::reglages(),
			'fond' => (bool) FKC_TerminalMarque::fondChemin(),
			'themes' => FKC_TerminalTheme::themes(),
			'polices' => FKC_TerminalMarque::polices(),
			'arrondis' => FKC_TerminalMarque::arrondis(),
			'ambiances' => FKC_TerminalMarque::ambiances(),
			'marque' => FKC_TerminalTheme::marque( array() ),
			'flash' => $this->flash(),
		) );
	}

	public function apparenceAction() {
		switch ( (string) ( $_POST['action'] ?? '' ) ) {
			case 'enregistrer':
				list( $ok, $msg ) = FKC_TerminalMarque::enregistrer( array(
					'theme' => $_POST['theme'] ?? '', 'accent' => ! empty( $_POST['accent_perso'] ) ? ( $_POST['accent'] ?? '' ) : '',
					'police' => $_POST['police'] ?? 'syne', 'arrondis' => $_POST['arrondis'] ?? 'standard', 'ambiance' => $_POST['ambiance'] ?? 'halos',
				) );
				if ( $ok && ! empty( $_FILES['fond']['name'] ) ) {
					list( $okF, $msgF ) = FKC_TerminalMarque::enregistrerFond( $_FILES['fond'] );
					$msg = $okF ? $msg : $msgF; $ok = $okF;
				}
				$this->flash( $msg, $ok ? 'ok' : 'err' );
				break;
			case 'fond_retirer':
				list( $ok, $msg ) = FKC_TerminalMarque::retirerFond();
				$this->flash( $msg, $ok ? 'ok' : 'err' );
				break;
			default:
				$this->flash( 'Action inconnue.', 'err' );
		}
		redirect( 'parametres/terminaux/apparence' );
	}

	public function apparenceFond() {
		$c = FKC_TerminalMarque::fondChemin();
		if ( ! $c ) { http_response_code( 404 ); return; }
		FKC_TerminalMedia::servir( $c );
	}

	/* ── Configuration d'une borne : horaires, rubriques, aperçu (Phase 3, lot 3 — 1.820.0) ── */

	/** Rubriques du catalogue public d'un pack, avec le nombre d'articles de chacune. */
	protected function rubriquesDuPack( $pack ) {
		$adapt = FKC_TerminalAdapter::pour( $pack );
		$out = array();
		try { $cat = $adapt ? (array) $adapt::catalogue( $pack ) : array(); } catch ( \Throwable $e ) { $cat = array(); }
		foreach ( $cat as $a ) {
			$c = trim( (string) ( $a['categorie'] ?? '' ) );
			if ( '' !== $c ) { $out[ $c ] = ( $out[ $c ] ?? 0 ) + 1; }
		}
		return $out;
	}

	public function configurer( $id ) {
		$t = FKC_Terminal::find( (int) $id );
		if ( ! $t ) { $this->flash( 'Terminal introuvable.', 'err' ); redirect( 'parametres/terminaux' ); return; }
		FKC_View::render( 'parametres::terminaux_configurer', array(
			'title' => 'Paramètres · Terminaux · ' . $t['nom'],
			't' => $t,
			'horaires' => FKC_Terminal::horaires( $t ),
			'ouverture' => FKC_Terminal::ouverture( $t ),
			'jours' => FKC_Terminal::jours(),
			'rubriquesPack' => $this->rubriquesDuPack( (string) $t['pack'] ),
			'rubriques' => FKC_Terminal::rubriques( $t ),
			'flash' => $this->flash(),
		) );
	}

	public function configurerAction( $id ) {
		$id = (int) $id;
		switch ( (string) ( $_POST['action'] ?? '' ) ) {
			case 'horaires':
				list( $ok, $msg ) = FKC_Terminal::enregistrerHoraires( $id, ! empty( $_POST['horaires_actifs'] ), (array) ( $_POST['jours'] ?? array() ) );
				break;
			case 'rubriques':
				$t = FKC_Terminal::find( $id );
				$connues = $t ? array_keys( $this->rubriquesDuPack( (string) $t['pack'] ) ) : array();
				$choix = array_values( array_intersect( array_map( 'strval', (array) ( $_POST['rubriques'] ?? array() ) ), $connues ) );
				if ( $connues && ! $choix ) {
					list( $ok, $msg ) = array( false, 'Gardez au moins une rubrique affichée : une borne sans carte ne sert à rien.' );
					break;
				}
				/* Toutes cochées = aucun filtre : une rubrique AJOUTÉE plus tard au catalogue apparaîtra d'elle-même. */
				if ( count( $choix ) === count( $connues ) ) { $choix = array(); }
				list( $ok, $msg ) = FKC_Terminal::enregistrerRubriques( $id, $choix );
				break;
			default:
				list( $ok, $msg ) = array( false, 'Action inconnue.' );
		}
		$this->flash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'parametres/terminaux/' . $id . '/configurer' );
	}

	/**
	 * APERÇU D'UNE BORNE, depuis l'administration : la page exacte que la borne
	 * affiche (thème, apparence, rubriques, contenus, horaires), SANS jeton —
	 * aucune route de borne n'est appelée, rien n'est envoyé. Les photos passent
	 * par les routes de gestion (session), pas par celles du jeton.
	 */
	public function apercu( $id ) {
		$t = FKC_Terminal::find( (int) $id );
		if ( ! $t ) { http_response_code( 404 ); echo 'Terminal introuvable.'; return; }
		$soc = class_exists( 'FKC_Tenant' ) ? (int) FKC_Tenant::id() : 0;
		$t['societe_id'] = $soc;
		$adapt = FKC_TerminalAdapter::pour( (string) $t['pack'] );
		$ui = FKC_TerminalTheme::resoudre( $t, $adapt, 'clair' );
		$ui['reglages'] = FKC_Terminal::reglages( $t );
		$ui['logo_url'] = ! empty( $ui['marque']['logo'] ) && $soc ? url( 'societes/' . $soc . '/logo' ) : '';
		if ( ! empty( $ui['fond_attente'] ) ) { $ui['fond_attente'] = url( 'parametres/terminaux/apparence/fond' ); }
		$pack = (string) $t['pack'];
		$routeImage = array( 'studio' => 'studio/catalogue/%d/image', 'restaurant' => 'restaurant/cuisine/plat/%d/image' );
		$cat = $adapt ? FKC_Terminal::filtrerCatalogue( $t, (array) $adapt::catalogue( $pack ) ) : array();
		foreach ( $cat as &$a ) {
			if ( ! empty( $a['image'] ) ) { $a['image'] = isset( $routeImage[ $pack ] ) ? url( sprintf( $routeImage[ $pack ], (int) $a['id'] ) ) : ''; }
		}
		unset( $a );
		$promos = FKC_TerminalPromo::publiques( $pack, $cat );
		foreach ( $promos as &$p ) {
			if ( ! empty( $p['image'] ) ) { $p['image'] = url( 'parametres/terminaux/promos/' . (int) $p['id'] . '/image' ); }
		}
		unset( $p );
		/* ?etat=ferme : voir l'écran « Fermé » sans attendre la fermeture. */
		$ouv = FKC_Terminal::ouverture( $t );
		if ( 'ferme' === ( $_GET['etat'] ?? '' ) ) {
			$ouv = array( 'ouvert' => false, 'libelle' => $ouv['ouvert'] ? 'Exemple d\'écran hors des horaires.' : $ouv['libelle'], 'bascule_dans' => 0 );
		}
		FKC_View::render( 'terminal::client', array(
			'terminal' => $t, 'ui' => $ui, 'apercu' => true, 'ouverture' => $ouv, 'promos' => $promos,
			'identite' => ( $adapt && method_exists( $adapt, 'identite' ) ) ? (array) $adapt::identite() : array(),
			'voc' => ( $adapt && method_exists( $adapt, 'vocabulaire' ) ) ? (array) $adapt::vocabulaire() : array(),
			'catalogue' => $cat,
			'peutCommander' => FKC_Terminal::peut( $t, 'commander' ),
			'autoReset' => false,
		), null );
	}
}
