<?php
/**
 * Choix du pack métier par la société — utile uniquement lorsque la licence est
 * délivrée en « multi » (le cabinet laisse la société choisir son vertical).
 * Écrit le paramètre société « pack_actif », lu par FKC_Packs::activeCode().
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_PackController {

	/**
	 * La société peut-elle choisir son pack ? (licence « multi »)
	 *
	 * « Multi » n'a plus jamais voulu dire « tous les packs » depuis 1.680.0 :
	 * il veut dire « le choix appartient à la société, DANS le jeu que
	 * l'éditeur a vendu » (voir FKC_Packs::autorises()). Un multi qui
	 * n'ouvrirait qu'un seul pack ne laisse aucun choix : l'écran le dit
	 * plutôt que d'afficher un sélecteur à une seule ligne.
	 */
	protected function libre() {
		if ( ! class_exists( 'FKC_License' ) || 'multi' !== FKC_License::packCode() ) { return false; }
		return count( FKC_Packs::autorises() ) > 1;
	}

	public function index() {
		FKC_View::render( 'parametres::choix', array(
			'title'   => 'Pack métier', 'module' => '',
			'libre'   => $this->libre(),
			'actif'   => FKC_Packs::activeCode(),
			// SEULS les packs couverts par la licence sont proposés.
			'options' => FKC_Packs::optionsAutorisees(),
			'familles' => FKC_Packs::optionsParFamilleAutorisees(),
			'catalogue' => FKC_Packs::options(), // libellés, pour nommer le pack actif même s'il vient d'être retiré
			'packs_nommes' => class_exists( 'FKC_License' ) ? FKC_License::packsNommes() : false,
			'autorises' => FKC_Packs::autorises(),
			'complementaires' => FKC_Packs::complementaires(),
			'complementaires_max' => class_exists( 'FKC_License' ) ? FKC_License::limit( 'packs_complementaires', -1 ) : -1,
			'flash'   => $this->flash(),
		) );
	}

	/**
	 * Packs COMPLÉMENTAIRES (vrai multi-pack) : en plus du pack principal
	 * ci-dessus, une société peut activer d'autres packs qui tournent
	 * réellement — pas seulement une terminologie de façade (voir
	 * FKC_Packs::complementaires()). Même restriction que le choix du
	 * principal : licence « multi » uniquement.
	 */
	public function complementairesUpdate() {
		if ( ! $this->libre() ) {
			$_SESSION['__pack_flash'] = array( 'type' => 'err', 'msg' => 'Votre licence fixe déjà le pack métier ; contactez votre partenaire FinaKop pour activer le multi-pack.' );
			redirect( 'parametres/pack' );
		}
		$brut  = (array) ( $_POST['complementaires'] ?? array() );
		$codes = array();
		foreach ( $brut as $c ) {
			$c = strtolower( preg_replace( '/[^a-z0-9_]/', '', (string) $c ) );
			if ( $c ) { $codes[] = $c; }
		}
		$demandes  = count( array_unique( $codes ) );
		$refuses   = array();
		foreach ( array_unique( $codes ) as $c ) {
			if ( ! FKC_Packs::estAutorise( $c ) ) { $refuses[] = $c; }
		}
		$appliques = FKC_Packs::setComplementaires( $codes );
		if ( $refuses ) {
			self::purgerCaches();
			$_SESSION['__pack_flash'] = array(
				'type' => 'err',
				'msg'  => count( $refuses ) . ' pack(s) non inclus dans votre licence ont été refusés ('
					. implode( ', ', $refuses ) . '). Contactez votre partenaire FinaKop pour les ajouter à votre clé.',
			);
			redirect( 'parametres/pack' );
		}
		self::purgerCaches();
		$n = count( $appliques );
		if ( $n < $demandes ) {
			$max = FKC_License::limit( 'packs_complementaires', -1 );
			$_SESSION['__pack_flash'] = array(
				'type' => 'err',
				'msg'  => 'Votre licence ' . FKC_License::editionLabel() . ' n\'autorise que ' . $max . ' pack(s) complémentaire(s) ; '
					. $n . ' activé(s), les autres ignorés. Passez à un palier supérieur pour en activer davantage.',
			);
		} else {
			$_SESSION['__pack_flash'] = array(
				'type' => 'ok',
				'msg'  => 0 === $n
					? 'Aucun pack complémentaire actif : seul le pack principal tourne.'
					: $n . ' pack(s) complémentaire(s) actif(s). Leurs écrans, comptes et workflows sont disponibles immédiatement, chacun sous sa propre terminologie.',
			);
		}
		redirect( 'parametres/pack' );
	}

	public function update() {
		if ( ! $this->libre() ) {
			$_SESSION['__pack_flash'] = array( 'type' => 'err', 'msg' => 'Votre licence fixe déjà le pack métier ; contactez votre partenaire FinaKop pour en changer.' );
			redirect( 'parametres/pack' );
		}
		$code = strtolower( preg_replace( '/[^a-z0-9_]/', '', (string) ( $_POST['pack'] ?? '' ) ) );
		if ( ! FKC_Packs::exists( $code ) || 'multi' === $code ) {
			$_SESSION['__pack_flash'] = array( 'type' => 'err', 'msg' => 'Pack métier inconnu.' );
			redirect( 'parametres/pack' );
		}
		/*
		 * Le pack existe sur disque mais n'a pas été vendu : REFUS. L'écran ne
		 * le proposait pas ; ce contrôle vaut pour la requête forgée.
		 */
		if ( ! FKC_Packs::estAutorise( $code ) ) {
			$_SESSION['__pack_flash'] = array(
				'type' => 'err',
				'msg'  => 'Ce Pack Métier n\'est pas inclus dans votre licence. Contactez votre partenaire FinaKop pour l\'ajouter à votre clé.',
			);
			redirect( 'parametres/pack' );
		}
		FKC_License::setParam( 'pack_actif', $code );
		/*
		 * Le pack est désormais pris en compte dès la requête suivante : le
		 * routeur re-résout après avoir branché la base de la société. Le message
		 * demandait auparavant de « recharger l'application », ce qui ne servait à
		 * rien — la re-résolution n'était pas appelée sur les routes génériques,
		 * et l'écran affichait indéfiniment l'ancien pack.
		 */
		self::purgerCaches();
		$libelle = (string) ( FKC_Packs::get( $code )['label'] ?? $code );
		$_SESSION['__pack_flash'] = array(
			'type' => 'ok',
			'msg'  => 'Pack métier « ' . $libelle . ' » activé. Ses écrans et sa terminologie sont disponibles immédiatement ; '
				. 'les comptes propres au secteur ont été ajoutés au plan comptable de l\'entité.',
		);
		redirect( 'parametres/pack' );
	}

	/**
	 * Purge les caches liés au pack, pour que la redirection qui suit affiche
	 * bien le nouveau choix et non celui qui vient d'être remplacé.
	 */
	protected static function purgerCaches() {
		if ( class_exists( 'FKC_License' ) ) { FKC_License::reresolve(); }
		if ( class_exists( 'FKC_Packs' ) )   { FKC_Packs::reset(); }
	}

	protected function flash() {
		$f = $_SESSION['__pack_flash'] ?? null;
		unset( $_SESSION['__pack_flash'] );
		return $f;
	}
}
