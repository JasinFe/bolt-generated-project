<?php
/**
 * MODE HORS LIGNE — service worker, manifeste et écran d'état.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * POURQUOI LE SERVICE WORKER EST SERVI PAR UNE ROUTE, ET NON EN FICHIER
 *
 * C'est la contrainte qui décide de toute l'architecture de ce lot, et elle
 * n'est pas négociable : LA PORTÉE D'UN SERVICE WORKER EST LIMITÉE PAR LE
 * CHEMIN D'OÙ IL EST SERVI. Un worker chargé depuis
 * `/wp-content/plugins/finakop-erp-core/app/assets/js/sw.js` ne peut
 * intercepter QUE les requêtes de ce dossier — c'est-à-dire les images et les
 * feuilles de style, et rien de l'application.
 *
 * Or `fkc_asset()` sert justement les fichiers depuis le dossier du plugin,
 * à un chemin sans rapport avec FKC_BASE_URL. Livrer `sw.js` en simple
 * fichier aurait donc produit un mode hors ligne parfaitement inopérant, et
 * silencieusement : l'enregistrement RÉUSSIT, le worker s'installe, et il
 * n'intercepte jamais rien. On aurait cherché longtemps.
 *
 * Le worker est donc rendu par une route sous la racine de l'application. La
 * portée en découle naturellement, sans en-tête particulier.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CE QUE LE WORKER MET EN CACHE, ET CE QU'IL NE MET SURTOUT PAS
 *
 * IL MET EN CACHE LA COQUILLE : la feuille de style, les scripts, le logo,
 * l'écran de caisse. De quoi ouvrir l'interface sans réseau.
 *
 * IL NE MET PAS EN CACHE LES DONNÉES MÉTIER. Servir un solde, un stock ou une
 * balance depuis un cache serait pire que de ne rien afficher : l'utilisateur
 * lirait un chiffre périmé sans savoir qu'il l'est, et prendrait une décision
 * dessus. Le principe suivi partout ailleurs dans FinaKop — ne jamais montrer
 * deux vérités pour le même fait — vaut ici aussi.
 *
 * Toute requête qui n'est pas la coquille passe par le réseau, et échoue
 * franchement s'il n'y a pas de réseau. C'est à l'écran de caisse de dire
 * qu'il travaille hors ligne, pas au cache de faire semblant.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_HorsLigneController {

	/**
	 * Sert le service worker.
	 *
	 * Public et sans session : le navigateur va le rechercher périodiquement,
	 * y compris quand aucun utilisateur n'est connecté. Exiger une session
	 * ferait échouer la mise à jour du worker sans que rien ne le signale.
	 */
	public function sw() {
		$js = self::workerJs();
		if ( ! headers_sent() ) {
			header( 'Content-Type: application/javascript; charset=utf-8' );
			// Portée explicite : le worker est servi à la racine de
			// l'application, mais l'en-tête rend l'intention lisible et
			// couvre les hébergements qui réécrivent les chemins.
			header( 'Service-Worker-Allowed: ' . ( FKC_BASE_PATH ?: '/' ) );
			// Jamais mis en cache : c'est LUI qui gère le cache, et un worker
			// figé par un cache intermédiaire ne se mettrait plus jamais à jour.
			header( 'Cache-Control: no-cache, must-revalidate' );
		}
		echo $js;
		exit;
	}

	/** Manifeste d'application, pour l'installation sur l'écran d'accueil. */
	public function manifeste() {
		$m = array(
			'name'             => 'FinaKop — Caisse',
			'short_name'       => 'FinaKop',
			'start_url'        => url( 'caisse' ),
			'scope'            => FKC_BASE_PATH ?: '/',
			'display'          => 'standalone',
			'background_color' => '#0f1720',
			'theme_color'      => '#0f1720',
			'icons'            => array(
				array( 'src' => fkc_asset( 'img/logo-256.png' ), 'sizes' => '256x256', 'type' => 'image/png', 'purpose' => 'any' ),
			),
		);
		if ( ! headers_sent() ) { header( 'Content-Type: application/manifest+json; charset=utf-8' ); }
		echo json_encode( $m, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	/** Écran d'état : blocs de numéros, file en attente, dernier envoi. */
	public function etat() {
		$poste = FKC_HorsLigneEtat::poste();
		FKC_View::render( 'parametres::hors_ligne', array(
			'title'   => 'Mode hors ligne',
			'poste'   => $poste,
			'blocs'   => class_exists( 'FKC_NumeroBloc' ) ? FKC_NumeroBloc::blocs( null, 50 ) : array(),
			'types'   => class_exists( 'FKC_HorsLigne' ) ? FKC_HorsLigne::types() : array(),
			'series'  => class_exists( 'FKC_Numerotation' ) ? FKC_Numerotation::series() : array(),
			'flash'   => $this->flash(),
		) );
	}

	/** Réserve un bloc de numéros pour un poste. À faire EN LIGNE. */
	public function reserver() {
		$serie  = (string) ( $_POST['serie'] ?? '' );
		$poste  = (string) ( $_POST['poste'] ?? '' );
		$taille = (int) ( $_POST['taille'] ?? FKC_NumeroBloc::TAILLE );
		list( $ok, $msg ) = FKC_NumeroBloc::reserver( $serie, $poste, $taille );
		$_SESSION['__hl_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( 'parametres/hors-ligne' );
	}

	protected function flash() {
		$f = $_SESSION['__hl_flash'] ?? null;
		unset( $_SESSION['__hl_flash'] );
		return $f;
	}

	/**
	 * Le corps du service worker.
	 *
	 * Écrit ici plutôt que dans un fichier d'assets pour une seule raison :
	 * il doit être servi par cette route (voir l'en-tête). Les URL sont
	 * calculées côté PHP — le worker ne doit pas deviner le chemin de base,
	 * qui varie selon que FinaKop tourne sur un sous-domaine ou dans un
	 * sous-répertoire.
	 */
	public static function workerJs() {
		$version = defined( 'FKC_VERSION' ) ? FKC_VERSION : '0';
		$coquille = array(
			fkc_asset( 'css/app.css' ),
			fkc_asset( 'js/app.js' ),
			fkc_asset( 'js/csrf.js' ),
			fkc_asset( 'js/pos.js' ),
			fkc_asset( 'js/hors-ligne.js' ),
			fkc_asset( 'img/logo.png' ),
		);
		$json = json_encode( $coquille, JSON_UNESCAPED_SLASHES );
		$base = json_encode( rtrim( FKC_BASE_URL, '/' ), JSON_UNESCAPED_SLASHES );

		return <<<JS
/* FinaKop — service worker. Généré par FKC_HorsLigneController. */
var CACHE = 'fkc-coquille-{$version}';
var COQUILLE = {$json};
var BASE = {$base};

self.addEventListener('install', function (e) {
	/*
	 * On ne fait PAS échouer l'installation si un fichier manque : un asset
	 * renommé entre deux versions empêcherait sinon toute mise à jour du
	 * worker, et le mode hors ligne resterait bloqué sur l'ancien.
	 */
	e.waitUntil(
		caches.open(CACHE).then(function (c) {
			return Promise.all(COQUILLE.map(function (u) {
				return c.add(u).catch(function () { return null; });
			}));
		}).then(function () { return self.skipWaiting(); })
	);
});

self.addEventListener('activate', function (e) {
	e.waitUntil(
		caches.keys().then(function (noms) {
			return Promise.all(noms.map(function (n) {
				return n !== CACHE ? caches.delete(n) : null;
			}));
		}).then(function () { return self.clients.claim(); })
	);
});

self.addEventListener('fetch', function (e) {
	var req = e.request;
	if (req.method !== 'GET') { return; }

	/*
	 * SEULE LA COQUILLE EST SERVIE DEPUIS LE CACHE.
	 *
	 * Tout le reste passe par le réseau et échoue franchement s'il n'y en a
	 * pas. Servir une donnée métier périmée — un solde, un stock — serait pire
	 * que de ne rien afficher : l'utilisateur lirait un chiffre faux sans
	 * savoir qu'il l'est, et déciderait dessus.
	 */
	var estCoquille = COQUILLE.some(function (u) { return req.url.indexOf(u) === 0 || u === req.url; });
	if (estCoquille) {
		e.respondWith(caches.match(req).then(function (r) { return r || fetch(req); }));
		return;
	}

	/* L'écran de caisse : réseau d'abord, coquille en secours. */
	if (req.mode === 'navigate' && req.url.indexOf(BASE + '/caisse') === 0) {
		e.respondWith(
			fetch(req).then(function (r) {
				var copie = r.clone();
				caches.open(CACHE).then(function (c) { c.put(req, copie); });
				return r;
			}).catch(function () {
				return caches.match(req).then(function (r) {
					return r || new Response(
						'<!doctype html><meta charset="utf-8"><body style="font-family:system-ui;padding:24px;background:#0f1720;color:#cfe0ee">' +
						'<h2>Hors ligne</h2><p>La caisse n\\'a pas encore été ouverte en ligne sur cet appareil. ' +
						'Reconnectez-vous une fois pour l\\'installer.</p></body>',
						{ headers: { 'Content-Type': 'text/html; charset=utf-8' } }
					);
				});
			})
		);
	}
});

/*
 * ── NOTIFICATIONS POUSSÉES (FinaKop Connect) ────────────────────────────
 *
 * La poussée ne transporte AUCUN contenu : c'est délibéré. Le texte d'une
 * conversation d'entreprise n'a pas à transiter par le service du fabricant
 * du navigateur, fût-il chiffré. Le worker, réveillé, redemande à FinaKop ce
 * qu'il doit afficher — avec la session de l'utilisateur, donc ses droits.
 *
 * Conséquence assumée : sans réseau au moment du réveil, la notification est
 * générique. Mieux vaut « vous avez des messages » que le titre d'une
 * conversation dont l'utilisateur vient d'être retiré.
 */
self.addEventListener('push', function (e) {
	e.waitUntil(
		fetch(BASE + '/connect/badge', { credentials: 'include', cache: 'no-store' })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (d) {
				if (d && d.ok && d.n > 0) {
					var titre = d.fils > 1 ? (d.n + ' messages · ' + d.fils + ' conversations') : (d.titre || 'Nouveau message');
					return self.registration.showNotification('FinaKop Connect', {
						body: titre,
						tag: 'fkc-connect',        /* remplace la précédente au lieu d'empiler */
						renotify: false,
						data: { url: (d.url || (BASE + '/connect')) }
					});
				}
				/* d.n === 0 : lu ailleurs entre-temps. On n'affiche rien plutôt
				   qu'une notification vide — mais la norme impose d'en montrer
				   une si l'on a été réveillé, sinon le navigateur finit par
				   révoquer l'abonnement. On la referme aussitôt. */
				return self.registration.showNotification('FinaKop', {
					body: 'À jour.', tag: 'fkc-connect', silent: true
				}).then(function () {
					return self.registration.getNotifications({ tag: 'fkc-connect' })
						.then(function (ns) { ns.forEach(function (n) { n.close(); }); });
				});
			})
			.catch(function () {
				return self.registration.showNotification('FinaKop Connect', {
					body: 'Vous avez des messages non lus.', tag: 'fkc-connect',
					data: { url: BASE + '/connect' }
				});
			})
	);
});

self.addEventListener('notificationclick', function (e) {
	e.notification.close();
	var cible = (e.notification.data && e.notification.data.url) || (BASE + '/connect');
	e.waitUntil(
		self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (ls) {
			/* Un onglet FinaKop déjà ouvert est RÉUTILISÉ : ouvrir un second
			   onglet à chaque notification est la meilleure façon d'en avoir
			   quinze en fin de journée. */
			for (var i = 0; i < ls.length; i++) {
				if (ls[i].url.indexOf(BASE) === 0 && 'focus' in ls[i]) { ls[i].navigate(cible); return ls[i].focus(); }
			}
			return self.clients.openWindow(cible);
		})
	);
});
JS;
	}
}

/**
 * État du poste courant.
 *
 * Le poste est identifié par un jeton posé dans un cookie de longue durée, et
 * NON par l'utilisateur connecté : un même caissier peut travailler sur deux
 * tablettes, et deux caissiers se relayer sur la même. C'est le MATÉRIEL qui
 * détient un bloc de numéros, pas la personne — sans quoi une relève d'équipe
 * ferait changer de bloc en pleine session.
 */
class FKC_HorsLigneEtat {

	const COOKIE = 'fkc_poste';

	/** Identifiant stable du poste, créé au premier passage. */
	public static function poste() {
		$p = isset( $_COOKIE[ self::COOKIE ] ) ? preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $_COOKIE[ self::COOKIE ] ) : '';
		if ( '' !== $p ) { return $p; }
		$p = 'p-' . bin2hex( random_bytes( 4 ) );
		if ( ! headers_sent() ) {
			setcookie( self::COOKIE, $p, array(
				'expires'  => time() + 5 * 365 * 86400,
				'path'     => FKC_BASE_PATH ?: '/',
				'secure'   => ! empty( $_SERVER['HTTPS'] ),
				'httponly' => false, // lu par le JavaScript de la caisse
				'samesite' => 'Lax',
			) );
			$_COOKIE[ self::COOKIE ] = $p;
		}
		return $p;
	}
}
