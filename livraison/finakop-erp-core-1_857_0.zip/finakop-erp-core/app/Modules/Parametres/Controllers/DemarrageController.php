<?php
/**
 * Parcours de démarrage en cinq étapes.
 *
 * Le métier n'est PAS demandé : il est activé par la licence, et le parcours
 * se contente de l'afficher. Ce que la société règle ici tient en trois
 * choses, toutes de PRÉSENTATION : sa façon de travailler, les modules
 * qu'elle veut voir parmi ceux que sa licence accorde, et la densité d'écran.
 *
 * L'activation d'un module ou d'une fonctionnalité reste un acte de
 * l'éditeur, depuis le générateur de licences. Aucun écran client ne peut
 * s'ouvrir un droit — c'est la propriété qui rend le jeton signé utile.
 *
 * (Famille et métier ne redeviennent des questions que pour un jeton délivré
 * en « multi », vendu précisément pour laisser ce choix à la société.)
 *
 * Le parcours vit sur UNE seule page : les cinq questions tiennent dans un
 * formulaire, et la réponse arrive d'un bloc. Un assistant à cinq pages
 * aurait exigé de conserver l'état entre les requêtes — donc une session, donc
 * un état à purger, donc un état qui se désynchronise. Cinq questions ne
 * valent pas cette machinerie, et la page unique laisse voir d'un coup d'œil
 * tout ce qui sera demandé.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_DemarrageController {

	public function index() {
		$flash = $_SESSION['__demarrage_flash'] ?? null;
		unset( $_SESSION['__demarrage_flash'] );

		FKC_View::render( 'demarrage', array(
			'title'        => 'Démarrage',
			'module'       => '',
			'societe'      => FKC_Tenant::current(),
			'packLibre'    => FKC_Onboarding::packLibre(),
			'packActif'    => class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : '',
			'familles'     => class_exists( 'FKC_Packs' ) ? FKC_Packs::optionsParFamilleAutorisees() : array(),
			'tailles'      => FKC_Onboarding::tailles(),
			'tailleActive' => FKC_Onboarding::effectif(),
			'facons'       => FKC_Onboarding::faconsTravail(),
			'faconsActives' => FKC_Onboarding::faconsRetenues(),
			'faconActive'  => FKC_Onboarding::faconTravail(),
			'roles'        => $this->rolesProposes(),
			'rolesActifs'  => FKC_Onboarding::rolesRetenus(),
			'roleActif'    => '',
			'modules'      => FKC_Onboarding::modulesProposables(),
			'choisis'      => FKC_Onboarding::modulesChoisis(),
			'fait'         => FKC_Onboarding::estFait(),
			'flash'        => $flash,
		) );
	}

	/**
	 * Les rôles proposés à la cinquième question.
	 *
	 * Un échantillon, pas le catalogue complet : le référentiel en compte
	 * plusieurs dizaines, et les faire défiler ici ferait manquer la question
	 * à tout le monde. On retient les postes qui recouvrent l'immense majorité
	 * des cas, un par niveau d'affichage.
	 *
	 * Le catalogue entier reste accessible dans l'écran des utilisateurs —
	 * c'est là que les rôles s'attribuent, avec journal et révocation.
	 */
	protected function rolesProposes() {
		$vedettes = array( 'direction', 'comptable', 'responsable_commercial',
			'responsable_caisse', 'caissier', 'magasinier', 'assistant' );
		$out = array();
		if ( ! class_exists( 'FKC_RoleEngine' ) ) { return $out; }
		foreach ( $vedettes as $code ) {
			if ( ! FKC_RoleEngine::existe( $code ) ) { continue; }
			$mode = class_exists( 'FKC_ModeUI' ) ? FKC_ModeUI::modeDuRole( $code ) : '';
			$out[ $code ] = array(
				'libelle'   => FKC_RoleEngine::libelle( $code ),
				'mode'      => $mode,
				'mode_meta' => ( $mode && class_exists( 'FKC_ModeUI' ) ) ? FKC_ModeUI::meta( $mode ) : null,
			);
		}
		return $out;
	}

	/** Enregistre les réponses. POST : le parcours écrit des paramètres. */
	public function enregistrer() {
		if ( ! FKC_Auth::isAdmin() ) {
			$_SESSION['__demarrage_flash'] = array( 'type' => 'err',
				'msg' => 'Seul un administrateur peut configurer le démarrage de l\'entité.' );
			redirect( 'demarrage' );
		}

		$pack   = (string) ( $_POST['pack'] ?? '' );
		$taille = (string) ( $_POST['taille'] ?? '' );
		// Aucune case cochée n'est pas la même chose qu'une étape sautée :
		// le témoin dit si la question a été posée à cet écran.
		$modules = isset( $_POST['modules_poses'] ) ? (array) ( $_POST['modules'] ?? array() ) : null;
		/*
		 * L'ORDRE DE SÉLECTION EST CELUI QUE L'UTILISATEUR A DONNÉ.
		 *
		 * Le navigateur poste les cases dans l'ordre du formulaire, pas dans
		 * celui des clics — un hôtel qui coche « réservations » d'abord et
		 * « comptoir » ensuite verrait le comptoir passer devant, sans rien
		 * avoir demandé. Un champ caché rempli par le script porte donc
		 * l'ordre réel ; sans script, on retombe sur l'ordre du formulaire,
		 * qui reste un ordre raisonnable.
		 */
		$facon = (array) ( $_POST['facon'] ?? array() );
		$ordre = array_filter( array_map( 'trim', explode( ',', (string) ( $_POST['facon_ordre'] ?? '' ) ) ) );
		if ( $ordre ) {
			$connues = $facon;
			$facon = array();
			foreach ( $ordre as $c ) {
				if ( in_array( $c, $connues, true ) ) { $facon[] = $c; }
			}
			foreach ( $connues as $c ) {
				if ( ! in_array( $c, $facon, true ) ) { $facon[] = $c; }
			}
		}
		/*
		 * Même mécanique que pour les façons de travailler : l'ordre des
		 * clics prime sur l'ordre de la page, et le contrôleur retombe sur
		 * celui de la page quand le script est absent.
		 */
		$role = (array) ( $_POST['role'] ?? array() );
		$ordreR = array_filter( array_map( 'trim', explode( ',', (string) ( $_POST['role_ordre'] ?? '' ) ) ) );
		if ( $ordreR ) {
			$connus = $role;
			$role = array();
			foreach ( $ordreR as $c ) {
				if ( in_array( $c, $connus, true ) ) { $role[] = $c; }
			}
			foreach ( $connus as $c ) {
				if ( ! in_array( $c, $role, true ) ) { $role[] = $c; }
			}
		}

		// La famille (étape 1) n'est PAS enregistrée : elle ne sert qu'à
		// réduire la liste des métiers à l'écran. Elle se déduit du pack, et
		// stocker une donnée déductible, c'est se préparer à la voir diverger.
		$journal = FKC_Onboarding::appliquer( $pack, $taille, $modules, $facon, $role );

		// Le pack et le mode viennent de changer : les caches doivent tomber,
		// sinon l'écran suivant montrerait encore l'ancienne configuration.
		if ( class_exists( 'FKC_License' ) ) { FKC_License::reresolve(); }
		if ( class_exists( 'FKC_Packs' ) )   { FKC_Packs::reset(); }
		if ( class_exists( 'FKC_ModeUI' ) )  { FKC_ModeUI::oublier(); }
		if ( class_exists( 'FKC_Ux' ) )      { FKC_Ux::oublier(); }

		$_SESSION['__demarrage_flash'] = array(
			'type'    => 'ok',
			'msg'     => 'Votre espace FinaKop est prêt.',
			'journal' => $journal,
		);
		redirect( 'demarrage/pret' );
	}

	/** « Votre espace FinaKop est prêt. » */
	public function pret() {
		$flash = $_SESSION['__demarrage_flash'] ?? null;
		unset( $_SESSION['__demarrage_flash'] );
		FKC_View::render( 'demarrage_pret', array(
			'title'   => 'Votre espace est prêt',
			'module'  => '',
			'resume'  => FKC_Onboarding::resume(),
			'tailles' => FKC_Onboarding::tailles(),
			'journal' => $flash['journal'] ?? array(),
			'societe' => FKC_Tenant::current(),
		) );
	}

    /** Écarte définitivement l'invitation, sans rien configurer. */
	public function ecarter() {
		if ( FKC_Auth::isAdmin() ) { FKC_Onboarding::marquerFait( 'ecarte' ); }
		redirect( '' );
	}
}
