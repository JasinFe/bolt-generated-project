<?php
/** Exercices comptables : ouverture, à-nouveaux (report des soldes de bilan). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Exercice {

	/* ── Bornes de l'exercice ────────────────────────────────────────────── */

	/** @var array|null Mémoïsation du couple (mois, jour) de début. */
	protected static $debut = null;

	/**
	 * Premier jour de l'exercice, au format array( mois, jour ).
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UN EXERCICE N'EST PAS FORCÉMENT UNE ANNÉE CIVILE (1.544.0)
	 *
	 * L'AUDCIF laisse l'exercice durer douze mois sans imposer qu'il commence
	 * le 1er janvier : une école clôture en juillet, une filiale s'aligne sur
	 * sa maison mère, une exploitation agricole suit sa campagne. Toute la
	 * comptabilité de FinaKop supposait pourtant le 01/01–31/12, en dur, à une
	 * dizaine d'endroits.
	 *
	 * Ce n'était pas une limitation cosmétique. Chez un dossier à exercice
	 * décalé, la clôture annuelle soldait douze mois qui n'étaient pas les
	 * siens, le compte de résultat mélangeait deux exercices, la dotation
	 * d'amortissement tombait au 31/12 au lieu de la date de clôture, et le
	 * bilan remis à la DGI ne couvrait pas la période déclarée. Les chiffres
	 * étaient faux sans que rien ne le signale.
	 *
	 * Le champ existait déjà : `societes.exercice_debut`, présent en base et
	 * sur la fiche société depuis longtemps — mais lu NULLE PART. On s'y
	 * raccorde plutôt que d'inventer un second réglage : deux endroits pour
	 * dire la même chose finissent toujours par se contredire.
	 *
	 * Seuls le mois et le jour comptent ; l'année saisie n'a pas de sens ici.
	 * Défaut : 1er janvier — un dossier qui n'a rien renseigné garde très
	 * exactement le comportement d'avant.
	 * ─────────────────────────────────────────────────────────────────────
	 */
	public static function debut() {
		if ( null !== self::$debut ) { return self::$debut; }
		self::$debut = array( 1, 1 );
		try {
			/*
			 * LA SOCIÉTÉ DE LA BASE BRANCHÉE, PAS CELLE DE LA SESSION (1.803.0).
			 *
			 * current() lit la société mémorisée en session. Dans un balayage
			 * multi-sociétés (consolidation, balayeur, lecture d'un dossier
			 * client par le cabinet), la base branchée n'est PAS celle-là :
			 * l'exercice décalé de la société de session s'appliquait aux
			 * livres d'une autre. On retrouve donc la société par le fichier
			 * réellement branché, et l'on ne retombe sur la session qu'à
			 * défaut.
			 */
			$soc = null;
			if ( class_exists( 'FKC_Master' ) && class_exists( 'FKC_DB' ) ) {
				try {
					$soc = FKC_Master::q( 'SELECT * FROM societes WHERE db_file=?', array( basename( (string) FKC_DB::file() ) ) )->fetch() ?: null;
				} catch ( \Throwable $e ) { $soc = null; }
			}
			if ( ! $soc ) { $soc = class_exists( 'FKC_Tenant' ) ? FKC_Tenant::current() : null; }
			$d   = trim( (string) ( $soc['exercice_debut'] ?? '' ) );
			if ( preg_match( '/^\d{4}-(\d{2})-(\d{2})$/', $d, $m ) ) {
				$mois = (int) $m[1]; $jour = (int) $m[2];
				/*
				 * Un exercice qui commencerait le 31 du mois serait
				 * ingérable : sa borne de fin tomberait un 30 février une
				 * année sur quatre. On ne « corrige » pas en silence — on
				 * ignore une saisie qu'on ne sait pas honorer, et on reste au
				 * 1er janvier, comportement connu et sûr.
				 */
				if ( $mois >= 1 && $mois <= 12 && $jour >= 1 && $jour <= 28 ) {
					self::$debut = array( $mois, $jour );
				}
			}
		} catch ( \Throwable $e ) { /* hors session : on garde l'année civile */ }
		return self::$debut;
	}

	/** L'exercice suit-il l'année civile ? */
	public static function estCalendaire() {
		$d = self::debut();
		return 1 === $d[0] && 1 === $d[1];
	}

	/**
	 * Bornes d'un exercice.
	 *
	 * CONVENTION : l'exercice porte le millésime de l'année où il SE TERMINE.
	 * Un exercice ouvert le 01/07/2025 et clos le 30/06/2026 est « 2026 ».
	 * C'est la convention de la clôture — celle sous laquelle le dossier est
	 * déposé — et elle a l'avantage de coïncider avec l'année civile quand
	 * l'exercice l'est aussi : aucun dossier existant ne change de millésime.
	 *
	 * @param int $annee Millésime de l'exercice.
	 * @return array{string, string} ( premier jour, dernier jour )
	 */
	public static function bornes( $annee ) {
		$annee = (int) $annee;
		list( $m, $j ) = self::debut();
		if ( 1 === $m && 1 === $j ) {
			return array( sprintf( '%04d-01-01', $annee ), sprintf( '%04d-12-31', $annee ) );
		}
		$debut = sprintf( '%04d-%02d-%02d', $annee - 1, $m, $j );
		$fin   = date( 'Y-m-d', strtotime( $debut . ' +1 year -1 day' ) );
		return array( $debut, $fin );
	}

	/** Premier / dernier jour d'un exercice (raccourcis de lecture). */
	public static function debutDe( $annee ) { $b = self::bornes( $annee ); return $b[0]; }
	public static function finDe( $annee )   { $b = self::bornes( $annee ); return $b[1]; }

	/**
	 * Millésime de l'exercice auquel appartient une date.
	 *
	 * C'est la fonction qui remplace `date('Y')` partout où l'on voulait dire
	 * « l'exercice en cours » et non « l'année en cours ».
	 */
	public static function annee( $date = null ) {
		$ts = $date ? strtotime( (string) $date ) : time();
		if ( ! $ts ) { $ts = time(); }
		$an = (int) date( 'Y', $ts );
		if ( self::estCalendaire() ) { return $an; }
		list( $m, $j ) = self::debut();
		/*
		 * L'exercice porte le millésime de l'année où il SE TERMINE.
		 * Une date postérieure à l'ouverture appartient donc à l'exercice qui
		 * se clôturera l'année SUIVANTE ; une date antérieure appartient à
		 * celui ouvert l'année passée, qui se clôture cette année.
		 *
		 * Pour un début au 1er juillet : août 2025 → 2026 ; janvier 2026 →
		 * 2026 ; le 1er juillet 2026 ouvre l'exercice 2027.
		 */
		$ouverture = sprintf( '%04d-%02d-%02d', $an, $m, $j );
		return ( date( 'Y-m-d', $ts ) >= $ouverture ) ? $an + 1 : $an;
	}

	/** Millésime de l'exercice en cours. */
	public static function courant() { return self::annee( null ); }

	/**
	 * Libellé lisible d'un exercice : « 2026 » ou « 2026 (01/07/2025 → 30/06/2026) ».
	 *
	 * Un exercice décalé doit s'annoncer partout où il s'affiche : « clôture
	 * annuelle 2026 » sans ses dates laisserait croire à l'année civile.
	 */
	public static function libelle( $annee ) {
		if ( self::estCalendaire() ) { return (string) (int) $annee; }
		list( $d, $f ) = self::bornes( $annee );
		return (int) $annee . ' (' . date( 'd/m/Y', strtotime( $d ) ) . ' → ' . date( 'd/m/Y', strtotime( $f ) ) . ')';
	}

	/** Réinitialise la mémoïsation (changement de société, tests). */
	public static function reset() { self::$debut = null; }

	/**
	 * Liste unifiée des exercices/années disponibles dans toute l'application :
	 * exercices déclarés (table exercices) ∪ années avec mouvements ∪ année courante.
	 * Source unique pour tous les sélecteurs d'exercice (tableau de bord, écritures, états, analytique…).
	 */
	public static function annees() {
		$ys = array();
		try {
			foreach ( FKC_DB::q( 'SELECT annee FROM exercices' )->fetchAll() as $r ) {
				if ( ! empty( $r['annee'] ) ) { $ys[] = (string) (int) $r['annee']; }
			}
		} catch ( \Throwable $e ) { /* table absente */ }
		try {
			foreach ( FKC_DB::q( "SELECT DISTINCT substr(date_ecriture,1,4) y FROM ecritures WHERE date_ecriture IS NOT NULL UNION SELECT DISTINCT substr(date_facture,1,4) FROM factures WHERE date_facture IS NOT NULL" )->fetchAll() as $r ) {
				if ( ! empty( $r['y'] ) ) { $ys[] = (string) $r['y']; }
			}
		} catch ( \Throwable $e ) { /* tables absentes */ }
		// L'exercice EN COURS, pas l'année en cours : sur un exercice décalé,
		// janvier appartient encore au millésime précédent.
		$cur = (string) self::courant();
		if ( ! in_array( $cur, $ys, true ) ) { $ys[] = $cur; }
		$ys = array_values( array_unique( array_filter( $ys ) ) );
		rsort( $ys );
		return $ys;
	}

	/** Liste des exercices ouverts, avec statut clôturé dérivé des clôtures annuelles. */
	public static function all() {
		$rows = FKC_DB::q( 'SELECT * FROM exercices ORDER BY annee DESC' )->fetchAll();
		foreach ( $rows as &$r ) {
			list( $deb, $fin ) = self::bornes( (int) $r['annee'] );
			$r['periode_debut'] = $deb; $r['periode_fin'] = $fin;
			$r['cloture_annuelle'] = (bool) FKC_DB::q(
				"SELECT 1 FROM clotures WHERE type='annuelle' AND periode_debut=? AND periode_fin=?",
				array( $deb, $fin )
			)->fetch();
		}
		return $rows;
	}

	public static function find( $annee ) {
		$r = FKC_DB::q( 'SELECT * FROM exercices WHERE annee=?', array( (int) $annee ) )->fetch();
		return $r ?: null;
	}

	public static function isOpen( $annee ) {
		return (bool) self::find( $annee );
	}

	/**
	 * Ouvre un exercice, avec ses à-nouveaux.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * L'OUVERTURE N'EST PLUS « RÉUSSIE » QUAND LES À-NOUVEAUX ONT ÉCHOUÉ.
	 *
	 * L'ancienne version portait, en toutes lettres, un commentaire disant que
	 * l'échec des à-nouveaux n'était pas bloquant et qu'on ouvrait l'exercice
	 * quand même, sans eux.
	 *
	 * L'intention était bonne — ne pas coincer l'utilisateur — mais l'effet
	 * était le pire possible. L'exercice s'ouvrait sur une balance VIDE :
	 * plus de capital, plus d'immobilisations, plus de créances, plus de
	 * dettes, plus de trésorerie. Et l'écran annonçait « Exercice 2026
	 * ouvert. » en vert, le motif de l'échec des à-nouveaux étant ajouté à la
	 * suite du même message de succès — là où personne ne le lit.
	 *
	 * On saisissait alors trois mois sur une comptabilité amputée de tout son
	 * passé. Au moment où quelqu'un s'en apercevait, il fallait supprimer ces
	 * trois mois pour pouvoir régénérer les à-nouveaux.
	 *
	 * Désormais : un échec des à-nouveaux REFUSE l'ouverture, et dit pourquoi.
	 * Deux exceptions, toutes deux explicites :
	 *
	 *   — il n'y a RIEN à reporter (première année d'exploitation, ou reprise
	 *     de bilan par le module de migration). Ce n'est pas un échec, et
	 *     l'ouverture se fait normalement ;
	 *   — l'utilisateur demande expressément une ouverture SANS à-nouveaux
	 *     ($reportAN = false), ou passe outre par procédure exceptionnelle
	 *     ($opts['forcer'] avec motif). Le choix est alors conscient, tracé,
	 *     et l'exercice porte la mention au journal de clôture.
	 *
	 * @param int   $annee
	 * @param bool  $reportAN Générer les à-nouveaux.
	 * @param array $opts     forcer (bool), motif (string), detail_auxiliaire (bool)
	 * @return array{bool, string} ( bool ok, string message )
	 */
	public static function ouvrir( $annee, $reportAN = true, array $opts = array() ) {
		$annee = (int) $annee;
		if ( $annee < 2000 || $annee > 2100 ) { return array( false, 'Année invalide.' ); }
		if ( self::isOpen( $annee ) ) { return array( false, 'L\'exercice ' . $annee . ' est déjà ouvert.' ); }

		$moteur = class_exists( 'FKC_ANouveaux' );

		/*
		 * PAS D'OUVERTURE SUR UNE OUVERTURE NON FIABLE (1.799.0) — pas même
		 * par la procédure exceptionnelle. Ouvrir « sans À-nouveaux » ferait
		 * relire à l'exercice la clôture de N-1 ; si l'ouverture de N-1 est
		 * doublée, cette clôture l'est aussi : l'anomalie passerait d'un
		 * exercice à l'autre sous la forme d'un solde calculé.
		 */
		if ( class_exists( 'FKC_SoldeOuverture' ) && FKC_SoldeOuverture::soldesCloture( $annee - 1 ) ) {
			$prec = FKC_SoldeOuverture::fiabilite( $annee - 1 );
			if ( ! $prec['fiable'] ) {
				$msg = 'Ouverture de l\'exercice ' . $annee . ' REFUSÉE — l\'ouverture de ' . ( $annee - 1 ) . ' n\'est pas fiable : '
					. implode( ' ', $prec['raisons'] ) . ' Réparez d\'abord ' . ( $annee - 1 ) . ' depuis l\'Audit des À-nouveaux.';
				if ( class_exists( 'FKC_ClotureJournal' ) ) { FKC_ClotureJournal::tracerRefus( $annee, 'ouverture', $msg ); }
				return array( false, $msg );
			}
		}

		/* ── Contrôles préalables à l'ouverture ──────────────────────────── */

		if ( $reportAN && class_exists( 'FKC_ClotureChecklist' ) ) {
			$s = FKC_ClotureChecklist::synthese( $annee, 'ouverture' );
			if ( (int) $s['bloquants'] > 0 ) {
				$msg = 'Ouverture refusée : ' . implode( ' · ', $s['libelles_bloquants'] ) . '. '
					. 'Un exercice qui s\'ouvre sur des soldes faux ne se répare qu\'en supprimant tout ce qui '
					. 'y aura été saisi entre-temps.';
				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracerRefus( $annee, 'ouverture', $msg );
				}
				return array( false, $msg );
			}
		}

		/*
		 * ═══════════════════════════════════════════════════════════════════
		 *  OUVERTURE ATOMIQUE, RAPPROCHEMENT AUTOMATIQUE (1.793.0)
		 * ═══════════════════════════════════════════════════════════════════
		 *  L'ouverture enchaînait quatre gestes indépendants : à-nouveaux,
		 *  enregistrement de l'exercice, extourne des rattachements, extourne
		 *  des écarts de conversion. Un échec au troisième laissait un exercice
		 *  ouvert, avec ses à-nouveaux, mais des charges de N-1 prêtes à être
		 *  comptées deux fois — un état intermédiaire qu'aucun écran ne
		 *  signalait autrement que par un avertissement dans un message.
		 *
		 *  Les quatre gestes forment désormais UNE transaction, et un
		 *  cinquième la ferme : le RAPPROCHEMENT clôture N ↔ ouverture N+1,
		 *  compte par compte. Si les à-nouveaux ne reprennent pas exactement
		 *  les soldes de clôture, ou si une extourne échoue, RIEN n'est
		 *  conservé : l'exercice n'est pas ouvert, et le refus est consigné.
		 *  La procédure exceptionnelle (ouvrir sans à-nouveaux, motif écrit,
		 *  administrateur) reste possible, et reste la seule.
		 */
		$forcer = ! empty( $opts['forcer'] );
		$motif  = trim( (string) ( $opts['motif'] ?? '' ) );
		$refusOuverture = function ( $msg ) use ( $annee ) {
			if ( class_exists( 'FKC_ClotureJournal' ) ) { FKC_ClotureJournal::tracerRefus( $annee, 'ouverture', $msg ); }
			return array( false, $msg );
		};
		try {
			$res = FKC_Tx::executer( function () use ( $annee, $reportAN, $moteur, $forcer, $motif, $opts ) {
				$eid = null; $msgAN = ''; $rap = null;

				/* ── 1. À-nouveaux ─────────────────────────────────────────── */
				if ( $reportAN && $moteur ) {
					list( $ok, $m, $id ) = FKC_ANouveaux::generer( $annee, array(
						'detail_auxiliaire' => ! isset( $opts['detail_auxiliaire'] ) || (bool) $opts['detail_auxiliaire'],
						'motif' => $motif,
					) );
					if ( ! $ok ) {
						if ( ! $forcer ) {
							throw new \DomainException( 'Ouverture de l\'exercice ' . $annee . ' REFUSÉE — les à-nouveaux n\'ont pas pu être générés. '
								. $m . ' L\'exercice n\'a pas été ouvert : s\'il l\'était, vous saisiriez sur une balance '
								. 'privée de son capital, de ses immobilisations, de ses créances et de sa trésorerie.' );
						}
						if ( mb_strlen( $motif ) < 20 ) {
							throw new \DomainException( 'Ouvrir un exercice sans à-nouveaux alors que leur génération a échoué est '
								. 'une procédure exceptionnelle : elle exige un motif écrit. Cause de l\'échec : ' . $m );
						}
						if ( ! class_exists( 'FKC_Auth' ) || ! FKC_Auth::isAdmin() ) {
							throw new \DomainException( 'Cette procédure exceptionnelle est réservée à l\'administrateur du dossier. '
								. 'Cause de l\'échec des à-nouveaux : ' . $m );
						}
						$msgAN = ' ⚠ OUVERT SANS À-NOUVEAUX par procédure exceptionnelle. Cause : ' . $m
							. ' La balance d\'ouverture est vide : elle devra être reprise avant toute exploitation.';
					} else {
						$eid = $id;
						$msgAN = ' ' . $m;
					}
				} elseif ( ! $reportAN ) {
					$msgAN = ' Aucun à-nouveau généré (choix explicite) : l\'exercice s\'ouvre sur une balance vide. '
						. 'Générez-les depuis Comptabilité → Clôture → À-nouveaux avant de saisir.';
				}

				/* ── 2. Enregistrement de l'exercice ───────────────────────── */
				FKC_DB::q( 'INSERT INTO exercices(annee,an_ecriture_id) VALUES(?,?)', array( $annee, $eid ) );
				// Traçabilité (1.798.0) : exercice source et empreinte de la balance reprise.
				if ( $eid && class_exists( 'FKC_SoldeOuverture' ) ) { FKC_SoldeOuverture::tracerGeneration( $annee, (int) $eid, null ); }

				/* ── 3. Rapprochement automatique clôture N ↔ ouverture N+1 ── */
				if ( $eid && $moteur ) {
					$rap = FKC_ANouveaux::rapprochement( $annee, false );
					if ( empty( $rap['concordant'] ) ) {
						$ex = array();
						foreach ( array_slice( (array) $rap['ecarts'], 0, 5 ) as $l ) {
							$ex[] = $l['numero'] . ' (clôture ' . fkc_money( $l['cloture'] ) . ' / ouverture ' . fkc_money( $l['ouverture'] ) . ')';
						}
						throw new \DomainException( 'Ouverture de l\'exercice ' . $annee . ' REFUSÉE — les à-nouveaux ne reprennent pas les soldes de clôture de '
							. ( $annee - 1 ) . ' : ' . count( (array) $rap['ecarts'] ) . ' compte(s) en écart — ' . implode( ' ; ', $ex )
							. '. Rien n\'a été conservé ; l\'exercice ' . ( $annee - 1 ) . ' est intact.' );
					}
				}

				/* ── 4. Extourne des rattachements de N-1 ──────────────────── */
				$msgExt = '';
				if ( class_exists( 'FKC_Regularisation' ) ) {
					list( $okE, $mE, $nE ) = FKC_Regularisation::extourner( $annee );
					if ( ! $okE ) {
						if ( ! $forcer ) {
							throw new \DomainException( 'Ouverture de l\'exercice ' . $annee . ' REFUSÉE — les rattachements de ' . ( $annee - 1 )
								. ' n\'ont pas pu être extournés : ' . $mE . ' Sans extourne, leurs charges et produits seraient comptés deux fois. Rien n\'a été conservé.' );
						}
						$msgExt = ' ⚠ ' . $mE . ' Ces rattachements doivent être extournés avant toute saisie sur ' . $annee . '.';
					} elseif ( $nE > 0 ) {
						$msgExt = ' ' . $mE;
					}
				}

				/* ── 5. Extourne des écarts de conversion de N-1 ───────────── */
				if ( class_exists( 'FKC_DeviseRevalorisation' ) ) {
					$finPrec = self::finDe( $annee - 1 );
					if ( FKC_DeviseRevalorisation::deja( $finPrec ) ) {
						list( $okD, $mD ) = FKC_DeviseRevalorisation::extourner( $finPrec, self::debutDe( $annee ) );
						if ( $okD ) {
							$msgExt .= ' Écarts de conversion de ' . ( $annee - 1 ) . ' extournés.';
						} elseif ( false === mb_stripos( (string) $mD, 'déjà passée' ) ) {
							if ( ! $forcer ) {
								throw new \DomainException( 'Ouverture de l\'exercice ' . $annee . ' REFUSÉE — écarts de conversion de ' . ( $annee - 1 )
									. ' non extournés : ' . $mD . ' Rien n\'a été conservé.' );
							}
							$msgExt .= ' ⚠ Écarts de conversion non extournés : ' . $mD;
						}
					}
				}
				return array( $eid, $msgAN, $msgExt, $rap );
			} );
		} catch ( \DomainException $e ) {
			return $refusOuverture( $e->getMessage() );
		} catch ( \Throwable $e ) {
			return $refusOuverture( 'Ouverture de l\'exercice ' . $annee . ' REFUSÉE — ' . $e->getMessage() . ' Rien n\'a été conservé.' );
		}
		list( $eid, $msgAN, $msgExt, $rap ) = $res;
		if ( $rap && class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'rapprochement', array(
				'libelle' => 'Rapprochement automatique à l\'ouverture — ' . $rap['message'],
				'detail'  => array( 'comptes' => (int) ( $rap['nb_comptes'] ?? 0 ), 'automatique' => true ),
			) );
		}

		if ( class_exists( 'FKC_ClotureJournal' ) ) {
			FKC_ClotureJournal::tracer( $annee, 'ouverture', array(
				'issue'   => ( $reportAN && ! $eid ) ? 'avertissement' : 'ok',
				'libelle' => 'Exercice ' . $annee . ' ouvert (' . date( 'd/m/Y', strtotime( self::debutDe( $annee ) ) )
					. ' → ' . date( 'd/m/Y', strtotime( self::finDe( $annee ) ) ) . ')' . ( $eid ? ', à-nouveaux générés' : ', sans à-nouveaux' ),
				'motif'   => $motif,
				'ecriture_id' => $eid ? (int) $eid : null,
			) );
		}

		return array( true, 'Exercice ' . $annee . ' ouvert.' . $msgAN . $msgExt );
	}

	/**
	 * Annule l'ouverture d'un exercice.
	 *
	 * ═══════════════════════════════════════════════════════════════════════
	 * CE QU'ELLE FAISAIT, ET CE QUE CELA COÛTAIT.
	 *
	 * Elle supprimait l'écriture d'à-nouveaux, puis la ligne d'exercice —
	 * sans rien regarder, sans transaction, sans trace. Trois défauts en
	 * découlaient :
	 *
	 *   — les LIGNES de l'écriture n'étaient pas retirées. Les clés étrangères
	 *     de SQLite ne sont actives que si PRAGMA foreign_keys est posé ; là
	 *     où il ne l'était pas, l'écriture disparaissait et ses lignes
	 *     restaient, rattachées à un en-tête inexistant. Elles continuaient
	 *     de peser dans la balance ;
	 *   — la suppression de l'écriture pouvait échouer (période entre-temps
	 *     verrouillée, écriture référencée) sans que la ligne d'exercice, elle,
	 *     soit épargnée. Une réouverture générait alors un SECOND jeu
	 *     d'à-nouveaux par-dessus le premier, et le bilan d'ouverture doublait ;
	 *   — un exercice déjà exploité — trois mois de saisie — perdait ses
	 *     soldes d'ouverture sans un mot d'avertissement.
	 *
	 * Tout cela passe désormais par FKC_ANouveaux::annuler(), qui contrôle,
	 * motive, consigne et travaille en transaction.
	 *
	 * @return array{bool,string}
	 */
	public static function annulerOuverture( $annee, $motif = '' ) {
		$annee = (int) $annee;
		$e = self::find( $annee );
		if ( ! $e ) { return array( false, 'L\'exercice ' . $annee . ' n\'est pas ouvert.' ); }

		if ( class_exists( 'FKC_ClotureProcessus' ) && FKC_ClotureProcessus::exerciceClos( $annee ) ) {
			return array( false, 'L\'exercice ' . $annee . ' est clôturé : son ouverture ne peut plus être annulée. '
				. 'Rouvrez d\'abord la clôture annuelle depuis Comptabilité → Clôture.' );
		}

		$motif = trim( (string) $motif );
		if ( mb_strlen( $motif ) < 10 ) {
			return array( false, 'Annuler l\'ouverture d\'un exercice supprime ses soldes d\'ouverture : '
				. 'indiquez le motif (une phrase). Il sera consigné au journal de clôture.' );
		}

		try {
			return FKC_Tx::executer( function () use ( $annee, $motif ) {
				if ( class_exists( 'FKC_ANouveaux' ) && FKC_ANouveaux::existent( $annee ) ) {
					list( $ok, $m ) = FKC_ANouveaux::annuler( $annee, $motif );
					if ( ! $ok ) { throw new \RuntimeException( $m ); }
				}
				FKC_DB::q( 'DELETE FROM exercices WHERE annee=?', array( $annee ) );

				if ( class_exists( 'FKC_ClotureJournal' ) ) {
					FKC_ClotureJournal::tracer( $annee, 'ouverture_annulee', array(
						'issue' => 'avertissement',
						'libelle' => 'Ouverture de l\'exercice ' . $annee . ' annulée',
						'motif' => $motif,
					) );
				}
				return array( true, 'Ouverture de l\'exercice ' . $annee . ' annulée, à-nouveaux compris.' );
			} );
		} catch ( \Throwable $e ) {
			return array( false, $e->getMessage() );
		}
	}

	/* ══════════════════════════════════════════════════════════════════════
	 * À-NOUVEAUX — DÉPLACÉS DANS FKC_ANouveaux (1.778.0)
	 * ══════════════════════════════════════════════════════════════════════
	 *
	 * `genererANouveaux()` et `compteReport()` vivaient ici. Ils ont été
	 * retirés, et pas seulement déménagés : leur mécanisme central était
	 * fautif.
	 *
	 * `genererANouveaux()` terminait par un ÉQUILIBRAGE PAR DIFFÉRENCE :
	 * l'écart entre débits et crédits était logé en 121 ou 129 pour que
	 * l'écriture tombe juste. Or cet écart, c'est presque toujours le
	 * RÉSULTAT de l'exercice précédent, quand sa détermination n'a pas été
	 * faite. Le code affectait donc en report à nouveau, tout seul et sans
	 * trace, un résultat dont aucune assemblée n'avait délibéré — en sautant
	 * l'affectation, qui n'existait d'ailleurs pas encore dans FinaKop.
	 *
	 * Le remplaçant REFUSE et NOMME la cause (FKC_ANouveaux::previsualiser),
	 * conserve le détail auxiliaire des tiers, interdit le doublon, et sait
	 * rapprocher l'ouverture de N+1 de la clôture de N.
	 *
	 * `compteReport()` n'avait plus d'objet : son seul appelant était
	 * l'équilibrage supprimé. Les comptes 121/129 restent accessibles à
	 * l'AFFECTATION du résultat (FKC_Affectation), qui est le seul geste
	 * habilité à les mouvementer — sur décision, et sur pièce.
	 */
}
