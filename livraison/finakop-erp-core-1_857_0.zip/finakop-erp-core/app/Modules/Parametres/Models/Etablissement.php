<?php
/**
 * Établissements d'une entité (succursales / points d'exploitation).
 * Table « etablissements » dans la base de l'entité active.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Etablissement {

	public static function all() {
		return FKC_DB::q( 'SELECT * FROM etablissements ORDER BY principal DESC, code' )->fetchAll();
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM etablissements WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/** Nombre d'établissements actifs (quota de licence). */
	public static function count() {
		return (int) FKC_DB::q( 'SELECT COUNT(*) FROM etablissements WHERE actif=1' )->fetchColumn();
	}

	public static function codeExists( $code, $except = 0 ) {
		return (bool) FKC_DB::q( 'SELECT 1 FROM etablissements WHERE code=? AND id<>?', array( $code, (int) $except ) )->fetchColumn();
	}

	public static function create( $d ) {
		FKC_DB::q(
			'INSERT INTO etablissements(code,libelle,adresse,principal,actif) VALUES(?,?,?,?,1)',
			array(
				strtoupper( trim( (string) ( $d['code'] ?? '' ) ) ),
				trim( (string) ( $d['libelle'] ?? '' ) ),
				trim( (string) ( $d['adresse'] ?? '' ) ) ?: null,
				! empty( $d['principal'] ) ? 1 : 0,
			)
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM etablissements WHERE id=?', array( (int) $id ) );
	}
}
