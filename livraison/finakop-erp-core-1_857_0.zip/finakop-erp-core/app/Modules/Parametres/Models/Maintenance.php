<?php
/** Maintenance des données (admin) : purges de période et réinitialisation d'exercice. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Maintenance {

	/** Exercices (années) présents dans les données. */
	public static function annees() {
		$ys = array();
		$srcs = array(
			"SELECT DISTINCT substr(date_ecriture,1,4) y FROM ecritures",
			"SELECT DISTINCT substr(date_facture,1,4) y FROM factures",
			"SELECT DISTINCT CAST(annee AS TEXT) y FROM paie_bulletins",
		);
		foreach ( $srcs as $sql ) {
			try { foreach ( FKC_DB::q( $sql )->fetchAll() as $r ) { if ( ! empty( $r['y'] ) ) { $ys[] = $r['y']; } } } catch ( Exception $e ) {}
		}
		$cur = date( 'Y' );
		if ( ! in_array( $cur, $ys, true ) ) { $ys[] = $cur; }
		$ys = array_values( array_unique( $ys ) );
		rsort( $ys );
		return $ys;
	}

	protected static function scalar( $sql, $p = array() ) {
		try { return (int) FKC_DB::q( $sql, $p )->fetchColumn(); } catch ( Exception $e ) { return 0; }
	}

	/** Compteurs de pièces sur une plage de dates (pour prévisualiser une purge). */
	public static function apercu( $debut, $fin ) {
		return array(
			'ecritures' => self::scalar( 'SELECT COUNT(*) FROM ecritures WHERE date_ecriture BETWEEN ? AND ?', array( $debut, $fin ) ),
			'factures'  => self::scalar( 'SELECT COUNT(*) FROM factures WHERE date_facture BETWEEN ? AND ?', array( $debut, $fin ) ),
			'achats'    => self::scalar( 'SELECT COUNT(*) FROM factures_fournisseurs WHERE date_facture BETWEEN ? AND ?', array( $debut, $fin ) ),
			'reglements'=> self::scalar( 'SELECT COUNT(*) FROM reglements WHERE date_reglement BETWEEN ? AND ?', array( $debut, $fin ) ),
		);
	}

	/**
	 * Bornes de l'exercice à réinitialiser.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * L'APERÇU ET LA SUPPRESSION DOIVENT DIRE LA MÊME CHOSE (1.548.0)
	 *
	 * `apercuExercice()` annonce ce qui va disparaître, `resetExercice()` le
	 * supprime. Les deux découpaient l'année civile alors qu'ils s'appellent
	 * « exercice » : sur un dossier clôturant au 30/06, l'écran annonçait la
	 * remise à zéro de l'exercice 2026 et effaçait en réalité janvier→décembre
	 * 2026, c'est-à-dire la seconde moitié de 2026 ET la première de 2027 —
	 * tout en laissant intact le premier semestre de l'exercice visé.
	 *
	 * C'est une opération IRRÉVERSIBLE : l'aperçu et l'exécution partagent
	 * donc désormais ce calcul, une seule fois, pour qu'ils ne puissent plus
	 * diverger. Si l'un change, l'autre change avec lui.
	 * ─────────────────────────────────────────────────────────────────────
	 */
	protected static function bornesExercice( $annee ) {
		$y = (string) $annee;
		if ( class_exists( 'FKC_Periode' ) ) {
			$b = FKC_Periode::bornes( $y );
			if ( $b ) { return $b; }
		}
		return array( $y . '-01-01', $y . '-12-31' );
	}

	/** Compteurs pour un exercice complet. */
	public static function apercuExercice( $annee ) {
		$y = (string) $annee;
		$b = self::bornesExercice( $y );
		$bb = array( $b[0], $b[1] );
		return array(
			'ecritures'  => self::scalar( "SELECT COUNT(*) FROM ecritures WHERE date_ecriture BETWEEN ? AND ?", $bb ),
			'factures'   => self::scalar( "SELECT COUNT(*) FROM factures WHERE date_facture BETWEEN ? AND ?", $bb ),
			'achats'     => self::scalar( "SELECT COUNT(*) FROM factures_fournisseurs WHERE date_facture BETWEEN ? AND ?", $bb ),
			'reglements' => self::scalar( "SELECT COUNT(*) FROM reglements WHERE date_reglement BETWEEN ? AND ?", $bb ),
			'clotures'   => self::scalar( "SELECT COUNT(*) FROM clotures WHERE (periode_fin BETWEEN ? AND ?) OR (periode_debut BETWEEN ? AND ?)", array( $b[0], $b[1], $b[0], $b[1] ) ),
			// La paie se déclare par année civile (colonne `annee`) : inchangé.
			'bulletins'  => self::scalar( "SELECT COUNT(*) FROM paie_bulletins WHERE annee=?", array( (int) $y ) ),
			'periode'    => $b,
		);
	}

	/**
	 * Remet à plat les pièces dont la référence d'écriture est devenue orpheline.
	 *
	 * Ne parcourait que six tables codées en dur — dont `factures`, qui n'a pas
	 * de colonne `ecriture_id`. Les reçus, mouvements de stock, déclarations
	 * fiscales, réceptions, situations de travaux et sessions de caisse
	 * conservaient donc, après purge, une référence pointant vers une écriture
	 * disparue, tout en se déclarant « comptabilisés ».
	 *
	 * FKC_EcritureLiens couvre les seize tables, remet le statut à sa valeur
	 * d'avant comptabilisation et journalise l'opération.
	 */
	protected static function repairEcritureRefs() {
		/*
		 * Les affectations analytiques survivaient à toutes les purges (1.547.0) :
		 * `ligne_affectations` n'a pas de clé étrangère, donc la cascade qui
		 * emporte les lignes d'écriture ne la touche pas. Purge de période,
		 * purge de factures, remise à zéro d'un exercice — chacune laissait
		 * des affectations pointant dans le vide. On les retire ici, au point
		 * de passage commun de toutes ces opérations.
		 */
		if ( class_exists( 'FKC_Affectation' ) ) { FKC_Affectation::purgerOrphelins(); }
		if ( class_exists( 'FKC_EcritureLiens' ) ) {
			FKC_EcritureLiens::reparer();
			return;
		}
		// Repli défensif si le registre n'est pas chargé (contexte partiel).
		foreach ( array( 'factures_fournisseurs', 'reglements', 'immo_dotations', 'clotures', 'paie_bulletins' ) as $t ) {
			try {
				FKC_DB::q( "UPDATE {$t} SET ecriture_id=NULL WHERE ecriture_id IS NOT NULL AND ecriture_id NOT IN (SELECT id FROM ecritures)" );
			} catch ( Exception $e ) {}
		}
	}

	/**
	 * Contrôle de cohérence comptable, exposé à l'utilisateur.
	 *
	 * @param bool $simulation true = compter sans rien modifier.
	 * @return array{orphelines:int,contrepassees:int,lettrages:int,detail:array}
	 */
	public static function coherenceEcritures( $simulation = true ) {
		if ( ! class_exists( 'FKC_EcritureLiens' ) ) {
			return array( 'orphelines' => 0, 'contrepassees' => 0, 'lettrages' => 0, 'detail' => array() );
		}
		return FKC_EcritureLiens::reparer( (bool) $simulation );
	}

	/** Supprime les écritures (et leurs lignes, via cascade) d'une plage de dates. */
	public static function purgeEcritures( $debut, $fin ) {
		$n = self::scalar( 'SELECT COUNT(*) FROM ecritures WHERE date_ecriture BETWEEN ? AND ?', array( $debut, $fin ) );
		FKC_DB::q( 'DELETE FROM ecritures WHERE date_ecriture BETWEEN ? AND ?', array( $debut, $fin ) );
		self::repairEcritureRefs();
		return $n;
	}

	/**
	 * Supprime les factures clients d'une plage de dates (lignes en cascade).
	 * @param bool $aussiEcritures supprime aussi les écritures comptables liées
	 */
	public static function purgeFactures( $debut, $fin, $aussiEcritures = false ) {
		$n = self::scalar( 'SELECT COUNT(*) FROM factures WHERE date_facture BETWEEN ? AND ?', array( $debut, $fin ) );
		if ( $aussiEcritures ) {
			$ids = array();
			foreach ( FKC_DB::q( 'SELECT ecriture_id FROM factures WHERE date_facture BETWEEN ? AND ? AND ecriture_id IS NOT NULL', array( $debut, $fin ) )->fetchAll() as $r ) {
				$ids[] = (int) $r['ecriture_id'];
			}
			if ( $ids ) {
				$in = implode( ',', array_fill( 0, count( $ids ), '?' ) );
				FKC_DB::q( "DELETE FROM ecritures WHERE id IN ($in)", $ids );
			}
		}
		FKC_DB::q( 'DELETE FROM factures WHERE date_facture BETWEEN ? AND ?', array( $debut, $fin ) );
		self::repairEcritureRefs();
		return $n;
	}

	/** Supprime les factures fournisseurs d'une plage (et écritures liées si demandé). */
	public static function purgeAchats( $debut, $fin, $aussiEcritures = false ) {
		$n = self::scalar( 'SELECT COUNT(*) FROM factures_fournisseurs WHERE date_facture BETWEEN ? AND ?', array( $debut, $fin ) );
		if ( $aussiEcritures ) {
			$ids = array();
			foreach ( FKC_DB::q( 'SELECT ecriture_id FROM factures_fournisseurs WHERE date_facture BETWEEN ? AND ? AND ecriture_id IS NOT NULL', array( $debut, $fin ) )->fetchAll() as $r ) {
				$ids[] = (int) $r['ecriture_id'];
			}
			if ( $ids ) {
				$in = implode( ',', array_fill( 0, count( $ids ), '?' ) );
				FKC_DB::q( "DELETE FROM ecritures WHERE id IN ($in)", $ids );
			}
		}
		FKC_DB::q( 'DELETE FROM factures_fournisseurs WHERE date_facture BETWEEN ? AND ?', array( $debut, $fin ) );
		self::repairEcritureRefs();
		return $n;
	}

	/**
	 * Réinitialise un exercice complet : supprime toutes les pièces de l'année
	 * (écritures, factures, achats, règlements, clôtures, bulletins, dotations).
	 * Conserve plan comptable, journaux, divisions, comptes de trésorerie,
	 * clients, fournisseurs, employés et paramètres.
	 */
	public static function resetExercice( $annee ) {
		$y  = (string) $annee;
		$yi = (int) $annee;
		$compte = self::apercuExercice( $y );
		// MÊME découpage que l'aperçu : c'est ce que l'utilisateur a validé.
		$b  = self::bornesExercice( $y );
		$bb = array( $b[0], $b[1] );
		$del = array(
			array( "DELETE FROM ecritures WHERE date_ecriture BETWEEN ? AND ?", $bb ),
			array( "DELETE FROM factures WHERE date_facture BETWEEN ? AND ?", $bb ),
			array( "DELETE FROM factures_fournisseurs WHERE date_facture BETWEEN ? AND ?", $bb ),
			array( "DELETE FROM reglements WHERE date_reglement BETWEEN ? AND ?", $bb ),
			array( "DELETE FROM clotures WHERE (periode_fin BETWEEN ? AND ?) OR (periode_debut BETWEEN ? AND ?)", array( $b[0], $b[1], $b[0], $b[1] ) ),
			array( "DELETE FROM paie_bulletins WHERE annee=?", array( $yi ) ),
			array( "DELETE FROM immo_dotations WHERE exercice=?", array( $yi ) ),
			/*
			 * REGISTRE DES REVENUS (1.666.0).
			 *
			 * Les revenus et leurs règlements suivaient les écritures dans le
			 * grand livre mais restaient dans leur registre : après une purge
			 * d'exercice, le tableau de bord du pack Artiste continuait
			 * d'afficher des revenus dont plus aucune écriture n'existait, et
			 * son « à recevoir » réclamait des créances effacées.
			 *
			 * L'ordre compte : les règlements d'abord, les revenus ensuite —
			 * une suppression en sens inverse laisserait des règlements
			 * orphelins le temps de la transaction.
			 *
			 * Les lignes de détail et les lignes d'import partent par cascade
			 * (ON DELETE CASCADE), et les empreintes d'import avec leur run :
			 * le fichier d'un exercice purgé redevient importable, ce qui est
			 * le comportement attendu.
			 */
			array( "DELETE FROM rev_reglements WHERE date BETWEEN ? AND ?", $bb ),
			array( "DELETE FROM rev_revenus WHERE date_fait BETWEEN ? AND ?", $bb ),
			array( "DELETE FROM imp_empreintes WHERE run_id IN (SELECT id FROM imp_runs WHERE date(created_at) BETWEEN ? AND ?)", $bb ),
			array( "DELETE FROM imp_runs WHERE date(created_at) BETWEEN ? AND ?", $bb ),
		);
		foreach ( $del as $d ) { try { FKC_DB::q( $d[0], $d[1] ); } catch ( Exception $e ) {} }
		self::repairEcritureRefs();
		return $compte;
	}

	/** Purge TOTALE des transactions de la société (toutes années). Conserve le paramétrage. */
	public static function purgeTout() {
		/*
		 * Les tables du registre des revenus sont citées AVANT celles dont
		 * elles dépendent par clé étrangère : rev_reglements référence
		 * rev_revenus, et imp_empreintes référence imp_runs. Vider dans
		 * l'autre sens laisserait des orphelins que la réparation des
		 * références ne sait pas rattraper.
		 */
		foreach ( array( 'ecritures', 'factures', 'factures_fournisseurs', 'reglements', 'clotures',
			'paie_bulletins', 'immo_dotations',
			'rev_reglements', 'rev_lignes', 'rev_revenus',
			'imp_empreintes', 'imp_lignes', 'imp_runs' ) as $t ) {
			try { FKC_DB::q( "DELETE FROM {$t}" ); } catch ( Exception $e ) {}
		}
		self::repairEcritureRefs();
	}
}
