<?php
/** Comptes de trésorerie (paramètres) : ajout / activation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_TresorerieCompte {

	public static function types() {
		return array(
			'banque'       => 'Banque',
			'caisse'       => 'Caisse',
			'mobile_money' => 'Mobile Money',
			'autre'        => 'Autre',
		);
	}

	/** Liste avec solde courant calculé depuis les écritures. */
	public static function all() {
		return FKC_DB::q(
			"SELECT tc.*, c.numero, c.libelle AS compte_libelle,
			   COALESCE((SELECT SUM(el.debit - el.credit) FROM ecriture_lignes el WHERE el.compte_id = tc.compte_id),0) AS solde
			 FROM tresorerie_comptes tc JOIN comptes c ON c.id = tc.compte_id
			 ORDER BY tc.actif DESC, tc.ordre, tc.libelle COLLATE NOCASE"
		)->fetchAll();
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM tresorerie_comptes WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/**
	 * Ajoute un compte de trésorerie. Crée le compte comptable (classe 5) s'il n'existe pas.
	 * @return array{bool, string} ( bool ok, string message )
	 */
	public static function add( $d ) {
		$libelle  = trim( (string) ( $d['libelle'] ?? '' ) );
		$numero   = preg_replace( '/\D/', '', (string) ( $d['numero'] ?? '' ) );
		$type     = trim( (string) ( $d['type'] ?? 'banque' ) ) ?: 'banque';
		$operateur= trim( (string) ( $d['operateur'] ?? '' ) ) ?: null;

		if ( '' === $libelle ) { return array( false, 'Le libellé est requis.' ); }
		if ( '' === $numero || '5' !== substr( $numero, 0, 1 ) ) {
			return array( false, 'Le numéro de compte doit appartenir à la classe 5 (trésorerie), ex. 521xxx, 571xxx, 55xxxx.' );
		}

		$compte = FKC_Compte::byNumero( $numero );
		if ( ! $compte ) {
			FKC_Compte::create( $numero, $d['compte_libelle'] ?? $libelle, 'detail' );
			$compte = FKC_Compte::byNumero( $numero );
		}
		if ( ! $compte ) { return array( false, 'Impossible de créer le compte comptable ' . $numero . '.' ); }

		// Évite le doublon de compte de trésorerie sur le même compte.
		if ( FKC_DB::q( 'SELECT 1 FROM tresorerie_comptes WHERE compte_id=?', array( (int) $compte['id'] ) )->fetch() ) {
			return array( false, 'Un compte de trésorerie utilise déjà le compte ' . $numero . '.' );
		}

		$ordre = (int) FKC_DB::q( 'SELECT COALESCE(MAX(ordre),0)+1 FROM tresorerie_comptes' )->fetchColumn();
		FKC_DB::q(
			'INSERT INTO tresorerie_comptes(libelle,type,operateur,compte_id,actif,ordre) VALUES(?,?,?,?,1,?)',
			array( $libelle, $type, $operateur, (int) $compte['id'], $ordre )
		);
		return array( true, 'Compte de trésorerie « ' . $libelle . ' » ajouté.' );
	}

	public static function update( $id, $d ) {
		FKC_DB::q(
			'UPDATE tresorerie_comptes SET libelle=?, type=?, operateur=?, actif=?, ordre=? WHERE id=?',
			array(
				trim( (string) $d['libelle'] ),
				trim( (string) ( $d['type'] ?? 'banque' ) ) ?: 'banque',
				trim( (string) ( $d['operateur'] ?? '' ) ) ?: null,
				empty( $d['actif'] ) ? 0 : 1,
				(int) ( $d['ordre'] ?? 0 ),
				(int) $id,
			)
		);
	}

	public static function toggle( $id ) {
		FKC_DB::q( 'UPDATE tresorerie_comptes SET actif = CASE actif WHEN 1 THEN 0 ELSE 1 END WHERE id=?', array( (int) $id ) );
	}
}
