<?php /** @var string $base @var string $version @var int $nb_cles @var int $nb_actives @var int $nb_appels @var bool $is_admin */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'parametres', 'back' => 'parametres', 'backLabel' => 'Paramètres' ) ); // cet écran n'avait aucune sortie hors bouton du navigateur
 ?>
<div class="launch-hero" style="margin-top:2px">
	<div class="launch-ico">🔌</div>
	<div style="flex:1"><h1 class="launch-title">API REST</h1>
		<p class="launch-sub">Connectez vos applications mobiles, intégrations bancaires et partenaires aux données de l'ERP. Lecture sécurisée par clé, isolée par entité.</p></div>
	<span class="modbadge b-on" style="align-self:center">Active · <?= e( $version ) ?></span>
</div>

<div class="stats">
	<div class="stat stat-accent"><span class="stat-label">Point d'entrée</span><span class="stat-value" style="font-size:14px;font-family:var(--mono);word-break:break-all"><?= e( $base ) ?>/api/<?= e( $version ) ?></span></div>
	<div class="stat"><span class="stat-label">Clés actives</span><span class="stat-value"><?= $nb_actives ?><small> / <?= $nb_cles ?></small></span></div>
	<div class="stat"><span class="stat-label">Appels cumulés</span><span class="stat-value"><?= e( fkc_money( $nb_appels ) ) ?></span></div>
</div>

<div class="card card-flush"><div class="card-head"><h2>Accès & outils</h2></div>
	<div class="fkc-cta-grid">
		<a class="fkc-cta" href="<?= e( url( 'api/docs' ) ) ?>" target="_blank" rel="noopener">
			<span class="fkc-cta-label">📘 Documentation développeurs</span>
			<span class="fkc-cta-desc">Endpoints, exemples, authentification, spécification OpenAPI (/api/docs).</span>
			<span class="fkc-cta-go" aria-hidden="true">↗</span>
		</a>
		<?php if ( $is_admin ) : ?>
		<a class="fkc-cta" href="<?= e( url( 'securite/cles-api' ) ) ?>">
			<span class="fkc-cta-label">🔑 Gérer les clés API</span>
			<span class="fkc-cta-desc">Générer, attribuer des scopes, lier à une entité, révoquer.</span>
			<span class="fkc-cta-go" aria-hidden="true">→</span>
		</a>
		<?php else : ?>
		<div class="fkc-cta" style="opacity:.6;cursor:default;background:var(--panel2);border-color:var(--line)">
			<span class="fkc-cta-label">🔑 Clés API</span>
			<span class="fkc-cta-desc">La gestion des clés est réservée à l'administrateur du cabinet.</span>
		</div>
		<?php endif; ?>
		<a class="fkc-cta" href="<?= e( url( 'api/' . $version . '/ping' ) ) ?>" target="_blank" rel="noopener">
			<span class="fkc-cta-label">📡 Tester la disponibilité</span>
			<span class="fkc-cta-desc">Appelle /api/<?= e( $version ) ?>/ping et renvoie l'état de l'API (public).</span>
			<span class="fkc-cta-go" aria-hidden="true">↗</span>
		</a>
		<a class="fkc-cta" href="<?= e( url( 'aide/article/cles-api' ) ) ?>">
			<span class="fkc-cta-label">❓ Guide : créer une clé</span>
			<span class="fkc-cta-desc">Pas à pas dans le centre d'aide.</span>
			<span class="fkc-cta-go" aria-hidden="true">→</span>
		</a>
	</div>
</div>
