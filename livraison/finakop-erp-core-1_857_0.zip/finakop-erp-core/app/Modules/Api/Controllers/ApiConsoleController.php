<?php
/** Console API : écran d'accueil du module API (statut, accès documentation et clés). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_ApiConsoleController {
	public function index() {
		$s = FKC_Master::q( "SELECT COUNT(*) n, COALESCE(SUM(CASE WHEN statut='active' THEN 1 ELSE 0 END),0) a, COALESCE(SUM(appels),0) c FROM cab_api_keys" )->fetch();
		FKC_View::render( 'api::index', array(
			'title'   => 'API',
			'base'    => ( defined( 'FKC_BASE_URL' ) ? rtrim( FKC_BASE_URL, '/' ) : '' ),
			'version' => FKC_Api::VERSION,
			'nb_cles' => (int) ( $s['n'] ?? 0 ),
			'nb_actives' => (int) ( $s['a'] ?? 0 ),
			'nb_appels'  => (int) ( $s['c'] ?? 0 ),
			'is_admin'   => FKC_Auth::isAdmin(),
		) );
	}
}
