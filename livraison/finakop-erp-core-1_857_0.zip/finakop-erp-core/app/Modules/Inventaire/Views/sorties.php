<?php /** @var array $articles @var array $entrepots @var array $motifs @var array $divisions @var bool $anaOn @var array $recents @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'sorties' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouvelle sortie de stock</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/sorties' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:200px"><span>Article</span><select name="article_id" required><option value="">—</option><?php foreach ( $articles as $a ) : if ( empty( $a['gere_stock'] ) ) continue; ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['code'] . ' · ' . $a['designation'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Entrepôt</span><select name="entrepot_id" required><?php foreach ( $entrepots as $e ) : ?><option value="<?= (int) $e['id'] ?>"><?= e( $e['libelle'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Quantité</span><input type="number" step="0.01" name="quantite" required style="width:100px"></label>
		<label class="fld" style="margin:0"><span>Motif</span><select name="motif"><?php foreach ( $motifs as $k => $lbl ) : ?><option value="<?= e( $k ) ?>"><?= e( $lbl ) ?></option><?php endforeach; ?></select></label>
		<?php if ( $anaOn ) : ?><label class="fld" style="margin:0"><span>Division (analytique)</span><select name="division_id"><option value="">—</option><?php foreach ( $divisions as $dv ) : ?><option value="<?= (int) $dv['id'] ?>"><?= e( $dv['code'] ) ?></option><?php endforeach; ?></select></label><?php endif; ?>
		<button class="btn btn-primary" type="submit">Sortir</button>
	</form>
	<p class="help" style="margin:8px 0 0">Sortie valorisée au CMP courant ; écriture automatique (D 603 variation / C 31 stock).</p>
</div></div>
<div class="card card-flush"><div class="card-head"><h2>Dernières sorties</h2></div>
	<table class="table"><thead><tr><th>Date</th><th>Article</th><th>Entrepôt</th><th>Motif</th><th class="num">Qté</th><th class="num">Valeur</th></tr></thead><tbody>
	<?php if ( ! $recents ) : ?><tr><td colspan="6" class="empty">Aucune sortie.</td></tr>
	<?php else : foreach ( $recents as $m ) : ?><tr><td class="code"><?= e( $m['date_mouv'] ) ?></td><td><?= e( $m['article_code'] ) ?></td>
		<td><?= e( $m['entrepot'] ) ?></td><td><?= e( $motifs[ $m['motif'] ] ?? $m['motif'] ) ?></td>
		<td class="num"><?= e( fkc_money( $m['quantite'], 2 ) ) ?></td><td class="num"><?= e( fkc_money( $m['valeur'] ) ) ?></td></tr>
	<?php endforeach; endif; ?></tbody></table>
</div>
