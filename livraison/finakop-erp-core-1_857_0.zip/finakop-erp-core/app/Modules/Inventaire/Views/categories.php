<?php /** @var array $cats @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'categories' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouvelle catégorie</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/categories' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0"><span>Code</span><input name="code" placeholder="auto" title="Laissez vide : le code est attribué automatiquement." style="width:120px;text-transform:uppercase"></label>
		<label class="fld" style="margin:0;min-width:220px"><span>Libellé</span><input name="libelle" required></label>
		<button class="btn btn-primary" type="submit">Ajouter</button>
	</form>
</div></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th>Libellé</th><th></th></tr></thead><tbody>
	<?php if ( ! $cats ) : ?><tr><td colspan="3" class="empty">Aucune catégorie.</td></tr>
	<?php else : foreach ( $cats as $c ) : ?><tr><td class="code"><?= e( $c['code'] ) ?></td><td><?= e( $c['libelle'] ) ?></td>
		<td class="right"><form method="post" action="<?= e( url( 'inventaire/categories/' . (int) $c['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Supprimer</button></form></td></tr>
	<?php endforeach; endif; ?></tbody>
</table></div>
