<?php /** @var array $receptions @var array $entrepots @var array $articles @var array $commandes @var array|null $achat @var array $divisions @var bool $anaOn @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$prefill = $achat ? $achat['lignes'] : array(); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'receptions' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouveau bon de réception<?= $achat ? ' — ' . e( $achat['numero'] ) : '' ?></h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/receptions' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<?php if ( $achat ) : ?><input type="hidden" name="achat_id" value="<?= (int) $achat['id'] ?>"><?php endif; ?>
		<div class="form-grid" style="grid-template-columns:1fr 1fr <?= $anaOn?'1fr':'' ?>">
			<label class="fld"><span>Entrepôt</span><select name="entrepot_id" required><?php foreach ( $entrepots as $e ) : ?><option value="<?= (int) $e['id'] ?>"><?= e( $e['libelle'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Date</span><input type="date" name="date" value="<?= date( 'Y-m-d' ) ?>"></label>
			<?php if ( $anaOn ) : ?><label class="fld"><span>Division (analytique)</span><select name="division_id"><option value="">—</option><?php foreach ( $divisions as $dv ) : ?><option value="<?= (int) $dv['id'] ?>"><?= e( $dv['code'] ) ?></option><?php endforeach; ?></select></label><?php endif; ?>
		</div>
		<?php
		/*
		 * SCANNER PLUTÔT QUE CHERCHER DANS UNE LISTE DÉROULANTE.
		 *
		 * Le bon de réception se remplit article par article, dans un menu qui
		 * peut compter des milliers de lignes — pendant que le livreur attend.
		 * Le carton, lui, porte son code : le lire remplit la ligne suivante et
		 * reporte le prix d'achat connu.
		 *
		 * Le scan ne valide rien : il PRÉPARE la ligne. Le contrôle des
		 * quantités et l'enregistrement restent des gestes délibérés, parce
		 * qu'une réception engage une dette fournisseur.
		 */
		?>
		<?php FKC_View::partial( 'scan::_scanbox', array(
			'contexte' => 'reception',
			'route'    => 'inventaire/receptions',
			'cible'    => 'receptionScanne',
		) ); ?>
		<table class="table" id="tblReception"><thead><tr><th>Article</th><th class="num">Commandé</th><th class="num">Reçu</th><th class="num">PU</th><th style="width:110px">Lot</th><th style="width:135px">Péremption</th><th>Écart</th></tr></thead><tbody>
		<?php
		$rows = $prefill ?: array_fill( 0, 5, null );
		foreach ( $rows as $i => $pl ) : ?>
			<tr>
				<td><select name="l_article[<?= $i ?>]"><option value="">—</option><?php foreach ( $articles as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= ( $pl && (int)$pl['article_id']===(int)$a['id'] )?'selected':'' ?>><?= e( $a['code'] . ' · ' . $a['designation'] ) ?></option><?php endforeach; ?></select></td>
				<td class="num"><input type="number" step="0.01" name="l_cmd[<?= $i ?>]" value="<?= $pl ? e( $pl['quantite'] ) : '' ?>" style="width:90px"></td>
				<td class="num"><input type="number" step="0.01" name="l_recu[<?= $i ?>]" value="<?= $pl ? e( $pl['quantite'] ) : '' ?>" style="width:90px"></td>
				<td class="num"><input type="number" step="0.01" name="l_pu[<?= $i ?>]" value="<?= $pl ? e( $pl['pu'] ) : '' ?>" style="width:100px"></td>
				<td><input type="text" name="l_lot[<?= $i ?>]" style="width:100px" placeholder="auto au scan"></td>
				<td><input type="date" name="l_peremption[<?= $i ?>]" style="width:130px"></td>
				<td class="muted" style="font-size:.85em">commandé − reçu</td>
			</tr>
		<?php endforeach; ?></tbody></table>
<script>
/*
 * Le scan remplit la PREMIÈRE ligne libre. Ajouter systématiquement une ligne
 * en bas obligerait à faire défiler à chaque carton ; réutiliser une ligne
 * déjà remplie écraserait une saisie.
 */
function receptionScanne(res) {
	var a = res.action || {}, corps = document.querySelector('#tblReception tbody');
	if (!corps || !a.entite_id) { return; }
	var lignes = corps.querySelectorAll('tr'), cible = null;
	for (var i = 0; i < lignes.length; i++) {
		var sel = lignes[i].querySelector('select[name^="l_article"]');
		if (sel && !sel.value) { cible = lignes[i]; break; }
		// Même article déjà saisi : on incrémente au lieu d'ouvrir un doublon.
		if (sel && String(sel.value) === String(a.entite_id)) {
			var q = lignes[i].querySelector('input[name^="l_recu"]');
			if (q) { q.value = (parseFloat(q.value || 0) + parseFloat(a.quantite || 1)).toFixed(2); }
			return;
		}
	}
	if (!cible) { window.alert('Toutes les lignes du bon sont remplies — enregistrez avant de continuer.'); return; }
	var sel = cible.querySelector('select[name^="l_article"]');
	sel.value = a.entite_id;
	var recu = cible.querySelector('input[name^="l_recu"]');
	if (recu) { recu.value = a.quantite || 1; }
	var pu = cible.querySelector('input[name^="l_pu"]');
	if (pu && !pu.value && a.pu) { pu.value = a.pu; }
	/*
	 * LE CARTON PORTE SON LOT ET SA DLC : on ne les redemande pas.
	 *
	 * Un code GS1 contient le numéro de lot (AI 10) et la date de péremption
	 * (AI 17). Le magasinier les recopiait à la main depuis l'étiquette qu'il
	 * venait de scanner — avec les fautes que cela suppose, et l'abandon pur
	 * et simple les jours de forte livraison.
	 */
	var att = res.attributs || {};
	var lot = cible.querySelector('input[name^="l_lot"]');
	if (lot && att.lot) { lot.value = att.lot; }
	var per = cible.querySelector('input[name^="l_peremption"]');
	if (per && att.expiration) { per.value = att.expiration; }
	// Une DLC dépassée se signale tout de suite : après validation, la
	// marchandise est en stock et l'erreur coûte une sortie de stock.
	if (res.peremption && res.peremption.perime) {
		cible.style.background = 'var(--danger-bg, #fde8e8)';
		cible.title = 'Lot périmé depuis ' + Math.abs(res.peremption.jours) + ' jour(s)';
	}
}
</script>
		<div class="actions"><button class="btn btn-primary" type="submit">Enregistrer la réception</button></div>
	</form>
	<p class="help" style="margin:0">Chaque ligne reçue génère une entrée en stock (mise à jour du CMP) et l'écriture comptable D 31 / C 603.</p>
</div></div>
<div class="card card-flush"><div class="card-head"><h2>Réceptions</h2></div>
	<table class="table"><thead><tr><th>N°</th><th>Date</th><th>Entrepôt</th><th>Commande</th></tr></thead><tbody>
	<?php if ( ! $receptions ) : ?><tr><td colspan="4" class="empty">Aucune réception.</td></tr>
	<?php else : foreach ( $receptions as $r ) : ?><tr><td class="code"><?= e( $r['numero'] ) ?></td><td class="code"><?= e( $r['date'] ) ?></td>
		<td><?= e( $r['entrepot'] ) ?></td><td><?= e( $r['achat_num'] ?: '—' ) ?></td></tr>
	<?php endforeach; endif; ?></tbody></table>
</div>
