<?php /** @var array $articles @var array $cats @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$types = FKC_InvArticle::types(); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'articles' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted"><?= count( $articles ) ?> article(s)</span>
	<a class="btn btn-primary btn-sm" href="<?= e( url( 'inventaire/articles/nouveau' ) ) ?>">+ Nouvel article</a>
	<?php if ( class_exists( 'FKC_ArticleBridge' ) && FKC_ArticleBridge::disponible() && ( $pont = FKC_ArticleBridge::etat() ) ) :
		/*
		 * Le libellé du bouton nommait TOUS les packs pontés. Sur une société
		 * multi-packs il dépassait la moitié de la barre d'outils et poussait
		 * les autres commandes hors écran. On nomme le pack quand il est seul —
		 * c'est le cas courant et l'information est alors utile — et on compte
		 * au-delà. Le détail chiffré reste accessible en infobulle.
		 */
		$noms = array(); $tip = array();
		foreach ( $pont['packs'] as $pk ) { $noms[] = $pk['label']; $tip[] = $pk['label'] . ' : ' . $pk['total'] . ' article(s), ' . $pk['lies'] . ' lié(s)'; }
		$nb      = count( $noms );
		$libelle = 1 === $nb ? 'Synchroniser avec ' . $noms[0] : 'Synchroniser les catalogues (' . $nb . ')';
		$cible   = 1 === $nb ? $noms[0] : $nb . ' catalogues métier';
	?>
		<form method="post" action="<?= e( url( 'inventaire/articles/resync' ) ) ?>" style="display:inline"
			onsubmit="return confirm('Réconcilier le catalogue Inventaire avec <?= e( $cible ) ?> ?\n\nLes articles manquants seront créés de chaque côté et les doublons appariés.\nAucune valeur existante ne sera écrasée, et les stocks ne seront pas modifiés.')">
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-ghost btn-sm" title="Inventaire : <?= (int) $pont['inventaire'] ?> article(s)&#10;<?= e( implode( "\n", $tip ) ) ?>">🔗 <?= e( $libelle ) ?></button>
		</form>
		<?php if ( FKC_Auth::isAdmin() ) : $masque = FKC_ArticleBridge::inventaireMasque(); ?>
		<form method="post" action="<?= e( url( 'inventaire/articles/masquage' ) ) ?>" style="display:inline"
			<?php if ( ! $masque ) : ?>onsubmit="return confirm('Masquer le module Inventaire du menu ?\n\nLe catalogue se pilotera alors depuis le pack métier uniquement.\nAttention : vous perdrez l\'accès direct à la valorisation SYSCOHADA, au multi-entrepôts et au journal des mouvements, que les packs ne proposent pas.\n\nAucune donnée n\'est supprimée ; cette page reste accessible par son adresse pour réafficher le module.')"<?php endif; ?>>
			<?= FKC_Csrf::field() ?>
			<button class="btn btn-ghost btn-sm"><?= $masque ? '👁 Réafficher ce module' : '🙈 Masquer ce module' ?></button>
		</form>
		<?php endif; ?>
	<?php endif; ?></div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : code, désignation, catégorie…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th>Désignation</th><th>Type</th><th>Catégorie</th><th class="num">Stock</th><th class="num">CMP</th><th class="num">Prix vente</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $articles ) : ?><tr><td colspan="8" class="empty">Aucun article. Créez votre premier article.</td></tr>
	<?php else : foreach ( $articles as $a ) : $dispo = (float) $a['stock_total'] - (float) $a['reserve_total']; $rupt = ! empty( $a['gere_stock'] ) && $a['stock_min'] > 0 && $dispo < $a['stock_min']; ?>
		<tr>
			<td class="code"><a href="<?= e( url( 'inventaire/articles/' . (int) $a['id'] . '/modifier' ) ) ?>"><strong><?= e( $a['code'] ) ?></strong></a></td>
			<td><?= e( $a['designation'] ) ?><?= empty( $a['actif'] ) ? ' <span class="modbadge b-off">Inactif</span>' : '' ?></td>
			<td><?= e( $types[ $a['type'] ] ?? $a['type'] ) ?></td>
			<td><?= e( $a['categorie'] ?: '—' ) ?></td>
			<td class="num"><?= empty( $a['gere_stock'] ) ? '—' : ( '<span style="' . ( $rupt ? 'color:var(--danger);font-weight:700' : '' ) . '">' . e( fkc_money( $a['stock_total'], 2 ) ) . '</span>' ) ?></td>
			<td class="num"><?= e( fkc_money( $a['cmp'], 0 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $a['prix_vente'], 0 ) ) ?></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'inventaire/articles/' . (int) $a['id'] . '/modifier' ) ) ?>">Fiche</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
