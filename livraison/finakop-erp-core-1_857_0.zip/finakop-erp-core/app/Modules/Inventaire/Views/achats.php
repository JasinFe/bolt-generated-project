<?php /** @var array $achats @var array|null $sel @var array $etapes @var array $fournisseurs @var array $articles @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$badge = array( 'demande'=>'b-off','manager'=>'','finance'=>'','achat'=>'','commande'=>'b-on','recu'=>'b-on','annule'=>'b-off' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'achats' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouvelle demande d'achat</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/achats' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
			<label class="fld"><span>Fournisseur</span><select name="fournisseur_id"><option value="">—</option><?php foreach ( $fournisseurs as $f ) : ?><option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld"><span>Service demandeur</span><input name="service_demandeur"></label>
			<label class="fld"><span>Date</span><input type="date" name="date" value="<?= date( 'Y-m-d' ) ?>"></label>
		</div>
		<table class="table"><thead><tr><th>Article</th><th>Désignation libre</th><th class="num">Qté</th><th class="num">PU</th></tr></thead><tbody>
		<?php for ( $i = 0; $i < 5; $i++ ) : ?><tr>
			<td><select name="l_article[<?= $i ?>]"><option value="">—</option><?php foreach ( $articles as $a ) : ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['code'] . ' · ' . $a['designation'] ) ?></option><?php endforeach; ?></select></td>
			<td><input name="l_designation[<?= $i ?>]" placeholder="(ou saisie libre)"></td>
			<td class="num"><input type="number" step="0.01" name="l_qte[<?= $i ?>]" style="width:90px"></td>
			<td class="num"><input type="number" step="0.01" name="l_pu[<?= $i ?>]" style="width:100px"></td>
		</tr><?php endfor; ?></tbody></table>
		<div class="actions"><button class="btn btn-primary" type="submit">Créer la demande</button></div>
	</form>
</div></div>

<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Demandes & commandes</h2></div>
		<table class="table"><thead><tr><th>N°</th><th>Fournisseur</th><th class="num">Total HT</th><th>Statut</th></tr></thead><tbody>
		<?php if ( ! $achats ) : ?><tr><td colspan="4" class="empty">Aucune demande.</td></tr>
		<?php else : foreach ( $achats as $a ) : ?><tr>
			<td class="code"><a href="<?= e( url( 'inventaire/achats?a=' . (int) $a['id'] ) ) ?>"><?= e( $a['numero'] ) ?></a></td>
			<td><?= e( $a['fournisseur'] ?: '—' ) ?></td><td class="num"><?= e( fkc_money( $a['total_ht'] ) ) ?></td>
			<td><span class="modbadge <?= $badge[ $a['statut'] ] ?? '' ?>"><?= e( $etapes[ $a['statut'] ] ?? $a['statut'] ) ?></span></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
	<?php if ( $sel ) : ?>
	<div class="card card-flush"><div class="card-head"><h2><?= e( $sel['numero'] ) ?> <span class="modbadge <?= $badge[ $sel['statut'] ] ?? '' ?>"><?= e( $etapes[ $sel['statut'] ] ?? $sel['statut'] ) ?></span></h2>
		<form method="post" action="<?= e( url( 'inventaire/achats/' . (int) $sel['id'] . '/action' ) ) ?>" style="display:flex;gap:4px">
			<?= FKC_Csrf::field() ?>
			<?php if ( FKC_InvAchat::suivant( $sel['statut'] ) ) : ?><button class="btn btn-sm" name="action" value="avancer">Valider l'étape</button><?php endif; ?>
			<?php if ( 'commande' === $sel['statut'] ) : ?><a class="btn btn-sm" href="<?= e( url( 'inventaire/receptions?a=' . (int) $sel['id'] ) ) ?>">Réceptionner</a><?php endif; ?>
			<?php if ( ! in_array( $sel['statut'], array( 'recu','annule' ), true ) ) : ?><button class="btn btn-ghost btn-sm" name="action" value="annuler">Annuler</button><?php endif; ?>
			<button class="btn btn-ghost btn-sm" name="action" value="supprimer" onclick="return confirm('Supprimer ?')">✕</button>
		</form>
	</div>
	<table class="table"><thead><tr><th>Article / désignation</th><th class="num">Qté</th><th class="num">PU</th><th class="num">Total</th></tr></thead><tbody>
		<?php foreach ( $sel['lignes'] as $l ) : ?><tr>
			<td><?= e( $l['art_designation'] ?: $l['designation'] ) ?></td><td class="num"><?= e( fkc_money( $l['quantite'], 2 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $l['pu'] ) ) ?></td><td class="num"><?= e( fkc_money( $l['quantite'] * $l['pu'] ) ) ?></td></tr>
		<?php endforeach; ?>
		<tr class="total"><td colspan="3">Total HT</td><td class="num"><?= e( fkc_money( $sel['total_ht'] ) ) ?></td></tr>
	</tbody></table>
	<?php endif; ?>
</div>
