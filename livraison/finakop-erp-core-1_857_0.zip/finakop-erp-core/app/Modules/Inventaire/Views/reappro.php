<?php /** @var array $alertes @var array $ruptures @var array $surstock @var array $peremption @var bool $lotsOn @var mixed $flash @var int|null $demandesOuvertes */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php
/*
 * L'action part d'ICI, où le manque est constaté. Demander un
 * réapprovisionnement depuis un autre module obligerait à recopier la liste
 * qu'on a sous les yeux.
 */
?>
<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
	<form method="post" action="<?= e( url( 'inventaire/reappro/demander' ) ) ?>"
		onsubmit="return confirm('Créer les demandes d\'achat pour tous les articles sous leur seuil ?')">
		<?= FKC_Csrf::field() ?>
		<button class="btn btn-primary btn-sm" type="submit">🛒 Créer les demandes d'achat</button>
	</form>
	<?php if ( $demandesOuvertes ) : ?>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats/demandes' ) ) ?>">
			<?= (int) $demandesOuvertes ?> demande(s) en attente de validation
		</a>
	<?php endif; ?>
</div>

<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'reappro' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<?php
/*
 * LE GESTE DU RAYON VIDE.
 *
 * La liste ci-dessous ne montre que ce que les SEUILS déclenchent. Or le
 * manque le plus certain est celui qu'on a sous les yeux : un rayon vide, une
 * étiquette qui reste. Sans cette boîte, le magasinier notait le code sur un
 * carnet et le ressaisissait au bureau — avec les fautes de recopie que cela
 * suppose, et l'oubli pur et simple quand le carnet se perd.
 *
 * Le scan n'engage aucune dépense : il ouvre une demande « à valider », que le
 * service achats arbitre. C'est ce qui permet de laisser le geste à n'importe
 * quel magasinier.
 */
?>
<div class="card card-flush">
	<div class="card-head"><h2>Demander au scan</h2><span class="muted">Un rayon vide, un code lu, une demande</span></div>
	<div style="padding:12px">
		<?php FKC_View::partial( 'scan::_scanbox', array(
			'contexte' => 'demande',
			'route'    => 'inventaire/reappro',
			'cible'    => 'reapproScanne',
		) ); ?>
		<div id="reapproFlux" style="font-size:.9em"></div>
		<p class="muted" style="font-size:.85em;margin:8px 0 0">
			La quantité proposée vise le stock maximum de l'article quand il est renseigné : scanner dit
			qu'il manque quelque chose, pas combien. Un second scan du même article ne crée pas de doublon.
		</p>
	</div>
</div>
<script>
function reapproScanne(res) {
	var a = res.action || {}, zone = document.getElementById('reapproFlux');
	var d = document.createElement('div');
	d.style.cssText = 'padding:5px 0;border-bottom:1px solid var(--line)';
	if (a.cree) {
		d.innerHTML = '<span style="color:var(--ok)">✓</span> <strong></strong> — demande de <strong class="q"></strong> créée';
		d.querySelector('strong').textContent = res.libelle || '';
		d.querySelector('.q').textContent = a.quantite;
	} else {
		// Le refus le plus fréquent est l'idempotence : le dire, sinon
		// l'utilisateur rescanne en croyant que rien ne s'est passé.
		d.innerHTML = '<span class="muted">•</span> <strong></strong> — <span class="m muted"></span>';
		d.querySelector('strong').textContent = res.libelle || '';
		d.querySelector('.m').textContent = a.message || 'aucune demande créée';
	}
	zone.insertBefore(d, zone.firstChild);
}
</script>
<div class="card card-flush"><div class="card-head"><h2>À réapprovisionner</h2><span class="muted"><?= count( $alertes ) ?> article(s) sous le seuil</span></div>
	<table class="table"><thead><tr><th>Code</th><th>Article</th><th class="num">Disponible</th><th class="num">Min</th><th class="num">Max</th><th class="num">Suggestion à commander</th></tr></thead><tbody>
	<?php if ( ! $alertes ) : ?><tr><td colspan="6" class="empty">Aucune alerte — tous les stocks sont au-dessus du seuil. ✓</td></tr>
	<?php else : foreach ( $alertes as $a ) : ?><tr>
		<td class="code"><a href="<?= e( url( 'inventaire/articles/' . (int) $a['id'] . '/modifier' ) ) ?>"><?= e( $a['code'] ) ?></a></td>
		<td><?= e( $a['designation'] ) ?></td>
		<td class="num" style="color:<?= $a['dispo']<=0?'var(--danger)':'var(--orange)' ?>;font-weight:700"><?= e( fkc_money( $a['dispo'], 2 ) ) ?></td>
		<td class="num"><?= e( fkc_money( $a['stock_min'], 0 ) ) ?></td><td class="num"><?= e( fkc_money( $a['stock_max'], 0 ) ) ?></td>
		<td class="num"><strong><?= e( fkc_money( $a['suggestion'], 0 ) ) ?></strong> <?= e( $a['unite'] ) ?></td></tr>
	<?php endforeach; endif; ?></tbody></table>
</div>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Ruptures</h2></div>
		<table class="table"><thead><tr><th>Article</th><th class="num">Dispo</th></tr></thead><tbody>
		<?php if ( ! $ruptures ) : ?><tr><td colspan="2" class="empty">Aucune rupture. ✓</td></tr>
		<?php else : foreach ( $ruptures as $r ) : ?><tr><td><?= e( $r['code'] . ' · ' . $r['designation'] ) ?></td><td class="num" style="color:var(--danger)"><?= e( fkc_money( $r['dispo'], 2 ) ) ?></td></tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
	<div class="card card-flush"><div class="card-head"><h2>Surstock (rotation faible)</h2></div>
		<table class="table"><thead><tr><th>Article</th><th class="num">Stock</th><th class="num">Max</th></tr></thead><tbody>
		<?php if ( ! $surstock ) : ?><tr><td colspan="3" class="empty">Aucun surstock.</td></tr>
		<?php else : foreach ( $surstock as $s ) : ?><tr><td><?= e( $s['code'] . ' · ' . $s['designation'] ) ?></td><td class="num"><?= e( fkc_money( $s['total'], 2 ) ) ?></td><td class="num"><?= e( fkc_money( $s['stock_max'], 0 ) ) ?></td></tr><?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>
<?php if ( $lotsOn ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Péremption ≤ 30 jours</h2></div>
	<table class="table"><thead><tr><th>Article</th><th>Lot/Série</th><th class="num">Qté</th><th>Péremption</th></tr></thead><tbody>
	<?php if ( ! $peremption ) : ?><tr><td colspan="4" class="empty">Aucun lot proche de la péremption.</td></tr>
	<?php else : foreach ( $peremption as $p ) : ?><tr><td><?= e( $p['code'] . ' · ' . $p['designation'] ) ?></td><td><?= e( $p['lot'] ?: $p['serie'] ) ?></td>
		<td class="num"><?= e( fkc_money( $p['quantite'], 2 ) ) ?></td><td class="code" style="color:var(--orange)"><?= e( $p['date_peremption'] ) ?></td></tr>
	<?php endforeach; endif; ?></tbody></table>
</div>
<?php endif; ?>
