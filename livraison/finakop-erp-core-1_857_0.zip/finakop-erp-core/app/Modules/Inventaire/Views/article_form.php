<?php /** @var array|null $a @var array $cats @var array $types @var array $defaults @var array $stockRows @var array $mouvements @var bool $valoOn @var float $fifo @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$v = function ( $k, $def = '' ) use ( $a ) { return e( $a[ $k ] ?? $def ); };
$action = $a ? url( 'inventaire/articles/' . (int) $a['id'] ) : url( 'inventaire/articles' );
$mt = FKC_InvMouvement::types(); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'articles' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span><a href="<?= e( url( 'inventaire/articles' ) ) ?>">← Articles</a> &nbsp; <strong><?= $a ? e( $a['code'] . ' · ' . $a['designation'] ) : 'Nouvel article' ?></strong></span>
	<?php if ( $a ) : ?><form method="post" action="<?= e( url( 'inventaire/articles/' . (int) $a['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer cet article ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Supprimer</button></form><?php endif; ?>
</div>

<form method="post" action="<?= e( $action ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-rows">
		<div class="card"><div class="card-head"><h2>Général</h2></div><div class="card-body">
			<label class="fld"><span>Code <?= $a ? '*' : '' ?></span>
				<input name="code" value="<?= $v( 'code' ) ?>" <?= $a ? 'required' : '' ?>
					placeholder="<?= $a ? '' : 'ex. SACHET-EAU-500 — laissez vide pour un code automatique' ?>">
			</label>
			<?php if ( ! $a ) : ?>
				<p class="muted" style="font-size:12px;margin:-6px 0 10px">Référence <strong>interne</strong> de l'article, unique dans le catalogue. Ce n'est pas le code-barres : ceux-ci se déclarent plus bas, dans les conditionnements. Laissé vide, un code de type <code>ART-00001</code> est attribué automatiquement.</p>
			<?php endif; ?>
			<label class="fld"><span>Désignation *</span><input name="designation" value="<?= $v( 'designation' ) ?>" required></label>
			<?php
			// Codes-barres déjà affectés à cet article (registre du moteur de scan).
			$codesArticle = ( $a && class_exists( 'FKC_Scan' ) ) ? FKC_Scan::codesDe( 'article', $a['id'] ) : array();
			?>
			<div class="fld">
				<span>📦 Conditionnements (unités multiples)</span>
				<p class="muted" style="font-size:11.5px;margin:2px 0 8px">Le stock est toujours exprimé dans l'<strong>unité de base</strong>. Déclarez ici chaque niveau d'emballage (unité, colis/carton, palette) avec son code-barres et sa contenance. Un seul produit, plusieurs codes-barres.</p>
				<?php if ( ! $a ) : ?>
					<!-- CRÉATION : table éditable soumise avec le formulaire (Option A). -->
					<div class="table-wrap">
						<table class="table" style="margin:0" id="condTable">
							<thead><tr><th>Niveau</th><th>Désignation</th><th>Code-barres</th><th class="num">Contenance</th><th></th></tr></thead>
							<tbody id="condBody"></tbody>
						</table>
					</div>
					<button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px" onclick="condAddRow()">+ Ajouter un conditionnement</button>
					<p class="muted" style="font-size:11px;margin:6px 0 0">L'unité de base est ajoutée automatiquement. Les lignes sans code-barres seront ignorées.</p>
				<?php else : ?>
					<!-- MODIFICATION : gestionnaire en direct (AJAX). -->
					<div id="cbList" style="margin:6px 0"></div>
					<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:flex-end;border:1px solid var(--line);border-radius:8px;padding:8px;margin-top:6px">
						<span style="display:flex;flex-direction:column;width:130px">
							<small class="muted">Niveau</small>
							<select id="cbUnite" onchange="cbMajFacteur()">
								<option value="unite">Unité (détail)</option>
								<option value="pack">Pack</option>
								<option value="carton">Colis / Carton</option>
								<option value="palette">Palette</option>
							</select>
						</span>
						<span style="display:flex;flex-direction:column;flex:1;min-width:130px">
							<small class="muted">Désignation</small>
							<input id="cbDesignation" placeholder="ex. Carton de 24" style="width:100%">
						</span>
						<span style="display:flex;flex-direction:column;flex:1;min-width:150px">
							<small class="muted">Code-barres (EAN/ITF/QR)</small>
							<span style="display:flex;gap:4px">
								<input id="cbCode" placeholder="Scannez ou saisissez…" style="flex:1;font-family:monospace">
								<button type="button" class="btn btn-ghost btn-sm" id="artScan" title="Scanner">📷</button>
							</span>
						</span>
						<span style="display:flex;flex-direction:column;width:120px">
							<small class="muted">Contenance</small>
							<input id="cbFacteur" type="number" min="1" step="1" value="1" title="Nombre d'unités de base contenues">
						</span>
						<button type="button" class="btn btn-primary btn-sm" onclick="cbAjouter(false)">Ajouter</button>
					</div>
					<div id="artCamZone" hidden style="margin-top:8px"></div>
				<?php endif; ?>
			</div>
			<label class="fld"><span>Description</span><textarea name="description" rows="2"><?= $v( 'description' ) ?></textarea></label>
			<label class="fld"><span>Unité de base</span><input name="unite" id="uniteBase" value="<?= $v( 'unite', 'U' ) ?>" style="width:120px" title="L'unité dans laquelle le stock est compté"></label>
		</div></div>
		<div class="card"><div class="card-head"><h2>Classification</h2></div><div class="card-body">
			<label class="fld"><span>Type</span><select name="type" onchange="majComptes(this.value)">
				<?php foreach ( $types as $k => $lbl ) : ?><option value="<?= e( $k ) ?>" <?= ( $a['type'] ?? 'produit' )===$k?'selected':'' ?>><?= e( $lbl ) ?></option><?php endforeach; ?>
			</select></label>
			<label class="fld"><span>Catégorie</span><select name="categorie_id"><option value="">—</option>
				<?php foreach ( $cats as $c ) : ?><option value="<?= (int) $c['id'] ?>" <?= (int)($a['categorie_id']??0)===(int)$c['id']?'selected':'' ?>><?= e( $c['libelle'] ) ?></option><?php endforeach; ?>
			</select></label>
			<label class="fld-check"><input type="checkbox" name="gere_stock" value="1" <?= ( ! $a || ! empty( $a['gere_stock'] ) )?'checked':'' ?>> <span>Géré en stock</span></label>
			<label class="fld-check"><input type="checkbox" name="gere_lot" value="1" <?= ! empty( $a['gere_lot'] )?'checked':'' ?>> <span>Suivi par lot / série</span></label>
		</div></div>
		<div class="card"><div class="card-head"><h2>Tarification & fiscalité</h2></div><div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Prix d'achat</span><input type="number" step="0.01" name="prix_achat" value="<?= $v( 'prix_achat', '0' ) ?>"></label>
				<label class="fld"><span>Prix de vente</span><input type="number" step="0.01" name="prix_vente" value="<?= $v( 'prix_vente', '0' ) ?>"></label>
				<label class="fld"><span>TVA (%)</span><input type="number" step="0.01" name="tva" value="<?= $v( 'tva', '18' ) ?>"></label>
				<label class="fld"><span>Seuil d'alerte</span><input type="number" step="0.01" name="stock_min" value="<?= $v( 'stock_min', '0' ) ?>"></label>
				<label class="fld"><span>Stock cible (réappro)</span><input type="number" step="0.01" name="stock_max" value="<?= $v( 'stock_max', '0' ) ?>"></label>
				<label class="fld-check"><input type="checkbox" name="actif" value="1" <?= ( ! $a || ! empty( $a['actif'] ) )?'checked':'' ?>> <span>Actif</span></label>
			</div>
		</div></div>
		<div class="card"><div class="card-head"><h2>Comptes comptables (SYSCOHADA)</h2></div><div class="card-body">
			<div class="form-grid" style="grid-template-columns:1fr 1fr">
				<label class="fld"><span>Compte stock (3x)</span><input name="compte_stock" id="c_stock" value="<?= e( $a['compte_stock'] ?? $defaults['stock'] ) ?>"></label>
				<label class="fld"><span>Compte variation (603x)</span><input name="compte_variation" id="c_var" value="<?= e( $a['compte_variation'] ?? $defaults['variation'] ) ?>"></label>
				<label class="fld"><span>Compte achat (60x)</span><input name="compte_achat" id="c_ach" value="<?= e( $a['compte_achat'] ?? $defaults['achat'] ) ?>"></label>
				<label class="fld"><span>Compte vente (70x)</span><input name="compte_vente" id="c_vte" value="<?= e( $a['compte_vente'] ?? $defaults['vente'] ) ?>"></label>
			</div>
			<p class="help" style="margin:6px 0 0">Inventaire permanent : les entrées débitent le compte stock par le crédit du compte de variation ; les sorties font l'inverse.</p>
			<?php /* Les deux seuils sont partagés avec les catalogues des packs
			   métiers : « Seuil d'alerte » et « Stock cible » y désignent
			   exactement les mêmes valeurs, sous les mêmes noms depuis la
			   1.230.3. Le rappeler évite de croire à deux réglages distincts. */ ?>
			<p class="help" style="margin:4px 0 0">Le seuil d'alerte et le stock cible sont communs au catalogue de votre pack métier : les modifier ici les met à jour des deux côtés.</p>
		</div></div>
	</div>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $a ? 'Enregistrer' : 'Créer l\'article' ?></button></div>
</form>

<?php if ( $a ) : ?>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Stock par entrepôt</h2>
		<?php if ( $valoOn ) : ?><span class="muted">CMP <?= e( fkc_money( $a['cmp'], 0 ) ) ?> · FIFO <?= e( fkc_money( $fifo ) ) ?></span><?php endif; ?></div>
		<table class="table"><thead><tr><th>Entrepôt</th><th class="num">Quantité</th><th class="num">Réservé</th><th class="num">Disponible</th></tr></thead><tbody>
		<?php if ( ! $stockRows ) : ?><tr><td colspan="4" class="empty">Aucun stock.</td></tr>
		<?php else : foreach ( $stockRows as $s ) : ?><tr><td><?= e( $s['entrepot'] ) ?></td><td class="num"><?= e( fkc_money( $s['quantite'], 2 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $s['reserve'], 2 ) ) ?></td><td class="num"><strong><?= e( fkc_money( $s['quantite'] - $s['reserve'], 2 ) ) ?></strong></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
	<div class="card card-flush"><div class="card-head"><h2>Mouvements récents (traçabilité)</h2></div>
		<table class="table"><thead><tr><th>Date</th><th>Type</th><th>Entrepôt</th><th class="num">Qté</th><th class="num">Valeur</th></tr></thead><tbody>
		<?php if ( ! $mouvements ) : ?><tr><td colspan="5" class="empty">Aucun mouvement.</td></tr>
		<?php else : foreach ( $mouvements as $m ) : ?><tr><td class="code"><?= e( $m['date_mouv'] ) ?></td>
			<td><span class="modbadge"><?= e( $mt[ $m['type'] ] ?? $m['type'] ) ?></span></td><td><?= e( $m['entrepot'] ) ?></td>
			<td class="num"><?= e( fkc_money( $m['quantite'], 2 ) ) ?></td><td class="num"><?= e( fkc_money( $m['valeur'] ) ) ?></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
</div>
<script>
function majComptes(t){var d=<?= json_encode( array( 'produit'=>FKC_InvArticle::defaultComptes('produit'),'consommable'=>FKC_InvArticle::defaultComptes('consommable'),'service'=>FKC_InvArticle::defaultComptes('service'),'immobilisation'=>FKC_InvArticle::defaultComptes('immobilisation') ) ) ?>;
if(!d[t])return; document.getElementById('c_stock').value=d[t].stock; document.getElementById('c_var').value=d[t].variation; document.getElementById('c_ach').value=d[t].achat; document.getElementById('c_vte').value=d[t].vente; }
</script>
<?php endif; ?>
<script src="<?= e( fkc_asset( 'js/vendor/zxing.min.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>" defer></script>
<script src="<?= e( fkc_asset( 'js/scanner.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>" defer></script>
<script src="<?= e( fkc_asset( 'js/scanui.js' ) ) ?>?v=<?= e( FKC_VERSION ) ?>" defer></script>
<script>
(function(){
	var btn=document.getElementById('artScan'); if(!btn) return;
	var ui=null;
	btn.addEventListener('click',function(){
		if(typeof FKCScanUI==='undefined'){ alert('Lecteur caméra en cours de chargement, réessayez.'); return; }
		if(ui && ui.estOuvert()){ ui.fermer(); return; }
		if(!ui){
			ui=FKCScanUI.monter('artCamZone',{
				titre:'Scanner le code-barres',
				continu:false,
				onCode:function(code){ document.getElementById('cbCode').value=code; if(ui){ ui.fermer(); } }
			});
		}
		ui.ouvrir();
	});
})();

<?php if ( ! $a ) : ?>
/* ── CRÉATION : table de conditionnements éditable, soumise avec le formulaire ── */
var NIVEAUX_CR={unite:'Unité (détail)',pack:'Pack',carton:'Colis / Carton',palette:'Palette'};
function condDefaut(niveau){ return niveau==='pack'?6:niveau==='carton'?24:niveau==='palette'?48:1; }
function condRow(niveau, fixed){
	var uniteBase=(document.getElementById('uniteBase')||{}).value||'U';
	var tr=document.createElement('tr');
	var opts=Object.keys(NIVEAUX_CR).map(function(k){ return '<option value="'+k+'"'+(k===niveau?' selected':'')+'>'+NIVEAUX_CR[k]+'</option>'; }).join('');
	tr.innerHTML=
		'<td>'+(fixed
			? '<input type="hidden" name="cond_niveau[]" value="unite"><span style="font-size:11px;font-weight:700;color:#6aa8ff;border:1px solid #6aa8ff;border-radius:6px;padding:2px 7px">Unité de base</span>'
			: '<select name="cond_niveau[]" onchange="condSync(this)">'+opts+'</select>')+'</td>'
		+'<td><input name="cond_designation[]" placeholder="'+(fixed?'ex. Sachet':'ex. Carton de 24')+'" style="width:100%"></td>'
		+'<td><input name="cond_code[]" placeholder="EAN / ITF" style="font-family:monospace;width:100%"></td>'
		+'<td><input name="cond_facteur[]" class="num" type="number" min="1" step="1" value="'+(fixed?1:condDefaut(niveau))+'"'+(fixed?' readonly':'')+' style="width:90px"></td>'
		+'<td style="text-align:right">'+(fixed?'':'<button type="button" class="btn btn-ghost btn-sm" style="padding:2px 8px" onclick="this.closest(\'tr\').remove()">✕</button>')+'</td>';
	return tr;
}
function condSync(sel){
	var tr=sel.closest('tr'), fact=tr.querySelector('input[name="cond_facteur[]"]');
	var niveau=sel.value;
	if(niveau==='unite'){ fact.value=1; fact.readOnly=true; } else { fact.readOnly=false; if(parseInt(fact.value,10)<2) fact.value=condDefaut(niveau); }
}
function condAddRow(){ document.getElementById('condBody').appendChild(condRow('carton',false)); }
(function(){
	var body=document.getElementById('condBody'); if(!body) return;
	body.appendChild(condRow('unite',true));   // ligne unité de base, toujours présente
	body.appendChild(condRow('carton',false)); // une ligne carton pré-remplie pour guider
})();
<?php else : ?>
/* ── Gestionnaire de codes-barres multi-niveaux ── */
var ART_ID=<?= (int) $a['id'] ?>;
var CB_LIST=<?= json_encode( url( 'inventaire/articles/' . (int) $a['id'] . '/codes' ) ) ?>;
var CB_ADD=<?= json_encode( url( 'inventaire/articles/' . (int) $a['id'] . '/codes/ajouter' ) ) ?>;
var CB_DEL=<?= json_encode( url( 'inventaire/articles/' . (int) $a['id'] . '/codes/retirer' ) ) ?>;
var NIVEAUX={unite:'Unité (détail)',pack:'Pack',carton:'Carton',palette:'Palette'};
function cbEsc(s){return(s==null?'':''+s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}

function cbMajFacteur(){
	var u=document.getElementById('cbUnite').value, f=document.getElementById('cbFacteur');
	if(u==='unite'){ f.value=1; f.disabled=true; } else { f.disabled=false; if(parseInt(f.value,10)<2) f.value=(u==='pack'?6:u==='carton'?24:48); }
}
function cbCharger(){
	fetch(CB_LIST).then(function(r){return r.json();}).then(function(d){
		var box=document.getElementById('cbList');
		if(!d.ok||!d.codes||!d.codes.length){ box.innerHTML='<p class="muted" style="font-size:12px">Aucun conditionnement déclaré. Ajoutez au moins l\'unité de base ci-dessous.</p>'; return; }
		var order={unite:0,pack:1,carton:2,palette:3};
		var badge={unite:'#6aa8ff',pack:'#c58cff',carton:'#ffb24d',palette:'#4dd0a0'};
		d.codes.sort(function(a,b){return (order[a.unite]||9)-(order[b.unite]||9);});
		var rows=d.codes.map(function(c){
			var fact=parseFloat(c.facteur)||1, col=badge[c.unite]||'#888', desig='';
			try{ if(c.meta){ var m=JSON.parse(c.meta); desig=m.designation||''; } }catch(e){}
			return '<tr>'
				+'<td><span style="font-size:11px;font-weight:700;color:'+col+';border:1px solid '+col+';border-radius:6px;padding:2px 7px;white-space:nowrap">'+cbEsc(NIVEAUX[c.unite]||c.unite)+'</span></td>'
				+'<td>'+cbEsc(desig||'—')+'</td>'
				+'<td style="font-family:monospace;font-size:12.5px;word-break:break-all">'+cbEsc(c.code)+'</td>'
				+'<td class="num">'+(fact>1?(fact+' unités'):'1 unité')+'</td>'
				+'<td style="text-align:right"><button type="button" class="btn btn-ghost btn-sm" style="padding:2px 8px" onclick="cbRetirer(\''+cbEsc(c.code).replace(/'/g,'')+'\',\''+c.unite+'\')">✕</button></td>'
				+'</tr>';
		}).join('');
		box.innerHTML='<div class="table-wrap"><table class="table" style="margin:0"><thead><tr>'
			+'<th>Niveau</th><th>Désignation</th><th>Code-barres</th><th class="num">Contenance</th><th></th>'
			+'</tr></thead><tbody>'+rows+'</tbody></table></div>';
	}).catch(function(){});
}
function cbAjouter(force){
	var code=document.getElementById('cbCode').value.trim();
	if(!code){ alert('Saisissez un code-barres.'); return; }
	var unite=document.getElementById('cbUnite').value;
	var facteur=parseInt(document.getElementById('cbFacteur').value,10)||1;
	var designation=document.getElementById('cbDesignation').value.trim();
	var f=new FormData(); f.append('code',code); f.append('unite',unite); f.append('facteur',facteur); f.append('designation',designation); if(force) f.append('force','1');
	fetch(CB_ADD,{method:'POST',body:f}).then(function(r){return r.json();}).then(function(d){
		if(d.ok){ document.getElementById('cbCode').value=''; document.getElementById('cbDesignation').value=''; cbCharger(); }
		else if(d.conflit){
			if(confirm(d.message+'\n\nVoulez-vous forcer la réaffectation de ce code à cet article ?')) cbAjouter(true);
		} else { alert(d.message||'Échec.'); }
	}).catch(function(){ alert('Erreur réseau.'); });
}
function cbRetirer(code,unite){
	if(!confirm('Détacher ce code-barres de l\'article ?')) return;
	var f=new FormData(); f.append('code',code); f.append('unite',unite);
	fetch(CB_DEL,{method:'POST',body:f}).then(function(r){return r.json();}).then(function(){ cbCharger(); }).catch(function(){});
}
cbMajFacteur(); cbCharger();
<?php endif; ?>
</script>
