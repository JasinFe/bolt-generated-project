<?php /** @var array $articles @var array $entrepots @var array $recents @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'transferts' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouveau transfert</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/transferts' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:200px"><span>Article</span><select name="article_id" required><option value="">—</option><?php foreach ( $articles as $a ) : if ( empty( $a['gere_stock'] ) ) continue; ?><option value="<?= (int) $a['id'] ?>"><?= e( $a['code'] . ' · ' . $a['designation'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>De</span><select name="from_id" required><?php foreach ( $entrepots as $e ) : ?><option value="<?= (int) $e['id'] ?>"><?= e( $e['libelle'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Vers</span><select name="to_id" required><?php foreach ( $entrepots as $e ) : ?><option value="<?= (int) $e['id'] ?>"><?= e( $e['libelle'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Quantité</span><input type="number" step="0.01" name="quantite" required style="width:100px"></label>
		<button class="btn btn-primary" type="submit">Transférer</button>
	</form>
	<p class="help" style="margin:8px 0 0">Sans incidence comptable ni sur le CMP (simple déplacement entre entrepôts).</p>
</div></div>
<div class="card card-flush"><div class="card-head"><h2>Derniers transferts</h2></div>
	<table class="table"><thead><tr><th>Date</th><th>Article</th><th>Origine</th><th class="num">Qté</th></tr></thead><tbody>
	<?php if ( ! $recents ) : ?><tr><td colspan="4" class="empty">Aucun transfert.</td></tr>
	<?php else : foreach ( $recents as $m ) : ?><tr><td class="code"><?= e( $m['date_mouv'] ) ?></td><td><?= e( $m['article_code'] ) ?></td>
		<td><?= e( $m['entrepot'] ) ?></td><td class="num"><?= e( fkc_money( $m['quantite'], 2 ) ) ?></td></tr>
	<?php endforeach; endif; ?></tbody></table>
</div>
