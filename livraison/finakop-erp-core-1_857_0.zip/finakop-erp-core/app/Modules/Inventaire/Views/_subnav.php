<?php /** Barre Retour / Fermer (remplace l'ancienne rangée d'onglets). @var string $tab (ignoré) */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => 'inventaire' ) );
