<?php /** @var array $articles @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'stocks' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : article, code, entrepôt…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th>Article</th><th class="num">Disponible</th><th class="num">Réservé</th><th class="num">Min</th><th class="num">Max</th><th>État</th></tr></thead>
	<tbody>
	<?php $any = false; foreach ( $articles as $a ) : if ( empty( $a['gere_stock'] ) ) continue; $any = true;
		$dispo = (float) $a['stock_total'] - (float) $a['reserve_total'];
		$etat = $dispo <= 0 ? array( 'Rupture','b-off' ) : ( $a['stock_min'] > 0 && $dispo < $a['stock_min'] ? array( 'Critique','b-off' ) : ( $a['stock_max'] > 0 && $a['stock_total'] > $a['stock_max'] ? array( 'Surstock','' ) : array( 'OK','b-on' ) ) ); ?>
		<tr>
			<td class="code"><a href="<?= e( url( 'inventaire/articles/' . (int) $a['id'] . '/modifier' ) ) ?>"><?= e( $a['code'] ) ?></a></td>
			<td><?= e( $a['designation'] ) ?></td>
			<td class="num"><strong><?= e( fkc_money( $dispo, 2 ) ) ?></strong></td>
			<td class="num"><?= e( fkc_money( $a['reserve_total'], 2 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $a['stock_min'], 0 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $a['stock_max'], 0 ) ) ?></td>
			<td><span class="modbadge <?= $etat[1] ?>"><?= e( $etat[0] ) ?></span></td>
		</tr>
	<?php endforeach; if ( ! $any ) : ?><tr><td colspan="7" class="empty">Aucun article géré en stock.</td></tr><?php endif; ?>
	</tbody>
</table></div>
