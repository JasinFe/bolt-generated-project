<?php /** @var array $d @var array $alertes @var array $recents @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$mt = FKC_InvMouvement::types(); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'dashboard' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Valeur totale du stock</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $d['valeur_stock'] ) ) ?></div><span class="muted" style="font-size:.8em"><?= (int) $d['articles'] ?> article(s)</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Articles en rupture</span><div style="font-size:1.5em;font-weight:700;color:<?= $d['ruptures']?'var(--danger)':'var(--ok)' ?>"><?= (int) $d['ruptures'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Articles critiques</span><div style="font-size:1.5em;font-weight:700;color:<?= $d['critiques']?'var(--orange)':'var(--ok)' ?>"><?= (int) $d['critiques'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Commandes en attente</span><div style="font-size:1.5em;font-weight:700"><?= (int) $d['commandes_attente'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Réceptions du jour</span><div style="font-size:1.5em;font-weight:700"><?= (int) $d['receptions_jour'] ?></div></div></div>
</div>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Alertes de réapprovisionnement</h2><a class="btn btn-ghost btn-sm" href="<?= e( url( 'inventaire/reappro' ) ) ?>">Tout voir</a></div>
		<table class="table"><thead><tr><th>Article</th><th class="num">Dispo</th><th class="num">Min</th><th class="num">À commander</th></tr></thead><tbody>
		<?php if ( ! $alertes ) : ?><tr><td colspan="4" class="empty">Aucune alerte. ✓</td></tr>
		<?php else : foreach ( $alertes as $a ) : ?><tr><td><strong><?= e( $a['code'] ) ?></strong> <?= e( $a['designation'] ) ?></td>
			<td class="num" style="color:<?= $a['dispo']<=0?'var(--danger)':'var(--orange)' ?>"><?= e( fkc_money( $a['dispo'], 2 ) ) ?></td>
			<td class="num"><?= e( fkc_money( $a['stock_min'], 0 ) ) ?></td><td class="num"><strong><?= e( fkc_money( $a['suggestion'], 0 ) ) ?></strong></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
	<div class="card card-flush"><div class="card-head"><h2>Derniers mouvements</h2></div>
		<table class="table"><thead><tr><th>Date</th><th>Article</th><th>Type</th><th class="num">Qté</th></tr></thead><tbody>
		<?php if ( ! $recents ) : ?><tr><td colspan="4" class="empty">Aucun mouvement.</td></tr>
		<?php else : foreach ( $recents as $m ) : ?><tr><td class="code"><?= e( $m['date_mouv'] ) ?></td>
			<td><?= e( $m['article_code'] ) ?></td><td><span class="modbadge"><?= e( $mt[ $m['type'] ] ?? $m['type'] ) ?></span></td>
			<td class="num"><?= e( fkc_money( $m['quantite'], 2 ) ) ?></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
</div>
