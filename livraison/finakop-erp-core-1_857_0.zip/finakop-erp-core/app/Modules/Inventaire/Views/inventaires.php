<?php /** @var array $entrepots @var int $ent @var array $lignes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'inventaires' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar">
	<form method="get" style="display:flex;gap:8px;align-items:center"><span class="muted">Entrepôt à inventorier</span>
		<select name="e" onchange="this.form.submit()"><option value="">— Sélectionner —</option><?php foreach ( $entrepots as $en ) : ?><option value="<?= (int) $en['id'] ?>" <?= $ent===(int)$en['id']?'selected':'' ?>><?= e( $en['libelle'] ) ?></option><?php endforeach; ?></select>
	</form>
	<span class="muted">Inventaire tournant / annuel / surprise — saisissez le réel, l'écart est ajusté et comptabilisé.</span>
</div>
<?php if ( $ent && $lignes ) : ?>
<form method="post" action="<?= e( url( 'inventaire/inventaires' ) ) ?>">
	<?= FKC_Csrf::field() ?><input type="hidden" name="entrepot_id" value="<?= $ent ?>">
	<?php
	/*
	 * COMPTER EN SCANNANT, PAS EN CHERCHANT SA LIGNE.
	 *
	 * L'inventaire physique se fait debout, devant le rayon, la liste à la
	 * main. Retrouver chaque article dans un tableau de plusieurs centaines de
	 * lignes pour taper sa quantité est le vrai coût de l'opération — et la
	 * source des erreurs : on saisit dans la ligne d'à côté.
	 *
	 * Chaque code lu INCRÉMENTE la ligne de son article. Compter dix cartons,
	 * c'est dix bips ; la quantité se cumule d'elle-même et la ligne remonte
	 * sous les yeux. Rien n'est validé au scan : l'ajustement des écarts reste
	 * un geste délibéré, parce qu'il passe une écriture.
	 */
	?>
	<?php FKC_View::partial( 'scan::_scanbox', array(
		'contexte' => 'inventaire',
		'route'    => 'inventaire/inventaires',
		'cible'    => 'comptageScanne',
	) ); ?>
	<div id="comptageFlux" class="muted" style="font-size:.9em;margin:-4px 0 10px;min-height:1.2em"></div>
	<script>
	function comptageScanne(res) {
		var a = res.action || {}, zone = document.getElementById('comptageFlux');
		var champ = document.querySelector('input[name="reel[' + a.article_id + ']"]');
		if (!champ) {
			// L'article existe mais n'est pas dans CET entrepôt : le dire, sinon
			// l'utilisateur croit avoir compté quelque chose qui ne sera pas pris.
			zone.innerHTML = '<span style="color:var(--danger)">✗</span> ' + (res.libelle || 'Article')
				+ ' n\'est pas suivi dans cet entrepôt — rien n\'a été compté.';
			return;
		}
		var actuel = parseFloat(champ.value);
		if (isNaN(actuel)) { actuel = 0; }
		champ.value = (actuel + parseFloat(a.quantite || 1)).toFixed(2);
		champ.closest('tr').style.background = 'var(--ok-bg)';
		champ.scrollIntoView({ block: 'center', behavior: 'smooth' });
		zone.innerHTML = '✓ ' + (res.libelle || '') + ' — compté : <strong>' + champ.value + '</strong>'
			+ (a.stock_theorique !== null && a.stock_theorique !== undefined ? ' (théorique ' + a.stock_theorique + ')' : '');
	}
	</script>
	<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : référence, date, statut…' ) ); ?>
<div class="card card-flush"><table class="table">
		<thead><tr><th>Code</th><th>Article</th><th class="num">Théorique</th><th class="num">Réel compté</th><th class="num">CMP</th></tr></thead>
		<tbody><?php foreach ( $lignes as $l ) : ?><tr>
			<td class="code"><?= e( $l['code'] ) ?></td><td><?= e( $l['designation'] ) ?></td>
			<td class="num"><?= e( fkc_money( $l['theo'], 2 ) ) ?></td>
			<td class="num"><input type="number" step="0.01" name="reel[<?= (int) $l['id'] ?>]" placeholder="<?= e( fkc_money( $l['theo'], 2 ) ) ?>" style="width:110px;text-align:right"></td>
			<td class="num"><?= e( fkc_money( $l['cmp'], 0 ) ) ?></td>
		</tr><?php endforeach; ?></tbody>
	</table></div>
	<div class="actions"><button class="btn btn-primary" type="submit">Valider l'inventaire & ajuster les écarts</button></div>
</form>
<?php elseif ( $ent ) : ?><div class="card"><div class="card-body empty">Aucun article géré en stock.</div></div>
<?php else : ?><div class="card"><div class="card-body empty" style="padding:40px;text-align:center">Sélectionnez un entrepôt pour démarrer un inventaire physique.</div></div><?php endif; ?>
