<?php /** @var array $eval @var array $opts @var bool $regleActive @var int|null $demandesOuvertes @var mixed $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php
/*
 * L'écran est construit autour d'une question, pas d'une liste : « qu'est-ce
 * qui va manquer, et quand ? ». Chaque ligne porte donc une DATE de rupture
 * avant sa quantité — c'est la date qui décide, la quantité ne fait qu'en
 * découler. Et chaque ligne s'ouvre sur le calcul complet : une suggestion
 * qu'on ne peut pas contredire ne se discute pas, elle s'ignore.
 */
$fmtJours = function ( $j ) {
	if ( null === $j ) { return '—'; }
	if ( $j <= 0 ) { return 'aujourd\'hui'; }
	return $j . ' j';
};
$couleur = function ( $j, $delai ) {
	if ( null === $j ) { return 'var(--muted)'; }
	if ( $j <= $delai ) { return 'var(--danger)'; }
	if ( $j <= $delai * 2 ) { return 'var(--orange)'; }
	return 'var(--ok)';
};
?>
<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
	<form method="post" action="<?= e( url( 'inventaire/previsionnel/demander' ) ) ?>"
		onsubmit="return confirm('Créer les demandes d\'achat anticipées pour les articles dont la rupture est projetée avant livraison ?')">
		<?= FKC_Csrf::field() ?>
		<input type="hidden" name="couverture" value="<?= (int) $opts['couverture'] ?>">
		<button class="btn btn-primary btn-sm" type="submit" <?= $eval['commander'] ? '' : 'disabled' ?>>
			🔮 Anticiper <?= count( $eval['commander'] ) ?> commande(s)
		</button>
	</form>
	<form method="get" action="<?= e( url( 'inventaire/previsionnel' ) ) ?>" style="display:flex;gap:6px;align-items:center">
		<label class="muted" style="font-size:.85em">Couverture visée après livraison</label>
		<input class="num" type="number" name="couverture" min="1" max="180" style="width:70px"
			value="<?= (int) $opts['couverture'] ?>">
		<span class="muted" style="font-size:.85em">jours</span>
		<button class="btn btn-ghost btn-sm" type="submit">Recalculer</button>
	</form>
	<?php if ( $demandesOuvertes ) : ?>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/achats/demandes' ) ) ?>">
			<?= (int) $demandesOuvertes ?> demande(s) en attente de validation
		</a>
	<?php endif; ?>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'inventaire/reappro' ) ) ?>">Seuils &amp; alertes →</a>
</div>

<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'previsionnel' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>

<?php if ( ! $regleActive ) : ?>
	<div class="alert alert-warn">La règle « approvisionnement prévisionnel » est désactivée : cet écran calcule et
		affiche, mais le passage automatique en demandes d'achat ne se déclenchera pas depuis les événements métier.
		Le bouton ci-dessus reste opérant.</div>
<?php endif; ?>

<div class="card card-flush">
	<div class="card-head">
		<h2>Rupture projetée avant livraison</h2>
		<span class="muted"><?= count( $eval['commander'] ) ?> article(s) à commander maintenant</span>
	</div>
	<table class="table">
		<thead><tr>
			<th>Code</th><th>Article</th>
			<th class="num">Tient</th><th>Rupture le</th>
			<th class="num">Dispo</th><th class="num">En commande</th>
			<th class="num">Point de commande</th><th class="num">À commander</th>
			<th class="num">Confiance</th><th></th>
		</tr></thead>
		<tbody>
		<?php if ( ! $eval['commander'] ) : ?>
			<tr><td colspan="10" class="empty">Aucune rupture projetée sur l'horizon délai + couverture. ✓</td></tr>
		<?php else : foreach ( $eval['commander'] as $r ) : ?>
			<tr>
				<td class="code"><a href="<?= e( url( 'inventaire/articles/' . (int) $r['id'] . '/modifier' ) ) ?>"><?= e( $r['code'] ) ?></a></td>
				<td><?= e( $r['designation'] ) ?><?php if ( $r['saisonnier'] ) : ?> <span title="Rythme hebdomadaire détecté et appliqué">📈</span><?php endif; ?></td>
				<td class="num" style="color:<?= e( $couleur( $r['jours_couverture'], (int) $r['delai_jours'] ) ) ?>;font-weight:700"><?= e( $fmtJours( $r['jours_couverture'] ) ) ?></td>
				<td class="code"><?= e( $r['date_rupture'] ?: '—' ) ?></td>
				<td class="num"><?= e( fkc_money( $r['dispo'], 2 ) ) ?></td>
				<td class="num"><?= $r['en_cours'] > 0 ? e( fkc_money( $r['en_cours'], 2 ) ) : '—' ?></td>
				<td class="num"><?= e( fkc_money( $r['point_commande'], 2 ) ) ?></td>
				<td class="num"><strong><?= e( fkc_money( $r['a_commander'], 2 ) ) ?></strong> <?= e( $r['unite'] ) ?></td>
				<td class="num"><?= (int) $r['confiance'] ?> %</td>
				<td><details><summary class="muted" style="cursor:pointer;font-size:.85em">Calcul</summary>
					<ul style="margin:6px 0 0;padding-left:18px;font-size:.85em;line-height:1.5">
						<?php foreach ( $r['explication'] as $l ) : ?><li><?= e( $l ) ?></li><?php endforeach; ?>
					</ul></details></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>

<div class="card card-flush">
	<div class="card-head">
		<h2>À surveiller</h2>
		<span class="muted">Le stock se tend, mais la série ne soutient pas encore une commande anticipée</span>
	</div>
	<table class="table">
		<thead><tr><th>Code</th><th>Article</th><th class="num">Tient</th><th class="num">Confiance</th><th>Pourquoi on ne commande pas</th></tr></thead>
		<tbody>
		<?php if ( ! $eval['surveiller'] ) : ?>
			<tr><td colspan="5" class="empty">Rien sous surveillance.</td></tr>
		<?php else : foreach ( $eval['surveiller'] as $r ) : ?>
			<tr>
				<td class="code"><?= e( $r['code'] ) ?></td>
				<td><?= e( $r['designation'] ) ?></td>
				<td class="num"><?= e( $fmtJours( $r['jours_couverture'] ) ) ?></td>
				<td class="num"><?= (int) $r['confiance'] ?> %</td>
				<td class="muted"><?= e( $r['motif'] ) ?></td>
			</tr>
		<?php endforeach; endif; ?>
		</tbody>
	</table>
</div>

<div class="form-grid">
	<div class="card card-flush">
		<div class="card-head"><h2>Couverts</h2><span class="muted"><?= count( $eval['ok'] ) ?> article(s)</span></div>
		<table class="table"><thead><tr><th>Article</th><th class="num">Tient</th></tr></thead><tbody>
		<?php if ( ! $eval['ok'] ) : ?><tr><td colspan="2" class="empty">—</td></tr>
		<?php else : foreach ( array_slice( $eval['ok'], 0, 15 ) as $r ) : ?>
			<tr><td><?= e( $r['code'] . ' · ' . $r['designation'] ) ?></td><td class="num"><?= e( $fmtJours( $r['jours_couverture'] ) ) ?></td></tr>
		<?php endforeach; endif; ?>
		</tbody></table>
	</div>
	<div class="card card-flush">
		<div class="card-head"><h2>Non projetables</h2><span class="muted"><?= count( $eval['insuffisant'] ) ?> article(s)</span></div>
		<?php
		/*
		 * Ces articles sont AFFICHÉS, pas tus. Un écran qui les passerait sous
		 * silence laisserait croire que tout le catalogue est couvert alors
		 * qu'une part n'a simplement pas pu être regardée — c'est la seule
		 * façon pour une prévision de mentir sans se tromper.
		 */
		?>
		<table class="table"><thead><tr><th>Article</th><th>Raison</th></tr></thead><tbody>
		<?php if ( ! $eval['insuffisant'] ) : ?><tr><td colspan="2" class="empty">Tout le catalogue est projetable. ✓</td></tr>
		<?php else : foreach ( array_slice( $eval['insuffisant'], 0, 15 ) as $r ) : ?>
			<tr><td><?= e( $r['code'] . ' · ' . $r['designation'] ) ?></td><td class="muted" style="font-size:.85em"><?= e( $r['motif'] ) ?></td></tr>
		<?php endforeach; endif; ?>
		</tbody></table>
	</div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Comment ces chiffres sont obtenus</h2></div>
	<div style="padding:12px;line-height:1.7">
		La demande de chaque article est projetée à partir de ses <strong><?= (int) $opts['historique'] ?> derniers jours</strong>
		de sorties, jour par jour, zéros compris. Quand un rythme hebdomadaire se répète sur au moins deux semaines,
		il module la projection : le samedi d'une supérette n'est pas un mardi. Le délai fournisseur est
		<strong>mesuré</strong> sur les réceptions passées, non déclaré. Le point de commande vaut la demande projetée
		pendant ce délai, augmentée d'un stock de sécurité dimensionné sur l'erreur du modèle
		(facteur <?= e( number_format( (float) $opts['securite'], 2, ',', ' ' ) ) ?>).
		En dessous de <strong><?= (int) $opts['confiance'] ?> % de confiance</strong>, rien n'est commandé : la règle
		de seuil reprend seule la main. Toutes les demandes créées naissent « à valider » — aucune dépense n'est
		engagée sans décision humaine.
	</div>
</div>
