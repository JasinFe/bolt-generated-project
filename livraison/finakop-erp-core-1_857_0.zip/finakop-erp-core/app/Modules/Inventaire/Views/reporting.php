<?php /** @var float $rotation @var float $valeur @var array $parCat @var array $dormants @var array $consommation @var array $mouvements @var array $previsions @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$mt = FKC_InvMouvement::types(); $motifs = FKC_InvMouvement::motifsSortie(); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'reporting' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Valeur du stock</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $valeur ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Taux de rotation (12 mois)</span><div style="font-size:1.5em;font-weight:700"><?= e( fkc_money( $rotation, 2 ) ) ?>×</div><span class="help">sorties valorisées / valeur du stock</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Articles dormants (90 j)</span><div style="font-size:1.5em;font-weight:700;color:<?= $dormants?'var(--orange)':'var(--ok)' ?>"><?= count( $dormants ) ?></div></div></div>
</div>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Consommation par motif (12 mois)</h2></div>
		<table class="table"><thead><tr><th>Motif</th><th class="num">Quantité</th><th class="num">Valeur</th></tr></thead><tbody>
		<?php if ( ! $consommation ) : ?><tr><td colspan="3" class="empty">Aucune sortie.</td></tr>
		<?php else : foreach ( $consommation as $motif => $c ) : ?><tr><td><?= e( $motifs[ $motif ] ?? $motif ) ?></td>
			<td class="num"><?= e( fkc_money( $c['qte'], 2 ) ) ?></td><td class="num"><?= e( fkc_money( $c['val'] ) ) ?></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
	<div class="card card-flush"><div class="card-head"><h2>Mouvements par type (12 mois)</h2></div>
		<table class="table"><thead><tr><th>Type</th><th class="num">Nombre</th><th class="num">Valeur</th></tr></thead><tbody>
		<?php if ( ! $mouvements ) : ?><tr><td colspan="3" class="empty">Aucun mouvement.</td></tr>
		<?php else : foreach ( $mouvements as $type => $m ) : ?><tr><td><?= e( $mt[ $type ] ?? $type ) ?></td>
			<td class="num"><?= (int) $m['n'] ?></td><td class="num"><?= e( fkc_money( $m['val'] ) ) ?></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
</div>
<div class="form-grid">
	<div class="card card-flush"><div class="card-head"><h2>Articles dormants</h2></div>
		<table class="table"><thead><tr><th>Code</th><th>Article</th><th class="num">Stock</th><th>Dernière sortie</th></tr></thead><tbody>
		<?php if ( ! $dormants ) : ?><tr><td colspan="4" class="empty">Aucun article dormant. ✓</td></tr>
		<?php else : foreach ( $dormants as $d ) : ?><tr><td class="code"><?= e( $d['code'] ) ?></td><td><?= e( $d['designation'] ) ?></td>
			<td class="num"><?= e( fkc_money( $d['total'], 2 ) ) ?></td><td class="code"><?= e( $d['derniere_sortie'] ?: 'jamais' ) ?></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
	<div class="card card-flush"><div class="card-head"><h2>Prévisions (conso. mensuelle moyenne)</h2></div>
		<table class="table"><thead><tr><th>Code</th><th>Article</th><th class="num">Conso/mois</th><th class="num">Dispo</th><th class="num">Couverture</th></tr></thead><tbody>
		<?php if ( ! $previsions ) : ?><tr><td colspan="5" class="empty">Pas assez de données.</td></tr>
		<?php else : foreach ( $previsions as $p ) : $cov = $p['conso_mois'] > 0 ? $p['dispo'] / $p['conso_mois'] : null; ?><tr>
			<td class="code"><?= e( $p['code'] ) ?></td><td><?= e( $p['designation'] ) ?></td>
			<td class="num"><?= e( fkc_money( $p['conso_mois'], 1 ) ) ?></td><td class="num"><?= e( fkc_money( $p['dispo'], 1 ) ) ?></td>
			<td class="num"><?= $cov !== null ? e( fkc_money( $cov, 1 ) ) . ' mois' : '—' ?></td></tr>
		<?php endforeach; endif; ?></tbody></table>
	</div>
</div>
