<?php /** @var array $fournisseurs @var array $moyennes @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'fournisseurs' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Évaluation fournisseur</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/fournisseurs/evaluation' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:200px"><span>Fournisseur</span><select name="fournisseur_id" required><option value="">—</option><?php foreach ( $fournisseurs as $f ) : ?><option value="<?= (int) $f['id'] ?>"><?= e( $f['nom'] ) ?></option><?php endforeach; ?></select></label>
		<label class="fld" style="margin:0"><span>Délai /5</span><input type="number" step="0.5" min="0" max="5" name="note_delai" value="3" style="width:80px"></label>
		<label class="fld" style="margin:0"><span>Prix /5</span><input type="number" step="0.5" min="0" max="5" name="note_prix" value="3" style="width:80px"></label>
		<label class="fld" style="margin:0"><span>Qualité /5</span><input type="number" step="0.5" min="0" max="5" name="note_qualite" value="3" style="width:80px"></label>
		<label class="fld" style="margin:0;flex:1;min-width:160px"><span>Commentaire</span><input name="commentaire"></label>
		<button class="btn btn-primary" type="submit">Noter</button>
	</form>
</div></div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : nom, code, contact…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Fournisseur</th><th class="num">Note moyenne</th><th class="num">Évaluations</th></tr></thead><tbody>
	<?php if ( ! $fournisseurs ) : ?><tr><td colspan="3" class="empty">Aucun fournisseur. Créez-en dans Référentiels › Fournisseurs.</td></tr>
	<?php else : foreach ( $fournisseurs as $f ) : $m = $moyennes[ (int) $f['id'] ] ?? null; ?>
		<tr><td><strong><?= e( $f['nom'] ) ?></strong></td>
			<td class="num"><?= $m ? '<strong>' . e( $m['moy'] ) . '</strong> / 5' : '<span class="muted">—</span>' ?></td>
			<td class="num"><?= $m ? (int) $m['n'] : 0 ?></td></tr>
	<?php endforeach; endif; ?></tbody>
</table></div>
