<?php /** @var string $methode @var array $rows @var float $total_cmp @var array $parCat @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$maxCat = 0; foreach ( $parCat as $v ) { $maxCat = max( $maxCat, $v ); } ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'valorisation' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Valeur totale du stock (CMP)</span><div style="font-size:1.6em;font-weight:700"><?= e( fkc_money( $total_cmp ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Méthode active</span><div style="font-size:1.6em;font-weight:700"><?= e( $methode ) ?></div><span class="help">CMP (coût moyen pondéré) & FIFO disponibles</span></div></div>
</div>
<div class="card card-flush"><div class="card-head"><h2>Valorisation par article</h2></div>
	<table class="table"><thead><tr><th>Code</th><th>Article</th><th class="num">Qté</th><th class="num">CMP</th><th class="num">Valeur CMP</th><th class="num">Valeur FIFO</th></tr></thead><tbody>
	<?php if ( ! $rows ) : ?><tr><td colspan="6" class="empty">Aucun article en stock.</td></tr>
	<?php else : foreach ( $rows as $r ) : ?><tr>
		<td class="code"><?= e( $r['code'] ) ?></td><td><?= e( $r['designation'] ) ?></td>
		<td class="num"><?= e( fkc_money( $r['qte'], 2 ) ) ?></td><td class="num"><?= e( fkc_money( $r['cmp'], 0 ) ) ?></td>
		<td class="num"><strong><?= e( fkc_money( $r['val_cmp'] ) ) ?></strong></td><td class="num"><?= e( fkc_money( $r['val_fifo'] ) ) ?></td></tr>
	<?php endforeach; endif; ?>
	<tr class="total"><td colspan="4">Total (CMP)</td><td class="num"><?= e( fkc_money( $total_cmp ) ) ?></td><td></td></tr>
	</tbody></table>
</div>
<div class="card"><div class="card-head"><h2>Valeur du stock par catégorie</h2></div><div class="card-body">
	<?php if ( ! $parCat ) : ?><p class="empty">Aucune donnée.</p>
	<?php else : foreach ( $parCat as $cat => $val ) : ?>
		<div style="margin-bottom:8px"><div style="display:flex;justify-content:space-between"><span><?= e( $cat ) ?></span><strong><?= e( fkc_money( $val ) ) ?></strong></div>
			<div style="background:var(--line);border-radius:4px;height:8px;overflow:hidden"><div style="background:var(--orange);height:8px;width:<?= $maxCat>0?round($val/$maxCat*100):0 ?>%"></div></div></div>
	<?php endforeach; endif; ?>
</div></div>
