<?php /** @var array $entrepots @var array $emplacements @var bool $multi @var int $nb @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'inventaire::_subnav', array( 'tab' => 'entrepots' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<?php if ( ! $multi && $nb >= 1 ) : ?><div class="alert alert-warn">Édition mono-entrepôt : la création d'entrepôts supplémentaires nécessite l'édition <strong>Enterprise</strong> (multi-entrepôts).</div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouvel entrepôt</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'inventaire/entrepots' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0"><span>Code</span><input name="code" placeholder="auto" title="Laissez vide : le code est attribué automatiquement." style="width:110px;text-transform:uppercase"></label>
		<label class="fld" style="margin:0;min-width:200px"><span>Libellé</span><input name="libelle" required></label>
		<label class="fld" style="margin:0;min-width:200px"><span>Adresse</span><input name="adresse"></label>
		<label class="fld" style="margin:0;flex-direction:row;align-items:center;gap:6px"><input type="checkbox" name="principal" value="1"> <span>Principal</span></label>
		<button class="btn btn-primary" type="submit" <?= ( ! $multi && $nb >= 1 ) ? 'disabled' : '' ?>>Ajouter</button>
	</form>
</div></div>
<?php foreach ( $entrepots as $e ) : ?>
<div class="card card-flush"><div class="card-head">
	<h2><?= e( $e['code'] ) ?> · <?= e( $e['libelle'] ) ?> <?= $e['principal'] ? '<span class="modbadge b-on">Principal</span>' : '' ?></h2>
	<form method="post" action="<?= e( url( 'inventaire/entrepots/' . (int) $e['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer cet entrepôt ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Supprimer</button></form>
</div><div class="card-body">
	<?php if ( $e['adresse'] ) : ?><p class="muted" style="margin:0 0 8px"><?= e( $e['adresse'] ) ?></p><?php endif; ?>
	<?php $arbre = $emplacements[ (int) $e['id'] ] ?? array(); $niv = FKC_InvEntrepot::niveaux(); ?>
	<?php if ( $arbre ) : ?>
	<div style="overflow-x:auto;margin-bottom:10px"><table class="table"><thead><tr><th>Emplacement</th><th>Niveau</th><th>Étiquette</th><th></th></tr></thead><tbody>
		<?php foreach ( $arbre as $em ) : ?>
		<tr>
			<td style="padding-left:<?= 12 + 18 * (int) $em['profondeur'] ?>px"><?= (int) $em['profondeur'] ? '└ ' : '' ?><strong><?= e( $em['code'] ) ?></strong><?= $em['libelle'] ? ' · ' . e( $em['libelle'] ) : '' ?></td>
			<td class="muted"><?= e( $niv[ $em['niveau'] ?? '' ] ?? '—' ) ?></td>
			<td><a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="<?= e( url( 'scan/generateur?type=qr&valeur=' . rawurlencode( 'FKC:emplacement:' . (int) $em['id'] ) ) ) ?>">🏷️ QR</a></td>
			<td style="text-align:right"><form method="post" action="<?= e( url( 'inventaire/emplacements/' . (int) $em['id'] . '/supprimer' ) ) ?>" style="display:inline" onsubmit="return confirm('Supprimer cet emplacement ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" style="color:var(--danger)">✕</button></form></td>
		</tr>
		<?php endforeach; ?>
	</tbody></table></div>
	<?php endif; ?>
	<form method="post" action="<?= e( url( 'inventaire/emplacements' ) ) ?>" class="form-grid form-compact">
		<?= FKC_Csrf::field() ?><input type="hidden" name="entrepot_id" value="<?= (int) $e['id'] ?>">
		<div class="fld"><label>Code</label><input name="code" placeholder="A-01" style="text-transform:uppercase" required></div>
		<div class="fld"><label>Libellé</label><input name="libelle" placeholder="Allée A"></div>
		<div class="fld"><label>Niveau</label><select name="niveau"><?php foreach ( $niv as $k => $v ) : ?><option value="<?= e( $k ) ?>"><?= e( $v ) ?></option><?php endforeach; ?></select></div>
		<div class="fld"><label>Dans</label><select name="parent_id"><option value="">— (racine de l'entrepôt)</option><?php foreach ( $arbre as $em ) : ?><option value="<?= (int) $em['id'] ?>"><?= e( str_repeat( '· ', (int) $em['profondeur'] ) . $em['code'] ) ?></option><?php endforeach; ?></select></div>
		<div class="fld"><label>&nbsp;</label><button class="btn btn-ghost btn-sm" type="submit">+ Ajouter</button></div>
	</form>
</div></div>
<?php endforeach; ?>
