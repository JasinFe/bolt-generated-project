<?php
/** Catégories d'articles. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvCategorie {
	public static function all() { return FKC_DB::q( 'SELECT * FROM inv_categories ORDER BY libelle COLLATE NOCASE' )->fetchAll(); }
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM inv_categories WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function map() { $m = array(); foreach ( self::all() as $c ) { $m[ (int) $c['id'] ] = $c['libelle']; } return $m; }
	public static function codeExists( $code, $exceptId = 0 ) { return (bool) FKC_DB::q( 'SELECT 1 FROM inv_categories WHERE code=? AND id<>?', array( strtoupper( $code ), (int) $exceptId ) )->fetch(); }
	/**
	 * Code de la catégorie — fabriqué si l'utilisateur n'en donne pas.
	 *
	 * La colonne est NOT NULL UNIQUE : un champ laissé vide faisait échouer
	 * l'insertion, ou passait un code vide qui bloquait la création suivante.
	 * L'utilisateur découvrait la contrainte après avoir rempli le formulaire.
	 */
	public static function code( $saisi ) {
		if ( ! class_exists( 'FKC_CodeAuto' ) ) { return strtoupper( trim( (string) $saisi ) ); }
		return strtoupper( FKC_CodeAuto::ou( $saisi, 'inv_categories', FKC_CodeAuto::prefixe( 'inv_categories', 'CAT-' ), 'code', 3 ) );
	}

	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO inv_categories(code,libelle,parent_id,actif) VALUES(?,?,?,?)',
			array( self::code( $d['code'] ?? '' ), trim( (string) $d['libelle'] ),
				! empty( $d['parent_id'] ) ? (int) $d['parent_id'] : null, empty( $d['actif'] ) ? 0 : 1 ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) {
		FKC_DB::q( 'UPDATE inv_articles SET categorie_id=NULL WHERE categorie_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM inv_categories WHERE id=?', array( (int) $id ) );
	}
}
