<?php
/** Réceptions : bon de réception, contrôle commandé/reçu/écart, génère entrée + comptabilisation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvReception {
	public static function all() {
		return FKC_DB::q( 'SELECT r.*, e.libelle entrepot, a.numero achat_num FROM inv_receptions r
			JOIN inv_entrepots e ON e.id=r.entrepot_id LEFT JOIN inv_achats a ON a.id=r.achat_id ORDER BY r.date DESC, r.id DESC' )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM inv_receptions WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		$r['lignes'] = FKC_DB::q( 'SELECT l.*, a.code art_code, a.designation FROM inv_reception_lignes l JOIN inv_articles a ON a.id=l.article_id WHERE l.reception_id=? ORDER BY l.id', array( (int) $id ) )->fetchAll();
		return $r;
	}
	public static function duJour() { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM inv_receptions WHERE date=?', array( date( 'Y-m-d' ) ) )->fetchColumn(); }

	/**
	 * Enregistre une réception et génère les entrées en stock (chaque ligne reçue
	 * met à jour stock + CMP et passe l'écriture D 31 / C 603).
	 * @param array $opts division_id, achat_id, note
	 */
	public static function enregistrer( $entrepotId, $date, $lignes, $opts = array() ) {
		// Numérotation haute-eau : le COUNT(*) réattribuait un numéro de bon
		// après suppression, et deux réceptions distinctes portaient la même
		// référence — celle qui sert à rapprocher la facture fournisseur.
		/* L'année du numéro est celle de la pièce, pas du jour de saisie (1.726.0). */
		$anBr = class_exists( 'FKC_Numerotation' ) ? FKC_Numerotation::anneeDe( $date ) : (int) date( 'Y' );
		$num = class_exists( 'FKC_CodeAuto' )
			? FKC_CodeAuto::suivant( 'inv_receptions', 'BR-' . $anBr . '-', 'numero', 4 )
			: 'BR-' . $anBr . '-' . str_pad( (string) ( 1 + (int) FKC_DB::q( "SELECT COUNT(*) FROM inv_receptions" )->fetchColumn() ), 4, '0', STR_PAD_LEFT );
		FKC_DB::q( 'INSERT INTO inv_receptions(numero,achat_id,entrepot_id,date,statut,note) VALUES(?,?,?,?,?,?)',
			array( $num, ! empty( $opts['achat_id'] ) ? (int) $opts['achat_id'] : null, (int) $entrepotId, $date, 'recu', trim( (string) ( $opts['note'] ?? '' ) ) ?: null ) );
		$rid = (int) FKC_DB::conn()->lastInsertId();
		$div = $opts['division_id'] ?? null;
		$montantTotal = 0.0;
		foreach ( (array) $lignes as $l ) {
			$artId = (int) ( $l['article_id'] ?? 0 ); $qte = (float) ( $l['qte_recue'] ?? 0 );
			if ( ! $artId || $qte <= 0 ) { continue; }
			$pu = (float) ( $l['pu'] ?? 0 );
			FKC_DB::q( 'INSERT INTO inv_reception_lignes(reception_id,article_id,qte_commandee,qte_recue,pu) VALUES(?,?,?,?,?)',
				array( $rid, $artId, (float) ( $l['qte_commandee'] ?? $qte ), $qte, $pu ) );

			/*
			 * LE LOT ET LA PÉREMPTION ENTRENT AVEC LA MARCHANDISE.
			 *
			 * La réception les ignorait : un article géré en lot recevait du
			 * stock SANS lot. Conséquences en chaîne — la traçabilité amont
			 * était impossible (« ce lot vient de quel fournisseur ? » restait
			 * sans réponse), les alertes de péremption ne trouvaient rien à
			 * signaler, et un rappel de lot obligeait à fouiller les bons
			 * papier. Le carton portait pourtant l'information sur son code.
			 *
			 * Le lot est créé s'il n'existe pas, complété sinon : deux
			 * réceptions du même lot s'additionnent au lieu d'ouvrir deux
			 * lignes que rien ne rapproche.
			 */
			$lotId = self::lotPour( $artId, $entrepotId, $l, $qte );
			FKC_InvMouvement::entree( $artId, $entrepotId, $qte, $pu, array( 'motif'=>'achat', 'ref_type'=>'reception', 'ref_id'=>$rid, 'division_id'=>$div, 'date'=>$date, 'lot_id'=>$lotId ) );
			$montantTotal += round( $qte * $pu, 2 );
		}

		/*
		 * ─────────────────────────────────────────────────────────────────
		 * LA MÊME LIVRAISON NE SE SAISIT PLUS DEUX FOIS (1.671.0).
		 *
		 * Les deux recettes de bout en bout (1.668.0 et 1.669.0) l'ont
		 * signalé comme leur manque le plus concret : `inv_receptions`
		 * alimente le STOCK, `achat_receptions` alimente le compte 408 et le
		 * BUDGET, et rien ne reliait les deux. Un magasinier devait saisir
		 * deux fois la même livraison — et rien ne garantissait que les deux
		 * saisies disent la même chose.
		 *
		 * Ce qu'on oubliait n'était pas anodin : sans entrée au registre des
		 * achats, la dette envers le fournisseur n'existait nulle part, la
		 * facture n'avait rien à rapprocher, et le budget ne voyait jamais le
		 * réalisé — la ligne restait engagée par une commande dont la
		 * marchandise était pourtant arrivée.
		 *
		 * ON NE CONSTRUIT RIEN : cinq entrées de stock du produit — Vertical,
		 * Retail, Pharmacie, Distribution, Fabrication — posent déjà ce pont,
		 * avec la même clé d'idempotence. Le module Inventaire était le seul
		 * à ne pas le faire.
		 *
		 * LE FOURNISSEUR PEUT MANQUER, et ce n'est pas une raison d'écarter
		 * la réception : l'arbitrage est celui de Vertical, la marchandise
		 * est là et la dette existe même sans nom en face. Elle s'attribue
		 * ensuite depuis Comptabilité → Achats.
		 */
		if ( class_exists( 'FKC_AchatReception' ) && $montantTotal > 0 ) {
			$frnId = ! empty( $opts['fournisseur_id'] ) ? (int) $opts['fournisseur_id'] : null;
			if ( ! $frnId && ! empty( $opts['achat_id'] ) ) {
				// La commande d'achat connaît son fournisseur : le redemander
				// à l'utilisateur serait lui faire ressaisir ce qu'il a déjà dit.
				try {
					$v = FKC_DB::q( 'SELECT fournisseur_id FROM inv_achats WHERE id=?', array( (int) $opts['achat_id'] ) )->fetchColumn();
					if ( $v ) { $frnId = (int) $v; }
				} catch ( \Throwable $e ) { /* réception sans fournisseur : voir plus haut */ }
			}
			$frnNom = null;
			if ( $frnId ) {
				try { $frnNom = (string) FKC_DB::q( 'SELECT nom FROM fournisseurs WHERE id=?', array( $frnId ) )->fetchColumn(); }
				catch ( \Throwable $e ) { $frnNom = null; }
			}
			$bl = null;
			if ( ! empty( $opts['achat_id'] ) ) {
				try { $bl = FKC_DB::q( 'SELECT budget_ligne_id FROM inv_achats WHERE id=?', array( (int) $opts['achat_id'] ) )->fetchColumn(); }
				catch ( \Throwable $e ) { $bl = null; }
			}
			try {
				FKC_AchatReception::enregistrer( array(
					'fournisseur_id'  => $frnId,
					'fournisseur_nom' => $frnNom ?: null,
					'pack'            => 'inventaire',
					'objet_type'      => 'inv_reception', 'objet_id' => $rid,
					'piece'           => $num,
					'libelle'         => 'Réception ' . $num,
					'date_reception'  => $date,
					'montant_ht'      => round( $montantTotal, 2 ),
					// La CLÉ porte l'identifiant du bon : une réception rejouée
					// — reprise après panne, double clic — n'entre qu'une fois.
					'cle'             => 'inv:reception:' . $rid,
					'budget_ligne_id' => $bl ? (int) $bl : null,
				) );
			} catch ( \Throwable $e ) {
				// Le registre des achats est une conséquence, pas une
				// condition : une panne ici ne doit pas refuser la
				// marchandise, qui est physiquement arrivée.
				if ( function_exists( 'fkc_log' ) ) {
					fkc_log( 'Réception ' . $num . ' : registre des achats non alimenté — ' . $e->getMessage(), 'WARN' );
				}
			}
		}
		if ( ! empty( $opts['achat_id'] ) ) {
			/*
			 * marquerRecu() ne solde plus la commande à l'aveugle : il compare
			 * le commandé au reçu CUMULÉ et laisse la commande ouverte tant
			 * qu'il reste de la marchandise à venir (1.651.0). La réception
			 * partielle est le cas ordinaire, pas l'exception.
			 */
			FKC_InvAchat::marquerRecu( (int) $opts['achat_id'] );

			/*
			 * SUR-LIVRAISON : ON L'ACCEPTE ET ON LE DIT (1.674.0).
			 *
			 * Le contrôle budgétaire a lieu au passage à « commande » et
			 * nulle part ailleurs : une réception qui dépasse le montant
			 * commandé ne réveillait rien. Un fournisseur qui livre 120 pour
			 * 100 consommait le budget de 20 unités que personne n'avait
			 * approuvées.
			 *
			 * ON NE REFUSE PAS LA SAISIE — la marchandise est physiquement
			 * arrivée, et la refuser ne la fait pas repartir ; elle finirait
			 * en stock non tracé, ce qui est pire. Même arbitrage qu'au
			 * dépassement budgétaire (1.627.0) et à la validation de commande
			 * (1.651.0) : on informe, on ne bloque pas.
			 *
			 * Le journal porte la trace immédiate, et `surLivraisons()` la
			 * rend visible au Centre d'intégrité — parce qu'un avertissement
			 * qui passe dans un journal que personne n'ouvre n'avertit
			 * personne.
			 */
			$ecart = FKC_InvAchat::ecartLivraison( (int) $opts['achat_id'] );
			if ( $ecart < -0.0001 && function_exists( 'fkc_log' ) ) {
				fkc_log( 'Réception ' . $num . ' : ' . fkc_money( -$ecart )
					. ' unité(s) reçue(s) EN PLUS de la commande #' . (int) $opts['achat_id']
					. ' — budget consommé au-delà de ce qui a été approuvé.', 'WARN' );
			}
			/*
			 * La réception hérite de la ligne budgétaire de SA commande. Sans
			 * cela, le budget verrait l'engagement partir et le réalisé ne
			 * jamais arriver : la ligne redeviendrait disponible alors que la
			 * dépense a bien eu lieu.
			 */
			if ( class_exists( 'FKC_BudgetConso' ) ) {
				try {
					$bl = FKC_DB::q( 'SELECT budget_ligne_id FROM inv_achats WHERE id=?', array( (int) $opts['achat_id'] ) )->fetchColumn();
					if ( $bl ) { FKC_BudgetConso::recalculer( (int) $bl ); }
				} catch ( \Throwable $e ) { /* le budget se recalera au prochain passage */ }
			}
		}
		return $rid;
	}
	/**
	 * Crée ou complète le lot d'une ligne de réception.
	 *
	 * Rien n'est fait si la ligne ne porte pas de numéro de lot : on n'invente
	 * pas un identifiant que le fournisseur n'a pas donné. Un lot inventé est
	 * pire que pas de lot — il donne l'illusion d'une traçabilité.
	 *
	 * @return int|null identifiant du lot, ou null
	 */
	protected static function lotPour( $articleId, $entrepotId, array $ligne, $qte ) {
		$lot = trim( (string) ( $ligne['lot'] ?? '' ) );
		$per = trim( (string) ( $ligne['peremption'] ?? '' ) );
		$ser = trim( (string) ( $ligne['serie'] ?? '' ) );
		if ( '' === $lot && '' === $ser ) { return null; }

		try {
			$e = FKC_DB::q(
				'SELECT id, quantite FROM inv_lots WHERE article_id=? AND entrepot_id=? AND COALESCE(lot,\'\')=? AND COALESCE(serie,\'\')=? LIMIT 1',
				array( (int) $articleId, (int) $entrepotId, $lot, $ser )
			)->fetch();
			if ( $e ) {
				FKC_DB::q( 'UPDATE inv_lots SET quantite = quantite + ?' . ( $per ? ', date_peremption=?' : '' ) . ' WHERE id=?',
					$per ? array( (float) $qte, $per, (int) $e['id'] ) : array( (float) $qte, (int) $e['id'] ) );
				return (int) $e['id'];
			}
			FKC_DB::q(
				'INSERT INTO inv_lots(article_id,entrepot_id,lot,serie,quantite,date_peremption) VALUES(?,?,?,?,?,?)',
				array( (int) $articleId, (int) $entrepotId, $lot ?: null, $ser ?: null, (float) $qte, $per ?: null )
			);
			return (int) FKC_DB::conn()->lastInsertId();
		} catch ( \Throwable $e ) { return null; }
	}

	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM inv_reception_lignes WHERE reception_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM inv_receptions WHERE id=?', array( (int) $id ) );
	}
}
