<?php
/** Mouvements de stock : entrée, sortie, transfert, ajustement — CMP, traçabilité, analytique, comptabilisation. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvMouvement {

	public static function motifsSortie() { return array( 'vente'=>'Vente','consommation'=>'Consommation interne','perte'=>'Perte','don'=>'Don' ); }
	public static function types() { return array( 'entree'=>'Entrée','sortie'=>'Sortie','transfert_out'=>'Transfert (sortie)','transfert_in'=>'Transfert (entrée)','ajustement'=>'Ajustement' ); }

	protected static function record( $d ) {
		FKC_DB::q( 'INSERT INTO inv_mouvements(article_id,entrepot_id,type,motif,quantite,pu,valeur,ref_type,ref_id,division_id,lot_id,ecriture_id,user_id,date_mouv) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array( (int) $d['article_id'], (int) $d['entrepot_id'], $d['type'], $d['motif'] ?? null,
				(float) $d['quantite'], (float) ( $d['pu'] ?? 0 ), (float) ( $d['valeur'] ?? 0 ),
				$d['ref_type'] ?? null, ! empty( $d['ref_id'] ) ? (int) $d['ref_id'] : null,
				! empty( $d['division_id'] ) ? (int) $d['division_id'] : null,
				! empty( $d['lot_id'] ) ? (int) $d['lot_id'] : null,
				! empty( $d['ecriture_id'] ) ? (int) $d['ecriture_id'] : null,
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null, $d['date_mouv'] ?? date( 'Y-m-d' ) ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/** Entrée en stock : met à jour le CMP, la quantité, comptabilise (D 31 / C 603). */
	public static function entree( $articleId, $entrepotId, $qte, $pu, $opts = array() ) {
		$qte = (float) $qte; if ( $qte <= 0 ) { return 0; }
		$art = FKC_InvArticle::find( $articleId ); if ( ! $art ) { return 0; }
		$pu = (float) $pu;
		/*
		 * Valorisation déléguée au moteur unique. La formule vivait ici, et à
		 * l'identique dans le module Vertical et le pack Retail : trois copies
		 * qu'aucun mécanisme ne tenait synchronisées. Le moteur corrige en outre
		 * le cas du stock négatif, où la moyenne pondérée classique produisait
		 * un coût supérieur à tout prix jamais payé.
		 *
		 * Les frais accessoires (transport, douane, manutention) sont incorporés
		 * au coût d'entrée, comme l'impose SYSCOHADA.
		 */
		$oldTot = FKC_InvStock::totalArticle( $articleId );
		$etat   = FKC_Valorisation::appliquerEntree(
			$oldTot, (float) $art['cmp'], $qte, $pu,
			(array) ( $opts['frais'] ?? array() ),
			$opts['motif'] ?? 'achat'
		);
		$pu = $etat['pu_entree'];
		FKC_InvStock::adjust( $articleId, $entrepotId, $qte );
		FKC_InvArticle::setCmp( $articleId, $etat['cump'] );
		$valeur = round( $etat['valeur'], 0 );
		$date = $opts['date'] ?? date( 'Y-m-d' );
		$eid = ( $opts['post'] ?? true ) ? FKC_InvComptable::comptabiliser( 'entree', $art, $valeur, $date, 'Entrée stock ' . $art['code'], $opts['division_id'] ?? null ) : null;
		return self::record( array(
			'article_id'=>$articleId, 'entrepot_id'=>$entrepotId, 'type'=>'entree', 'motif'=>$opts['motif'] ?? 'achat',
			'quantite'=>$qte, 'pu'=>$pu, 'valeur'=>$valeur, 'ref_type'=>$opts['ref_type'] ?? null, 'ref_id'=>$opts['ref_id'] ?? null,
			'division_id'=>$opts['division_id'] ?? null, 'lot_id'=>$opts['lot_id'] ?? null, 'ecriture_id'=>$eid, 'date_mouv'=>$date,
		) );
	}

	/** Sortie de stock : valorisée au CMP courant, comptabilise (D 603 / C 31). */
	public static function sortie( $articleId, $entrepotId, $qte, $opts = array() ) {
		$qte = (float) $qte; if ( $qte <= 0 ) { return 0; }
		$art = FKC_InvArticle::find( $articleId ); if ( ! $art ) { return 0; }
		$cmp = (float) $art['cmp'];
		$valeur = round( $qte * $cmp, 0 );
		FKC_InvStock::adjust( $articleId, $entrepotId, -$qte );
		$date = $opts['date'] ?? date( 'Y-m-d' );
		$motif = $opts['motif'] ?? 'consommation';
		$eid = ( $opts['post'] ?? true ) ? FKC_InvComptable::comptabiliser( 'sortie', $art, $valeur, $date, 'Sortie stock ' . $art['code'] . ' (' . $motif . ')', $opts['division_id'] ?? null ) : null;
		// Miroir descendant : si l'article est apparié à un pack métier, sa
		// sortie doit y être répercutée. Sans cela, une vente encaissée à la
		// caisse du noyau viderait le stock central pendant que le catalogue du
		// pack afficherait toujours la marchandise en rayon. Le pont ne se
		// déclenche pas lorsque c'est le pack qui a initié le mouvement.
		// `sans_miroir` (1.839.0) : l'appelant répercute LUI-MÊME la sortie
		// dans le pack (caisse → Commerce Core : mouvement, n° de série,
		// garantie) ; le miroir générique la décompterait une seconde fois.
		if ( class_exists( 'FKC_ArticleBridge' ) && empty( $opts['sans_miroir'] ) ) {
			try { FKC_ArticleBridge::miroirVersPacks( $articleId, $qte, array( 'motif' => $motif ) ); }
			catch ( \Throwable $e ) { /* une sortie ne doit jamais être bloquée par le miroir */ }
		}
		return self::record( array(
			'article_id'=>$articleId, 'entrepot_id'=>$entrepotId, 'type'=>'sortie', 'motif'=>$motif,
			'quantite'=>$qte, 'pu'=>$cmp, 'valeur'=>$valeur, 'ref_type'=>$opts['ref_type'] ?? null, 'ref_id'=>$opts['ref_id'] ?? null,
			'division_id'=>$opts['division_id'] ?? null, 'ecriture_id'=>$eid, 'date_mouv'=>$date,
		) );
	}

	/** Transfert entre entrepôts : aucune incidence comptable ni sur le CMP global. */
	public static function transfert( $articleId, $fromId, $toId, $qte, $opts = array() ) {
		$qte = (float) $qte; if ( $qte <= 0 || (int) $fromId === (int) $toId ) { return 0; }
		$art = FKC_InvArticle::find( $articleId ); if ( ! $art ) { return 0; }
		$cmp = (float) $art['cmp']; $date = $opts['date'] ?? date( 'Y-m-d' );
		FKC_InvStock::adjust( $articleId, $fromId, -$qte );
		FKC_InvStock::adjust( $articleId, $toId, $qte );
		self::record( array( 'article_id'=>$articleId, 'entrepot_id'=>$fromId, 'type'=>'transfert_out', 'motif'=>'transfert',
			'quantite'=>$qte, 'pu'=>$cmp, 'valeur'=>round( $qte * $cmp, 0 ), 'ref_id'=>$toId, 'date_mouv'=>$date ) );
		return self::record( array( 'article_id'=>$articleId, 'entrepot_id'=>$toId, 'type'=>'transfert_in', 'motif'=>'transfert',
			'quantite'=>$qte, 'pu'=>$cmp, 'valeur'=>round( $qte * $cmp, 0 ), 'ref_id'=>$fromId, 'date_mouv'=>$date ) );
	}

	/** Ajustement d'inventaire : aligne la quantité d'un entrepôt sur le réel, comptabilise l'écart. */
	public static function ajustement( $articleId, $entrepotId, $qteReelle, $opts = array() ) {
		$art = FKC_InvArticle::find( $articleId ); if ( ! $art ) { return 0; }
		$theo = FKC_InvStock::quantite( $articleId, $entrepotId );
		$delta = (float) $qteReelle - $theo;
		if ( abs( $delta ) < 0.0001 ) { return 0; }
		$cmp = (float) $art['cmp']; $valeur = round( abs( $delta ) * $cmp, 0 );
		$date = $opts['date'] ?? date( 'Y-m-d' );
		FKC_InvStock::setQuantite( $articleId, $entrepotId, (float) $qteReelle );
		$sens = $delta > 0 ? 'entree' : 'sortie';

		/*
		 * Un écart d'inventaire N'EST PAS une consommation.
		 *
		 * Il était comptabilisé comme un mouvement de stock ordinaire, donc au
		 * compte de variation d'exploitation (603) : la casse, le vol et les
		 * erreurs de saisie se noyaient dans le coût matière, exactement là où
		 * ils devaient sauter aux yeux. Un restaurant dont le coût matière
		 * dérive doit pouvoir dire si ses recettes coûtent plus cher ou si sa
		 * cave fuit — deux décisions opposées.
		 *
		 * L'écart part désormais sur un compte de pertes distinct. Repli sur
		 * l'ancien comportement si le service n'est pas disponible : un
		 * ajustement ne doit jamais rester sans écriture.
		 */
		$eid = null;
		if ( $opts['post'] ?? true ) {
			$fait = false;
			if ( class_exists( 'FKC_StockCompta' ) ) {
				// Signe attendu par le service : positif = manquant.
				$manquant = -$delta * $cmp;
				list( $okEc, , $eidEc ) = FKC_StockCompta::comptabiliserEcartInventaire(
					FKC_StockCompta::natureDuPack( class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : '' ),
					$manquant, $date, 'Écart d\'inventaire — ' . $art['code'] . ' ' . $art['designation']
				);
				if ( $okEc ) { $eid = $eidEc; $fait = true; }
			}
			if ( ! $fait ) {
				$eid = FKC_InvComptable::comptabiliser( $sens, $art, $valeur, $date, 'Ajustement inventaire ' . $art['code'], $opts['division_id'] ?? null );
			}
		}
		return self::record( array(
			'article_id'=>$articleId, 'entrepot_id'=>$entrepotId, 'type'=>'ajustement', 'motif'=>'inventaire',
			'quantite'=>$delta, 'pu'=>$cmp, 'valeur'=>$valeur, 'ecriture_id'=>$eid, 'date_mouv'=>$date,
			// 1.818.0 : l'origine de l'ajustement (ex. session Smart Scan) — traçabilité Scan → Stock → Écriture.
			'ref_type' => $opts['ref_type'] ?? null, 'ref_id' => $opts['ref_id'] ?? null,
		) );
	}

	/* Consultations / traçabilité */
	public static function forArticle( $articleId, $limit = 100 ) {
		return FKC_DB::q( 'SELECT m.*, e.libelle entrepot FROM inv_mouvements m JOIN inv_entrepots e ON e.id=m.entrepot_id WHERE m.article_id=? ORDER BY m.date_mouv DESC, m.id DESC LIMIT ?', array( (int) $articleId, (int) $limit ) )->fetchAll();
	}
	public static function recents( $limit = 50 ) {
		return FKC_DB::q( 'SELECT m.*, a.code article_code, a.designation, e.libelle entrepot, u.nom_complet user_nom
			FROM inv_mouvements m JOIN inv_articles a ON a.id=m.article_id JOIN inv_entrepots e ON e.id=m.entrepot_id
			LEFT JOIN utilisateurs u ON u.id=m.user_id ORDER BY m.created_at DESC, m.id DESC LIMIT ?', array( (int) $limit ) )->fetchAll();
	}
	public static function recuesAujourdhui() {
		return (int) FKC_DB::q( "SELECT COUNT(*) FROM inv_mouvements WHERE type='entree' AND date_mouv=?", array( date( 'Y-m-d' ) ) )->fetchColumn();
	}
}
