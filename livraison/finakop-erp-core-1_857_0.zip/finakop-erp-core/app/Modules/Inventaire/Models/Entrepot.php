<?php
/** Entrepôts & emplacements. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvEntrepot {
	public static function all( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE actif=1' : '';
		return FKC_DB::q( "SELECT * FROM inv_entrepots{$w} ORDER BY principal DESC, libelle COLLATE NOCASE" )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM inv_entrepots WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function map() { $m = array(); foreach ( self::all() as $e ) { $m[ (int) $e['id'] ] = $e['libelle']; } return $m; }
	public static function principal() {
		$r = FKC_DB::q( 'SELECT * FROM inv_entrepots WHERE principal=1 AND actif=1' )->fetch();
		if ( $r ) { return $r; }
		return FKC_DB::q( 'SELECT * FROM inv_entrepots WHERE actif=1 ORDER BY id LIMIT 1' )->fetch() ?: null;
	}
	public static function count() { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM inv_entrepots WHERE actif=1' )->fetchColumn(); }
	public static function codeExists( $code, $exceptId = 0 ) { return (bool) FKC_DB::q( 'SELECT 1 FROM inv_entrepots WHERE code=? AND id<>?', array( strtoupper( $code ), (int) $exceptId ) )->fetch(); }
	/** Code de l'entrepôt — fabriqué si le champ est laissé vide (colonne NOT NULL UNIQUE). */
	public static function code( $saisi ) {
		if ( ! class_exists( 'FKC_CodeAuto' ) ) { return strtoupper( trim( (string) $saisi ) ); }
		return strtoupper( FKC_CodeAuto::ou( $saisi, 'inv_entrepots', FKC_CodeAuto::prefixe( 'inv_entrepots', 'ENT-' ), 'code', 3 ) );
	}

	public static function create( $d ) {
		$principal = empty( $d['principal'] ) ? 0 : 1;
		if ( $principal ) { FKC_DB::q( 'UPDATE inv_entrepots SET principal=0' ); }
		FKC_DB::q( 'INSERT INTO inv_entrepots(code,libelle,adresse,principal,actif) VALUES(?,?,?,?,?)',
			array( self::code( $d['code'] ?? '' ), trim( (string) $d['libelle'] ),
				trim( (string) ( $d['adresse'] ?? '' ) ) ?: null, $principal, empty( $d['actif'] ) ? 0 : 1 ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM inv_entrepots WHERE id=?', array( (int) $id ) ); }

	/* ── Emplacements HIÉRARCHIQUES (1.818.0) ──────────────────────────────
	   Entrepôt → Zone → Allée → Rayon → Niveau → Bac. La table était plate
	   (un code, un libellé) : on ne pouvait ni dire où se trouve un bac, ni
	   compter un rayon entier. Chaque emplacement porte désormais son parent
	   et son niveau ; son CHEMIN complet se lit partout (scan, inventaire).
	   Chaque emplacement est inscrit au registre des codes sous la forme
	   QR « FKC:emplacement:<id> » — unique même si deux entrepôts ont un
	   « A-01 » — et, si le code court est libre, sous ce code aussi. */

	public static function niveaux() {
		return array( 'zone' => 'Zone', 'allee' => 'Allée', 'rayon' => 'Rayon', 'niveau' => 'Niveau', 'bac' => 'Bac' );
	}

	protected static $hierPret = array();
	public static function ensureHierarchie() {
		$f = (string) FKC_DB::file();
		if ( isset( self::$hierPret[ $f ] ) ) { return; }
		self::$hierPret[ $f ] = true;
		$cols = array_column( FKC_DB::q( 'PRAGMA table_info(inv_emplacements)' )->fetchAll(), 'name' );
		foreach ( array( 'parent_id' => 'INTEGER', 'niveau' => "TEXT DEFAULT 'bac'" ) as $c => $d ) {
			if ( ! in_array( $c, $cols, true ) ) { FKC_DB::conn()->exec( "ALTER TABLE inv_emplacements ADD COLUMN {$c} {$d}" ); }
		}
	}

	public static function emplacements( $entrepotId ) {
		self::ensureHierarchie();
		return FKC_DB::q( 'SELECT * FROM inv_emplacements WHERE entrepot_id=? ORDER BY code', array( (int) $entrepotId ) )->fetchAll();
	}

	/** Arbre à plat, dans l'ordre de lecture, avec la profondeur de chaque nœud. */
	public static function arbre( $entrepotId ) {
		$tous = self::emplacements( $entrepotId );
		$enfants = array();
		foreach ( $tous as $e ) { $enfants[ (int) ( $e['parent_id'] ?? 0 ) ][] = $e; }
		$out = array();
		$vus = array();
		$descendre = function ( $pid, $prof ) use ( &$descendre, &$out, &$vus, $enfants ) {
			foreach ( $enfants[ $pid ] ?? array() as $e ) {
				if ( isset( $vus[ (int) $e['id'] ] ) ) { continue; } // garde-fou anti-cycle
				$vus[ (int) $e['id'] ] = true;
				$e['profondeur'] = $prof;
				$out[] = $e;
				$descendre( (int) $e['id'], $prof + 1 );
			}
		};
		$descendre( 0, 0 );
		// Orphelins (parent supprimé ou dans un autre entrepôt) : affichés à la racine.
		foreach ( $tous as $e ) { if ( ! isset( $vus[ (int) $e['id'] ] ) ) { $e['profondeur'] = 0; $out[] = $e; } }
		return $out;
	}

	/** « Principal › Zone A › Rayon 3 › Bac 2 ». */
	public static function chemin( $emplacementId ) {
		self::ensureHierarchie();
		$parts = array(); $id = (int) $emplacementId; $garde = 0; $entrepot = null;
		while ( $id && $garde++ < 12 ) {
			$e = FKC_DB::q( 'SELECT * FROM inv_emplacements WHERE id=?', array( $id ) )->fetch();
			if ( ! $e ) { break; }
			$entrepot = (int) $e['entrepot_id'];
			array_unshift( $parts, trim( (string) ( $e['libelle'] ?: $e['code'] ) ) );
			$id = (int) ( $e['parent_id'] ?? 0 );
		}
		if ( $entrepot ) {
			$lib = FKC_DB::q( 'SELECT libelle FROM inv_entrepots WHERE id=?', array( $entrepot ) )->fetchColumn();
			if ( $lib ) { array_unshift( $parts, $lib ); }
		}
		return implode( ' › ', $parts );
	}

	/** @return array{bool,string,int|null} */
	public static function addEmplacement( $d ) {
		self::ensureHierarchie();
		$ent = (int) ( $d['entrepot_id'] ?? 0 );
		$code = strtoupper( trim( (string) ( $d['code'] ?? '' ) ) );
		if ( ! $ent || '' === $code ) { return array( false, 'Entrepôt et code requis.', null ); }
		$parent = (int) ( $d['parent_id'] ?? 0 );
		if ( $parent ) {
			$pe = FKC_DB::q( 'SELECT entrepot_id FROM inv_emplacements WHERE id=?', array( $parent ) )->fetchColumn();
			if ( (int) $pe !== $ent ) { return array( false, 'Le parent doit appartenir au même entrepôt.', null ); }
		}
		$niveau = array_key_exists( $d['niveau'] ?? '', self::niveaux() ) ? $d['niveau'] : 'bac';
		if ( FKC_DB::q( 'SELECT 1 FROM inv_emplacements WHERE entrepot_id=? AND code=?', array( $ent, $code ) )->fetchColumn() ) {
			return array( false, 'Le code ' . $code . ' existe déjà dans cet entrepôt.', null );
		}
		FKC_DB::q( 'INSERT INTO inv_emplacements(entrepot_id,code,libelle,actif,parent_id,niveau) VALUES(?,?,?,1,?,?)',
			array( $ent, $code, trim( (string) ( $d['libelle'] ?? '' ) ) ?: null, $parent ?: null, $niveau ) );
		$id = (int) FKC_DB::conn()->lastInsertId();
		self::inscrireAuRegistre( $id );
		return array( true, 'Emplacement ' . $code . ' ajouté.', $id );
	}

	/** Inscrit l'emplacement au registre des codes (QR unique + code court s'il est libre). */
	public static function inscrireAuRegistre( $id ) {
		if ( ! class_exists( 'FKC_Scan' ) ) { return; }
		$e = FKC_DB::q( 'SELECT * FROM inv_emplacements WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $e ) { return; }
		$lib = self::chemin( (int) $id );
		FKC_Scan::lier( array( 'code' => FKC_Scan::qrPayload( 'emplacement', (int) $id ), 'entite_type' => 'emplacement', 'entite_id' => (int) $id,
			'module' => 'inventaire', 'libelle' => $lib, 'symbologie' => 'qr' ), false );
		// Code court : seulement s'il n'appartient à rien d'autre (sinon le QR suffit).
		FKC_Scan::lier( array( 'code' => (string) $e['code'], 'entite_type' => 'emplacement', 'entite_id' => (int) $id,
			'module' => 'inventaire', 'libelle' => $lib ), false );
	}

	/** @return array{bool,string} */
	public static function deleteEmplacement( $id ) {
		self::ensureHierarchie();
		if ( FKC_DB::q( 'SELECT 1 FROM inv_emplacements WHERE parent_id=?', array( (int) $id ) )->fetchColumn() ) {
			return array( false, 'Cet emplacement contient des sous-emplacements : supprimez-les d\'abord.' );
		}
		$e = FKC_DB::q( 'SELECT code FROM inv_emplacements WHERE id=?', array( (int) $id ) )->fetch();
		FKC_DB::q( 'DELETE FROM inv_emplacements WHERE id=?', array( (int) $id ) );
		if ( class_exists( 'FKC_Scan' ) && $e ) {
			FKC_DB::q( "UPDATE scan_codes SET actif=0 WHERE entite_type='emplacement' AND entite_id=?", array( (int) $id ) );
		}
		return array( true, 'Emplacement supprimé.' );
	}
}
