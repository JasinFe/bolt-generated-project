<?php
/** Valorisation du stock : CMP (coût moyen pondéré) et FIFO. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvValorisation {
	public static function methode() {
		$m = class_exists( 'FKC_License' ) ? FKC_License::param( 'inv_valorisation', 'CMP' ) : 'CMP';
		return in_array( $m, array( 'CMP', 'FIFO' ), true ) ? $m : 'CMP';
	}
	/** Valeur totale du stock (CMP). */
	public static function valeurStock() {
		return (float) FKC_DB::q( 'SELECT COALESCE(SUM(s.quantite*a.cmp),0) FROM inv_stock s JOIN inv_articles a ON a.id=s.article_id' )->fetchColumn();
	}
	public static function valeurArticle( $articleId ) {
		$a = FKC_InvArticle::find( $articleId ); if ( ! $a ) { return 0.0; }
		return round( FKC_InvStock::totalArticle( $articleId ) * (float) $a['cmp'], 0 );
	}
	public static function parCategorie() {
		$rows = FKC_DB::q( "SELECT COALESCE(c.libelle,'Sans catégorie') cat, COALESCE(SUM(s.quantite*a.cmp),0) val
			FROM inv_stock s JOIN inv_articles a ON a.id=s.article_id LEFT JOIN inv_categories c ON c.id=a.categorie_id
			GROUP BY cat ORDER BY val DESC" )->fetchAll();
		$o = array(); foreach ( $rows as $r ) { $o[ $r['cat'] ] = (float) $r['val']; } return $o;
	}
	/** Valeur FIFO d'un article : couches d'entrée restantes après consommation des plus anciennes. */
	public static function fifoArticle( $articleId ) {
		$entrees = FKC_DB::q( "SELECT quantite, pu FROM inv_mouvements WHERE article_id=? AND type IN('entree','transfert_in') ORDER BY date_mouv, id", array( (int) $articleId ) )->fetchAll();
		$sorties = (float) FKC_DB::q( "SELECT COALESCE(SUM(quantite),0) FROM inv_mouvements WHERE article_id=? AND type IN('sortie','transfert_out')", array( (int) $articleId ) )->fetchColumn();
		$reste = max( 0.0, FKC_InvStock::totalArticle( $articleId ) );
		// Consomme les couches les plus anciennes.
		$couches = array();
		foreach ( $entrees as $e ) { $couches[] = array( (float) $e['quantite'], (float) $e['pu'] ); }
		$aConsommer = $sorties;
		foreach ( $couches as $i => $c ) {
			if ( $aConsommer <= 0 ) { break; }
			$pris = min( $c[0], $aConsommer ); $couches[ $i ][0] -= $pris; $aConsommer -= $pris;
		}
		$val = 0.0; $q = 0.0;
		foreach ( $couches as $c ) { if ( $c[0] > 0 ) { $val += $c[0] * $c[1]; $q += $c[0]; } }
		// Ajuste au stock réel courant (en cas d'ajustements).
		if ( $q > 0 && abs( $q - $reste ) > 0.0001 ) { $val = $val / $q * $reste; }
		return round( $val, 0 );
	}
}
