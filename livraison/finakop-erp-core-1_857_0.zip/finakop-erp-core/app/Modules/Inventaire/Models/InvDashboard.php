<?php
/** Tableau de bord Inventaire. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvDashboard {
	public static function compute() {
		return array(
			'valeur_stock'      => FKC_InvValorisation::valeurStock(),
			'articles'          => (int) FKC_DB::q( 'SELECT COUNT(*) FROM inv_articles WHERE actif=1' )->fetchColumn(),
			'ruptures'          => FKC_InvReappro::countRuptures(),
			'critiques'         => FKC_InvReappro::countCritiques(),
			'commandes_attente' => FKC_InvAchat::enAttente(),
			'receptions_jour'   => FKC_InvReception::duJour(),
			'mouvements_jour'   => FKC_InvMouvement::recuesAujourdhui(),
		);
	}
}
