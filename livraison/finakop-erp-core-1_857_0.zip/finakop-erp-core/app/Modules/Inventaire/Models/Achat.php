<?php
/** Achats : demande d'achat, bon de commande, workflow Demandeur→Manager→Finance→Achat. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

/*
 * Ce modèle attribue ses références par FKC_CodeAuto (1.631.0). index.php le
 * charge, mais pas les harnais qui montent un modèle seul : sans ce require,
 * la classe manque au moment précis où l'on crée une pièce. On l'exige donc
 * plutôt que de retomber sur un COUNT(*) — un repli qui réintroduirait le
 * défaut corrigé serait pire que l'absence de repli.
 */
require_once FKC_ROOT . 'Core/CodeAuto.php';

class FKC_InvAchat {
	public static function etapes() {
		return array( 'demande'=>'Demande','manager'=>'Validé manager','finance'=>'Validé finance','achat'=>'Validé achat','commande'=>'Commandé','recu'=>'Reçu','annule'=>'Annulé' );
	}
	public static function suivant( $statut ) {
		$o = array( 'demande'=>'manager','manager'=>'finance','finance'=>'achat','achat'=>'commande' );
		return $o[ $statut ] ?? null;
	}
	public static function all( $statut = '' ) {
		$w = ''; $p = array();
		if ( '' !== $statut ) { $w = ' WHERE a.statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT a.*, f.nom fournisseur FROM inv_achats a LEFT JOIN fournisseurs f ON f.id=a.fournisseur_id{$w} ORDER BY a.created_at DESC", $p )->fetchAll();
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM inv_achats WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $r ) { return null; }
		$r['lignes'] = FKC_DB::q( 'SELECT l.*, a.designation art_designation, a.code art_code FROM inv_achat_lignes l LEFT JOIN inv_articles a ON a.id=l.article_id WHERE l.achat_id=? ORDER BY l.id', array( (int) $id ) )->fetchAll();
		return $r;
	}
	public static function enAttente() { return (int) FKC_DB::q( "SELECT COUNT(*) FROM inv_achats WHERE statut NOT IN('recu','annule')" )->fetchColumn(); }

	public static function create( $d, $lignes ) {
		// Le rang venait d'un COUNT sur l'année : une demande supprimée
		// faisait réattribuer son numéro, et deux demandeurs simultanés
		// obtenaient le même. Voir FKC_CodeAuto (1.631.0).
		self::ensureColonnes();
		/* L'année du numéro est celle de la pièce, pas du jour de saisie (1.726.0). */
		$dateDa = ( $d['date'] ?? '' ) ?: date( 'Y-m-d' );
		$anDa = class_exists( 'FKC_Numerotation' ) ? FKC_Numerotation::anneeDe( $dateDa ) : (int) date( 'Y' );
		$num = FKC_CodeAuto::suivant( 'inv_achats', 'DA-' . $anDa . '-', 'numero', 4 );
		FKC_DB::q( 'INSERT INTO inv_achats(numero,type,fournisseur_id,service_demandeur,statut,date,division_id,note,budget_ligne_id) VALUES(?,?,?,?,?,?,?,?,?)',
			array( $num, 'demande', ! empty( $d['fournisseur_id'] ) ? (int) $d['fournisseur_id'] : null,
				trim( (string) ( $d['service_demandeur'] ?? '' ) ) ?: null, 'demande', $dateDa,
				! empty( $d['division_id'] ) ? (int) $d['division_id'] : null, trim( (string) ( $d['note'] ?? '' ) ) ?: null,
				! empty( $d['budget_ligne_id'] ) ? (int) $d['budget_ligne_id'] : null ) );
		$id = (int) FKC_DB::conn()->lastInsertId();
		foreach ( (array) $lignes as $l ) {
			if ( empty( $l['designation'] ) && empty( $l['article_id'] ) ) { continue; }
			FKC_DB::q( 'INSERT INTO inv_achat_lignes(achat_id,article_id,designation,quantite,pu) VALUES(?,?,?,?,?)',
				array( $id, ! empty( $l['article_id'] ) ? (int) $l['article_id'] : null, trim( (string) ( $l['designation'] ?? '' ) ) ?: null,
					(float) ( $l['quantite'] ?? 0 ), (float) ( $l['pu'] ?? 0 ) ) );
		}
		self::recomputeTotal( $id );
		return $id;
	}
	public static function recomputeTotal( $id ) {
		$t = (float) FKC_DB::q( 'SELECT COALESCE(SUM(quantite*pu),0) FROM inv_achat_lignes WHERE achat_id=?', array( (int) $id ) )->fetchColumn();
		FKC_DB::q( 'UPDATE inv_achats SET total_ht=? WHERE id=?', array( $t, (int) $id ) );
	}
	/**
	 * Fait avancer une demande d'un cran dans son circuit d'approbation.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * DEUX VALIDATEURS SIMULTANÉS FAISAIENT SAUTER UN CRAN (1.651.0).
	 *
	 * L'ancienne version lisait le statut, calculait le suivant, puis
	 * écrivait — sans condition. Deux responsables qui cliquent au même
	 * instant lisaient tous deux « manager », écrivaient tous deux
	 * « finance »… ou, si l'un était une fraction de seconde en retard,
	 * poussaient la demande à « achat » sans que la finance l'ait jamais vue.
	 * Un circuit d'approbation qui saute une signature ne vaut rien.
	 *
	 * La bascule est désormais CONDITIONNELLE au statut lu : la base arbitre,
	 * le second appel ne touche aucune ligne et le dit. Même motif que
	 * FKC_BPE::reclamer() (1.620.0) et que la libération de parts (1.632.0).
	 *
	 * @return array{0:bool,1:string} succès, et message pour l'écran.
	 */
	public static function avancer( $id ) {
		self::ensureColonnes();
		$a = FKC_DB::q( 'SELECT * FROM inv_achats WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $a ) { return array( false, 'Demande introuvable.' ); }
		$next = self::suivant( $a['statut'] );
		if ( ! $next ) {
			return array( false, 'Cette demande est déjà au bout de son circuit (' . ( self::etapes()[ $a['statut'] ] ?? $a['statut'] ) . ').' );
		}

		$avert = '';
		/*
		 * « BUDGET DISPONIBLE ? » AU MOMENT OÙ L'ON S'ENGAGE.
		 *
		 * Le contrôle se fait au passage à « commande » et pas avant : une
		 * demande n'engage rien tant qu'elle peut être refusée. Il AVERTIT
		 * sans bloquer — un dépassement est une décision de gestion, pas une
		 * faute comptable (même arbitrage qu'en 1.627.0). Refuser la saisie
		 * ferait imputer la dépense sur une autre ligne pour contourner le
		 * blocage, et rendrait le budget illisible.
		 */
		if ( 'commande' === $next && ! empty( $a['budget_ligne_id'] ) && class_exists( 'FKC_BudgetConso' ) ) {
			$c = FKC_BudgetConso::controler( (int) $a['budget_ligne_id'], (float) $a['total_ht'] );
			if ( empty( $c['ok'] ) ) { $avert = ' ' . (string) $c['message']; }
		}

		$st = FKC_DB::q(
			'UPDATE inv_achats SET statut=?, valide_par=? WHERE id=? AND statut=?',
			array( $next, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null, (int) $id, (string) $a['statut'] )
		);
		if ( 1 !== $st->rowCount() ) {
			return array( false, 'Cette demande a été traitée entre-temps par quelqu\'un d\'autre — rechargez l\'écran.' );
		}

		// L'engagement budgétaire suit la commande, pas la demande.
		if ( ! empty( $a['budget_ligne_id'] ) && class_exists( 'FKC_BudgetConso' ) ) {
			FKC_BudgetConso::recalculerEngage( (int) $a['budget_ligne_id'] );
		}
		return array( true, 'Demande ' . $a['numero'] . ' : ' . ( self::etapes()[ $next ] ?? $next ) . '.' . $avert );
	}

	/** Colonnes ajoutées après coup sur les bases en service. */
	public static function ensureColonnes() {
		static $fait = false;
		if ( $fait ) { return; }
		$fait = true;
		try {
			$cols = array();
			foreach ( FKC_DB::q( 'PRAGMA table_info(inv_achats)' )->fetchAll() as $c ) { $cols[] = $c['name']; }
			if ( ! in_array( 'budget_ligne_id', $cols, true ) ) {
				FKC_DB::conn()->exec( 'ALTER TABLE inv_achats ADD COLUMN budget_ligne_id INTEGER' );
			}
		} catch ( \Throwable $e ) { /* le métier continue sans le pont budgétaire */ }
	}
	public static function annuler( $id ) {
		$b = self::ligneBudget( $id );
		FKC_DB::q( "UPDATE inv_achats SET statut='annule' WHERE id=?", array( (int) $id ) );
		// Une commande annulée cesse d'engager : sans ce recalcul, le budget
		// resterait consommé par une dépense qui n'aura jamais lieu.
		if ( $b && class_exists( 'FKC_BudgetConso' ) ) { FKC_BudgetConso::recalculerEngage( $b ); }
	}

	/**
	 * Solde une commande DÈS QU'ELLE EST ENTIÈREMENT REÇUE, et pas avant.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * UNE RÉCEPTION PARTIELLE SOLDAIT LA COMMANDE ENTIÈRE (1.651.0).
	 *
	 * `marquerRecu()` écrivait « recu » sans rien regarder. Un fournisseur qui
	 * livre la moitié de sa commande — le cas ordinaire — la faisait donc
	 * disparaître des en-cours : le reste à recevoir n'existait plus nulle
	 * part, personne ne relançait, et la marchandise manquante ne se
	 * remarquait qu'au moment d'en avoir besoin.
	 *
	 * On compare désormais ce qui a été COMMANDÉ à ce qui a été REÇU,
	 * article par article et sur TOUTES les réceptions de la commande. Tant
	 * qu'il reste quelque chose à venir, la commande reste « commandée » — et
	 * continue donc d'engager le budget, ce qui est exact : le fournisseur
	 * doit toujours cette marchandise.
	 */
	public static function marquerRecu( $id ) {
		$id = (int) $id;
		$b  = self::ligneBudget( $id );
		if ( self::resteARecevoir( $id ) > 0.0001 ) {
			if ( $b && class_exists( 'FKC_BudgetConso' ) ) { FKC_BudgetConso::recalculerEngage( $b ); }
			return false;
		}
		FKC_DB::q( "UPDATE inv_achats SET statut='recu' WHERE id=?", array( $id ) );
		if ( $b && class_exists( 'FKC_BudgetConso' ) ) { FKC_BudgetConso::recalculerEngage( $b ); }
		return true;
	}

	/**
	 * Quantité totale restant à recevoir sur une commande.
	 *
	 * Une commande sans ligne chiffrée rend 0 : on ne retient pas une
	 * commande en en-cours au prétexte qu'on ne sait pas ce qu'elle contient.
	 *
	 * @return float
	 */
	public static function resteARecevoir( $id ) {
		$id = (int) $id;
		try {
			$commande = (float) FKC_DB::q(
				'SELECT COALESCE(SUM(quantite),0) FROM inv_achat_lignes WHERE achat_id=?', array( $id )
			)->fetchColumn();
			if ( $commande <= 0 ) { return 0.0; }
			$recu = (float) FKC_DB::q(
				'SELECT COALESCE(SUM(l.qte_recue),0) FROM inv_reception_lignes l
				 JOIN inv_receptions r ON r.id = l.reception_id WHERE r.achat_id=?', array( $id )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
		return round( max( 0, $commande - $recu ), 4 );
	}

	/**
	 * Écart entre le commandé et le reçu, SIGNE COMPRIS.
	 *
	 * `resteARecevoir()` borne à zéro, et il a raison : ce qu'il rend sert à
	 * savoir si la commande reste ouverte, et une commande sur-livrée n'a
	 * plus rien à attendre. Mais ce `max(0, …)` MASQUE la sur-livraison —
	 * un fournisseur qui livre 120 pour 100 commandés rend simplement
	 * « 0 à recevoir », comme s'il avait livré juste.
	 *
	 * Cette méthode ne borne pas : négative, elle dit exactement de combien
	 * on a reçu en trop.
	 *
	 * @return float positif = reste dû, négatif = livré en trop.
	 */
	public static function ecartLivraison( $id ) {
		$id = (int) $id;
		try {
			$commande = (float) FKC_DB::q(
				'SELECT COALESCE(SUM(quantite),0) FROM inv_achat_lignes WHERE achat_id=?', array( $id )
			)->fetchColumn();
			if ( $commande <= 0 ) { return 0.0; }
			$recu = (float) FKC_DB::q(
				'SELECT COALESCE(SUM(l.qte_recue),0) FROM inv_reception_lignes l
				 JOIN inv_receptions r ON r.id = l.reception_id WHERE r.achat_id=?', array( $id )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
		return round( $commande - $recu, 4 );
	}

	/**
	 * Commandes livrées en plus grande quantité qu'elles n'en demandaient.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LE DERNIER MANQUE DES DEUX RECETTES DE BOUT EN BOUT
	 *
	 * Le contrôle budgétaire a lieu au passage à « commande » — le moment où
	 * l'on s'engage — et nulle part ailleurs. Une réception qui dépasse le
	 * montant commandé ne réveille donc rien : un fournisseur qui livre 120
	 * pour 100 consomme le budget de 20 unités que personne n'a approuvées,
	 * et le stock les accepte sans un mot.
	 *
	 * CE N'EST PAS UNE FAUTE DU MAGASINIER. La marchandise est arrivée, il
	 * l'a saisie ; c'est le fournisseur qui a livré en trop, ou la commande
	 * qui a été révisée sans être mise à jour. Le contrôle NOMME le cas pour
	 * qu'on tranche — retour, avoir, ou révision de la commande — au lieu de
	 * le laisser passer dans le budget.
	 *
	 * Il vaut zéro dans un dossier tenu, et se corrige de trois façons dont
	 * aucune ne relève du logiciel : c'est pour cela qu'il informe et ne
	 * bloque pas.
	 *
	 * @return array
	 */
	public static function surLivraisons( $limit = 50 ) {
		self::ensureColonnes();
		$limit = max( 1, min( 200, (int) $limit ) );
		try {
			$lignes = FKC_DB::q(
				"SELECT a.*, f.nom AS fournisseur FROM inv_achats a
				 LEFT JOIN fournisseurs f ON f.id = a.fournisseur_id
				 WHERE a.statut NOT IN('annule') AND EXISTS (
				     SELECT 1 FROM inv_receptions r WHERE r.achat_id = a.id
				 )
				 ORDER BY a.id DESC LIMIT " . ( $limit * 4 )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }

		$out = array();
		foreach ( $lignes as $l ) {
			$ecart = self::ecartLivraison( (int) $l['id'] );
			if ( $ecart >= -0.0001 ) { continue; }   // rien reçu en trop
			$l['excedent'] = round( -$ecart, 4 );
			$out[] = $l;
			if ( count( $out ) >= $limit ) { break; }
		}
		return $out;
	}

	/** Ligne budgétaire rattachée à une demande, ou null. */
	protected static function ligneBudget( $id ) {
		self::ensureColonnes();
		try {
			$v = FKC_DB::q( 'SELECT budget_ligne_id FROM inv_achats WHERE id=?', array( (int) $id ) )->fetchColumn();
		} catch ( \Throwable $e ) { return null; }
		return $v ? (int) $v : null;
	}

	/**
	 * Commandes engagées et jamais reçues au bout d'un délai.
	 *
	 * DU BUDGET IMMOBILISÉ POUR RIEN. Une commande passée il y a trois mois
	 * et jamais livrée continue d'engager sa ligne : le disponible affiché
	 * est plus bas que le disponible réel, et des dépenses légitimes se
	 * voient refusées au profit d'une marchandise qui n'arrivera pas.
	 *
	 * Le contrôle vaut zéro dans un service achats à jour, il nomme le
	 * fournisseur, et il se corrige de deux façons — relancer, ou annuler.
	 *
	 * @return array
	 */
	public static function commandesDormantes( $jours = 60, $limit = 50 ) {
		self::ensureColonnes();
		$limit = max( 1, min( 200, (int) $limit ) );
		$avant = date( 'Y-m-d', time() - max( 1, (int) $jours ) * 86400 );
		try {
			$lignes = FKC_DB::q(
				"SELECT a.*, f.nom AS fournisseur FROM inv_achats a
				 LEFT JOIN fournisseurs f ON f.id = a.fournisseur_id
				 WHERE a.statut='commande' AND a.date <= ?
				 ORDER BY a.date ASC LIMIT " . $limit,
				array( $avant )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		foreach ( $lignes as $i => $l ) { $lignes[ $i ]['reste'] = self::resteARecevoir( (int) $l['id'] ); }
		return $lignes;
	}
	public static function delete( $id ) {
		FKC_DB::q( 'DELETE FROM inv_achat_lignes WHERE achat_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM inv_achats WHERE id=?', array( (int) $id ) );
	}
}
