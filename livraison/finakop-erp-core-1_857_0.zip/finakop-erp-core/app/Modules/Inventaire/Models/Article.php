<?php
/** Articles & services (fiche article : général, classification, tarification, fiscalité, comptes). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvArticle {
	public static function types() { return array( 'produit'=>'Produit','service'=>'Service','consommable'=>'Consommable','immobilisation'=>'Immobilisation' ); }

	/** Comptes SYSCOHADA par défaut selon le type (modifiables sur la fiche). */
	public static function defaultComptes( $type ) {
		$d = array(
			'produit'        => array( 'stock'=>'311000', 'variation'=>'603100', 'achat'=>'601000', 'vente'=>'701100' ),
			'consommable'    => array( 'stock'=>'321000', 'variation'=>'603300', 'achat'=>'602000', 'vente'=>'' ),
			'service'        => array( 'stock'=>'', 'variation'=>'', 'achat'=>'604000', 'vente'=>'706100' ),
			'immobilisation' => array( 'stock'=>'', 'variation'=>'', 'achat'=>'241000', 'vente'=>'' ),
		);
		return $d[ $type ] ?? $d['produit'];
	}
	public static function gereStockType( $type ) { return in_array( $type, array( 'produit', 'consommable' ), true ); }

	public static function all( $actifOnly = false ) {
		$w = $actifOnly ? ' WHERE a.actif=1' : '';
		return FKC_DB::q( "SELECT a.*, c.libelle categorie,
			(SELECT COALESCE(SUM(quantite),0) FROM inv_stock s WHERE s.article_id=a.id) stock_total,
			(SELECT COALESCE(SUM(reserve),0) FROM inv_stock s WHERE s.article_id=a.id) reserve_total
			FROM inv_articles a LEFT JOIN inv_categories c ON c.id=a.categorie_id{$w} ORDER BY a.designation COLLATE NOCASE" )->fetchAll();
	}
	public static function find( $id ) { $r = FKC_DB::q( 'SELECT * FROM inv_articles WHERE id=?', array( (int) $id ) )->fetch(); return $r ?: null; }
	public static function codeExists( $code, $exceptId = 0 ) { return (bool) FKC_DB::q( 'SELECT 1 FROM inv_articles WHERE code=? AND id<>?', array( $code, (int) $exceptId ) )->fetch(); }

	/**
	 * Prochain code article disponible, façon « ART-00001 ».
	 *
	 * Un compteur persistant (table `parametres`) mémorise le plus haut numéro
	 * jamais attribué : après la suppression d'un article, son code n'est donc
	 * PAS réattribué à un nouveau produit — ce qui éviterait qu'un ancien
	 * document d'achat semble désigner le mauvais article. Le compteur est
	 * recalé sur le catalogue existant (utile après un import), et une boucle
	 * de garde vérifie la disponibilité réelle avant de rendre le code.
	 *
	 * @param string $prefixe Préfixe du code (défaut « ART- »).
	 * @return string
	 */
	public static function nextCode( $prefixe = 'ART-' ) {
		$prefixe = trim( (string) $prefixe ) ?: 'ART-';
		$cle = 'inv_code_seq_' . $prefixe;

		// Plus haut numéro présent dans le catalogue (récupère les imports).
		$max = 0;
		$rows = FKC_DB::q( 'SELECT code FROM inv_articles WHERE code LIKE ?', array( $prefixe . '%' ) )->fetchAll();
		foreach ( $rows as $r ) {
			$suffixe = substr( (string) $r['code'], strlen( $prefixe ) );
			// Uniquement les suffixes purement numériques : « ART-00042 » compte,
			// « ART-EAU » est ignoré (nomenclature libre de l'utilisateur).
			if ( '' !== $suffixe && ctype_digit( $suffixe ) ) {
				$max = max( $max, (int) $suffixe );
			}
		}
		// Repère haute-eau : ne redescend jamais, même après suppression.
		$seq = (int) FKC_DB::q( 'SELECT valeur FROM parametres WHERE cle=?', array( $cle ) )->fetchColumn();
		$max = max( $max, $seq );

		do {
			$max++;
			$code = $prefixe . str_pad( (string) $max, 5, '0', STR_PAD_LEFT );
		} while ( self::codeExists( $code ) && $max < 999999 );

		FKC_DB::q( 'INSERT INTO parametres(cle,valeur) VALUES(?,?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur',
			array( $cle, (string) $max ) );
		return $code;
	}

	protected static function cols() {
		return array( 'code','designation','description','type','categorie_id','unite','prix_achat','prix_vente','tva',
			'compte_stock','compte_variation','compte_achat','compte_vente','stock_min','stock_max','gere_stock','gere_lot','actif' );
	}
	protected static function vals( $d ) {
		$type = isset( self::types()[ $d['type'] ?? '' ] ) ? $d['type'] : 'produit';
		return array(
			// `code` et `designation` sont obligatoires côté écran, mais un
			// appelant programmatique peut les omettre : les lire sans `??`
			// émettait deux E_WARNING par article créé. Invisible en
			// production, où l'affichage des erreurs est coupé ; du bruit
			// permanent dans un journal, où il finit par masquer le signal.
			// Même famille que le correctif de FKC_Facture::save en 1.622.0.
			trim( (string) ( $d['code'] ?? '' ) ), trim( (string) ( $d['designation'] ?? '' ) ), trim( (string) ( $d['description'] ?? '' ) ) ?: null,
			$type, ! empty( $d['categorie_id'] ) ? (int) $d['categorie_id'] : null, trim( (string) ( $d['unite'] ?? 'U' ) ) ?: 'U',
			(float) ( $d['prix_achat'] ?? 0 ), (float) ( $d['prix_vente'] ?? 0 ), (float) ( $d['tva'] ?? 18 ),
			trim( (string) ( $d['compte_stock'] ?? '' ) ) ?: null, trim( (string) ( $d['compte_variation'] ?? '' ) ) ?: null,
			trim( (string) ( $d['compte_achat'] ?? '' ) ) ?: null, trim( (string) ( $d['compte_vente'] ?? '' ) ) ?: null,
			(float) ( $d['stock_min'] ?? 0 ), (float) ( $d['stock_max'] ?? 0 ),
			empty( $d['gere_stock'] ) ? 0 : 1, empty( $d['gere_lot'] ) ? 0 : 1, empty( $d['actif'] ) ? 0 : 1,
		);
	}
	public static function create( $d ) {
		$c = self::cols(); $ph = implode( ',', array_fill( 0, count( $c ), '?' ) );
		FKC_DB::q( 'INSERT INTO inv_articles(' . implode( ',', $c ) . ") VALUES({$ph})", self::vals( $d ) );
		return (int) FKC_DB::conn()->lastInsertId();
	}
	public static function update( $id, $d ) {
		$c = self::cols(); $set = implode( '=?,', $c ) . '=?';
		$v = self::vals( $d ); $v[] = (int) $id;
		FKC_DB::q( "UPDATE inv_articles SET {$set} WHERE id=?", $v );
	}
	public static function setCmp( $id, $cmp ) { FKC_DB::q( 'UPDATE inv_articles SET cmp=? WHERE id=?', array( (float) $cmp, (int) $id ) ); }
	/**
	 * Retire un article de l'Inventaire.
	 *
	 * La suppression sèche effaçait la fiche ET son stock, en laissant derrière
	 * elle les mouvements du journal et les écritures comptables qui la
	 * désignaient : le grand livre citait un article introuvable et la
	 * valorisation du stock devenait invérifiable. Un article qui a bougé est
	 * donc désormais DÉSACTIVÉ, jamais effacé ; seul un article vierge de toute
	 * histoire est réellement supprimé.
	 *
	 * @param int $id Article.
	 * @return array{0:bool,1:string,2:string} ok, message, action
	 */
	public static function delete( $id ) {
		$id = (int) $id;
		$compte = function ( $sql ) use ( $id ) {
			try { return (int) FKC_DB::q( $sql, array( $id ) )->fetchColumn(); } catch ( \Throwable $e ) { return 0; }
		};
		$raisons = array();
		$mv = $compte( 'SELECT COUNT(*) FROM inv_mouvements WHERE article_id=?' );
		if ( $mv ) { $raisons[] = $mv . ' mouvement(s) de stock'; }
		$st = 0.0;
		try { $st = (float) FKC_DB::q( 'SELECT COALESCE(SUM(quantite),0) FROM inv_stock WHERE article_id=?', array( $id ) )->fetchColumn(); } catch ( \Throwable $e ) {}
		if ( abs( $st ) > 0.00001 ) { $raisons[] = 'un stock de ' . fkc_money( $st ); }
		$li = $compte( "SELECT COUNT(*) FROM fkc_article_liens WHERE inv_article_id=?" );
		if ( $li ) { $raisons[] = $li . ' lien(s) avec un pack métier'; }

		if ( ! $raisons ) {
			try {
				FKC_Tx::executer( function () use ( $id ) {
					FKC_DB::q( 'DELETE FROM inv_stock WHERE article_id=?', array( $id ) );
					FKC_DB::q( 'DELETE FROM inv_articles WHERE id=?', array( $id ) );
				} );
				return array( true, 'Article supprimé : il n\'avait jamais servi.', 'supprime' );
			} catch ( \Throwable $e ) {
				return array( false, 'Suppression impossible : aucune modification n\'a été enregistrée.', 'aucune' );
			}
		}

		try {
			FKC_DB::q( 'UPDATE inv_articles SET actif=0 WHERE id=?', array( $id ) );
		} catch ( \Throwable $e ) {
			return array( false, 'Désactivation impossible.', 'aucune' );
		}
		return array( true, 'Article désactivé plutôt que supprimé : il porte ' . implode( ', ', $raisons )
			. '. L\'effacer rendrait le grand livre et la valorisation du stock incohérents.', 'archive' );
	}
}
