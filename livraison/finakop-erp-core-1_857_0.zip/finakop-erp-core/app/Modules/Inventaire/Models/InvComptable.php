<?php
/** Intégration comptable SYSCOHADA automatique (inventaire permanent : 31x ↔ 603). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvComptable {

	/** La comptabilisation automatique est-elle possible (module compta + classes présentes) ? */
	public static function possible() {
		return class_exists( 'FKC_Ecriture' ) && class_exists( 'FKC_Compte' ) && class_exists( 'FKC_Journal' )
			&& class_exists( 'FKC_License' ) && FKC_License::moduleEnabled( 'comptabilite' );
	}

	protected static function journalStock() {
		foreach ( FKC_Journal::all() as $j ) { if ( 'STK' === $j['code'] ) { return (int) $j['id']; } }
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		return 0;
	}
	protected static function compteId( $numero, $libelle ) {
		$numero = trim( (string) $numero );
		if ( '' === $numero ) { return 0; }
		$cpt = FKC_Compte::byNumero( $numero );
		if ( ! $cpt ) {
			FKC_Compte::create( str_pad( $numero, 6, '0' ), $libelle );
			$cpt = FKC_Compte::byNumero( $numero );
		}
		return $cpt ? (int) $cpt['id'] : 0;
	}

	/**
	 * Comptabilise un mouvement de stock.
	 * @param string $sens 'entree' (D stock / C variation) ou 'sortie' (D variation / C stock).
	 * @return int|null  ecriture_id (ou id brouillard), ou null si non comptabilisé.
	 */
	public static function comptabiliser( $sens, $article, $valeur, $date, $libelle, $divisionId = null ) {
		if ( ! self::possible() ) { return null; }
		$valeur = round( (float) $valeur, 0 );
		if ( $valeur <= 0 ) { return null; }
		$cStock = self::compteId( $article['compte_stock'] ?? '', 'Stock — ' . ( $article['designation'] ?? '' ) );
		$cVar   = self::compteId( $article['compte_variation'] ?? '', 'Variation de stocks' );
		if ( ! $cStock || ! $cVar ) { return null; }
		$journal = self::journalStock();
		if ( ! $journal ) { return null; }

		$lStock = array( 'compte_id' => $cStock, 'libelle' => $libelle, 'debit' => 0, 'credit' => 0, 'division_id' => $divisionId ? (int) $divisionId : null );
		$lVar   = array( 'compte_id' => $cVar,   'libelle' => $libelle, 'debit' => 0, 'credit' => 0, 'division_id' => $divisionId ? (int) $divisionId : null );
		if ( 'entree' === $sens ) { $lStock['debit'] = $valeur; $lVar['credit'] = $valeur; }
		else { $lVar['debit'] = $valeur; $lStock['credit'] = $valeur; }

		$entete = array(
			'journal_id' => $journal, 'date_ecriture' => $date,
			'piece' => 'STK-' . strtoupper( substr( $sens, 0, 3 ) ), 'libelle' => $libelle,
			'reference' => 'Inventaire', 'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
		);
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( $entete, array( $lStock, $lVar ), array( 'source' => 'inventaire' ) );
		if ( ! $ok ) { return null; }
		// Pont vers le bus d'événements : valorisation, alertes de stock et
		// packs (restaurant, pharmacie…) réagissent au mouvement comptabilisé.
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'stock_mouvement_comptabilise', array(
				'sens' => (string) $sens, 'article' => (string) ( $article['designation'] ?? '' ),
				'article_id' => isset( $article['id'] ) ? (int) $article['id'] : null,
				'valeur' => (float) $valeur, 'date' => (string) $date,
				'division_id' => $divisionId ? (int) $divisionId : null,
				'ecriture_id' => $eid ? (int) $eid : null, 'brouillon_id' => $bid ? (int) $bid : null,
			), array( 'poster' => false ) );
		}
		return $eid ?: $bid;
	}
}
