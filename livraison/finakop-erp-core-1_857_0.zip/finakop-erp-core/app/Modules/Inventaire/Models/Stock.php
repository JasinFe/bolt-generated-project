<?php
/** Niveaux de stock par article et entrepôt (disponible, réservé, min, max). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvStock {
	public static function row( $articleId, $entrepotId ) {
		$r = FKC_DB::q( 'SELECT * FROM inv_stock WHERE article_id=? AND entrepot_id=?', array( (int) $articleId, (int) $entrepotId ) )->fetch();
		if ( ! $r ) {
			FKC_DB::q( 'INSERT INTO inv_stock(article_id,entrepot_id,quantite,reserve) VALUES(?,?,0,0)', array( (int) $articleId, (int) $entrepotId ) );
			$r = FKC_DB::q( 'SELECT * FROM inv_stock WHERE article_id=? AND entrepot_id=?', array( (int) $articleId, (int) $entrepotId ) )->fetch();
		}
		return $r;
	}
	public static function quantite( $articleId, $entrepotId ) {
		return (float) FKC_DB::q( 'SELECT COALESCE(quantite,0) FROM inv_stock WHERE article_id=? AND entrepot_id=?', array( (int) $articleId, (int) $entrepotId ) )->fetchColumn();
	}
	public static function totalArticle( $articleId ) {
		return (float) FKC_DB::q( 'SELECT COALESCE(SUM(quantite),0) FROM inv_stock WHERE article_id=?', array( (int) $articleId ) )->fetchColumn();
	}
	public static function disponibleArticle( $articleId ) {
		$r = FKC_DB::q( 'SELECT COALESCE(SUM(quantite),0) q, COALESCE(SUM(reserve),0) r FROM inv_stock WHERE article_id=?', array( (int) $articleId ) )->fetch();
		return (float) $r['q'] - (float) $r['r'];
	}
	public static function parArticle( $articleId ) {
		return FKC_DB::q( 'SELECT s.*, e.libelle entrepot FROM inv_stock s JOIN inv_entrepots e ON e.id=s.entrepot_id WHERE s.article_id=? ORDER BY e.libelle', array( (int) $articleId ) )->fetchAll();
	}
	/** Applique une variation de quantité (peut être négative). */
	public static function adjust( $articleId, $entrepotId, $delta ) {
		self::row( $articleId, $entrepotId );
		FKC_DB::q( 'UPDATE inv_stock SET quantite=quantite+? WHERE article_id=? AND entrepot_id=?', array( (float) $delta, (int) $articleId, (int) $entrepotId ) );
	}
	public static function setQuantite( $articleId, $entrepotId, $q ) {
		self::row( $articleId, $entrepotId );
		FKC_DB::q( 'UPDATE inv_stock SET quantite=? WHERE article_id=? AND entrepot_id=?', array( (float) $q, (int) $articleId, (int) $entrepotId ) );
	}
	public static function addReserve( $articleId, $entrepotId, $delta ) {
		self::row( $articleId, $entrepotId );
		FKC_DB::q( 'UPDATE inv_stock SET reserve=MAX(0,reserve+?) WHERE article_id=? AND entrepot_id=?', array( (float) $delta, (int) $articleId, (int) $entrepotId ) );
	}
}
