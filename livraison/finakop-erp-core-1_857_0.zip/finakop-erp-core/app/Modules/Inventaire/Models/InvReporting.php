<?php
/** Reporting Inventaire : rotation, valeur, dormants, consommation, mouvements, prévisions. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvReporting {

	public static function valeurParCategorie() { return FKC_InvValorisation::parCategorie(); }

	/** Taux de rotation = sorties valorisées (N jours) / valeur moyenne du stock. */
	public static function rotation( $jours = 365 ) {
		$depuis = date( 'Y-m-d', strtotime( "-{$jours} days" ) );
		$sorties = (float) FKC_DB::q( "SELECT COALESCE(SUM(valeur),0) FROM inv_mouvements WHERE type='sortie' AND date_mouv>=?", array( $depuis ) )->fetchColumn();
		$valeur = FKC_InvValorisation::valeurStock();
		return $valeur > 0 ? round( $sorties / $valeur, 2 ) : 0.0;
	}

	/** Articles dormants : aucun mouvement de sortie depuis N jours, mais encore en stock. */
	public static function dormants( $jours = 90 ) {
		$depuis = date( 'Y-m-d', strtotime( "-{$jours} days" ) );
		return FKC_DB::q( "SELECT a.id, a.code, a.designation, a.cmp,
			(SELECT COALESCE(SUM(quantite),0) FROM inv_stock s WHERE s.article_id=a.id) total,
			(SELECT MAX(date_mouv) FROM inv_mouvements m WHERE m.article_id=a.id AND m.type='sortie') derniere_sortie
			FROM inv_articles a WHERE a.actif=1 AND a.gere_stock=1
			AND (SELECT COALESCE(SUM(quantite),0) FROM inv_stock s WHERE s.article_id=a.id) > 0
			AND NOT EXISTS (SELECT 1 FROM inv_mouvements m WHERE m.article_id=a.id AND m.type='sortie' AND m.date_mouv>=?)
			ORDER BY a.designation", array( $depuis ) )->fetchAll();
	}

	/** Consommation (sorties) valorisée par motif. */
	public static function consommationParMotif( $jours = 365 ) {
		$depuis = date( 'Y-m-d', strtotime( "-{$jours} days" ) );
		$rows = FKC_DB::q( "SELECT motif, COALESCE(SUM(valeur),0) val, COALESCE(SUM(quantite),0) qte FROM inv_mouvements
			WHERE type='sortie' AND date_mouv>=? GROUP BY motif ORDER BY val DESC", array( $depuis ) )->fetchAll();
		$o = array(); foreach ( $rows as $r ) { $o[ $r['motif'] ?: 'autre' ] = array( 'val'=>(float) $r['val'], 'qte'=>(float) $r['qte'] ); }
		return $o;
	}

	/** Statistiques de mouvements par type. */
	public static function mouvementsParType( $jours = 365 ) {
		$depuis = date( 'Y-m-d', strtotime( "-{$jours} days" ) );
		$rows = FKC_DB::q( "SELECT type, COUNT(*) n, COALESCE(SUM(valeur),0) val FROM inv_mouvements WHERE date_mouv>=? GROUP BY type", array( $depuis ) )->fetchAll();
		$o = array(); foreach ( $rows as $r ) { $o[ $r['type'] ] = array( 'n'=>(int) $r['n'], 'val'=>(float) $r['val'] ); }
		return $o;
	}

	/** Prévision simple : consommation mensuelle moyenne (sur 90 j) des articles les plus consommés. */
	public static function previsions( $limit = 10 ) {
		$depuis = date( 'Y-m-d', strtotime( '-90 days' ) );
		return FKC_DB::q( "SELECT a.code, a.designation, COALESCE(SUM(m.quantite),0)/3.0 conso_mois,
			(SELECT COALESCE(SUM(quantite-reserve),0) FROM inv_stock s WHERE s.article_id=a.id) dispo
			FROM inv_articles a JOIN inv_mouvements m ON m.article_id=a.id AND m.type='sortie' AND m.date_mouv>=?
			WHERE a.actif=1 GROUP BY a.id ORDER BY conso_mois DESC LIMIT ?", array( $depuis, (int) $limit ) )->fetchAll();
	}
}
