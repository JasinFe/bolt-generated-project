<?php
/** Réapprovisionnement & alertes intelligentes (rupture, critique, surstock, péremption). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvReappro {

	/** Articles gérés en stock avec leur disponible. */
	protected static function avecDispo( $extraWhere = '' ) {
		return FKC_DB::q( "SELECT * FROM (
			SELECT a.id, a.code, a.designation, a.stock_min, a.stock_max, a.cmp, a.unite,
				(SELECT COALESCE(SUM(quantite-reserve),0) FROM inv_stock s WHERE s.article_id=a.id) dispo,
				(SELECT COALESCE(SUM(quantite),0) FROM inv_stock s WHERE s.article_id=a.id) total
			FROM inv_articles a WHERE a.actif=1 AND a.gere_stock=1
		) t {$extraWhere}" )->fetchAll();
	}

	public static function suggestion( $dispo, $min, $max ) {
		$cible = $max > 0 ? $max : $min * 2;
		return max( 0, round( $cible - $dispo, 2 ) );
	}

	/** Articles sous le seuil minimum (réappro à déclencher). */
	public static function enAlerte() {
		$rows = self::avecDispo( 'WHERE stock_min > 0 AND dispo < stock_min ORDER BY (dispo - stock_min)' );
		foreach ( $rows as &$r ) { $r['suggestion'] = self::suggestion( (float) $r['dispo'], (float) $r['stock_min'], (float) $r['stock_max'] ); }
		return $rows;
	}
	public static function ruptures() { return self::avecDispo( 'WHERE dispo <= 0 ORDER BY designation' ); }
	public static function critiques() { return self::avecDispo( 'WHERE stock_min > 0 AND dispo > 0 AND dispo < stock_min ORDER BY designation' ); }
	public static function surstock() { return self::avecDispo( 'WHERE stock_max > 0 AND total > stock_max ORDER BY (total - stock_max) DESC' ); }

	public static function peremption( $jours = 30 ) {
		$limite = date( 'Y-m-d', strtotime( "+{$jours} days" ) );
		return FKC_DB::q( "SELECT l.*, a.code, a.designation FROM inv_lots l JOIN inv_articles a ON a.id=l.article_id
			WHERE l.date_peremption IS NOT NULL AND l.date_peremption<>'' AND l.date_peremption<=? AND l.quantite>0 ORDER BY l.date_peremption", array( $limite ) )->fetchAll();
	}
	public static function countRuptures() { return count( self::ruptures() ); }
	public static function countCritiques() { return count( self::critiques() ); }
}
