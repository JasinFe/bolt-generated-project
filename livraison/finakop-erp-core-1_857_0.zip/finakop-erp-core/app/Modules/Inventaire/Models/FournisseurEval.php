<?php
/** Évaluation fournisseurs : délais, prix, qualité. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InvFournisseurEval {
	public static function forFournisseur( $fid ) {
		return FKC_DB::q( 'SELECT * FROM inv_fournisseur_eval WHERE fournisseur_id=? ORDER BY date DESC', array( (int) $fid ) )->fetchAll();
	}
	public static function create( $d ) {
		FKC_DB::q( 'INSERT INTO inv_fournisseur_eval(fournisseur_id,date,note_delai,note_prix,note_qualite,commentaire) VALUES(?,?,?,?,?,?)',
			array( (int) $d['fournisseur_id'], $d['date'] ?? date( 'Y-m-d' ),
				(float) ( $d['note_delai'] ?? 0 ), (float) ( $d['note_prix'] ?? 0 ), (float) ( $d['note_qualite'] ?? 0 ),
				trim( (string) ( $d['commentaire'] ?? '' ) ) ?: null ) );
	}
	/** Note moyenne globale par fournisseur (sur 5). */
	public static function moyennes() {
		$rows = FKC_DB::q( 'SELECT fournisseur_id, AVG((note_delai+note_prix+note_qualite)/3.0) moy, COUNT(*) n FROM inv_fournisseur_eval GROUP BY fournisseur_id' )->fetchAll();
		$o = array(); foreach ( $rows as $r ) { $o[ (int) $r['fournisseur_id'] ] = array( 'moy'=>round( (float) $r['moy'], 1 ), 'n'=>(int) $r['n'] ); }
		return $o;
	}
	public static function delete( $id ) { FKC_DB::q( 'DELETE FROM inv_fournisseur_eval WHERE id=?', array( (int) $id ) ); }
}
