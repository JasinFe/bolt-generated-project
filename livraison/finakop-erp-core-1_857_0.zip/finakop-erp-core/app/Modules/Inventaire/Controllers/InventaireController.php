<?php
/** Module Inventaire : articles, stocks, achats, réceptions, mouvements, valorisation, réappro, reporting. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_InventaireController {

	/* ── Tableau de bord ── */
	public function index() {
		if ( ! $this->feature( 'inventaire.articles' ) ) { return; }
		FKC_View::render( 'inventaire::dashboard', array(
			'title' => 'Inventaire · Tableau de bord', 'tab' => 'dashboard',
			'd' => FKC_InvDashboard::compute(), 'alertes' => array_slice( FKC_InvReappro::enAlerte(), 0, 8 ),
			'recents' => FKC_InvMouvement::recents( 8 ), 'flash' => $this->flash(),
		) );
	}

	/* ── Articles & services ── */
	public function articles() {
		if ( ! $this->feature( 'inventaire.articles' ) ) { return; }
		FKC_View::render( 'inventaire::articles', array(
			'title' => 'Inventaire · Articles', 'tab' => 'articles',
			'articles' => FKC_InvArticle::all(), 'cats' => FKC_InvCategorie::map(), 'flash' => $this->flash(),
		) );
	}
	public function articleNew() { $this->articleForm( null ); }
	public function articleEdit( $id ) { $this->articleForm( FKC_InvArticle::find( $id ) ); }
	protected function articleForm( $a ) {
		if ( ! $this->feature( 'inventaire.articles' ) ) { return; }
		FKC_View::render( 'inventaire::article_form', array(
			'title' => 'Inventaire · ' . ( $a ? 'Modifier' : 'Nouvel article' ), 'tab' => 'articles', 'a' => $a,
			'cats' => FKC_InvCategorie::all(), 'types' => FKC_InvArticle::types(), 'defaults' => FKC_InvArticle::defaultComptes( $a['type'] ?? 'produit' ),
			'stockRows' => $a ? FKC_InvStock::parArticle( $a['id'] ) : array(),
			'mouvements' => $a ? FKC_InvMouvement::forArticle( $a['id'], 20 ) : array(),
			'valoOn' => FKC_Modules::featureEnabled( 'inventaire.valorisation' ),
			'fifo' => $a ? FKC_InvValorisation::fifoArticle( $a['id'] ) : 0, 'flash' => $this->flash(),
		) );
	}
	/**
	 * Réconcilie les catalogues Inventaire et Retail.
	 * N'écrase aucune valeur existante : apparie les couples et crée les
	 * articles manquants de chaque côté. Les stocks ne sont jamais touchés.
	 */
	public function articlesResync() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { redirect( 'inventaire' ); }
		if ( ! class_exists( 'FKC_ArticleBridge' ) || ! FKC_ArticleBridge::disponible() ) {
			$this->setFlash( 'Pont catalogue indisponible : le pack Retail n\'est pas actif sur cette société.' );
			redirect( 'inventaire/articles' );
		}
		$res = FKC_ArticleBridge::reconcilier();

		/*
		 * Compte rendu : les TOTAUX d'abord, le détail seulement pour ce qui a
		 * bougé.
		 *
		 * L'ancienne version énumérait les trois compteurs de chaque pack
		 * ponté, zéros compris. Sur une société multi-packs cela produisait un
		 * pavé de six lignes où rien ne se détachait, alors que l'information
		 * utile tient en une phrase : combien d'articles ont été créés, et où.
		 * Un pack sans changement n'apprend rien au lecteur.
		 */
		$tot = array( 'lies' => 0, 'crees_pack' => 0, 'crees_inventaire' => 0 );
		$details = array();
		foreach ( $res as $pack => $r ) {
			foreach ( $tot as $k => $_ ) { $tot[ $k ] += (int) $r[ $k ]; }
			if ( ! $r['lies'] && ! $r['crees_pack'] && ! $r['crees_inventaire'] ) { continue; }
			$d   = FKC_ArticleBridge::descripteur( $pack );
			$bouts = array();
			if ( $r['lies'] )             { $bouts[] = $r['lies'] . ' apparié' . ( $r['lies'] > 1 ? 's' : '' ); }
			if ( $r['crees_inventaire'] ) { $bouts[] = '+' . $r['crees_inventaire'] . ' ici'; }
			if ( $r['crees_pack'] )       { $bouts[] = '+' . $r['crees_pack'] . ' dans le pack'; }
			$details[] = ( $d ? $d['label_pack'] : $pack ) . ' (' . implode( ', ', $bouts ) . ')';
		}

		if ( ! $tot['lies'] && ! $tot['crees_pack'] && ! $tot['crees_inventaire'] ) {
			$this->setFlash( 'Catalogues déjà synchronisés — aucun changement.' );
			redirect( 'inventaire/articles' );
		}

		$phrase = array();
		if ( $tot['crees_inventaire'] ) { $phrase[] = $tot['crees_inventaire'] . ' article(s) ajouté(s) à l\'Inventaire'; }
		if ( $tot['crees_pack'] )       { $phrase[] = $tot['crees_pack'] . ' ajouté(s) aux catalogues métier'; }
		if ( $tot['lies'] )             { $phrase[] = $tot['lies'] . ' doublon(s) apparié(s)'; }

		// Au-delà de trois packs concernés, le détail redevient un pavé : on le
		// résume plutôt que de le tronquer au hasard.
		$suffixe = '';
		if ( $details && count( $details ) <= 3 ) {
			$suffixe = ' — ' . implode( ' · ', $details ) . '.';
		} elseif ( $details ) {
			$suffixe = ' — sur ' . count( $details ) . ' catalogues métier.';
		}

		$this->setFlash( 'Synchronisation terminée : ' . implode( ', ', $phrase ) . $suffixe
			. ' Les stocks n\'ont pas été modifiés.' );
		redirect( 'inventaire/articles' );
	}

	/** Active/désactive le masquage du module Inventaire quand un pack le couvre. */
	public function articlesMasquage() {
		if ( ! FKC_Auth::isAdmin() ) { redirect( 'inventaire/articles' ); }
		if ( ! class_exists( 'FKC_ArticleBridge' ) || ! FKC_ArticleBridge::disponible() ) { redirect( 'inventaire/articles' ); }
		$actif = ! FKC_ArticleBridge::inventaireMasque();
		FKC_ArticleBridge::basculerMasquage( $actif );
		$this->setFlash( $actif
			? 'Module Inventaire masqué du menu : le catalogue se pilote depuis le pack métier. Aucune donnée n\'est supprimée et la synchronisation continue. Pour le réafficher : Paramètres → Modules retirés du menu.'
			: 'Module Inventaire de nouveau visible dans le menu.' );
		redirect( $actif ? 'inventaire/articles' : 'inventaire/articles' );
	}

	public function articleSave( $id = 0 ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { redirect( 'inventaire' ); }
		$d = $_POST;
		$code = trim( (string) ( $d['code'] ?? '' ) );
		// Création avec code vide : on attribue une référence automatique plutôt
		// que de bloquer la saisie. En modification, on ne réécrit JAMAIS le code
		// existant (il peut être référencé par des documents d'achat).
		if ( '' === $code && ! $id ) {
			$code = FKC_InvArticle::nextCode();
			$d['code'] = $code;
		}
		if ( '' === $code || '' === trim( (string) ( $d['designation'] ?? '' ) ) ) { $this->setFlash( 'Code et désignation requis.' ); redirect( $id ? 'inventaire/articles/' . (int) $id . '/modifier' : 'inventaire/articles/nouveau' ); }
		if ( FKC_InvArticle::codeExists( $code, (int) $id ) ) { $this->setFlash( 'Ce code article existe déjà.' ); redirect( $id ? 'inventaire/articles/' . (int) $id . '/modifier' : 'inventaire/articles/nouveau' ); }
		if ( $id ) { FKC_InvArticle::update( $id, $d ); $this->setFlash( 'Article mis à jour.' ); }
		else { $id = FKC_InvArticle::create( $d ); $this->setFlash( 'Article créé.' ); }
		// Pont catalogue : réplique l'identité de l'article vers le pack Retail
		// (jamais les quantités de stock — voir FKC_ArticleBridge).
		if ( $id && class_exists( 'FKC_ArticleBridge' ) ) { FKC_ArticleBridge::versTousLesPacks( (int) $id ); }

		// Moteur d'Identification : enregistre les conditionnements saisis en même
		// temps que le produit (Option A : tout sur une page, avant Créer).
		if ( class_exists( 'FKC_Scan' ) ) {
			$art = FKC_InvArticle::find( $id );
			$lib = $art['designation'] ?? '';

			// Nouvelles lignes de conditionnement : tableaux parallèles cond_*.
			$codes   = (array) ( $d['cond_code'] ?? array() );
			$niveaux = (array) ( $d['cond_niveau'] ?? array() );
			$facts   = (array) ( $d['cond_facteur'] ?? array() );
			$desigs  = (array) ( $d['cond_designation'] ?? array() );
			$nb = max( count( $codes ), count( $niveaux ) );
			for ( $i = 0; $i < $nb; $i++ ) {
				$cCode = trim( (string) ( $codes[ $i ] ?? '' ) );
				if ( '' === $cCode ) { continue; } // ligne sans code = ignorée
				$niveau = in_array( $niveaux[ $i ] ?? 'unite', array( 'unite', 'pack', 'carton', 'palette' ), true ) ? ( $niveaux[ $i ] ?? 'unite' ) : 'unite';
				$fact = ( 'unite' === $niveau ) ? 1.0 : max( 2.0, (float) ( $facts[ $i ] ?? 0 ) );
				$desig = trim( (string) ( $desigs[ $i ] ?? '' ) );
				// Liaison sûre : ignore silencieusement un conflit (le produit est déjà créé).
				FKC_Scan::lier( array(
					'code' => $cCode, 'entite_type' => 'article', 'entite_id' => (int) $id,
					'module' => 'inventaire', 'unite' => $niveau, 'facteur' => $fact, 'libelle' => $lib,
					'meta' => $desig !== '' ? array( 'designation' => $desig ) : null,
				), false );
			}

			// Rétrocompat : anciens champs simples s'ils sont encore présents.
			$cb = trim( (string) ( $d['code_barre'] ?? '' ) );
			if ( '' !== $cb ) {
				// 1.811.0 : lier() et non enregistrer() — enregistrer() réaffectait
				// sans contrôle un code appartenant déjà à un AUTRE article.
				FKC_Scan::lier( array( 'code' => $cb, 'entite_type' => 'article', 'entite_id' => (int) $id, 'module' => 'inventaire', 'libelle' => $lib, 'unite' => 'unite', 'facteur' => 1 ), false );
			}
			$cbCarton = trim( (string) ( $d['code_barre_carton'] ?? '' ) );
			$parCarton = (float) ( $d['unites_par_carton'] ?? 0 );
			if ( '' !== $cbCarton && $parCarton > 1 ) {
				FKC_Scan::lier( array( 'code' => $cbCarton, 'entite_type' => 'article', 'entite_id' => (int) $id, 'module' => 'inventaire', 'libelle' => $lib, 'unite' => 'carton', 'facteur' => $parCarton ), false );
			}
		}
		redirect( 'inventaire/articles/' . (int) $id . '/modifier' );
	}
	public function articleDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { redirect( 'inventaire' ); }
		list( $okDel, $msgDel ) = FKC_InvArticle::delete( $id ); $this->setFlash( $msgDel );
		redirect( 'inventaire/articles' );
	}

	/* ── Conditionnements / codes-barres multi-niveaux d'un article ── */

	protected function codeJson( $payload ) {
		if ( ! headers_sent() ) { header( 'Content-Type: application/json; charset=utf-8' ); }
		echo json_encode( $payload, JSON_UNESCAPED_UNICODE ); exit;
	}

	/** Liste les codes-barres (unité, pack, carton, palette) d'un article. */
	public function articleCodes( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { return $this->codeJson( array( 'ok' => false ) ); }
		$this->codeJson( array( 'ok' => true, 'codes' => class_exists( 'FKC_Scan' ) ? FKC_Scan::codesDe( 'article', (int) $id ) : array() ) );
	}

	/** Ajoute/lie un code-barres à un article, avec contrôle d'unicité. */
	public function articleCodeAdd( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { return $this->codeJson( array( 'ok' => false, 'message' => 'Non autorisé.' ) ); }
		$art = FKC_InvArticle::find( (int) $id );
		if ( ! $art ) { return $this->codeJson( array( 'ok' => false, 'message' => 'Article introuvable.' ) ); }
		$designation = trim( (string) ( $_POST['designation'] ?? '' ) );
		$res = FKC_Scan::lier( array(
			'code' => (string) ( $_POST['code'] ?? '' ),
			'entite_type' => 'article', 'entite_id' => (int) $id, 'module' => 'inventaire',
			'unite' => (string) ( $_POST['unite'] ?? 'unite' ),
			'facteur' => (float) ( $_POST['facteur'] ?? 1 ),
			'libelle' => $art['designation'] ?? '',
			'meta' => $designation !== '' ? array( 'designation' => $designation ) : null,
		), ! empty( $_POST['force'] ) );
		$this->codeJson( $res );
	}

	/** Détache un code-barres d'un article. */
	public function articleCodeDel( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { return $this->codeJson( array( 'ok' => false ) ); }
		$code = (string) ( $_POST['code'] ?? '' );
		$unite = (string) ( $_POST['unite'] ?? 'unite' );
		if ( '' !== trim( $code ) ) { FKC_Scan::retirer( $code, $unite, true ); }
		$this->codeJson( array( 'ok' => true ) );
	}

	/* ── Catégories ── */
	public function categories() {
		if ( ! $this->feature( 'inventaire.articles' ) ) { return; }
		FKC_View::render( 'inventaire::categories', array(
			'title' => 'Inventaire · Catégories', 'tab' => 'categories',
			'cats' => FKC_InvCategorie::all(), 'flash' => $this->flash(),
		) );
	}
	public function categorieStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { redirect( 'inventaire' ); }
		/*
		 * Le code n'est plus exigé : le modèle l'attribue quand le champ est
		 * vide. Refuser la création pour un identifiant que l'application sait
		 * fabriquer faisait perdre la saisie déjà faite, sans rien protéger.
		 * Le libellé, lui, reste obligatoire — personne ne peut le deviner.
		 */
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		if ( '' === trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { $this->setFlash( 'Le libellé de la catégorie est requis.' ); }
		elseif ( '' !== $code && FKC_InvCategorie::codeExists( $code ) ) { $this->setFlash( 'Ce code existe déjà.' ); }
		else {
			$_POST['actif'] = 1;
			FKC_InvCategorie::create( $_POST );
			$this->setFlash( 'Catégorie créée.' . ( '' === $code ? ' Code attribué automatiquement.' : '' ) );
		}
		redirect( 'inventaire/categories' );
	}
	public function categorieDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.articles' ) ) { redirect( 'inventaire' ); }
		FKC_InvCategorie::delete( $id ); $this->setFlash( 'Catégorie supprimée.' );
		redirect( 'inventaire/categories' );
	}

	/* ── Entrepôts & emplacements ── */
	public function entrepots() {
		if ( ! $this->feature( 'inventaire.entrepots' ) ) { return; }
		$emplacements = array();
		foreach ( FKC_InvEntrepot::all() as $e ) { $emplacements[ (int) $e['id'] ] = FKC_InvEntrepot::arbre( $e['id'] ); } // 1.818.0 : arbre
		FKC_View::render( 'inventaire::entrepots', array(
			'title' => 'Inventaire · Entrepôts', 'tab' => 'entrepots',
			'entrepots' => FKC_InvEntrepot::all(), 'emplacements' => $emplacements,
			'multi' => FKC_Modules::featureEnabled( 'inventaire.multi_entrepots' ), 'nb' => FKC_InvEntrepot::count(), 'flash' => $this->flash(),
		) );
	}
	public function entrepotStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.entrepots' ) ) { redirect( 'inventaire' ); }
		$code = strtoupper( trim( (string) ( $_POST['code'] ?? '' ) ) );
		// Multi-entrepôts réservé à Enterprise : au-delà du 1er entrepôt, exiger la fonction.
		if ( FKC_InvEntrepot::count() >= 1 && ! FKC_Modules::featureEnabled( 'inventaire.multi_entrepots' ) ) {
			$this->setFlash( 'Le multi-entrepôts nécessite l\'édition Enterprise.' ); redirect( 'inventaire/entrepots' );
		}
		// Même règle que pour les catégories : le libellé est indispensable, le
		// code est attribué s'il manque.
		if ( '' === trim( (string) ( $_POST['libelle'] ?? '' ) ) ) { $this->setFlash( 'Le libellé de l\'entrepôt est requis.' ); }
		elseif ( '' !== $code && FKC_InvEntrepot::codeExists( $code ) ) { $this->setFlash( 'Ce code existe déjà.' ); }
		elseif ( ! FKC_License::within( 'entrepots', FKC_InvEntrepot::count() ) ) { $this->setFlash( FKC_License::quotaMessage( 'entrepots', 'entrepôt(s)' ) ); }
		else {
			$_POST['actif'] = 1;
			FKC_InvEntrepot::create( $_POST );
			$this->setFlash( 'Entrepôt créé.' . ( '' === $code ? ' Code attribué automatiquement.' : '' ) );
		}
		redirect( 'inventaire/entrepots' );
	}
	public function entrepotDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.entrepots' ) ) { redirect( 'inventaire' ); }
		FKC_InvEntrepot::delete( $id ); $this->setFlash( 'Entrepôt supprimé.' );
		redirect( 'inventaire/entrepots' );
	}
	public function emplacementStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.entrepots' ) ) { redirect( 'inventaire' ); }
		list( , $msg ) = FKC_InvEntrepot::addEmplacement( $_POST );
		$this->setFlash( $msg );
		redirect( 'inventaire/entrepots' );
	}
	public function emplacementDelete( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.entrepots' ) ) { redirect( 'inventaire' ); }
		list( , $msg ) = FKC_InvEntrepot::deleteEmplacement( $id );
		$this->setFlash( $msg );
		redirect( 'inventaire/entrepots' );
	}

	/* ── Stocks ── */
	public function stocks() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		FKC_View::render( 'inventaire::stocks', array(
			'title' => 'Inventaire · Stocks', 'tab' => 'stocks',
			'articles' => FKC_InvArticle::all( true ), 'flash' => $this->flash(),
		) );
	}

	/* ── Sorties ── */
	public function sorties() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		FKC_View::render( 'inventaire::sorties', array(
			'title' => 'Inventaire · Sorties', 'tab' => 'sorties',
			'articles' => FKC_InvArticle::all( true ), 'entrepots' => FKC_InvEntrepot::all( true ),
			'motifs' => FKC_InvMouvement::motifsSortie(), 'divisions' => $this->divisions(), 'anaOn' => $this->anaOn(),
			'recents' => $this->mouvementsType( 'sortie', 30 ), 'flash' => $this->flash(),
		) );
	}
	public function sortieStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.stocks' ) ) { redirect( 'inventaire' ); }
		$art = (int) ( $_POST['article_id'] ?? 0 ); $ent = (int) ( $_POST['entrepot_id'] ?? 0 ); $qte = (float) ( $_POST['quantite'] ?? 0 );
		if ( ! $art || ! $ent || $qte <= 0 ) { $this->setFlash( 'Article, entrepôt et quantité requis.' ); }
		else {
			FKC_InvMouvement::sortie( $art, $ent, $qte, array( 'motif' => $_POST['motif'] ?? 'consommation', 'division_id' => $this->anaOn() ? ( $_POST['division_id'] ?? null ) : null, 'date' => $_POST['date'] ?? date( 'Y-m-d' ) ) );
			$this->setFlash( 'Sortie enregistrée et comptabilisée.' );
		}
		redirect( 'inventaire/sorties' );
	}

	/* ── Transferts ── */
	public function transferts() {
		if ( ! $this->feature( 'inventaire.entrepots' ) ) { return; }
		FKC_View::render( 'inventaire::transferts', array(
			'title' => 'Inventaire · Transferts', 'tab' => 'transferts',
			'articles' => FKC_InvArticle::all( true ), 'entrepots' => FKC_InvEntrepot::all( true ),
			'recents' => $this->mouvementsType( 'transfert_out', 30 ), 'flash' => $this->flash(),
		) );
	}
	public function transfertStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.entrepots' ) ) { redirect( 'inventaire' ); }
		$art = (int) ( $_POST['article_id'] ?? 0 ); $from = (int) ( $_POST['from_id'] ?? 0 ); $to = (int) ( $_POST['to_id'] ?? 0 ); $qte = (float) ( $_POST['quantite'] ?? 0 );
		if ( ! $art || ! $from || ! $to || $from === $to || $qte <= 0 ) { $this->setFlash( 'Vérifiez article, entrepôts (distincts) et quantité.' ); }
		else { FKC_InvMouvement::transfert( $art, $from, $to, $qte, array( 'date' => $_POST['date'] ?? date( 'Y-m-d' ) ) ); $this->setFlash( 'Transfert effectué.' ); }
		redirect( 'inventaire/transferts' );
	}

	/* ── Inventaires physiques (ajustements) ── */
	public function inventaires() {
		if ( ! $this->feature( 'inventaire.entrepots' ) ) { return; }
		$ent = (int) ( $_GET['e'] ?? 0 );
		$lignes = array();
		if ( $ent ) {
			foreach ( FKC_InvArticle::all( true ) as $a ) {
				if ( empty( $a['gere_stock'] ) ) { continue; }
				$theo = FKC_InvStock::quantite( $a['id'], $ent );
				$lignes[] = array(
					'id' => $a['id'], 'code' => $a['code'], 'designation' => $a['designation'],
					'theo' => $theo, 'cmp' => $a['cmp'],
					// Champs attendus par le priorisateur.
					'ref' => $a['code'], 'stock' => $theo, 'cout_unitaire' => (float) $a['cmp'],
				);
			}
			/*
			 * Ordre de comptage, non alphabétique.
			 *
			 * « Tournant » veut dire qu'on ne compte pas tout, tout le temps :
			 * on compte souvent ce qui est cher et tourne vite. Présenter la
			 * liste par ordre alphabétique revient à consacrer autant
			 * d'attention au sel qu'au whisky — et, en pratique, à ce que la
			 * fin de liste ne soit jamais comptée.
			 */
			if ( class_exists( 'FKC_InventaireTournant' ) && $lignes ) {
				$lignes = FKC_InventaireTournant::prioriser( $lignes, count( $lignes ) );
			}
		}
		FKC_View::render( 'inventaire::inventaires', array(
			'title' => 'Inventaire · Inventaire physique', 'tab' => 'inventaires',
			'entrepots' => FKC_InvEntrepot::all( true ), 'ent' => $ent, 'lignes' => $lignes, 'flash' => $this->flash(),
		) );
	}
	public function inventaireStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.entrepots' ) ) { redirect( 'inventaire' ); }
		$ent = (int) ( $_POST['entrepot_id'] ?? 0 );
		$reels = (array) ( $_POST['reel'] ?? array() );
		$n = 0;
		foreach ( $reels as $artId => $val ) {
			if ( '' === trim( (string) $val ) ) { continue; }
			$mid = FKC_InvMouvement::ajustement( (int) $artId, $ent, (float) $val, array( 'date' => $_POST['date'] ?? date( 'Y-m-d' ) ) );
			if ( $mid ) { $n++; }
		}
		$this->setFlash( $n . ' écart(s) d\'inventaire ajusté(s) et comptabilisé(s).' );
		redirect( 'inventaire/inventaires?e=' . $ent );
	}

	/* ── Achats ── */
	public function achats() {
		if ( ! $this->feature( 'inventaire.achats' ) ) { return; }
		$sel = isset( $_GET['a'] ) ? FKC_InvAchat::find( (int) $_GET['a'] ) : null;
		FKC_View::render( 'inventaire::achats', array(
			'title' => 'Inventaire · Achats', 'tab' => 'achats',
			'achats' => FKC_InvAchat::all(), 'sel' => $sel, 'etapes' => FKC_InvAchat::etapes(),
			'fournisseurs' => $this->fournisseursList(), 'articles' => FKC_InvArticle::all( true ), 'flash' => $this->flash(),
		) );
	}
	public function achatStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.achats' ) ) { redirect( 'inventaire' ); }
		$lignes = array();
		$desigs = (array) ( $_POST['l_designation'] ?? array() ); $arts = (array) ( $_POST['l_article'] ?? array() );
		$qtes = (array) ( $_POST['l_qte'] ?? array() ); $pus = (array) ( $_POST['l_pu'] ?? array() );
		foreach ( $qtes as $i => $q ) {
			if ( (float) $q <= 0 ) { continue; }
			$lignes[] = array( 'article_id' => $arts[ $i ] ?? null, 'designation' => $desigs[ $i ] ?? '', 'quantite' => $q, 'pu' => $pus[ $i ] ?? 0 );
		}
		if ( ! $lignes ) { $this->setFlash( 'Ajoutez au moins une ligne.' ); redirect( 'inventaire/achats' ); }
		$id = FKC_InvAchat::create( $_POST, $lignes );
		$this->setFlash( 'Demande d\'achat créée.' );
		redirect( 'inventaire/achats?a=' . $id );
	}
	public function achatAction( $id ) {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.achats' ) ) { redirect( 'inventaire' ); }
		$a = $_POST['action'] ?? '';
		if ( 'avancer' === $a ) {
			// Le message vient désormais du modèle : il porte l'étape atteinte
			// et, au passage à « commande », l'avertissement budgétaire. Un
			// « étape validée » invariable disait la même chose qu'on ait
			// avancé, dépassé le budget, ou été devancé par un collègue.
			list( $ok, $msg ) = FKC_InvAchat::avancer( $id );
			$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		}
		elseif ( 'annuler' === $a ) { FKC_InvAchat::annuler( $id ); $this->setFlash( 'Demande annulée.' ); }
		elseif ( 'supprimer' === $a ) { FKC_InvAchat::delete( $id ); $this->setFlash( 'Supprimé.' ); redirect( 'inventaire/achats' ); }
		redirect( 'inventaire/achats?a=' . (int) $id );
	}

	/* ── Réceptions ── */
	public function receptions() {
		if ( ! $this->feature( 'inventaire.achats' ) ) { return; }
		$achat = isset( $_GET['a'] ) ? FKC_InvAchat::find( (int) $_GET['a'] ) : null;
		FKC_View::render( 'inventaire::receptions', array(
			'title' => 'Inventaire · Réceptions', 'tab' => 'receptions',
			'receptions' => FKC_InvReception::all(), 'entrepots' => FKC_InvEntrepot::all( true ),
			'articles' => FKC_InvArticle::all( true ), 'commandes' => FKC_InvAchat::all(),
			'achat' => $achat, 'divisions' => $this->divisions(), 'anaOn' => $this->anaOn(), 'flash' => $this->flash(),
		) );
	}
	public function receptionStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.achats' ) ) { redirect( 'inventaire' ); }
		$ent = (int) ( $_POST['entrepot_id'] ?? 0 );
		if ( ! $ent ) { $this->setFlash( 'Entrepôt requis.' ); redirect( 'inventaire/receptions' ); }
		$lignes = array();
		$arts = (array) ( $_POST['l_article'] ?? array() ); $cmd = (array) ( $_POST['l_cmd'] ?? array() );
		$rec = (array) ( $_POST['l_recu'] ?? array() ); $pus = (array) ( $_POST['l_pu'] ?? array() );
		// Lot, péremption et série accompagnent désormais la ligne : le carton
		// les porte sur son code, il n'y a plus de raison de les perdre.
		$lots = (array) ( $_POST['l_lot'] ?? array() );
		$pers = (array) ( $_POST['l_peremption'] ?? array() );
		$sers = (array) ( $_POST['l_serie'] ?? array() );
		foreach ( $arts as $i => $aid ) {
			if ( ! (int) $aid || (float) ( $rec[ $i ] ?? 0 ) <= 0 ) { continue; }
			$lignes[] = array(
				'article_id' => $aid, 'qte_commandee' => $cmd[ $i ] ?? 0,
				'qte_recue' => $rec[ $i ], 'pu' => $pus[ $i ] ?? 0,
				'lot' => $lots[ $i ] ?? '', 'peremption' => $pers[ $i ] ?? '', 'serie' => $sers[ $i ] ?? '',
			);
		}
		if ( ! $lignes ) { $this->setFlash( 'Aucune ligne reçue.' ); redirect( 'inventaire/receptions' ); }
		FKC_InvReception::enregistrer( $ent, $_POST['date'] ?? date( 'Y-m-d' ), $lignes, array(
			'achat_id' => $_POST['achat_id'] ?? null, 'division_id' => $this->anaOn() ? ( $_POST['division_id'] ?? null ) : null, 'note' => $_POST['note'] ?? '',
		) );
		$this->setFlash( 'Réception enregistrée : stock et comptabilité mis à jour.' );
		redirect( 'inventaire/receptions' );
	}

	/* ── Fournisseurs (évaluation) ── */
	public function fournisseurs() {
		if ( ! $this->feature( 'inventaire.achats' ) ) { return; }
		FKC_View::render( 'inventaire::fournisseurs', array(
			'title' => 'Inventaire · Fournisseurs', 'tab' => 'fournisseurs',
			'fournisseurs' => $this->fournisseursList(), 'moyennes' => FKC_InvFournisseurEval::moyennes(), 'flash' => $this->flash(),
		) );
	}
	public function fournisseurEvalStore() {
		if ( ! FKC_Modules::featureEnabled( 'inventaire.achats' ) ) { redirect( 'inventaire' ); }
		if ( ! empty( $_POST['fournisseur_id'] ) ) { FKC_InvFournisseurEval::create( $_POST ); $this->setFlash( 'Évaluation enregistrée.' ); }
		redirect( 'inventaire/fournisseurs' );
	}

	/* ── Réapprovisionnement & alertes ── */
	public function reappro() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		FKC_View::render( 'inventaire::reappro', array(
			'title' => 'Inventaire · Réapprovisionnement', 'tab' => 'reappro',
			'alertes' => FKC_InvReappro::enAlerte(), 'ruptures' => FKC_InvReappro::ruptures(),
			'surstock' => FKC_InvReappro::surstock(),
			'peremption' => FKC_Modules::featureEnabled( 'inventaire.lots' ) ? FKC_InvReappro::peremption( 30 ) : array(),
			'lotsOn' => FKC_Modules::featureEnabled( 'inventaire.lots' ), 'flash' => $this->flash(),
			// Nombre de demandes d'achat déjà ouvertes : sans lui, l'utilisateur
			// relancerait le réapprovisionnement sans savoir qu'il l'a déjà fait.
			'demandesOuvertes' => class_exists( 'FKC_SupplyChain' )
				? (int) ( FKC_SupplyChain::compteurs()['a_valider'] ?? 0 ) : null,
		) );
	}

	/**
	 * Crée les demandes d'achat pour les articles sous leur seuil.
	 *
	 * L'action part de l'écran où le manque est constaté : demander un
	 * réapprovisionnement depuis un autre module obligerait à recopier la liste
	 * qu'on a sous les yeux.
	 */
	public function reapproDemander() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		$r = FKC_ReglesStock::reapprovisionner();
		$this->setFlash( $r['demandes'] > 0
			? $r['demandes'] . ' demande(s) d\'achat créée(s) sur ' . $r['examines'] . ' article(s) sous leur seuil.'
			: 'Aucun article sous son seuil : rien à demander.' );
		redirect( 'inventaire/reappro' );
	}

	/* ── Approvisionnement prévisionnel ── */

	/**
	 * L'écran qui montre le manque AVANT qu'il n'arrive.
	 *
	 * Volontairement séparé de « Réappro. & alertes » : celui-ci répond à
	 * « qu'est-ce qui manque ? », celui-là à « qu'est-ce qui va manquer, et
	 * quand ? ». Les fondre donnerait un tableau où l'urgence constatée et
	 * l'urgence projetée se mélangeraient, et où l'on ne saurait plus si une
	 * ligne appelle une commande aujourd'hui ou une surveillance.
	 */
	public function previsionnel() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		if ( ! class_exists( 'FKC_ApproPrevisionnel' ) ) { redirect( 'inventaire/reappro' ); }

		// Réglages ajustables à la volée : un gérant doit pouvoir voir l'effet
		// d'une couverture de 7 jours plutôt que 14 sans ouvrir les paramètres.
		$o = array();
		if ( isset( $_GET['couverture'] ) ) { $o['couverture'] = (int) $_GET['couverture']; }
		if ( isset( $_GET['delai'] ) && '' !== $_GET['delai'] ) { $o['delai'] = max( 0, (int) $_GET['delai'] ); }

		$eval = FKC_ApproPrevisionnel::evaluer( $o );
		FKC_View::render( 'inventaire::previsionnel', array(
			'title' => 'Inventaire · Approvisionnement prévisionnel', 'tab' => 'previsionnel',
			'eval' => $eval, 'opts' => $eval['options'],
			'regleActive' => FKC_ReglesStock::active( 'reappro_prevision' ),
			'demandesOuvertes' => class_exists( 'FKC_SupplyChain' )
				? (int) ( FKC_SupplyChain::compteurs()['a_valider'] ?? 0 ) : null,
			'flash' => $this->flash(),
		) );
	}

	/** Transforme les projections en demandes d'achat (origine « prévision »). */
	public function previsionnelDemander() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		if ( ! class_exists( 'FKC_ApproPrevisionnel' ) ) { redirect( 'inventaire/reappro' ); }

		$o = array();
		if ( isset( $_POST['couverture'] ) ) { $o['couverture'] = (int) $_POST['couverture']; }
		$r = FKC_ApproPrevisionnel::declencher( $o );

		$this->setFlash( $r['demandes'] > 0
			? $r['demandes'] . ' demande(s) d\'achat anticipée(s) créée(s) sur ' . $r['examines']
				. ' article(s) dont la rupture est projetée avant livraison — environ '
				. fkc_money( $r['valeur'] ) . ' F, à valider par le service achats.'
			: 'Aucune commande à anticiper : les stocks tiennent jusqu\'à la prochaine livraison.' );
		redirect( 'inventaire/previsionnel' );
	}

	/* ── Valorisation ── */
	public function valorisation() {
		if ( ! $this->feature( 'inventaire.valorisation' ) ) { return; }
		$rows = array();
		foreach ( FKC_InvArticle::all( true ) as $a ) {
			if ( empty( $a['gere_stock'] ) ) { continue; }
			$tot = FKC_InvStock::totalArticle( $a['id'] );
			$rows[] = array( 'code' => $a['code'], 'designation' => $a['designation'], 'qte' => $tot, 'cmp' => (float) $a['cmp'],
				'val_cmp' => round( $tot * (float) $a['cmp'], 0 ), 'val_fifo' => FKC_InvValorisation::fifoArticle( $a['id'] ) );
		}
		FKC_View::render( 'inventaire::valorisation', array(
			'title' => 'Inventaire · Valorisation', 'tab' => 'valorisation',
			'methode' => FKC_InvValorisation::methode(), 'rows' => $rows,
			'total_cmp' => FKC_InvValorisation::valeurStock(), 'parCat' => FKC_InvValorisation::parCategorie(), 'flash' => $this->flash(),
		) );
	}

	/* ── Reporting ── */
	public function reporting() {
		if ( ! $this->feature( 'inventaire.stocks' ) ) { return; }
		FKC_View::render( 'inventaire::reporting', array(
			'title' => 'Inventaire · Reporting', 'tab' => 'reporting',
			'rotation' => FKC_InvReporting::rotation( 365 ), 'valeur' => FKC_InvValorisation::valeurStock(),
			'parCat' => FKC_InvReporting::valeurParCategorie(), 'dormants' => FKC_InvReporting::dormants( 90 ),
			'consommation' => FKC_InvReporting::consommationParMotif( 365 ), 'mouvements' => FKC_InvReporting::mouvementsParType( 365 ),
			'previsions' => FKC_InvReporting::previsions( 10 ), 'flash' => $this->flash(),
		) );
	}

	/* ── helpers ── */
	protected function feature( $code ) {
		if ( FKC_Modules::featureEnabled( $code ) ) { return true; }
		FKC_View::render( 'inventaire::_locked', array(
			'title' => 'Inventaire · ' . FKC_Modules::featureLabel( $code ), 'tab' => '',
			'label' => FKC_Modules::featureLabel( $code ), 'min' => FKC_Modules::featureMinLabel( $code ),
		) );
		return false;
	}
	protected function anaOn() { return FKC_Modules::featureEnabled( 'inventaire.valorisation' ) && class_exists( 'FKC_License' ) && FKC_License::moduleEnabled( 'analytique' ); }
	protected function divisions() {
		try { return FKC_DB::q( 'SELECT id, code, libelle FROM divisions WHERE actif=1 ORDER BY libelle' )->fetchAll(); }
		catch ( Exception $e ) { return array(); }
	}
	protected function fournisseursList() {
		try { return class_exists( 'FKC_Fournisseur' ) ? FKC_Fournisseur::all() : FKC_DB::q( 'SELECT * FROM fournisseurs ORDER BY nom' )->fetchAll(); }
		catch ( Exception $e ) { return array(); }
	}
	protected function mouvementsType( $type, $limit ) {
		return FKC_DB::q( 'SELECT m.*, a.code article_code, a.designation, e.libelle entrepot FROM inv_mouvements m
			JOIN inv_articles a ON a.id=m.article_id JOIN inv_entrepots e ON e.id=m.entrepot_id WHERE m.type=? ORDER BY m.created_at DESC, m.id DESC LIMIT ?', array( $type, (int) $limit ) )->fetchAll();
	}
	protected function setFlash( $m ) { $_SESSION['__flash_inv'] = $m; }
	protected function flash() { $m = $_SESSION['__flash_inv'] ?? null; unset( $_SESSION['__flash_inv'] ); return $m; }
}
