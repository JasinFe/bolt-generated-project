<?php /** @var array $kpis @var array $clients @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$risk = array( 'faible' => 0, 'moyen' => 0, 'critique' => 0 );
foreach ( $clients as $c ) { if ( $c['encours'] > 0 ) { $risk[ $c['risque'] ]++; } }
$ag = $kpis['aging']; $maxAg = max( 1, $ag['courant'], $ag['b0_30'], $ag['b31_60'], $ag['b61_90'], $ag['b90p'] ); ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'dashboard' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="form-grid" style="margin-bottom:18px">
	<?php
	$cards = array(
		array( 'Montant facturé', $kpis['facture'], 'var(--text)' ),
		array( 'Montant encaissé', $kpis['encaisse'], 'var(--ok)' ),
		array( 'Montant en retard', $kpis['retard'], 'var(--orange)' ),
		array( 'Montant à risque', $kpis['a_risque'], 'var(--danger)' ),
	);
	foreach ( $cards as $c ) : ?>
		<div class="card"><div class="card-body">
			<span class="muted"><?= e( $c[0] ) ?></span>
			<div style="font-size:1.6em;font-weight:700;color:<?= $c[2] ?>"><?= e( fkc_money( $c[1] ) ) ?></div>
			<span class="muted" style="font-size:.85em">FCFA</span>
		</div></div>
	<?php endforeach; ?>
</div>

<div class="form-grid" style="margin-bottom:18px">
	<div class="card"><div class="card-body"><span class="muted">DSO (délai moyen d'encaissement)</span><div style="font-size:1.4em;font-weight:700"><?= (int) $kpis['dso'] ?> j</div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Taux de recouvrement</span><div style="font-size:1.4em;font-weight:700"><?= e( $kpis['taux'] ) ?> %</div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Encours total</span><div style="font-size:1.4em;font-weight:700"><?= e( fkc_money( $kpis['encours'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted"><?= e( FKC_Recouvrement::motDebiteur() ) ?> en retard</span><div style="font-size:1.4em;font-weight:700"><?= (int) $kpis['nb_clients_retard'] ?></div></div></div>
</div>

<?php
/*
 * QUATRE INDICATEURS CALCULÉS ET JAMAIS AFFICHÉS.
 *
 * Le moteur produit depuis plusieurs versions « à relancer », « sous accord »,
 * « part douteuse » et « créances orphelines » — avec, dans le code, le
 * commentaire qui explique pourquoi ils manquaient : l'encours dit l'état du
 * poste client, il ne dit pas ce qu'il y a À FAIRE. Aucun écran ne les
 * montrait. Un calcul que personne ne lit ne sert à rien.
 */
?>
<div class="form-grid" style="margin-bottom:18px">
	<div class="card"><div class="card-body">
		<span class="muted">À relancer aujourd'hui</span>
		<div style="font-size:1.4em;font-weight:700"><?= e( fkc_money( $kpis['a_relancer'] ?? 0 ) ) ?></div>
		<span class="muted" style="font-size:.85em"><?= (int) ( $kpis['nb_a_relancer'] ?? 0 ) ?> facture(s)</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Sous accord (promesse, plan, contentieux)</span>
		<div style="font-size:1.4em;font-weight:700;color:var(--ok)"><?= e( fkc_money( $kpis['sous_accord'] ?? 0 ) ) ?></div>
		<span class="muted" style="font-size:.85em">Dû, mais pas à relancer</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Part douteuse de l'encours</span>
		<div style="font-size:1.4em;font-weight:700;color:var(--danger)"><?= e( $kpis['part_douteuse'] ?? 0 ) ?> %</div>
		<span class="muted" style="font-size:.85em">Base d'une provision, pas le retard brut</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Créances sans client rattaché</span>
		<div style="font-size:1.4em;font-weight:700;color:<?= ( $kpis['creances_orphelines'] ?? 0 ) > 0 ? 'var(--orange)' : 'var(--text)' ?>"><?= e( fkc_money( $kpis['creances_orphelines'] ?? 0 ) ) ?></div>
		<span class="muted" style="font-size:.85em">À raccrocher à une fiche client</span>
	</div></div>
</div>

<?php if ( ( $kpis['passe_en_perte'] ?? 0 ) > 0 ) : ?>
	<p class="help" style="margin:-8px 0 16px">Hors encours : <strong><?= e( fkc_money( $kpis['passe_en_perte'] ) ) ?> FCFA</strong> de créances passées en perte (module Dépréciation), qui ne sont plus relancées.</p>
<?php endif; ?>

<?php
/*
 * Un renvoi vers les anomalies, et seulement s'il y en a.
 *
 * Le poste client peut être exact au centime et raconter faux : un crédit
 * saisi sans facture derrière éteint des créances bien réelles au lettrage, et
 * le client sort de la file de relance sans avoir rien payé. Rien, jusqu'ici,
 * ne le signalait — et c'est sur ce chiffre qu'on décide.
 */
$nbAno = FKC_Recouvrement::nbAnomalies();
if ( $nbAno ) : ?>
	<div class="alert alert-warn" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
		<span><strong><?= (int) $nbAno ?> anomalie(s)</strong> peuvent fausser l'encours ci-dessus sans erreur de calcul.</span>
		<a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/anomalies' ) ) ?>">Examiner →</a>
	</div>
<?php endif; ?>

<div class="card">
	<div class="card-head"><h2>Balance âgée (encours)</h2><span><a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/pilotage' ) ) ?>">Tendances →</a> <a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/balance-agee' ) ) ?>">Détail →</a></span></div>
	<div class="card-body">
		<?php foreach ( array( 'courant' => 'var(--ok)', 'b0_30' => '#7cc', 'b31_60' => 'var(--orange)', 'b61_90' => '#e8853a', 'b90p' => 'var(--danger)' ) as $k => $col ) : ?>
			<div style="display:flex;align-items:center;gap:10px;margin:6px 0">
				<span class="muted" style="width:80px;font-size:.85em"><?= e( FKC_Recouvrement::bucketLabel( $k ) ) ?></span>
				<div style="flex:1;background:rgba(255,255,255,.05);border-radius:6px;height:18px;overflow:hidden">
					<div style="height:100%;width:<?= round( $ag[ $k ] / $maxAg * 100 ) ?>%;background:<?= $col ?>"></div>
				</div>
				<span style="width:120px;text-align:right;font-weight:600"><?= e( fkc_money( $ag[ $k ] ) ) ?></span>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<div class="card">
	<div class="card-head"><h2>Répartition du risque</h2><a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/clients' ) ) ?>"><?= e( FKC_Recouvrement::motDebiteur() ) ?> →</a></div>
	<div class="card-body" style="display:flex;gap:24px;flex-wrap:wrap">
		<div>🟢 Faible : <strong><?= (int) $risk['faible'] ?></strong></div>
		<div>🟠 Moyen : <strong><?= (int) $risk['moyen'] ?></strong></div>
		<div>🔴 Critique : <strong><?= (int) $risk['critique'] ?></strong></div>
	</div>
</div>
