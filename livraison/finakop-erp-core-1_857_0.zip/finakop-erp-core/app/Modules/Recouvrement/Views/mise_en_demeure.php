<?php /**
 * Mise en demeure imprimable.
 *
 * 1.841.1 — la lettre ne réclame plus que le montant ÉCHU, et elle le
 * détaille facture par facture (numéro, date, échéance, reste dû). Elle ne
 * prétend plus « malgré nos relances » quand aucune relance n'a été tracée.
 *
 * @var array $client @var array|null $stats @var mixed $societe
 * @var array $echues @var float $montant_echu @var int $relances_prealables
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
// Barre de navigation : cet écran n'en avait aucune, on ne pouvait en
// sortir qu'avec le bouton du navigateur.
FKC_View::partial( '_modnav', array( 'module' => 'recouvrement', 'back' => 'recouvrement', 'backLabel' => 'Recouvrement' ) );
$soc = is_array( $societe ) ? $societe : array();
$nomSoc = $soc['nom'] ?? $soc['raison_sociale'] ?? 'Notre société';
$echues = isset( $echues ) && is_array( $echues ) ? $echues : array();
$montant = (float) ( $montant_echu ?? 0 );
$relances = (int) ( $relances_prealables ?? 0 );
$fmtDate = function ( $d ) { return $d ? date( 'd/m/Y', strtotime( (string) $d ) ) : '—'; };
$identifiants = array();
foreach ( array( 'rccm' => 'RCCM', 'ncc' => 'NCC', 'telephone' => 'Tél.', 'email' => 'E-mail' ) as $k => $lib ) {
	if ( ! empty( $soc[ $k ] ) ) { $identifiants[] = $lib . ' : ' . $soc[ $k ]; }
} ?>
<style>@media print{.fkc-noprint,.sidebar,nav,.subnav,.topbar,header{display:none!important}body{background:#fff!important}}</style>
<div class="bar fkc-noprint">
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/clients/' . (int) $client['id'] ) ) ?>">← Retour</a>
	<?php if ( $montant > 0 ) : ?><button class="btn btn-primary btn-sm" onclick="window.print()">🖨 Imprimer / Enregistrer en PDF</button><?php endif; ?>
</div>
<?php if ( $montant <= 0 ) : ?>
	<div class="card"><div class="card-body">
		<p style="margin:0"><strong>Aucune facture échue pour ce client.</strong></p>
		<p class="help" style="margin:6px 0 0">Une mise en demeure ne peut porter que sur des sommes exigibles. L'encours de ce client
			(<?= e( fkc_money( $stats['encours'] ?? 0 ) ) ?> FCFA) n'est pas encore arrivé à échéance.</p>
	</div></div>
<?php return; endif; ?>
<div class="card"><div class="card-body" style="max-width:760px;margin:0 auto;line-height:1.6">
	<p style="text-align:right;margin:0"><strong><?= e( $nomSoc ) ?></strong><br><?= e( $soc['adresse'] ?? '' ) ?>
		<?php foreach ( $identifiants as $idf ) : ?><br><span style="font-size:.9em"><?= e( $idf ) ?></span><?php endforeach; ?></p>
	<p style="text-align:right;margin:4px 0 24px">Le <?= e( date( 'd/m/Y' ) ) ?></p>
	<p style="margin:0"><strong><?= e( $client['nom'] ) ?></strong><br><?= e( $client['adresse'] ?? '' ) ?><?php if ( ! empty( $client['ville'] ) ) : ?><br><?= e( $client['ville'] ) ?><?php endif; ?></p>
	<p style="margin:24px 0 6px"><strong>Objet : Mise en demeure de payer</strong></p>
	<p>Madame, Monsieur,</p>
	<p>Sauf erreur ou omission de notre part, les sommes ci-dessous, arrivées à échéance, demeurent impayées<?= $relances > 0 ? ' malgré nos précédentes relances' : '' ?> :</p>
	<table class="table" style="margin:8px 0 14px">
		<thead><tr><th>Pièce</th><th>Date</th><th>Échéance</th><th class="num">Reste dû (FCFA)</th></tr></thead>
		<tbody><?php foreach ( $echues as $f ) : ?>
			<tr><td class="code"><?= e( ( ! empty( $f['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $f['source'] ) . ' ' : '' ) . ( ( $f['numero'] ?? '' ) ?: 'n°' . (int) $f['facture_id'] ) ) ?></td>
				<td><?= e( $fmtDate( $f['date_facture'] ?? '' ) ) ?></td>
				<td><?= e( $fmtDate( $f['echeance'] ?? '' ) ) ?></td>
				<td class="num"><?= e( fkc_money( $f['montant'] ) ) ?></td></tr>
		<?php endforeach; ?></tbody>
		<tfoot><tr class="total"><td colspan="3" class="right">Total exigible</td><td class="num"><?= e( fkc_money( $montant ) ) ?></td></tr></tfoot>
	</table>
	<?php $pen = (array) ( $penalites ?? array() ); if ( ( $pen['total'] ?? 0 ) > 0 ) : ?>
	<p>Conformément à nos conditions générales, des pénalités de retard sont exigibles :
		<?= e( fkc_money( $pen['interets'] ) ) ?> FCFA d'intérêts<?= ( $pen['forfait'] ?? 0 ) > 0 ? ' et ' . e( fkc_money( $pen['forfait'] ) ) . ' FCFA d\'indemnité forfaitaire' : '' ?>,
		soit <strong><?= e( fkc_money( $pen['total'] ) ) ?> FCFA</strong>.</p>
	<?php endif; ?>
	<p>En conséquence, nous vous mettons en demeure de régler la somme de <strong><?= e( fkc_money( $montant + (float) ( $pen['total'] ?? 0 ) ) ) ?> FCFA</strong><?= ( $pen['total'] ?? 0 ) > 0 ? ' (principal et pénalités)' : '' ?>
		dans un délai de <strong>huit (8) jours</strong> à compter de la réception du présent courrier.</p>
	<?php if ( ! empty( $paiement ) ) : ?><p style="white-space:pre-line"><?= e( $paiement ) ?></p><?php endif; ?>
	<p>À défaut de règlement dans ce délai, nous nous réservons le droit d'engager toute procédure de recouvrement,
		notamment la procédure d'injonction de payer prévue par l'Acte uniforme OHADA portant organisation des procédures
		simplifiées de recouvrement et des voies d'exécution, sans nouvel avis, ainsi que de réclamer les intérêts de retard
		et frais y afférents.</p>
	<p>Si le règlement a été effectué entre-temps, nous vous remercions de nous en transmettre la référence et de ne pas tenir compte du présent courrier.</p>
	<p>Dans l'attente de votre règlement, nous vous prions d'agréer, Madame, Monsieur, l'expression de nos salutations distinguées.</p>
	<p style="margin-top:28px">La Direction<br><strong><?= e( $nomSoc ) ?></strong></p>
</div></div>
