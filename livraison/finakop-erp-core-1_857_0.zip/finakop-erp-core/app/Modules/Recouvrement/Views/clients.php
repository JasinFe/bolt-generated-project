<?php /** @var array $lignes @var string $tri @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$scoreCol = function ( $s ) { return $s >= 75 ? 'var(--ok)' : ( $s >= 45 ? 'var(--orange)' : 'var(--danger)' ); }; ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'clients' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span class="muted">Classement & score de paiement</span>
	<span>Trier : 
		<a class="btn btn-ghost btn-sm <?= 'risque'===$tri?'':'' ?>" href="?tri=risque">À risque</a>
		<a class="btn btn-ghost btn-sm" href="?tri=encours">Encours</a>
		<a class="btn btn-ghost btn-sm" href="?tri=score">Score</a>
	</span>
</div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : client, téléphone…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th><?= e( FKC_Recouvrement::motDebiteur( false ) ) ?></th><th class="num">Encours</th><th class="num">En retard</th><th class="num">À risque</th><th class="num">Retard max</th><th>Score</th><th>Risque</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $lignes ) : ?><tr><td colspan="8" class="empty">Aucun client.</td></tr>
	<?php else : foreach ( $lignes as $c ) : ?>
		<tr>
			<td><a href="<?= e( url( 'recouvrement/clients/' . (int) $c['id'] ) ) ?>"><strong><?= e( $c['nom'] ) ?></strong></a></td>
			<td class="num"><?= e( fkc_money( $c['encours'] ) ) ?></td>
			<td class="num"><?= $c['retard'] > 0 ? e( fkc_money( $c['retard'] ) ) : '—' ?></td>
			<td class="num" style="<?= $c['a_risque'] > 0 ? 'color:var(--danger)' : '' ?>"><?= $c['a_risque'] > 0 ? e( fkc_money( $c['a_risque'] ) ) : '—' ?></td>
			<td class="num"><?= $c['jours_max'] > 0 ? (int) $c['jours_max'] . ' j' : '—' ?></td>
			<td><strong style="color:<?= $scoreCol( $c['score'] ) ?>"><?= (int) $c['score'] ?>/100</strong> <span class="muted" style="font-size:.85em"><?= e( FKC_Recouvrement::scoreLabel( $c['score'] ) ) ?></span></td>
			<td><?= e( FKC_Recouvrement::risqueLabel( $c['risque'] ) ) ?></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/clients/' . (int) $c['id'] ) ) ?>">Fiche</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
