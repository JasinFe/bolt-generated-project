<?php /** @var array $lignes @var array $kpis @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ag = $kpis['aging']; ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'agee' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Balance âgée intelligente — répartition de l'encours par ancienneté (lettrage FIFO des encaissements)</span></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th><?= e( FKC_Recouvrement::motDebiteur( false ) ) ?></th><th class="num">Non échu</th><th class="num">0-30 j</th><th class="num">31-60 j</th><th class="num">61-90 j</th><th class="num">90+ j</th><th class="num">Encours</th><th>Risque</th></tr></thead>
	<tbody>
	<?php if ( ! $lignes ) : ?><tr><td colspan="8" class="empty">Aucun encours client.</td></tr>
	<?php else : foreach ( $lignes as $c ) : $b = $c['buckets']; ?>
		<tr>
			<td><a href="<?= e( url( 'recouvrement/clients/' . (int) $c['id'] ) ) ?>"><strong><?= e( $c['nom'] ) ?></strong></a></td>
			<td class="num"><?= $b['courant'] > 0 ? e( fkc_money( $b['courant'] ) ) : '—' ?></td>
			<td class="num"><?= $b['b0_30'] > 0 ? e( fkc_money( $b['b0_30'] ) ) : '—' ?></td>
			<td class="num" style="<?= $b['b31_60'] > 0 ? 'color:var(--orange)' : '' ?>"><?= $b['b31_60'] > 0 ? e( fkc_money( $b['b31_60'] ) ) : '—' ?></td>
			<td class="num" style="<?= $b['b61_90'] > 0 ? 'color:#e8853a' : '' ?>"><?= $b['b61_90'] > 0 ? e( fkc_money( $b['b61_90'] ) ) : '—' ?></td>
			<td class="num" style="<?= $b['b90p'] > 0 ? 'color:var(--danger)' : '' ?>"><?= $b['b90p'] > 0 ? e( fkc_money( $b['b90p'] ) ) : '—' ?></td>
			<td class="num"><strong><?= e( fkc_money( $c['encours'] ) ) ?></strong></td>
			<td><?= e( FKC_Recouvrement::risqueLabel( $c['risque'] ) ) ?></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
	<?php if ( $lignes ) : ?><tfoot><tr class="total">
		<td class="right">Total</td>
		<td class="num"><?= e( fkc_money( $ag['courant'] ) ) ?></td><td class="num"><?= e( fkc_money( $ag['b0_30'] ) ) ?></td>
		<td class="num"><?= e( fkc_money( $ag['b31_60'] ) ) ?></td><td class="num"><?= e( fkc_money( $ag['b61_90'] ) ) ?></td>
		<td class="num"><?= e( fkc_money( $ag['b90p'] ) ) ?></td><td class="num"><?= e( fkc_money( $kpis['encours'] ) ) ?></td><td></td>
	</tr></tfoot><?php endif; ?>
</table></div>
