<?php /** @var array $promesses @var array $statuts @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'promesses' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Promesses de paiement · <?= count( $promesses ) ?></span></div>
<?php FKC_View::partial( '_listsearch', array( 'placeholder' => 'Filtrer : client, date, montant…' ) ); ?>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Date promise</th><th>Client</th><th class="num">Montant</th><th>Statut</th><th>Note</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $promesses ) : ?><tr><td colspan="6" class="empty">Aucune promesse enregistrée.</td></tr>
	<?php else : foreach ( $promesses as $p ) : $retard = strtotime( $p['date_promesse'] ) < strtotime( date( 'Y-m-d' ) ) && 'en_attente' === $p['statut']; ?>
		<tr>
			<td class="code" style="<?= $retard ? 'color:var(--danger)' : '' ?>"><?= e( $p['date_promesse'] ) ?><?= $retard ? ' ⚠' : '' ?></td>
			<td><a href="<?= e( url( 'recouvrement/clients/' . (int) $p['client_id'] ) ) ?>"><?= e( $p['client_nom'] ?: '—' ) ?></a></td>
			<td class="num"><?= e( fkc_money( $p['montant'] ) ) ?></td>
			<td><span class="modbadge <?= 'tenue'===$p['statut']?'b-on':('non_tenue'===$p['statut']?'b-off':'') ?>"><?= e( $statuts[ $p['statut'] ] ?? $p['statut'] ) ?></span></td>
			<td class="muted"><?= e( $p['note'] ?: '—' ) ?></td>
			<td class="right"><?php if ( 'en_attente' === $p['statut'] ) : ?>
				<form method="post" action="<?= e( url( 'recouvrement/promesses/' . (int) $p['id'] . '/statut' ) ) ?>" style="display:inline">
					<?= FKC_Csrf::field() ?>
					<button class="btn btn-ghost btn-sm" type="submit" name="statut" value="tenue">Tenue</button>
					<button class="btn btn-ghost btn-sm" type="submit" name="statut" value="non_tenue">Non tenue</button>
				</form>
			<?php endif; ?></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
