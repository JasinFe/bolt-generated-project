<?php /**
 * Plans d'apurement.
 *
 * Deux corrections ici. La vue rappelait plan() pour CHAQUE plan affiché — une
 * requête par plan, plus une par lot d'échéances — alors que le contrôleur peut
 * tout charger d'un coup. Et surtout, elle ne disait rien de l'état RÉEL de
 * l'échéancier : un plan dont trois échéances sont passées sans paiement
 * s'affichait « Actif », comme celui qui est réglé à la lettre. C'est pourtant
 * cette différence qui décide si le client reste à l'abri de la relance.
 *
 * @var array $plans @var array $clients @var array $statuts @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'plans' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="card">
	<div class="card-head"><h2>Nouveau plan d'apurement</h2></div>
	<div class="card-body">
		<form method="post" action="<?= e( url( 'recouvrement/plans/creer' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0;min-width:220px"><span>Client</span><select name="client_id" required><option value="">— Sélectionner —</option><?php foreach ( $clients as $c ) : ?><option value="<?= (int) $c['id'] ?>"><?= e( $c['nom'] ) ?></option><?php endforeach; ?></select></label>
			<label class="fld" style="margin:0"><span>Montant total</span><input type="number" name="montant_total" min="0" required style="width:140px"></label>
			<label class="fld" style="margin:0"><span>Nb échéances</span><input type="number" name="nb_echeances" min="1" value="3" style="width:90px"></label>
			<label class="fld" style="margin:0"><span>1re échéance</span><input type="date" name="premiere_date" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
			<button class="btn btn-primary" type="submit">Créer le plan</button>
		</form>
		<p class="help" style="margin:8px 0 0">Le montant est réparti en mensualités égales à partir de la première échéance. Tant qu'il est respecté, le client sort de la file de relance ; dès qu'une échéance est passée sans paiement, il y revient.</p>
	</div>
</div>
<?php if ( ! $plans ) : ?>
	<div class="card"><div class="card-body"><p class="muted" style="margin:0">Aucun plan d'apurement.</p></div></div>
<?php endif; ?>
<?php foreach ( $plans as $pl ) :
	$etat = $pl['etat'];
	$statut = (string) $pl['statut'];
	$defaut = ! empty( $etat['en_defaut'] ) && ! in_array( $statut, array( 'solde', 'clos', 'annule', 'rompu' ), true ); ?>
<div class="card card-flush">
	<div class="card-head"><h2><?= e( $pl['client_nom'] ?: '—' ) ?> · <?= e( fkc_money( $pl['montant_total'] ) ) ?> FCFA</h2>
		<span>
			<span class="modbadge <?= 'solde'===$statut?'b-on':( in_array($statut,array('rompu','annule','clos'),true)?'b-off':'' ) ?>"><?= e( $statuts[ $statut ] ?? ucfirst( $statut ) ) ?></span>
			<?php if ( $defaut ) : ?>
				<span class="modbadge b-off" title="La relance amiable n'est plus suspendue">⚠ <?= (int) $etat['echues_impayees'] ?> échéance(s) en retard — <?= e( fkc_money( $etat['montant_du'] ) ) ?> F</span>
			<?php elseif ( 'actif' === $statut ) : ?>
				<span class="modbadge b-on">Respecté — relance suspendue</span>
			<?php endif; ?>
		</span></div>
	<table class="table">
		<thead><tr><th>#</th><th>Échéance</th><th class="num">Montant</th><th>Statut</th><th></th></tr></thead>
		<tbody><?php foreach ( $pl['echeances'] as $ec ) :
			$enRetard = 'paye' !== $ec['statut'] && $ec['date_echeance'] < date( 'Y-m-d' ); ?>
			<tr><td><?= (int) $ec['rang'] ?></td><td class="code" style="<?= $enRetard ? 'color:var(--danger)' : '' ?>"><?= e( $ec['date_echeance'] ) ?><?= $enRetard ? ' ⚠' : '' ?></td><td class="num"><?= e( fkc_money( $ec['montant'] ) ) ?></td>
				<td><span class="modbadge <?= 'paye'===$ec['statut']?'b-on':( $enRetard?'b-off':'' ) ?>"><?= 'paye'===$ec['statut']?'Payée':( $enRetard?'En retard':'Due' ) ?></span></td>
				<td class="right"><?php if ( 'paye' !== $ec['statut'] ) : ?>
					<form method="post" action="<?= e( url( 'recouvrement/plans/echeance/' . (int) $ec['id'] ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Marquer payée</button></form>
				<?php endif; ?></td></tr>
		<?php endforeach; ?></tbody>
		<tfoot><tr class="total"><td colspan="2" class="right">Payé <?= e( fkc_money( $etat['paye'] ) ) ?> · Reste</td><td class="num"><?= e( fkc_money( $etat['reste'] ) ) ?></td><td colspan="2"></td></tr></tfoot>
	</table>
</div>
<?php endforeach; ?>
