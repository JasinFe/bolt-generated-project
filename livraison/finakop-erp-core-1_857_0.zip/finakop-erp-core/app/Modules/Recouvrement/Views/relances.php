<?php /**
 * File de relance.
 *
 * CET ÉCRAN ÉTAIT RESTÉ À LA VERSION D'AVANT LES PALIERS.
 *
 * Le moteur choisit désormais un palier parmi ceux de la société — libellé,
 * canal, ton, délai minimal entre deux envois — et le contrôleur les
 * transmettait déjà. La vue, elle, en ignorait tout :
 *
 *   — elle annonçait « Email J-7 · WhatsApp J+3 » en dur, la cadence d'avant,
 *     même chez une société qui avait paramétré la sienne ;
 *   — elle ne connaissait que deux canaux sur cinq : tout ce qui n'était pas
 *     WhatsApp était traité comme un e-mail. Une MISE EN DEMEURE par courrier
 *     s'affichait donc « 🟢 WhatsApp » et proposait un bouton « mailto: » ;
 *   — le palier et le ton, calculés, n'apparaissaient nulle part : impossible
 *     de savoir, en regardant l'écran, à quel stade de la procédure on en est.
 *
 * @var array $dues @var array $regles @var array $paliers @var bool $personnalisee
 * @var array $canaux @var array $tons @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$icone = array( 'email' => '✉', 'whatsapp' => '🟢', 'sms' => '💬', 'telephone' => '📞', 'courrier' => '📄' );
$tonBadge = array( 'courtoisie' => '', 'ferme' => 'b-warn', 'mise_en_demeure' => 'b-off' );
?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'relances' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar" style="flex-wrap:wrap;gap:8px">
	<span class="muted"><?= count( $dues ) ?> client(s) à relancer — un relevé par client — cadence <?= $personnalisee ? 'propre à la société' : 'par défaut' ?>.</span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/politiques' ) ) ?>">⚙️ Modifier la cadence</a>
	<?php $nbMail = 0; foreach ( $dues as $g ) { if ( 'email' === $g['canal'] && ! empty( $g['email'] ) ) { $nbMail++; } }
	if ( ! empty( $envoi_direct ) && $nbMail > 0 ) : ?>
		<form method="post" action="<?= e( url( 'recouvrement/relances/envoyer-tout' ) ) ?>" style="display:inline" onsubmit="return confirm('Envoyer maintenant les <?= (int) $nbMail ?> relevé(s) prévus par e-mail ?')">
			<?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" type="submit">✉ Envoyer les <?= (int) $nbMail ?> e-mail(s) du jour</button>
		</form>
	<?php endif; ?>
</div>
<div class="card">
	<div class="card-head"><h2>Paliers appliqués</h2></div>
	<div class="card-body" style="display:flex;gap:14px;flex-wrap:wrap">
		<?php foreach ( $paliers as $p ) : $j = (int) $p['jours']; ?>
			<span class="modbadge <?= e( $tonBadge[ $p['ton'] ] ?? '' ) ?>">
				<?= e( $icone[ $p['canal'] ] ?? '•' ) ?> <?= e( $p['libelle'] ) ?>
				· J<?= $j >= 0 ? '+' . $j : $j ?>
				· <?= e( $canaux[ $p['canal'] ] ?? $p['canal'] ) ?>
				· <?= e( $tons[ $p['ton'] ] ?? $p['ton'] ) ?>
			</span>
		<?php endforeach; ?>
	</div>
</div>
<?php if ( ! $dues ) : ?>
	<div class="card"><div class="card-body"><p class="muted" style="margin:0">Aucune relance à effectuer aujourd'hui. 🎉</p></div></div>
<?php else : foreach ( $dues as $f ) :
	$canal = (string) $f['canal'];
	$tel = preg_replace( '/\D+/', '', (string) $f['telephone'] );
	$msg = $f['message']['corps'];
	$wa = 'https://wa.me/' . $tel . '?text=' . rawurlencode( $msg );
	$mailto = 'mailto:' . rawurlencode( (string) $f['email'] ) . '?subject=' . rawurlencode( (string) $f['message']['sujet'] ) . '&body=' . rawurlencode( $msg );
	$jours = (int) $f['jours']; ?>
<div class="card">
	<div class="card-head">
		<h2><?= e( $f['client_nom'] ) ?> · <?php $nbL = count( $f['lignes'] ?? array() ); if ( $nbL > 1 ) : ?>relevé de <?= $nbL ?> pièces<?php else : ?><?= e( ! empty( $f['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? mb_strtolower( FKC_RecouvrementSources::court( $f['source'] ) ) : 'facture' ) ?> <?= e( ( $f['numero'] ?? '' ) ?: 'n°' . (int) $f['facture_id'] ) ?><?php endif; ?> · <?= e( fkc_money( $f['montant'] ) ) ?> FCFA</h2>
		<span class="modbadge <?= e( $tonBadge[ $f['ton'] ] ?? '' ) ?>">
			<?= e( $icone[ $canal ] ?? '•' ) ?> <?= e( $f['palier'] ) ?>
			· <?= e( $canaux[ $canal ] ?? $canal ) ?>
			· <?= $jours > 0 ? 'J+' . $jours : 'J' . $jours ?>
		</span>
	</div>
	<div class="card-body">
		<?php if ( $nbL > 1 ) : ?>
		<table class="table" style="margin:0 0 10px">
			<thead><tr><th>Pièce</th><th>Échéance</th><th class="num">Reste dû</th><th class="num">Retard</th><th>Palier</th></tr></thead>
			<tbody><?php foreach ( $f['lignes'] as $l ) : ?>
				<tr><td class="code"><?= e( ( ! empty( $l['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $l['source'] ) . ' ' : '' ) . ( ( $l['numero'] ?? '' ) ?: 'n°' . (int) $l['facture_id'] ) ) ?></td>
					<td class="code"><?= e( date( 'd/m/Y', strtotime( $l['echeance'] ) ) ) ?></td>
					<td class="num"><?= e( fkc_money( $l['montant'] ) ) ?></td>
					<td class="num"><?= (int) $l['jours'] > 0 ? (int) $l['jours'] . ' j' : '—' ?></td>
					<td class="muted"><?= e( $l['palier'] ) ?></td></tr>
			<?php endforeach; ?></tbody>
		</table>
		<?php endif; ?>
		<?php if ( $f['message']['sujet'] ) : ?><p style="margin:0 0 6px"><strong>Objet :</strong> <?= e( $f['message']['sujet'] ) ?></p><?php endif; ?>
		<pre style="white-space:pre-wrap;font-family:inherit;background:rgba(255,255,255,.04);padding:10px;border-radius:8px;margin:0"><?= e( $msg ) ?></pre>
		<div class="actions" style="margin-top:10px;flex-wrap:wrap;gap:8px">
			<?php if ( 'whatsapp' === $canal ) : ?>
				<a class="btn btn-primary btn-sm" href="<?= e( $wa ) ?>" target="_blank" <?= $tel ? '' : 'aria-disabled="true" style="opacity:.5;pointer-events:none"' ?>>Ouvrir WhatsApp</a>
				<?php if ( ! $tel ) : ?><span class="muted" style="font-size:.85em">Aucun numéro sur la fiche client.</span><?php endif; ?>
			<?php elseif ( 'sms' === $canal ) : ?>
				<a class="btn btn-primary btn-sm" href="sms:<?= e( $tel ) ?>?body=<?= e( rawurlencode( $msg ) ) ?>" <?= $tel ? '' : 'aria-disabled="true" style="opacity:.5;pointer-events:none"' ?>>Ouvrir le SMS</a>
				<?php if ( ! $tel ) : ?><span class="muted" style="font-size:.85em">Aucun numéro sur la fiche client.</span><?php endif; ?>
			<?php elseif ( 'telephone' === $canal ) : ?>
				<a class="btn btn-primary btn-sm" href="tel:<?= e( $tel ) ?>" <?= $tel ? '' : 'aria-disabled="true" style="opacity:.5;pointer-events:none"' ?>>Appeler</a>
				<span class="muted" style="font-size:.85em">Le texte ci-dessus sert de trame d'entretien.</span>
			<?php elseif ( 'courrier' === $canal ) : ?>
				<?php if ( 'mise_en_demeure' === $f['ton'] ) : ?>
					<a class="btn btn-primary btn-sm" href="<?= e( url( 'recouvrement/clients/' . (int) $f['client_id'] . '/mise-en-demeure' ) ) ?>" target="_blank">📄 Éditer la mise en demeure</a>
				<?php endif; ?>
				<button class="btn btn-ghost btn-sm" type="button" onclick="window.print()">Imprimer ce texte</button>
			<?php else : ?>
				<?php if ( ! empty( $envoi_direct ) && $f['email'] ) : ?>
					<form method="post" action="<?= e( url( 'recouvrement/relances/envoyer' ) ) ?>" style="display:inline">
						<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= (int) $f['client_id'] ?>">
						<button class="btn btn-primary btn-sm" type="submit">✉ Envoyer maintenant</button>
					</form>
				<?php endif; ?>
				<a class="btn <?= ! empty( $envoi_direct ) ? 'btn-ghost' : 'btn-primary' ?> btn-sm" href="<?= e( $mailto ) ?>" <?= $f['email'] ? '' : 'aria-disabled="true" style="opacity:.5;pointer-events:none"' ?>>Ouvrir dans ma messagerie</a>
				<?php if ( ! $f['email'] ) : ?><span class="muted" style="font-size:.85em">Aucune adresse sur la fiche client.</span><?php endif; ?>
			<?php endif; ?>
			<form method="post" action="<?= e( url( 'recouvrement/relances/log' ) ) ?>" style="display:inline">
				<?= FKC_Csrf::field() ?>
				<input type="hidden" name="client_id" value="<?= (int) $f['client_id'] ?>">
				<input type="hidden" name="facture_id" value="<?= (int) $f['facture_id'] ?>">
				<input type="hidden" name="canal" value="<?= e( $canal ) ?>">
				<input type="hidden" name="ton" value="<?= e( $f['ton'] ) ?>">
				<input type="hidden" name="detail" value="<?= e( $f['palier'] ) ?> (<?= e( $canaux[ $canal ] ?? $canal ) ?>) — <?= e( $nbL > 1 ? 'relevé : ' . ( $f['references'] ?? '' ) . ' — total ' . fkc_money( $f['montant'] ) . ' F' : ( ( ! empty( $f['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? mb_strtolower( FKC_RecouvrementSources::court( $f['source'] ) ) : 'facture' ) . ' ' . ( ( $f['numero'] ?? '' ) ?: 'n°' . (int) $f['facture_id'] ) ) ) ?>">
				<button class="btn btn-ghost btn-sm" type="submit">Marquer comme envoyée</button>
			</form>
			<?php
			/*
			 * AU PALIER « MISE EN DEMEURE », LE PRÉCONTENTIEUX EST À UN GESTE
			 * (1.841.4). Il n'est pas ouvert d'office : c'est une décision.
			 */
			if ( 'mise_en_demeure' === $f['ton'] && ! isset( $dossiers_ouverts[ (int) $f['client_id'] ] ) && (int) $f['client_id'] > 0 ) :
				$echu = 0.0; foreach ( ( $f['lignes'] ?? array( $f ) ) as $l ) { if ( (int) $l['jours'] > 0 ) { $echu += (float) $l['montant']; } } ?>
				<form method="post" action="<?= e( url( 'recouvrement/dossiers/basculer' ) ) ?>" style="display:inline" onsubmit="return confirm('Ouvrir le dossier précontentieux de ce client ?')">
					<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= (int) $f['client_id'] ?>">
					<input type="hidden" name="montant" value="<?= (int) $echu ?>"><input type="hidden" name="motif" value="Mise en demeure restée sans effet">
					<button class="btn btn-ghost btn-sm" type="submit">⚖ Ouvrir le précontentieux</button>
				</form>
			<?php elseif ( isset( $dossiers_ouverts[ (int) $f['client_id'] ] ) ) : ?>
				<span class="modbadge b-off">Dossier <?= e( FKC_RecouvrementSuivi::statutsDossier()[ $dossiers_ouverts[ (int) $f['client_id'] ] ] ?? '' ) ?></span>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php endforeach; endif; ?>
