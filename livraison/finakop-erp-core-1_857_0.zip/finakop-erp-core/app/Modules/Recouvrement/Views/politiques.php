<?php defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php /** @var array $paliers @var bool $perso_relance @var float $seuil_montant @var array $canaux @var array $tons @var array $niveaux @var array $roles @var bool $perso_wf @var array|string|null $flash @var bool $peut_modifier */ ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'politiques' ) ); ?>
<h1>Politiques internes de recouvrement</h1>
<?php if ( $flash ) : $fm = is_array( $flash ) ? $flash : array( 'type' => 'ok', 'msg' => (string) $flash ); ?>
	<div class="alert alert-<?= 'err' === $fm['type'] ? 'err' : 'ok' ?>"><?= e( $fm['msg'] ) ?></div>
<?php endif; ?>
<?php $peut = ! empty( $peut_modifier ); if ( ! $peut ) : ?>
	<div class="alert alert-warn">Consultation seule : ces politiques ne peuvent être modifiées que par un administrateur.</div>
<?php endif; ?>
<fieldset style="border:0;padding:0;margin:0"<?= $peut ? '' : ' disabled' ?>>
<p class="muted" style="max-width:78ch">
	Ces règles ne relèvent pas de la comptabilité mais de la <strong>politique interne</strong> de
	l'entreprise, et elles sont propres à ce dossier. Une officine relance à sept jours parce que ses
	créances sont petites et nombreuses ; un constructeur attend soixante jours parce qu'un chantier se
	paie par situations. Les valeurs livrées ne sont que des points de départ prudents.
</p>

<div class="card">
	<div class="card-head"><h2>Cadence des relances</h2>
		<span class="muted"><?= $perso_relance ? 'politique propre à ce dossier' : 'valeurs par défaut' ?></span></div>
	<div style="padding:0 12px 8px" class="muted">
		Un jour négatif est un rappel <em>avant</em> l'échéance — ce n'est pas une relance, c'est une
		courtoisie, et elle évite l'essentiel des retards d'inattention. Le moteur applique le palier
		<strong>atteint le plus avancé</strong> : un client à quatre-vingt-dix jours reçoit la mise en
		demeure, pas le rappel de courtoisie.
	</div>
	<form method="post" action="<?= e( url( 'recouvrement/politiques/relances' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<table class="table">
			<thead><tr><th style="width:110px">Jour</th><th>Libellé</th><th style="width:150px">Canal</th>
				<th style="width:160px">Ton</th><th style="width:150px">Délai mini entre deux</th></tr></thead>
			<tbody>
			<?php for ( $i = 0; $i < 8; $i++ ) : $p = $paliers[ $i ] ?? null; ?>
				<tr>
					<td><input type="number" name="jours[<?= $i ?>]" value="<?= null !== $p ? (int) $p['jours'] : '' ?>" style="width:90px"></td>
					<td><input type="text" name="libelle[<?= $i ?>]" value="<?= $p ? e( $p['libelle'] ) : '' ?>" style="width:100%"></td>
					<td><select name="canal[<?= $i ?>]"><?php foreach ( $canaux as $k => $v ) : ?>
						<option value="<?= e( $k ) ?>" <?= $p && $p['canal'] === $k ? 'selected' : '' ?>><?= e( $v ) ?></option>
					<?php endforeach; ?></select></td>
					<td><select name="ton[<?= $i ?>]"><?php foreach ( $tons as $k => $v ) : ?>
						<option value="<?= e( $k ) ?>" <?= $p && $p['ton'] === $k ? 'selected' : '' ?>><?= e( $v ) ?></option>
					<?php endforeach; ?></select></td>
					<td><input type="number" name="min_jours_entre[<?= $i ?>]" value="<?= $p ? (int) $p['min_jours_entre'] : 7 ?>" style="width:80px"> jours</td>
				</tr>
			<?php endfor; ?>
			</tbody>
		</table>
		<div style="padding:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
			<label>Ne pas relancer en dessous de
				<input type="number" name="seuil_montant" value="<?= (int) $seuil_montant ?>" style="width:130px"> F</label>
			<span class="muted">Relancer une créance de deux mille francs coûte plus cher en temps qu'elle ne rapporte.</span>
			<button class="btn btn-primary btn-sm" type="submit">Enregistrer</button>
		</div>
	</form>
	<?php if ( $perso_relance ) : ?>
	<form method="post" action="<?= e( url( 'recouvrement/politiques/reinit' ) ) ?>" style="padding:0 10px 10px">
		<?= FKC_Csrf::field() ?><input type="hidden" name="quoi" value="relance">
		<button class="btn btn-ghost btn-sm" type="submit">Revenir aux valeurs par défaut</button>
	</form>
	<?php endif; ?>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Validation des dotations</h2>
		<span class="muted"><?= $perso_wf ? 'politique propre à ce dossier' : 'valeurs par défaut' ?></span></div>
	<div style="padding:0 12px 8px" class="muted">
		Un seuil ne dit pas qui a raison : il dit <strong>à partir de quand la décision cesse d'être
		individuelle</strong>. Une dotation modifie le résultat de l'exercice.
		Un niveau à partir de <strong>0 F est obligatoire</strong> — sans lui, les petites dotations ne
		relèveraient d'aucun niveau et personne ne pourrait les valider.
		Les rôles proposés viennent du <strong>moteur de rôles</strong>, celui-là même qui décide de la
		validation — une saisie libre laissait écrire un code que personne ne porte, et le niveau bloquait
		alors en silence.
		Un niveau supérieur valide ce qui est en dessous : les seuils disent à partir de quand il faut
		monter, pas qu'il est interdit de descendre.
	</div>
	<form method="post" action="<?= e( url( 'recouvrement/politiques/workflow' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<table class="table">
			<thead><tr><th style="width:200px">À partir de</th><th style="width:200px">Rôle requis</th><th>Libellé affiché</th></tr></thead>
			<tbody>
			<?php for ( $i = 0; $i < 6; $i++ ) : $n = $niveaux[ $i ] ?? null; ?>
				<tr>
					<td><input type="number" name="seuil[<?= $i ?>]" value="<?= null !== $n ? (int) $n['seuil'] : '' ?>" style="width:150px"> F</td>
					<td><select name="role[<?= $i ?>]" style="width:100%">
						<?php foreach ( $roles as $rk => $rl ) : ?>
							<option value="<?= e( $rk ) ?>" <?= $n && $n['role'] === $rk ? 'selected' : '' ?>><?= e( $rl ) ?></option>
						<?php endforeach; ?>
					</select></td>
					<td><input type="text" name="niveau_libelle[<?= $i ?>]" value="<?= $n ? e( $n['libelle'] ) : '' ?>" style="width:100%"></td>
				</tr>
			<?php endfor; ?>
			</tbody>
		</table>
		<div style="padding:10px"><button class="btn btn-primary btn-sm" type="submit">Enregistrer</button></div>
	</form>
	<div style="padding:0 12px 12px" class="muted">
		L'administrateur passe toujours, et c'est assumé : un workflow qu'aucun utilisateur présent ne peut
		débloquer paralyse l'entreprise le jour où le chef comptable est en congé. L'historique dit qui a
		validé quoi — le contrôle est a posteriori, pas par blocage.
	</div>
	<?php if ( $perso_wf ) : ?>
	<form method="post" action="<?= e( url( 'recouvrement/politiques/reinit' ) ) ?>" style="padding:0 10px 10px">
		<?= FKC_Csrf::field() ?><input type="hidden" name="quoi" value="workflow">
		<button class="btn btn-ghost btn-sm" type="submit">Revenir aux valeurs par défaut</button>
	</form>
	<?php endif; ?>
</div>

<?php $pai = $paiement ?? array( 'numeros' => array(), 'lien' => '', 'instructions' => '' ); $pen = $penalites ?? array( 'actif' => false, 'taux_mensuel' => 0, 'grace' => 0, 'forfait' => 0 ); ?>
<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Moyens de paiement cités dans les relances</h2></div>
	<div style="padding:0 12px 8px" class="muted">
		Une relance qui ne dit pas <strong>comment payer</strong> fait perdre le paiement du jour. Les numéros renseignés ici
		sont ajoutés à chaque message, avec la référence de la pièce. Le lien de paiement est celui de votre page marchande
		(Wave, Orange Money…) : écrivez <code>{montant}</code> et <code>{reference}</code> là où l'opérateur les attend, ils seront
		remplis pour chaque client. Laissez vide ce que vous n'utilisez pas.
	</div>
	<form method="post" action="<?= e( url( 'recouvrement/politiques/paiement' ) ) ?>" style="padding:0 12px 12px">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid">
			<?php foreach ( ( $operateurs ?? array() ) as $k => $lib ) : ?>
				<label class="fld"><span><?= e( $lib ) ?></span><input type="tel" name="numeros[<?= e( $k ) ?>]" value="<?= e( $pai['numeros'][ $k ] ?? '' ) ?>" placeholder="07 00 00 00 00"></label>
			<?php endforeach; ?>
		</div>
		<label class="fld"><span>Lien de paiement (facultatif)</span><input type="url" name="lien" value="<?= e( $pai['lien'] ) ?>" placeholder="https://…?montant={montant}&ref={reference}" style="width:100%"></label>
		<label class="fld"><span>Autres instructions (virement, RIB, caisse…)</span><input type="text" name="instructions" maxlength="400" value="<?= e( $pai['instructions'] ) ?>" style="width:100%"></label>
		<button class="btn btn-primary btn-sm" type="submit">Enregistrer</button>
	</form>
</div>

<div class="card" style="margin-top:14px">
	<div class="card-head"><h2>Pénalités de retard</h2><span class="muted"><?= $pen['actif'] ? 'activées' : 'désactivées' ?></span></div>
	<div style="padding:0 12px 8px" class="muted">
		Elles ne sont dues que si vos <strong>conditions générales</strong> les prévoient. Activées, elles sont chiffrées dans
		les relances fermes et la mise en demeure : intérêts au taux mensuel, au prorata des jours de retard au-delà du délai de
		grâce, plus une indemnité forfaitaire par relevé. Elles ne sont jamais comptabilisées d'office : réclamer n'est pas facturer.
	</div>
	<form method="post" action="<?= e( url( 'recouvrement/politiques/penalites' ) ) ?>" style="padding:0 12px 12px;display:flex;gap:12px;flex-wrap:wrap;align-items:end">
		<?= FKC_Csrf::field() ?>
		<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="actif" value="1" <?= $pen['actif'] ? 'checked' : '' ?>> Réclamer des pénalités</label>
		<label class="fld" style="margin:0"><span>Taux mensuel (%)</span><input type="number" step="0.001" min="0" max="10" name="taux_mensuel" value="<?= e( (string) $pen['taux_mensuel'] ) ?>" style="width:110px"></label>
		<label class="fld" style="margin:0"><span>Délai de grâce (jours)</span><input type="number" min="0" name="grace" value="<?= (int) $pen['grace'] ?>" style="width:110px"></label>
		<label class="fld" style="margin:0"><span>Indemnité forfaitaire (F)</span><input type="number" min="0" name="forfait" value="<?= (int) $pen['forfait'] ?>" style="width:140px"></label>
		<button class="btn btn-primary btn-sm" type="submit">Enregistrer</button>
	</form>
</div>
</fieldset>
