<?php /**
 * Anomalies du poste client.
 *
 * Cet écran répond à une question que le reste du module ne peut pas poser :
 * « l'encours est-il faux, alors même que le calcul est juste ? »
 *
 * Le moteur reflète le grand livre. Il ne peut donc pas distinguer un client
 * qui a payé d'un client dont le compte a été crédité par erreur — les deux se
 * présentent de la même façon. Le lettrage impute alors ce crédit sur des
 * factures bien réelles, et le client sort de la file de relance sans avoir
 * rien réglé. Rien ne le signalait.
 *
 * @var array $anomalies @var array $kpis @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$couleur = array( 3 => 'b-off', 2 => 'b-warn', 1 => '' );
$niveau  = array( 3 => 'Bloquant', 2 => 'À vérifier', 1 => 'Hypothèse' );
$groupes = array();
foreach ( $anomalies as $a ) { $groupes[ $a['type'] ][] = $a; }
?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'anomalies' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="form-grid" style="margin-bottom:18px">
	<div class="card"><div class="card-body">
		<span class="muted">Anomalies détectées</span>
		<div style="font-size:1.4em;font-weight:700;color:<?= $anomalies ? 'var(--orange)' : 'var(--ok)' ?>"><?= count( $anomalies ) ?></div>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Crédits non affectés</span>
		<div style="font-size:1.4em;font-weight:700"><?= e( fkc_money( $kpis['credits_non_affectes'] ?? 0 ) ) ?></div>
		<span class="muted" style="font-size:.85em">Payé au-delà du facturé</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Créances sans fiche client</span>
		<div style="font-size:1.4em;font-weight:700"><?= e( fkc_money( $kpis['creances_orphelines'] ?? 0 ) ) ?></div>
		<span class="muted" style="font-size:.85em">Personne ne peut les relancer</span>
	</div></div>
</div>

<?php if ( ! $anomalies ) : ?>
	<div class="card"><div class="card-body">
		<p style="margin:0"><strong>Aucune anomalie détectée.</strong></p>
		<p class="help" style="margin:6px 0 0">Chaque encaissement trouve une facture en face, chaque créance porte une fiche client, et chaque facture a une échéance. L'encours affiché par le module peut être lu tel quel.</p>
	</div></div>
<?php else : ?>
	<div class="card"><div class="card-body">
		<p class="help" style="margin:0">Ces points ne sont pas des erreurs de calcul : ce sont des saisies, des oublis ou des fiches manquantes qui rendent l'encours inexact sans que rien ne le signale. Certains sont parfaitement normaux — une avance reçue avant facturation est un crédit légitime. Rien n'est corrigé automatiquement.</p>
	</div></div>
<?php endif; ?>

<?php foreach ( $groupes as $type => $liste ) : $premier = $liste[0]; ?>
<div class="card card-flush">
	<div class="card-head">
		<h2><?= e( $premier['libelle'] ) ?> <span class="muted">(<?= count( $liste ) ?>)</span></h2>
		<span class="modbadge <?= e( $couleur[ $premier['gravite'] ] ?? '' ) ?>"><?= e( $niveau[ $premier['gravite'] ] ?? '' ) ?></span>
	</div>
	<div class="card-body" style="padding-bottom:0">
		<p style="margin:0 0 4px"><?= e( $premier['explication'] ) ?></p>
		<p class="help" style="margin:0"><strong>À faire :</strong> <?= e( $premier['geste'] ) ?></p>
	</div>
	<table class="table">
		<thead><tr><th>Client</th><th>Pièce</th><th>Date</th><th class="num">Montant</th><th></th></tr></thead>
		<tbody><?php foreach ( $liste as $a ) : ?>
			<tr>
				<td><?= e( $a['client_nom'] ) ?></td>
				<td class="code"><?= e( $a['reference'] ?? '—' ) ?></td>
				<td class="code"><?= e( $a['date'] ?? '—' ) ?></td>
				<td class="num"><?= e( fkc_money( $a['montant'] ) ) ?></td>
				<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( $a['lien'] ) ) ?>">Ouvrir →</a></td>
			</tr>
		<?php endforeach; ?></tbody>
		<tfoot><tr class="total"><td colspan="3" class="right">Total</td><td class="num"><?= e( fkc_money( array_sum( array_column( $liste, 'montant' ) ) ) ) ?></td><td></td></tr></tfoot>
	</table>
</div>
<?php endforeach; ?>
