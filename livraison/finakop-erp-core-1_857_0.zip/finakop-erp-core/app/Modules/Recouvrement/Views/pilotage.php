<?php /**
 * Pilotage du recouvrement (1.841.5) : tendances, DSO, CEI, promesses, équipe.
 *
 * @var array $kpis @var int $dso90 @var array $historique @var array $promesses
 * @var array $agents @var int $periode @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$dernierCei = null;
// Le CEI d'un mois EN COURS n'est pas un CEI : il se lit sur un mois clos.
foreach ( array_reverse( $historique ) as $h ) { if ( null !== $h['cei'] && date( 'Y-m' ) !== $h['mois'] ) { $dernierCei = $h; break; } }
$maxEnc = 1.0; foreach ( $historique as $h ) { $maxEnc = max( $maxEnc, (float) $h['encours'] ); }
$moisFr = array( '01' => 'janv.', '02' => 'févr.', '03' => 'mars', '04' => 'avr.', '05' => 'mai', '06' => 'juin',
	'07' => 'juil.', '08' => 'août', '09' => 'sept.', '10' => 'oct.', '11' => 'nov.', '12' => 'déc.' );
$libMois = function ( $m ) use ( $moisFr ) { return ( $moisFr[ substr( $m, 5, 2 ) ] ?? substr( $m, 5, 2 ) ) . ' ' . substr( $m, 2, 2 ); };
?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'pilotage' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="form-grid" style="margin-bottom:18px">
	<div class="card"><div class="card-body">
		<span class="muted">DSO sur 12 mois</span>
		<div style="font-size:1.6em;font-weight:700"><?= (int) $kpis['dso'] ?> j</div>
		<span class="muted" style="font-size:.85em">délai moyen d'encaissement</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">DSO glissant 90 jours</span>
		<div style="font-size:1.6em;font-weight:700"><?= (int) $dso90 ?> j</div>
		<span class="muted" style="font-size:.85em"><?= $dso90 > (int) $kpis['dso'] ? '▲ se dégrade' : ( $dso90 < (int) $kpis['dso'] ? '▼ s\'améliore' : 'stable' ) ?> par rapport à l'année</span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Efficacité du recouvrement (CEI)</span>
		<div style="font-size:1.6em;font-weight:700"><?= $dernierCei ? e( $dernierCei['cei'] ) . ' %' : '—' ?></div>
		<span class="muted" style="font-size:.85em"><?= $dernierCei ? 'part de l\'exigible encaissée en ' . e( $libMois( $dernierCei['mois'] ) ) : 'disponible après deux mois de photos' ?></span>
	</div></div>
	<div class="card"><div class="card-body">
		<span class="muted">Promesses tenues (90 j)</span>
		<div style="font-size:1.6em;font-weight:700"><?= null !== $promesses['taux'] ? e( $promesses['taux'] ) . ' %' : '—' ?></div>
		<span class="muted" style="font-size:.85em"><?= (int) $promesses['tenues'] ?> tenue(s) · <?= (int) $promesses['non_tenues'] ?> non tenue(s)</span>
	</div></div>
</div>

<div class="card">
	<div class="card-head"><h2>Encours en fin de mois</h2>
		<span class="muted" style="font-size:.85em;display:flex;gap:14px;align-items:center">
			<span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--orange);vertical-align:middle"></span> En retard</span>
			<span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:var(--ok);vertical-align:middle"></span> Non échu</span>
		</span>
	</div>
	<div class="card-body">
	<?php if ( count( $historique ) < 2 ) : ?>
		<p class="muted" style="margin:0">L'historique se construit mois après mois : une photo du poste client est prise à chaque ouverture du
			tableau de bord et à chaque passage planifié, et la dernière du mois fait foi. Les tendances apparaissent à partir du deuxième mois.</p>
	<?php endif; ?>
		<div style="display:flex;align-items:flex-end;gap:6px;height:180px;padding-top:6px;overflow-x:auto" role="img" aria-label="Encours en fin de mois, en retard et non échu">
			<?php foreach ( $historique as $h ) :
				$hr = (float) $h['retard'] / $maxEnc * 160; $hn = max( 0.0, (float) $h['encours'] - (float) $h['retard'] ) / $maxEnc * 160;
				$tip = $libMois( $h['mois'] ) . ' — encours ' . fkc_money( $h['encours'] ) . ' F, dont ' . fkc_money( $h['retard'] ) . ' F en retard'; ?>
				<div title="<?= e( $tip ) ?>" style="flex:1;min-width:40px;display:flex;flex-direction:column;align-items:center;gap:4px">
					<div style="width:70%;max-width:36px;display:flex;flex-direction:column;justify-content:flex-end;height:160px">
						<?php if ( $hn > 0 ) : ?><div style="height:<?= round( $hn, 1 ) ?>px;background:var(--ok);border-radius:4px 4px 0 0;margin-bottom:2px"></div><?php endif; ?>
						<?php if ( $hr > 0 ) : ?><div style="height:<?= round( $hr, 1 ) ?>px;background:var(--orange);border-radius:<?= $hn > 0 ? '0' : '4px 4px 0 0' ?>"></div><?php endif; ?>
					</div>
					<span class="muted" style="font-size:.72em;white-space:nowrap"><?= e( $libMois( $h['mois'] ) ) ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>

<div class="card card-flush"><div class="card-head"><h2>Historique mensuel</h2></div>
<div style="overflow-x:auto"><table class="table">
	<thead><tr><th>Mois</th><th class="num">Facturé</th><th class="num">Encaissé</th><th class="num">Encours fin</th><th class="num">En retard</th><th class="num">+ 90 j</th><th class="num">DSO</th><th class="num">DSO 90 j</th><th class="num">CEI</th></tr></thead>
	<tbody>
	<?php if ( ! $historique ) : ?><tr><td colspan="9" class="empty">Aucune photo pour l'instant.</td></tr><?php endif; ?>
	<?php foreach ( array_reverse( $historique ) as $h ) : ?>
		<tr><td><?= e( $libMois( $h['mois'] ) ) ?><?= date( 'Y-m' ) === $h['mois'] ? ' <span class="muted" style="font-size:.8em">(en cours)</span>' : '' ?></td>
			<td class="num"><?= e( fkc_money( $h['facture_mois'] ) ) ?></td>
			<td class="num"><?= e( fkc_money( $h['encaisse_mois'] ) ) ?></td>
			<td class="num"><strong><?= e( fkc_money( $h['encours'] ) ) ?></strong></td>
			<td class="num"><?= e( fkc_money( $h['retard'] ) ) ?></td>
			<td class="num"><?= (float) $h['b90p'] > 0 ? e( fkc_money( $h['b90p'] ) ) : '—' ?></td>
			<td class="num"><?= (int) $h['dso'] ?> j</td>
			<td class="num"><?= (int) $h['dso_90'] ?> j</td>
			<td class="num"><?= null !== $h['cei'] ? e( $h['cei'] ) . ' %' . ( date( 'Y-m' ) === $h['mois'] ? ' <span class="muted" style="font-size:.8em">provisoire</span>' : '' ) : '—' ?></td></tr>
	<?php endforeach; ?>
	</tbody>
</table></div></div>

<div class="card card-flush">
	<div class="card-head"><h2>Équipe de recouvrement</h2>
		<span><?php foreach ( array( 30 => '30 j', 90 => '90 j', 365 => '12 mois' ) as $j => $lib ) : ?>
			<a class="btn btn-sm <?= $periode === $j ? 'btn-primary' : 'btn-ghost' ?>" href="<?= e( url( 'recouvrement/pilotage' ) . '?jours=' . $j ) ?>"><?= e( $lib ) ?></a>
		<?php endforeach; ?></span>
	</div>
	<div style="overflow-x:auto"><table class="table">
		<thead><tr><th>Agent</th><th class="num">Relances</th><th class="num">Appels</th><th class="num">Mises en demeure</th><th class="num">Suivis d'un paiement</th><th class="num">Promesses</th><th class="num">Montant promis</th><th class="num">Tenues</th></tr></thead>
		<tbody>
		<?php if ( ! $agents ) : ?><tr><td colspan="8" class="empty">Aucune action de recouvrement sur la période.</td></tr><?php endif; ?>
		<?php foreach ( $agents as $a ) : $conclues = $a['promesses_tenues'] + $a['promesses_non_tenues']; ?>
			<tr><td><strong><?= e( $a['nom'] ) ?></strong></td>
				<td class="num"><?= (int) $a['relances'] ?></td>
				<td class="num"><?= (int) $a['appels'] ?></td>
				<td class="num"><?= (int) $a['mises_en_demeure'] ?></td>
				<td class="num"><?= null !== $a['taux_effet'] ? (int) $a['taux_effet'] . ' %' : '—' ?></td>
				<td class="num"><?= (int) $a['promesses'] ?></td>
				<td class="num"><?= e( fkc_money( $a['montant_promis'] ) ) ?></td>
				<td class="num"><?= $conclues > 0 ? (int) $a['promesses_tenues'] . ' / ' . $conclues : '—' ?></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
	<p class="help" style="padding:0 12px 12px;margin:0">« Suivis d'un paiement » : part des contacts suivis d'un encaissement du client sous
		<?= (int) FKC_RecouvrementPilotage::FENETRE_EFFET ?> jours. C'est une association, pas une preuve : elle se lit avec le volume de contacts.</p>
</div>
