<?php /** @var array $client @var array|null $stats @var array $actions @var array $promesses @var array $plans @var array|null $dossier @var int $seuil @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$s = $stats ?: array( 'encours' => 0, 'retard' => 0, 'a_risque' => 0, 'score' => 100, 'risque' => 'faible', 'jours_max' => 0 );
$scoreCol = $s['score'] >= 75 ? 'var(--ok)' : ( $s['score'] >= 45 ? 'var(--orange)' : 'var(--danger)' );
$types = FKC_RecouvrementSuivi::typesAction();
$cid = (int) $client['id']; ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'clients' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar">
	<span><strong style="font-size:1.1em"><?= e( $client['nom'] ) ?></strong> <span class="muted"><?= e( $client['telephone'] ?? '' ) ?></span> · <?= e( FKC_Recouvrement::risqueLabel( $s['risque'] ) ) ?></span>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/clients' ) ) ?>">← <?= e( FKC_Recouvrement::motDebiteur() ) ?></a>
</div>

<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Encours</span><div style="font-size:1.3em;font-weight:700"><?= e( fkc_money( $s['encours'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">En retard</span><div style="font-size:1.3em;font-weight:700;color:var(--orange)"><?= e( fkc_money( $s['retard'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">À risque</span><div style="font-size:1.3em;font-weight:700;color:var(--danger)"><?= e( fkc_money( $s['a_risque'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Score payeur</span><div style="font-size:1.3em;font-weight:700;color:<?= $scoreCol ?>"><?= (int) $s['score'] ?>/100</div><span class="muted" style="font-size:.82em"><?= e( FKC_Recouvrement::scoreLabel( $s['score'] ) ) ?></span></div></div>
</div>

<div class="bar" style="gap:8px;flex-wrap:wrap">
	<a class="btn btn-primary btn-sm" href="<?= e( url( 'recouvrement/clients/' . $cid . '/mise-en-demeure' ) ) ?>" target="_blank">📄 Mise en demeure (PDF)</a>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/plans' ) ) ?>">Plan d'apurement</a>
	<?php if ( ! $dossier && $s['jours_max'] >= $seuil && $s['encours'] > 0 ) : ?>
		<form method="post" action="<?= e( url( 'recouvrement/dossiers/basculer' ) ) ?>" onsubmit="return confirm('Basculer en précontentieux ?')" style="display:inline">
			<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= $cid ?>"><input type="hidden" name="montant" value="<?= (int) $s['encours'] ?>">
			<button class="btn btn-ghost btn-sm" type="submit">⚠ Basculer en précontentieux</button>
		</form>
	<?php elseif ( $dossier ) : ?>
		<span class="modbadge b-off">Dossier <?= e( FKC_RecouvrementSuivi::statutsDossier()[ $dossier['statut'] ] ?? $dossier['statut'] ) ?></span>
	<?php endif; ?>
</div>

<?php if ( ! empty( $ouvertes ) ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Créances ouvertes (<?= count( $ouvertes ) ?>)</h2></div><table class="table">
	<thead><tr><th>Pièce</th><th>Échéance</th><th class="num">Reste dû</th><th class="num">Retard</th><th>Situation</th></tr></thead>
	<tbody><?php foreach ( $ouvertes as $o ) : ?>
		<tr><td class="code"><?= e( ( ! empty( $o['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $o['source'] ) . ' ' : '' ) . ( $o['numero'] ?: 'n°' . (int) $o['facture_id'] ) ) ?></td>
			<td class="code"><?= e( date( 'd/m/Y', strtotime( $o['echeance'] ) ) ) ?></td>
			<td class="num"><?= e( fkc_money( $o['montant'] ) ) ?></td>
			<td class="num"><?= $o['jours'] > 0 ? (int) $o['jours'] . ' j' : '—' ?></td>
			<td><?php if ( ! empty( $o['douteuse'] ) ) : ?><span class="modbadge b-off">Douteuse (provisionnée)</span> <?php endif; ?>
				<?= ! empty( $o['suspendu'] ) ? '<span class="modbadge">' . e( $o['suspendu'] ) . '</span>' : '' ?></td></tr>
	<?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>

<div class="form-rows">
	<div class="card">
		<div class="card-head"><h2>Enregistrer une action</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url( 'recouvrement/clients/' . $cid . '/action' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Type</span><select name="type"><option value="appel">Appel</option><option value="note">Note</option><option value="litige">Litige</option></select></label>
				<label class="fld"><span>Détail</span><textarea name="detail" rows="2" placeholder="Compte rendu, litige, engagement…"></textarea></label>
				<button class="btn btn-primary btn-sm" type="submit">Ajouter</button>
			</form>
		</div>
	</div>
	<div class="card">
		<div class="card-head"><h2>Promesse de paiement</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url( 'recouvrement/clients/' . $cid . '/promesse' ) ) ?>">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Facture concernée</span><select name="facture_id">
					<option value="">Tout le compte du client</option>
					<?php foreach ( ( $ouvertes ?? array() ) as $o ) : if ( empty( $o['facture_id'] ) ) { continue; } ?>
						<option value="<?= (int) $o['facture_id'] ?>"><?= e( ( $o['numero'] ?: 'n°' . (int) $o['facture_id'] ) . ' — ' . fkc_money( $o['montant'] ) . ' F' . ( $o['jours'] > 0 ? ' · ' . (int) $o['jours'] . ' j de retard' : ' · non échue' ) ) ?></option>
					<?php endforeach; ?>
				</select></label>
				<p class="help" style="margin:0 0 6px">Une promesse sur une facture ne suspend la relance que de cette facture.</p>
				<label class="fld"><span>Montant promis (FCFA)</span><input type="number" name="montant" min="0" value="<?= (int) $s['retard'] ?>"></label>
				<label class="fld"><span>Date promise</span><input type="date" name="date_promesse" value="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<label class="fld"><span>Note</span><input type="text" name="note"></label>
				<button class="btn btn-primary btn-sm" type="submit">Enregistrer la promesse</button>
			</form>
		</div>
	</div>
</div>

<?php if ( $promesses ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Promesses</h2></div><table class="table">
	<thead><tr><th>Date</th><th class="num">Montant</th><th>Statut</th><th>Note</th><th></th></tr></thead>
	<tbody><?php foreach ( $promesses as $p ) : ?>
		<tr><td class="code"><?= e( $p['date_promesse'] ) ?></td><td class="num"><?= e( fkc_money( $p['montant'] ) ) ?></td>
			<td><span class="modbadge <?= 'tenue'===$p['statut']?'b-on':('non_tenue'===$p['statut']?'b-off':'') ?>"><?= e( FKC_RecouvrementSuivi::statutsPromesse()[ $p['statut'] ] ?? $p['statut'] ) ?></span></td>
			<td class="muted"><?= e( $p['note'] ?: '—' ) ?></td>
			<td class="right">
				<?php if ( 'en_attente' === $p['statut'] ) : ?>
				<form method="post" action="<?= e( url( 'recouvrement/promesses/' . (int) $p['id'] . '/statut' ) ) ?>" style="display:inline">
					<?= FKC_Csrf::field() ?><input type="hidden" name="retour" value="recouvrement/clients/<?= $cid ?>">
					<button class="btn btn-ghost btn-sm" type="submit" name="statut" value="tenue">Tenue</button>
					<button class="btn btn-ghost btn-sm" type="submit" name="statut" value="non_tenue">Non tenue</button>
				</form>
				<?php endif; ?>
			</td></tr>
	<?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>

<div class="card card-flush"><div class="card-head"><h2>Historique</h2></div><table class="table">
	<thead><tr><th>Date</th><th>Type</th><th>Canal</th><th>Détail</th></tr></thead>
	<tbody>
	<?php if ( ! $actions ) : ?><tr><td colspan="4" class="empty">Aucune action.</td></tr>
	<?php else : foreach ( $actions as $a ) : ?>
		<tr><td class="code"><?= e( $a['created_at'] ) ?></td><td><?= e( $types[ $a['type'] ] ?? $a['type'] ) ?></td><td class="muted"><?= e( $a['canal'] ?: '—' ) ?></td><td><?= e( $a['detail'] ?: '—' ) ?></td></tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
