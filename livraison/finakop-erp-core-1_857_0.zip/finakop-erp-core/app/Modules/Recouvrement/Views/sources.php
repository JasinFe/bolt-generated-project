<?php /**
 * Sources de créances (1.841.2).
 *
 * Ce que le recouvrement suit EN PLUS des factures : cotisations, pièces des
 * dossiers métiers, scolarité, loyers. Pour chaque source, l'encours, le
 * retard, et ce qui ne peut pas encore être relancé faute de fiche client.
 *
 * @var array $synthese @var array $erreurs @var array $kpis @var array|null $flash
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$origines = (array) ( $kpis['origines'] ?? array() );
$aRattacher = false;
foreach ( $synthese as $s ) { if ( $s['rattachable'] && ( $s['sans_client'] > 0 || ( $s['non_rattachees'] ?? 0 ) > 0 ) ) { $aRattacher = true; } }
?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'sources' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="card"><div class="card-body">
	<p style="margin:0">Le recouvrement suit les <strong>factures</strong> et, avec elles, les créances que les métiers
		constatent ailleurs. Toutes entrent dans le même lettrage que le compte client : un paiement de cotisation
		n'éteint plus une facture, et un loyer impayé se relance comme une facture échue.</p>
</div></div>

<div class="form-grid" style="margin-bottom:18px">
	<div class="card"><div class="card-body">
		<span class="muted">Factures</span>
		<div style="font-size:1.4em;font-weight:700"><?= e( fkc_money( $origines['factures'] ?? 0 ) ) ?></div>
		<span class="muted" style="font-size:.85em">encours</span>
	</div></div>
	<?php foreach ( $synthese as $s ) : if ( $s['lignes'] <= 0 && ! ( $s['non_rattachees'] ?? 0 ) ) { continue; } ?>
	<div class="card"><div class="card-body">
		<span class="muted"><?= e( $s['libelle'] ) ?></span>
		<div style="font-size:1.4em;font-weight:700"><?= e( fkc_money( $s['encours'] ) ) ?></div>
		<span class="muted" style="font-size:.85em">dont <?= e( fkc_money( $s['retard'] ) ) ?> en retard · <?= (int) $s['lignes'] ?> pièce(s)</span>
	</div></div>
	<?php endforeach; ?>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Détail par source</h2>
		<?php if ( $aRattacher ) : ?>
		<form method="post" action="<?= e( url( 'recouvrement/sources/rattacher' ) ) ?>" style="display:inline"
			onsubmit="return confirm('Créer ou reprendre une fiche client pour chaque débiteur non rattaché ?')">
			<?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" type="submit">Rattacher les tiers</button>
		</form>
		<?php endif; ?>
	</div>
	<table class="table">
		<thead><tr><th>Source</th><th class="num">Encours</th><th class="num">En retard</th><th class="num">Pièces</th><th class="num">Sans fiche client</th><th></th></tr></thead>
		<tbody><?php $vide = true; foreach ( $synthese as $code => $s ) :
			// Une source sans pièce, sans tiers en attente et sans erreur n'a rien à dire (1.841.6).
			if ( $s['lignes'] <= 0 && ! ( $s['non_rattachees'] ?? 0 ) && ! isset( $erreurs[ $code ] ) ) { continue; } $vide = false; ?>
			<tr>
				<td><strong><?= e( $s['libelle'] ) ?></strong><?= isset( $erreurs[ $code ] ) ? ' <span class="modbadge b-off" title="' . e( $erreurs[ $code ] ) . '">lecture impossible</span>' : '' ?></td>
				<td class="num"><?= e( fkc_money( $s['encours'] ) ) ?></td>
				<td class="num"><?= $s['retard'] > 0 ? e( fkc_money( $s['retard'] ) ) : '—' ?></td>
				<td class="num"><?= (int) $s['lignes'] ?></td>
				<td class="num"><?php
					if ( $s['sans_client'] > 0 ) { echo e( fkc_money( $s['sans_client'] ) ); }
					elseif ( null !== $s['non_rattachees'] && $s['non_rattachees'] > 0 ) { echo (int) $s['non_rattachees'] . ( 'pieces' === $code ? ' pièce(s) hors suivi' : ' tiers' ); }
					else { echo '—'; } ?></td>
				<td class="muted" style="font-size:.85em"><?= 'pieces' === $code && ( $s['non_rattachees'] ?? 0 ) > 0
					? 'Dossiers sans client : renseignez le client du dossier pour suivre ses pièces.' : '' ?></td>
			</tr>
		<?php endforeach; if ( $vide ) : ?><tr><td colspan="6" class="empty">Aucune créance hors factures dans ce dossier.</td></tr><?php endif; ?></tbody>
	</table>
</div>
<p class="help">Une source n'apparaît que si le module ou le pack qui la porte a été utilisé dans ce dossier. Les pièces des dossiers métiers
	ne sont suivies que lorsqu'elles ont débité le compte client (411) : une vente au comptant n'est pas une créance.</p>
