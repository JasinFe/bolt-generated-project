<?php /** @var array $retards @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'centre' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Centre d'appels — factures en retard, de la plus ancienne à la plus récente · <?= count( $retards ) ?> ligne(s)</span></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th><?= e( FKC_Recouvrement::motDebiteur( false ) ) ?></th><th>Téléphone</th><th>Facture</th><th>Échéance</th><th class="num">Montant</th><th class="num">Retard</th><th>Tranche</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $retards ) : ?><tr><td colspan="8" class="empty">Aucune facture en retard. 🎉</td></tr>
	<?php else : foreach ( $retards as $f ) : ?>
		<tr>
			<td><a href="<?= e( url( 'recouvrement/clients/' . (int) $f['client_id'] ) ) ?>"><strong><?= e( $f['client_nom'] ) ?></strong></a><?php if ( 0 === (int) $f['client_id'] && ! empty( $f['tiers_nom'] ) ) : ?><br><span class="muted" style="font-size:.85em"><?= e( $f['tiers_nom'] ) ?></span><?php endif; ?></td>
			<td><?php if ( $f['telephone'] ) : ?><a href="tel:<?= e( preg_replace( '/\s+/', '', $f['telephone'] ) ) ?>"><?= e( $f['telephone'] ) ?></a><?php else : ?><span class="muted">—</span><?php endif; ?></td>
			<td class="code"><?= e( ( ! empty( $f['source'] ) && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $f['source'] ) . ' ' : '' ) . ( ( $f['numero'] ?? '' ) ?: 'n°' . (int) $f['facture_id'] ) ) ?></td>
			<td class="code"><?= e( date( 'd/m/Y', strtotime( $f['echeance'] ) ) ) ?></td>
			<td class="num"><?= e( fkc_money( $f['montant'] ) ) ?></td>
			<td class="num" style="color:var(--danger)"><?= (int) $f['jours'] ?> j</td>
			<td><span class="modbadge <?= 'b90p' === $f['bucket'] ? 'b-off' : '' ?>"><?= e( FKC_Recouvrement::bucketLabel( $f['bucket'] ) ) ?></span></td>
			<td class="right"><a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/clients/' . (int) $f['client_id'] ) ) ?>">Traiter</a></td>
		</tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
