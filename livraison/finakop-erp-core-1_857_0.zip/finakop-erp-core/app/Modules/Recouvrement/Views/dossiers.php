<?php /** @var array $dossiers @var array $eligibles @var array $statuts @var int $seuil @var array|null $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' ); ?>
<?php FKC_View::partial( 'recouvrement::_subnav', array( 'tab' => 'dossiers' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err' === $flash['type'] ? 'err' : 'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Dossiers précontentieux — bascule automatique au-delà de <?= (int) $seuil ?> jours de retard</span></div>

<?php if ( $eligibles ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Clients éligibles à la bascule (<?= count( $eligibles ) ?>)</h2></div>
<table class="table">
	<thead><tr><th>Client</th><th class="num">Encours</th><th class="num">Retard max</th><th>Risque</th><th></th></tr></thead>
	<tbody><?php foreach ( $eligibles as $c ) : ?>
		<tr><td><a href="<?= e( url( 'recouvrement/clients/' . (int) $c['id'] ) ) ?>"><?= e( $c['nom'] ) ?></a></td>
			<td class="num"><?= e( fkc_money( $c['encours'] ) ) ?></td><td class="num" style="color:var(--danger)"><?= (int) $c['jours_max'] ?> j</td>
			<td><?= e( FKC_Recouvrement::risqueLabel( $c['risque'] ) ) ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'recouvrement/dossiers/basculer' ) ) ?>" style="display:inline" onsubmit="return confirm('Basculer en précontentieux ?')">
				<?= FKC_Csrf::field() ?><input type="hidden" name="client_id" value="<?= (int) $c['id'] ?>"><input type="hidden" name="montant" value="<?= (int) $c['encours'] ?>">
				<button class="btn btn-primary btn-sm" type="submit">Basculer</button></form></td></tr>
	<?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>

<div class="card card-flush"><div class="card-head"><h2>Dossiers ouverts</h2></div>
<table class="table">
	<thead><tr><th>Client</th><th class="num">Montant</th><th>Ouvert le</th><th>Statut</th><th>Motif</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $dossiers ) : ?><tr><td colspan="6" class="empty">Aucun dossier précontentieux.</td></tr>
	<?php else : foreach ( $dossiers as $d ) : ?>
		<tr><td><a href="<?= e( url( 'recouvrement/clients/' . (int) $d['client_id'] ) ) ?>"><?= e( $d['client_nom'] ?: '—' ) ?></a></td>
			<td class="num"><?= e( fkc_money( $d['montant'] ) ) ?></td><td class="code"><?= e( $d['date_bascule'] ) ?></td>
			<td><span class="modbadge <?= 'clos'===$d['statut']?'b-on':'b-off' ?>"><?= e( $statuts[ $d['statut'] ] ?? $d['statut'] ) ?></span></td>
			<td class="muted"><?= e( $d['motif'] ?: '—' ) ?></td>
			<td class="right">
				<a class="btn btn-ghost btn-sm" href="<?= e( url( 'recouvrement/clients/' . (int) $d['client_id'] . '/mise-en-demeure' ) ) ?>" target="_blank">Mise en demeure</a>
				<form method="post" action="<?= e( url( 'recouvrement/dossiers/' . (int) $d['id'] . '/statut' ) ) ?>" style="display:inline">
					<?= FKC_Csrf::field() ?>
					<select name="statut" onchange="this.form.submit()">
						<?php foreach ( $statuts as $k => $lib ) : ?><option value="<?= e( $k ) ?>" <?= $k===$d['statut']?'selected':'' ?>><?= e( $lib ) ?></option><?php endforeach; ?>
					</select>
				</form>
			</td></tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
