<?php
/**
 * Paramétrage des politiques internes : relances et validation.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_PolitiqueController {

	/*
	 * Le message porte désormais son type : un refus (« Deux paliers au même
	 * jour ») s'affichait avec la même présentation qu'un succès (1.841.1).
	 * Clé propre au contrôleur : la clé générique était partagée.
	 */
	protected function flash() { $f = $_SESSION['fkc_flash_politique'] ?? null; unset( $_SESSION['fkc_flash_politique'] ); return $f; }
	protected function setFlash( $m, $ok = true ) { $_SESSION['fkc_flash_politique'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => (string) $m ); }

	public function index() {
		FKC_View::render( 'recouvrement::politiques', array(
			'title' => 'Recouvrement · Politiques internes', 'tab' => 'politiques',
			'paliers' => FKC_PolitiqueRelance::paliers(),
			'perso_relance' => FKC_PolitiqueRelance::estPersonnalisee(),
			'seuil_montant' => FKC_PolitiqueRelance::seuilMontant(),
			'canaux' => FKC_PolitiqueRelance::canaux(),
			'tons' => FKC_PolitiqueRelance::tons(),
			'niveaux' => FKC_WorkflowValidation::seuils(),
			'roles' => FKC_WorkflowValidation::rolesDisponibles(),
			'perso_wf' => FKC_WorkflowValidation::estPersonnalise(),
			'flash' => $this->flash(),
			'peut_modifier' => FKC_Auth::isAdmin(),
			'paiement' => FKC_RecouvrementReglages::paiement(),
			'penalites' => FKC_RecouvrementReglages::penalites(),
			'operateurs' => FKC_RecouvrementReglages::operateurs(),
		) );
	}

	/**
	 * Les lignes arrivent en tableaux parallèles depuis le formulaire.
	 * On recompose, puis on laisse le modèle valider : c'est lui qui connaît
	 * les règles, et les dupliquer ici les ferait diverger.
	 */
	public function relances() {
		$p = array();
		foreach ( (array) ( $_POST['jours'] ?? array() ) as $i => $j ) {
			if ( '' === trim( (string) $j ) ) { continue; }
			$p[] = array(
				'jours' => (int) $j,
				'canal' => $_POST['canal'][ $i ] ?? 'email',
				'ton' => $_POST['ton'][ $i ] ?? 'ferme',
				'libelle' => $_POST['libelle'][ $i ] ?? '',
				'min_jours_entre' => (int) ( $_POST['min_jours_entre'][ $i ] ?? 7 ),
			);
		}
		list( $ok, $msg ) = FKC_PolitiqueRelance::definir( $p );
		// Le seuil n'est enregistré qu'avec des paliers valides : un
		// formulaire refusé ne doit rien changer à moitié.
		if ( $ok ) { FKC_License::setParam( 'relance_seuil_montant', max( 0.0, (float) ( $_POST['seuil_montant'] ?? 0 ) ) ); }
		$this->setFlash( $msg, $ok );
		redirect( 'recouvrement/politiques' );
	}

	public function workflow() {
		$n = array();
		foreach ( (array) ( $_POST['seuil'] ?? array() ) as $i => $s ) {
			if ( '' === trim( (string) $s ) ) { continue; }
			$n[] = array( 'seuil' => (float) $s, 'role' => $_POST['role'][ $i ] ?? '',
				'libelle' => $_POST['niveau_libelle'][ $i ] ?? '' );
		}
		list( $ok, $msg ) = FKC_WorkflowValidation::definir( $n );
		$this->setFlash( $msg, $ok );
		redirect( 'recouvrement/politiques' );
	}

	/** Moyens de paiement cités dans les relances (1.841.4). */
	public function paiement() {
		list( $ok, $msg ) = FKC_RecouvrementReglages::definirPaiement( array(
			'numeros' => (array) ( $_POST['numeros'] ?? array() ), 'lien' => $_POST['lien'] ?? '', 'instructions' => $_POST['instructions'] ?? '',
		) );
		$this->setFlash( $msg, $ok );
		redirect( 'recouvrement/politiques' );
	}

	/** Pénalités de retard (1.841.4). */
	public function penalites() {
		list( $ok, $msg ) = FKC_RecouvrementReglages::definirPenalites( array(
			'actif' => ! empty( $_POST['actif'] ), 'taux_mensuel' => $_POST['taux_mensuel'] ?? 0,
			'grace' => $_POST['grace'] ?? 0, 'forfait' => $_POST['forfait'] ?? 0,
		) );
		$this->setFlash( $msg, $ok );
		redirect( 'recouvrement/politiques' );
	}

	public function reinit() {
		$quoi = $_POST['quoi'] ?? '';
		if ( 'relance' === $quoi )  { list( , $msg ) = FKC_PolitiqueRelance::reinitialiser(); }
		elseif ( 'workflow' === $quoi ) { list( , $msg ) = FKC_WorkflowValidation::reinitialiser(); }
		else { $msg = 'Rien à réinitialiser.'; }
		$this->setFlash( $msg );
		redirect( 'recouvrement/politiques' );
	}
}
