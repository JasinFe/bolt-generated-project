<?php
/** Module Recouvrement : pilotage, balance âgée, scoring, relances, contentieux. @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RecouvrementController {

	/* ---------- Tableau de bord ---------- */
	public function dashboard() {
		$this->constaterPromesses();
		$d = FKC_Recouvrement::compute();
		// Photo du mois (1.841.5) : la dernière du mois fait foi pour l'historique.
		try { FKC_RecouvrementPilotage::photographier( $d ); } catch ( \Throwable $e ) {}
		FKC_View::render( 'recouvrement::dashboard', array(
			'title' => 'Recouvrement · Tableau de bord', 'tab' => 'dashboard',
			'kpis' => $d['kpis'], 'clients' => $d['clients'], 'flash' => $this->flash(),
		) );
	}

	/* ---------- Balance âgée ---------- */
	public function agee() {
		$d = FKC_Recouvrement::compute();
		$lignes = array_filter( $d['clients'], function ( $c ) { return $c['encours'] > 0; } );
		usort( $lignes, function ( $a, $b ) { return $b['encours'] <=> $a['encours']; } );
		FKC_View::render( 'recouvrement::agee', array(
			'title' => 'Recouvrement · Balance âgée', 'tab' => 'agee',
			'lignes' => $lignes, 'kpis' => $d['kpis'], 'flash' => $this->flash(),
		) );
	}

	/* ---------- Classement clients (score / risque / encours) ---------- */
	public function clients() {
		$d = FKC_Recouvrement::compute();
		$tri = $_GET['tri'] ?? 'risque';
		$lignes = array_values( $d['clients'] );
		usort( $lignes, function ( $a, $b ) use ( $tri ) {
			if ( 'score' === $tri ) { return $a['score'] <=> $b['score']; }
			if ( 'encours' === $tri ) { return $b['encours'] <=> $a['encours']; }
			return $b['a_risque'] <=> $a['a_risque'];
		} );
		FKC_View::render( 'recouvrement::clients', array(
			'title' => 'Recouvrement · ' . FKC_Recouvrement::motDebiteur(), 'tab' => 'clients',
			'lignes' => $lignes, 'tri' => $tri, 'flash' => $this->flash(),
		) );
	}

	/* ---------- Centre d'appels (worklist des retards) ---------- */
	public function centre() {
		$this->constaterPromesses();
		$d = FKC_Recouvrement::compute();
		$retards = array_values( array_filter( $d['factures'], function ( $f ) { return $f['jours'] > 0; } ) );
		FKC_View::render( 'recouvrement::centre', array(
			'title' => 'Recouvrement · Centre d\'appels', 'tab' => 'centre',
			'retards' => $retards, 'flash' => $this->flash(),
		) );
	}

	/* ---------- Fiche client ---------- */
	public function fiche( $id ) {
		$this->constaterPromesses();
		$d = FKC_Recouvrement::compute();
		$stats = FKC_Recouvrement::client( $id, $d );
		$client = FKC_Client::find( $id );
		if ( ! $client ) { redirect( 'recouvrement/clients' ); }
		// Factures ouvertes du client : c'est sur l'une d'elles que porte,
		// en général, une promesse de paiement (1.841.1).
		$ouvertes = array_values( array_filter( $d['factures'], function ( $f ) use ( $id ) { return (int) $f['client_id'] === (int) $id; } ) );
		FKC_View::render( 'recouvrement::fiche', array(
			'title' => 'Recouvrement · ' . $client['nom'], 'tab' => 'clients',
			'client' => $client, 'stats' => $stats, 'ouvertes' => $ouvertes,
			'actions' => FKC_RecouvrementSuivi::actions( $id ),
			'promesses' => FKC_RecouvrementSuivi::promessesClient( $id ),
			'plans' => FKC_RecouvrementSuivi::plans( $id ),
			'dossier' => FKC_RecouvrementSuivi::dossierActif( $id ),
			'seuil' => FKC_Recouvrement::seuilPrecontentieux(),
			'flash' => $this->flash(),
		) );
	}

	public function action( $id ) {
		$type = in_array( $_POST['type'] ?? 'note', array( 'appel', 'note', 'litige' ), true ) ? ( $_POST['type'] ?? 'note' ) : 'note';
		FKC_RecouvrementSuivi::ajouterAction( (int) $id, (int) ( $_POST['facture_id'] ?? 0 ) ?: null, $type, $_POST['detail'] ?? '' );
		$this->setFlash( 'Action enregistrée.' );
		redirect( 'recouvrement/clients/' . (int) $id );
	}
	public function promesse( $id ) {
		/*
		 * La facture visée doit appartenir au client : une promesse ne
		 * suspend désormais QUE sa facture (1.841.1), et un identifiant venu
		 * d'un formulaire modifié suspendrait la relance d'un autre client.
		 */
		$fid = (int) ( $_POST['facture_id'] ?? 0 );
		if ( $fid ) {
			$proprio = FKC_DB::q( 'SELECT client_id FROM factures WHERE id=?', array( $fid ) )->fetchColumn();
			if ( (int) $proprio !== (int) $id ) { $fid = 0; }
		}
		if ( (float) ( $_POST['montant'] ?? 0 ) <= 0 ) {
			$this->setFlash( 'Le montant promis doit être positif.', 'err' );
			redirect( 'recouvrement/clients/' . (int) $id );
		}
		FKC_RecouvrementSuivi::ajouterPromesse( (int) $id, $fid ?: null, (float) ( $_POST['montant'] ?? 0 ), $_POST['date_promesse'] ?? date( 'Y-m-d' ), $_POST['note'] ?? '' );
		$this->setFlash( 'Promesse de paiement enregistrée.' );
		redirect( 'recouvrement/clients/' . (int) $id );
	}

	/* ---------- Promesses (liste globale) ---------- */
	public function promesses() {
		$this->constaterPromesses();
		FKC_View::render( 'recouvrement::promesses', array(
			'title' => 'Recouvrement · Promesses de paiement', 'tab' => 'promesses',
			'promesses' => FKC_RecouvrementSuivi::promesses(), 'statuts' => FKC_RecouvrementSuivi::statutsPromesse(), 'flash' => $this->flash(),
		) );
	}
	public function promesseStatut( $id ) {
		FKC_RecouvrementSuivi::statutPromesse( (int) $id, $_POST['statut'] ?? '' );
		$this->setFlash( 'Statut de la promesse mis à jour.' );
		// Le retour est d'origine utilisateur : redirect() le ramène désormais à
		// une URL interne, mais on garde un repli explicite plutôt que
		// l'accueil si le champ est absent.
		$retour = trim( (string) ( $_POST['retour'] ?? '' ) );
		redirect( '' !== $retour ? $retour : 'recouvrement/promesses' );
	}

	/* ---------- Plans d'apurement ---------- */
	public function anomalies() {
		$d = FKC_Recouvrement::compute();
		FKC_View::render( 'recouvrement::anomalies', array(
			'title' => 'Recouvrement · Anomalies', 'tab' => 'anomalies',
			'anomalies' => FKC_Recouvrement::anomalies( $d ),
			'kpis' => $d['kpis'], 'flash' => $this->flash(),
		) );
	}

	public function plans() {
		/*
		 * Les échéances sont chargées ICI, et non dans la boucle de la vue qui
		 * rappelait plan() pour chaque plan affiché. L'état réel (échéances
		 * échues impayées) y est joint : c'est lui qui décide si le plan
		 * protège encore son client de la relance, et l'écran doit le dire.
		 */
		$plans = array();
		foreach ( FKC_RecouvrementSuivi::plans() as $pl ) {
			$full = FKC_RecouvrementSuivi::plan( (int) $pl['id'] );
			if ( ! $full ) { continue; }
			$full['client_nom'] = $pl['client_nom'] ?? null;
			$full['etat'] = FKC_RecouvrementSuivi::etatPlan( (int) $pl['id'] );
			$plans[] = $full;
		}
		FKC_View::render( 'recouvrement::plans', array(
			'title' => 'Recouvrement · Plans d\'apurement', 'tab' => 'plans',
			'plans' => $plans, 'clients' => FKC_Client::all( true ),
			'statuts' => FKC_RecouvrementSuivi::statutsPlan(), 'flash' => $this->flash(),
		) );
	}
	public function planCreer() {
		$cid = (int) ( $_POST['client_id'] ?? 0 );
		if ( ! $cid || (float) ( $_POST['montant_total'] ?? 0 ) <= 0 ) { $this->setFlash( 'Client et montant requis.', 'err' ); redirect( 'recouvrement/plans' ); }
		FKC_RecouvrementSuivi::creerPlan( $cid, (float) $_POST['montant_total'], (int) ( $_POST['nb_echeances'] ?? 1 ), $_POST['premiere_date'] ?? date( 'Y-m-d' ), $_POST['note'] ?? '' );
		$this->setFlash( 'Plan d\'apurement créé.' );
		redirect( 'recouvrement/plans' );
	}
	public function planEcheance( $id ) {
		FKC_RecouvrementSuivi::echeancePayee( (int) $id );
		$this->setFlash( 'Échéance marquée payée.' );
		redirect( 'recouvrement/plans' );
	}

	/* ---------- Dossiers précontentieux ---------- */
	public function dossiers() {
		$d = FKC_Recouvrement::compute();
		$seuil = FKC_Recouvrement::seuilPrecontentieux();
		// Les dossiers ouverts sont lus UNE fois, pas une fois par client :
		// l'écran interrogeait la base autant de fois qu'il y a de clients,
		// pour une liste qui tient dans un seul SELECT.
		$ouverts = array();
		foreach ( FKC_RecouvrementSuivi::dossiers() as $dd ) {
			if ( 'clos' !== (string) ( $dd['statut'] ?? '' ) ) { $ouverts[ (int) $dd['client_id'] ] = true; }
		}
		$eligibles = array();
		foreach ( $d['clients'] as $c ) {
			// Le poste collectif « créances sans client rattaché » n'a pas de
			// fiche : on ne peut ni le mettre en demeure ni le poursuivre.
			if ( 0 === (int) $c['id'] ) { continue; }
			if ( $c['jours_max'] >= $seuil && $c['encours'] > 0 && ! isset( $ouverts[ (int) $c['id'] ] ) ) { $eligibles[] = $c; }
		}
		FKC_View::render( 'recouvrement::dossiers', array(
			'title' => 'Recouvrement · Précontentieux', 'tab' => 'dossiers',
			'dossiers' => FKC_RecouvrementSuivi::dossiers(), 'eligibles' => $eligibles,
			'statuts' => FKC_RecouvrementSuivi::statutsDossier(), 'seuil' => $seuil, 'flash' => $this->flash(),
		) );
	}
	public function dossierBasculer() {
		$cid = (int) ( $_POST['client_id'] ?? 0 );
		list( $ok, $msg ) = FKC_RecouvrementSuivi::basculer( $cid, (float) ( $_POST['montant'] ?? 0 ), $_POST['motif'] ?? 'Retard supérieur au seuil' );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'recouvrement/dossiers' );
	}
	public function dossierStatut( $id ) {
		FKC_RecouvrementSuivi::statutDossier( (int) $id, $_POST['statut'] ?? '' );
		$this->setFlash( 'Dossier mis à jour.' );
		redirect( 'recouvrement/dossiers' );
	}

	/* ---------- Relances ---------- */
	/**
	 * File de relance du jour — déléguée au modèle (1.847.0) pour que
	 * l'écran et Maestro ne puissent jamais diverger sur qui relancer.
	 */
	protected function fileDeRelance() { return FKC_RecouvrementRelances::file(); }

	public function relances() {
		$this->constaterPromesses();
		$dues = $this->fileDeRelance();
		$regles = FKC_RecouvrementSuivi::regles();
		$ouverts = array();
		foreach ( FKC_RecouvrementSuivi::dossiers() as $dd ) { if ( 'clos' !== (string) ( $dd['statut'] ?? '' ) ) { $ouverts[ (int) $dd['client_id'] ] = $dd['statut']; } }
		$envoiDirect = class_exists( 'FKC_Courriel' ) && FKC_Courriel::disponible();
		FKC_View::render( 'recouvrement::relances', array(
			'title' => 'Recouvrement · Relances', 'tab' => 'relances',
			'dues' => $dues, 'regles' => $regles, 'paliers' => FKC_PolitiqueRelance::paliers(),
			'personnalisee' => FKC_PolitiqueRelance::estPersonnalisee(),
			'canaux' => FKC_PolitiqueRelance::canaux(), 'tons' => FKC_PolitiqueRelance::tons(),
			'flash' => $this->flash(),
			'envoi_direct' => $envoiDirect, 'dossiers_ouverts' => $ouverts,
			'seuil_precontentieux' => FKC_Recouvrement::seuilPrecontentieux(),
		) );
	}
	public function relanceLog() {
		$cid = (int) ( $_POST['client_id'] ?? 0 );
		FKC_RecouvrementSuivi::enregistrerRelance( $cid, (int) ( $_POST['facture_id'] ?? 0 ) ?: null, $_POST['canal'] ?? 'email', $_POST['detail'] ?? '' );
		$suite = FKC_RecouvrementSuivi::apresMiseEnDemeure( $cid, (string) ( $_POST['ton'] ?? '' ) );
		$this->setFlash( 'Relance enregistrée dans l\'historique.' . $suite );
		redirect( 'recouvrement/relances' );
	}

	/**
	 * ENVOI RÉEL DU COURRIEL DE RELANCE (1.841.4).
	 *
	 * L'écran préparait le message et ouvrait la messagerie de l'opérateur
	 * (lien mailto:) : il fallait copier, envoyer, revenir, cliquer sur
	 * « marquer comme envoyée ». Trois gestes de trop, et autant d'occasions
	 * d'oublier le dernier — la relance partie n'était alors jamais tracée.
	 * Quand le serveur sait envoyer (FKC_Courriel), l'envoi et la trace ne
	 * font plus qu'un. L'échec est dit tel quel et rien n'est tracé.
	 */
	public function relanceEnvoyer() {
		$cid = (int) ( $_POST['client_id'] ?? 0 );
		list( $ok, $msg ) = $this->envoyerReleve( $cid );
		$this->setFlash( $msg, $ok ? 'ok' : 'err' );
		redirect( 'recouvrement/relances' );
	}

	/** Envoie en une fois tous les relevés du jour dont le canal est l'e-mail. */
	public function relanceEnvoyerTout() {
		$n = 0; $echecs = array();
		foreach ( $this->fileDeRelance() as $g ) {
			if ( 'email' !== $g['canal'] ) { continue; }
			list( $ok, $msg ) = $this->envoyerReleve( (int) $g['client_id'], $g );
			if ( $ok ) { $n++; } else { $echecs[] = $g['client_nom'] . ' : ' . $msg; }
		}
		$this->setFlash( $n . ' relevé(s) envoyé(s) par courriel.' . ( $echecs ? ' Non envoyés — ' . implode( ' ; ', array_slice( $echecs, 0, 5 ) ) . ( count( $echecs ) > 5 ? ' …' : '' ) : '' ), $echecs && ! $n ? 'err' : 'ok' );
		redirect( 'recouvrement/relances' );
	}

	/** @return array{0:bool,1:string} — délégué au modèle (1.847.0) */
	protected function envoyerReleve( $cid, $groupe = null ) { return FKC_RecouvrementRelances::envoyer( $cid, $groupe ); }

	/* ---------- Pilotage (1.841.5) ---------- */
	public function pilotage() {
		$this->constaterPromesses();
		$d = FKC_Recouvrement::compute();
		try { FKC_RecouvrementPilotage::photographier( $d ); } catch ( \Throwable $e ) {}
		$periode = in_array( (int) ( $_GET['jours'] ?? 30 ), array( 30, 90, 365 ), true ) ? (int) ( $_GET['jours'] ?? 30 ) : 30;
		FKC_View::render( 'recouvrement::pilotage', array(
			'title' => 'Recouvrement · Pilotage', 'tab' => 'pilotage',
			'kpis' => $d['kpis'],
			'dso90' => FKC_RecouvrementPilotage::dsoGlissant( 90, $d ),
			'historique' => FKC_RecouvrementPilotage::historique( 12 ),
			'promesses' => FKC_RecouvrementPilotage::promesses( 90 ),
			'agents' => FKC_RecouvrementPilotage::agents( $periode ), 'periode' => $periode,
			'flash' => $this->flash(),
		) );
	}

	/* ---------- Sources de créances (1.841.2) ---------- */
	public function sources() {
		$d = FKC_Recouvrement::compute();
		FKC_View::render( 'recouvrement::sources', array(
			'title' => 'Recouvrement · Sources de créances', 'tab' => 'sources',
			'synthese' => FKC_RecouvrementSources::synthese( $d ),
			'erreurs' => FKC_RecouvrementSources::erreurs(),
			'kpis' => $d['kpis'], 'flash' => $this->flash(),
		) );
	}
	public function sourcesRattacher() {
		list( $n, $det ) = FKC_RecouvrementSources::rattacherTout();
		$parts = array();
		foreach ( $det as $code => $k ) { if ( $k ) { $src = FKC_RecouvrementSources::get( $code ); $parts[] = $k . ' · ' . ( $src['libelle'] ?? $code ); } }
		$this->setFlash( $n ? $n . ' tiers rattaché(s) à une fiche client (' . implode( ', ', $parts ) . ').' : 'Tous les tiers sont déjà rattachés.' );
		redirect( 'recouvrement/sources' );
	}

	/* ---------- Mise en demeure (imprimable / PDF) ---------- */
	public function miseEnDemeure( $id ) {
		$client = FKC_Client::find( $id );
		$d = FKC_Recouvrement::compute();
		$stats = FKC_Recouvrement::client( $id, $d );
		if ( ! $client ) { redirect( 'recouvrement/clients' ); }
		/*
		 * ON NE MET EN DEMEURE QUE POUR CE QUI EST EXIGIBLE (1.841.1).
		 *
		 * La lettre réclamait l'ENCOURS — factures non échues comprises. Un
		 * client qui doit 100 000 F échus et 5 000 000 F payables dans deux
		 * mois recevait une mise en demeure de 5 100 000 F sous huitaine :
		 * une somme qu'il ne doit pas encore, et une lettre qui se retourne
		 * contre le créancier. On réclame désormais le seul montant échu,
		 * facture par facture — c'est aussi ce que demandera le juge d'une
		 * injonction de payer.
		 */
		$echues = array_values( array_filter( $d['factures'], function ( $f ) use ( $id ) {
			return (int) $f['client_id'] === (int) $id && (int) $f['jours'] > 0;
		} ) );
		usort( $echues, function ( $a, $b ) { return strcmp( (string) $a['echeance'], (string) $b['echeance'] ); } );
		$montantEchu = (float) array_sum( array_column( $echues, 'montant' ) );
		$relancesPrealables = 0;
		foreach ( FKC_RecouvrementSuivi::actions( (int) $id ) as $a ) {
			if ( in_array( $a['type'], array( 'relance', 'appel', 'mise_en_demeure' ), true ) ) { $relancesPrealables++; }
		}
		/*
		 * IMPRIMER N'EST PAS ENVOYER, ET RELIRE N'EST PAS METTRE EN DEMEURE.
		 *
		 * Chaque affichage de cette page — un aperçu, une réimpression, un
		 * simple retour arrière du navigateur — ajoutait une ligne « Mise en
		 * demeure générée » à l'historique du client. C'est l'historique qu'on
		 * produit devant un juge pour établir ses diligences : quinze mentions
		 * le même jour n'y prouvent pas quinze diligences, elles jettent le
		 * doute sur toutes les autres.
		 *
		 * On garde la trace — elle est utile — mais une seule par jour et par
		 * client. La date, pas le compteur, est ce qui fait foi.
		 */
		if ( $montantEchu > 0 && ! FKC_RecouvrementSuivi::aActionAujourdhui( (int) $id, 'mise_en_demeure' ) ) {
			FKC_RecouvrementSuivi::ajouterAction( (int) $id, null, 'mise_en_demeure', 'Mise en demeure générée (' . fkc_money( $montantEchu ) . ' FCFA échus, '
				. count( $echues ) . ' facture(s)).' );
		}
		FKC_View::render( 'recouvrement::mise_en_demeure', array(
			'title' => 'Mise en demeure · ' . $client['nom'], 'tab' => 'clients', 'print' => true,
			'client' => $client, 'stats' => $stats, 'societe' => FKC_Tenant::current(),
			'echues' => $echues, 'montant_echu' => $montantEchu, 'relances_prealables' => $relancesPrealables,
			// 1.841.4 — pénalités chiffrées si la société les a paramétrées ;
			// moyens de paiement pour que la lettre dise comment régler.
			'penalites' => class_exists( 'FKC_RecouvrementReglages' ) ? FKC_RecouvrementReglages::calculerPenalites( $echues ) : array( 'total' => 0 ),
			'paiement' => class_exists( 'FKC_RecouvrementReglages' ) ? trim( FKC_RecouvrementReglages::blocPaiement( $montantEchu, $client['nom'] ?? '', false ) ) : '',
		) );
	}

	/**
	 * Constat automatique des promesses avant d'afficher un écran qui en
	 * dépend (1.841.3). Idempotent, et sans effet s'il n'y a rien à constater.
	 */
	protected function constaterPromesses() {
		try { FKC_RecouvrementSuivi::actualiserPromesses(); } catch ( \Throwable $e ) { /* un constat raté ne bloque pas l'écran */ }
	}

	protected function setFlash( $m, $t = 'ok' ) { $_SESSION['__flash_recouv'] = array( 'type' => $t, 'msg' => $m ); }
	protected function flash() { $m = $_SESSION['__flash_recouv'] ?? null; unset( $_SESSION['__flash_recouv'] ); return $m; }
}
