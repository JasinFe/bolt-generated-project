<?php
/**
 * Persistance du recouvrement : actions (historique / centre d'appels / litiges),
 * promesses de paiement, plans d'apurement, dossiers précontentieux, journal des relances.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RecouvrementSuivi {

	/* ---- Actions / historique ---- */
	public static function typesAction() {
		return array( 'appel' => 'Appel', 'note' => 'Note', 'litige' => 'Litige', 'relance' => 'Relance', 'mise_en_demeure' => 'Mise en demeure', 'promesse' => 'Promesse' );
	}
	public static function actions( $clientId ) {
		return FKC_DB::q( 'SELECT * FROM recouvrement_actions WHERE client_id=? ORDER BY id DESC', array( (int) $clientId ) )->fetchAll();
	}
	public static function ajouterAction( $clientId, $factureId, $type, $detail, $canal = null ) {
		FKC_DB::q(
			'INSERT INTO recouvrement_actions(client_id,facture_id,type,canal,detail,created_by) VALUES(?,?,?,?,?,?)',
			array( (int) $clientId, $factureId ? (int) $factureId : null, $type, $canal, trim( (string) $detail ) ?: null, FKC_Auth::id() )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}
	/** Une action de ce type a-t-elle déjà été journalisée aujourd'hui pour ce client ? */
	public static function aActionAujourdhui( $clientId, $type ) {
		try {
			$n = FKC_DB::q(
				"SELECT COUNT(*) FROM recouvrement_actions WHERE client_id=? AND type=? AND date(created_at)=date('now','localtime')",
				array( (int) $clientId, (string) $type )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return false; }
		return (int) $n > 0;
	}

	/**
	 * Date de la dernière relance, par client et par canal, EN UNE REQUÊTE.
	 *
	 * L'écran des relances interrogeait la base une fois par ligne candidate.
	 * Sur un portefeuille en difficulté — précisément le cas où l'écran sert —
	 * cela fait des centaines d'allers-retours pour une information qui tient
	 * dans un seul regroupement.
	 *
	 * @return array client_id => array( canal => 'Y-m-d H:i:s' )
	 */
	public static function dernieresRelances() {
		$out = array();
		try {
			$rows = FKC_DB::q(
				"SELECT client_id, canal, MAX(created_at) dernier
				 FROM recouvrement_actions
				 WHERE type='relance' AND canal IS NOT NULL
				 GROUP BY client_id, canal"
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( $rows as $r ) {
			$out[ (int) $r['client_id'] ][ (string) $r['canal'] ] = (string) $r['dernier'];
		}
		return $out;
	}

	/**
	 * Clients déjà contactés AUJOURD'HUI, tous canaux et tous écrans confondus
	 * (1.841.2).
	 *
	 * Le journal est partagé par la file de relance, le centre d'appels et la
	 * relance des soldes de commandes (Studio, prestataires). Chacun gardait
	 * son propre délai : un client pouvait recevoir un e-mail de relance de
	 * facture le matin et un WhatsApp de relance de commande l'après-midi.
	 * Un contact par jour et par client, quel qu'en soit l'objet.
	 *
	 * @return array client_id => true
	 */
	public static function contactesAujourdhui() {
		$out = array();
		try {
			foreach ( FKC_DB::q( "SELECT DISTINCT client_id FROM recouvrement_actions
				WHERE type IN ('relance','appel','mise_en_demeure') AND date(created_at)=date('now','localtime')" )->fetchAll() as $r ) {
				$out[ (int) $r['client_id'] ] = true;
			}
		} catch ( \Throwable $e ) {}
		return $out;
	}

	public static function aRelanceRecente( $clientId, $canal, $jours = 7 ) {
		$r = FKC_DB::q(
			"SELECT COUNT(*) FROM recouvrement_actions WHERE client_id=? AND type='relance' AND canal=? AND created_at >= datetime('now','localtime','-' || ? || ' day')",
			array( (int) $clientId, $canal, (int) $jours )
		)->fetchColumn();
		return (int) $r > 0;
	}

	/* ---- Promesses de paiement ---- */
	public static function statutsPromesse() { return array( 'en_attente' => 'En attente', 'tenue' => 'Tenue', 'non_tenue' => 'Non tenue' ); }
	public static function promesses( $statut = null ) {
		$sql = 'SELECT p.*, c.nom client_nom FROM recouvrement_promesses p LEFT JOIN clients c ON c.id=p.client_id';
		$p = array();
		if ( $statut ) { $sql .= ' WHERE p.statut=?'; $p[] = $statut; }
		$sql .= ' ORDER BY p.date_promesse ASC, p.id DESC';
		return FKC_DB::q( $sql, $p )->fetchAll();
	}
	public static function promessesClient( $clientId ) {
		return FKC_DB::q( 'SELECT * FROM recouvrement_promesses WHERE client_id=? ORDER BY date_promesse DESC, id DESC', array( (int) $clientId ) )->fetchAll();
	}
	public static function ajouterPromesse( $clientId, $factureId, $montant, $dateProm, $note = '' ) {
		self::ensurePromesses();
		// Reste dû de la facture AU MOMENT de la promesse : c'est lui qui
		// permettra de constater, plus tard, qu'elle a été tenue (1.841.3).
		$resteInitial = null;
		if ( $factureId && class_exists( 'FKC_Recouvrement' ) ) {
			try {
				$resteInitial = 0.0;
				foreach ( FKC_Recouvrement::compute( true )['factures'] as $w ) {
					if ( (int) $w['facture_id'] === (int) $factureId ) { $resteInitial = (float) $w['montant']; break; }
				}
			} catch ( \Throwable $e ) { $resteInitial = null; }
		}
		FKC_DB::q(
			'INSERT INTO recouvrement_promesses(client_id,facture_id,montant,date_promesse,statut,note,created_by,reste_initial) VALUES(?,?,?,?,?,?,?,?)',
			array( (int) $clientId, $factureId ? (int) $factureId : null, (float) $montant, $dateProm, 'en_attente', trim( (string) $note ) ?: null, FKC_Auth::id(), $resteInitial )
		);
		// L'identifiant est lu AVANT la trace : lu après, c'était celui de
		// l'action d'historique qui revenait à l'appelant (1.841.1).
		$pid = (int) FKC_DB::conn()->lastInsertId();
		self::ajouterAction( $clientId, $factureId, 'promesse', 'Promesse de ' . fkc_money( $montant ) . ' FCFA pour le ' . $dateProm );
		return $pid;
	}
	protected static $promPretes = false;
	/** Colonnes ajoutées en 1.841.3 : reste dû initial, date de constat. */
	public static function ensurePromesses() {
		if ( self::$promPretes ) { return; }
		$cols = array();
		try { foreach ( FKC_DB::q( 'PRAGMA table_info(recouvrement_promesses)' )->fetchAll() as $c ) { $cols[] = $c['name']; } } catch ( \Throwable $e ) {}
		foreach ( array( 'reste_initial' => 'REAL', 'constate_le' => 'TEXT' ) as $c => $t ) {
			if ( $cols && ! in_array( $c, $cols, true ) ) {
				try { FKC_DB::conn()->exec( "ALTER TABLE recouvrement_promesses ADD COLUMN {$c} {$t}" ); } catch ( \Throwable $e ) {}
			}
		}
		self::$promPretes = true;
	}

	/** Jours de grâce après la date promise avant de constater une promesse non tenue. */
	public static function gracePromesse() {
		return class_exists( 'FKC_License' ) ? max( 0, (int) FKC_License::param( 'recouv_promesse_grace', 2 ) ) : 2;
	}

	/**
	 * CONSTAT AUTOMATIQUE DES PROMESSES (1.841.3).
	 *
	 * Une promesse restait « en attente » tant que personne ne cliquait sur
	 * « Tenue » ou « Non tenue » — c'est-à-dire, en pratique, souvent pour
	 * toujours. La fiabilité des promesses que calcule Maestro reposait donc
	 * sur des clics oubliés, et une promesse échue et oubliée brouillait la
	 * lecture de la file.
	 *
	 * On constate désormais ce que disent les paiements :
	 *
	 *   — promesse sur UNE FACTURE : tenue quand le reste dû de la facture a
	 *     baissé d'au moins le montant promis depuis la promesse, ou quand la
	 *     facture est soldée ;
	 *   — promesse sur TOUT LE COMPTE : tenue quand les encaissements reçus
	 *     du client depuis la promesse couvrent le montant promis (répartis
	 *     entre ses promesses dans l'ordre des dates promises) ;
	 *   — non tenue quand la date promise est passée, délai de grâce compris,
	 *     sans que la condition soit remplie.
	 *
	 * Chaque constat est tracé dans l'historique du client. L'utilisateur
	 * garde la main : il peut toujours requalifier une promesse à la main.
	 *
	 * @return array{tenues:int, non_tenues:int}
	 */
	public static function actualiserPromesses() {
		$out = array( 'tenues' => 0, 'non_tenues' => 0 );
		if ( ! class_exists( 'FKC_Recouvrement' ) ) { return $out; }
		self::ensurePromesses();
		try { $prom = self::promesses( 'en_attente' ); } catch ( \Throwable $e ) { return $out; }
		if ( ! $prom ) { return $out; }
		$d = FKC_Recouvrement::compute( true );
		$ouvert = array();
		foreach ( $d['factures'] as $w ) { if ( ! empty( $w['facture_id'] ) ) { $ouvert[ (int) $w['facture_id'] ] = (float) $w['montant']; } }
		$limite = date( 'Y-m-d', strtotime( '-' . self::gracePromesse() . ' day' ) );
		usort( $prom, function ( $a, $b ) { return strcmp( (string) $a['date_promesse'], (string) $b['date_promesse'] ) ?: ( (int) $a['id'] <=> (int) $b['id'] ); } );
		$pool = array(); // client => encaissé disponible pour ses promesses « compte »
		foreach ( $prom as $p ) {
			$cid = (int) $p['client_id']; $m = (float) $p['montant']; $tenue = false; $detail = '';
			if ( ! empty( $p['facture_id'] ) ) {
				$fid = (int) $p['facture_id'];
				$reste = $ouvert[ $fid ] ?? 0.0;
				if ( null !== $p['reste_initial'] && '' !== (string) $p['reste_initial'] ) {
					$tenue = ( (float) $p['reste_initial'] - $reste ) >= $m - 0.5 || $reste <= 0.5;
				} else {
					$tenue = $reste <= 0.5 || self::encaisseDepuis( $cid, (string) $p['created_at'] ) >= $m - 0.5;
				}
				$detail = 'facture';
			} else {
				if ( ! isset( $pool[ $cid ] ) ) { $pool[ $cid ] = self::encaisseDepuis( $cid, (string) $p['created_at'] ); }
				if ( $pool[ $cid ] >= $m - 0.5 ) { $tenue = true; $pool[ $cid ] -= $m; }
				$detail = 'compte';
			}
			if ( $tenue ) {
				FKC_DB::q( "UPDATE recouvrement_promesses SET statut='tenue', constate_le=datetime('now','localtime') WHERE id=? AND statut='en_attente'", array( (int) $p['id'] ) );
				self::ajouterAction( $cid, $p['facture_id'] ?: null, 'promesse', 'Promesse du ' . $p['date_promesse'] . ' (' . fkc_money( $m ) . ' F) tenue — constaté sur les paiements reçus.' );
				$out['tenues']++;
			} elseif ( (string) $p['date_promesse'] < $limite ) {
				FKC_DB::q( "UPDATE recouvrement_promesses SET statut='non_tenue', constate_le=datetime('now','localtime') WHERE id=? AND statut='en_attente'", array( (int) $p['id'] ) );
				self::ajouterAction( $cid, $p['facture_id'] ?: null, 'promesse', 'Promesse du ' . $p['date_promesse'] . ' (' . fkc_money( $m ) . ' F) NON tenue — aucun paiement suffisant constaté.' );
				$out['non_tenues']++;
			}
		}
		if ( $out['tenues'] || $out['non_tenues'] ) { FKC_Recouvrement::oublier(); }
		return $out;
	}

	/** Encaissements reçus d'un client depuis une date (règlements et reçus). */
	public static function encaisseDepuis( $clientId, $depuis ) {
		$jour = substr( (string) $depuis, 0, 10 ) ?: date( 'Y-m-d' );
		$t = 0.0;
		try {
			$t += (float) FKC_DB::q( "SELECT COALESCE(SUM(montant),0) FROM reglements WHERE sens='encaissement' AND tiers_type='client'
				AND tiers_id=? AND COALESCE(statut,'actif')<>'annule' AND date_reglement>=?", array( (int) $clientId, $jour ) )->fetchColumn();
		} catch ( \Throwable $e ) {}
		try {
			$t += (float) FKC_DB::q( "SELECT COALESCE(SUM(montant_ttc),0) FROM recus WHERE client_id=? AND ecriture_id IS NOT NULL
				AND statut NOT IN ('annule') AND sens<>'decaissement' AND date_recu>=?
				AND type_operation IN ('paiement_facture','vente_comptant','acompte_client','avance_commande')", array( (int) $clientId, $jour ) )->fetchColumn();
		} catch ( \Throwable $e ) {}
		return $t;
	}

	public static function statutPromesse( $id, $statut ) {
		if ( ! isset( self::statutsPromesse()[ $statut ] ) ) { return false; }
		FKC_DB::q( 'UPDATE recouvrement_promesses SET statut=? WHERE id=?', array( $statut, (int) $id ) );
		return true;
	}

	/* ---- Plans d'apurement ---- */
	public static function plans( $clientId = null ) {
		$sql = 'SELECT pl.*, c.nom client_nom FROM recouvrement_plans pl LEFT JOIN clients c ON c.id=pl.client_id';
		$p = array();
		if ( $clientId ) { $sql .= ' WHERE pl.client_id=?'; $p[] = (int) $clientId; }
		$sql .= ' ORDER BY pl.id DESC';
		return FKC_DB::q( $sql, $p )->fetchAll();
	}
	public static function plan( $id ) {
		$pl = FKC_DB::q( 'SELECT * FROM recouvrement_plans WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $pl ) { return null; }
		$pl['echeances'] = FKC_DB::q( 'SELECT * FROM recouvrement_plan_echeances WHERE plan_id=? ORDER BY rang ASC', array( (int) $id ) )->fetchAll();
		return $pl;
	}
	public static function creerPlan( $clientId, $total, $nb, $premiereDate, $note = '' ) {
		$total = (float) $total; $nb = max( 1, (int) $nb );
		FKC_DB::q(
			'INSERT INTO recouvrement_plans(client_id,montant_total,nb_echeances,statut,note,created_by) VALUES(?,?,?,?,?,?)',
			array( (int) $clientId, $total, $nb, 'actif', trim( (string) $note ) ?: null, FKC_Auth::id() )
		);
		$pid = (int) FKC_DB::conn()->lastInsertId();
		$part = round( $total / $nb );
		for ( $i = 1; $i <= $nb; $i++ ) {
			$montant = ( $i === $nb ) ? round( $total - $part * ( $nb - 1 ) ) : $part;
			$date = self::ajouterMois( $premiereDate, $i - 1 );
			FKC_DB::q( 'INSERT INTO recouvrement_plan_echeances(plan_id,rang,date_echeance,montant,statut) VALUES(?,?,?,?,?)', array( $pid, $i, $date, $montant, 'du' ) );
		}
		self::ajouterAction( $clientId, null, 'note', 'Plan d\'apurement créé : ' . fkc_money( $total ) . ' FCFA en ' . $nb . ' échéance(s).' );
		return $pid;
	}
	/**
	 * Ajoute des mois SANS débordement (1.841.1).
	 *
	 * strtotime('31 janvier +1 month') rend le 3 mars : un plan commencé un
	 * 31 sautait février et plaçait deux échéances en mars. Le jour demandé
	 * est conservé quand il existe, ramené au dernier jour du mois sinon —
	 * 31/01, 28/02 (ou 29), 31/03, 30/04…
	 */
	public static function ajouterMois( $date, $n ) {
		$t = strtotime( (string) $date ) ?: time();
		$j = (int) date( 'j', $t );
		$m = (int) date( 'n', $t ) - 1 + (int) $n;
		$a = (int) date( 'Y', $t ) + intdiv( $m, 12 );
		$m = $m % 12 + 1;
		$fin = (int) date( 't', mktime( 0, 0, 0, $m, 1, $a ) );
		return sprintf( '%04d-%02d-%02d', $a, $m, min( $j, $fin ) );
	}

	public static function statutsPlan() {
		return array( 'actif' => 'Actif', 'solde' => 'Soldé', 'rompu' => 'Rompu', 'clos' => 'Clos', 'annule' => 'Annulé' );
	}

	/**
	 * État réel d'un plan, échéances à l'appui.
	 *
	 * Le statut stocké dit ce qu'on a DÉCIDÉ ; les échéances disent ce qui se
	 * passe. Un plan « actif » dont trois échéances sont passées sans paiement
	 * n'est plus actif que sur le papier — et c'est pourtant lui qui, jusqu'ici,
	 * mettait son client à l'abri de toute relance.
	 *
	 * @return array{en_defaut:bool, echues_impayees:int, montant_du:float, reste:float, paye:float}
	 */
	public static function etatPlan( $planId ) {
		$out = array( 'en_defaut' => false, 'echues_impayees' => 0, 'montant_du' => 0.0, 'reste' => 0.0, 'paye' => 0.0 );
		try {
			$rows = FKC_DB::q(
				'SELECT date_echeance, montant, statut FROM recouvrement_plan_echeances WHERE plan_id=?',
				array( (int) $planId )
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		$today = date( 'Y-m-d' );
		foreach ( $rows as $e ) {
			$m = (float) $e['montant'];
			if ( 'paye' === (string) $e['statut'] ) { $out['paye'] += $m; continue; }
			$out['reste'] += $m;
			if ( (string) $e['date_echeance'] < $today ) {
				$out['echues_impayees']++;
				$out['montant_du'] += $m;
			}
		}
		$out['en_defaut'] = $out['echues_impayees'] > 0;
		return $out;
	}

	public static function planEnDefaut( $planId ) {
		$e = self::etatPlan( $planId );
		return (bool) $e['en_defaut'];
	}

	public static function echeancePayee( $echId ) {
		FKC_DB::q( "UPDATE recouvrement_plan_echeances SET statut='paye' WHERE id=?", array( (int) $echId ) );
		$ech = FKC_DB::q( 'SELECT plan_id FROM recouvrement_plan_echeances WHERE id=?', array( (int) $echId ) )->fetch();
		if ( $ech ) {
			$reste = (int) FKC_DB::q( "SELECT COUNT(*) FROM recouvrement_plan_echeances WHERE plan_id=? AND statut!='paye'", array( (int) $ech['plan_id'] ) )->fetchColumn();
			if ( 0 === $reste ) { FKC_DB::q( "UPDATE recouvrement_plans SET statut='solde' WHERE id=?", array( (int) $ech['plan_id'] ) ); }
		}
		return true;
	}

	/* ---- Dossiers précontentieux ---- */
	/**
	 * SUITE D'UNE MISE EN DEMEURE ENVOYÉE (1.841.4).
	 *
	 * Envoyer la mise en demeure est une DILIGENCE : elle se trace comme
	 * telle (et non comme une simple relance), parce que c'est elle que
	 * demandent le juge d'une injonction de payer et l'administration
	 * fiscale pour déduire une dépréciation. Un dossier précontentieux déjà
	 * ouvert avance d'une étape ; sans dossier, on le propose — l'ouvrir
	 * reste une décision.
	 *
	 * @return string complément de message pour l'écran
	 */
	public static function apresMiseEnDemeure( $clientId, $ton ) {
		if ( 'mise_en_demeure' !== (string) $ton || ! (int) $clientId ) { return ''; }
		if ( ! self::aActionAujourdhui( (int) $clientId, 'mise_en_demeure' ) ) {
			self::ajouterAction( (int) $clientId, null, 'mise_en_demeure', 'Mise en demeure envoyée au client.' );
		}
		$d = self::dossierActif( (int) $clientId );
		if ( $d && 'precontentieux' === $d['statut'] ) {
			self::statutDossier( (int) $d['id'], 'mise_en_demeure' );
			self::ajouterAction( (int) $clientId, null, 'note', 'Dossier passé en « Mise en demeure » à l\'envoi du courrier.' );
			return ' Le dossier précontentieux passe au stade « Mise en demeure ».';
		}
		if ( ! $d ) { return ' Sans règlement sous huitaine, ouvrez le dossier précontentieux de ce client.'; }
		return '';
	}

	public static function statutsDossier() { return array( 'precontentieux' => 'Précontentieux', 'mise_en_demeure' => 'Mise en demeure', 'contentieux' => 'Contentieux', 'clos' => 'Clos' ); }
	public static function dossiers( $statut = null ) {
		$sql = 'SELECT d.*, c.nom client_nom FROM recouvrement_dossiers d LEFT JOIN clients c ON c.id=d.client_id';
		$p = array();
		if ( $statut ) { $sql .= ' WHERE d.statut=?'; $p[] = $statut; }
		$sql .= ' ORDER BY d.id DESC';
		return FKC_DB::q( $sql, $p )->fetchAll();
	}
	public static function dossierActif( $clientId ) {
		$r = FKC_DB::q( "SELECT * FROM recouvrement_dossiers WHERE client_id=? AND statut!='clos' ORDER BY id DESC LIMIT 1", array( (int) $clientId ) )->fetch();
		return $r ?: null;
	}
	public static function basculer( $clientId, $montant, $motif = '' ) {
		if ( self::dossierActif( $clientId ) ) { return array( false, 'Un dossier est déjà ouvert pour ce client.' ); }
		FKC_DB::q(
			'INSERT INTO recouvrement_dossiers(client_id,montant,statut,motif,date_bascule,created_by) VALUES(?,?,?,?,?,?)',
			array( (int) $clientId, (float) $montant, 'precontentieux', trim( (string) $motif ) ?: null, date( 'Y-m-d' ), FKC_Auth::id() )
		);
		self::ajouterAction( $clientId, null, 'note', 'Bascule en dossier précontentieux (' . fkc_money( $montant ) . ' FCFA).' );
		return array( true, 'Dossier précontentieux ouvert.' );
	}
	public static function statutDossier( $id, $statut ) {
		if ( ! isset( self::statutsDossier()[ $statut ] ) ) { return false; }
		FKC_DB::q( 'UPDATE recouvrement_dossiers SET statut=? WHERE id=?', array( $statut, (int) $id ) );
		return true;
	}

	/* ---- Relances : règles paramétrables + modèles de message ---- */
	public static function regles() {
		return array(
			'email_avant'    => (int) FKC_License::param( 'recouv_relance_email_avant', 7 ),    // J-7 avant échéance
			'whatsapp_apres' => (int) FKC_License::param( 'recouv_relance_whatsapp_apres', 3 ), // J+3 après échéance
		);
	}
	/**
	 * Construit le message d'une relance.
	 *
	 * TROIS DÉFAUTS CORRIGÉS ICI, ET LE PREMIER PARTAIT CHEZ LES CLIENTS.
	 *
	 *   1. « Bonjour @Jean Dupont, » — un résidu de gabarit que chaque client
	 *      relancé recevait, par e-mail comme par WhatsApp. Un détail qui
	 *      décrédibilise à lui seul toute la chaîne de relance.
	 *
	 *   2. Le TON était calculé par la politique de la société (courtoisie,
	 *      ferme, mise en demeure) et jeté : deux modèles figés, choisis sur le
	 *      seul canal. Le client à quatre-vingt-dix jours recevait exactement le
	 *      texte du rappel de courtoisie.
	 *
	 *   3. Le modèle e-mail annonçait « votre facture ARRIVE à échéance le … »
	 *      quelle que soit l'ancienneté. Écrire cela sur une créance échue
	 *      depuis trois mois donne au client l'impression qu'on ne suit pas son
	 *      compte — et lui fournit un argument pour ne pas payer.
	 *
	 * Le canal ne commande plus que la LONGUEUR (un SMS n'est pas une lettre) ;
	 * le ton commande le contenu, et l'ancienneté commande le temps du verbe.
	 *
	 * @param string $canal email|whatsapp|sms|telephone|courrier
	 * @param array  $row   ligne de la file de relance (+ éventuellement 'ton')
	 * @return array{sujet:string, corps:string}
	 */
	public static function modeleMessage( $canal, $row ) {
		$m = self::modeleMessageBrut( $canal, $row );
		$bref = in_array( $canal, array( 'whatsapp', 'sms', 'telephone' ), true );
		$ton = (string) ( $row['ton'] ?? ( (int) ( $row['jours'] ?? 0 ) > 0 ? 'ferme' : 'courtoisie' ) );
		$num = trim( (string) ( $row['numero'] ?? '' ) ) ?: 'n°' . ( $row['facture_id'] ?? '' );
		return self::enrichir( $m, array( $row ), $ton, $bref, (float) ( $row['montant'] ?? 0 ), $num );
	}

	/**
	 * COMMENT PAYER, ET CE QUE COÛTE LE RETARD (1.841.4).
	 *
	 * Le paragraphe de paiement (numéros Mobile Money, lien prérempli) est
	 * ajouté à TOUTE relance : c'est lui qui transforme un rappel en
	 * paiement le jour même. Les pénalités ne le sont qu'aux relances fermes
	 * et aux mises en demeure — les chiffrer dans un rappel de courtoisie
	 * ferait perdre plus qu'elles ne rapportent. Les deux s'insèrent AVANT la
	 * formule de politesse. Rien n'est ajouté tant que la société n'a rien
	 * paramétré : les messages restent alors ceux d'avant.
	 */
	protected static function enrichir( array $m, array $lignes, $ton, $bref, $montant, $reference ) {
		if ( ! class_exists( 'FKC_RecouvrementReglages' ) ) { return $m; }
		$ajout = '';
		$echu = false; foreach ( $lignes as $l ) { if ( (int) ( $l['jours'] ?? 0 ) > 0 ) { $echu = true; } }
		if ( $echu && in_array( $ton, array( 'ferme', 'mise_en_demeure' ), true ) ) {
			$ajout .= FKC_RecouvrementReglages::blocPenalites( $lignes, $bref );
		}
		$ajout .= FKC_RecouvrementReglages::blocPaiement( $montant, $reference, $bref );
		if ( '' === $ajout ) { return $m; }
		$c = $m['corps'];
		if ( $bref ) {
			$pos = strrpos( $c, ' Cordialement.' );
			$m['corps'] = false !== $pos ? substr( $c, 0, $pos ) . $ajout . substr( $c, $pos ) : $c . $ajout;
		} else {
			$pos = strrpos( $c, "\n\n" );
			$m['corps'] = false !== $pos ? substr( $c, 0, $pos ) . $ajout . substr( $c, $pos ) : $c . $ajout;
		}
		return $m;
	}

	protected static function modeleMessageBrut( $canal, $row ) {
		$nom     = trim( (string) ( $row['client_nom'] ?? '' ) );
		/*
		 * Le client connaît sa facture par son NUMÉRO (FAC-2026-0003), jamais
		 * par l'identifiant interne de la base. « Votre facture n°4 » ne lui
		 * permet pas de la retrouver, ni au service comptable de la
		 * rapprocher (1.841.1).
		 */
		$num     = trim( (string) ( $row['numero'] ?? '' ) );
		$ref     = '' !== $num ? $num : 'n°' . ( $row['facture_id'] ?? '' );
		/*
		 * UNE COTISATION N'EST PAS UNE FACTURE (1.841.2). Les créances des
		 * sources (cotisations, loyers, scolarité, pièces de dossier) se
		 * relancent sous leur propre nom, accordé en genre : « votre loyer
		 * est échu », « votre cotisation est échue ».
		 */
		$src     = (string) ( $row['source'] ?? '' );
		$doc     = '' !== $src && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::document( $src ) : 'votre facture';
		$court   = '' !== $src && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $src ) : 'Facture';
		$fem     = '' !== $src && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::feminin( $src ) : true;
		$e       = $fem ? 'e' : '';
		$Doc     = mb_strtoupper( mb_substr( $doc, 0, 1 ) ) . mb_substr( $doc, 1 );
		$montant = fkc_money( $row['montant'] ?? 0 ) . ' FCFA';
		$ech     = ! empty( $row['echeance'] ) ? date( 'd/m/Y', strtotime( $row['echeance'] ) ) : '';
		$jours   = (int) ( $row['jours'] ?? 0 );
		$ton     = (string) ( $row['ton'] ?? ( $jours > 0 ? 'ferme' : 'courtoisie' ) );
		$salut   = 'Bonjour' . ( '' !== $nom ? ' ' . $nom : '' ) . ',';
		$bref    = in_array( $canal, array( 'whatsapp', 'sms', 'telephone' ), true );

		// Rappel AVANT échéance : ce n'est pas une relance, et le dire évite de
		// froisser un client qui n'a encore rien à se reprocher.
		if ( $jours <= 0 ) {
			$corps = $bref
				? $salut . ' ' . $doc . ' ' . $ref . ' (' . $montant . ') arrive à échéance le ' . $ech
					. '. Merci d\'anticiper son règlement. Cordialement.'
				: $salut . "\n\nNous vous rappelons que " . $doc . ' ' . $ref . ' d\'un montant de ' . $montant
					. ' arrive à échéance le ' . $ech . ".\nNous vous remercions de bien vouloir procéder à son règlement dans les délais."
					. "\n\nCe message est un simple rappel : si le règlement est déjà parti, n'en tenez pas compte."
					. "\n\nCordialement,";
			return array( 'sujet' => $bref ? '' : $Doc . ' ' . $ref . ' arrive à échéance', 'corps' => $corps );
		}

		if ( 'mise_en_demeure' === $ton ) {
			$corps = $bref
				? $salut . ' ' . $doc . ' ' . $ref . ' (' . $montant . '), échu' . $e . ' le ' . $ech . ', reste impayé' . $e . ' depuis '
					. $jours . ' jours. Sans règlement sous huitaine, le dossier sera transmis au précontentieux.'
				: $salut . "\n\nMalgré nos relances, " . $doc . ' ' . $ref . ' d\'un montant de ' . $montant
					. ', échu' . $e . ' le ' . $ech . ', demeure impayé' . $e . ' à ce jour, soit ' . $jours . " jours de retard."
					. "\n\nNous vous mettons en demeure de procéder à son règlement sous huitaine à compter de la réception"
					. " du présent courrier. À défaut, le dossier sera transmis à notre service précontentieux et les"
					. " voies de droit seront engagées, sans nouvel avis."
					. "\n\nSi le règlement a été effectué entre-temps, merci de nous en transmettre la preuve."
					. "\n\nVeuillez agréer nos salutations distinguées,";
			return array( 'sujet' => $bref ? '' : 'MISE EN DEMEURE — ' . mb_strtolower( $court ) . ' ' . $ref, 'corps' => $corps );
		}

		if ( 'ferme' === $ton ) {
			$corps = $bref
				? $salut . ' ' . $doc . ' ' . $ref . ' (' . $montant . ') est échu' . $e . ' depuis le ' . $ech . ' (' . $jours
					. ' jours). Merci de régulariser sans délai ou de nous indiquer une date de règlement. Cordialement.'
				: $salut . "\n\n" . $Doc . ' ' . $ref . ' d\'un montant de ' . $montant . ' est échu' . $e . ' depuis le ' . $ech
					. ', soit ' . $jours . ' jours de retard, et demeure impayé' . $e . '.'
					. "\n\nNous vous remercions de procéder à son règlement sans délai, ou de nous indiquer la date à"
					. " laquelle il interviendra."
					. "\n\nSi le règlement a déjà été effectué, merci de nous en communiquer la référence."
					. "\n\nCordialement,";
			return array( 'sujet' => $bref ? '' : $court . ' ' . $ref . ' échu' . $e . ' — règlement attendu', 'corps' => $corps );
		}

		$corps = $bref
			? $salut . ' sauf erreur de notre part, ' . $doc . ' ' . $ref . ' (' . $montant . ') échu' . $e . ' le ' . $ech
				. ' n\'a pas encore été réglé' . $e . '. Merci d\'y donner suite. Cordialement.'
			: $salut . "\n\nSauf erreur de notre part, " . $doc . ' ' . $ref . ' d\'un montant de ' . $montant
				. ', échu' . $e . ' le ' . $ech . ', n\'a pas encore été réglé' . $e . '.'
				. "\n\nNous vous remercions de bien vouloir y donner suite, ou de nous signaler toute difficulté afin"
				. " que nous puissions en convenir ensemble."
				. "\n\nCordialement,";
		return array( 'sujet' => $bref ? '' : $court . ' ' . $ref . ' — rappel', 'corps' => $corps );
	}
	/**
	 * RELEVÉ DE RELANCE : UN MESSAGE PAR CLIENT, TOUTES SES PIÈCES (1.841.3).
	 *
	 * Un client qui doit trois factures et une cotisation recevait quatre
	 * messages, ou — depuis la règle d'un contact par jour — un seul message
	 * qui n'en citait qu'une, les trois autres disparaissant de la file
	 * jusqu'au lendemain. Le relevé les cite toutes, avec le total, sur le ton
	 * du palier le plus avancé : c'est la pièce la plus ancienne qui décide de
	 * la fermeté, pas la plus récente.
	 *
	 * Avec une seule pièce, le message reste celui de modeleMessage().
	 *
	 * @param string $canal
	 * @param string $clientNom
	 * @param array  $lignes lignes de la file (numero, montant, echeance, jours, source)
	 * @param string $ton    courtoisie | ferme | mise_en_demeure
	 * @return array{sujet:string, corps:string}
	 */
	public static function modeleReleve( $canal, $clientNom, array $lignes, $ton = 'ferme' ) {
		if ( 1 === count( $lignes ) ) {
			$l = reset( $lignes );
			return self::modeleMessage( $canal, $l + array( 'client_nom' => $clientNom, 'ton' => $ton ) );
		}
		$m = self::modeleReleveBrut( $canal, $clientNom, $lignes, $ton );
		$refs = array();
		foreach ( array_slice( $lignes, 0, 3 ) as $l ) { $refs[] = trim( (string) ( $l['numero'] ?? '' ) ) ?: 'n°' . ( $l['facture_id'] ?? '' ); }
		return self::enrichir( $m, $lignes, (string) $ton, in_array( $canal, array( 'whatsapp', 'sms', 'telephone' ), true ),
			(float) array_sum( array_column( $lignes, 'montant' ) ), implode( ' ', $refs ) . ( count( $lignes ) > 3 ? ' …' : '' ) );
	}

	protected static function modeleReleveBrut( $canal, $clientNom, array $lignes, $ton = 'ferme' ) {
		$nom   = trim( (string) $clientNom );
		$salut = 'Bonjour' . ( '' !== $nom ? ' ' . $nom : '' ) . ',';
		$bref  = in_array( $canal, array( 'whatsapp', 'sms', 'telephone' ), true );
		$total = 0.0; $echues = 0; $items = array();
		foreach ( $lignes as $l ) {
			$total += (float) $l['montant'];
			$jours = (int) ( $l['jours'] ?? 0 );
			if ( $jours > 0 ) { $echues++; }
			$src   = (string) ( $l['source'] ?? '' );
			$court = '' !== $src && class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::court( $src ) : 'Facture';
			$num   = trim( (string) ( $l['numero'] ?? '' ) ) ?: 'n°' . ( $l['facture_id'] ?? '' );
			$ech   = ! empty( $l['echeance'] ) ? date( 'd/m/Y', strtotime( $l['echeance'] ) ) : '';
			$items[] = ( $bref ? '• ' : '  - ' ) . $court . ' ' . $num . ' : ' . fkc_money( $l['montant'] ) . ' FCFA'
				. ( $jours > 0 ? ', échéance ' . $ech . ' (' . $jours . ' j)' : ', échéance ' . $ech );
		}
		$liste = implode( "\n", $items );
		$tot   = fkc_money( $total ) . ' FCFA';
		$n     = count( $lignes );

		if ( 0 === $echues ) {
			$corps = $salut . ( $bref ? ' ' : "\n\n" ) . 'Nous vous rappelons les échéances à venir de votre compte :' . "\n" . $liste
				. "\n" . 'Total : ' . $tot . '.' . ( $bref ? ' Merci d\'anticiper leur règlement. Cordialement.'
				: "\n\nCe message est un simple rappel : si le règlement est déjà parti, n'en tenez pas compte.\n\nCordialement," );
			return array( 'sujet' => $bref ? '' : 'Vos échéances à venir (' . $n . ' pièces)', 'corps' => $corps );
		}
		if ( 'mise_en_demeure' === $ton ) {
			$corps = $salut . ( $bref ? ' ' : "\n\n" ) . ( $bref ? '' : 'Malgré nos relances, ' ) . 'les sommes suivantes demeurent impayées :' . "\n" . $liste
				. "\n" . 'Total dû : ' . $tot . '.' . ( $bref
					? ' Sans règlement sous huitaine, le dossier sera transmis au précontentieux.'
					: "\n\nNous vous mettons en demeure de régler ce montant sous huitaine à compter de la réception du présent"
						. " courrier. À défaut, le dossier sera transmis à notre service précontentieux et les voies de droit"
						. " seront engagées, sans nouvel avis.\n\nSi le règlement a été effectué entre-temps, merci de nous en"
						. " transmettre la preuve.\n\nVeuillez agréer nos salutations distinguées," );
			return array( 'sujet' => $bref ? '' : 'MISE EN DEMEURE — relevé de ' . $n . ' pièces impayées', 'corps' => $corps );
		}
		if ( 'ferme' === $ton ) {
			$corps = $salut . ( $bref ? ' ' : "\n\n" ) . 'Les sommes suivantes restent impayées :' . "\n" . $liste
				. "\n" . 'Total dû : ' . $tot . '.' . ( $bref
					? ' Merci de régulariser sans délai ou de nous indiquer une date de règlement. Cordialement.'
					: "\n\nNous vous remercions de procéder à leur règlement sans délai, ou de nous indiquer la date à"
						. " laquelle il interviendra.\n\nSi le règlement a déjà été effectué, merci de nous en communiquer la"
						. " référence.\n\nCordialement," );
			return array( 'sujet' => $bref ? '' : 'Relevé de ' . $n . ' pièces échues — règlement attendu', 'corps' => $corps );
		}
		$corps = $salut . ( $bref ? ' ' : "\n\n" ) . 'Sauf erreur de notre part, les sommes suivantes n\'ont pas encore été réglées :' . "\n" . $liste
			. "\n" . 'Total : ' . $tot . '.' . ( $bref ? ' Merci d\'y donner suite. Cordialement.'
				: "\n\nNous vous remercions de bien vouloir y donner suite, ou de nous signaler toute difficulté afin que"
					. " nous puissions en convenir ensemble.\n\nCordialement," );
		return array( 'sujet' => $bref ? '' : 'Relevé de compte — ' . $n . ' pièces à régler', 'corps' => $corps );
	}

	/**
	 * Journalise une relance envoyée.
	 *
	 * Le canal est CONTRÔLÉ : c'est lui qui commande le délai minimal avant la
	 * relance suivante. Un canal fantaisiste — saisi à la main, ou venu d'un
	 * formulaire modifié — créait une ligne d'historique que aRelanceRecente()
	 * ne retrouvait jamais, et le client pouvait être relancé tous les jours
	 * sans que le garde-fou ne s'en aperçoive.
	 */
	public static function enregistrerRelance( $clientId, $factureId, $canal, $detail = '' ) {
		$canaux = class_exists( 'FKC_PolitiqueRelance' ) ? FKC_PolitiqueRelance::canaux() : array( 'email' => 'E-mail' );
		$canal  = isset( $canaux[ (string) $canal ] ) ? (string) $canal : 'email';
		if ( ! (int) $clientId ) { return 0; }
		return self::ajouterAction( $clientId, $factureId, 'relance', $detail ?: ( 'Relance ' . $canal ), $canal );
	}
}
