<?php
/**
 * Recouvrement — la file de relance du jour et l'envoi d'un relevé (1.847.0).
 *
 * Extraites du contrôleur, où elles étaient protégées, pour servir DEUX
 * appelants sans jamais diverger : l'écran Recouvrement → Relances et le
 * plan d'action « relance_impayes » de Maestro. Qui est à relancer, sur quel
 * canal, avec quel ton, qui a déjà été contacté aujourd'hui : une seule
 * réponse, écrite une seule fois. Le comportement est inchangé.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RecouvrementRelances {

	/**
	 * File de relance du jour, un relevé par client (1.841.4 : extraite de
	 * relances() pour servir aussi l'envoi direct par courriel).
	 *
	 * @return array liste de relevés
	 */
	public static function file() {
		$d = FKC_Recouvrement::compute();
		$regles = FKC_RecouvrementSuivi::regles();
		$recentes = FKC_RecouvrementSuivi::dernieresRelances();
		$contactes = FKC_RecouvrementSuivi::contactesAujourdhui();
		$dues = array();
		foreach ( $d['factures'] as $f ) {
			/*
			 * LA CADENCE VIENT DE LA POLITIQUE DE LA SOCIÉTÉ, PLUS DU CODE.
			 *
			 * Deux règles étaient écrites en dur — e-mail à J-7, WhatsApp à
			 * J+3 — et valaient pour tout le monde. Une officine et un
			 * constructeur n'ont pourtant pas la même cadence : les créances de
			 * l'une sont petites et nombreuses, celles de l'autre se paient par
			 * situations à soixante jours. Chaque société définit désormais ses
			 * paliers ; les valeurs d'origine restent le défaut.
			 */
			$palier = FKC_PolitiqueRelance::palierPour( (int) $f['jours'] );
			if ( ! $palier ) { continue; }
			$canal = $palier['canal'];
			$seuilM = FKC_PolitiqueRelance::seuilMontant();
			if ( $seuilM > 0 && (float) $f['montant'] < $seuilM ) { continue; }
			/*
			 * LA FILE DE RELANCE NE PROPOSE QUE CE QUI EST RELANÇABLE.
			 *
			 * Le moteur marque désormais les lignes couvertes par une promesse
			 * en cours, un plan d'apurement ou un dossier contentieux. Les
			 * laisser ici reviendrait à rappeler un client qui a fait ce qu'on
			 * lui demandait — et, pour un dossier déjà en mise en demeure, à
			 * envoyer une relance amiable qui peut être opposée au créancier
			 * comme une renonciation à sa procédure.
			 *
			 * Les montants restent dans l'encours et dans la balance âgée : ils
			 * sont dus. Ils ne sont simplement pas à relancer aujourd'hui.
			 */
			if ( isset( $f['relancable'] ) && ! $f['relancable'] ) { continue; }
			// Une créance sans client rattaché n'a ni téléphone ni adresse :
			// elle se traite en la raccrochant à un client, pas en la relançant.
			if ( 0 === (int) $f['client_id'] ) { continue; }
			/*
			 * Le délai minimal entre deux relances appartient au palier : une
			 * mise en demeure ne se réexpédie pas toutes les semaines, un
			 * rappel de courtoisie oui. Un délai unique de sept jours traitait
			 * les deux de la même façon.
			 */
			// Déjà contacté aujourd'hui, par cet écran ou un autre (1.841.2).
			if ( isset( $contactes[ (int) $f['client_id'] ] ) ) { continue; }
			$dernier = $recentes[ (int) $f['client_id'] ][ $canal ] ?? null;
			if ( $dernier && strtotime( $dernier ) >= strtotime( '-' . max( 1, (int) $palier['min_jours_entre'] ) . ' day' ) ) { continue; }
			$f['palier'] = $palier['libelle'];
			$f['ton'] = $palier['ton'];
			$f['canal'] = $canal;
			// Le ton est posé AVANT la construction du message : c'est lui qui
			// commande le contenu, pas seulement l'étiquette affichée à l'écran.
			$f['message'] = FKC_RecouvrementSuivi::modeleMessage( $canal, $f );
			// L'adresse est déjà dans l'instantané du moteur : la relire client
			// par client, c'était une requête par ligne de relance.
			$f['email'] = $d['clients'][ (int) $f['client_id'] ]['email'] ?? '';
			$dues[] = $f;
		}
		/*
		 * UN RELEVÉ PAR CLIENT (1.841.3). Les lignes éligibles d'un même client
		 * sont regroupées : un seul message les cite toutes, sur le canal et le
		 * ton du palier le plus avancé. Voir FKC_RecouvrementSuivi::modeleReleve().
		 */
		$groupes = array();
		foreach ( $dues as $f ) {
			$cid = (int) $f['client_id'];
			if ( ! isset( $groupes[ $cid ] ) ) { $groupes[ $cid ] = $f + array( 'lignes' => array() ); }
			$g =& $groupes[ $cid ];
			$g['lignes'][] = $f;
			if ( (int) $f['jours'] > (int) $g['jours'] ) {
				foreach ( array( 'palier', 'ton', 'canal', 'jours' ) as $k ) { $g[ $k ] = $f[ $k ]; }
			}
			unset( $g );
		}
		foreach ( $groupes as &$g ) {
			usort( $g['lignes'], function ( $a, $b ) { return (int) $b['jours'] <=> (int) $a['jours']; } );
			$g['montant'] = (float) array_sum( array_column( $g['lignes'], 'montant' ) );
			$g['message'] = FKC_RecouvrementSuivi::modeleReleve( $g['canal'], $g['client_nom'], $g['lignes'], $g['ton'] );
			$g['facture_id'] = 1 === count( $g['lignes'] ) ? (int) $g['lignes'][0]['facture_id'] : 0;
			$g['references'] = implode( ', ', array_map( function ( $l ) { return ( $l['numero'] ?? '' ) ?: 'n°' . (int) $l['facture_id']; }, $g['lignes'] ) );
		}
		unset( $g );
		usort( $groupes, function ( $a, $b ) { return (int) $b['jours'] <=> (int) $a['jours']; } );
		return array_values( $groupes );
	}

	/** @return array{0:bool,1:string} */
	public static function envoyer( $cid, $groupe = null ) {
		if ( ! class_exists( 'FKC_Courriel' ) || ! FKC_Courriel::disponible() ) {
			return array( false, 'L\'envoi de courriels n\'est pas disponible sur ce serveur.' );
		}
		if ( null === $groupe ) {
			foreach ( self::file() as $g ) { if ( (int) $g['client_id'] === (int) $cid ) { $groupe = $g; break; } }
		}
		if ( ! $groupe ) { return array( false, 'Ce client n\'a plus de relance à envoyer aujourd\'hui.' ); }
		$to = (string) ( $groupe['email'] ?? '' );
		if ( ! FKC_Courriel::adresseValide( $to ) ) { return array( false, 'Adresse e-mail absente ou invalide sur la fiche de ' . $groupe['client_nom'] . '.' ); }
		// Le courriel part toujours dans sa version longue, même si le palier
		// prévoit un autre canal : un e-mail n'est pas un SMS.
		$m = $groupe['message'];
		if ( 'email' !== $groupe['canal'] || '' === (string) $m['sujet'] ) {
			$m = FKC_RecouvrementSuivi::modeleReleve( 'email', $groupe['client_nom'], $groupe['lignes'], $groupe['ton'] );
		}
		$soc = class_exists( 'FKC_Tenant' ) ? (array) FKC_Tenant::current() : array();
		$signature = trim( (string) ( $soc['nom'] ?? $soc['raison_sociale'] ?? '' ) );
		$texte = $m['corps'] . ( '' !== $signature ? "\n" . $signature : '' );
		list( $ok, $msg ) = FKC_Courriel::envoyer( $to, $m['sujet'], $texte, null, 'relance:' . (int) $cid );
		if ( ! $ok ) { return array( false, $msg ); }
		FKC_RecouvrementSuivi::enregistrerRelance( (int) $cid, (int) ( $groupe['facture_id'] ?? 0 ) ?: null, 'email',
			$groupe['palier'] . ' (e-mail envoyé à ' . $to . ') — ' . ( $groupe['references'] ?? '' ) );
		$suite = FKC_RecouvrementSuivi::apresMiseEnDemeure( (int) $cid, (string) $groupe['ton'] );
		return array( true, $msg . $suite );
	}


	/**
	 * Action exécutable par Maestro : envoyer le relevé du jour d'UN client.
	 * Le droit au module Recouvrement est revérifié au moment d'agir.
	 */
	public static function enregistrerAction() {
		if ( ! class_exists( 'FKC_Actions' ) ) { return; }
		FKC_Actions::register( 'recouvrement_relancer', array(
			'label' => 'Envoyer le relevé de relance', 'icone' => '✉️', 'classe' => 'primary',
			'roles' => array( 'admin', 'direction', 'comptable', 'recouvrement' ),
			'confirm' => 'Envoyer ce relevé de relance par e-mail ? Un courriel parti ne se reprend pas.',
			'handler' => function ( $p ) {
				if ( class_exists( 'FKC_Auth' ) && FKC_Auth::id() && ! FKC_Auth::can( 'recouvrement' ) ) {
					return array( false, 'Votre rôle n\'ouvre pas le module Recouvrement.' );
				}
				return self::envoyer( (int) ( $p['id'] ?? 0 ) );
			},
		) );
	}
}
FKC_RecouvrementRelances::enregistrerAction();
