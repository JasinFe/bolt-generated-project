<?php
/**
 * Moteur d'analyse du recouvrement (sans état) : balance âgée, score payeur, niveau de
 * risque, KPIs (DSO, taux de recouvrement). Calculé à partir des factures certifiées,
 * des encaissements (règlements) et des clients existants — aucune donnée dupliquée.
 * Les encaissements étant suivis au niveau client, l'ancienneté est obtenue par
 * lettrage FIFO (imputation du payé sur les factures les plus anciennes).
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Recouvrement {

	/**
	 * INSTANTANÉ DE LA REQUÊTE — POURQUOI IL A FALLU L'AJOUTER.
	 *
	 * compute() lit tous les clients, toutes les factures, tous les règlements
	 * et tous les reçus, puis reconstruit le lettrage FIFO en PHP. Ce n'est pas
	 * un calcul qu'on relance à la légère — or il était relancé huit fois hors
	 * tests, et une fois PAR CLIENT dans l'analyse du portefeuille de crédit :
	 * sur trois cents clients, trois cent un calculs complets pour un seul
	 * écran.
	 *
	 * La mémoïsation n'est pas qu'une optimisation. Un tableau de bord qui
	 * appelle trois fois le moteur peut afficher trois états différents du
	 * poste client si un encaissement tombe entre-temps ; l'instantané garantit
	 * qu'un même écran parle d'un seul instant.
	 *
	 * Là où l'on DÉCIDE après avoir écrit — accorder une commande de plus après
	 * avoir facturé la précédente — l'instantané serait un piège : ces appels
	 * passent explicitement `compute( true )`.
	 */
	protected static $snapshot = null;

	/** Oublie l'instantané : changement de société, ou écriture sur le poste client. */
	public static function oublier() { self::$snapshot = null; }

	public static function seuilPrecontentieux() { return (int) FKC_License::param( 'recouv_seuil_precontentieux', 90 ); }
	public static function seuilRisque()         { return (int) FKC_License::param( 'recouv_seuil_risque_jours', 60 ); }

	protected static function aujourdhui() { return strtotime( date( 'Y-m-d' ) ); }

	protected static function echeance( $f, $delaiClient ) {
		if ( ! empty( $f['echeance'] ) ) { return $f['echeance']; }
		return date( 'Y-m-d', strtotime( $f['date_facture'] . ' +' . max( 0, (int) $delaiClient ) . ' day' ) );
	}

	protected static function bucket( $jours ) {
		if ( $jours <= 0 )  { return 'courant'; }
		if ( $jours <= 30 ) { return 'b0_30'; }
		if ( $jours <= 60 ) { return 'b31_60'; }
		if ( $jours <= 90 ) { return 'b61_90'; }
		return 'b90p';
	}

	/**
	 * @param bool $frais force le recalcul (décision prise après une écriture).
	 */
	public static function compute( $frais = false ) {
		if ( ! $frais && null !== self::$snapshot ) { return self::$snapshot; }
		$out = self::calculer();
		self::$snapshot = $out;
		return $out;
	}

	protected static function calculer() {
		$today = self::aujourdhui();
		$clients = array();
		foreach ( FKC_Client::all() as $c ) {
			$clients[ (int) $c['id'] ] = array(
				'id' => (int) $c['id'], 'nom' => $c['nom'], 'telephone' => $c['telephone'] ?? '',
				'email' => $c['email'] ?? '', 'delai' => (int) ( $c['delai_paiement'] ?? 0 ),
				'facture' => 0.0, 'encaisse' => 0.0, 'encours' => 0.0, 'retard' => 0.0, 'a_risque' => 0.0,
				'buckets' => array( 'courant' => 0.0, 'b0_30' => 0.0, 'b31_60' => 0.0, 'b61_90' => 0.0, 'b90p' => 0.0 ),
				'jours_max' => 0, 'score' => 100, 'risque' => 'faible', 'perte' => 0.0,
			);
		}
		foreach ( FKC_DB::q( "SELECT tiers_id, COALESCE(SUM(montant),0) s FROM reglements WHERE sens='encaissement' AND tiers_type='client' AND COALESCE(statut,'actif')<>'annule' GROUP BY tiers_id" )->fetchAll() as $r ) {
			if ( isset( $clients[ (int) $r['tiers_id'] ] ) ) { $clients[ (int) $r['tiers_id'] ]['encaisse'] = (float) $r['s']; }
		}
		// Pont Recouvrement ↔ Encaissement : les reçus comptabilisés qui soldent
		// la créance client (paiement de facture, vente au comptant — écriture
		// D trésorerie / C 411) alimentent aussi le « payé » ; les remboursements
		// (D 411 / C trésorerie) le réduisent. Les acomptes/avances (419) ne
		// comptent qu'une fois imputés sur une facture (OD 419→411 dédiée).
		try {
			$rows = FKC_DB::q(
				"SELECT client_id,
				        COALESCE(SUM(CASE WHEN sens='decaissement' THEN -montant_ttc ELSE montant_ttc END),0) s
				 FROM recus
				 WHERE client_id IS NOT NULL AND ecriture_id IS NOT NULL
				   AND statut NOT IN ('annule')
				   AND ( type_operation IN ('paiement_facture','vente_comptant','remboursement')
				         OR (type_operation IN ('acompte_client','avance_commande') AND rapproche_at IS NOT NULL) )
				 GROUP BY client_id"
			)->fetchAll();
			foreach ( $rows as $r ) {
				if ( isset( $clients[ (int) $r['client_id'] ] ) ) { $clients[ (int) $r['client_id'] ]['encaisse'] += (float) $r['s']; }
			}
		} catch ( \Throwable $e ) { /* module Encaissement absent : table recus inexistante */ }
		/*
		 * ACOMPTE RATTACHÉ À UNE FACTURE, PAS ENCORE RAPPROCHÉ (1.841.1).
		 *
		 * Il dort en 419 tant que l'OD 419→411 n'est pas passée, mais le
		 * client a bel et bien payé CETTE facture. Pour le recouvrement, il
		 * l'éteint à due concurrence — et il le fait des DEUX côtés à la
		 * fois : dans l'encaissé et dans l'imputation nommée. Avant, seule
		 * l'imputation le voyait : le pool FIFO était amputé d'une somme qu'il
		 * n'avait jamais reçue, la facture la plus ancienne restait
		 * artificiellement ouverte et l'encours ressortait gonflé du montant
		 * de l'acompte.
		 */
		$acomptesFacture = array();
		try {
			$rows = FKC_DB::q(
				"SELECT client_id, facture_id, COALESCE(SUM(montant_ttc),0) s
				 FROM recus
				 WHERE client_id IS NOT NULL AND facture_id IS NOT NULL AND facture_id <> 0
				   AND ecriture_id IS NOT NULL AND statut NOT IN ('annule') AND sens <> 'decaissement'
				   AND type_operation IN ('acompte_client','avance_commande') AND rapproche_at IS NULL
				 GROUP BY client_id, facture_id"
			)->fetchAll();
			foreach ( $rows as $r ) {
				if ( ! isset( $clients[ (int) $r['client_id'] ] ) ) { continue; }
				$clients[ (int) $r['client_id'] ]['encaisse'] += (float) $r['s'];
				$acomptesFacture[ (int) $r['facture_id'] ] = ( $acomptesFacture[ (int) $r['facture_id'] ] ?? 0.0 ) + (float) $r['s'];
			}
		} catch ( \Throwable $e ) { /* colonne rapproche_at absente : rien à ajouter */ }
		/*
		 * ACOMPTE D'UNE COMMANDE DEVENUE FACTURE (1.841.6).
		 *
		 * Un acompte versé sur une commande de services (Studio, agences,
		 * événementiel…) est encaissé AVANT la facture : son reçu ne porte donc
		 * pas de facture, seulement la commande. Une fois la commande facturée,
		 * la facture restait due en entier tant que le comptable n'avait pas
		 * imputé l'acompte à la main — et le client était relancé pour une somme
		 * qu'il avait en partie payée. La commande sait quelle facture elle a
		 * produite : l'acompte s'y rattache, des deux côtés, comme ci-dessus.
		 */
		try {
			$rows = FKC_DB::q(
				"SELECT r.client_id, o.facture_id, COALESCE(SUM(r.montant_ttc),0) s
				 FROM recus r JOIN svc_orders o ON o.id = r.order_id
				 WHERE r.client_id IS NOT NULL AND ( r.facture_id IS NULL OR r.facture_id = 0 )
				   AND r.ecriture_id IS NOT NULL AND r.statut NOT IN ('annule') AND r.sens <> 'decaissement'
				   AND r.type_operation IN ('acompte_client','avance_commande') AND r.rapproche_at IS NULL
				   AND o.facture_id IS NOT NULL AND o.facture_id <> 0
				 GROUP BY r.client_id, o.facture_id"
			)->fetchAll();
			foreach ( $rows as $r ) {
				if ( ! isset( $clients[ (int) $r['client_id'] ] ) ) { continue; }
				$clients[ (int) $r['client_id'] ]['encaisse'] += (float) $r['s'];
				$acomptesFacture[ (int) $r['facture_id'] ] = ( $acomptesFacture[ (int) $r['facture_id'] ] ?? 0.0 ) + (float) $r['s'];
			}
		} catch ( \Throwable $e ) { /* pas de commandes de services dans ce dossier */ }
		/*
		 * UN BROUILLON N'EST PAS UNE CRÉANCE.
		 *
		 * Le filtre n'écartait que les factures annulées. Les BROUILLONS —
		 * devis en cours de rédaction, factures préparées mais non émises —
		 * entraient donc dans l'encours, dans le retard et dans le DSO. Sur un
		 * jeu de test représentatif, l'encours annoncé était de 13 500 000 F
		 * pour 4 500 000 F de créances réelles : le TRIPLE. Et le DSO ressortait
		 * à 365 jours, une valeur absurde que personne ne peut interpréter.
		 *
		 * Le danger n'est pas seulement l'affichage : c'est sur ce chiffre que
		 * l'on décide d'une relance. Relancer un client pour un devis qu'il n'a
		 * jamais reçu abîme la relation commerciale et décrédibilise toutes les
		 * relances suivantes.
		 */
		/*
		 * … MAIS UNE FACTURE COMPTABILISÉE N'EST PAS UN BROUILLON, QUEL QUE
		 * SOIT CE QUE DIT SA COLONNE `statut`.
		 *
		 * Le filtre ci-dessus, seul, vidait le recouvrement de presque tout son
		 * contenu chez la majorité des dossiers. `factures.statut` ne quitte en
		 * effet « brouillon » que dans quatre cas : certification FNE, les trois
		 * chemins de la brique verticale (correctif COM-006), et la perception
		 * du pack gestion collective. Le chemin ORDINAIRE — module Facturation,
		 * save() puis comptabiliser() — ne le repassait jamais.
		 *
		 * Autrement dit : une société qui facture normalement, sans FNE, voyait
		 * un encours de zéro, une balance âgée vide et aucune relance, pendant
		 * que le compte 411 était bien débité. La créance existait en
		 * comptabilité et le module censé la recouvrer l'ignorait.
		 *
		 * La cause est corrigée à la source (FKC_Facture::comptabiliser pose
		 * désormais « validee »). Cette seconde condition rattrape l'EXISTANT :
		 * une écriture au débit du client vaut émission, et les dossiers déjà
		 * installés retrouvent leur encours sans migration ni intervention.
		 */
		$sql = "SELECT id,numero,client_id,client_nom,date_facture,echeance,montant_ttc,statut
			 FROM factures
			 WHERE ( statut IS NULL OR (
			           statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
			           AND ( LOWER(statut) NOT IN ('brouillon','devis','proforma')
			                 OR COALESCE(ecriture_id,0) <> 0 ) ) )
			 ORDER BY date_facture ASC, id ASC";
		try {
			$factures = FKC_DB::q( $sql )->fetchAll();
		} catch ( \Throwable $e ) {
			// Base antérieure à la colonne de liaison comptable : on retombe
			// sur le filtre historique plutôt que de rendre l'écran inutilisable.
			$factures = FKC_DB::q(
				"SELECT id,numero,client_id,client_nom,date_facture,echeance,montant_ttc,statut
				 FROM factures
				 WHERE ( statut IS NULL OR (
				           statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
				           AND LOWER(statut) NOT IN ('brouillon','devis','proforma') ) )
				 ORDER BY date_facture ASC, id ASC"
			)->fetchAll();
		}
		/*
		 * ─────────────────────────────────────────────────────────────────
		 * L'IMPUTATION NOMMÉE PASSE AVANT LE FIFO (1.731.0).
		 *
		 * Ce moteur imputait TOUT l'encaissé du client sur ses factures les
		 * plus anciennes. C'est le bon repli quand personne n'a dit sur quoi
		 * il payait — et une erreur dès que quelqu'un l'a dit. Or deux
		 * sources le disaient déjà : les reçus, qui portent `facture_id`
		 * depuis longtemps, et maintenant les encaissements de la
		 * comptabilité. Le FIFO écrasait les deux.
		 *
		 * Conséquence concrète : un client qui règle la facture de mars en
		 * contestant celle de janvier voyait janvier s'éteindre et mars
		 * rester ouverte. La balance âgée le classait à jour sur sa créance
		 * litigieuse, et la file de relance visait la facture payée.
		 *
		 * LES TOTAUX NE BOUGENT PAS : c'est la même somme, répartie là où
		 * elle a réellement été affectée. Seule la ventilation change — donc
		 * les buckets, l'antériorité et la liste de travail.
		 */
		$imputes = ( class_exists( 'FKC_Imputation' ) )
			? FKC_Imputation::parFacture( array_map( function ( $f ) { return (int) $f['id']; }, $factures ) )
			: array();
		/*
		 * SOURCES DE CRÉANCES (1.841.2) — cotisations, pièces des dossiers
		 * métiers, scolarité, loyers. Elles entrent dans le MÊME lettrage que
		 * les factures, à leur date : c'est ainsi que fonctionne le compte
		 * 411 du client, et c'est ce qui empêche un paiement de cotisation
		 * d'éteindre une facture. Voir FKC_RecouvrementSources.
		 */
		$consomme = array();
		if ( class_exists( 'FKC_RecouvrementSources' ) ) {
			foreach ( FKC_RecouvrementSources::creances() as $sc ) {
				$factures[] = array(
					'id' => 0, 'numero' => $sc['numero'], 'client_id' => $sc['client_id'], 'client_nom' => $sc['tiers_nom'],
					'date_facture' => $sc['date'], 'echeance' => $sc['echeance'] ?: null, 'montant_ttc' => $sc['montant'],
					'statut' => 'source', 'source' => $sc['source'], 'source_ref' => $sc['ref'],
					'source_paye' => $sc['paye'], 'route' => $sc['route'], 'telephone_source' => $sc['telephone'],
				);
			}
			$consomme = FKC_RecouvrementSources::consommeParClient();
			usort( $factures, function ( $a, $b ) {
				$c = strcmp( (string) $a['date_facture'], (string) $b['date_facture'] );
				if ( 0 !== $c ) { return $c; }
				// À date égale, la facture avant la pièce de source, puis l'ordre de saisie.
				$sa = isset( $a['source'] ) ? 1 : 0; $sb = isset( $b['source'] ) ? 1 : 0;
				if ( $sa !== $sb ) { return $sa <=> $sb; }
				return ( (int) $a['id'] <=> (int) $b['id'] ) ?: ( (int) ( $a['source_ref'] ?? 0 ) <=> (int) ( $b['source_ref'] ?? 0 ) );
			} );
		}
		foreach ( $acomptesFacture as $fid => $m ) { $imputes[ $fid ] = ( $imputes[ $fid ] ?? 0.0 ) + $m; }
		/*
		 * AVOIRS (1.841.1) — un avoir qui désigne sa facture d'origine éteint
		 * CELLE-CI. Versé au pool FIFO, il soldait la facture la plus ancienne
		 * et laissait ouverte — donc relancée — la facture qu'il annulait.
		 * Seul le surplus (origine déjà réglée, avoir sans origine) reste un
		 * crédit libre qui rejoint le pool.
		 */
		if ( class_exists( 'FKC_Imputation' ) && method_exists( 'FKC_Imputation', 'avoirsAffectes' ) ) {
			$affect = FKC_Imputation::avoirsAffectes( $factures, $imputes );
		} else {
			$affect = array( 'par_facture' => array(), 'libres' => array() );
			foreach ( $factures as $f ) { if ( (float) $f['montant_ttc'] < 0 ) { $cid = (int) $f['client_id']; $affect['libres'][ $cid ] = ( $affect['libres'][ $cid ] ?? 0 ) + -(float) $f['montant_ttc']; } }
		}
		$avoirs = $affect['libres'];
		$avoirParFacture = $affect['par_facture'];
		$depre = self::depreciationsParFacture();
		$imputeParClient = array();
		foreach ( $factures as $f ) {
			$m = (float) ( $imputes[ (int) $f['id'] ] ?? 0 );
			if ( 0.0 === $m ) { continue; }
			$cid = (int) $f['client_id'];
			$imputeParClient[ $cid ] = ( $imputeParClient[ $cid ] ?? 0.0 ) + $m;
		}
		// Factures encaissées par un pack hors du circuit client (1.841.6) :
		// elles éteignent la facture sans puiser dans l'encaissé du client.
		$externes = class_exists( 'FKC_RecouvrementSources' ) ? FKC_RecouvrementSources::imputationsExternes() : array();
		$reste = array();
		foreach ( $clients as $cid => $c ) {
			// Le pool FIFO ne porte que ce qui n'a pas été affecté nommément.
			$reste[ $cid ] = $c['encaisse'] + ( $avoirs[ $cid ] ?? 0 ) - ( $imputeParClient[ $cid ] ?? 0 )
				// Ce que les sources ont déjà lettré nommément sur leurs créances.
				- ( $consomme[ $cid ] ?? 0 );
		}

		$worklist = array(); $caRecent = 0.0; $seuilRisque = self::seuilRisque();
		foreach ( $factures as $f ) {
			$cid = (int) $f['client_id'];
			/*
			 * LES CRÉANCES SANS CLIENT RATTACHÉ DISPARAISSAIENT EN SILENCE.
			 *
			 * Une facture dont le client_id est vide — vente à un client de
			 * passage, fiche client supprimée depuis — était simplement sautée.
			 * Elle n'apparaissait ni dans l'encours, ni dans la balance âgée,
			 * ni dans la liste de travail : la créance existait en comptabilité
			 * et personne ne la relançait jamais.
			 *
			 * On les regroupe désormais sous un poste collectif. Ce n'est pas
			 * idéal — on ne peut ni téléphoner ni écrire à un poste collectif —
			 * mais un montant visible qu'on sait devoir rattacher vaut mieux
			 * qu'un montant invisible que personne ne cherche.
			 */
			if ( ! isset( $clients[ $cid ] ) ) {
				if ( ! isset( $clients[0] ) ) {
					$clients[0] = array(
						'id' => 0, 'nom' => 'Créances sans client rattaché', 'telephone' => '', 'email' => '',
						'delai' => 0, 'facture' => 0.0, 'encaisse' => 0.0, 'encours' => 0.0,
						'retard' => 0.0, 'a_risque' => 0.0,
						'buckets' => array( 'courant' => 0.0, 'b0_30' => 0.0, 'b31_60' => 0.0, 'b61_90' => 0.0, 'b90p' => 0.0 ),
						'jours_max' => 0, 'score' => 100, 'risque' => 'faible', 'perte' => 0.0, 'orphelin' => true,
					);
					$reste[0] = 0.0;
				}
				$cid = 0;
			}
			$clients[ $cid ]['facture'] += (float) $f['montant_ttc'];
			if ( strtotime( $f['date_facture'] ) >= strtotime( '-365 day', $today ) ) { $caRecent += (float) $f['montant_ttc']; }
			if ( (float) $f['montant_ttc'] <= 0 ) { continue; } // avoir : déjà intégré au pool de crédit

			// Ce que l'imputation nommée a déjà éteint sur CETTE facture.
			$estSource = isset( $f['source'] );
			$impute = $estSource ? (float) $f['source_paye'] : (float) ( $imputes[ (int) $f['id'] ] ?? 0 ) + (float) ( $externes[ (int) $f['id'] ] ?? 0 );
			$avoirF = $estSource ? 0.0 : (float) ( $avoirParFacture[ (int) $f['id'] ] ?? 0 );
			$base   = (float) $f['montant_ttc'] - $impute - $avoirF;
			if ( $base <= 0 ) { continue; } // facture soldée par imputation explicite ou par son avoir

			$paye = max( 0.0, min( $reste[ $cid ], $base ) );
			$reste[ $cid ] -= $paye;
			$resteFac = round( $base - $paye );
			if ( $resteFac <= 0 ) { continue; }

			/*
			 * UNE CRÉANCE PASSÉE EN PERTE N'EST PLUS À RECOUVRER (1.841.1).
			 *
			 * Le module Dépréciation la sort du bilan (C 416 / D 651) ; ce
			 * moteur, qui ne lisait pas la table `depreciations`, continuait
			 * de la compter dans l'encours, la balance âgée, le DSO et la
			 * file de relance — indéfiniment. Elle est désormais publiée à
			 * part (« perte »), APRÈS le lettrage pour ne pas déplacer
			 * l'imputation des règlements antérieurs. Une créance dépréciée
			 * mais non perdue reste due : on la marque « douteuse ».
			 */
			$etatDepre = $estSource ? null : ( $depre[ (int) $f['id'] ] ?? null );
			if ( 'perte' === $etatDepre ) {
				$clients[ $cid ]['perte'] += $resteFac;
				continue;
			}

			$ech = self::echeance( $f, $clients[ $cid ]['delai'] );
			$jours = (int) floor( ( $today - strtotime( $ech ) ) / 86400 );
			$clients[ $cid ]['buckets'][ self::bucket( $jours ) ] += $resteFac;
			$clients[ $cid ]['encours'] += $resteFac;
			if ( $jours > 0 ) { $clients[ $cid ]['retard'] += $resteFac; }
			if ( $jours >= $seuilRisque ) { $clients[ $cid ]['a_risque'] += $resteFac; }
			if ( $jours > $clients[ $cid ]['jours_max'] ) { $clients[ $cid ]['jours_max'] = $jours; }

			$worklist[] = array(
				'client_id' => $cid, 'client_nom' => $clients[ $cid ]['nom'], 'telephone' => $clients[ $cid ]['telephone'],
				'facture_id' => (int) $f['id'], 'numero' => (string) ( $f['numero'] ?? '' ),
				'date_facture' => $f['date_facture'], 'echeance' => $ech,
				'montant' => $resteFac, 'ttc' => round( (float) $f['montant_ttc'] ), 'impute' => round( $impute ),
				'jours' => $jours, 'bucket' => self::bucket( $jours ),
				'avoir' => round( $avoirF ),
				'douteuse' => ( 'douteuse' === $etatDepre ),
				// Origine de la créance : null pour une facture, code de la
				// source sinon (cotisations, pieces, scolarite, loyers).
				'source' => $estSource ? (string) $f['source'] : null,
				'source_ref' => $estSource ? (int) $f['source_ref'] : null,
				'tiers_nom' => $estSource ? (string) $f['client_nom'] : null,
			);
			if ( $estSource && '' === (string) $clients[ $cid ]['telephone'] && 0 !== $cid ) {
				$worklist[ count( $worklist ) - 1 ]['telephone'] = (string) $f['telephone_source'];
			}
		}

		foreach ( $clients as $cid => &$c ) {
			/*
			 * LE CRÉDIT QUI RESTE APRÈS LE LETTRAGE N'EST PLUS AVALÉ EN SILENCE.
			 *
			 * Le lettrage FIFO impute le payé sur les factures les plus
			 * anciennes. Quand il reste du crédit une fois toutes les factures
			 * servies, ce reliquat disparaissait purement et simplement du
			 * calcul — alors qu'il signale presque toujours quelque chose :
			 * une avance reçue, un règlement saisi deux fois, ou une vente au
			 * comptant encaissée sans facture derrière (le reçu crédite le 411,
			 * rien ne le débite).
			 *
			 * Le danger n'est pas le reliquat lui-même : c'est ce qu'il a
			 * absorbé AVANT de devenir un reliquat. Un crédit sans origine
			 * solde des factures bien réelles, et le client sort de la file de
			 * relance pour des sommes qu'il n'a jamais payées.
			 *
			 * On le publie, on ne le corrige pas : le grand livre dit que le
			 * compte du client est créditeur, et le moteur doit refléter le
			 * grand livre. C'est à l'écran d'anomalies d'expliquer pourquoi.
			 */
			$c['credit'] = round( max( 0.0, (float) ( $reste[ $cid ] ?? 0 ) ) );

			$w = $c['buckets']['b31_60'] * 0.35 + $c['buckets']['b61_90'] * 0.7 + $c['buckets']['b90p'] * 1.0;
			$score = 100.0;
			// Pénalités appliquées uniquement en présence d'un retard effectif : un client dont
			// les factures ne sont pas encore échues n'est pas pénalisé de ne pas avoir déjà payé.
			if ( $c['retard'] > 0 ) {
				if ( $c['facture'] > 0 ) { $score -= 25 * ( 1 - max( 0, min( 1, $c['encaisse'] / $c['facture'] ) ) ); }
				$score -= 60 * ( $w / max( $c['encours'], 1 ) );
			}
			$c['score'] = (int) max( 0, min( 100, round( $score ) ) );
			$c['risque'] = $c['score'] >= 75 ? 'faible' : ( $c['score'] >= 45 ? 'moyen' : 'critique' );
		}
		unset( $c );

		/*
		 * PONT AVEC LE SUIVI — LE MOTEUR L'IGNORAIT TOTALEMENT.
		 *
		 * FKC_RecouvrementSuivi tient les promesses de paiement, les plans
		 * d'apurement et les dossiers contentieux. Le moteur de calcul n'en
		 * lisait AUCUN : zéro référence dans tout le fichier. La liste de
		 * travail proposait donc de relancer, au même titre que les autres :
		 *
		 *   — un client qui a promis de payer vendredi, et dont la promesse
		 *     n'est pas encore échue ;
		 *   — un client qui règle son plan d'apurement à la lettre ;
		 *   — un client déjà en contentieux, dont le dossier est entre les
		 *     mains d'un avocat.
		 *
		 * Les deux premiers cas abîment la relation : on rappelle quelqu'un qui
		 * a fait ce qu'on lui demandait. Le troisième est plus grave — une
		 * relance amiable envoyée après une mise en demeure peut être opposée
		 * au créancier comme une renonciation à sa procédure.
		 *
		 * On ne RETIRE pas ces lignes : les montants restent dus et doivent
		 * figurer dans l'encours. On les marque, pour que l'écran puisse les
		 * écarter de la file de relance sans les faire disparaître du bilan.
		 */
		$suspensions = self::suspensions();
		$promFactures = self::promessesParFacture();
		foreach ( $worklist as &$w ) {
			/*
			 * UNE PROMESSE SUR UNE FACTURE NE COUVRE QUE CETTE FACTURE (1.841.1).
			 * Une promesse de 20 000 F sur une petite facture sortait de la
			 * file un impayé de 900 000 F à quatre-vingts jours. Le plan et le
			 * contentieux, eux, portent sur le client entier et l'emportent.
			 */
			$sc = $suspensions[ $w['client_id'] ] ?? null;
			if ( $sc && 'promesse' !== $sc['type'] ) { $s = $sc; }
			else { $s = $promFactures[ (int) $w['facture_id'] ] ?? $sc; }
			$w['suspendu'] = $s ? $s['motif'] : null;
			$w['suspendu_type'] = $s ? $s['type'] : null;
			$w['relancable'] = ( null === $w['suspendu'] );
		}
		unset( $w );

		usort( $worklist, function ( $a, $b ) {
			// Les lignes relançables d'abord : c'est une file de travail, elle
			// doit commencer par ce sur quoi on peut agir aujourd'hui.
			if ( $a['relancable'] !== $b['relancable'] ) { return $a['relancable'] ? -1 : 1; }
			return $b['jours'] <=> $a['jours'];
		} );

		$tFacture = 0; $tEncaisse = 0; $tEncours = 0; $tRetard = 0; $tRisque = 0;
		$agg = array( 'courant' => 0.0, 'b0_30' => 0.0, 'b31_60' => 0.0, 'b61_90' => 0.0, 'b90p' => 0.0 );
		foreach ( $clients as $c ) {
			$tFacture += $c['facture']; $tEncaisse += $c['encaisse']; $tEncours += $c['encours'];
			$tRetard += $c['retard']; $tRisque += $c['a_risque'];
			foreach ( $agg as $k => $v ) { $agg[ $k ] += $c['buckets'][ $k ]; }
		}
		$dso = $caRecent > 0 ? round( $tEncours / $caRecent * 365 ) : 0;
		$kpis = array(
			'facture' => round( $tFacture ), 'encaisse' => round( $tEncaisse ), 'encours' => round( $tEncours ),
			'retard' => round( $tRetard ), 'a_risque' => round( $tRisque ),
			'dso' => $dso, 'taux' => $tFacture > 0 ? round( $tEncaisse / $tFacture * 100, 1 ) : 0,
			'aging' => $agg, 'nb_clients_retard' => count( array_filter( $clients, function ( $c ) { return $c['retard'] > 0; } ) ),
			/*
			 * TROIS INDICATEURS QUI MANQUAIENT, ET QUI CHANGENT LA LECTURE.
			 *
			 * « encours » et « retard » disent l'état du poste client ; ils ne
			 * disent pas ce qu'il y a À FAIRE. Un directeur qui voit 40 M de
			 * retard ne sait pas si son équipe a du travail devant elle ou si
			 * tout est déjà sous promesse.
			 */
			'a_relancer'      => round( array_sum( array_map(
				function ( $w ) { return $w['relancable'] ? $w['montant'] : 0; }, $worklist ) ) ),
			'sous_accord'     => round( array_sum( array_map(
				function ( $w ) { return $w['relancable'] ? 0 : $w['montant']; }, $worklist ) ) ),
			'nb_a_relancer'   => count( array_filter( $worklist, function ( $w ) { return $w['relancable']; } ) ),
			// Part de l'encours qui a dépassé le seuil de précontentieux : c'est
			// elle qui justifie une provision pour dépréciation, pas le retard brut.
			'part_douteuse'   => $tEncours > 0 ? round( $tRisque / $tEncours * 100, 1 ) : 0,
			'creances_orphelines' => round( $clients[0]['encours'] ?? 0 ),
			// Crédit resté sans emploi après lettrage : avances légitimes, mais
			// aussi doubles saisies et encaissements sans facture. Un montant
			// qui grossit ici est un poste client qui se déforme.
			'credits_non_affectes' => round( array_sum( array_map(
				function ( $c ) { return (float) ( $c['credit'] ?? 0 ); }, $clients ) ) ),
			// Encours par origine (1.841.2) : 'factures' + une clé par source.
			'origines' => ( function () use ( $worklist ) {
				$o = array();
				foreach ( $worklist as $w ) { $k = $w['source'] ?? null; $k = $k ?: 'factures'; $o[ $k ] = ( $o[ $k ] ?? 0 ) + (float) $w['montant']; }
				return array_map( 'round', $o );
			} )(),
			// Restes de factures passées en perte (1.841.1) : hors encours, hors relance.
			'passe_en_perte' => round( array_sum( array_map(
				function ( $c ) { return (float) ( $c['perte'] ?? 0 ); }, $clients ) ) ),
		);
		return array( 'clients' => $clients, 'factures' => $worklist, 'kpis' => $kpis );
	}

	/**
	 * État de dépréciation par facture (1.841.1) : 'perte' ou 'douteuse'.
	 *
	 * « perte » : la créance est sortie du bilan, elle n'est plus à recouvrer.
	 * « douteuse » : provision engagée (comptabilisée ou au journal
	 * temporaire), la créance reste due et se relance. Une analyse en cours,
	 * abandonnée ou reprise ne qualifie pas la créance.
	 *
	 * @return array facture_id => 'perte'|'douteuse'
	 */
	public static function depreciationsParFacture() {
		$out = array();
		try {
			$rows = FKC_DB::q(
				"SELECT facture_id, statut FROM depreciations
				 WHERE facture_id IS NOT NULL AND statut IN ('perte','comptabilisee','en_attente')"
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; } // module Dépréciation jamais ouvert : table absente
		foreach ( $rows as $r ) {
			$fid = (int) $r['facture_id'];
			if ( 'perte' === ( $out[ $fid ] ?? '' ) ) { continue; }
			$out[ $fid ] = 'perte' === (string) $r['statut'] ? 'perte' : 'douteuse';
		}
		return $out;
	}

	/**
	 * ANOMALIES DU POSTE CLIENT — CE QUI FAUSSE LE RECOUVREMENT SANS ERREUR DE CALCUL.
	 *
	 * Le moteur reflète fidèlement le grand livre. C'est précisément pourquoi
	 * il ne peut pas, seul, distinguer un client qui a payé d'un client dont le
	 * compte a été crédité par erreur : les deux se présentent de la même
	 * façon. Le lettrage FIFO impute alors ce crédit sur des factures bien
	 * réelles, et le client sort de la file de relance sans avoir rien réglé.
	 *
	 * Aucun de ces cas n'est un défaut du code : ce sont des saisies, des
	 * oublis, des fiches manquantes. Mais tant qu'ils restaient invisibles,
	 * ils rendaient l'encours faux sans que rien ne le signale — la pire
	 * combinaison, parce qu'on continue de décider sur ce chiffre.
	 *
	 * On ne corrige rien d'autorité : chaque anomalie nomme sa cause probable
	 * et le geste qui la lève. Certaines sont parfaitement normales — une
	 * avance reçue avant facturation est un crédit légitime.
	 *
	 * @return array liste triée par gravité puis montant décroissant
	 */
	public static function anomalies( $donnees = null ) {
		$d = ( is_array( $donnees ) && isset( $donnees['clients'] ) ) ? $donnees : self::compute();
		$out = array();

		/* 1. Crédit resté sans emploi après lettrage. */
		foreach ( $d['clients'] as $cid => $c ) {
			if ( (float) ( $c['credit'] ?? 0 ) <= 0 ) { continue; }
			$out[] = array(
				'type' => 'credit_non_affecte', 'gravite' => 2,
				'client_id' => (int) $cid, 'client_nom' => (string) $c['nom'],
				'montant' => (float) $c['credit'],
				'libelle' => 'Solde créditeur non affecté',
				'explication' => 'Le compte de ce client est créditeur une fois toutes ses factures soldées. '
					. 'Ce crédit a d\'abord servi à éteindre les factures les plus anciennes : si son origine '
					. 'n\'est pas une avance réelle, des créances ont été soldées à tort et le client n\'est '
					. 'plus relancé pour elles.',
				'geste' => 'Vérifier les encaissements de ce client : avance à facturer, règlement saisi deux '
					. 'fois, ou vente au comptant encaissée sans facture.',
				'lien' => 'recouvrement/clients/' . (int) $cid,
			);
		}

		/*
		 * 2. Vente au comptant encaissée sans facture — LA CAUSE LA PLUS
		 *    FRÉQUENTE du cas précédent, et la seule qu'on puisse nommer.
		 *
		 * Le reçu de vente au comptant crédite le compte du client (D
		 * trésorerie / C 411) en attendant que sa transformation en facture
		 * vienne le débiter. Tant que la transformation n'a pas lieu, il ne
		 * reste que la moitié créditrice de l'opération.
		 */
		try {
			$rows = FKC_DB::q(
				"SELECT r.id, r.numero, r.date_recu, r.montant_ttc, r.client_id, c.nom
				 FROM recus r LEFT JOIN clients c ON c.id = r.client_id
				 WHERE r.type_operation='vente_comptant' AND r.client_id IS NOT NULL
				   AND r.ecriture_id IS NOT NULL
				   AND r.statut NOT IN ('annule','transforme')
				 ORDER BY r.date_recu ASC"
			)->fetchAll();
			foreach ( $rows as $r ) {
				$out[] = array(
					'type' => 'comptant_non_facture', 'gravite' => 2,
					'client_id' => (int) $r['client_id'], 'client_nom' => (string) ( $r['nom'] ?: '—' ),
					'montant' => (float) $r['montant_ttc'],
					'reference' => (string) $r['numero'], 'date' => (string) $r['date_recu'],
					'libelle' => 'Vente au comptant encaissée sans facture',
					'explication' => 'Ce reçu a crédité le compte du client sans qu\'aucune facture ne vienne '
						. 'le débiter. Le crédit obtenu vient éteindre d\'autres créances au lettrage.',
					'geste' => 'Transformer le reçu en facture depuis le module Encaissement.',
					'lien' => 'encaissement/' . (int) $r['id'],
				);
			}
		} catch ( \Throwable $e ) { /* module Encaissement absent */ }

		/* 3. Créances sans fiche client : personne ne peut les relancer. */
		if ( ( $d['clients'][0]['encours'] ?? 0 ) > 0 ) {
			try {
				$rows = FKC_DB::q(
					"SELECT id, numero, date_facture, montant_ttc, client_nom
					 FROM factures
					 WHERE ( client_id IS NULL OR client_id=0
					         OR client_id NOT IN (SELECT id FROM clients) )
					   AND montant_ttc > 0
					   AND ( statut IS NULL OR ( statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
					         AND ( LOWER(statut) NOT IN ('brouillon','devis','proforma')
					               OR COALESCE(ecriture_id,0) <> 0 ) ) )
					 ORDER BY date_facture ASC"
				)->fetchAll();
				foreach ( $rows as $r ) {
					$out[] = array(
						'type' => 'creance_orpheline', 'gravite' => 3,
						'client_id' => 0, 'client_nom' => (string) ( $r['client_nom'] ?: '—' ),
						'montant' => (float) $r['montant_ttc'],
						'reference' => (string) $r['numero'], 'date' => (string) $r['date_facture'],
						'libelle' => 'Créance sans fiche client',
						'explication' => 'Cette facture n\'est rattachée à aucune fiche client : on ne peut ni '
							. 'la relancer, ni la mettre en demeure, ni la suivre.',
						'geste' => 'Rattacher la facture à une fiche client, ou créer la fiche manquante.',
						'lien' => 'facturation/factures/' . (int) $r['id'],
					);
				}
			} catch ( \Throwable $e ) {}
		}

		/*
		 * 3 bis. Créances d'une source dont le tiers n'a pas de fiche client
		 * (1.841.2) : un parent d'élève, un locataire connus du seul pack. Le
		 * geste est unique pour toute la source — « rattacher les tiers » —
		 * d'où une anomalie par source et non par pièce.
		 */
		$parSource = array();
		foreach ( $d['factures'] as $w ) {
			if ( empty( $w['source'] ) || 0 !== (int) $w['client_id'] ) { continue; }
			$parSource[ $w['source'] ] = ( $parSource[ $w['source'] ] ?? 0.0 ) + (float) $w['montant'];
		}
		foreach ( $parSource as $code => $m ) {
			$lib = class_exists( 'FKC_RecouvrementSources' ) && ( $src = FKC_RecouvrementSources::get( $code ) ) ? $src['libelle'] : $code;
			$out[] = array(
				'type' => 'source_sans_tiers_' . $code, 'gravite' => 3,
				'client_id' => 0, 'client_nom' => $lib, 'montant' => $m,
				'libelle' => 'Créances « ' . $lib . ' » sans fiche client',
				'explication' => 'Ces créances sont connues du pack mais leurs débiteurs n\'ont pas de fiche client : '
					. 'on ne peut ni les relancer, ni suivre leurs promesses, ni les mettre en demeure.',
				'geste' => 'Rattacher les tiers depuis l\'écran « Sources de créances » : une fiche est créée (ou reprise) pour chacun.',
				'lien' => 'recouvrement/sources',
			);
		}

		/*
		 * 4. Facture sans échéance chez un client sans délai de paiement.
		 *
		 * Le moteur retombe alors sur la date de facture : la créance est
		 * réputée exigible le jour même de son émission, et se retrouve en
		 * retard dès le lendemain. Ce n'est pas un calcul faux — c'est la seule
		 * hypothèse raisonnable — mais c'est une hypothèse, et elle envoie des
		 * relances à des clients qui ont réellement trente jours devant eux.
		 */
		try {
			$rows = FKC_DB::q(
				"SELECT f.id, f.numero, f.date_facture, f.montant_ttc, f.client_id, c.nom
				 FROM factures f JOIN clients c ON c.id = f.client_id
				 WHERE ( f.echeance IS NULL OR f.echeance='' )
				   AND COALESCE(c.delai_paiement,0) = 0
				   AND f.montant_ttc > 0
				   AND ( f.statut IS NULL OR ( f.statut NOT LIKE 'annul%' AND f.statut NOT LIKE 'ANNUL%'
				         AND ( LOWER(f.statut) NOT IN ('brouillon','devis','proforma')
				               OR COALESCE(f.ecriture_id,0) <> 0 ) ) )
				 ORDER BY f.date_facture ASC"
			)->fetchAll();
			foreach ( $rows as $r ) {
				if ( 0.0 === (float) ( $d['clients'][ (int) $r['client_id'] ]['encours'] ?? 0 ) ) { continue; }
				$out[] = array(
					'type' => 'sans_echeance', 'gravite' => 1,
					'client_id' => (int) $r['client_id'], 'client_nom' => (string) $r['nom'],
					'montant' => (float) $r['montant_ttc'],
					'reference' => (string) $r['numero'], 'date' => (string) $r['date_facture'],
					'libelle' => 'Facture sans échéance, client sans délai',
					'explication' => 'Faute d\'échéance et de délai sur la fiche client, cette créance est '
						. 'réputée exigible le jour de son émission — elle bascule en retard dès le lendemain.',
					'geste' => 'Renseigner le délai de paiement sur la fiche client, ou l\'échéance sur la facture.',
					'lien' => 'recouvrement/clients/' . (int) $r['client_id'],
				);
			}
		} catch ( \Throwable $e ) {}

		usort( $out, function ( $a, $b ) {
			if ( $a['gravite'] !== $b['gravite'] ) { return $b['gravite'] <=> $a['gravite']; }
			return $b['montant'] <=> $a['montant'];
		} );
		return $out;
	}

	/** Nombre d'anomalies, pour la pastille des écrans. */
	public static function nbAnomalies( $donnees = null ) { return count( self::anomalies( $donnees ) ); }

	/**
	 * Clients dont la relance amiable doit être suspendue, et pourquoi.
	 *
	 * L'ordre de priorité n'est pas arbitraire : le contentieux l'emporte sur
	 * tout, parce qu'une relance amiable envoyée après une mise en demeure peut
	 * être opposée au créancier comme une renonciation à sa procédure. Vient le
	 * plan d'apurement, puis la promesse — la plus fragile des trois, puisqu'une
	 * promesse échue et non tenue redevient immédiatement relançable.
	 *
	 * @return array client_id => array{type, motif}
	 */
	public static function suspensions() {
		$out = array();
		if ( ! class_exists( 'FKC_RecouvrementSuivi' ) ) { return $out; }
		$today = date( 'Y-m-d' );

		try {
			foreach ( FKC_RecouvrementSuivi::promesses( 'en_attente' ) as $p ) {
				// Une promesse ÉCHUE ne protège plus : c'est même le premier
				// motif de relance, et il est plus ferme que les autres.
				if ( ! empty( $p['date_promesse'] ) && $p['date_promesse'] < $today ) { continue; }
				// Une promesse qui désigne sa facture ne protège qu'elle :
				// voir promessesParFacture() (1.841.1).
				if ( ! empty( $p['facture_id'] ) ) { continue; }
				$out[ (int) $p['client_id'] ] = array(
					'type'  => 'promesse',
					'motif' => 'Promesse de paiement pour le ' . $p['date_promesse'],
				);
			}
		} catch ( \Throwable $e ) {}

		/*
		 * UN PLAN NE PROTÈGE QUE TANT QU'IL EST HONORÉ — ET TANT QU'IL EXISTE.
		 *
		 * Deux défauts se cumulaient ici, et tous deux allaient dans le même
		 * sens : ne jamais relancer.
		 *
		 *   1. La liste d'exclusion retenait « clos », « annule » et « rompu ».
		 *      Or echeancePayee() écrit « solde » — un statut qui n'y figurait
		 *      pas. Un plan intégralement réglé continuait donc de suspendre la
		 *      relance de son client POUR TOUJOURS, y compris sur les factures
		 *      émises bien après lui.
		 *
		 *   2. Aucune échéance n'était regardée. Le commentaire du moteur parle
		 *      d'« un client qui règle son plan d'apurement à la lettre » ; le
		 *      code, lui, protégeait aussi bien celui qui n'avait jamais rien
		 *      versé. Il suffisait de signer un échéancier pour sortir
		 *      définitivement de la file de relance.
		 *
		 * Un plan dont une échéance est passée sans être payée est un plan
		 * rompu dans les faits. On ne le REQUALIFIE pas d'autorité en base —
		 * c'est une décision commerciale, qui appartient à l'utilisateur — mais
		 * il cesse de protéger, et le motif le dit.
		 */
		try {
			foreach ( FKC_RecouvrementSuivi::plans() as $pl ) {
				$statut = (string) ( $pl['statut'] ?? '' );
				if ( in_array( $statut, array( 'clos', 'annule', 'rompu', 'solde' ), true ) ) { continue; }
				if ( FKC_RecouvrementSuivi::planEnDefaut( (int) $pl['id'] ) ) { continue; }
				$out[ (int) $pl['client_id'] ] = array(
					'type'  => 'plan',
					'motif' => 'Plan d\'apurement en cours et respecté',
				);
			}
		} catch ( \Throwable $e ) {}

		try {
			foreach ( FKC_RecouvrementSuivi::dossiers() as $d ) {
				if ( 'clos' === (string) ( $d['statut'] ?? '' ) ) { continue; }
				$out[ (int) $d['client_id'] ] = array(
					'type'  => 'contentieux',
					'motif' => 'Dossier ' . ( FKC_RecouvrementSuivi::statutsDossier()[ $d['statut'] ] ?? $d['statut'] )
						. ' — la relance amiable est suspendue',
				);
			}
		} catch ( \Throwable $e ) {}

		return $out;
	}

	/**
	 * Promesses en cours qui désignent une facture précise (1.841.1).
	 *
	 * @return array facture_id => array{type, motif}
	 */
	public static function promessesParFacture() {
		$out = array();
		if ( ! class_exists( 'FKC_RecouvrementSuivi' ) ) { return $out; }
		$today = date( 'Y-m-d' );
		try {
			foreach ( FKC_RecouvrementSuivi::promesses( 'en_attente' ) as $p ) {
				if ( empty( $p['facture_id'] ) ) { continue; }
				if ( ! empty( $p['date_promesse'] ) && $p['date_promesse'] < $today ) { continue; }
				$out[ (int) $p['facture_id'] ] = array(
					'type'  => 'promesse',
					'motif' => 'Promesse de paiement pour le ' . $p['date_promesse'],
				);
			}
		} catch ( \Throwable $e ) {}
		return $out;
	}

	/**
	 * Le nom des débiteurs dans le vocabulaire du métier (1.841.4).
	 *
	 * « Clients » à la pharmacie, « Locataires » en gérance, « Membres » dans
	 * une association : c'est le mot du pack. Une exception, et elle compte :
	 * à l'école, le débiteur n'est pas l'élève mais sa famille — relancer
	 * « les élèves » serait à la fois faux et maladroit.
	 *
	 * @param bool $pluriel
	 */
	public static function motDebiteur( $pluriel = true ) {
		$mot = class_exists( 'FKC_UxVocabulaire' )
			? FKC_UxVocabulaire::mot( $pluriel ? 'clients' : 'client', $pluriel ? 'Clients' : 'Client' )
			: ( $pluriel ? 'Clients' : 'Client' );
		$exceptions = array( 'Élèves' => 'Familles', 'Élève' => 'Famille' );
		return $exceptions[ $mot ] ?? $mot;
	}

	public static function risqueLabel( $r ) {
		$m = array( 'faible' => '🟢 Faible', 'moyen' => '🟠 Moyen', 'critique' => '🔴 Critique' );
		return $m[ $r ] ?? $r;
	}
	public static function scoreLabel( $score ) {
		if ( $score >= 85 ) { return 'Excellent payeur'; }
		if ( $score >= 70 ) { return 'Bon payeur'; }
		if ( $score >= 45 ) { return 'Payeur moyen'; }
		return 'Payeur à risque';
	}
	public static function bucketLabel( $b ) {
		$m = array( 'courant' => 'Non échu', 'b0_30' => '0-30 j', 'b31_60' => '31-60 j', 'b61_90' => '61-90 j', 'b90p' => '90+ j' );
		return $m[ $b ] ?? $b;
	}
	public static function client( $clientId, $donnees = null ) {
		$d = ( is_array( $donnees ) && isset( $donnees['clients'] ) ) ? $donnees : self::compute();
		return $d['clients'][ (int) $clientId ] ?? null;
	}
}
