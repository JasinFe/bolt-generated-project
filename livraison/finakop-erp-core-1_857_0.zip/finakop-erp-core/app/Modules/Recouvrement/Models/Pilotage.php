<?php
/**
 * PILOTAGE DU RECOUVREMENT (1.841.5).
 *
 * Le tableau de bord dit où en est le poste client AUJOURD'HUI. Il ne dit ni
 * si cela va mieux qu'il y a trois mois, ni si l'équipe encaisse ce qu'elle
 * pourrait encaisser, ni qui, dans l'équipe, obtient des résultats. Ce
 * modèle y répond, sans second moteur : tout part de FKC_Recouvrement.
 *
 *  — PHOTO MENSUELLE de la balance âgée. Une balance âgée ne se reconstitue
 *    pas après coup : les règlements lettrés depuis effacent l'ancienneté
 *    qu'avaient les créances. On la photographie donc — à chaque ouverture
 *    du tableau de bord et à chaque passage planifié — et la dernière photo
 *    d'un mois devient sa photo de fin de mois.
 *
 *  — DSO GLISSANT 90 JOURS, à côté du DSO sur douze mois : le second lisse
 *    tout, le premier montre une dérive dès qu'elle commence.
 *
 *  — CEI (Collection Effectiveness Index) : sur un mois, la part de ce qui
 *    POUVAIT être encaissé qui l'a été.
 *      CEI = (encours début + facturé du mois − encours fin)
 *          / (encours début + facturé du mois − non échu fin)
 *    100 % : tout ce qui était exigible est rentré. Il exige deux photos
 *    consécutives ; il ne s'affiche qu'à partir de là.
 *
 *  — TAUX DE PROMESSES TENUES, sur les promesses constatées (1.841.3).
 *
 *  — PERFORMANCE PAR AGENT : contacts, promesses obtenues et tenues, et part
 *    des contacts suivis d'un paiement du client sous quinze jours. C'est
 *    une ASSOCIATION, pas une preuve : l'agent qui appelle les meilleurs
 *    payeurs aura un bon taux. Elle se lit avec le volume, jamais seule.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RecouvrementPilotage {

	const FENETRE_EFFET = 15;

	protected static $pret = false;
	public static function ensure() {
		if ( self::$pret ) { return; }
		FKC_DB::conn()->exec( "CREATE TABLE IF NOT EXISTS recouvrement_photos(
			mois TEXT PRIMARY KEY,
			encours REAL NOT NULL DEFAULT 0, retard REAL NOT NULL DEFAULT 0, a_risque REAL NOT NULL DEFAULT 0,
			courant REAL NOT NULL DEFAULT 0, b0_30 REAL NOT NULL DEFAULT 0, b31_60 REAL NOT NULL DEFAULT 0,
			b61_90 REAL NOT NULL DEFAULT 0, b90p REAL NOT NULL DEFAULT 0,
			facture_mois REAL NOT NULL DEFAULT 0, encaisse_mois REAL NOT NULL DEFAULT 0,
			dso INTEGER NOT NULL DEFAULT 0, dso_90 INTEGER NOT NULL DEFAULT 0,
			nb_clients_retard INTEGER NOT NULL DEFAULT 0,
			pris_le TEXT DEFAULT(datetime('now','localtime'))
		)" );
		self::$pret = true;
	}

	/* ═══════════════ Montants de période ═══════════════ */

	/**
	 * Facturé entre deux dates : factures émises (même filtre que le moteur)
	 * et créances des sources, avoirs déduits.
	 */
	public static function facture( $du, $au ) {
		$t = 0.0;
		try {
			$t += (float) FKC_DB::q(
				"SELECT COALESCE(SUM(montant_ttc),0) FROM factures
				 WHERE date_facture BETWEEN ? AND ?
				   AND ( statut IS NULL OR ( statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'
				         AND ( LOWER(statut) NOT IN ('brouillon','devis','proforma') OR COALESCE(ecriture_id,0) <> 0 ) ) )",
				array( $du, $au )
			)->fetchColumn();
		} catch ( \Throwable $e ) {}
		if ( class_exists( 'FKC_RecouvrementSources' ) ) {
			foreach ( FKC_RecouvrementSources::creances() as $c ) {
				if ( $c['date'] >= $du && $c['date'] <= $au ) { $t += (float) $c['montant']; }
			}
		}
		return round( $t );
	}

	/** Encaissé entre deux dates : règlements clients et reçus comptés par le moteur. */
	public static function encaisse( $du, $au ) {
		$t = 0.0;
		try {
			$t += (float) FKC_DB::q( "SELECT COALESCE(SUM(montant),0) FROM reglements WHERE sens='encaissement' AND tiers_type='client'
				AND COALESCE(statut,'actif')<>'annule' AND date_reglement BETWEEN ? AND ?", array( $du, $au ) )->fetchColumn();
		} catch ( \Throwable $e ) {}
		try {
			$t += (float) FKC_DB::q( "SELECT COALESCE(SUM(CASE WHEN sens='decaissement' THEN -montant_ttc ELSE montant_ttc END),0) FROM recus
				WHERE client_id IS NOT NULL AND ecriture_id IS NOT NULL AND statut NOT IN ('annule') AND date_recu BETWEEN ? AND ?
				AND type_operation IN ('paiement_facture','vente_comptant','remboursement','acompte_client','avance_commande')", array( $du, $au ) )->fetchColumn();
		} catch ( \Throwable $e ) {}
		return round( $t );
	}

	/** DSO glissant sur N jours : encours / facturé sur N jours × N. */
	public static function dsoGlissant( $jours = 90, $donnees = null ) {
		$d = ( is_array( $donnees ) && isset( $donnees['kpis'] ) ) ? $donnees : FKC_Recouvrement::compute();
		$ca = self::facture( date( 'Y-m-d', strtotime( '-' . (int) $jours . ' day' ) ), date( 'Y-m-d' ) );
		return $ca > 0 ? (int) round( (float) $d['kpis']['encours'] / $ca * (int) $jours ) : 0;
	}

	/* ═══════════════ Photos mensuelles ═══════════════ */

	/** Photographie le poste client du mois en cours (remplace la photo du mois). */
	public static function photographier( $donnees = null ) {
		self::ensure();
		$d = ( is_array( $donnees ) && isset( $donnees['kpis'] ) ) ? $donnees : FKC_Recouvrement::compute();
		$k = $d['kpis']; $ag = $k['aging'];
		$mois = date( 'Y-m' );
		$du = $mois . '-01'; $au = date( 'Y-m-t' );
		FKC_DB::q(
			"INSERT OR REPLACE INTO recouvrement_photos(mois,encours,retard,a_risque,courant,b0_30,b31_60,b61_90,b90p,facture_mois,encaisse_mois,dso,dso_90,nb_clients_retard,pris_le)
			 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now','localtime'))",
			array( $mois, (float) $k['encours'], (float) $k['retard'], (float) $k['a_risque'],
				(float) $ag['courant'], (float) $ag['b0_30'], (float) $ag['b31_60'], (float) $ag['b61_90'], (float) $ag['b90p'],
				self::facture( $du, $au ), self::encaisse( $du, $au ), (int) $k['dso'], self::dsoGlissant( 90, $d ),
				(int) $k['nb_clients_retard'] )
		);
		return $mois;
	}

	/**
	 * Historique des photos, du plus ancien au plus récent, avec le CEI de
	 * chaque mois qui a une photo le mois précédent.
	 */
	public static function historique( $nb = 12 ) {
		self::ensure();
		$rows = array_reverse( FKC_DB::q( 'SELECT * FROM recouvrement_photos ORDER BY mois DESC LIMIT ' . max( 1, (int) $nb + 1 ) )->fetchAll() );
		$out = array(); $prec = null;
		foreach ( $rows as $r ) {
			$r['cei'] = null;
			if ( $prec && date( 'Y-m', strtotime( $prec['mois'] . '-01 +1 month' ) ) === $r['mois'] ) {
				$r['cei'] = self::cei( (float) $prec['encours'], (float) $r['facture_mois'], (float) $r['encours'], (float) $r['courant'] );
			}
			$out[] = $r; $prec = $r;
		}
		return array_slice( $out, -max( 1, (int) $nb ) );
	}

	/** CEI en %, ou null si le dénominateur est nul. */
	public static function cei( $encoursDebut, $factureMois, $encoursFin, $nonEchuFin ) {
		$den = $encoursDebut + $factureMois - $nonEchuFin;
		if ( $den <= 0 ) { return null; }
		return round( max( 0.0, min( 100.0, ( $encoursDebut + $factureMois - $encoursFin ) / $den * 100 ) ), 1 );
	}

	/* ═══════════════ Promesses ═══════════════ */

	/** @return array{tenues:int, non_tenues:int, taux:float|null} sur les N derniers jours */
	public static function promesses( $jours = 90 ) {
		$out = array( 'tenues' => 0, 'non_tenues' => 0, 'taux' => null );
		$depuis = date( 'Y-m-d', strtotime( '-' . (int) $jours . ' day' ) );
		try {
			if ( class_exists( 'FKC_RecouvrementSuivi' ) ) { FKC_RecouvrementSuivi::ensurePromesses(); }
			$r = FKC_DB::q( "SELECT SUM(CASE WHEN statut='tenue' THEN 1 ELSE 0 END) t, SUM(CASE WHEN statut='non_tenue' THEN 1 ELSE 0 END) n
				FROM recouvrement_promesses WHERE statut IN ('tenue','non_tenue') AND COALESCE(substr(constate_le,1,10), date_promesse) >= ?", array( $depuis ) )->fetch();
			$out['tenues'] = (int) ( $r['t'] ?? 0 ); $out['non_tenues'] = (int) ( $r['n'] ?? 0 );
		} catch ( \Throwable $e ) {}
		$tot = $out['tenues'] + $out['non_tenues'];
		$out['taux'] = $tot > 0 ? round( $out['tenues'] / $tot * 100, 1 ) : null;
		return $out;
	}

	/* ═══════════════ Agents ═══════════════ */

	/**
	 * Activité et résultats par agent sur les N derniers jours.
	 *
	 * @return array liste triée par contacts décroissants
	 */
	public static function agents( $jours = 30 ) {
		$depuis = date( 'Y-m-d', strtotime( '-' . (int) $jours . ' day' ) );
		$ag = array();
		$init = function ( $uid ) use ( &$ag ) {
			if ( ! isset( $ag[ $uid ] ) ) {
				$ag[ $uid ] = array( 'user_id' => $uid, 'nom' => '', 'relances' => 0, 'appels' => 0, 'mises_en_demeure' => 0,
					'contacts' => 0, 'suivis_paiement' => 0, 'taux_effet' => null,
					'promesses' => 0, 'montant_promis' => 0.0, 'promesses_tenues' => 0, 'promesses_non_tenues' => 0 );
			}
		};
		try {
			$acts = FKC_DB::q( "SELECT created_by, client_id, type, date(created_at) jour FROM recouvrement_actions
				WHERE type IN ('relance','appel','mise_en_demeure') AND created_by IS NOT NULL AND date(created_at) >= ?", array( $depuis ) )->fetchAll();
		} catch ( \Throwable $e ) { $acts = array(); }
		// Paiements par client, en une lecture.
		$paiements = array();
		try {
			foreach ( FKC_DB::q( "SELECT tiers_id c, date_reglement j FROM reglements WHERE sens='encaissement' AND tiers_type='client'
				AND COALESCE(statut,'actif')<>'annule' AND date_reglement >= ?", array( $depuis ) )->fetchAll() as $p ) { $paiements[ (int) $p['c'] ][] = $p['j']; }
		} catch ( \Throwable $e ) {}
		try {
			foreach ( FKC_DB::q( "SELECT client_id c, date_recu j FROM recus WHERE client_id IS NOT NULL AND ecriture_id IS NOT NULL
				AND statut NOT IN ('annule') AND sens<>'decaissement' AND date_recu >= ?", array( $depuis ) )->fetchAll() as $p ) { $paiements[ (int) $p['c'] ][] = $p['j']; }
		} catch ( \Throwable $e ) {}
		foreach ( $acts as $a ) {
			$uid = (int) $a['created_by']; $init( $uid );
			$cle = 'relance' === $a['type'] ? 'relances' : ( 'appel' === $a['type'] ? 'appels' : 'mises_en_demeure' );
			$ag[ $uid ][ $cle ]++; $ag[ $uid ]['contacts']++;
			$fin = date( 'Y-m-d', strtotime( $a['jour'] . ' +' . self::FENETRE_EFFET . ' day' ) );
			foreach ( $paiements[ (int) $a['client_id'] ] ?? array() as $j ) {
				if ( $j >= $a['jour'] && $j <= $fin ) { $ag[ $uid ]['suivis_paiement']++; break; }
			}
		}
		try {
			foreach ( FKC_DB::q( "SELECT created_by, statut, montant FROM recouvrement_promesses WHERE created_by IS NOT NULL AND date(created_at) >= ?", array( $depuis ) )->fetchAll() as $p ) {
				$uid = (int) $p['created_by']; $init( $uid );
				$ag[ $uid ]['promesses']++; $ag[ $uid ]['montant_promis'] += (float) $p['montant'];
				if ( 'tenue' === $p['statut'] ) { $ag[ $uid ]['promesses_tenues']++; }
				if ( 'non_tenue' === $p['statut'] ) { $ag[ $uid ]['promesses_non_tenues']++; }
			}
		} catch ( \Throwable $e ) {}
		foreach ( $ag as $uid => &$x ) {
			$x['taux_effet'] = $x['contacts'] > 0 ? round( $x['suivis_paiement'] / $x['contacts'] * 100 ) : null;
			$u = null;
			try { $u = class_exists( 'FKC_User' ) ? FKC_User::find( $uid ) : null; } catch ( \Throwable $e ) {}
			$x['nom'] = $u ? (string) ( $u['nom_complet'] ?: $u['login'] ) : 'Utilisateur n°' . $uid;
		}
		unset( $x );
		$out = array_values( $ag );
		usort( $out, function ( $a, $b ) { return ( $b['contacts'] + $b['promesses'] ) <=> ( $a['contacts'] + $a['promesses'] ); } );
		return $out;
	}
}
