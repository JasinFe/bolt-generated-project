<?php
/**
 * Politiques internes paramétrables, propres à chaque société.
 *
 * POURQUOI CES DEUX RÈGLES NE PEUVENT PAS ÊTRE ÉCRITES DANS LE CODE
 *
 * La cadence des relances et les seuils de validation ne relèvent pas de la
 * comptabilité : ils relèvent de la POLITIQUE INTERNE de l'entreprise. Une
 * officine relance à sept jours parce que ses créances sont petites et
 * nombreuses ; un constructeur attend soixante jours parce qu'un chantier se
 * paie par situations. Une SARL familiale fait valider toute dotation par le
 * gérant ; un groupe exige deux signatures au-delà de dix millions.
 *
 * Écrire ces valeurs dans le code obligerait chaque client à s'adapter au
 * logiciel. Elles vivent donc dans `parametres`, table PROPRE À CHAQUE SOCIÉTÉ
 * — chaque dossier a sa base, donc sa politique, sans que rien ne fuite d'une
 * société à l'autre.
 *
 * LES DÉFAUTS NE SONT PAS DES RECOMMANDATIONS UNIVERSELLES.
 *
 * Ils existent pour qu'une société qui n'a rien paramétré ne se retrouve pas
 * sans politique du tout — un système sans règle relance tout le monde, ou
 * personne. Ils sont volontairement prudents : mieux vaut une relance de trop
 * tard qu'un client fâché le premier jour.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_PolitiqueRelance {

	const CLE = 'relance_paliers';

	/**
	 * Paliers par défaut : quand relancer, par quel canal, avec quel ton.
	 *
	 * L'ordre des canaux n'est pas indifférent. On commence par le plus léger —
	 * un e-mail avant l'échéance n'est pas une relance, c'est un rappel de
	 * courtoisie, et il évite l'essentiel des retards d'inattention. On termine
	 * par le plus engageant. Envoyer une mise en demeure en premier fait gagner
	 * quelques jours et perdre un client.
	 *
	 * « min_jours_entre » évite le harcèlement : sans lui, un client à
	 * quatre-vingt-dix jours déclencherait tous les paliers d'un coup.
	 */
	public static function defauts() {
		return array(
			array( 'jours' => -7,  'canal' => 'email',    'ton' => 'courtoisie',
				'libelle' => 'Rappel avant échéance', 'min_jours_entre' => 7 ),
			array( 'jours' => 3,   'canal' => 'email',    'ton' => 'ferme',
				'libelle' => 'Première relance', 'min_jours_entre' => 7 ),
			array( 'jours' => 15,  'canal' => 'whatsapp', 'ton' => 'ferme',
				'libelle' => 'Relance téléphonique', 'min_jours_entre' => 7 ),
			array( 'jours' => 30,  'canal' => 'courrier', 'ton' => 'ferme',
				'libelle' => 'Lettre de relance', 'min_jours_entre' => 15 ),
			array( 'jours' => 60,  'canal' => 'courrier', 'ton' => 'mise_en_demeure',
				'libelle' => 'Mise en demeure', 'min_jours_entre' => 30 ),
		);
	}

	public static function canaux() {
		return array( 'email' => 'E-mail', 'whatsapp' => 'WhatsApp', 'sms' => 'SMS',
			'telephone' => 'Appel téléphonique', 'courrier' => 'Courrier' );
	}

	public static function tons() {
		return array( 'courtoisie' => 'Courtoisie', 'ferme' => 'Ferme',
			'mise_en_demeure' => 'Mise en demeure' );
	}

	/** Paliers de la société courante, ou les défauts si rien n'est paramétré. */
	public static function paliers() {
		/*
		 * Le repli sur les défauts couvre AUSSI le cas où la couche de
		 * paramètres n'est pas chargée — un calcul de politique ne doit jamais
		 * faire tomber l'écran qui l'appelle. Une cadence par défaut vaut mieux
		 * qu'une erreur fatale.
		 */
		$brut = class_exists( 'FKC_License' ) ? FKC_License::param( self::CLE, '' ) : '';
		if ( ! $brut ) { return self::defauts(); }
		$d = json_decode( (string) $brut, true );
		if ( ! is_array( $d ) || ! $d ) { return self::defauts(); }
		usort( $d, function ( $a, $b ) { return (int) $a['jours'] <=> (int) $b['jours']; } );
		return $d;
	}

	/** La société a-t-elle défini sa propre politique ? */
	public static function estPersonnalisee() {
		return class_exists( 'FKC_License' ) && '' !== (string) FKC_License::param( self::CLE, '' );
	}

	/**
	 * Enregistre les paliers, après contrôle.
	 *
	 * ON REFUSE DEUX PALIERS AU MÊME JOUR. Ce n'est pas un excès de rigueur :
	 * le moteur choisit le palier atteint le plus avancé, et deux paliers
	 * simultanés rendent le choix dépendant de l'ordre du tableau — donc
	 * imprévisible pour celui qui l'a saisi.
	 */
	public static function definir( array $paliers ) {
		$vus = array(); $propres = array();
		foreach ( $paliers as $p ) {
			$j = (int) ( $p['jours'] ?? 0 );
			$canal = (string) ( $p['canal'] ?? '' );
			if ( ! isset( self::canaux()[ $canal ] ) ) {
				return array( false, 'Canal inconnu : ' . $canal );
			}
			if ( isset( $vus[ $j ] ) ) {
				return array( false, 'Deux paliers au même jour (' . $j . ') : le moteur ne saurait '
					. 'lequel appliquer, et le choix dépendrait de l\'ordre de saisie.' );
			}
			$vus[ $j ] = true;
			$ton = (string) ( $p['ton'] ?? 'ferme' );
			$propres[] = array(
				'jours' => $j, 'canal' => $canal,
				'ton' => isset( self::tons()[ $ton ] ) ? $ton : 'ferme',
				'libelle' => trim( (string) ( $p['libelle'] ?? '' ) ) ?: ( 'Relance J' . ( $j >= 0 ? '+' : '' ) . $j ),
				'min_jours_entre' => max( 1, (int) ( $p['min_jours_entre'] ?? 7 ) ),
			);
		}
		if ( ! $propres ) { return array( false, 'Au moins un palier est requis.' ); }
		usort( $propres, function ( $a, $b ) { return $a['jours'] <=> $b['jours']; } );
		FKC_License::setParam( self::CLE, json_encode( $propres, JSON_UNESCAPED_UNICODE ) );
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'politique_relance', count( $propres ) . ' palier(s) définis' );
		}
		return array( true, count( $propres ) . ' palier(s) enregistrés.' );
	}

	/** Revient aux défauts (supprime la personnalisation). */
	public static function reinitialiser() {
		FKC_License::setParam( self::CLE, '' );
		return array( true, 'Politique de relance réinitialisée aux valeurs par défaut.' );
	}

	/**
	 * Palier applicable à une créance, ou null s'il n'y a rien à faire.
	 *
	 * On retient le palier ATTEINT LE PLUS AVANCÉ, pas le premier : un client à
	 * quatre-vingt-dix jours n'a pas besoin d'un rappel de courtoisie, il a
	 * besoin d'une mise en demeure. Parcourir la liste dans l'ordre inverse est
	 * donc le comportement correct, pas une optimisation.
	 */
	public static function palierPour( $joursRetard ) {
		$paliers = self::paliers();
		for ( $i = count( $paliers ) - 1; $i >= 0; $i-- ) {
			if ( (int) $joursRetard >= (int) $paliers[ $i ]['jours'] ) { return $paliers[ $i ]; }
		}
		return null;
	}

	/**
	 * Seuil de montant en deçà duquel on ne relance pas.
	 *
	 * Relancer une créance de deux mille francs coûte plus cher en temps que la
	 * créance elle-même, et agace un client qui paiera de toute façon.
	 */
	public static function seuilMontant() {
		return class_exists( 'FKC_License' ) ? (float) FKC_License::param( 'relance_seuil_montant', 0 ) : 0.0;
	}
}

/**
 * Workflow de validation à seuils — propre à chaque société.
 */
class FKC_WorkflowValidation {

	const CLE = 'workflow_seuils';

	/**
	 * Seuils par défaut : à partir de quel montant, quel niveau d'accord.
	 *
	 * Un seuil ne dit pas « qui a raison », il dit à partir de quand la décision
	 * cesse d'être individuelle. Les montants sont en francs CFA et
	 * volontairement bas par défaut : une société qui n'a rien paramétré doit
	 * plutôt demander une validation de trop qu'en laisser passer une.
	 */
	public static function defauts() {
		return array(
			/*
			 * CES TROIS RÔLES EXISTENT — AU MOTEUR DE RÔLES, PAS AU CATALOGUE
			 * HISTORIQUE.
			 *
			 * Deux catalogues coexistent depuis l'arrivée de FKC_RoleEngine :
			 * les neuf rôles de FKC_User::roles(), stockés dans
			 * `cabinet_users.role` et servant l'écran de création
			 * d'utilisateur ; et les vingt-deux rôles du moteur, stockés dans
			 * `user_roles` avec périmètre et seuil financier.
			 *
			 * C'est le MOTEUR qui fait autorité pour la validation :
			 * peutValider() l'interroge en premier. « chef_compta » y figure au
			 * niveau 4 — le niveau intermédiaire est donc bien franchissable.
			 * Le confondre avec le catalogue historique conduirait à supprimer
			 * un palier parfaitement valide et à écraser un workflow à trois
			 * niveaux en deux.
			 */
			array( 'seuil' => 0,         'role' => 'comptable',   'libelle' => 'Comptable' ),
			array( 'seuil' => 5000000,   'role' => 'chef_compta', 'libelle' => 'Chef comptable' ),
			array( 'seuil' => 20000000,  'role' => 'direction',   'libelle' => 'Direction générale' ),
		);
	}

	/**
	 * Rôles proposables comme niveau de validation.
	 *
	 * Tirés du catalogue réel des utilisateurs, jamais d'une liste écrite ici :
	 * une seconde liste divergerait le jour où un rôle serait ajouté, et le
	 * paramétrage renverrait de nouveau à des rôles que personne ne porte.
	 *
	 * « personnalise » est écarté — il ne désigne pas une fonction mais une
	 * absence de profil type. L'employer comme niveau de validation
	 * autoriserait tout utilisateur sans rôle défini.
	 */
	public static function rolesDisponibles() {
		$out = array();
		/*
		 * ON INTERROGE LE MOTEUR, PAS LE CATALOGUE HISTORIQUE.
		 *
		 * peutValider() décide à partir de FKC_RoleEngine : proposer ici les
		 * neuf rôles de FKC_User::roles() ferait refuser à la saisie des rôles
		 * qui fonctionnent parfaitement — « chef_compta », « responsable_site »,
		 * « responsable_commercial » — et l'utilisateur croirait à une
		 * limitation du produit.
		 *
		 * Les rôles sont ordonnés par NIVEAU décroissant : dans une liste de
		 * seuils de validation, on cherche d'abord les fonctions qui valident,
		 * pas les fonctions qui exécutent.
		 */
		if ( class_exists( 'FKC_RoleEngine' ) ) {
			$cat = FKC_RoleEngine::catalogue();
			uasort( $cat, function ( $a, $b ) { return (int) $b['niveau'] <=> (int) $a['niveau']; } );
			foreach ( $cat as $k => $r ) {
				if ( 'personnalise' === $k ) { continue; }
				$out[ $k ] = $r['libelle'] . ' (niv. ' . (int) $r['niveau'] . ')';
			}
			return $out;
		}
		if ( class_exists( 'FKC_User' ) ) {
			foreach ( FKC_User::roles() as $k => $r ) {
				if ( 'personnalise' === $k ) { continue; }
				$out[ $k ] = $r['label'];
			}
			return $out;
		}
		return array( 'comptable' => 'Comptable', 'direction' => 'Direction' );
	}

	public static function seuils() {
		$brut = class_exists( 'FKC_License' ) ? FKC_License::param( self::CLE, '' ) : '';
		if ( ! $brut ) { return self::defauts(); }
		$d = json_decode( (string) $brut, true );
		if ( ! is_array( $d ) || ! $d ) { return self::defauts(); }
		usort( $d, function ( $a, $b ) { return (float) $a['seuil'] <=> (float) $b['seuil']; } );
		return $d;
	}

	public static function estPersonnalise() {
		return class_exists( 'FKC_License' ) && '' !== (string) FKC_License::param( self::CLE, '' );
	}

	/**
	 * Enregistre les seuils.
	 *
	 * IL FAUT UN SEUIL À ZÉRO. Sans lui, une dotation de mille francs ne
	 * relèverait d'aucun niveau et ne pourrait être validée par personne — le
	 * workflow bloquerait exactement les dossiers les plus anodins.
	 */
	public static function definir( array $seuils ) {
		$propres = array(); $zero = false; $vus = array();
		foreach ( $seuils as $s ) {
			$m = round( (float) ( $s['seuil'] ?? 0 ) );
			$r = trim( (string) ( $s['role'] ?? '' ) );
			if ( '' === $r ) { return array( false, 'Chaque seuil doit désigner un rôle.' ); }
			/*
			 * Un rôle inconnu se saisit sans difficulté et bloque en silence :
			 * personne ne le porte, donc seul l'administrateur franchit le
			 * niveau — et l'on met le blocage sur le compte des droits.
			 */
			$dispo = self::rolesDisponibles();
			if ( ! isset( $dispo[ $r ] ) ) {
				return array( false, 'Rôle inconnu : « ' . $r . ' ». Rôles disponibles : '
					. implode( ', ', array_keys( $dispo ) ) . '.' );
			}
			if ( isset( $vus[ (string) $m ] ) ) {
				return array( false, 'Deux niveaux au même montant (' . fkc_money( $m ) . ' F).' );
			}
			$vus[ (string) $m ] = true;
			if ( 0 === (int) $m ) { $zero = true; }
			$propres[] = array( 'seuil' => $m, 'role' => $r,
				'libelle' => trim( (string) ( $s['libelle'] ?? '' ) ) ?: $r );
		}
		if ( ! $zero ) {
			return array( false, 'Un niveau à partir de 0 F est obligatoire : sans lui, les petites '
				. 'dotations ne relèveraient d\'aucun niveau et personne ne pourrait les valider.' );
		}
		usort( $propres, function ( $a, $b ) { return $a['seuil'] <=> $b['seuil']; } );
		FKC_License::setParam( self::CLE, json_encode( $propres, JSON_UNESCAPED_UNICODE ) );
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'workflow_seuils', count( $propres ) . ' niveau(x) définis' );
		}
		return array( true, count( $propres ) . ' niveau(x) enregistrés.' );
	}

	public static function reinitialiser() {
		FKC_License::setParam( self::CLE, '' );
		return array( true, 'Workflow réinitialisé aux valeurs par défaut.' );
	}

	/** Niveau requis pour un montant donné : le plus élevé qu'il atteint. */
	public static function niveauRequis( $montant ) {
		$s = self::seuils();
		$niveau = $s[0] ?? array( 'seuil' => 0, 'role' => 'admin', 'libelle' => 'Administrateur' );
		foreach ( $s as $n ) {
			if ( (float) $montant >= (float) $n['seuil'] ) { $niveau = $n; }
		}
		return $niveau;
	}

	/**
	 * L'utilisateur courant peut-il valider ce montant ?
	 *
	 * L'ADMINISTRATEUR PASSE TOUJOURS, et c'est un choix assumé. Un workflow
	 * qu'aucun utilisateur présent ne peut débloquer paralyse l'entreprise le
	 * jour où le chef comptable est en congé. La trace d'audit dit qui a validé
	 * quoi : le contrôle est a posteriori, pas par blocage.
	 *
	 * CORRECTIF — la comparaison au rôle configuré (`$n['role']`, ex.
	 * 'chef_compta') portait sur `cabinet_users.role`, colonne qui ne vaut
	 * JAMAIS que 'admin' ou 'user' : hors administrateur, AUCUN utilisateur
	 * ne pouvait donc jamais atteindre un palier, quel que soit son rôle
	 * métier réel. Le contrôle s'appuie désormais sur FKC_RoleEngine —
	 * seuil financier propre au(x) rôle(s) attribué(s), affiné par périmètre
	 * — avec repli sur l'ancienne comparaison pour les comptes non migrés.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function peutValider( $montant, $perimetreType = null, $perimetreId = null ) {
		$n = self::niveauRequis( $montant );
		if ( ! class_exists( 'FKC_Auth' ) ) { return array( true, '' ); }
		if ( FKC_Auth::isAdmin() ) { return array( true, '' ); }
		$u = FKC_Auth::user();
		if ( ! $u ) { return array( false, 'Session expirée.' ); }

		if ( class_exists( 'FKC_RoleEngine' ) ) {
			$seuil = FKC_RoleEngine::seuilFinancier( (int) $u['id'], $perimetreType, $perimetreId );
			if ( null === $seuil || (float) $seuil >= (float) $montant ) { return array( true, '' ); }
			// Rôle explicitement nommé par la politique (compat : un administrateur
			// a pu configurer un seuil sur un code de rôle du moteur).
			if ( FKC_RoleEngine::aRole( (int) $u['id'], $n['role'] ) ) { return array( true, '' ); }
		} else {
			$role = (string) ( $u['role'] ?? '' );
			if ( $role === $n['role'] ) { return array( true, '' ); }
			/*
			 * UN NIVEAU SUPÉRIEUR VALIDE CE QUI EST EN DESSOUS.
			 *
			 * L'égalité stricte interdisait au directeur de valider une
			 * dotation de cent mille francs, parce que ce montant relève du
			 * comptable. Les seuils disent à partir de quand il FAUT monter,
			 * pas qu'il est interdit de descendre.
			 *
			 * Le classement vient des seuils eux-mêmes : le rôle exigé au seuil
			 * le plus haut est le plus élevé. Cette branche ne sert que si le
			 * moteur de rôles est absent — lui dispose du niveau explicite.
			 */
			$rang = array(); $i = 0;
			foreach ( self::seuils() as $x ) { $rang[ $x['role'] ] = $i++; }
			if ( isset( $rang[ $role ], $rang[ $n['role'] ] ) && $rang[ $role ] >= $rang[ $n['role'] ] ) {
				return array( true, '' );
			}
		}
		/*
		 * On nomme le niveau requis dans le refus. Un « accès refusé » sec
		 * oblige l'utilisateur à deviner à qui s'adresser, et la demande se
		 * perd — le dossier reste bloqué sans que personne ne sache pourquoi.
		 */
		return array( false, 'Ce montant (' . fkc_money( $montant ) . ' F) requiert l\'accord de : '
			. $n['libelle'] . '. Transmettez le dossier pour validation.' );
	}
}

/**
 * RÉGLAGES DE RECOUVREMENT PROPRES À LA SOCIÉTÉ (1.841.4) :
 * comment le client peut payer, et ce que coûte un retard.
 *
 * ── Moyens de paiement cités dans les relances ─────────────────────────
 * Une relance qui ne dit pas COMMENT payer fait perdre le paiement du jour :
 * le client doit rappeler pour demander un numéro. En Afrique de l'Ouest,
 * c'est un numéro Wave ou Orange Money qu'il attend. On cite donc les
 * moyens que la société a renseignés — et, si elle dispose d'un lien de
 * paiement (page marchande de son opérateur), ce lien, avec le montant et
 * la référence déjà remplis. Aucun format d'opérateur n'est écrit en dur :
 * le lien est un GABARIT fourni par la société ({montant}, {reference}),
 * parce que ces formats changent et diffèrent d'un opérateur à l'autre.
 *
 * ── Pénalités de retard ────────────────────────────────────────────────
 * Elles ne sont dues que si les conditions générales du créancier les
 * prévoient : désactivées par défaut. Une fois paramétrées, elles sont
 * CHIFFRÉES dans les relances fermes et la mise en demeure (taux mensuel
 * au prorata des jours de retard après un délai de grâce, plus une
 * indemnité forfaitaire par relevé). Elles ne sont jamais comptabilisées
 * d'office : réclamer n'est pas facturer, et c'est à la société de décider
 * si elle les facture effectivement.
 */
class FKC_RecouvrementReglages {

	const CLE_PAIEMENT  = 'recouv_paiement';
	const CLE_PENALITES = 'recouv_penalites';

	public static function operateurs() {
		return array( 'wave' => 'Wave', 'orange_money' => 'Orange Money', 'mtn_momo' => 'MTN MoMo', 'moov_money' => 'Moov Money' );
	}

	protected static function lire( $cle ) {
		$brut = class_exists( 'FKC_License' ) ? (string) FKC_License::param( $cle, '' ) : '';
		$d = '' !== $brut ? json_decode( $brut, true ) : null;
		return is_array( $d ) ? $d : array();
	}

	/** @return array{numeros:array, lien:string, instructions:string} */
	public static function paiement() {
		$d = self::lire( self::CLE_PAIEMENT );
		return array(
			'numeros'      => array_filter( array_map( 'strval', (array) ( $d['numeros'] ?? array() ) ) ),
			'lien'         => (string) ( $d['lien'] ?? '' ),
			'instructions' => (string) ( $d['instructions'] ?? '' ),
		);
	}

	/** @return array{actif:bool, taux_mensuel:float, grace:int, forfait:float} */
	public static function penalites() {
		$d = self::lire( self::CLE_PENALITES );
		return array(
			'actif'        => ! empty( $d['actif'] ),
			'taux_mensuel' => max( 0.0, (float) ( $d['taux_mensuel'] ?? 0 ) ),
			'grace'        => max( 0, (int) ( $d['grace'] ?? 0 ) ),
			'forfait'      => max( 0.0, (float) ( $d['forfait'] ?? 0 ) ),
		);
	}

	public static function definirPaiement( array $d ) {
		$numeros = array();
		foreach ( self::operateurs() as $k => $lib ) {
			$n = preg_replace( '/[^0-9+ ]/', '', (string) ( $d['numeros'][ $k ] ?? '' ) );
			if ( '' !== trim( $n ) ) { $numeros[ $k ] = trim( $n ); }
		}
		$lien = trim( (string) ( $d['lien'] ?? '' ) );
		if ( '' !== $lien && ! preg_match( '#^https://[^\s<>"]+$#i', $lien ) ) {
			return array( false, 'Le lien de paiement doit être une adresse https:// complète (sans espace).' );
		}
		$instr = trim( mb_substr( (string) ( $d['instructions'] ?? '' ), 0, 400 ) );
		FKC_License::setParam( self::CLE_PAIEMENT, json_encode( array( 'numeros' => $numeros, 'lien' => $lien, 'instructions' => $instr ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'recouv_paiement', count( $numeros ) . ' numéro(s), lien ' . ( $lien ? 'oui' : 'non' ) ); }
		return array( true, 'Moyens de paiement enregistrés.' );
	}

	public static function definirPenalites( array $d ) {
		$taux = (float) str_replace( ',', '.', (string) ( $d['taux_mensuel'] ?? 0 ) );
		if ( $taux < 0 || $taux > 10 ) {
			return array( false, 'Taux mensuel hors limites (0 à 10 % par mois).' );
		}
		$p = array( 'actif' => ! empty( $d['actif'] ), 'taux_mensuel' => round( $taux, 3 ),
			'grace' => max( 0, (int) ( $d['grace'] ?? 0 ) ), 'forfait' => max( 0.0, round( (float) ( $d['forfait'] ?? 0 ) ) ) );
		FKC_License::setParam( self::CLE_PENALITES, json_encode( $p ) );
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'recouv_penalites', json_encode( $p ) ); }
		return array( true, $p['actif'] ? 'Pénalités de retard activées.' : 'Pénalités de retard désactivées.' );
	}

	/**
	 * Pénalités exigibles sur un ensemble de pièces.
	 *
	 * @param array $lignes lignes de la file (montant, jours)
	 * @return array{interets:float, forfait:float, total:float}
	 */
	public static function calculerPenalites( array $lignes ) {
		$p = self::penalites();
		$out = array( 'interets' => 0.0, 'forfait' => 0.0, 'total' => 0.0 );
		if ( ! $p['actif'] ) { return $out; }
		$echues = 0;
		foreach ( $lignes as $l ) {
			$j = (int) ( $l['jours'] ?? 0 ) - $p['grace'];
			if ( (int) ( $l['jours'] ?? 0 ) > 0 ) { $echues++; }
			if ( $j <= 0 ) { continue; }
			$out['interets'] += (float) $l['montant'] * $p['taux_mensuel'] / 100 * $j / 30;
		}
		$out['interets'] = round( $out['interets'] );
		$out['forfait'] = $echues > 0 ? $p['forfait'] : 0.0;
		$out['total'] = $out['interets'] + $out['forfait'];
		return $out;
	}

	/** Lien de paiement prérempli, ou '' si la société n'en a pas. */
	public static function lienPaiement( $montant, $reference ) {
		$g = self::paiement()['lien'];
		if ( '' === $g ) { return ''; }
		return strtr( $g, array( '{montant}' => (string) (int) round( (float) $montant ), '{reference}' => rawurlencode( (string) $reference ) ) );
	}

	/**
	 * Paragraphe « comment payer » ajouté aux messages de relance.
	 *
	 * @param bool $bref version SMS / WhatsApp
	 */
	public static function blocPaiement( $montant, $reference, $bref = false ) {
		$p = self::paiement();
		$ops = self::operateurs(); $parts = array();
		foreach ( $p['numeros'] as $k => $n ) { $parts[] = ( $ops[ $k ] ?? $k ) . ' ' . $n; }
		$lien = self::lienPaiement( $montant, $reference );
		if ( ! $parts && '' === $lien && '' === $p['instructions'] ) { return ''; }
		$t = $bref ? ' Pour payer : ' : "\n\nPour régler : ";
		$seg = array();
		if ( $parts ) { $seg[] = implode( ' · ', $parts ) . ( $bref ? '' : ' (référence ' . $reference . ')' ); }
		if ( '' !== $lien ) { $seg[] = ( $bref ? '' : 'paiement en ligne : ' ) . $lien; }
		if ( '' !== $p['instructions'] && ! $bref ) { $seg[] = $p['instructions']; }
		return $t . implode( $bref ? ' — ' : "\n", $seg ) . ( $bref ? '.' : '' );
	}

	/** Paragraphe « pénalités » (relances fermes et mise en demeure). */
	public static function blocPenalites( array $lignes, $bref = false ) {
		$c = self::calculerPenalites( $lignes );
		if ( $c['total'] <= 0 ) { return ''; }
		if ( $bref ) { return ' Pénalités de retard exigibles : ' . fkc_money( $c['total'] ) . ' FCFA.'; }
		return "\n\nConformément à nos conditions générales, des pénalités de retard sont exigibles : "
			. fkc_money( $c['interets'] ) . ' FCFA d\'intérêts' . ( $c['forfait'] > 0 ? ' et ' . fkc_money( $c['forfait'] ) . ' FCFA d\'indemnité forfaitaire' : '' )
			. ', soit ' . fkc_money( $c['total'] ) . ' FCFA.';
	}
}
