<?php
/**
 * REGISTRE DES SOURCES DE CRÉANCES (1.841.2).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  LE PROBLÈME
 * ═══════════════════════════════════════════════════════════════════════════
 *  Le moteur de recouvrement ne lisait que la table `factures`. Or plusieurs
 *  métiers constatent leurs créances ailleurs, et c'est légitime :
 *
 *    — les COTISATIONS (module Social) ne sont pas des ventes : pas de FNE,
 *      pas de TVA, pas de chiffre d'affaires ;
 *    — les PIÈCES VERTICALES (Cabinet, Santé et les autres packs
 *      déclaratifs) sont numérotées par dossier ;
 *    — la SCOLARITÉ (École) se paie par tranches ;
 *    — les LOYERS (Immobilier) par quittances.
 *
 *  Deux défauts en découlaient. Ces créances étaient INVISIBLES : jamais
 *  relancées, absentes de la balance âgée. Et, pire, leurs RÈGLEMENTS
 *  étaient visibles : un paiement de cotisation ou d'honoraires, enregistré
 *  au nom du client, entrait dans l'encaissé sans créance en face et
 *  éteignait au lettrage des factures bien réelles du même client — qui
 *  n'était plus relancé pour elles.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  LE PRINCIPE
 * ═══════════════════════════════════════════════════════════════════════════
 *  Chaque source DÉCLARE ses créances ; le moteur les traite exactement
 *  comme des factures — même lettrage, même ancienneté, même file de
 *  relance — sans qu'un second moteur de recouvrement voie le jour.
 *
 *  Une source déclare, pour chaque créance : le client, une référence
 *  lisible, la date, l'échéance, le montant dû, et ce qui a déjà été réglé
 *  NOMMÉMENT (son propre lettrage). Elle déclare aussi quels règlements ou
 *  reçus ce lettrage consomme, pour que le moteur ne les compte pas deux
 *  fois. Ce qui n'est pas lettré nommément se lettre en FIFO avec le reste
 *  du compte du client, comme au grand livre.
 *
 *  Une source qui échoue ne fait jamais tomber le moteur : elle est ignorée
 *  et signalée à l'écran « Sources de créances ».
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_RecouvrementSources {

	/** @var array code => définition */
	protected static $sources = array();
	/** @var array code => message d'erreur de la dernière collecte */
	protected static $erreurs = array();

	/**
	 * Déclare une source.
	 *
	 * @param string $code
	 * @param array  $def {
	 *   @type string   libelle    « Cotisations », « Loyers »…
	 *   @type string   document   nom du document dans un message : « votre cotisation »
	 *   @type string   court      « Cotisation » (objet d'un e-mail, colonne)
	 *   @type callable creances   () → liste de créances (voir normaliser())
	 *   @type callable consommes  () → array{reglements:array id=>montant, recus:array id=>montant}
	 *   @type callable rattacher  () → int nombre de tiers rattachés (facultatif)
	 *   @type callable non_rattachees () → int créances sans client connues de la source (facultatif)
	 * }
	 */
	public static function register( $code, array $def ) {
		$def['code'] = (string) $code;
		$def += array( 'libelle' => $code, 'document' => 'votre pièce', 'court' => 'Pièce' );
		self::$sources[ (string) $code ] = $def;
	}

	public static function all() { return self::$sources; }
	public static function get( $code ) { return self::$sources[ (string) $code ] ?? null; }
	public static function erreurs() { return self::$erreurs; }

	/**
	 * Créances de toutes les sources, normalisées.
	 *
	 * @return array liste de lignes { source, ref, client_id, tiers_nom, telephone,
	 *               numero, date, echeance, montant, paye, route }
	 */
	public static function creances() {
		$out = array(); self::$erreurs = array();
		foreach ( self::$sources as $code => $s ) {
			if ( empty( $s['creances'] ) || ! is_callable( $s['creances'] ) ) { continue; }
			try {
				foreach ( (array) call_user_func( $s['creances'] ) as $r ) {
					$n = self::normaliser( $code, $r );
					if ( $n ) { $out[] = $n; }
				}
			} catch ( \Throwable $e ) {
				self::noterErreur( $code, $e );
			}
		}
		return $out;
	}

	/**
	 * Une table absente n'est pas une erreur (1.841.6) : c'est un pack qui
	 * n'a jamais été utilisé dans ce dossier. L'écran « Sources » affichait
	 * « lecture impossible » pour l'École ou l'Immobilier chez une société
	 * qui n'en fait pas — une fausse alerte qui use l'attention.
	 */
	protected static function noterErreur( $code, \Throwable $e ) {
		if ( false !== stripos( $e->getMessage(), 'no such table' ) || false !== stripos( $e->getMessage(), 'no such column' ) ) { return; }
		self::$erreurs[ $code ] = $e->getMessage();
	}

	protected static function normaliser( $code, array $r ) {
		$montant = round( (float) ( $r['montant'] ?? 0 ), 2 );
		if ( 0.0 === $montant ) { return null; }
		$date = (string) ( $r['date'] ?? '' );
		if ( '' === $date ) { return null; }
		return array(
			'source'    => (string) $code,
			'ref'       => (int) ( $r['ref'] ?? 0 ),
			'client_id' => (int) ( $r['client_id'] ?? 0 ),
			'tiers_nom' => (string) ( $r['tiers_nom'] ?? '' ),
			'telephone' => (string) ( $r['telephone'] ?? '' ),
			'numero'    => (string) ( $r['numero'] ?? '' ),
			'date'      => $date,
			'echeance'  => (string) ( $r['echeance'] ?? '' ),
			'montant'   => $montant,
			'paye'      => max( 0.0, round( (float) ( $r['paye'] ?? 0 ), 2 ) ),
			'route'     => (string) ( $r['route'] ?? '' ),
		);
	}

	/**
	 * Part de l'encaissé de chaque client que les sources ont déjà lettrée.
	 *
	 * Seuls comptent les règlements et reçus que le moteur compte LUI-MÊME
	 * dans l'encaissé : un reçu sans client n'y est pas, et le retrancher du
	 * pool retirerait au client une somme qu'on ne lui avait jamais créditée.
	 *
	 * @return array client_id => montant
	 */
	public static function consommeParClient() {
		$regs = array(); $recus = array();
		// Liens posés par les packs à l'encaissement (lier()).
		try {
			self::ensure();
			foreach ( FKC_DB::q( "SELECT objet, objet_id, SUM(montant) s FROM recouvrement_liens GROUP BY objet, objet_id" )->fetchAll() as $l ) {
				if ( 'recu' === $l['objet'] ) { $recus[ (int) $l['objet_id'] ] = ( $recus[ (int) $l['objet_id'] ] ?? 0.0 ) + (float) $l['s']; }
				else { $regs[ (int) $l['objet_id'] ] = ( $regs[ (int) $l['objet_id'] ] ?? 0.0 ) + (float) $l['s']; }
			}
		} catch ( \Throwable $e ) {}
		foreach ( self::$sources as $code => $s ) {
			if ( empty( $s['consommes'] ) || ! is_callable( $s['consommes'] ) ) { continue; }
			try {
				$c = (array) call_user_func( $s['consommes'] );
				foreach ( (array) ( $c['reglements'] ?? array() ) as $id => $m ) { $regs[ (int) $id ] = ( $regs[ (int) $id ] ?? 0.0 ) + (float) $m; }
				foreach ( (array) ( $c['recus'] ?? array() ) as $id => $m ) { $recus[ (int) $id ] = ( $recus[ (int) $id ] ?? 0.0 ) + (float) $m; }
			} catch ( \Throwable $e ) { self::noterErreur( $code, $e ); }
		}
		$out = array();
		foreach ( array_chunk( array_keys( $regs ), 500 ) as $ids ) {
			try {
				$rows = FKC_DB::q(
					"SELECT id, tiers_id, montant FROM reglements
					 WHERE id IN (" . implode( ',', array_fill( 0, count( $ids ), '?' ) ) . ")
					   AND sens='encaissement' AND tiers_type='client' AND COALESCE(statut,'actif')<>'annule'",
					$ids
				)->fetchAll();
			} catch ( \Throwable $e ) { $rows = array(); }
			foreach ( $rows as $r ) {
				$cid = (int) $r['tiers_id'];
				$out[ $cid ] = ( $out[ $cid ] ?? 0.0 ) + min( (float) $r['montant'], $regs[ (int) $r['id'] ] );
			}
		}
		foreach ( array_chunk( array_keys( $recus ), 500 ) as $ids ) {
			try {
				$rows = FKC_DB::q(
					"SELECT id, client_id, montant_ttc FROM recus
					 WHERE id IN (" . implode( ',', array_fill( 0, count( $ids ), '?' ) ) . ")
					   AND client_id IS NOT NULL AND ecriture_id IS NOT NULL AND statut NOT IN ('annule')
					   AND sens <> 'decaissement'
					   AND type_operation IN ('paiement_facture','vente_comptant')",
					$ids
				)->fetchAll();
			} catch ( \Throwable $e ) { $rows = array(); }
			foreach ( $rows as $r ) {
				$cid = (int) $r['client_id'];
				$out[ $cid ] = ( $out[ $cid ] ?? 0.0 ) + min( (float) $r['montant_ttc'], $recus[ (int) $r['id'] ] );
			}
		}
		return $out;
	}

	/**
	 * RÈGLEMENTS DE FACTURES ENCAISSÉS HORS DU CIRCUIT CLIENT (1.841.6).
	 *
	 * Certains packs émettent une vraie facture — pour qu'elle soit suivie et
	 * relancée — mais encaissent ensuite par leur propre écriture, sans
	 * règlement ni reçu au nom du client. C'est le cas des redevances de la
	 * gestion collective. Le recouvrement ne voyait jamais ce paiement : la
	 * facture restait ouverte et relancée alors que le pack et le compte 411
	 * étaient soldés.
	 *
	 * Une source peut donc déclarer, par facture, le montant qu'elle a
	 * encaissé elle-même. Il éteint la facture comme une imputation nommée,
	 * mais NE puise PAS dans l'encaissé du client : il n'y a jamais été.
	 *
	 * @return array facture_id => montant
	 */
	public static function imputationsExternes() {
		$out = array();
		foreach ( self::$sources as $code => $s ) {
			if ( empty( $s['imputations'] ) || ! is_callable( $s['imputations'] ) ) { continue; }
			try {
				foreach ( (array) call_user_func( $s['imputations'] ) as $fid => $m ) {
					if ( (int) $fid && (float) $m > 0 ) { $out[ (int) $fid ] = ( $out[ (int) $fid ] ?? 0.0 ) + (float) $m; }
				}
			} catch ( \Throwable $e ) { self::noterErreur( $code, $e ); }
		}
		return $out;
	}

	/**
	 * Où s'encaisse une créance de source (1.841.6).
	 *
	 * Une cotisation, un loyer ou une tranche de scolarité s'encaissent depuis
	 * leur module : c'est là que le paiement est LETTRÉ à la pièce (lettrage
	 * de cotisation, quittance, tranche). Encaissé depuis la comptabilité, il
	 * solderait le compte client mais laisserait la pièce impayée dans le pack.
	 *
	 * @return string route, ou '' si la créance s'encaisse comme une facture
	 */
	public static function routeEncaissement( $code ) {
		$s = self::get( $code );
		return $s ? (string) ( $s['encaisser'] ?? '' ) : '';
	}

	/** Libellés d'une source pour les messages (repli : facture). */
	public static function document( $code ) {
		$s = self::get( $code );
		return $s ? (string) $s['document'] : 'votre facture';
	}
	public static function court( $code ) {
		$s = self::get( $code );
		return $s ? (string) $s['court'] : 'Facture';
	}
	/** Le document est-il féminin ? (accord : « échue » / « échu »). */
	public static function feminin( $code ) {
		$s = self::get( $code );
		return $s ? ! isset( $s['feminin'] ) || (bool) $s['feminin'] : true;
	}

	/* ═══════════════ Tiers miroirs ═══════════════ */

	/**
	 * Fiche client d'un tiers de pack (parent, locataire…).
	 *
	 * Le moteur est bâti autour du CLIENT : c'est la fiche qui porte le
	 * téléphone, le score, l'historique des relances et le compte 411
	 * auxiliaire. Un parent d'élève ou un locataire qui n'existe que dans
	 * la table du pack ne peut être ni relancé ni suivi. On lui crée donc un
	 * miroir dans le référentiel clients — jamais un doublon : le lien est
	 * mémorisé, et une fiche existante de même nom et même téléphone est
	 * reprise plutôt que recréée. Même principe que le miroir des membres
	 * du module Social.
	 *
	 * @param bool $creer false = lecture seule (le calcul ne crée rien)
	 * @return int client_id, 0 si inconnu et $creer = false
	 */
	public static function tiers( $source, $cle, $nom, $telephone = '', $creer = true ) {
		self::ensure();
		$cle = (string) $cle;
		$id = (int) FKC_DB::q( 'SELECT client_id FROM recouvrement_tiers WHERE source=? AND cle=?', array( (string) $source, $cle ) )->fetchColumn();
		if ( $id && class_exists( 'FKC_Client' ) && FKC_Client::find( $id ) ) { return $id; }
		if ( ! $creer || ! class_exists( 'FKC_Client' ) ) { return 0; }
		$nom = trim( (string) $nom ) ?: 'Tiers ' . $source;
		$tel = trim( (string) $telephone );
		$exist = FKC_DB::q(
			'SELECT id FROM clients WHERE LOWER(TRIM(nom))=LOWER(?) AND COALESCE(telephone,\'\')=? ORDER BY id LIMIT 1',
			array( $nom, $tel )
		)->fetchColumn();
		$id = $exist ? (int) $exist : FKC_Client::create( array( 'nom' => $nom, 'type' => 'B2C', 'telephone' => $tel,
			'notes' => 'Fiche créée pour le recouvrement (' . $source . ').' ) );
		FKC_DB::q( 'INSERT OR REPLACE INTO recouvrement_tiers(source, cle, client_id) VALUES(?,?,?)', array( (string) $source, $cle, $id ) );
		return $id;
	}

	/** Toutes les correspondances d'une source, en une requête : cle => client_id. */
	public static function correspondances( $source ) {
		self::ensure();
		$out = array();
		foreach ( FKC_DB::q( 'SELECT cle, client_id FROM recouvrement_tiers WHERE source=?', array( (string) $source ) )->fetchAll() as $r ) {
			$out[ (string) $r['cle'] ] = (int) $r['client_id'];
		}
		return $out;
	}

	/**
	 * Mémorise qu'un reçu (ou un règlement) solde une créance de source.
	 *
	 * Sans ce lien, un paiement de loyer enregistré au nom du locataire
	 * serait compté deux fois : une fois dans le « payé » de la quittance,
	 * une fois dans l'encaissé du client — où il éteindrait en plus une
	 * autre créance au lettrage.
	 */
	public static function lier( $source, $ref, $objet, $objetId, $montant ) {
		if ( ! (int) $objetId || (float) $montant <= 0 ) { return; }
		self::ensure();
		FKC_DB::q( 'INSERT INTO recouvrement_liens(source, ref, objet, objet_id, montant) VALUES(?,?,?,?,?)',
			array( (string) $source, (int) $ref, 'recu' === $objet ? 'recu' : 'reglement', (int) $objetId, round( (float) $montant, 2 ) ) );
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }
	}

	protected static $pret = false;
	public static function ensure() {
		if ( self::$pret ) { return; }
		FKC_DB::conn()->exec( "CREATE TABLE IF NOT EXISTS recouvrement_tiers(
			source TEXT NOT NULL, cle TEXT NOT NULL, client_id INTEGER NOT NULL,
			created_at TEXT DEFAULT(datetime('now','localtime')),
			PRIMARY KEY(source, cle)
		);
		CREATE TABLE IF NOT EXISTS recouvrement_liens(
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			source TEXT NOT NULL, ref INTEGER NOT NULL,
			objet TEXT NOT NULL DEFAULT 'recu', objet_id INTEGER NOT NULL,
			montant REAL NOT NULL DEFAULT 0,
			created_at TEXT DEFAULT(datetime('now','localtime'))
		);
		CREATE INDEX IF NOT EXISTS idx_recouv_liens ON recouvrement_liens(objet, objet_id);" );
		self::$pret = true;
	}

	/** Rattache les tiers de toutes les sources qui le savent faire. */
	public static function rattacherTout() {
		$n = 0; $det = array();
		foreach ( self::$sources as $code => $s ) {
			if ( empty( $s['rattacher'] ) || ! is_callable( $s['rattacher'] ) ) { continue; }
			try { $k = (int) call_user_func( $s['rattacher'] ); $n += $k; $det[ $code ] = $k; }
			catch ( \Throwable $e ) { self::noterErreur( $code, $e ); }
		}
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }
		return array( $n, $det );
	}

	/** Synthèse par source, pour l'écran « Sources de créances ». */
	public static function synthese( $donnees = null ) {
		$d = ( is_array( $donnees ) && isset( $donnees['factures'] ) ) ? $donnees : FKC_Recouvrement::compute();
		$out = array();
		foreach ( self::$sources as $code => $s ) {
			$out[ $code ] = array( 'code' => $code, 'libelle' => $s['libelle'], 'encours' => 0.0, 'retard' => 0.0,
				'lignes' => 0, 'sans_client' => 0.0, 'rattachable' => ! empty( $s['rattacher'] ), 'non_rattachees' => null );
			if ( ! empty( $s['non_rattachees'] ) && is_callable( $s['non_rattachees'] ) ) {
				try { $out[ $code ]['non_rattachees'] = (int) call_user_func( $s['non_rattachees'] ); } catch ( \Throwable $e ) {}
			}
		}
		foreach ( $d['factures'] as $f ) {
			$code = (string) ( $f['source'] ?? '' );
			if ( '' === $code || ! isset( $out[ $code ] ) ) { continue; }
			$out[ $code ]['encours'] += (float) $f['montant'];
			$out[ $code ]['lignes']++;
			if ( (int) $f['jours'] > 0 ) { $out[ $code ]['retard'] += (float) $f['montant']; }
			if ( 0 === (int) $f['client_id'] ) { $out[ $code ]['sans_client'] += (float) $f['montant']; }
		}
		return $out;
	}
}

/* ═══════════════════════════════════════════════════════════════════════════
   SOURCES LIVRÉES AVEC LE SOCLE
   Chacune ne lit que si ses tables existent : un dossier qui n'a jamais
   ouvert le pack n'a rien à déclarer, et aucune table n'est créée ici.
   ═══════════════════════════════════════════════════════════════════════════ */

/* ── Cotisations (module Social : associations, ONG, coopératives…) ──────── */
FKC_RecouvrementSources::register( 'cotisations', array(
	'libelle'  => 'Cotisations',
	'document' => 'votre cotisation',
	'court'    => 'Cotisation',
	'encaisser' => 'social/impayes',
	'creances' => function () {
		$rows = FKC_DB::q(
			"SELECT l.id, l.montant_du, a.reference, a.date_appel, a.echeance, m.client_id,
			        TRIM(COALESCE(m.nom,'') || ' ' || COALESCE(m.prenoms,'')) AS nom, m.telephone,
			        COALESCE((SELECT SUM(t.montant) FROM soc_lettrage t WHERE t.ligne_id=l.id),0) AS regle
			 FROM soc_appel_lignes l JOIN soc_appels a ON a.id=l.appel_id JOIN soc_membres m ON m.id=l.membre_id
			 WHERE a.statut='emis' AND l.annulee=0 AND (l.ecriture_id IS NOT NULL OR l.brouillon_id IS NOT NULL)"
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array( 'ref' => $r['id'], 'client_id' => $r['client_id'], 'tiers_nom' => $r['nom'], 'telephone' => $r['telephone'],
				'numero' => $r['reference'], 'date' => $r['date_appel'], 'echeance' => $r['echeance'] ?: $r['date_appel'],
				'montant' => $r['montant_du'], 'paye' => $r['regle'] );
		}
		return $out;
	},
	'consommes' => function () {
		$r = array();
		foreach ( FKC_DB::q( 'SELECT reglement_id, SUM(montant) s FROM soc_lettrage GROUP BY reglement_id' )->fetchAll() as $x ) {
			$r[ (int) $x['reglement_id'] ] = (float) $x['s'];
		}
		return array( 'reglements' => $r );
	},
	'rattacher' => function () {
		if ( ! class_exists( 'FKC_Cotisation' ) ) { return 0; }
		$n = 0;
		foreach ( FKC_DB::q( "SELECT DISTINCT l.membre_id FROM soc_appel_lignes l JOIN soc_membres m ON m.id=l.membre_id
			WHERE l.annulee=0 AND m.client_id IS NULL" )->fetchAll() as $r ) {
			if ( FKC_Cotisation::tiersDe( (int) $r['membre_id'] ) ) { $n++; }
		}
		return $n;
	},
) );

/* ── Pièces verticales (Cabinet, Santé et packs déclaratifs) ─────────────── */
/*
 * 1.841.6 — L'écriture se retrouve par `ecriture_id` OU par sa référence
 * « vp.piece#<id> » : une pièce validée depuis le journal temporaire (le
 * réglage par défaut) n'avait jamais reçu son `ecriture_id`, et restait
 * invisible — le paiement de ses honoraires soldait alors une autre facture.
 *
 * Ce qui fait foi, c'est l'ÉCRITURE : une pièce n'est une créance que si
 * elle a DÉBITÉ le compte client (411). Une vente au comptant, une pièce
 * d'achat ou une reprise de provision ne débitent pas le 411 et ne sont donc
 * pas des créances — le même filtre vaut pour les quarante-sept packs sans
 * connaître le métier de chacun. Seules les pièces dont le dossier désigne un
 * client sont retenues : les autres ne peuvent être lettrées avec aucun
 * paiement. L'École et l'Immobilier ont leur propre source, plus fine
 * (tranches, quittances).
 */
FKC_RecouvrementSources::register( 'pieces', array(
	'libelle'  => 'Pièces des dossiers métiers',
	'document' => 'votre pièce',
	'court'    => 'Pièce',
	'creances' => function () {
		$rows = FKC_DB::q(
			"SELECT p.id, p.type, p.numero, p.date_piece, d.id AS dossier_id, d.code, d.pack, d.client_id, d.tiers_nom,
			        (SELECT COALESCE(SUM(l.debit - l.credit),0) FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
			          WHERE c.numero LIKE '411%' AND l.ecriture_id IN (
			                SELECT e.id FROM ecritures e
			                 WHERE e.id = p.ecriture_id OR e.reference = 'vp.piece#' || p.id ) ) AS du
			 FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE p.statut='comptabilisee'
			   AND d.client_id IS NOT NULL AND d.pack NOT IN ('ecole','immobilier')"
		)->fetchAll();
		$delais = array();
		$out = array();
		foreach ( $rows as $r ) {
			if ( abs( (float) $r['du'] ) < 0.5 ) { continue; }
			$cid = (int) $r['client_id'];
			if ( ! isset( $delais[ $cid ] ) ) {
				$delais[ $cid ] = (int) FKC_DB::q( 'SELECT COALESCE(delai_paiement,0) FROM clients WHERE id=?', array( $cid ) )->fetchColumn();
			}
			$out[] = array( 'ref' => $r['id'], 'client_id' => $cid, 'tiers_nom' => $r['tiers_nom'],
				'numero' => $r['code'] . '-' . strtoupper( substr( (string) $r['type'], 0, 3 ) ) . '-' . str_pad( (string) $r['numero'], 3, '0', STR_PAD_LEFT ),
				'date' => $r['date_piece'],
				'echeance' => date( 'Y-m-d', strtotime( $r['date_piece'] . ' +' . max( 0, $delais[ $cid ] ) . ' day' ) ),
				'montant' => (float) $r['du'], 'paye' => 0 );
		}
		return $out;
	},
	'non_rattachees' => function () {
		return (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			WHERE p.statut='comptabilisee' AND d.client_id IS NULL AND d.pack NOT IN ('ecole','immobilier')" )->fetchColumn();
	},
) );

/* ── Scolarité (pack École) : une créance par tranche ────────────────────── */
/*
 * Le payeur est le TUTEUR : un parent qui a trois enfants inscrits est un
 * seul débiteur, qu'on appelle une fois. La clé du miroir est donc le
 * couple tuteur + téléphone ; l'élève sert de repli quand le tuteur n'est
 * pas renseigné.
 */
function fkc_recouv_cle_ecole( array $r ) {
	$t = trim( (string) ( $r['tuteur'] ?? '' ) );
	return '' !== $t ? 'tuteur:' . mb_strtolower( $t ) . '|' . preg_replace( '/\D+/', '', (string) ( $r['tuteur_tel'] ?? '' ) )
		: 'eleve:' . (int) $r['eleve_id'];
}
FKC_RecouvrementSources::register( 'scolarite', array(
	'libelle'  => 'Scolarité',
	'document' => 'la scolarité',
	'court'    => 'Scolarité',
	'encaisser' => 'ecole/scolarite',
	'creances' => function () {
		$map = FKC_RecouvrementSources::correspondances( 'scolarite' );
		$ins = FKC_DB::q(
			"SELECT i.id, i.eleve_id, e.nom, e.matricule, e.tuteur, e.tuteur_tel,
			        COALESCE((SELECT SUM(montant) FROM ec_paiements p WHERE p.inscription_id=i.id),0) AS paye
			 FROM ec_inscriptions i JOIN ec_eleves e ON e.id=i.eleve_id WHERE i.statut='active'"
		)->fetchAll();
		$tranches = array();
		foreach ( FKC_DB::q( 'SELECT * FROM ec_tranches ORDER BY inscription_id, ordre' )->fetchAll() as $t ) {
			$tranches[ (int) $t['inscription_id'] ][] = $t;
		}
		$out = array();
		foreach ( $ins as $i ) {
			$cid = $map[ fkc_recouv_cle_ecole( $i ) ] ?? 0;
			// Le payé de l'inscription s'impute sur ses tranches dans l'ordre,
			// exactement comme FKC_EcoleScolarite::situation().
			$reste = (float) $i['paye'];
			foreach ( $tranches[ (int) $i['id'] ] ?? array() as $t ) {
				$couvert = min( $reste, (float) $t['montant'] ); $reste -= $couvert;
				$out[] = array( 'ref' => $t['id'], 'client_id' => $cid,
					'tiers_nom' => trim( (string) $i['tuteur'] ) ? $i['tuteur'] . ' (' . $i['nom'] . ')' : $i['nom'],
					'telephone' => $i['tuteur_tel'],
					'numero' => $i['matricule'] . ' · ' . $t['libelle'],
					'date' => $t['echeance'], 'echeance' => $t['echeance'],
					'montant' => $t['montant'], 'paye' => $couvert );
			}
		}
		return $out;
	},
	'rattacher' => function () {
		$n = 0;
		foreach ( FKC_DB::q( "SELECT DISTINCT i.eleve_id, e.nom, e.tuteur, e.tuteur_tel FROM ec_inscriptions i
			JOIN ec_eleves e ON e.id=i.eleve_id WHERE i.statut='active'" )->fetchAll() as $r ) {
			$cle = fkc_recouv_cle_ecole( $r );
			if ( FKC_RecouvrementSources::tiers( 'scolarite', $cle, '', '', false ) ) { continue; }
			FKC_RecouvrementSources::tiers( 'scolarite', $cle, trim( (string) $r['tuteur'] ) ?: $r['nom'], $r['tuteur_tel'] );
			$n++;
		}
		return $n;
	},
	'non_rattachees' => function () {
		$map = FKC_RecouvrementSources::correspondances( 'scolarite' ); $n = 0;
		foreach ( FKC_DB::q( "SELECT DISTINCT i.eleve_id, e.tuteur, e.tuteur_tel FROM ec_inscriptions i
			JOIN ec_eleves e ON e.id=i.eleve_id WHERE i.statut='active'" )->fetchAll() as $r ) {
			if ( empty( $map[ fkc_recouv_cle_ecole( $r ) ] ) ) { $n++; }
		}
		return $n;
	},
) );

/* ── Loyers (pack Immobilier) : une créance par quittance ────────────────── */
function fkc_recouv_cle_bail( array $r ) {
	return 'loc:' . mb_strtolower( trim( (string) $r['locataire'] ) ) . '|' . preg_replace( '/\D+/', '', (string) ( $r['telephone'] ?? '' ) );
}
FKC_RecouvrementSources::register( 'loyers', array(
	'libelle'  => 'Loyers',
	'document' => 'votre loyer',
	'court'    => 'Loyer',
	'encaisser' => 'immobilier/gerance',
	'feminin'  => false,
	'creances' => function () {
		$map = FKC_RecouvrementSources::correspondances( 'loyers' );
		$rows = FKC_DB::q(
			"SELECT q.id, q.periode, q.date_echeance, q.montant, q.regle, b.locataire, b.telephone, b.id AS bail_id
			 FROM im_quittances q JOIN im_baux b ON b.id=q.bail_id"
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array( 'ref' => $r['id'], 'client_id' => $map[ fkc_recouv_cle_bail( $r ) ] ?? 0,
				'tiers_nom' => $r['locataire'], 'telephone' => $r['telephone'],
				'numero' => 'QUIT-' . (int) $r['id'] . ' · ' . $r['periode'],
				'date' => $r['periode'] . '-01', 'echeance' => $r['date_echeance'],
				'montant' => $r['montant'], 'paye' => min( (float) $r['regle'], (float) $r['montant'] ) );
		}
		return $out;
	},
	'rattacher' => function () {
		$n = 0;
		foreach ( FKC_DB::q( 'SELECT DISTINCT locataire, telephone FROM im_baux' )->fetchAll() as $r ) {
			$cle = fkc_recouv_cle_bail( $r );
			if ( FKC_RecouvrementSources::tiers( 'loyers', $cle, '', '', false ) ) { continue; }
			FKC_RecouvrementSources::tiers( 'loyers', $cle, $r['locataire'], $r['telephone'] );
			$n++;
		}
		return $n;
	},
	'non_rattachees' => function () {
		$map = FKC_RecouvrementSources::correspondances( 'loyers' ); $n = 0;
		foreach ( FKC_DB::q( 'SELECT DISTINCT locataire, telephone FROM im_baux' )->fetchAll() as $r ) {
			if ( empty( $map[ fkc_recouv_cle_bail( $r ) ] ) ) { $n++; }
		}
		return $n;
	},
) );

/* ── Redevances (gestion collective) : factures encaissées par le pack ───── */
/*
 * Aucune créance à déclarer — la redevance facturée EST une facture du
 * socle. Seul son encaissement, passé par l'écriture propre du pack
 * (gc_redevance_encaissee_*), doit être porté sur la facture.
 */
FKC_RecouvrementSources::register( 'redevances', array(
	'libelle'  => 'Redevances (gestion collective)',
	'document' => 'votre facture',
	'court'    => 'Facture',
	'imputations' => function () {
		$out = array();
		foreach ( FKC_DB::q( "SELECT facture_id, montant_encaisse FROM gc_redevances
			WHERE facture_id IS NOT NULL AND montant_encaisse > 0 AND statut <> 'annulee'" )->fetchAll() as $r ) {
			$out[ (int) $r['facture_id'] ] = (float) $r['montant_encaisse'];
		}
		return $out;
	},
) );
