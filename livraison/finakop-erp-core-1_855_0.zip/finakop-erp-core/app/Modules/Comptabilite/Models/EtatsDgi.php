<?php
/**
 * États financiers DGI (format Système Minimal de Trésorerie — SMT).
 * Bilan (GA/HA…) et Compte de résultat (KA/JA…) avec colonnes N et N-1,
 * base de renseignement de la liasse DGI de fin d'exercice.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_EtatsDgi {

	/** Net (débit - crédit) des comptes dont le numéro commence par l'un des préfixes, sur la période. */
	/**
	 * Soldes nets (débit − crédit) de TOUS les comptes mouvementés sur une
	 * période, en UNE requête, mémorisés par période.
	 *
	 * POURQUOI CE CACHE EXISTE
	 *
	 * net() était appelée une fois par préfixe : la seule cascade des soldes
	 * intermédiaires en déclenchait 33 par exercice, soit 66 balayages de
	 * ecriture_lignes pour un affichage — auxquels s'ajoutaient ceux du bilan
	 * et des états complémentaires. Tant que ces états ne servaient qu'à
	 * l'impression annuelle, le coût passait inaperçu ; exposés au Centre de
	 * Pilotage, ils sont rejoués à chaque ouverture de session.
	 *
	 * Un plan comptable compte quelques centaines de comptes : les charger
	 * intégralement puis agréger en PHP est sans commune mesure avec des
	 * dizaines de jointures. Le cache est indexé par période, donc N et N-1
	 * coûtent une requête chacun.
	 *
	 * @param string $d1 Début (Y-m-d).
	 * @param string $d2 Fin (Y-m-d).
	 * @return array<string, float> numéro de compte => solde net
	 */
	/** Carte des soldes mémorisée, par période. */
	protected static $cacheSoldes = array();

	/**
	 * Purge la carte des soldes.
	 *
	 * Indispensable après toute écriture : la mémorisation par période accélère
	 * la lecture des états, mais elle rendrait des soldes PÉRIMÉS à un
	 * contrôleur qui comptabilise puis affiche dans la même requête — un écran
	 * de validation qui montrerait la situation d'avant l'écriture qu'on vient
	 * d'accepter. FKC_Ecriture appelle cette purge à chaque enregistrement.
	 */
	public static function oublierSoldes() {
		self::$cacheSoldes = array();
		self::$memo = array(); self::$memoCle = null;
	}

	/* ══ Mémoïsation des états (1.854.0) ═════════════════════════════════════
	 *
	 * Un affichage de la liasse reconstruisait les mêmes états des dizaines
	 * de fois : controle() bâtit bilan SMT et SN, compte de résultat, flux et
	 * notes des deux systèmes ; resultat() rebâtit le bilan de N et de N-1 ;
	 * notes() rebâtit bilan et résultat… puis le contrôleur redemandait tout.
	 *
	 * Chaque état est désormais calculé UNE fois par requête. La clé suit
	 * `total_changes()` de la connexion, comme FKC_SoldeOuverture : toute
	 * écriture en base, où qu'elle soit faite — écriture comptable, brouillard,
	 * note annexe, UPDATE direct —, invalide le cache sans qu'un appelant ait
	 * à y penser. oublierSoldes() le purge aussi (changement d'état statique,
	 * comme FKC_Exercice::reset() dans les tests).
	 */
	protected static $memo = array();
	protected static $memoCle = null;

	protected static function memo( $nom, array $args, $calcul ) {
		try {
			$pdo = FKC_DB::conn();
			$cle = spl_object_id( $pdo ) . ':' . (int) $pdo->query( 'SELECT total_changes()' )->fetchColumn();
		} catch ( \Throwable $e ) { return call_user_func_array( $calcul, $args ); }
		if ( $cle !== self::$memoCle ) { self::$memo = array(); self::$memoCle = $cle; }
		$k = $nom . ':' . json_encode( $args );
		if ( ! array_key_exists( $k, self::$memo ) ) { self::$memo[ $k ] = call_user_func_array( $calcul, $args ); }
		return self::$memo[ $k ];
	}

	/**
	 * LE COMPTE DE RÉSULTAT NE SURVIVAIT PAS À LA DÉTERMINATION DU RÉSULTAT (1.786.0).
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * L'écriture de détermination du résultat solde les classes 6, 7 et 8 vers
	 * 131 (bénéfice) ou 139 (perte). Après elle, ces classes sont à zéro dans
	 * le grand livre — et la cascade du compte de résultat, SN comme SMT, les
	 * lit telles quelles. XI valait donc **zéro** sur tout exercice clôturé,
	 * quand `resultatNet()`, lui, savait retrouver le bon nombre en additionnant
	 * les deux états. Les deux lectures se contredisaient, et `controle()`
	 * déclarait la liasse INCOHÉRENTE.
	 *
	 * Conséquence, et elle est lourde : la liasse d'un exercice clôturé — donc
	 * **exactement le document qu'on dépose à la DGI** — n'était pas éditable,
	 * le produit refusant à juste titre de sortir des états incohérents. Le
	 * défaut est aussi ancien que la cascade ; il ne se voyait pas parce qu'on
	 * consulte les états AVANT de clôturer, et qu'après, on ne revient pas.
	 *
	 * Depuis la 1.782.0, ce même constat alimente un contrôle BLOQUANT de
	 * clôture. Il transformait le défaut en impasse : l'étape 4 du processus
	 * (« déterminer le résultat ») vidait les classes de gestion, et l'étape 5
	 * (« clôturer ») était alors refusée pour incohérence. Un exercice dont on
	 * avait déterminé le résultat ne pouvait plus être clôturé du tout.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * LA RÈGLE POSÉE ICI
	 *
	 * **Un compte de gestion se lit hors écriture de détermination du résultat.**
	 * Le compte de résultat est le relevé des MOUVEMENTS de l'année ; ce qui
	 * reste des classes 6/7/8 après leur virement n'en dit rien. La ligne de
	 * l'écriture sur 131/139 est en revanche CONSERVÉE : le bilan en a besoin,
	 * c'est là que le résultat figure au passif d'un exercice clôturé.
	 *
	 * L'écriture est reconnue à sa traçabilité (`source` + `origine`), écrite
	 * par `FKC_Cloture` au moment même où l'écriture naît. C'est le seul
	 * repère qui existe dès l'étape 4 : `clotures.ecriture_id` n'apparaît qu'à
	 * l'étape 5, et une correction qui s'y adosserait laisserait ouverte toute
	 * la fenêtre entre les deux.
	 */
	const ORIGINE_RESULTAT = 'resultat';
	const SOURCE_RESULTAT  = 'cloture';

	/** Clause SQL isolant l'écriture de détermination du résultat. */
	public static function sqlEcritureResultat( $alias = 'e' ) {
		return "( COALESCE({$alias}.origine,'') = '" . self::ORIGINE_RESULTAT
			. "' AND COALESCE({$alias}.source,'') = '" . self::SOURCE_RESULTAT . "' )";
	}

	protected static function soldesPeriode( $d1, $d2 ) {
		$cle = $d1 . '|' . $d2;
		if ( isset( self::$cacheSoldes[ $cle ] ) ) { return self::$cacheSoldes[ $cle ]; }
		$map = array();
		$res = self::sqlEcritureResultat( 'e' );
		try {
			foreach ( FKC_DB::q(
				"SELECT c.numero AS n, COALESCE(SUM(l.debit-l.credit),0) AS s
				 FROM ecriture_lignes l
				 JOIN ecritures e ON e.id=l.ecriture_id
				 JOIN comptes c ON c.id=l.compte_id
				 WHERE e.date_ecriture BETWEEN ? AND ?
				   AND NOT ( substr(c.numero,1,1) IN ('6','7','8') AND $res )
				 GROUP BY c.numero",
				array( $d1, $d2 )
			)->fetchAll() as $r ) {
				$map[ (string) $r['n'] ] = (float) $r['s'];
			}
		} catch ( \Throwable $e ) { $map = array(); }
		/*
		 * SOLDE D'OUVERTURE CALCULÉ (1.798.0).
		 *
		 * Une période qui commence le premier jour d'un exercice SANS
		 * À-nouveaux ne portait que les mouvements de l'année : capital,
		 * immobilisations, dettes et trésorerie d'ouverture en étaient absents,
		 * sur un bilan pourtant équilibré. Le gestionnaire des À-nouveaux
		 * fournit alors la clôture de N-1 — exactement ce que le Grand Livre
		 * et la Balance affichent. Quand les À-nouveaux existent, ils sont
		 * déjà dans la période et le complément est vide : jamais les deux.
		 */
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			try {
				foreach ( FKC_SoldeOuverture::complementCalcule( $d1 ) as $num => $solde ) {
					$map[ (string) $num ] = ( $map[ (string) $num ] ?? 0.0 ) + (float) $solde;
				}
			} catch ( \Throwable $e ) { /* le complément manque : controle() le signalera */ }
		}
		return self::$cacheSoldes[ $cle ] = $map;
	}

	/**
	 * Solde net cumulé des comptes dont le numéro commence par l'un des
	 * préfixes. Résultat identique à l'ancienne requête par LIKE '<pref>%',
	 * calculé sur la carte mémorisée de la période.
	 */
	protected static function net( array $prefixes, $d1, $d2 ) {
		$map = self::soldesPeriode( $d1, $d2 );
		if ( ! $map ) { return 0.0; }
		$total = 0.0;
		foreach ( $map as $numero => $solde ) {
			foreach ( $prefixes as $p ) {
				if ( 0 === strpos( $numero, (string) $p ) ) { $total += $solde; break; }
			}
		}
		return $total;
	}

	/**
	 * Soldes des comptes MOUVEMENTÉS d'une classe sur la période,
	 * indexés par numéro de compte.
	 *
	 * C'est la brique du routage exhaustif : au lieu de demander « combien
	 * font les comptes que je connais », on demande « quels comptes ont
	 * bougé », et chacun doit trouver sa ligne. Un compte ouvert par un pack
	 * métier ne peut plus passer entre les mailles.
	 *
	 * La classe se lit sur le PREMIER CHIFFRE du numéro, et non sur la colonne
	 * `classe` : c'est la même convention que net(), et elle reste juste même
	 * si un compte a été créé avec une classe mal renseignée.
	 */
	/** Soldes des comptes mouvementés de plusieurs classes, indexés par numéro. */
	protected static function soldesClasses( array $classes, $d1, $d2 ) {
		$out = array();
		foreach ( $classes as $c ) {
			foreach ( self::soldesClasse( $c, $d1, $d2 ) as $num => $solde ) { $out[ $num ] = $solde; }
		}
		ksort( $out );
		return $out;
	}

	protected static function soldesClasse( $classe, $d1, $d2 ) {
		$out = array();
		foreach ( self::soldesPeriode( $d1, $d2 ) as $numero => $solde ) {
			if ( 0 === strpos( (string) $numero, (string) $classe ) && abs( $solde ) > 0.004 ) {
				$out[ (string) $numero ] = (float) $solde;
			}
		}
		return $out;
	}

	/**
	 * Bornes de l'exercice — année civile si rien n'est déclaré.
	 *
	 * LES ÉTATS COUVRAIENT DOUZE MOIS QUI N'ÉTAIENT PAS CEUX DU DOSSIER (1.544.0).
	 *
	 * Bilan, compte de résultat, flux de trésorerie et annexes calculaient
	 * tous sur « $annee-01-01 → $annee-12-31 ». Chez un dossier clôturant au
	 * 30/06, la liasse remise à la DGI mélangeait la seconde moitié d'un
	 * exercice et la première du suivant : ni le résultat, ni le bilan, ni le
	 * comparatif N-1 ne correspondaient à la période déclarée. Rien ne le
	 * signalait, puisque les états s'équilibraient parfaitement — sur la
	 * mauvaise période.
	 */
	protected static function bornesEx( $annee ) {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'bornes' ) ) {
			return FKC_Exercice::bornes( (int) $annee );
		}
		return array( sprintf( '%04d-01-01', (int) $annee ), sprintf( '%04d-12-31', (int) $annee ) );
	}

	/**
	 * Résultat de l'exercice, tel qu'il doit figurer au passif du bilan.
	 *
	 * LE BILAN NE TENAIT PAS DEBOUT DÈS QU'IL SE PASSAIT QUELQUE CHOSE (1.564.0).
	 *
	 * Cette méthode ne lisait que les classes 6 et 7. La classe 8 — activités
	 * hors activités ordinaires ET impôt sur le résultat — en était absente.
	 * Or ces comptes-là ne sont pas exotiques : ils s'ouvrent à la première
	 * cession d'immobilisation et à la première liquidation d'impôt.
	 *
	 * L'effet était mécanique. Une cession débite la banque et sort le bien :
	 * l'actif bouge de la plus-value. Le produit de cession vivant en 82 et la
	 * valeur comptable en 81, le résultat calculé ici les ignorait tous les
	 * deux, et le passif ne bougeait pas. Le bilan sortait faux de la
	 * plus-value exacte — mesuré : 700 000 F d'écart sur une cession banale.
	 * L'impôt sur les bénéfices (89) faisait la même chose en sens inverse.
	 *
	 * SECONDE MOITIÉ DU DÉFAUT : L'EXERCICE CLÔTURÉ.
	 *
	 * La clôture annuelle solde les classes de gestion vers 131 (bénéfice) ou
	 * 139 (perte). Après elle, les classes 6, 7 et 8 sont à zéro : ce calcul
	 * renvoyait donc 0, et le résultat n'était plus nulle part au passif du
	 * bilan Système Normal, qui ne routait aucun compte 13. Le bilan de tout
	 * exercice CLÔTURÉ — c'est-à-dire précisément celui qu'on dépose — était
	 * déséquilibré du montant entier du résultat.
	 *
	 * On additionne donc les deux : le résultat encore dans les comptes de
	 * gestion, et celui déjà viré en 131/139. L'un des deux est toujours nul,
	 * jamais les deux à la fois, et leur somme est le résultat dans les deux
	 * états du dossier — avant comme après clôture.
	 *
	 * @param string $d1 Début de l'exercice (Y-m-d).
	 * @param string $d2 Fin de l'exercice (Y-m-d).
	 * @return float Bénéfice positif, perte négative.
	 */
	protected static function resultatNet( $d1, $d2 ) {
		// Produits au crédit, charges au débit : le résultat est l'opposé du
		// solde net des trois classes de gestion.
		$gestion = -self::net( array( '6', '7', '8' ), $d1, $d2 );
		/*
		 * LA SOMME NE DOIT PAS COMPTER LE RÉSULTAT DEUX FOIS (1.786.0).
		 *
		 * Le commentaire ci-dessus repose sur « l'un des deux est toujours
		 * nul » : avant la détermination, les classes de gestion portent le
		 * résultat et 131/139 sont vides ; après, l'inverse. Depuis que les
		 * classes de gestion se lisent HORS écriture de détermination
		 * (voir soldesPeriode), `$gestion` reste juste dans les deux états —
		 * et les deux termes deviendraient non nuls en même temps.
		 *
		 * La part de 131/139 écrite par cette même écriture est donc neutralisée
		 * ici, exactement comme l'étaient déjà les à-nouveaux et l'affectation.
		 * Ce qui subsiste de `$affecte` est ce qu'aucun mécanisme du logiciel
		 * n'explique — un virement manuel en 131 —, et il continue de compter.
		 */
		$affecte = -( self::net( array( '131', '139' ), $d1, $d2 )
			- self::netReporte( array( '131', '139' ), $d1, $d2 )
			- self::netDetermination( array( '131', '139' ), $d1, $d2 ) );
		return $gestion + $affecte;
	}

	/**
	 * Part des comptes 131/139 REPORTÉE par les à-nouveaux, et non déterminée
	 * par la clôture de l'exercice consulté.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * LE DÉFAUT QUE CECI RÉPARE N'APPARAISSAIT QU'AU DEUXIÈME EXERCICE (1.564.2)
	 *
	 * Tant que le résultat déterminé n'a pas été affecté par l'assemblée, il
	 * reste en 131, et l'ouverture de l'exercice suivant le REPORTE avec les
	 * autres soldes de bilan. Le calcul du résultat lisait alors ce report
	 * comme un résultat de l'année : l'exercice N+1 s'attribuait le bénéfice
	 * de N en plus du sien.
	 *
	 * Rien ne le signalait, parce que le bilan RESTAIT ÉQUILIBRÉ — le montant
	 * était au bon endroit, sous le mauvais nom. C'est le tableau des flux de
	 * trésorerie, construit ensuite, qui l'a fait apparaître : lui seul
	 * rapproche le résultat des mouvements réels de trésorerie.
	 *
	 * Un contrôle qui ne se déclenche qu'au deuxième exercice est le pire des
	 * contrôles : il laisse le temps de prendre confiance.
	 */
	/**
	 * PART DE 131/139 QUI N'EST PAS LE RÉSULTAT DE L'EXERCICE (1.785.0).
	 *
	 * Deux mouvements y touchent sans rien dire du résultat de l'année :
	 *   — les À-NOUVEAUX, qui reportent un résultat antérieur non affecté ;
	 *   — l'AFFECTATION de ce résultat antérieur, décidée par l'assemblée
	 *     PENDANT l'exercice (D 131 / C 111-121 pour un bénéfice, D 121 / C 139
	 *     pour une perte), qui le solde.
	 *
	 * netANouveaux() ne voyait que le premier. L'écriture d'affectation, datée
	 * de l'exercice N+1, était donc lue comme un résultat de N+1 : le compte de
	 * résultat restait juste (il ne lit que 6/7/8), mais le « résultat du grand
	 * livre » s'en écartait du montant affecté, le report à nouveau du bilan le
	 * comptait deux fois, et le contrôle bloquant « états financiers
	 * incohérents » REFUSAIT la clôture de tout exercice au cours duquel le
	 * résultat précédent avait été affecté — c'est-à-dire de tous, dès la
	 * deuxième année. Trouvé par l'audit de conformité du chantier clôture.
	 */
	protected static function netReporte( array $prefixes, $d1, $d2 ) {
		return self::netANouveaux( $prefixes, $d1, $d2 ) + self::netAffectations( $prefixes, $d1, $d2 );
	}

	/**
	 * Mouvements portés sur ces comptes par l'écriture de détermination du
	 * résultat elle-même (1.786.0).
	 *
	 * Elle n'est PAS exclue de `soldesPeriode()` sur les comptes de bilan :
	 * c'est elle qui place le résultat en 131/139, et le passif d'un exercice
	 * clôturé n'aurait plus rien sans elle. Elle doit donc être neutralisée
	 * ici, et ici seulement, pour ne pas s'ajouter au résultat que les classes
	 * de gestion portent déjà.
	 */
	protected static function netDetermination( array $prefixes, $d1, $d2 ) {
		$ou = array(); $args = array( $d1, $d2 );
		foreach ( $prefixes as $p ) { $ou[] = 'c.numero LIKE ?'; $args[] = $p . '%'; }
		if ( ! $ou ) { return 0.0; }
		$res = self::sqlEcritureResultat( 'e' );
		try {
			return (float) FKC_DB::q(
				'SELECT COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0)
				 FROM ecriture_lignes l JOIN ecritures e ON e.id = l.ecriture_id JOIN comptes c ON c.id = l.compte_id
				 WHERE ' . $res . ' AND e.date_ecriture BETWEEN ? AND ? AND (' . implode( ' OR ', $ou ) . ')',
				$args
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/** Mouvements des écritures d'affectation du résultat datées de la période. */
	protected static function netAffectations( array $prefixes, $d1, $d2 ) {
		$ou = array(); $args = array( $d1, $d2 );
		foreach ( $prefixes as $p ) { $ou[] = 'c.numero LIKE ?'; $args[] = $p . '%'; }
		if ( ! $ou ) { return 0.0; }
		try {
			return (float) FKC_DB::q(
				'SELECT COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0)
				 FROM ecriture_lignes l JOIN ecritures e ON e.id = l.ecriture_id JOIN comptes c ON c.id = l.compte_id
				 WHERE e.id IN (SELECT ecriture_id FROM affectations_resultat WHERE ecriture_id IS NOT NULL)
				   AND e.date_ecriture BETWEEN ? AND ? AND (' . implode( ' OR ', $ou ) . ')',
				$args
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }   // table absente : aucune affectation
	}

	protected static function netANouveaux( array $prefixes, $d1, $d2 ) {
		/*
		 * Solde d'ouverture de l'exercice — écriture d'À-nouveaux OU solde
		 * calculé — lu par le gestionnaire central (1.798.0). L'ancienne
		 * lecture ne suivait que le pointeur `an_ecriture_id` : un pointeur
		 * orphelin, ou un solde calculé, faisait lire un résultat antérieur
		 * comme le résultat de l'année.
		 */
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			try {
				$an = FKC_SoldeOuverture::exerciceDe( $d2 );
				if ( (string) $d1 > FKC_SoldeOuverture::debutDe( $an ) ) { return 0.0; }
				return FKC_SoldeOuverture::netOuverture( $an, $prefixes );
			} catch ( \Throwable $e ) { return 0.0; }
		}
		if ( ! class_exists( 'FKC_Exercice' ) ) { return 0.0; }
		$annee = FKC_Exercice::annee( $d2 );
		$ex    = FKC_Exercice::find( (int) $annee );
		if ( ! $ex || empty( $ex['an_ecriture_id'] ) ) { return 0.0; }

		$ou = array(); $args = array( (int) $ex['an_ecriture_id'] );
		foreach ( $prefixes as $p ) { $ou[] = 'c.numero LIKE ?'; $args[] = $p . '%'; }
		if ( ! $ou ) { return 0.0; }
		try {
			$r = FKC_DB::q(
				'SELECT COALESCE(SUM(l.debit),0) - COALESCE(SUM(l.credit),0) n
				 FROM ecriture_lignes l JOIN comptes c ON c.id = l.compte_id
				 WHERE l.ecriture_id = ? AND (' . implode( ' OR ', $ou ) . ')',
				$args
			)->fetch();
		} catch ( \Throwable $e ) { return 0.0; }
		return $r ? (float) $r['n'] : 0.0;
	}

	/* ── Solde d'ouverture calculé (1.798.0) ───────────────────────────────── */

	/** Clause « période de bilan » : [d1,d2], solde d'ouverture compris quand d1 ouvre l'exercice. */
	protected static function clausePeriodeBilan( $d1, $d2 ) {
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			$n = FKC_SoldeOuverture::exerciceDe( $d2 );
			if ( (string) $d1 === FKC_SoldeOuverture::debutDe( $n ) ) { return FKC_SoldeOuverture::clauseJusqua( $d2 ); }
		}
		return array( 'e.date_ecriture BETWEEN ? AND ?', array( (string) $d1, (string) $d2 ) );
	}

	/**
	 * Compte d'actif auquel se rapporte un compte d'amortissement ou de
	 * dépréciation, par la règle de numérotation SYSCOHADA.
	 *
	 * 28 et 29 reprennent le numéro du bien amorti : 2845 amortit le 245,
	 * 2917 déprécie le 217, 296 déprécie le 26. Déduire le bien du numéro,
	 * plutôt que tenir une liste de préfixes en regard de chaque ligne du
	 * bilan, supprime d'un coup deux familles d'erreurs constatées :
	 *
	 *   — les OUBLIS : 291800, 293400, 293500, 293700, 293800, 293900,
	 *     281010 et 286000 n'étaient cités par aucune ligne. Leur montant
	 *     disparaissait purement et simplement de la liasse ;
	 *   — les DOUBLONS : 294500 était compté à la fois dans « Matériel,
	 *     mobilier » (préfixe 294) et dans « Matériel de transport » (2945),
	 *     et les huit comptes 296x à la fois dans « Titres de participation »
	 *     et dans « Autres immobilisations financières ». La dépréciation
	 *     était déduite deux fois : actif net sous-évalué, bilan faux.
	 *
	 * Une règle vaut mieux qu'une liste : elle vaut aussi pour les comptes
	 * que les packs métiers ouvriront demain.
	 */
	protected static function actifSousJacent( $numero ) {
		$p = substr( (string) $numero, 0, 2 );
		if ( '28' === $p || '29' === $p ) { return '2' . substr( (string) $numero, 2 ); }
		return (string) $numero;
	}

	/** Vrai si le compte vient en déduction de l'actif (amortissement, dépréciation). */
	protected static function estContraActif( $numero ) {
		$p = substr( (string) $numero, 0, 2 );
		return '28' === $p || '29' === $p || '209' === substr( (string) $numero, 0, 3 );
	}

	/**
	 * Ligne du bilan Système Normal pour un compte de la classe 1.
	 *
	 * Les préfixes sont rangés du plus précis au plus général : le premier qui
	 * accroche gagne. `null` signifie « aucune ligne ne réclame ce compte » —
	 * l'appelant le range alors dans le report à nouveau ET le signale, ce qui
	 * vaut mieux que de le perdre en silence, comme c'était le cas pour les
	 * 13x (résultat) et les 18x (comptes de liaison et dettes liées à des
	 * participations) : 2 000 000 F s'évaporaient du passif sur un simple
	 * compte courant de groupe.
	 */
	protected static function ligneClasse1( $numero ) {
		static $map = array(
			'109' => 'CB', '105' => 'CD', '106' => 'CE',
			'111' => 'CF', '112' => 'CF', '113' => 'CF',
			'131' => 'CJ', '139' => 'CJ',
			'10'  => 'CA', '11' => 'CG', '12' => 'CH', '13' => 'CH',
			'14'  => 'CL', '15' => 'CM',
			'16'  => 'DA', '18' => 'DA', '17' => 'DB', '19' => 'DC',
		);
		$numero = (string) $numero;
		foreach ( $map as $pref => $code ) {
			if ( 0 === strpos( $numero, $pref ) ) { return $code; }
		}
		return null;
	}

	/** Ligne d'immobilisation du bilan SN pour un compte de la classe 2. */
	protected static function ligneClasse2( $numero ) {
		static $map = array(
			'211' => 'AE', '212' => 'AE', '213' => 'AF', '214' => 'AF',
			'215' => 'AG', '216' => 'AG',
			'231' => 'AK', '232' => 'AK', '233' => 'AK',
			'245' => 'AN',
			'20'  => 'AH', '21' => 'AH', '22' => 'AJ', '23' => 'AL',
			'24'  => 'AM', '25' => 'AP', '26' => 'AR', '27' => 'AS',
		);
		$ref = self::actifSousJacent( $numero );
		foreach ( $map as $pref => $code ) {
			if ( 0 === strpos( $ref, $pref ) ) { return $code; }
		}
		return null;
	}

	/**
	 * Ventilation d'un compte (classes 1 à 5) sur le bilan SMT
	 * → array( côté 'A'|'P', ligne, montant signé ).
	 *
	 * LA CLASSE 1 EST TRAITÉE AVANT LE TEST DE SIGNE (1.564.0).
	 *
	 * Le test « solde débiteur → actif » venait en premier et n'avait pas de
	 * cas pour la classe 1 : il tombait donc sur son repli, « Clients et
	 * débiteurs divers ». Un report à nouveau débiteur (129) ou une perte
	 * nette (139) — deux comptes de capitaux propres parfaitement ordinaires —
	 * s'affichaient à l'actif du bilan comme une créance client. Les capitaux
	 * propres appartiennent au passif quel que soit leur sens ; un solde
	 * débiteur y figure en négatif, il ne change pas de côté.
	 */
	protected static function classify( $numero, $solde ) {
		$numero = (string) $numero;
		$n2 = substr( $numero, 0, 2 ); $n3 = substr( $numero, 0, 3 ); $c1 = substr( $numero, 0, 1 );

		// Capitaux propres et ressources assimilées : toujours au passif.
		if ( '1' === $c1 ) {
			// 131/139 sont portés par la ligne « Résultat de l'exercice » (HB),
			// alimentée par resultatNet() : les compter ici les doublerait.
			if ( '131' === $n3 || '139' === $n3 ) { return array( 'P', 'HB', -$solde ); }
			if ( in_array( $n3, array( '101', '104', '105' ), true ) ) { return array( 'P', 'HA', -$solde ); }
			if ( in_array( $n2, array( '16', '17', '18', '19' ), true ) ) { return array( 'P', 'HC', -$solde ); }
			return array( 'P', 'HE', -$solde );
		}

		// Comptes contra-actif (amortissements / dépréciations) : toujours côté
		// actif, en déduction du poste qu'ils corrigent.
		if ( in_array( $n2, array( '28', '29' ), true ) ) { return array( 'A', 'GA', $solde ); }
		if ( '39' === $n2 ) { return array( 'A', 'GB', $solde ); }
		if ( '49' === $n2 ) { return array( 'A', 'GC', $solde ); }

		/*
		 * LA BANQUE DU SMT EST UNE LIGNE SIGNÉE (1.568.0).
		 *
		 * Le modèle intitule la ligne GF « Banque (en + ou en -) » : un découvert
		 * s'y inscrit en négatif, il ne bascule pas au passif. Le renvoyer vers
		 * « Fournisseurs et créditeurs divers », comme on le faisait, gonflait
		 * les dettes d'exploitation d'un montant bancaire et faussait au passage
		 * la variation des dettes qui sert au compte de résultat.
		 *
		 * La caisse (GD) ne peut pas être créditrice : un solde négatif y est
		 * une anomalie de saisie, qu'on laisse voir plutôt que de déguiser.
		 */
		if ( '5' === $c1 ) {
			if ( '57' === $n2 ) { return array( 'A', 'GD', $solde ); }
			return array( 'A', 'GF', $solde );
		}
		if ( $solde > 0 ) { // débiteur → actif
			if ( '2' === $c1 ) { return array( 'A', 'GA', $solde ); }
			if ( '3' === $c1 ) { return array( 'A', 'GB', $solde ); }
			if ( '4' === $c1 ) { return array( 'A', 'GC', $solde ); }
			return array( 'A', 'GC', $solde );
		}
		// Un stock ou une immobilisation créditeurs n'existent pas : ce sont
		// des anomalies de saisie. On les laisse du côté de leur poste plutôt
		// que de les déguiser en dette.
		if ( '2' === $c1 ) { return array( 'A', 'GA', $solde ); }
		if ( '3' === $c1 ) { return array( 'A', 'GB', $solde ); }
		return array( 'P', 'HD', -$solde ); // classes 4 et 5 créditrices
	}

	/** Bilan SMT sur une année (avec N-1). */
	public static function bilan( $annee ) {
		return self::memo( 'bilan', array( $annee ), array( __CLASS__, 'bilanCalcul' ) );
	}

	protected static function bilanCalcul( $annee ) {
		$annee = (int) $annee; $n1 = $annee - 1;
		$periodes = array(
			'n'  => array( self::bornesEx( $annee )[0], self::bornesEx( $annee )[1] ),
			'n1' => array( self::bornesEx( $n1 )[0], self::bornesEx( $n1 )[1] ),
		);
		$actif  = array( 'GA' => 0, 'GB' => 0, 'GC' => 0, 'GD' => 0, 'GF' => 0 );
		$passif = array( 'HA' => 0, 'HB' => 0, 'HC' => 0, 'HD' => 0, 'HE' => 0 );
		$res = array( 'actif' => array(), 'passif' => array() );

		foreach ( $periodes as $k => $per ) {
			$a = array_fill_keys( array_keys( $actif ), 0.0 );
			$p = array_fill_keys( array_keys( $passif ), 0.0 );
			/*
			 * MÊME CARTE DE SOLDES QUE LE BILAN SN (1.853.0).
			 *
			 * La requête propre au SMT filtrait sur la colonne `classe`, quand
			 * tout le reste des états lit la classe sur le PREMIER CHIFFRE du
			 * numéro. Un compte importé avec une classe mal renseignée
			 * (migration, reprise de balance) sortait du bilan SMT et restait
			 * dans le SN : deux bilans du même dossier, deux totaux. La carte
			 * mémorisée inclut déjà le solde d'ouverture calculé.
			 */
			foreach ( self::soldesClasses( array( 1, 2, 3, 4, 5 ), $per[0], $per[1] ) as $numero => $solde ) {
				list( $cote, $ligne, $montant ) = self::classify( $numero, (float) $solde );
				if ( 'A' === $cote ) { $a[ $ligne ] += $montant; } else { $p[ $ligne ] += $montant; }
			}
			/*
			 * classify() a rangé 131/139 en HB ; on écrase donc cette ligne
			 * avec le résultat calculé, pour ne pas compter deux fois le même
			 * montant. Mais resultatNet() écarte la part REPORTÉE par les
			 * à-nouveaux — un résultat antérieur non affecté : elle rejoint
			 * les réserves et reports (HE), faute de quoi elle disparaîtrait
			 * du bilan dès le deuxième exercice.
			 */
			$p['HB']  = self::resultatNet( $per[0], $per[1] );
			$p['HE'] += -self::netReporte( array( '131', '139' ), $per[0], $per[1] );
			$res['actif'][ $k ]  = $a;
			$res['passif'][ $k ] = $p;
		}

		$libA = array( 'GA' => 'Immobilisations', 'GB' => 'Stocks', 'GC' => 'Clients et débiteurs divers', 'GD' => 'Caisse', 'GF' => 'Banque (en + ou en -)' );
		$noteA = array( 'GA' => '3', 'GB' => '4', 'GC' => '5 & 8', 'GD' => '', 'GF' => '' );
		$libP = array( 'HA' => 'Capital', 'HB' => "Résultat de l'exercice (+ ou -)", 'HC' => 'Emprunts et dettes financières', 'HD' => 'Fournisseurs et créditeurs divers', 'HE' => 'Réserves, report à nouveau' );
		$noteP = array( 'HA' => '', 'HB' => '', 'HC' => '6', 'HD' => '5 & 9', 'HE' => '' );

		$actifLines = array(); $totA_n = 0; $totA_n1 = 0;
		foreach ( array( 'GA', 'GB', 'GC', 'GD', 'GF' ) as $code ) {
			$actifLines[ $code ] = array( 'code' => $code, 'libelle' => $libA[ $code ], 'note' => $noteA[ $code ], 'n' => $res['actif']['n'][ $code ], 'n1' => $res['actif']['n1'][ $code ] );
			$totA_n += $res['actif']['n'][ $code ]; $totA_n1 += $res['actif']['n1'][ $code ];
		}
		$passifLines = array(); $totP_n = 0; $totP_n1 = 0;
		foreach ( array( 'HA', 'HE', 'HB', 'HC', 'HD' ) as $code ) {
			$passifLines[ $code ] = array( 'code' => $code, 'libelle' => $libP[ $code ], 'note' => $noteP[ $code ], 'n' => $res['passif']['n'][ $code ], 'n1' => $res['passif']['n1'][ $code ] );
			$totP_n += $res['passif']['n'][ $code ]; $totP_n1 += $res['passif']['n1'][ $code ];
		}

		return array(
			'annee' => $annee, 'annee_n1' => $n1,
			'actif' => $actifLines, 'passif' => $passifLines,
			'total_actif' => array( 'n' => $totA_n, 'n1' => $totA_n1 ),
			'total_passif' => array( 'n' => $totP_n, 'n1' => $totP_n1 ),
			'equilibre' => abs( $totA_n - $totP_n ) < 1,
		);
	}

	/**
	 * Compte de résultat du Système Minimal de Trésorerie.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * IL LUI MANQUAIT TROIS LIGNES, ET SA FORMULE ÉTAIT FAUSSE (1.568.0)
	 *
	 * Le SMT n'est pas une comptabilité d'engagement présentée en plus court :
	 * c'est une comptabilité de TRÉSORERIE. Le modèle le dit dans ses propres
	 * intitulés — « TOTAL DES RECETTES SUR PRODUITS (A) (non compris recettes
	 * non encaissées) », « TOTAL DÉPENSES SUR CHARGES (B) (non compris charges
	 * non décaissées) » — puis rétablit le résultat comptable par trois
	 * corrections :
	 *
	 *   VA  + Variations des stocks sur les achats  (D)
	 *   VB  + Variation des créances                (E)
	 *   VC  − Variation des dettes d'exploitation   (F)
	 *
	 *   RÉSULTAT (H) = C + D + E − F − G
	 *
	 * Ces trois lignes n'existaient nulle part chez nous, et le résultat était
	 * calculé H = C − G. Le total tombait juste par accident — parce que A et B
	 * étaient tenus en engagement, si bien que C valait déjà le résultat avant
	 * dotations. Mais les lignes A et B ne voulaient alors pas dire ce que le
	 * formulaire annonce, et les trois corrections restaient à zéro.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * COMMENT LES RECETTES ET DÉPENSES REDEVIENNENT DES ENCAISSEMENTS
	 *
	 * FinaKop tient une comptabilité d'engagement. On repasse en trésorerie en
	 * retranchant les corrections là où elles se rattachent naturellement :
	 *
	 *   — la variation des créances se retranche des VENTES (KA) : ce qui est
	 *     facturé et non encaissé n'est pas une recette ;
	 *   — la variation des stocks s'ajoute aux ACHATS (JA) : ce qui est acheté
	 *     et non consommé a bien été décaissé ;
	 *   — la variation des dettes se retranche des ACHATS (JA) : ce qui est dû
	 *     et non payé n'est pas une dépense.
	 *
	 * Ces rattachements sont ceux du modèle lui-même (« variations des stocks
	 * SUR LES ACHATS »). Le résultat final est, par construction, celui du
	 * grand livre : les corrections s'annulent exactement contre elles-mêmes.
	 */
	public static function resultat( $annee ) {
		return self::memo( 'resultat', array( $annee ), array( __CLASS__, 'resultatCalcul' ) );
	}

	protected static function resultatCalcul( $annee ) {
		$annee = (int) $annee; $n1 = $annee - 1;

		/*
		 * Le `max( 0, … )` faisait disparaître de l'argent (corrigé en
		 * 1.564.0) : un poste borné à zéro perd son montant, et le total avec
		 * lui. Un poste négatif se lit — déstockage, rabais obtenu, reprise.
		 */
		$calc = function ( $an ) {
			$an = (int) $an;
			list( $d1, $d2 ) = self::bornesEx( $an );
			/*
			 * ROUTAGE COMPTE PAR COMPTE (1.853.0). Chaque compte de gestion
			 * mouvementé trouve SA ligne — préfixe connu, sinon repli de sa
			 * classe — au lieu d'additionner des listes de préfixes : un
			 * compte ouvert par un Pack Métier hors de ces listes ne peut plus
			 * sortir du compte de résultat sans que le total le sache.
			 */
			$g = array_fill_keys( array_keys( self::postesResultatSmt() ), 0.0 );
			foreach ( self::soldesClasses( array( 6, 7, 8 ), $d1, $d2 ) as $num => $solde ) {
				$code = self::ligneResultatSmt( $num );
				if ( null === $code ) { continue; }
				$g[ $code ] += ( 'K' === $code[0] ) ? -$solde : $solde;
			}

			// Variations de bilan, lues sur le bilan SMT lui-même.
			$b = self::bilan( $an );
			$dl = function ( $c ) use ( $b ) {
				foreach ( array( 'actif', 'passif' ) as $cote ) {
					if ( isset( $b[ $cote ][ $c ] ) ) { return (float) $b[ $cote ][ $c ]['n'] - (float) $b[ $cote ][ $c ]['n1']; }
				}
				return 0.0;
			};
			$VA = $dl( 'GB' );            // variation des stocks
			$VB = $dl( 'GC' );            // variation des créances
			$VC = $dl( 'HD' );            // variation des dettes d'exploitation

			$KA = $g['KA'] - $VB;                  // ventes encaissées
			$KB = $g['KB'];
			$JA = $g['JA'] + $VA - $VC;            // achats décaissés
			$JB = $g['JB']; $JC = $g['JC']; $JD = $g['JD']; $JE = $g['JE']; $JF = $g['JF']; $JG = $g['JG'];

			$KX = $KA + $KB;
			$JX = $JA + $JB + $JC + $JD + $JE + $JF;
			$KZ = $KX - $JX;
			$KZC = $KZ + $VA + $VB - $VC - $JG;
			return compact( 'KA', 'KB', 'KX', 'JA', 'JB', 'JC', 'JD', 'JE', 'JF', 'JX', 'KZ', 'VA', 'VB', 'VC', 'JG', 'KZC' );
		};
		$N  = $calc( $annee );
		$P  = $calc( $n1 );

		// Libellés relevés sur le classeur DGI, mot pour mot.
		$lib = array(
			'KA' => 'Recettes sur ventes ou prestations de services',
			'KB' => 'Autres recettes sur activités',
			'KX' => 'TOTAL DES RECETTES SUR PRODUITS (A) (non compris recettes non encaissées)',
			'JA' => 'Dépenses sur achats',
			'JB' => 'Dépenses sur loyers',
			'JC' => 'Dépenses sur salaires',
			'JD' => 'Dépenses sur impôts et taxes',
			'JE' => "Charges d'intérêts",
			'JF' => 'Autres dépenses sur activités',
			'JX' => 'TOTAL DEPENSES SUR CHARGES (B) (non compris charges non décaissées)',
		);
		$mk = function ( $codes ) use ( $N, $P, $lib ) {
			$out = array();
			foreach ( $codes as $c ) {
				$out[ $c ] = array( 'code' => $c, 'libelle' => $lib[ $c ], 'n' => $N[ $c ], 'n1' => $P[ $c ],
					'bold' => in_array( $c, array( 'KX', 'JX' ), true ) );
			}
			return $out;
		};
		$sold = function ( $c, $libelle ) use ( $N, $P ) {
			return array( 'code' => $c, 'libelle' => $libelle, 'n' => $N[ $c ], 'n1' => $P[ $c ] );
		};

		return array(
			'annee' => $annee, 'annee_n1' => $n1,
			'produits' => $mk( array( 'KA', 'KB', 'KX' ) ),
			'charges'  => $mk( array( 'JA', 'JB', 'JC', 'JD', 'JE', 'JF', 'JX' ) ),
			'kz'  => $sold( 'KZ', 'SOLDE (C) : Excédent (+) ou insuffisance (-) de recettes (C = A - B)' ),
			// Les trois corrections qui font repasser la trésorerie en résultat.
			'variations' => array(
				$sold( 'VA', '+ Variations des stocks sur les achats [N - (N-1)] (D)' ),
				$sold( 'VB', '+ Variation des créances [N - (N-1)] (E)' ),
				$sold( 'VC', '- Variation des dettes d\'exploitation [N - (N-1)] (F)' ),
			),
			'jg'  => $sold( 'JG', 'DOTATIONS AUX AMORTISSEMENTS (G)' ),
			'kzc' => $sold( 'KZC', "RESULTAT DE L'EXERCICE (H = C + D + E - F - G)" ),
		);
	}

	/**
	 * Comptes de gestion rattachés à chaque poste du compte de résultat SN.
	 *
	 * Cette table était écrite EN LIGNE dans sigBruts(). Les notes annexes ont
	 * besoin exactement de la même : la note « Achats » doit contenir les
	 * comptes que la ligne RA additionne, sinon la note et le poste qu'elle
	 * détaille annoncent deux montants différents. Une seule définition les
	 * rend incapables de diverger.
	 *
	 * Rangée du plus précis au plus général : le premier préfixe qui accroche
	 * gagne, comme pour les classes 1 et 2.
	 */
	/**
	 * Comptes de gestion rattachés à chaque poste du compte de résultat SMT.
	 *
	 * Même raison d'être que postesResultat() pour le Système Normal : les
	 * notes annexes doivent détailler exactement les comptes que le poste
	 * additionne, et une seconde liste serait une seconde occasion de diverger.
	 */
	protected static function postesResultatSmt() {
		return array(
			'KA' => array( '70', '71' ),
			'KB' => array( '72', '73', '74', '75', '77', '78', '79', '82', '84', '86', '88' ),
			'JA' => array( '60', '61' ),
			'JB' => array( '62', '63' ),
			'JC' => array( '66' ),
			'JD' => array( '64', '89' ),
			'JE' => array( '67' ),
			'JF' => array( '65', '69', '81', '83', '85', '87' ),
			'JG' => array( '68' ),
		);
	}


	/** Accès public au net() pour les closures. */
	public static function netPub( $pref, $d1, $d2 ) { return self::net( (array) $pref, $d1, $d2 ); }

	/* ═══════════════════ SYSTÈME NORMAL (SN) — liasse officielle DGI ═══════════════════ */

	/** Solde net (débit - crédit) cumulé sur l'exercice pour une liste de préfixes de comptes. */
	protected static function snNet( $prefixes, $d1, $d2 ) { return self::net( (array) $prefixes, $d1, $d2 ); }

	/**
	 * Poste du bilan SN pour un compte des classes 3, 4 ou 5.
	 *
	 * Ce routage vivait à l'intérieur de bilanSN(), dans une fermeture. Les
	 * notes annexes ont besoin de la MÊME attribution, compte par compte :
	 * une note qui détaille la ligne « Clients » doit contenir exactement les
	 * comptes que cette ligne additionne. Sortir la règle de la fermeture est
	 * la seule façon de garantir qu'une note et son poste ne puissent jamais
	 * annoncer deux totaux différents.
	 *
	 * Le sens du solde compte : un fournisseur débiteur est une créance, un
	 * compte bancaire créditeur est un découvert. La méthode reçoit donc le
	 * solde et renvoie array( code, montant signé pour ce poste ).
	 */
	protected static function posteClasse345( $num, $s ) {
		$num = (string) $num;
		// Troisième élément du retour : vrai si le compte est une dépréciation,
		// qui doit alimenter la colonne « AMORT et DEPREC. » du bilan officiel.
		$dep = in_array( substr( $num, 0, 2 ), array( '39', '49', '59' ), true )
			&& ! in_array( substr( $num, 0, 3 ), array( '499', '599' ), true );
		$n2 = substr( $num, 0, 2 ); $n3 = substr( $num, 0, 3 );
		$deb = $s > 0; $m = abs( $s );

		// Stocks (classe 3), dépréciations 39 comprises : elles viennent en
		// déduction du poste qu'elles corrigent.
		if ( '3' === substr( $num, 0, 1 ) ) { return array( 'BB', $s, $dep ); }

		/*
		 * Un fournisseur DÉBITEUR est une créance, pas une dette en négatif :
		 * il rejoint « Fournisseurs, avances versées ».
		 */
		if ( '40' === $n2 ) {
			if ( '409' === $n3 || $deb ) { return array( 'BH', $m, $dep ); }
			return array( 'DJ', $m, $dep );
		}
		if ( '41' === $n2 ) {
			if ( '419' === $n3 ) { return array( 'DI', -$s, $dep ); }
			return $deb ? array( 'BI', $m, $dep ) : array( 'DI', $m, $dep );
		}
		if ( in_array( $n2, array( '42', '43', '44' ), true ) ) {
			return $deb ? array( 'BJ', $m, $dep ) : array( 'DK', $m, $dep );
		}
		if ( in_array( $n2, array( '45', '46', '47' ), true ) ) {
			if ( '476' === $n3 || '478' === $n3 ) { return array( 'BU', $s, $dep ); }
			if ( '477' === $n3 || '479' === $n3 ) { return array( 'DV', -$s, $dep ); }
			return $deb ? array( 'BJ', $m, $dep ) : array( 'DM', $m, $dep );
		}
		if ( '48' === $n2 ) { return $deb ? array( 'BA', $m, $dep ) : array( 'DH', $m, $dep ); }
		/*
		 * Dépréciations des comptes de tiers : elles réduisent le poste qu'elles
		 * corrigent, et non « Autres créances » en bloc. Le 499 n'est pas une
		 * dépréciation mais un RISQUE PROVISIONNÉ : il appartient au passif
		 * circulant (DN), ligne qui n'était jamais alimentée.
		 */
		if ( '49' === $n2 ) {
			if ( '499' === $n3 ) { return array( 'DN', -$s, $dep ); }
			if ( '491' === $n3 ) { return array( 'BI', $s, $dep ); }
			return array( 'BJ', $s, $dep );
		}

		// classe 5
		if ( '50' === $n2 ) { return array( 'BQ', $s, $dep ); }
		if ( '51' === $n2 ) { return array( 'BR', $s, $dep ); }
		if ( '57' === $n2 ) { return array( 'BS', $s, $dep ); }
		if ( in_array( $n2, array( '52', '53', '54' ), true ) ) {
			return $deb ? array( 'BS', $m, $dep ) : array( 'DR', $m, $dep );
		}
		if ( '56' === $n2 ) {
			if ( $deb ) { return array( 'BS', $m, $dep ); }
			if ( '565' === $n3 || '564' === $n3 ) { return array( 'DQ', $m, $dep ); }
			return array( 'DR', $m, $dep );
		}
		if ( '58' === $n2 ) { return $deb ? array( 'BS', $m, $dep ) : array( 'DR', $m, $dep ); }
		if ( '59' === $n2 ) {
			if ( '599' === $n3 ) { return array( 'DN', -$s, $dep ); }
			if ( '590' === $n3 ) { return array( 'BQ', $s, $dep ); }
			if ( '591' === $n3 ) { return array( 'BR', $s, $dep ); }
			return array( 'BS', $s, $dep );
		}
		return $deb ? array( 'BJ', $m, $dep ) : array( 'DM', $m, $dep );
	}

	/**
	 * Bilan Système Normal (présentation officielle DGI) avec colonnes BRUT / AMORT-DEPREC / NET
	 * pour l'exercice N et NET pour N-1. Codes AD…BZ (actif) et CA…DZ (passif).
	 */
	public static function bilanSN( $annee ) {
		return self::memo( 'bilanSN', array( $annee ), array( __CLASS__, 'bilanSNCalcul' ) );
	}

	protected static function bilanSNCalcul( $annee ) {
		$annee = (int) $annee; $n1 = $annee - 1;
		$pN = array( self::bornesEx( $annee )[0], self::bornesEx( $annee )[1] );
		$pP = array( self::bornesEx( $n1 )[0], self::bornesEx( $n1 )[1] );

		/*
		 * LES LIGNES D'IMMOBILISATIONS NE SONT PLUS DES LISTES DE PRÉFIXES (1.564.0).
		 *
		 * Chaque ligne portait sa propre liste de comptes bruts et de comptes
		 * d'amortissement. Trente-cinq comptes imputables du plan de base n'y
		 * figuraient nulle part — immobilisations en cours (239x, 249x),
		 * dépréciations 291800, 2934 à 2939 — et huit y figuraient deux fois.
		 * Ce qui manquait disparaissait de la liasse ; ce qui figurait deux
		 * fois était déduit deux fois.
		 *
		 * On ne tient plus que les LIBELLÉS. L'affectation d'un compte à une
		 * ligne se déduit de son numéro (voir ligneClasse2), et tous les
		 * comptes mouvementés de la classe 2 sont parcourus : aucun ne peut
		 * plus être oublié, y compris ceux qu'un pack métier ouvrira demain.
		 */
		$immo = array(
			'AE' => array( 'Frais de développement et de prospection', '3' ),
			'AF' => array( 'Brevets, licences, logiciels et droits similaires', '3' ),
			'AG' => array( 'Fonds commercial et droit au bail', '3' ),
			'AH' => array( 'Autres immobilisations incorporelles', '3' ),
			'AJ' => array( 'Terrains', '3' ),
			'AK' => array( 'Bâtiments', '3' ),
			'AL' => array( 'Aménagements, agencements et installations', '3' ),
			'AM' => array( 'Matériel, mobilier et actifs biologiques', '3' ),
			'AN' => array( 'Matériel de transport', '3' ),
			'AP' => array( 'Avances et acomptes versés sur immobilisations', '3' ),
			'AR' => array( 'Titres de participation', '4' ),
			'AS' => array( 'Autres immobilisations financières', '4' ),
		);
		$nonVentiles = array();
		$calcImmo = function ( $per ) use ( $immo, &$nonVentiles ) {
			$r = array();
			foreach ( array_keys( $immo ) as $code ) { $r[ $code ] = array( 'brut' => 0.0, 'amort' => 0.0, 'net' => 0.0 ); }
			foreach ( self::soldesClasse( '2', $per[0], $per[1] ) as $numero => $solde ) {
				$code = self::ligneClasse2( $numero );
				if ( null === $code ) {
					$code = 'AH';
					$nonVentiles[ $numero ] = $solde;
				}
				if ( self::estContraActif( $numero ) ) { $r[ $code ]['amort'] += -$solde; }
				else { $r[ $code ]['brut'] += $solde; }
			}
			foreach ( $r as $code => $v ) { $r[ $code ]['net'] = $v['brut'] - $v['amort']; }
			return $r;
		};
		$iN = $calcImmo( $pN ); $iP = $calcImmo( $pP );

		// Comptes circulants & trésorerie (classes 3,4,5) routés par compte (débit→actif, crédit→passif).
		/*
		 * Le routage compte par compte vit désormais dans posteClasse345(),
		 * hors de cette fermeture, pour que les notes annexes s'appuient sur
		 * exactement la même règle que le bilan qu'elles détaillent.
		 */
		$route = function ( $per ) {
			$codes = array( 'BA', 'BB', 'BH', 'BI', 'BJ', 'BQ', 'BR', 'BS', 'BU', 'DH', 'DI', 'DJ', 'DK', 'DM', 'DN', 'DQ', 'DR', 'DV' );
			$buckets = array_fill_keys( $codes, 0.0 );
			/*
			 * LE BILAN OFFICIEL VEUT LE BRUT ET LES DÉPRÉCIATIONS SUR TOUT
			 * L'ACTIF, pas seulement sur les immobilisations : le modèle DGI
			 * réclame les colonnes BRUT et « AMORT et DEPREC. » jusqu'à la
			 * ligne BZ. On tient donc les dépréciations de stocks (39), de
			 * créances (49) et de titres (59) à part, en plus du net.
			 */
			$dep = array_fill_keys( $codes, 0.0 );
			foreach ( self::soldesClasses( array( 3, 4, 5 ), $per[0], $per[1] ) as $num => $solde ) {
				list( $code, $val, $estDep ) = self::posteClasse345( $num, $solde );
				$buckets[ $code ] += $val;
				if ( $estDep ) { $dep[ $code ] += -$val; }
			}
			$buckets['_dep'] = $dep;
			return $buckets;
		};
		$cN = $route( $pN ); $cP = $route( $pP );

		/*
		 * Capitaux propres & dettes financières (classe 1), crédit positif.
		 *
		 * Ici aussi, les listes de préfixes ne tenaient pas leur promesse :
		 * ni les comptes 13 (résultat) ni les comptes 18 (dettes liées à des
		 * participations, comptes de liaison et de succursales) n'étaient
		 * réclamés par une ligne. Un simple compte courant de groupe faisait
		 * disparaître 2 000 000 F du passif ; après clôture, c'est le résultat
		 * entier qui manquait. On parcourt donc TOUS les comptes de la classe,
		 * et celui qu'aucune ligne ne réclame atterrit au report à nouveau —
		 * en étant signalé, jamais perdu.
		 */
		$capDef = array(
			'CA' => array( 'Capital', '13' ),
			'CB' => array( 'Apporteurs capital non appelé (-)', '13' ),
			'CD' => array( 'Primes liées au capital social', '14' ),
			'CE' => array( 'Écarts de réévaluation', '3e' ),
			'CF' => array( 'Réserves indisponibles', '14' ),
			'CG' => array( 'Réserves libres', '14' ),
			'CH' => array( 'Report à nouveau (+ ou -)', '14' ),
			'CL' => array( 'Subventions d\'investissement', '15' ),
			'CM' => array( 'Provisions réglementées', '15' ),
		);
		$detDef = array(
			'DA' => array( 'Emprunts et dettes financières diverses', '16' ),
			'DB' => array( 'Dettes de location-acquisition', '16' ),
			'DC' => array( 'Provisions pour risques et charges', '16' ),
		);
		$ventilerCl1 = function ( $per ) use ( $capDef, $detDef, &$nonVentiles ) {
			$b = array_fill_keys( array_merge( array_keys( $capDef ), array_keys( $detDef ), array( 'CJ' ) ), 0.0 );
			foreach ( self::soldesClasse( '1', $per[0], $per[1] ) as $numero => $solde ) {
				$code = self::ligneClasse1( $numero );
				if ( null === $code ) {
					$code = 'CH';
					$nonVentiles[ $numero ] = $solde;
				}
				/*
				 * CJ (résultat de l'exercice) est calculé par resultatNet() :
				 * l'additionner ici le compterait deux fois. Mais resultatNet()
				 * écarte la part REPORTÉE par les à-nouveaux — un résultat
				 * antérieur non encore affecté — et cette part-là doit tout de
				 * même figurer au passif, sous le report à nouveau. Sans quoi
				 * elle disparaîtrait du bilan dès le deuxième exercice.
				 */
				if ( 'CJ' === $code ) { continue; }
				$b[ $code ] += -$solde; // un passif se lit au crédit
			}
			// Résultat antérieur reporté par les à-nouveaux : au report à nouveau.
			$b['CH'] += -self::netReporte( array( '131', '139' ), $per[0], $per[1] );
			return $b;
		};
		$vN = $ventilerCl1( $pN ); $vP = $ventilerCl1( $pP );
		$capN = array(); $capP = array(); $detN = array(); $detP = array();
		foreach ( $capDef as $k => $d ) { $capN[ $k ] = $vN[ $k ]; $capP[ $k ] = $vP[ $k ]; }
		foreach ( $detDef as $k => $d ) { $detN[ $k ] = $vN[ $k ]; $detP[ $k ] = $vP[ $k ]; }
		$resN = self::resultatNet( $pN[0], $pN[1] ); $resP = self::resultatNet( $pP[0], $pP[1] );

		// Construction des lignes ACTIF.
		$A = array();
		$pushA = function ( $code, $lib, $note, $vN, $vP, $type = 'detail', $brut = null, $amort = null ) use ( &$A ) {
			$A[] = array( 'code' => $code, 'libelle' => $lib, 'note' => $note, 'type' => $type,
				'brut' => $brut, 'amort' => $amort, 'net' => $vN, 'n1' => $vP );
		};
		$sumImmo = function ( $codes, $iX, $field ) { $t = 0; foreach ( $codes as $c ) { $t += $iX[ $c ][ $field ]; } return $t; };
		// Incorporelles (AD = AE..AH)
		$pushA( 'AD', 'IMMOBILISATIONS INCORPORELLES', '3', $sumImmo( array( 'AE', 'AF', 'AG', 'AH' ), $iN, 'net' ), $sumImmo( array( 'AE', 'AF', 'AG', 'AH' ), $iP, 'net' ), 'sub', $sumImmo( array( 'AE', 'AF', 'AG', 'AH' ), $iN, 'brut' ), $sumImmo( array( 'AE', 'AF', 'AG', 'AH' ), $iN, 'amort' ) );
		foreach ( array( 'AE', 'AF', 'AG', 'AH' ) as $c ) { $pushA( $c, $immo[ $c ][0], $immo[ $c ][1], $iN[ $c ]['net'], $iP[ $c ]['net'], 'detail', $iN[ $c ]['brut'], $iN[ $c ]['amort'] ); }
		// Corporelles (AI = AJ..AN)
		$pushA( 'AI', 'IMMOBILISATIONS CORPORELLES', '3', $sumImmo( array( 'AJ', 'AK', 'AL', 'AM', 'AN' ), $iN, 'net' ), $sumImmo( array( 'AJ', 'AK', 'AL', 'AM', 'AN' ), $iP, 'net' ), 'sub', $sumImmo( array( 'AJ', 'AK', 'AL', 'AM', 'AN' ), $iN, 'brut' ), $sumImmo( array( 'AJ', 'AK', 'AL', 'AM', 'AN' ), $iN, 'amort' ) );
		foreach ( array( 'AJ', 'AK', 'AL', 'AM', 'AN' ) as $c ) { $pushA( $c, $immo[ $c ][0], $immo[ $c ][1], $iN[ $c ]['net'], $iP[ $c ]['net'], 'detail', $iN[ $c ]['brut'], $iN[ $c ]['amort'] ); }
		$pushA( 'AP', $immo['AP'][0], '3', $iN['AP']['net'], $iP['AP']['net'], 'detail', $iN['AP']['brut'], $iN['AP']['amort'] );
		// Immo financières (AQ = AR+AS)
		$pushA( 'AQ', 'IMMOBILISATIONS FINANCIÈRES', '4', $sumImmo( array( 'AR', 'AS' ), $iN, 'net' ), $sumImmo( array( 'AR', 'AS' ), $iP, 'net' ), 'sub', $sumImmo( array( 'AR', 'AS' ), $iN, 'brut' ), $sumImmo( array( 'AR', 'AS' ), $iN, 'amort' ) );
		foreach ( array( 'AR', 'AS' ) as $c ) { $pushA( $c, $immo[ $c ][0], $immo[ $c ][1], $iN[ $c ]['net'], $iP[ $c ]['net'], 'detail', $iN[ $c ]['brut'], $iN[ $c ]['amort'] ); }
		$totImmoN = $sumImmo( array( 'AE', 'AF', 'AG', 'AH', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AP', 'AR', 'AS' ), $iN, 'net' );
		$totImmoP = $sumImmo( array( 'AE', 'AF', 'AG', 'AH', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AP', 'AR', 'AS' ), $iP, 'net' );
		$tousImmo = array( 'AE', 'AF', 'AG', 'AH', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AP', 'AR', 'AS' );
		$brutImmoN = $sumImmo( $tousImmo, $iN, 'brut' );
		$depImmoN  = $sumImmo( $tousImmo, $iN, 'amort' );
		$pushA( 'AZ', 'TOTAL ACTIF IMMOBILISÉ', '', $totImmoN, $totImmoP, 'total', $brutImmoN, $depImmoN );
		// Brut et dépréciations de l'actif circulant, exigés par le modèle.
		$dN = $cN['_dep']; $dP = $cP['_dep'];
		$dep = function ( $codes ) use ( $dN ) { $t = 0.0; foreach ( (array) $codes as $c ) { $t += $dN[ $c ]; } return $t; };
		$pcirc = function ( $code, $libelle, $note, $codes, $type = 'detail' ) use ( $pushA, $cN, $cP, $dN ) {
			$codes = (array) $codes;
			$n = 0.0; $p = 0.0; $d = 0.0;
			foreach ( $codes as $c ) { $n += $cN[ $c ]; $p += $cP[ $c ]; $d += $dN[ $c ]; }
			$pushA( $code, $libelle, $note, $n, $p, $type, $n + $d, $d );
		};
		$pcirc( 'BA', 'ACTIF CIRCULANT HAO', '5', 'BA' );
		$pcirc( 'BB', 'STOCKS ET ENCOURS', '6', 'BB' );
		$pcirc( 'BG', 'CRÉANCES ET EMPLOIS ASSIMILÉS', '', array( 'BH', 'BI', 'BJ' ), 'sub' );
		$pcirc( 'BH', 'Fournisseurs, avances versées', '17', 'BH' );
		$pcirc( 'BI', 'Clients', '7', 'BI' );
		$pcirc( 'BJ', 'Autres créances', '8', 'BJ' );
		$totCircN = $cN['BA'] + $cN['BB'] + $cN['BH'] + $cN['BI'] + $cN['BJ'];
		$totCircP = $cP['BA'] + $cP['BB'] + $cP['BH'] + $cP['BI'] + $cP['BJ'];
		$pcirc( 'BK', 'TOTAL ACTIF CIRCULANT', '', array( 'BA', 'BB', 'BH', 'BI', 'BJ' ), 'total' );
		$pcirc( 'BQ', 'Titres de placement', '9', 'BQ' );
		$pcirc( 'BR', 'Valeurs à encaisser', '10', 'BR' );
		$pcirc( 'BS', 'Banques, chèques postaux, caisse et assimilés', '11', 'BS' );
		$totTresAN = $cN['BQ'] + $cN['BR'] + $cN['BS']; $totTresAP = $cP['BQ'] + $cP['BR'] + $cP['BS'];
		$pcirc( 'BT', 'TOTAL TRÉSORERIE-ACTIF', '', array( 'BQ', 'BR', 'BS' ), 'total' );
		$pcirc( 'BU', 'Écart de conversion-Actif', '12', 'BU' );
		$totActN = $totImmoN + $totCircN + $totTresAN + $cN['BU'];
		$totActP = $totImmoP + $totCircP + $totTresAP + $cP['BU'];
		$depTot = $depImmoN + $dep( array( 'BA', 'BB', 'BH', 'BI', 'BJ', 'BQ', 'BR', 'BS', 'BU' ) );
		$pushA( 'BZ', 'TOTAL GÉNÉRAL', '', $totActN, $totActP, 'grand', $totActN + $depTot, $depTot );

		// Construction des lignes PASSIF.
		$P = array();
		$pushP = function ( $code, $lib, $note, $vN, $vP, $type = 'detail' ) use ( &$P ) {
			$P[] = array( 'code' => $code, 'libelle' => $lib, 'note' => $note, 'type' => $type, 'net' => $vN, 'n1' => $vP );
		};
		foreach ( array( 'CA', 'CB', 'CD', 'CE', 'CF', 'CG', 'CH' ) as $k ) { $pushP( $k, $capDef[ $k ][0], $capDef[ $k ][1], $capN[ $k ], $capP[ $k ] ); }
		$pushP( 'CJ', 'Résultat net de l\'exercice (bénéfice + ou perte -)', '', $resN, $resP );
		foreach ( array( 'CL', 'CM' ) as $k ) { $pushP( $k, $capDef[ $k ][0], $capDef[ $k ][1], $capN[ $k ], $capP[ $k ] ); }
		$totCpN = array_sum( $capN ) + $resN; $totCpP = array_sum( $capP ) + $resP;
		$pushP( 'CP', 'TOTAL CAPITAUX PROPRES ET RESSOURCES ASSIMILÉES', '', $totCpN, $totCpP, 'total' );
		foreach ( array( 'DA', 'DB', 'DC' ) as $k ) { $pushP( $k, $detDef[ $k ][0], $detDef[ $k ][1], $detN[ $k ], $detP[ $k ] ); }
		$totDetN = array_sum( $detN ); $totDetP = array_sum( $detP );
		$pushP( 'DD', 'TOTAL DETTES FINANCIÈRES ET RESSOURCES ASSIMILÉES', '', $totDetN, $totDetP, 'total' );
		$pushP( 'DF', 'TOTAL RESSOURCES STABLES', '', $totCpN + $totDetN, $totCpP + $totDetP, 'total' );
		$pushP( 'DH', 'Dettes circulantes HAO', '5', $cN['DH'], $cP['DH'] );
		$pushP( 'DI', 'Clients, avances reçues', '7', $cN['DI'], $cP['DI'] );
		$pushP( 'DJ', 'Fournisseurs d\'exploitation', '17', $cN['DJ'], $cP['DJ'] );
		$pushP( 'DK', 'Dettes fiscales et sociales', '18', $cN['DK'], $cP['DK'] );
		$pushP( 'DM', 'Autres dettes', '19', $cN['DM'], $cP['DM'] );
		$pushP( 'DN', 'Provisions pour risques et charges à court terme', '19', $cN['DN'], $cP['DN'] );
		$totPcN = $cN['DH'] + $cN['DI'] + $cN['DJ'] + $cN['DK'] + $cN['DM'] + $cN['DN'];
		$totPcP = $cP['DH'] + $cP['DI'] + $cP['DJ'] + $cP['DK'] + $cP['DM'] + $cP['DN'];
		$pushP( 'DP', 'TOTAL PASSIF CIRCULANT', '', $totPcN, $totPcP, 'total' );
		$pushP( 'DQ', 'Banques, crédits d\'escompte', '20', $cN['DQ'], $cP['DQ'] );
		$pushP( 'DR', 'Banques, établissements financiers et crédits de trésorerie', '20', $cN['DR'], $cP['DR'] );
		$totTpN = $cN['DQ'] + $cN['DR']; $totTpP = $cP['DQ'] + $cP['DR'];
		$pushP( 'DT', 'TOTAL TRÉSORERIE-PASSIF', '', $totTpN, $totTpP, 'total' );
		$pushP( 'DV', 'Écart de conversion-Passif', '12', $cN['DV'], $cP['DV'] );
		$totPasN = $totCpN + $totDetN + $totPcN + $totTpN + $cN['DV'];
		$totPasP = $totCpP + $totDetP + $totPcP + $totTpP + $cP['DV'];
		$pushP( 'DZ', 'TOTAL GÉNÉRAL', '', $totPasN, $totPasP, 'grand' );

		return array(
			'annee' => $annee, 'annee_n1' => $n1, 'actif' => $A, 'passif' => $P,
			'total_actif' => array( 'n' => $totActN, 'n1' => $totActP ),
			'total_passif' => array( 'n' => $totPasN, 'n1' => $totPasP ),
			'equilibre' => abs( $totActN - $totPasN ) < 1,
			// Comptes qu'aucune ligne officielle ne réclamait : rangés dans la
			// ligne de repli, mais nommés — pour qu'on puisse les rattacher.
			'non_ventiles' => $nonVentiles,
		);
	}


	/** Poste du compte de résultat SMT pour un compte de gestion, ou null. */
	protected static function ligneResultatSmt( $numero ) {
		$numero = (string) $numero;
		$decl = self::ligneDeclaree( $numero, 'smt' );
		if ( null !== $decl ) { return $decl; }
		foreach ( self::postesResultatSmt() as $code => $prefs ) {
			foreach ( $prefs as $pref ) {
				if ( 0 === strpos( $numero, $pref ) ) { return $code; }
			}
		}
		// Repli par classe (1.853.0) : un compte inconnu reste dans le total.
		$c1 = substr( $numero, 0, 1 );
		if ( '7' === $c1 ) { return 'KB'; }
		if ( '6' === $c1 || '8' === $c1 ) { return 'JF'; }
		return null;
	}

	protected static function postesResultat() {
		return array(
			'TA' => array( '701' ), 'TB' => array( '702' ), 'TC' => array( '704', '705', '706' ),
			'TD' => array( '703', '707' ),
			'RA' => array( '601' ), 'RB' => array( '6031' ), 'RC' => array( '602' ), 'RD' => array( '6032' ),
			'RF' => array( '6033' ), 'RE' => array( '604', '605', '608' ),
			'TI' => array( '781', '782' ), 'TM' => array( '787' ),
			'TJ' => array( '791', '798', '799' ), 'TL' => array( '797' ),
			'RL' => array( '681', '691' ), 'RN' => array( '687', '697' ),
			'RS' => array( '891', '89' ),
			'TE' => array( '73' ), 'TF' => array( '72' ), 'TG' => array( '71' ), 'TH' => array( '75' ),
			'RG' => array( '61' ), 'RH' => array( '62', '63' ), 'RI' => array( '64' ), 'RJ' => array( '65' ),
			'RK' => array( '66' ), 'TK' => array( '77' ), 'RM' => array( '67' ),
			'TN' => array( '82' ), 'TO' => array( '84', '86', '88' ),
			'RO' => array( '81' ), 'RP' => array( '83', '85' ), 'RQ' => array( '87' ),
		);
	}

	/**
	 * Lignes de REPLI du compte de résultat SN, par préfixe (1.853.0).
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * LES COMPTES DES PACKS MÉTIERS SORTAIENT DU RÉSULTAT NET
	 *
	 * postesResultat() nomme les comptes du plan de base. Le pack Royalties
	 * ouvre pourtant 682000, 708000, 708100 et 709000 ; le pack ONG 689500 et
	 * 789500 ; le plan SYCEBNL 792500 et 796000. Aucun n'était réclamé : leur
	 * montant manquait à XI, qui divergeait du résultat du grand livre, et
	 * controle() déclarait la liasse INCOHÉRENTE — édition refusée, clôture
	 * bloquée, pour un dossier parfaitement tenu.
	 *
	 * Le repli range chaque compte inconnu dans la ligne la plus proche de sa
	 * nature ; controle() le NOMME ensuite, pour qu'on puisse le rattacher.
	 */
	protected static function replisResultat() {
		return array(
			'60' => 'RE', '68' => 'RL', '69' => 'RL',
			'70' => 'TC', '78' => 'TI', '79' => 'TJ',
			'6'  => 'RJ', '7'  => 'TH', '8'  => 'RP',
		);
	}

	/* ── Correspondances déclarées par les Packs Métiers (1.854.0) ──────────── */

	/** Déclarations faites à l'exécution (hooks de packs tiers). */
	protected static $declares = array();
	/** Table fusionnée, mémorisée. */
	protected static $correspondances = null;

	/**
	 * Déclare la ligne de liasse de comptes de gestion — pour un pack qui
	 * préfère le faire dans son hooks.php plutôt que dans son manifeste.
	 *
	 * @param array $map numéro ou préfixe => array( 'sn' => 'TC', 'smt' => 'KA' )
	 */
	public static function declarerComptesLiasse( array $map, $source = 'hook' ) {
		foreach ( $map as $pref => $l ) {
			self::$declares[ (string) $pref ] = (array) $l + array( 'source' => $source );
		}
		self::$correspondances = null;
	}

	/**
	 * LA LIGNE DE LIASSE D'UN COMPTE DE PACK EST DÉCLARÉE, PLUS DEVINÉE (1.854.0).
	 *
	 * La 1.853.0 rangeait les comptes inconnus par un REPLI de classe : la
	 * liasse ne pouvait plus être fausse, mais « 709000 → TC » restait une
	 * déduction. Chaque source déclare désormais la ligne de ses comptes :
	 *
	 *   — les manifestes des packs (clé `liasse` de pack.php) ;
	 *   — les modules qui ouvrent des comptes (FKC_LabelComptable, Royalties) ;
	 *   — le plan SYCEBNL (FKC_PlanSycebnl) ;
	 *   — les hooks, via declarerComptesLiasse().
	 *
	 * Une déclaration n'est retenue que si la ligne existe au modèle : un
	 * code mal saisi ne doit pas sortir un compte du résultat. Les
	 * déclarations écartées sont rendues sous la clé `_rejets`.
	 *
	 * @return array préfixe => array( 'sn' => code|null, 'smt' => code|null, 'source' => … )
	 */
	public static function correspondancesDeclarees() {
		if ( null !== self::$correspondances ) { return self::$correspondances; }
		$brut = array();
		if ( class_exists( 'FKC_Packs' ) ) {
			try {
				foreach ( FKC_Packs::all() as $code => $m ) {
					foreach ( (array) ( $m['liasse'] ?? array() ) as $pref => $l ) {
						$brut[ (string) $pref ] = (array) $l + array( 'source' => 'pack ' . $code );
					}
				}
			} catch ( \Throwable $e ) {}
		}
		foreach ( array( 'FKC_LabelComptable' => 'Royalties', 'FKC_PlanSycebnl' => 'SYCEBNL' ) as $cls => $lib ) {
			if ( class_exists( $cls ) && method_exists( $cls, 'lignesLiasse' ) ) {
				try {
					foreach ( (array) call_user_func( array( $cls, 'lignesLiasse' ) ) as $pref => $l ) {
						$brut[ (string) $pref ] = (array) $l + array( 'source' => $lib );
					}
				} catch ( \Throwable $e ) {}
			}
		}
		foreach ( self::$declares as $pref => $l ) { $brut[ (string) $pref ] = $l; }

		$sn = self::postesResultat(); $smt = self::postesResultatSmt();
		$out = array(); $rejets = array();
		foreach ( $brut as $pref => $l ) {
			if ( ! preg_match( '/^[678]\d*$/', (string) $pref ) ) { $rejets[ $pref ] = 'préfixe hors classes 6, 7, 8'; continue; }
			$lsn  = isset( $l['sn'] ) && isset( $sn[ $l['sn'] ] ) ? (string) $l['sn'] : null;
			$lsmt = isset( $l['smt'] ) && isset( $smt[ $l['smt'] ] ) ? (string) $l['smt'] : null;
			if ( ! empty( $l['sn'] ) && null === $lsn )   { $rejets[ $pref ] = 'ligne SN inconnue : ' . $l['sn']; }
			if ( ! empty( $l['smt'] ) && null === $lsmt ) { $rejets[ $pref ] = 'ligne SMT inconnue : ' . $l['smt']; }
			if ( null === $lsn && null === $lsmt ) { continue; }
			$out[ (string) $pref ] = array( 'sn' => $lsn, 'smt' => $lsmt, 'source' => (string) ( $l['source'] ?? '' ) );
		}
		// Le préfixe le plus long gagne : 70810 avant 708.
		uksort( $out, function ( $a, $b ) { return strlen( (string) $b ) - strlen( (string) $a ) ?: strcmp( (string) $a, (string) $b ); } );
		$out['_rejets'] = $rejets;
		return self::$correspondances = $out;
	}

	/** Ligne déclarée pour un compte ('sn' | 'smt'), ou null. */
	protected static function ligneDeclaree( $numero, $systeme ) {
		foreach ( self::correspondancesDeclarees() as $pref => $l ) {
			if ( '_rejets' === $pref ) { continue; }
			if ( 0 === strpos( (string) $numero, (string) $pref ) && ! empty( $l[ $systeme ] ) ) { return $l[ $systeme ]; }
		}
		return null;
	}

	/** Poste du compte de résultat SN pour un compte de gestion, ou null. */
	protected static function ligneResultat( $numero, &$repli = null ) {
		$numero = (string) $numero;
		$repli  = false;
		$decl = self::ligneDeclaree( $numero, 'sn' );
		if ( null !== $decl ) { return $decl; }
		foreach ( self::postesResultat() as $code => $prefs ) {
			foreach ( $prefs as $pref ) {
				if ( 0 === strpos( $numero, $pref ) ) { return $code; }
			}
		}
		foreach ( self::replisResultat() as $pref => $code ) {
			if ( 0 === strpos( $numero, (string) $pref ) ) { $repli = true; return $code; }
		}
		return null;
	}

	/**
	 * Comptes de gestion mouvementés qu'aucune ligne officielle ne réclame et
	 * qui ont été rangés dans une ligne de repli — numéro => [ligne, solde].
	 */
	public static function gestionNonVentiles( $d1, $d2 ) {
		$out = array();
		foreach ( self::soldesClasses( array( 6, 7, 8 ), $d1, $d2 ) as $num => $solde ) {
			$code = self::ligneResultat( $num, $repli );
			if ( $repli ) { $out[ (string) $num ] = array( 'ligne' => $code, 'solde' => (float) $solde ); }
		}
		return $out;
	}

	/** Bornes de l'exercice, exposées pour les outils et les tests. */
	public static function bornesPub( $annee ) { return self::bornesEx( (int) $annee ); }

	public static function sigBruts( $d1, $d2 ) {
		return self::memo( 'sigBruts', array( $d1, $d2 ), array( __CLASS__, 'sigBrutsCalcul' ) );
	}

	protected static function sigBrutsCalcul( $d1, $d2 ) {
		// Les postes élémentaires viennent tous de ligneResultat() : la
		// cascade ci-dessous ne fait plus que les combiner. Le routage se fait
		// COMPTE PAR COMPTE, repli compris (1.853.0) : XI est donc toujours
		// le résultat du grand livre, quels que soient les comptes ouverts.
		$v = array_fill_keys( array_keys( self::postesResultat() ), 0.0 );
		foreach ( self::soldesClasses( array( 6, 7, 8 ), $d1, $d2 ) as $num => $solde ) {
			$code = self::ligneResultat( $num );
			if ( null === $code ) { continue; }
			$v[ $code ] += ( 'T' === $code[0] ) ? -$solde : $solde;
		}
		$v['XA'] = $v['TA'] - $v['RA'] - $v['RB'];
		$v['XB'] = $v['TA'] + $v['TB'] + $v['TC'] + $v['TD'];
		$v['XC'] = $v['XB'] - $v['RA'] - $v['RB'] + $v['TE'] + $v['TF'] + $v['TG'] + $v['TH'] + $v['TI'] - $v['RC'] - $v['RD'] - $v['RE'] - $v['RF'] - $v['RG'] - $v['RH'] - $v['RI'] - $v['RJ'];
		$v['XD'] = $v['XC'] - $v['RK'];
		$v['XE'] = $v['XD'] + $v['TJ'] - $v['RL'];
		$v['XF'] = $v['TK'] + $v['TL'] + $v['TM'] - $v['RM'] - $v['RN'];
		$v['XG'] = $v['XE'] + $v['XF'];
		$v['XH'] = $v['TN'] + $v['TO'] - $v['RO'] - $v['RP'];
		$v['XI'] = $v['XG'] + $v['XH'] - $v['RQ'] - $v['RS'];
		return $v;
	}

	public static function resultatSN( $annee ) {
		return self::memo( 'resultatSN', array( $annee ), array( __CLASS__, 'resultatSNCalcul' ) );
	}

	protected static function resultatSNCalcul( $annee ) {
		$annee = (int) $annee; $n1 = $annee - 1;
		// Le calcul vit désormais dans sigBruts(), partagé avec le Centre de Pilotage.
		$calc = function ( $d1, $d2 ) { return self::sigBruts( $d1, $d2 ); };
		$N = $calc( self::bornesEx( $annee )[0], self::bornesEx( $annee )[1] );
		$P = $calc( self::bornesEx( $n1 )[0], self::bornesEx( $n1 )[1] );
		// [code, libellé, signe, note, type] — type: solde = sous-total caractéristique
		$def = array(
			array( 'TA', 'Ventes de marchandises', '+', '21', 'd' ),
			array( 'RA', 'Achats de marchandises', '-', '22', 'd' ),
			array( 'RB', 'Variation de stocks de marchandises', '-/+', '6', 'd' ),
			array( 'XA', 'MARGE COMMERCIALE', '', '', 's' ),
			array( 'TB', 'Ventes de produits fabriqués', '+', '21', 'd' ),
			array( 'TC', 'Travaux, services vendus', '+', '21', 'd' ),
			array( 'TD', 'Produits accessoires', '+', '21', 'd' ),
			array( 'XB', 'CHIFFRE D\'AFFAIRES', '', '', 's' ),
			array( 'TE', 'Production stockée (ou déstockage)', '-/+', '6', 'd' ),
			array( 'TF', 'Production immobilisée', '+', '21', 'd' ),
			array( 'TG', 'Subventions d\'exploitation', '+', '21', 'd' ),
			array( 'TH', 'Autres produits', '+', '21', 'd' ),
			array( 'TI', 'Transferts de charges d\'exploitation', '+', '12', 'd' ),
			array( 'RC', 'Achats de matières premières et fournitures liées', '-', '22', 'd' ),
			array( 'RD', 'Variation de stocks de matières premières', '-/+', '6', 'd' ),
			array( 'RE', 'Autres achats', '-', '22', 'd' ),
			array( 'RF', 'Variation de stocks d\'autres approvisionnements', '-/+', '6', 'd' ),
			array( 'RG', 'Transports', '-', '23', 'd' ),
			array( 'RH', 'Services extérieurs', '-', '24', 'd' ),
			array( 'RI', 'Impôts et taxes', '-', '25', 'd' ),
			array( 'RJ', 'Autres charges', '-', '26', 'd' ),
			array( 'XC', 'VALEUR AJOUTÉE', '', '', 's' ),
			array( 'RK', 'Charges de personnel', '-', '27', 'd' ),
			array( 'XD', 'EXCÉDENT BRUT D\'EXPLOITATION', '', '', 's' ),
			array( 'TJ', 'Reprises d\'amortissements, provisions et dépréciations', '+', '28', 'd' ),
			array( 'RL', 'Dotations aux amortissements, aux provisions et dépréciations', '-', '3C&28', 'd' ),
			array( 'XE', 'RÉSULTAT D\'EXPLOITATION', '', '', 's' ),
			array( 'TK', 'Revenus financiers et assimilés', '+', '29', 'd' ),
			array( 'TL', 'Reprises de provisions et dépréciations financières', '+', '28', 'd' ),
			array( 'TM', 'Transferts de charges financières', '+', '12', 'd' ),
			array( 'RM', 'Frais financiers et charges assimilées', '-', '29', 'd' ),
			array( 'RN', 'Dotations aux provisions et aux dépréciations financières', '-', '3C&28', 'd' ),
			array( 'XF', 'RÉSULTAT FINANCIER', '', '', 's' ),
			array( 'XG', 'RÉSULTAT DES ACTIVITÉS ORDINAIRES', '', '', 's' ),
			array( 'TN', 'Produits des cessions d\'immobilisations', '+', '3D', 'd' ),
			array( 'TO', 'Autres produits HAO', '+', '30', 'd' ),
			array( 'RO', 'Valeurs comptables des cessions d\'immobilisations', '-', '3D', 'd' ),
			array( 'RP', 'Autres charges HAO', '-', '30', 'd' ),
			array( 'XH', 'RÉSULTAT HORS ACTIVITÉS ORDINAIRES', '', '', 's' ),
			array( 'RQ', 'Participation des travailleurs', '-', '30', 'd' ),
			array( 'RS', 'Impôts sur le résultat', '-', '37', 'd' ),
			array( 'XI', 'RÉSULTAT NET', '', '', 'g' ),
		);
		$lignes = array();
		foreach ( $def as $d ) {
			$lignes[] = array( 'code' => $d[0], 'libelle' => $d[1], 'signe' => $d[2], 'note' => $d[3], 'type' => $d[4], 'n' => $N[ $d[0] ], 'n1' => $P[ $d[0] ] );
		}
		return array( 'annee' => $annee, 'annee_n1' => $n1, 'lignes' => $lignes );
	}

	/**
	 * Bandeau d'identification de la liasse — un seul endroit pour deux écrans.
	 *
	 * DEUX DÉFAUTS RÉELS RÉPARÉS ICI (1.564.0).
	 *
	 * 1. « Exercice clos le 31/12/AAAA » et « durée : 12 mois » étaient écrits
	 *    en dur, dans les deux contrôleurs. La 1.544.0 avait pourtant appris à
	 *    toute la comptabilité qu'un exercice ne commence pas forcément le
	 *    1er janvier : les CALCULS suivaient le bon exercice, la PRÉSENTATION
	 *    continuait d'annoncer le 31 décembre. Un dossier clôturant au 30 juin
	 *    déposait une liasse juste, datée du mauvais jour.
	 *
	 * 2. Le contrôleur DGI repliait la raison sociale sur une valeur en dur —
	 *    le nom de l'éditeur. Tout dossier n'ayant pas encore renseigné sa
	 *    fiche société imprimait donc la liasse d'une AUTRE entreprise. Une
	 *    zone d'identification vide se signale ; elle ne s'invente pas.
	 */
	public static function entete( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		$soc = class_exists( 'FKC_Tenant' ) ? FKC_Tenant::current() : array();
		$raison = '';
		if ( class_exists( 'FKC_License' ) ) { $raison = (string) FKC_License::param( 'fne_company_name', '' ); }
		if ( '' === $raison ) { $raison = (string) ( $soc['raison_sociale'] ?? '' ); }
		$ncc = '';
		if ( class_exists( 'FKC_License' ) ) { $ncc = (string) FKC_License::param( 'fne_ncc', '' ); }
		if ( '' === $ncc ) { $ncc = (string) ( $soc['ncc'] ?? '' ); }

		/*
		 * LE NUMÉRO DE TÉLÉDÉCLARANT MANQUAIT (1.568.0).
		 *
		 * Chaque feuillet du classeur DGI le réclame, à côté du NCC : sans lui,
		 * la liasse n'est pas rattachable au compte qui la dépose. Il se règle
		 * dans les paramètres de la société et voyage désormais avec l'en-tête,
		 * à l'écran comme à l'impression et dans les exports.
		 */
		$ntd = '';
		if ( class_exists( 'FKC_License' ) ) { $ntd = (string) FKC_License::param( 'dgi_ntd', '' ); }

		return array(
			'societe' => '' !== trim( $raison ) ? $raison : '—',
			'ncc'     => $ncc,
			'ntd'     => $ntd,
			'adresse' => (string) ( $soc['adresse'] ?? '' ),
			'sigle'   => (string) ( $soc['sigle'] ?? '' ),
			'du'      => $d1,
			'au'      => $d2,
			'ouvert'  => date( 'd/m/Y', strtotime( $d1 ) ),
			'cloture' => date( 'd/m/Y', strtotime( $d2 ) ),
			'duree'   => self::dureeMois( $d1, $d2 ),
			'libelle' => class_exists( 'FKC_Exercice' ) ? FKC_Exercice::libelle( $annee ) : (string) $annee,
			'edite'   => date( 'd/m/Y à H:i' ),
		);
	}

	/** Durée d'un exercice en mois entamés — 12 pour une année pleine. */
	protected static function dureeMois( $d1, $d2 ) {
		$a = strtotime( (string) $d1 ); $b = strtotime( (string) $d2 );
		if ( ! $a || ! $b || $b < $a ) { return 12; }
		return (int) ( ( (int) date( 'Y', $b ) * 12 + (int) date( 'n', $b ) )
			- ( (int) date( 'Y', $a ) * 12 + (int) date( 'n', $a ) ) + 1 );
	}

	/* ═════════════════ TABLEAU DES FLUX DE TRÉSORERIE (TFT) ═════════════════ */

	/**
	 * Tableau des Flux de Trésorerie — codes officiels du modèle DGI.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * J'AVAIS INVENTÉ LES RÉFÉRENCES (corrigé en 1.568.0)
	 *
	 * La version livrée en 1.564.2 était juste au fond — les trois blocs, la
	 * fermeture par construction — mais elle portait des codes de mon cru :
	 * FB pour la variation des stocks, FE pour les acquisitions, FG et FH pour
	 * le financement. Le modèle officiel numérote autrement, et l'écart n'était
	 * pas cosmétique : le dépôt se fait champ par champ EN CITANT CES CODES.
	 * Un tableau juste sous les mauvaises références se saisit dans les
	 * mauvaises cases.
	 *
	 * Les codes ci-dessous sont relevés sur le classeur DGI : ZA, FA à FE, ZB,
	 * FF à FJ, ZC, FK à FN, ZD, FO à FQ, ZE, ZF, ZG, ZH. Le modèle demande
	 * aussi une colonne N-1, absente de la première version.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * POURQUOI IL TOMBE TOUJOURS JUSTE
	 *
	 * Le bilan s'équilibrant aux deux dates :
	 *
	 *   ΔTrésorerie = ΔCapitaux propres + ΔDettes financières
	 *               + ΔPassif circulant − ΔActif immobilisé
	 *               − ΔStocks − ΔCréances
	 *
	 * Or la variation de l'actif immobilisé NET se décompose exactement en
	 * acquisitions − valeur comptable des cessions − dotations, ces trois
	 * termes se lisant sur les MOUVEMENTS de la classe 2 (à-nouveaux exclus).
	 * En substituant, les termes se regroupent en trois blocs dont la somme est
	 * la variation de trésorerie, sans reliquat.
	 *
	 * Le découpage FF/FG/FH et FI/FJ, puis FK à FN et FO à FQ, redistribue ces
	 * totaux SANS les changer : la fermeture tient donc quel que soit le détail.
	 *
	 * @param int $annee Millésime de l'exercice.
	 * @return array
	 */
	public static function fluxTresorerie( $annee ) {
		return self::memo( 'fluxTresorerie', array( $annee ), array( __CLASS__, 'fluxTresorerieCalcul' ) );
	}

	protected static function fluxTresorerieCalcul( $annee ) {
		$annee = (int) $annee;
		$calc = function ( $an ) {
			$an = (int) $an;
			list( $d1, $d2 ) = self::bornesEx( $an );
			$b = self::bilanSN( $an );
			$L = array();
			foreach ( $b['actif'] as $l )  { $L[ $l['code'] ] = array( (float) $l['net'], (float) $l['n1'] ); }
			foreach ( $b['passif'] as $l ) { $L[ $l['code'] ] = array( (float) $l['net'], (float) $l['n1'] ); }
			$n  = function ( $c ) use ( $L ) { return isset( $L[ $c ] ) ? $L[ $c ][0] : 0.0; };
			$n1 = function ( $c ) use ( $L ) { return isset( $L[ $c ] ) ? $L[ $c ][1] : 0.0; };
			$d  = function ( $c ) use ( $n, $n1 ) { return $n( $c ) - $n1( $c ); };
			$som = function ( array $codes ) use ( $d ) { $t = 0.0; foreach ( $codes as $c ) { $t += $d( $c ); } return $t; };

			$m   = self::mouvementsImmobilisations( $an, $d1, $d2 );
			$vcn = $m['sorties_brutes'] - $m['amortissements_sortis'];
			$resultat = self::resultatNet( $d1, $d2 );

			/*
			 * Produits de cession, par nature du bien cédé (comptes 82).
			 * 821 incorporelles, 822 corporelles, 826 financières ; tout autre
			 * compte 82 rejoint FI, faute de mieux — mais il est compté.
			 */
			$cessIncorpCorp = -self::net( array( '821', '822' ), $d1, $d2 );
			$cessFin        = -self::net( array( '826' ), $d1, $d2 );
			$cessTotal      = -self::net( array( '82' ), $d1, $d2 );
			$cessIncorpCorp += ( $cessTotal - $cessIncorpCorp - $cessFin ); // reste rattaché à FI

			/*
			 * Les provisions pour risques (19) ne sont pas un mouvement de
			 * trésorerie : elles rejoignent la CAFG plutôt que le financement,
			 * où leur variation n'aurait rien à faire. Le total reste le même.
			 */
			$dProv19 = $d( 'DC' );
			$cafg = $resultat + $m['dotations'] + $dProv19 + $vcn - $cessTotal;

			$dHao      = $d( 'BA' );
			$dStocks   = $d( 'BB' );
			$dCreances = $som( array( 'BH', 'BI', 'BJ', 'BU' ) );
			$dPassifC  = $som( array( 'DH', 'DI', 'DJ', 'DK', 'DM', 'DN', 'DV' ) );

			$FA = $cafg;
			$FB = -$dHao;
			$FC = -$dStocks;
			$FD = -$dCreances;
			$FE = $dPassifC;
			$BF = $FB + $FC + $FD + $FE;   // variation du besoin de financement
			$ZB = $FA + $BF;

			$FF = -$m['acq_incorporelles'];
			$FG = -$m['acq_corporelles'];
			$FH = -$m['acq_financieres'];
			$FI = $cessIncorpCorp;
			$FJ = $cessFin;
			$ZC = $FF + $FG + $FH + $FI + $FJ;

			/*
			 * Capitaux propres. Le TOTAL est imposé par l'équilibre du bilan
			 * (variation des capitaux propres, résultat déduit) ; le détail se
			 * lit sur les mouvements. FN absorbe ce que FK, FL et FM
			 * n'expliquent pas — dans un dossier ordinaire, c'est bien la
			 * distribution de dividendes. `zd_reste` le rend visible pour qui
			 * veut vérifier.
			 */
			$mvtCp = self::mouvementsCapitaux( $an, $d1, $d2 );
			$ZD = $d( 'CP' ) - $resultat;
			$FK = $mvtCp['apports'];
			$FL = $mvtCp['subventions'];
			$FM = -$mvtCp['prelevements'];
			$FN = $ZD - $FK - $FL - $FM;

			/*
			 * Capitaux étrangers. FO = emprunts au sens du modèle (161, 162,
			 * 1661, 1662) ; FP = les autres comptes 16, 17 et 18 ; FQ = les
			 * remboursements. Le total vaut la variation des dettes
			 * financières, provisions exclues puisqu'elles sont passées en CAFG.
			 */
			$ZE = $som( array( 'DA', 'DB' ) );
			$FO = $mvtCp['emprunts'];
			$FQ = -$mvtCp['remboursements'];
			$FP = $ZE - $FO - $FQ;

			$ZF = $ZD + $ZE;
			$ZG = $ZB + $ZC + $ZF;
			$ZA = $n1( 'BT' ) - $n1( 'DT' );
			$ZH = $ZA + $ZG;
			$reel = $n( 'BT' ) - $n( 'DT' );

			$r = compact(
				'ZA', 'FA', 'FB', 'FC', 'FD', 'FE', 'ZB', 'FF', 'FG', 'FH', 'FI', 'FJ', 'ZC',
				'FK', 'FL', 'FM', 'FN', 'ZD', 'FO', 'FP', 'FQ', 'ZE', 'ZF', 'ZG', 'ZH'
			) + array(
				'reel' => $reel, 'resultat' => $resultat, 'cafg' => $cafg, 'vcn' => $vcn,
				'cessions' => $cessTotal, 'acquisitions' => $m['acquisitions'], 'dotations' => $m['dotations'],
				'zd_reste' => $FN, 'ze_reste' => $FP,
			);
			$r['2'] = $BF;
			return $r;
		};

		$N  = $calc( $annee );
		$P  = $calc( $annee - 1 );
		list( $d1, $d2 ) = self::bornesEx( $annee );

		$def = array(
			array( 'ZA', 'Trésorerie nette au ' . date( 'd/m/Y', strtotime( $d1 ) ) . ' (Trésorerie actif N-1 − Trésorerie passif N-1)', 'total', 'A' ),
			array( '',   'Flux de trésorerie provenant des activités opérationnelles', 'entete', '' ),
			array( 'FA', "Capacité d'Autofinancement Globale (CAFG)", 'detail', '' ),
			array( 'FB', "− Variation d'actif circulant HAO", 'detail', '5' ),
			array( 'FC', '− Variation des stocks', 'detail', '6' ),
			array( 'FD', '− Variation des créances', 'detail', '7' ),
			array( 'FE', '+ Variation du passif circulant', 'detail', '' ),
			// Le modèle intercale ici une ligne de sous-total sans référence
			// alphabétique ; e-impots la désigne par le code « 2 ».
			array( '2',  'Variation du BF lié aux activités opérationnelles (FB+FC+FD+FE)', 'total', '' ),
			array( 'ZB', 'Flux de trésorerie provenant des activités opérationnelles (Somme FA à FE)', 'total', 'B' ),
			array( '',   "Flux de trésorerie provenant des activités d'investissement", 'entete', '' ),
			array( 'FF', "− Décaissements liés aux acquisitions d'immobilisations incorporelles", 'detail', '3' ),
			array( 'FG', "− Décaissements liés aux acquisitions d'immobilisations corporelles", 'detail', '3' ),
			array( 'FH', "− Décaissements liés aux acquisitions d'immobilisations financières", 'detail', '4' ),
			array( 'FI', "+ Encaissements liés aux cessions d'immobilisations incorporelles et corporelles", 'detail', '3D' ),
			array( 'FJ', "+ Encaissements liés aux cessions d'immobilisations financières", 'detail', '3D' ),
			array( 'ZC', "Flux de trésorerie provenant des activités d'investissement (somme FF à FJ)", 'total', 'C' ),
			array( '',   'Flux de trésorerie provenant du financement par les capitaux propres', 'entete', '' ),
			array( 'FK', '+ Augmentations de capital par apports nouveaux', 'detail', '13' ),
			array( 'FL', "+ Subventions d'investissement reçues", 'detail', '15' ),
			array( 'FM', '− Prélèvements sur le capital', 'detail', '13' ),
			array( 'FN', '− Dividendes versés', 'detail', '' ),
			array( 'ZD', 'Flux de trésorerie provenant des capitaux propres (somme FK à FN)', 'total', 'D' ),
			array( '',   'Trésorerie provenant du financement par les capitaux étrangers', 'entete', '' ),
			array( 'FO', '+ Emprunts', 'detail', '16' ),
			array( 'FP', '+ Autres dettes financières diverses', 'detail', '16' ),
			array( 'FQ', '− Remboursements des emprunts et autres dettes financières', 'detail', '16' ),
			array( 'ZE', 'Flux de trésorerie provenant des capitaux étrangers (somme FO à FQ)', 'total', 'E' ),
			array( 'ZF', 'Flux de trésorerie provenant des activités de financement (D+E)', 'total', 'F' ),
			array( 'ZG', 'VARIATION DE LA TRÉSORERIE NETTE DE LA PÉRIODE (B+C+F)', 'grand', 'G' ),
			array( 'ZH', 'Trésorerie nette au ' . date( 'd/m/Y', strtotime( $d2 ) ) . ' (G+A)', 'grand', 'H' ),
		);

		$lignes = array();
		foreach ( $def as $x ) {
			list( $code, $libelle, $type, $note ) = $x;
			$lignes[] = array(
				'code' => $code, 'libelle' => $libelle, 'type' => $type, 'note' => $note,
				'valeur' => ( '' === $code ) ? null : round( (float) $N[ $code ], 2 ),
				'n1'     => ( '' === $code ) ? null : round( (float) $P[ $code ], 2 ),
			);
		}

		return array(
			'annee' => $annee, 'du' => $d1, 'au' => $d2, 'lignes' => $lignes,
			'ouverture' => round( $N['ZA'], 2 ), 'cloture' => round( $N['ZH'], 2 ),
			// Le TFT et le bilan doivent annoncer la MÊME trésorerie de clôture.
			// C'est ce contrôle qui rend cet état digne de confiance.
			'tresorerie_bilan' => round( $N['reel'], 2 ),
			'ecart' => round( $N['ZH'] - $N['reel'], 2 ),
			'detail' => array(
				'resultat' => round( $N['resultat'], 2 ), 'cafg' => round( $N['cafg'], 2 ),
				'acquisitions' => round( $N['acquisitions'], 2 ), 'vcn_cessions' => round( $N['vcn'], 2 ),
				'prix_cessions' => round( $N['cessions'], 2 ), 'dotations' => round( $N['dotations'], 2 ),
			),
		);
	}

	/**
	 * Mouvements des capitaux propres et des dettes financières sur l'exercice.
	 *
	 * DEUX EXCLUSIONS, ET ELLES COMPTENT.
	 *
	 * Les à-nouveaux, d'abord : ils recréditent le capital au premier jour, ce
	 * qui passerait pour une augmentation de capital de l'exercice.
	 *
	 * Les écritures PUREMENT INTERNES à la classe 1, ensuite. L'affectation du
	 * résultat vire le 131 vers les réserves et le report à nouveau : rien
	 * n'entre, rien ne sort, et pourtant on y verrait un prélèvement suivi d'un
	 * apport. Une écriture qui ne touche que des comptes de capitaux propres ne
	 * déplace pas de trésorerie — on l'écarte.
	 */
	protected static function mouvementsCapitaux( $annee, $d1, $d2 ) {
		$out = array( 'apports' => 0.0, 'subventions' => 0.0, 'prelevements' => 0.0,
			'emprunts' => 0.0, 'remboursements' => 0.0 );
		$exclu = 0;
		if ( class_exists( 'FKC_Exercice' ) ) {
			$ex = FKC_Exercice::find( (int) $annee );
			if ( $ex && ! empty( $ex['an_ecriture_id'] ) ) { $exclu = (int) $ex['an_ecriture_id']; }
			elseif ( class_exists( 'FKC_SoldeOuverture' ) && ( $idAN = FKC_SoldeOuverture::anOfficiel( (int) $annee ) ) ) { $exclu = (int) $idAN; }
		}
		try {
			$rows = FKC_DB::q(
				"SELECT c.numero, l.debit, l.credit, l.ecriture_id
				 FROM ecriture_lignes l
				 JOIN ecritures e ON e.id = l.ecriture_id
				 JOIN comptes c ON c.id = l.compte_id
				 WHERE e.date_ecriture BETWEEN ? AND ? AND c.numero LIKE '1%' AND e.id <> ?",
				array( (string) $d1, (string) $d2, $exclu )
			)->fetchAll();
			// Écritures ne touchant QUE la classe 1 : mouvements internes.
			$interne = array();
			foreach ( FKC_DB::q(
				"SELECT l.ecriture_id, SUM(CASE WHEN substr(c.numero,1,1)='1' THEN 0 ELSE 1 END) hors
				 FROM ecriture_lignes l JOIN ecritures e ON e.id = l.ecriture_id
				 JOIN comptes c ON c.id = l.compte_id
				 WHERE e.date_ecriture BETWEEN ? AND ? GROUP BY l.ecriture_id",
				array( (string) $d1, (string) $d2 )
			)->fetchAll() as $r ) {
				if ( 0 === (int) $r['hors'] ) { $interne[ (int) $r['ecriture_id'] ] = true; }
			}
		} catch ( \Throwable $e ) { return $out; }

		foreach ( $rows as $r ) {
			if ( isset( $interne[ (int) $r['ecriture_id'] ] ) ) { continue; }
			$num = (string) $r['numero']; $deb = (float) $r['debit']; $cre = (float) $r['credit'];
			$p2 = substr( $num, 0, 2 ); $p3 = substr( $num, 0, 3 ); $p4 = substr( $num, 0, 4 );
			if ( '10' === $p2 ) { $out['apports'] += $cre; $out['prelevements'] += $deb; continue; }
			if ( '14' === $p2 ) { $out['subventions'] += $cre - $deb; continue; }
			if ( in_array( $p3, array( '161', '162' ), true ) || in_array( $p4, array( '1661', '1662' ), true ) ) {
				$out['emprunts'] += $cre; $out['remboursements'] += $deb; continue;
			}
			if ( in_array( $p2, array( '16', '17', '18' ), true ) ) { $out['remboursements'] += $deb; continue; }
		}
		return $out;
	}

	/**
	 * Mouvements de la classe 2 sur l'exercice, à-nouveaux EXCLUS.
	 *
	 * L'exclusion n'est pas un détail : l'écriture d'à-nouveaux débite tout
	 * l'actif immobilisé au premier jour de l'exercice. La compter ferait
	 * passer chaque bien déjà détenu pour une acquisition de l'année, et le
	 * tableau des flux annoncerait un investissement massif là où il ne s'est
	 * rien passé.
	 */
	protected static function mouvementsImmobilisations( $annee, $d1, $d2 ) {
		$exclu = 0;
		if ( class_exists( 'FKC_Exercice' ) ) {
			$ex = FKC_Exercice::find( (int) $annee );
			if ( $ex && ! empty( $ex['an_ecriture_id'] ) ) { $exclu = (int) $ex['an_ecriture_id']; }
			elseif ( class_exists( 'FKC_SoldeOuverture' ) && ( $idAN = FKC_SoldeOuverture::anOfficiel( (int) $annee ) ) ) { $exclu = (int) $idAN; }
		}
		$out = array( 'acquisitions' => 0.0, 'sorties_brutes' => 0.0, 'dotations' => 0.0, 'amortissements_sortis' => 0.0,
			// Le modèle sépare les décaissements d'investissement selon la
			// nature du bien : incorporel (FF), corporel (FG), financier (FH).
			'acq_incorporelles' => 0.0, 'acq_corporelles' => 0.0, 'acq_financieres' => 0.0 );
		try {
			$rows = FKC_DB::q(
				'SELECT c.numero, COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) cr
				 FROM ecriture_lignes l
				 JOIN ecritures e ON e.id = l.ecriture_id
				 JOIN comptes c ON c.id = l.compte_id
				 WHERE e.date_ecriture BETWEEN ? AND ? AND c.numero LIKE ? AND e.id <> ?
				 GROUP BY c.numero',
				array( (string) $d1, (string) $d2, '2%', $exclu )
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }

		foreach ( $rows as $r ) {
			$deb = (float) $r['d']; $cre = (float) $r['cr'];
			if ( self::estContraActif( $r['numero'] ) ) {
				$out['dotations']             += $cre;
				$out['amortissements_sortis'] += $deb;
			} else {
				$out['acquisitions']   += $deb;
				$out['sorties_brutes'] += $cre;
				$p2 = substr( (string) $r['numero'], 0, 2 );
				if ( in_array( $p2, array( '20', '21' ), true ) )      { $out['acq_incorporelles'] += $deb; }
				elseif ( in_array( $p2, array( '26', '27' ), true ) )  { $out['acq_financieres'] += $deb; }
				else                                                   { $out['acq_corporelles'] += $deb; }
			}
		}
		return $out;
	}

	/* ═════════════════════════ NOTES ANNEXES ═════════════════════════ */

	/**
	 * Poste de liasse auquel chaque numéro de note se rattache.
	 *
	 * Les numéros ne sont pas inventés ici : le bilan et le compte de résultat
	 * les portaient DÉJÀ dans leur colonne « Note », depuis toujours, sans que
	 * rien n'existe derrière. Cette table ne fait que refermer le renvoi.
	 */
	protected static function planNotes() {
		return array(
			'3'  => array( 'titre' => 'Immobilisations',                              'postes' => array( 'AE', 'AF', 'AG', 'AH', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AP' ), 'forme' => 'immobilisations' ),
			'4'  => array( 'titre' => 'Immobilisations financières',                  'postes' => array( 'AR', 'AS' ), 'forme' => 'immobilisations' ),
			'5'  => array( 'titre' => 'Actif circulant et dettes circulantes HAO',    'postes' => array( 'BA', 'DH' ) ),
			'6'  => array( 'titre' => 'Stocks et encours',                            'postes' => array( 'BB' ) ),
			'7'  => array( 'titre' => 'Clients',                                      'postes' => array( 'BI', 'DI' ) ),
			'8'  => array( 'titre' => 'Autres créances',                              'postes' => array( 'BJ' ) ),
			'9'  => array( 'titre' => 'Titres de placement',                          'postes' => array( 'BQ' ) ),
			'10' => array( 'titre' => 'Valeurs à encaisser',                          'postes' => array( 'BR' ) ),
			'11' => array( 'titre' => 'Disponibilités',                               'postes' => array( 'BS' ) ),
			'12' => array( 'titre' => 'Écarts de conversion et transferts de charges', 'postes' => array( 'BU', 'DV', 'TI', 'TM' ) ),
			'13' => array( 'titre' => 'Capital',                                      'postes' => array( 'CA', 'CB' ) ),
			'14' => array( 'titre' => 'Primes, réserves et report à nouveau',         'postes' => array( 'CD', 'CF', 'CG', 'CH' ) ),
			'15' => array( 'titre' => 'Subventions d\'investissement et provisions réglementées', 'postes' => array( 'CL', 'CM' ) ),
			'16' => array( 'titre' => 'Dettes financières et ressources assimilées',  'postes' => array( 'DA', 'DB', 'DC' ) ),
			'17' => array( 'titre' => 'Fournisseurs',                                 'postes' => array( 'BH', 'DJ' ) ),
			'18' => array( 'titre' => 'Dettes fiscales et sociales',                  'postes' => array( 'DK' ) ),
			'19' => array( 'titre' => 'Autres dettes et provisions pour risques à court terme', 'postes' => array( 'DM', 'DN' ) ),
			'20' => array( 'titre' => 'Banques, crédits d\'escompte et de trésorerie', 'postes' => array( 'DQ', 'DR' ) ),
			'21' => array( 'titre' => 'Chiffre d\'affaires et autres produits',        'postes' => array( 'TA', 'TB', 'TC', 'TD', 'TE', 'TF', 'TG', 'TH' ) ),
			'22' => array( 'titre' => 'Achats',                                       'postes' => array( 'RA', 'RB', 'RC', 'RD', 'RE', 'RF' ) ),
			'23' => array( 'titre' => 'Transports',                                   'postes' => array( 'RG' ) ),
			'24' => array( 'titre' => 'Services extérieurs',                          'postes' => array( 'RH' ) ),
			'25' => array( 'titre' => 'Impôts et taxes',                              'postes' => array( 'RI' ) ),
			'26' => array( 'titre' => 'Autres charges',                               'postes' => array( 'RJ' ) ),
			'27' => array( 'titre' => 'Charges de personnel',                         'postes' => array( 'RK' ) ),
			'28' => array( 'titre' => 'Dotations et reprises d\'amortissements, provisions et dépréciations', 'postes' => array( 'RL', 'RN', 'TJ', 'TL' ) ),
			'29' => array( 'titre' => 'Charges et revenus financiers',                'postes' => array( 'TK', 'RM' ) ),
			'3D' => array( 'titre' => "Cessions d'immobilisations", 'postes' => array( 'TN', 'RO' ) ),
			'30' => array( 'titre' => 'Autres charges et produits HAO', 'postes' => array( 'TO', 'RP', 'RQ' ) ),
			'37' => array( 'titre' => 'Impôts sur le résultat', 'postes' => array( 'RS' ) ),
		);
	}

	/**
	 * Postes du Système Minimal de Trésorerie et notes qui les détaillent.
	 *
	 * LE SMT A SA PROPRE NUMÉROTATION, ET ON NE LA DEVINE PAS.
	 *
	 * Plaquer les numéros du Système Normal sur une liasse SMT serait pire
	 * qu'une absence de notes : le lecteur suivrait un renvoi vers un numéro
	 * qui ne veut rien dire dans son système. Les numéros repris ici sont ceux
	 * que le bilan SMT porte DÉJÀ dans sa colonne « Note » (3, 4, 5, 6, 8, 9).
	 * Là où la liasse SMT ne renvoie à aucun numéro, la note est identifiée
	 * par le code du poste — c'est exact, et cela n'invente rien.
	 */
	protected static function planNotesSmt() {
		return array(
			'3'  => array( 'titre' => 'Immobilisations',                       'postes' => array( 'GA' ), 'forme' => 'immobilisations' ),
			'4'  => array( 'titre' => 'Stocks',                                'postes' => array( 'GB' ) ),
			'5'  => array( 'titre' => 'Clients et débiteurs divers',           'postes' => array( 'GC' ) ),
			'6'  => array( 'titre' => 'Emprunt',                               'postes' => array( 'HC' ) ),
			'7'  => array( 'titre' => 'Détail des recettes et des dépenses',   'postes' => array( 'KA', 'KB', 'JA', 'JB', 'JC', 'JD', 'JE', 'JF', 'JG' ) ),
			'9'  => array( 'titre' => 'Fournisseurs et créditeurs divers',     'postes' => array( 'HD' ) ),
			'GD' => array( 'titre' => 'Caisse',                                'postes' => array( 'GD' ) ),
			'GF' => array( 'titre' => 'Banque (en + ou en -)',                 'postes' => array( 'GF' ) ),
			'HA' => array( 'titre' => 'Capital',                               'postes' => array( 'HA' ) ),
		);
	}

	/**
	 * Notes annexes de la liasse — le quatrième état de synthèse.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * ELLES ÉTAIENT PROMISES SANS ÊTRE SERVIES
	 *
	 * Le bilan et le compte de résultat portent depuis toujours une colonne
	 * « Note » qui renvoie aux numéros 3 à 31. Rien n'existait derrière. Un
	 * lecteur de la liasse — administration, banque, expert-comptable — suivait
	 * un renvoi vers une note absente ; et le Système Normal SYSCOHADA exige
	 * les quatre états, pas trois.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * POURQUOI ELLES NE PEUVENT PAS CONTREDIRE LA LIASSE
	 *
	 * Une note annexe n'est rien d'autre que la réponse à « quels comptes
	 * composent cette ligne ». La tentation serait d'écrire, pour chaque note,
	 * une nouvelle liste de comptes — et de retrouver, à la première
	 * divergence, exactement le défaut réparé en 1.564.0 sur le bilan :
	 * trente-cinq comptes perdus, huit comptés double.
	 *
	 * Les notes réutilisent donc EXACTEMENT le routage du bilan et du compte
	 * de résultat, compte par compte. Le total d'une note est la somme des
	 * comptes que son poste additionne : les deux ne peuvent diverger que si
	 * le routage lui-même change, et il n'y en a qu'un. L'écart est calculé et
	 * rendu quand même — un contrôle qu'on croit inutile est celui qui finit
	 * par servir.
	 *
	 * @param int $annee Millésime de l'exercice.
	 * @return array Notes indexées par numéro.
	 */
	public static function notes( $annee, $systeme = 'sn' ) {
		return self::memo( 'notes', array( $annee, $systeme ), array( __CLASS__, 'notesCalcul' ) );
	}

	protected static function notesCalcul( $annee, $systeme = 'sn' ) {
		$smt = ( 'smt' === $systeme );
		$annee = (int) $annee; $n1 = $annee - 1;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		list( $p1, $p2 ) = self::bornesEx( $n1 );

		// Attribution compte par compte, pour les deux exercices.
		$ventiler = function ( $du, $au ) use ( $smt ) {
			$out = array();
			foreach ( self::soldesClasses( array( 1, 2, 3, 4, 5 ), $du, $au ) as $num => $solde ) {
				$c1 = substr( (string) $num, 0, 1 );
				/*
				 * LA LIGNE « RÉSULTAT » N'A PAS DE NOTE, ET C'EST LÀ LE PIÈGE.
				 *
				 * Les comptes 131/139 portent deux choses : le résultat que la
				 * clôture vient de déterminer, et celui de l'exercice précédent
				 * que les à-nouveaux ont reporté faute d'affectation. Le bilan
				 * range le premier sur sa ligne de résultat — calculée, donc
				 * sans note — et le second au report à nouveau.
				 *
				 * Verser le solde ENTIER dans la note du report à nouveau la
				 * ferait diverger de son poste du montant du résultat, dès la
				 * première clôture. On ne retient donc que la part reportée,
				 * exactement comme le bilan.
				 */
				$reporte = function ( $num, $du, $au ) {
					return -self::netReporte( array( (string) $num ), $du, $au );
				};
				if ( $smt ) {
					// Le SMT a son propre routage : celui de son bilan.
					list( $cote, $code, $val ) = self::classify( $num, $solde );
					if ( 'HB' === $code ) {
						$r = $reporte( $num, $du, $au );
						if ( abs( $r ) > 0.004 ) { $out['HE'][ $num ] = $r; }
						continue;
					}
					$out[ $code ][ $num ] = $val;
					continue;
				}
				if ( '1' === $c1 ) {
					$code = self::ligneClasse1( $num );
					if ( 'CJ' === $code ) {
						$r = $reporte( $num, $du, $au );
						if ( abs( $r ) > 0.004 ) { $out['CH'][ $num ] = $r; }
						continue;
					}
					if ( null === $code ) { $code = 'CH'; }
					$out[ $code ][ $num ] = -$solde;
				} elseif ( '2' === $c1 ) {
					$code = self::ligneClasse2( $num );
					if ( null === $code ) { $code = 'AH'; }
					$out[ $code ][ $num ] = self::estContraActif( $num ) ? $solde : $solde;
				} else {
					list( $code, $val ) = self::posteClasse345( $num, $solde );
					$out[ $code ][ $num ] = $val;
				}
			}
			foreach ( self::soldesClasses( array( 6, 7, 8 ), $du, $au ) as $num => $solde ) {
				$code = $smt ? self::ligneResultatSmt( $num ) : self::ligneResultat( $num );
				if ( null === $code ) { continue; }
				$produit = $smt ? ( 'K' === $code[0] ) : ( 'T' === $code[0] );
				$out[ $code ][ $num ] = $produit ? -$solde : $solde;
			}
			if ( $smt ) {
				/*
				 * LE PASSAGE EN ENCAISSEMENTS DOIT SE VOIR DANS LA NOTE.
				 *
				 * Au SMT, les lignes KA et JA ne sont pas les comptes de gestion
				 * bruts : elles sont corrigées des variations de créances, de
				 * stocks et de dettes pour redevenir des recettes et des
				 * dépenses. Une note qui n'énumérerait que les comptes ne
				 * retomberait donc jamais sur son poste. Les corrections y
				 * figurent comme des lignes à part entière — c'est plus honnête
				 * qu'un écart inexpliqué, et cela montre d'où vient la
				 * différence entre le grand livre et la trésorerie.
				 */
				$an = FKC_Exercice::annee( $au );
				$b  = self::bilan( (int) $an );
				$dl = function ( $c ) use ( $b ) {
					foreach ( array( 'actif', 'passif' ) as $cote ) {
						if ( isset( $b[ $cote ][ $c ] ) ) { return (float) $b[ $cote ][ $c ]['n'] - (float) $b[ $cote ][ $c ]['n1']; }
					}
					return 0.0;
				};
				$corr = array(
					'KA' => array( '(VB)' => -$dl( 'GC' ) ),
					'JA' => array( '(VA)' => $dl( 'GB' ), '(VC)' => -$dl( 'HD' ) ),
				);
				foreach ( $corr as $code => $lignes ) {
					foreach ( $lignes as $cle => $v ) {
						if ( abs( $v ) > 0.004 ) { $out[ $code ][ $cle ] = $v; }
					}
				}
			}
			return $out;
		};
		$vN = $ventiler( $d1, $d2 );
		$vP = $ventiler( $p1, $p2 );

		$libelles = self::libellesComptes();
		$notes = array();
		$plan = $smt ? self::planNotesSmt() : self::planNotes();
		foreach ( $plan as $num => $def ) {
			$lignes = array(); $totN = 0.0; $totP = 0.0;
			$comptes = array();
			foreach ( $def['postes'] as $poste ) {
				foreach ( array_keys( (array) ( $vN[ $poste ] ?? array() ) ) as $c ) { $comptes[ $c ] = $poste; }
				foreach ( array_keys( (array) ( $vP[ $poste ] ?? array() ) ) as $c ) { $comptes[ $c ] = $poste; }
			}
			ksort( $comptes );
			$libCorr = array(
				'(VB)' => 'Variation des créances — passage aux encaissements',
				'(VA)' => 'Variation des stocks — passage aux décaissements',
				'(VC)' => 'Variation des dettes — passage aux décaissements',
			);
			foreach ( $comptes as $c => $poste ) {
				$a = (float) ( $vN[ $poste ][ $c ] ?? 0.0 );
				$b = (float) ( $vP[ $poste ][ $c ] ?? 0.0 );
				if ( abs( $a ) < 0.005 && abs( $b ) < 0.005 ) { continue; }
				$lignes[] = array(
					'numero' => (string) $c, 'libelle' => $libCorr[ $c ] ?? ( $libelles[ $c ] ?? '' ),
					'poste' => $poste, 'n' => round( $a, 2 ), 'n1' => round( $b, 2 ),
				);
				$totN += $a; $totP += $b;
			}
			if ( ! $lignes ) { continue; }
			$notes[ (string) $num ] = array(
				'numero' => (string) $num, 'titre' => $def['titre'],
				'postes' => $def['postes'], 'forme' => $def['forme'] ?? 'detail',
				'lignes' => $lignes, 'total' => round( $totN, 2 ), 'total_n1' => round( $totP, 2 ),
			);
		}

		/*
		 * Le total de chaque note doit être celui du poste qu'elle détaille.
		 * Les deux viennent du même routage : l'écart devrait toujours être
		 * nul. On le calcule quand même — un contrôle qu'on croit inutile est
		 * celui qui finit par servir, et il ne coûte rien.
		 */
		$ref = array();
		if ( $smt ) {
			$bil = self::bilan( $annee );
			foreach ( $bil['actif'] as $l )  { $ref[ $l['code'] ] = (float) $l['n']; }
			foreach ( $bil['passif'] as $l ) { $ref[ $l['code'] ] = (float) $l['n']; }
			// La ligne HB (résultat) est calculée, pas ventilée : elle n'a pas de note.
			$cr = self::resultat( $annee );
			foreach ( array_merge( $cr['produits'], $cr['charges'] ) as $l ) { $ref[ $l['code'] ] = (float) $l['n']; }
			$ref['JG'] = (float) $cr['jg']['n'];
			foreach ( $cr['variations'] as $v ) { $ref[ $v['code'] ] = (float) $v['n']; }
		} else {
			$bil = self::bilanSN( $annee );
			$sig = self::sigBruts( $d1, $d2 );
			foreach ( $bil['actif'] as $l )  { $ref[ $l['code'] ] = (float) $l['net']; }
			foreach ( $bil['passif'] as $l ) { $ref[ $l['code'] ] = (float) $l['net']; }
			foreach ( $sig as $c => $v )     { if ( ! isset( $ref[ $c ] ) ) { $ref[ $c ] = (float) $v; } }
		}
		$ecarts = array();
		foreach ( $notes as $num => $n ) {
			$attendu = 0.0;
			foreach ( $n['postes'] as $poste ) { $attendu += $ref[ $poste ] ?? 0.0; }
			$e = round( $n['total'] - $attendu, 2 );
			$notes[ $num ]['poste_total'] = round( $attendu, 2 );
			$notes[ $num ]['ecart'] = $e;
			if ( abs( $e ) >= 1 ) { $ecarts[ $num ] = $e; }
		}

		// Note 3 et 4 : tableau de variation des immobilisations.
		foreach ( $plan as $num => $def ) {
			if ( isset( $notes[ $num ] ) && 'immobilisations' === ( $def['forme'] ?? '' ) ) {
				$notes[ $num ]['mouvements'] = self::variationImmobilisations( $annee, $d1, $d2, $def['postes'], $smt );
			}
		}

		return array( 'annee' => $annee, 'systeme' => $smt ? 'smt' : 'sn', 'du' => $d1, 'au' => $d2, 'notes' => $notes, 'ecarts' => $ecarts );
	}

	/**
	 * Tableau de variation des immobilisations (notes 3 et 4).
	 *
	 * Une note d'immobilisations ne se contente pas d'un solde : elle montre
	 * ce qui est entré et ce qui est sorti. Les à-nouveaux sont exclus des
	 * mouvements — sinon chaque bien déjà détenu passerait pour une
	 * acquisition de l'exercice, comme au tableau des flux.
	 */
	protected static function variationImmobilisations( $annee, $d1, $d2, array $postes, $smt = false ) {
		$exclu = 0;
		if ( class_exists( 'FKC_Exercice' ) ) {
			$ex = FKC_Exercice::find( (int) $annee );
			if ( $ex && ! empty( $ex['an_ecriture_id'] ) ) { $exclu = (int) $ex['an_ecriture_id']; }
			elseif ( class_exists( 'FKC_SoldeOuverture' ) && ( $idAN = FKC_SoldeOuverture::anOfficiel( (int) $annee ) ) ) { $exclu = (int) $idAN; }
		}
		$lignes = array();
		try {
			$rows = FKC_DB::q(
				'SELECT c.numero, COALESCE(SUM(l.debit),0) d, COALESCE(SUM(l.credit),0) cr
				 FROM ecriture_lignes l JOIN ecritures e ON e.id = l.ecriture_id JOIN comptes c ON c.id = l.compte_id
				 WHERE e.date_ecriture BETWEEN ? AND ? AND c.numero LIKE ? AND e.id <> ?
				 GROUP BY c.numero', array( (string) $d1, (string) $d2, '2%', $exclu )
			)->fetchAll();
		} catch ( \Throwable $e ) { $rows = array(); }

		$mvt = array();
		foreach ( $rows as $r ) { $mvt[ (string) $r['numero'] ] = array( (float) $r['d'], (float) $r['cr'] ); }

		/*
		 * UN BIEN INTÉGRALEMENT CÉDÉ DOIT FIGURER AU TABLEAU.
		 *
		 * Ne parcourir que les comptes ayant un solde ferait disparaître le
		 * bien vendu en cours d'exercice : son solde est nul à la clôture,
		 * donc il ne serait nulle part — alors que la note d'immobilisations
		 * existe précisément pour montrer ce qui est entré et ce qui est
		 * SORTI. On réunit donc les comptes soldés et les comptes mouvementés.
		 */
		$soldesN = self::soldesClasse( '2', $d1, $d2 );
		foreach ( array_keys( $mvt ) as $num ) {
			if ( ! isset( $soldesN[ $num ] ) ) { $soldesN[ $num ] = 0.0; }
		}
		ksort( $soldesN );
		$libelles = self::libellesComptes();
		foreach ( $soldesN as $num => $solde ) {
			if ( $smt ) {
				list( $cote, $code, $val ) = self::classify( $num, $solde );
			} else {
				$code = self::ligneClasse2( $num );
				if ( null === $code ) { $code = 'AH'; }
			}
			if ( ! in_array( $code, $postes, true ) ) { continue; }
			list( $deb, $cre ) = $mvt[ (string) $num ] ?? array( 0.0, 0.0 );
			$contra = self::estContraActif( $num );
			// Ouverture = clôture − mouvements de l'exercice.
			$cloture   = $contra ? -$solde : $solde;
			$entrees   = $contra ? $cre : $deb;
			$sorties   = $contra ? $deb : $cre;
			$ouverture = $cloture - $entrees + $sorties;
			if ( abs( $ouverture ) < 0.005 && abs( $entrees ) < 0.005 && abs( $sorties ) < 0.005 && abs( $cloture ) < 0.005 ) { continue; }
			$lignes[] = array(
				'numero' => (string) $num, 'libelle' => $libelles[ $num ] ?? '',
				'poste' => $code, 'nature' => $contra ? 'amortissement' : 'brut',
				'ouverture' => round( $ouverture, 2 ), 'entrees' => round( $entrees, 2 ),
				'sorties' => round( $sorties, 2 ), 'cloture' => round( $cloture, 2 ),
			);
		}
		return $lignes;
	}

	/** Libellés du plan, indexés par numéro — un seul aller-retour en base. */
	protected static function libellesComptes() {
		static $cache = null;
		if ( null !== $cache ) { return $cache; }
		$cache = array();
		try {
			foreach ( FKC_DB::q( 'SELECT numero, libelle FROM comptes' )->fetchAll() as $r ) {
				$cache[ (string) $r['numero'] ] = (string) $r['libelle'];
			}
		} catch ( \Throwable $e ) { $cache = array(); }
		return $cache;
	}

	/* ═══════════════ NOTES DESCRIPTIVES (texte du dossier) ═══════════════ */

	/**
	 * Notes que le logiciel NE PEUT PAS calculer.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * Les notes chiffrées se déduisent du grand livre. Celles-ci, non : les
	 * règles et méthodes comptables retenues, les engagements hors bilan, les
	 * faits marquants de l'exercice et les événements survenus après la
	 * clôture ne sont écrits nulle part dans les écritures. Seul le dossier
	 * peut les rédiger — et le Système Normal les exige.
	 *
	 * `obligatoire` ne bloque rien : il fait remonter la note vide dans le
	 * contrôle, en RÉSERVE et non en incohérence. Une liasse dont l'annexe
	 * descriptive est vide n'est pas fausse, elle est incomplète — la même
	 * distinction que pour les écritures en attente.
	 */
	public static function planNotesTexte() {
		return array(
			'2'   => array( 'titre' => 'Règles et méthodes comptables', 'obligatoire' => true,
				'aide' => 'Référentiel appliqué, méthodes d\'évaluation des stocks et des immobilisations, durées d\'amortissement, changements de méthode et leur incidence.' ),
			'1'   => array( 'titre' => 'Dettes garanties par des sûretés réelles', 'obligatoire' => false,
				'aide' => 'Nature des sûretés consenties, biens grevés, montants garantis et échéances.' ),
			'27A' => array( 'titre' => 'Engagements donnés', 'obligatoire' => false,
				'aide' => 'Cautions, avals, nantissements, hypothèques et autres engagements donnés, avec leur montant.' ),
			'27B' => array( 'titre' => 'Engagements reçus', 'obligatoire' => false,
				'aide' => 'Cautions et garanties reçues, lignes de crédit confirmées non utilisées.' ),
			'34'  => array( 'titre' => 'Effectifs et masse salariale', 'obligatoire' => false,
				'aide' => 'Effectif moyen par catégorie, masse salariale de l\'exercice, comparaison avec l\'exercice précédent.' ),
			'35'  => array( 'titre' => 'Rémunération des dirigeants', 'obligatoire' => false,
				'aide' => 'Rémunérations et avantages alloués aux organes de direction et d\'administration.' ),
			/* DIFFÉRABLE (1.791.0) : par nature, les événements postérieurs à la
			   clôture ne sont connus qu'APRÈS elle. La note reste exigée au dépôt,
			   mais son absence ne rend pas la liasse provisoire : elle se
			   complète à tout moment, exercice clos ou verrouillé compris. */
			'36'  => array( 'titre' => 'Faits caractéristiques et événements postérieurs à la clôture', 'obligatoire' => true, 'differable' => true,
				'aide' => 'Opérations marquantes de l\'exercice, litiges, et tout événement survenu après la clôture susceptible d\'influer sur la lecture des comptes.' ),
		);
	}

	/**
	 * PROPOSITION DE RÉDACTION DE LA NOTE 2 — règles et méthodes comptables
	 * (1.785.0).
	 *
	 * La note est obligatoire au Système Normal et le logiciel ne peut pas
	 * l'écrire À LA PLACE du dossier : il ne connaît pas ses choix de méthode.
	 * Il connaît en revanche ce que ses propres paramètres et registres
	 * APPLIQUENT : référentiel, durée de l'exercice, mode d'amortissement et
	 * durées des fiches d'immobilisation, méthode de valorisation des stocks,
	 * traitement des devises, des dépréciations, des rattachements, régime
	 * fiscal. La proposition dit cela, et seulement cela ; ce que le dossier
	 * seul sait (changements de méthode, dérogations) reste entre crochets,
	 * à compléter. Rien n'est enregistré : le texte s'affiche dans le champ,
	 * et c'est l'enregistrement humain qui en fait la note.
	 */
	public static function proposerNote2( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		$mois = (int) round( ( strtotime( $d2 ) - strtotime( $d1 ) ) / ( 86400 * 30.44 ) );
		$p = array();
		$p[] = 'Les états financiers de l\'exercice clos le ' . date( 'd/m/Y', strtotime( $d2 ) ) . ' (' . $mois . ' mois, du '
			. date( 'd/m/Y', strtotime( $d1 ) ) . ' au ' . date( 'd/m/Y', strtotime( $d2 ) ) . ') sont établis conformément à l\'Acte uniforme OHADA '
			. 'relatif au droit comptable et à l\'information financière (AUDCIF) et au Système comptable OHADA révisé (SYSCOHADA). '
			. 'Ils sont présentés en francs CFA.';
		$p[] = 'Les conventions générales appliquées sont la continuité d\'exploitation, la permanence des méthodes, le coût historique, la prudence, '
			. 'l\'indépendance des exercices et l\'intangibilité du bilan d\'ouverture.';
		try {
			$immo = FKC_DB::q( "SELECT methode, MIN(duree_annees) dmin, MAX(duree_annees) dmax, COUNT(*) n FROM immobilisations
				WHERE statut='en_service' AND date_acquisition<=? GROUP BY methode", array( $d2 ) )->fetchAll();
			if ( $immo ) {
				$m = array();
				foreach ( $immo as $r ) {
					$lib = 'degressif' === $r['methode'] ? 'dégressif' : ( 'lineaire' === $r['methode'] ? 'linéaire' : (string) $r['methode'] );
					$m[] = $lib . ' (' . (int) $r['n'] . ' bien(s), durées de ' . rtrim( rtrim( number_format( (float) $r['dmin'], 1, ',', '' ), '0' ), ',' )
						. ' à ' . rtrim( rtrim( number_format( (float) $r['dmax'], 1, ',', '' ), '0' ), ',' ) . ' ans)';
				}
				$p[] = 'Immobilisations : inscrites au coût d\'acquisition, amorties selon le mode ' . implode( ' et ', $m ) . ' sur leur durée d\'utilité, à compter de leur mise en service.';
			}
		} catch ( \Throwable $e ) {}
		if ( class_exists( 'FKC_InvValorisation' ) ) {
			$v = strtoupper( (string) FKC_InvValorisation::methode() );
			$lib = array( 'CMP' => 'au coût moyen unitaire pondéré', 'CUMP' => 'au coût moyen unitaire pondéré', 'FIFO' => 'selon la méthode du premier entré, premier sorti', 'PEPS' => 'selon la méthode du premier entré, premier sorti' );
			$p[] = 'Stocks : évalués ' . ( $lib[ $v ] ?? 'selon la méthode ' . $v ) . ' ; une dépréciation est constatée lorsque la valeur actuelle est inférieure au coût.';
		}
		$p[] = 'Créances : inscrites à leur valeur nominale ; les créances douteuses font l\'objet d\'une dépréciation individuelle en fonction du risque de non-recouvrement.';
		try {
			if ( FKC_DB::q( "SELECT 1 FROM ecriture_lignes l JOIN ecritures e ON e.id=l.ecriture_id WHERE COALESCE(l.devise,'')<>'' AND e.date_ecriture BETWEEN ? AND ? LIMIT 1", array( $d1, $d2 ) )->fetchColumn() ) {
				$p[] = 'Opérations en devises : converties au cours du jour de l\'opération ; les créances et dettes en devises sont réévaluées au cours de clôture, les écarts portés en écarts de conversion (478/479), une provision étant constituée pour les pertes latentes.';
			}
		} catch ( \Throwable $e ) {}
		if ( class_exists( 'FKC_Regularisation' ) ) {
			try {
				if ( FKC_Regularisation::lister( $annee ) ) {
					$p[] = 'Rattachement à l\'exercice : charges à payer, factures non parvenues, produits à recevoir et charges ou produits constatés d\'avance sont comptabilisés à la clôture et extournés à l\'ouverture de l\'exercice suivant.';
				}
			} catch ( \Throwable $e ) {}
		}
		if ( class_exists( 'FKC_FiscalConfig' ) ) {
			try {
				$cfg = FKC_FiscalConfig::get();
				$ri = FKC_FiscalConfig::regimeInfo( $cfg['regime'] );
				$p[] = 'Régime fiscal : ' . (string) ( $ri['libelle'] ?? $cfg['regime'] ) . '. L\'impôt sur le résultat de l\'exercice est déterminé à partir du résultat comptable, après les réintégrations et déductions du tableau de passage.';
			} catch ( \Throwable $e ) {}
		}
		$p[] = '[À compléter : changements de méthode intervenus sur l\'exercice et leur incidence, ou mention « Aucun changement de méthode » ; dérogations éventuelles aux règles générales.]';
		return implode( "\n\n", $p );
	}

	/** Notes descriptives d'un exercice, plan complet et contenus saisis. */
	public static function notesTexte( $annee ) {
		$annee = (int) $annee;
		$saisi = array();
		try {
			foreach ( FKC_DB::q( 'SELECT cle, contenu, updated_at FROM etats_notes WHERE annee = ?', array( $annee ) )->fetchAll() as $r ) {
				$saisi[ (string) $r['cle'] ] = array( 'contenu' => (string) $r['contenu'], 'updated_at' => (string) $r['updated_at'] );
			}
		} catch ( \Throwable $e ) { $saisi = array(); }

		$out = array(); $manquantes = array(); $aCompleter = array();
		foreach ( self::planNotesTexte() as $cle => $def ) {
			$c = trim( (string) ( $saisi[ $cle ]['contenu'] ?? '' ) );
			$out[ $cle ] = array(
				'cle' => (string) $cle, 'titre' => $def['titre'], 'aide' => $def['aide'],
				'obligatoire' => (bool) $def['obligatoire'], 'contenu' => $c,
				'updated_at' => $saisi[ $cle ]['updated_at'] ?? '',
				'differable' => ! empty( $def['differable'] ),
			);
			if ( $def['obligatoire'] && '' === $c ) {
				if ( empty( $def['differable'] ) ) { $manquantes[] = (string) $cle; } else { $aCompleter[] = (string) $cle; }
			}
		}
		return array( 'annee' => $annee, 'notes' => $out, 'manquantes' => $manquantes, 'a_completer' => $aCompleter );
	}

	/** Enregistre une note descriptive. Un contenu vide efface la note. */
	public static function enregistrerNoteTexte( $annee, $cle, $contenu ) {
		$annee = (int) $annee; $cle = (string) $cle;
		if ( ! isset( self::planNotesTexte()[ $cle ] ) ) {
			return array( false, 'Note descriptive inconnue : ' . $cle . '.' );
		}
		$contenu = trim( (string) $contenu );
		try {
			if ( '' === $contenu ) {
				FKC_DB::q( 'DELETE FROM etats_notes WHERE annee = ? AND cle = ?', array( $annee, $cle ) );
				return array( true, 'Note ' . $cle . ' effacée.' );
			}
			FKC_DB::q(
				"INSERT INTO etats_notes(annee, cle, systeme, contenu, updated_at, updated_by)
				 VALUES(?,?,?,?,datetime('now','localtime'),?)
				 ON CONFLICT(annee, cle) DO UPDATE SET
					contenu = excluded.contenu,
					updated_at = excluded.updated_at,
					updated_by = excluded.updated_by",
				array( $annee, $cle, 'sn', $contenu, (int) FKC_Auth::id() )
			);
		} catch ( \Throwable $e ) {
			return array( false, 'Enregistrement impossible : ' . $e->getMessage() );
		}
		return array( true, 'Note ' . $cle . ' enregistrée.' );
	}

	/**
	 * Reprend les notes descriptives de l'exercice précédent.
	 *
	 * Les méthodes comptables changent rarement : les ressaisir chaque année
	 * est du travail perdu. Mais une note qui se recopierait TOUTE SEULE serait
	 * dangereuse — l'annexe descriptive engage le dossier, et « ce qui était
	 * vrai l'an dernier » n'est pas une affirmation que le logiciel peut faire
	 * à sa place. La reprise est donc un geste explicite, elle ne touche que
	 * les notes VIDES de l'exercice courant, et elle dit ce qu'elle a repris.
	 */
	public static function reprendreNotesTexte( $annee ) {
		$annee = (int) $annee;
		$courant = self::notesTexte( $annee )['notes'];
		$precedent = self::notesTexte( $annee - 1 )['notes'];
		$reprises = array();
		foreach ( $precedent as $cle => $n ) {
			if ( '' === $n['contenu'] ) { continue; }
			if ( '' !== ( $courant[ $cle ]['contenu'] ?? '' ) ) { continue; }
			list( $ok ) = self::enregistrerNoteTexte( $annee, $cle, $n['contenu'] );
			if ( $ok ) { $reprises[] = $cle; }
		}
		if ( ! $reprises ) {
			return array( false, 'Rien à reprendre : l\'exercice ' . ( $annee - 1 ) . ' n\'a pas de note descriptive que celui-ci n\'ait déjà.' );
		}
		return array( true, count( $reprises ) . ' note(s) reprise(s) de ' . ( $annee - 1 ) . ' : '
			. implode( ', ', $reprises ) . '. Relisez-les : elles engagent l\'exercice ' . $annee . '.' );
	}

	/* ═════════════════ EXPORT PAR CODES DE LIASSE (TÉLÉLIASSE) ═════════════════ */

	/**
	 * La liasse à plat, une ligne par CODE DE RÉFÉRENCE officiel.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * CE QUE C'EST, ET CE QUE CE N'EST PAS
	 *
	 * En Côte d'Ivoire, les états financiers se déposent par voie électronique
	 * sur le module « Téléliasse » du portail e-impots.gouv.ci, et en cas de
	 * discordance c'est la version électronique qui fait foi. Le dépôt se fait
	 * champ par champ, chaque champ portant le code de référence du modèle
	 * SYSCOHADA — AE, BI, CJ, XI, ZH…
	 *
	 * CE N'EST DONC PAS UN FICHIER D'IMPORT. Le schéma d'import du module
	 * Téléliasse n'est pas publié ; produire un fichier en le devinant
	 * donnerait un document que le portail rejette, sous un nom qui laisserait
	 * croire l'inverse. Tant que le format officiel n'est pas connu, cet
	 * export s'en tient à ce qui est vrai : la liasse à plat, rangée par code,
	 * de sorte que chaque champ du formulaire se retrouve d'un coup d'œil sans
	 * avoir à le chercher dans un PDF de dix pages.
	 *
	 * Le jour où le format est connu, tout le travail est fait : il ne restera
	 * qu'à écrire la mise en forme, les valeurs étant déjà indexées par le code
	 * qu'attend l'administration.
	 *
	 * @param int    $annee   Millésime de l'exercice.
	 * @param string $systeme 'sn' ou 'smt'.
	 * @return array
	 */
	public static function codesLiasse( $annee, $systeme = 'sn' ) {
		return self::memo( 'codesLiasse', array( $annee, $systeme ), array( __CLASS__, 'codesLiasseCalcul' ) );
	}

	protected static function codesLiasseCalcul( $annee, $systeme = 'sn' ) {
		$annee = (int) $annee;
		$smt   = ( 'smt' === $systeme );
		$e     = self::entete( $annee );
		/*
		 * L'ORDRE COMPTE AUTANT QUE LES VALEURS.
		 *
		 * La saisie sur le portail se fait feuillet par feuillet, dans l'ordre
		 * du modèle SYSCOHADA. Un export rangé autrement oblige à chercher
		 * chaque champ, et c'est là que naissent les erreurs de report : on
		 * saisit la valeur de la ligne voisine. Les lignes portent donc leur
		 * feuillet et un numéro d'ordre, et ne sont jamais retriées.
		 */
		$lignes = array(); $ordre = 0;
		$push = function ( $etat, $feuillet, $code, $libelle, $n, $n1 = null ) use ( &$lignes, &$ordre ) {
			$code = trim( (string) $code );
			if ( '' === $code ) { return; }
			$ordre++;
			$lignes[] = array(
				'etat' => $etat, 'feuillet' => $feuillet, 'ordre' => $ordre,
				'code' => $code, 'libelle' => (string) $libelle,
				'n' => round( (float) $n, 2 ), 'n1' => ( null === $n1 ) ? null : round( (float) $n1, 2 ),
			);
		};

		if ( $smt ) {
			$b = self::bilan( $annee );
			foreach ( $b['actif'] as $l )  { $push( 'BILAN-SMT', 'Bilan — Actif', $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			$push( 'BILAN-SMT', 'Bilan — Actif', 'GZ', 'TOTAL ACTIF', $b['total_actif']['n'], $b['total_actif']['n1'] );
			foreach ( $b['passif'] as $l ) { $push( 'BILAN-SMT', 'Bilan — Passif', $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			$push( 'BILAN-SMT', 'Bilan — Passif', 'HZ', 'TOTAL PASSIF', $b['total_passif']['n'], $b['total_passif']['n1'] );
			$cr = self::resultat( $annee );
			foreach ( $cr['produits'] as $l ) { $push( 'RESULTAT-SMT', 'Compte de résultat — Recettes', $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			foreach ( $cr['charges'] as $l )  { $push( 'RESULTAT-SMT', 'Compte de résultat — Dépenses', $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			$push( 'RESULTAT-SMT', 'Compte de résultat — Soldes', 'KZ', $cr['kz']['libelle'], $cr['kz']['n'], $cr['kz']['n1'] );
			foreach ( $cr['variations'] as $v ) { $push( 'RESULTAT-SMT', 'Compte de résultat — Soldes', $v['code'], $v['libelle'], $v['n'], $v['n1'] ); }
			$push( 'RESULTAT-SMT', 'Compte de résultat — Soldes', 'JG', $cr['jg']['libelle'], $cr['jg']['n'], $cr['jg']['n1'] );
			$push( 'RESULTAT-SMT', 'Compte de résultat — Soldes', 'KZC', $cr['kzc']['libelle'], $cr['kzc']['n'], $cr['kzc']['n1'] );
		} else {
			$b = self::bilanSN( $annee );
			foreach ( $b['actif'] as $l )  { $push( 'BILAN-SN', 'Bilan — Actif', $l['code'], $l['libelle'], $l['net'], $l['n1'] ); }
			foreach ( $b['passif'] as $l ) { $push( 'BILAN-SN', 'Bilan — Passif', $l['code'], $l['libelle'], $l['net'], $l['n1'] ); }
			foreach ( self::resultatSN( $annee )['lignes'] as $l ) { $push( 'RESULTAT-SN', 'Compte de résultat', $l['code'], $l['libelle'], $l['n'], $l['n1'] ); }
			foreach ( self::fluxTresorerie( $annee )['lignes'] as $l ) {
				if ( null === $l['valeur'] ) { continue; }
				$push( 'FLUX', 'Tableau des flux de trésorerie', $l['code'], $l['libelle'], $l['valeur'], $l['n1'] );
			}
		}

		// Les notes chiffrées, code de poste par code de poste.
		foreach ( self::notes( $annee, $systeme )['notes'] as $note ) {
			$f = 'Note ' . $note['numero'] . ' — ' . $note['titre'];
			foreach ( $note['lignes'] as $l ) {
				$push( 'NOTE-' . $note['numero'], $f, $l['numero'], $l['libelle'], $l['n'], $l['n1'] );
			}
		}
		// L'annexe descriptive fait partie du dépôt : les notes obligatoires
		// non rédigées doivent apparaître dans la liste des champs à saisir.
		foreach ( self::notesTexte( $annee )['notes'] as $nt ) {
			if ( '' === $nt['contenu'] && ! $nt['obligatoire'] ) { continue; }
			$ordre++;
			$lignes[] = array(
				'etat' => 'ANNEXE', 'feuillet' => 'Annexe descriptive', 'ordre' => $ordre,
				'code' => 'N' . $nt['cle'], 'libelle' => $nt['titre'],
				'n' => null, 'n1' => null, 'texte' => $nt['contenu'],
			);
		}

		$feuillets = array();
		foreach ( $lignes as $l ) {
			if ( ! isset( $feuillets[ $l['feuillet'] ] ) ) { $feuillets[ $l['feuillet'] ] = 0; }
			$feuillets[ $l['feuillet'] ]++;
		}
		return array(
			'annee' => $annee, 'systeme' => $smt ? 'smt' : 'sn', 'entete' => $e,
			'lignes' => $lignes, 'nb' => count( $lignes ),
			'feuillets' => $feuillets,
			'controle' => self::controle( $annee ),
		);
	}

	/* ═════════════════ EXPORT EDI XML POUR E-IMPOTS ═════════════════ */

	/**
	 * Lignes de chaque tableau de la liasse, dans l'ordre du modèle DGI.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * CETTE TABLE N'EST PAS DE MOI
	 *
	 * Elle est relevée sur les classeurs officiels `DGI-liasse-NO.xlsm` et
	 * `DGI-liasse-MT.xlsm`, onglet « champs fixes », qui portent le mapping
	 * complet des champs e-impots. Le code d'un champ EDI se construit par la
	 * règle :
	 *
	 *     {TYPE}_{TABLEAU}_{LIGNE}_{POSITION}     ex. NO_ACTIF_AE_1
	 *
	 * TYPE vaut NO (Système Normal) ou MT (Système Minimal de Trésorerie),
	 * POSITION désigne la colonne : au Système Normal l'actif en compte quatre
	 * (brut, amortissements, net, net N-1) et les autres tableaux deux (N,
	 * N-1) ; au Système Minimal, deux partout.
	 *
	 * Tenir la règle plutôt que les 4 289 codes évite d'embarquer un tableau
	 * qu'on ne pourrait plus vérifier ; les LIGNES, elles, ne se devinent pas
	 * et sont donc listées telles quelles.
	 */
	protected static function lignesEdi() {
		return array(
			'NO' => array(
				'ACTIF' => array(
					'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AP', 'AQ', 'AR', 'AS', 'AZ', 'BA', 'BB',
					'BG', 'BH', 'BI', 'BJ', 'BK', 'BQ', 'BR', 'BS', 'BT', 'BU', 'BZ',
				),
				'PASSIF' => array(
					'CA', 'CB', 'CD', 'CE', 'CF', 'CG', 'CH', 'CJ', 'CL', 'CM', 'CP', 'DA', 'DB', 'DC', 'DD', 'DF', 'DH', 'DI',
					'DJ', 'DK', 'DM', 'DN', 'DP', 'DQ', 'DR', 'DT', 'DV', 'DZ',
				),
				'RESULTAT' => array(
					'TA', 'RA', 'RB', 'XA', 'TB', 'TC', 'TD', 'XB', 'TE', 'TF', 'TG', 'TH', 'TI', 'RC', 'RD', 'RE', 'RF', 'RG',
					'RH', 'RI', 'RJ', 'XC', 'RK', 'XD', 'TJ', 'RL', 'XE', 'TK', 'TL', 'TM', 'RM', 'RN', 'XF', 'XG', 'TN', 'TO',
					'RO', 'RP', 'XH', 'RQ', 'RS', 'XI',
				),
				'TFT' => array(
					'ZA', 'FA', 'FB', 'FC', 'FD', 'FE', 'ZB', 'FF', 'FG', 'FH', 'FI', 'FJ', 'ZC', 'FK', 'FL', 'FM', 'FN', 'ZD',
					'FO', 'FP', 'FQ', 'ZE', 'ZF', 'ZG', 'ZH',
				),
				'CHARGES' => array(
					'6011', '6012', '6013', '6014', '6015', '6019', 'RA', '6031', 'RB', '6021', '6022', '6023', '6024', '6025',
					'6029', 'RC', '6032', 'RD', '6041', '6042', '6043', '6044', '6045', '6046', '6047', '6049', '6051', '6052',
					'6053', '6054', '6055', '6056', '6057', '6058', '6059', '6081', '6082', '6083', '6085', '6089', 'RE', '6033',
					'RF', '612', '613', '614', '616', '6181', '6182', '6183', '619', 'RG', '621', '6221', '6222', '6223', '6224',
					'6225', '6226', '6228', '6232', '6233', '6234', '6238', '6241', '6242', '6243', '6244', '6248', '6251', '6252',
					'6253', '6254', '6255', '6257', '6258', '6261', '6265', '6266', '6271', '6272', '6273', '6274', '6275', '6276',
					'6277', '6278', '6281', '6282', '6283', '6284', '6288', '6311', '6312', '6313', '6314', '6315', '6316', '6317',
					'6318', '6322', '6324', '6325', '6326', '6327', '6328', '633', '6342', '6343', '6344', '6345', '6346', '6351',
					'6358', '6371', '6372', '6381', '6382', '6383', '6384', '6385', '6388', 'RH', '6411', '6412', '6413', '6414',
					'6415', '6418', '645', '6461', '6462', '6463', '6464', '6468', '6471', '6472', '6473', '6474', '6478', '648',
					'RI', '6511', '6515', '6521', '6525', '6541', '6542', '656', '657', '6581', '6582', '6583', '6588', '6591',
					'6593', '6594', '6598', 'RJ', '6611', '6612', '6613', '6614', '6615', '6616', '6617', '6618', '6621', '6622',
					'6623', '6624', '6625', '6626', '6627', '6628', '6631', '6632', '6633', '6634', '6638', '6641', '6642', '6661',
					'6662', '6671', '6672', '6681', '6682', '6683', '6684', '6685', '6686', '6687', '6688', 'RK', '6711', '6712',
					'6713', '6714', '6721', '6722', '6723', '6728', '673', '6741', '6742', '6743', '6744', '6745', '6748', '675',
					'676', '6771', '6772', '6781', '6782', '6784', '6791', '6795', '6798', 'RM', '6812', '6813', '6911', '6913',
					'6914', 'RL', '6971', '6972', 'RN',
				),
				'NOTE3A' => array(
					'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
				),
				'NOTE3C' => array(
					'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14',
				),
				'NOTE6' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11' ),
				'NOTE9' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10' ),
				'NOTE10' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9' ),
				'NOTE11' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15' ),
				'NOTE20' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10' ),
				'NOTE7' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15' ),
				'NOTE8' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13' ),
				'NOTE17' => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14' ),
				'NOTE18' => array(
					'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18',
				),
				'NOTE19' => array(
					'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21',
				),
				'NOTE21A' => array(
					'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18',
					'19', '20', '21', '22', '23', '24', '25',
				),
				'NOTE22' => array(
					'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18',
					'19', '20', '21', '22', '23', '24', '25',
				),
			),
			'MT' => array(
				'ACTIF' => array(
					'GA', 'GB', 'GC', 'GD', 'GF', 'GZ',
				),
				'PASSIF' => array(
					'HA', 'HB', 'HC', 'HD', 'HZ',
				),
				'RESULTAT' => array(
					'KA', 'KB', 'KX', 'JA', 'JB', 'JC', 'JD', 'JE', 'JF', 'JX', 'KZ', 'VA', 'VB', 'VC', 'JG', 'KZC',
				),
				'CHARGES' => array(
					'6011', '6012', '6013', '6014', '6015', '6019', 'RA', '6031', 'RB', '6021', '6022', '6023', '6024', '6025',
					'6029', 'RC', '6032', 'RD', '6041', '6042', '6043', '6044', '6045', '6046', '6047', '6049', '6051', '6052',
					'6053', '6054', '6055', '6056', '6057', '6058', '6059', '6081', '6082', '6083', '6085', '6089', 'RE', '6033',
					'RF', '612', '613', '614', '616', '6181', '6182', '6183', '619', 'RG', '621', '6221', '6222', '6223', '6224',
					'6225', '6226', '6228', '6232', '6233', '6234', '6238', '6241', '6242', '6243', '6244', '6248', '6251', '6252',
					'6253', '6254', '6255', '6257', '6258', '6261', '6265', '6266', '6271', '6272', '6273', '6274', '6275', '6276',
					'6277', '6278', '6281', '6282', '6283', '6284', '6288', '6311', '6312', '6313', '6314', '6315', '6316', '6317',
					'6318', '6322', '6324', '6325', '6326', '6327', '6328', '633', '6342', '6343', '6344', '6345', '6346', '6351',
					'6358', '6371', '6372', '6381', '6382', '6383', '6384', '6385', '6388', 'RH', '6411', '6412', '6413', '6414',
					'6415', '6418', '645', '6461', '6462', '6463', '6464', '6468', '6471', '6472', '6473', '6474', '6478', '648',
					'RI', '6511', '6515', '6521', '6525', '6541', '6542', '656', '657', '6581', '6582', '6583', '6588', '6591',
					'6593', '6594', '6598', 'RJ', '6611', '6612', '6613', '6614', '6615', '6616', '6617', '6618', '6621', '6622',
					'6623', '6624', '6625', '6626', '6627', '6628', '6631', '6632', '6633', '6634', '6638', '6641', '6642', '6661',
					'6662', '6671', '6672', '6681', '6682', '6683', '6684', '6685', '6686', '6687', '6688', 'RK', '6711', '6712',
					'6713', '6714', '6721', '6722', '6723', '6728', '673', '6741', '6742', '6743', '6744', '6745', '6748', '675',
					'676', '6771', '6772', '6781', '6782', '6784', '6791', '6795', '6798', 'RM', '6812', '6813', '6911', '6913',
					'6914', 'RL', '6971', '6972', 'RN',
				),
			),
		);
	}

	/** Nombre de colonnes attendues par tableau, selon le modèle. */
	protected static function colonnesEdi( $type, $tableau ) {
		if ( 'NO' === $type && 'ACTIF' === $tableau ) { return 4; } // brut, amort, net, net N-1
		if ( 'CHARGES' === $tableau ) { return 4; }                 // N, N-1, variation valeur, variation %
		// Les notes annexes n'ont pas toutes le même nombre de colonnes :
		// relevé sur l'onglet « champs fixes » du classeur.
		if ( 'NOTE3A' === $tableau ) { return 7; }
		if ( 'NOTE3C' === $tableau ) { return 6; }
		if ( 'NOTE6' === $tableau )  { return 4; }
		// Notes à ventilation : le solde, le comparatif, la variation, puis
		// les trois tranches de terme. 18 et 19 ajoutent la variation en valeur.
		if ( 'NOTE18' === $tableau || 'NOTE19' === $tableau ) { return 7; }
		if ( in_array( $tableau, array( 'NOTE7', 'NOTE8', 'NOTE17' ), true ) ) { return 6; }
		if ( 0 === strpos( $tableau, 'NOTE' ) ) { return 3; }
		return 2;                                                   // N, N-1
	}

	/* ═══════════ VENTILATIONS DEMANDÉES PAR LES NOTES ANNEXES ═══════════ */

	/**
	 * Ventilation d'un poste de tiers par TERME RESTANT À COURIR.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * Les notes 7, 8, 17, 18 et 19 ne se contentent pas d'un solde : elles
	 * demandent, en regard, la part exigible à un an au plus, celle de un à
	 * deux ans, et celle au-delà. Aucun compte ne porte cette information — le
	 * terme tient à la pièce, et c'est pourquoi il vit désormais sur la LIGNE
	 * d'écriture (colonne `echeance`, cf. FKC_DB).
	 *
	 * DEUX PARTIS PRIS, ASSUMÉS ET VISIBLES.
	 *
	 * Une ligne SANS échéance compte pour « à un an au plus ». Ce n'est pas un
	 * pis-aller : une créance ou une dette d'exploitation est à moins d'un an
	 * par nature — c'est même ce qui la classe en actif ou passif circulant.
	 * Le terme long est l'exception, et c'est celle-là qu'on saisit.
	 *
	 * Le terme se mesure depuis la CLÔTURE de l'exercice, et non depuis la
	 * date d'écriture : la note dit ce qui reste à courir au 31 décembre, pas
	 * ce qui restait à courir le jour de la facture.
	 *
	 * @param array  $prefixes Comptes du poste.
	 * @param string $d1       Début de l'exercice.
	 * @param string $d2       Clôture — c'est d'elle qu'on compte.
	 * @return array array( un_an, deux_ans, plus )
	 */
	protected static function ventilationEcheance( array $prefixes, $d1, $d2 ) {
		$out = array( 0.0, 0.0, 0.0 );
		if ( ! $prefixes ) { return $out; }
		$ou = array(); $args = array( (string) $d1, (string) $d2 );
		foreach ( $prefixes as $p ) { $ou[] = 'c.numero LIKE ?'; $args[] = $p . '%'; }
		// Solde au soir de la clôture, solde d'ouverture compris (1.798.0) :
		// une créance née avant l'exercice et toujours due figure au bilan,
		// elle doit figurer dans sa ventilation.
		list( $periode, $pPer ) = self::clausePeriodeBilan( $d1, $d2 );
		try {
			$rows = FKC_DB::q(
				'SELECT l.echeance, COALESCE(SUM(l.debit - l.credit),0) s
				 FROM ecriture_lignes l
				 JOIN ecritures e ON e.id = l.ecriture_id
				 JOIN comptes c ON c.id = l.compte_id
				 WHERE ' . $periode . ' AND (' . implode( ' OR ', $ou ) . ')
				 GROUP BY l.echeance',
				array_merge( $pPer, array_slice( $args, 2 ) )
			)->fetchAll();
		} catch ( \Throwable $e ) { return $out; }

		$cloture = strtotime( (string) $d2 );
		foreach ( $rows as $r ) {
			$s = abs( (float) $r['s'] );
			if ( $s < 0.005 ) { continue; }
			$ech = trim( (string) ( $r['echeance'] ?? '' ) );
			$i = 0;
			if ( '' !== $ech ) {
				$t = strtotime( $ech );
				if ( $t ) {
					$jours = ( $t - $cloture ) / 86400;
					if ( $jours > 730 )      { $i = 2; }
					elseif ( $jours > 365 )  { $i = 1; }
				}
			}
			$out[ $i ] += $s;
		}
		return $out;
	}

	/**
	 * Ventilation d'un poste de produits ou de charges par ZONE du tiers.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * Les notes 21A et 22 séparent ventes et achats selon l'implantation du
	 * tiers : dans l'État partie, dans les autres États parties de la Région,
	 * hors Région — et à part, ce qui se traite avec le groupe.
	 *
	 * Cette information ne se lit ni dans le compte, ni dans l'écriture : elle
	 * tient à QUI est en face. Elle vit donc sur la fiche du tiers, et se
	 * rattache ici par le tiers porté par la ligne — ou, à défaut, par celui
	 * de la pièce, comme le fait déjà le grand livre auxiliaire.
	 *
	 * Une ligne dont le tiers est inconnu compte dans l'État partie : c'est le
	 * cas de l'immense majorité des opérations d'un dossier ivoirien, et la
	 * seule répartition qu'on puisse poser sans inventer. Les tiers étrangers
	 * et les sociétés du groupe se marquent sur leur fiche, une fois.
	 *
	 * @return array array( etat_partie, region, hors_region, groupe )
	 */
	protected static function ventilationZone( array $prefixes, $d1, $d2, $sens = 'client' ) {
		$out = array( 0.0, 0.0, 0.0, 0.0 );
		if ( ! $prefixes ) { return $out; }
		$ou = array(); $args = array( (string) $d1, (string) $d2 );
		foreach ( $prefixes as $p ) { $ou[] = 'c.numero LIKE ?'; $args[] = $p . '%'; }
		$table = ( 'fournisseur' === $sens ) ? 'fournisseurs' : 'clients';
		$tmap = class_exists( 'FKC_GrandLivreTiers' ) ? FKC_GrandLivreTiers::tmapPub() : '';
		if ( '' === $tmap ) { $out[0] = abs( self::net( $prefixes, $d1, $d2 ) ); return $out; }
		try {
			/*
			 * LE TIERS SE CHERCHE AU NIVEAU DE L'ÉCRITURE, PAS DE LA LIGNE.
			 *
			 * Défaut trouvé à l'audit de la 1.585.0, et que mon propre test
			 * masquait : il posait le client sur la ligne de vente, ce
			 * qu'aucun module ne fait en exploitation. Dans une écriture de
			 * facturation, le tiers est porté par la ligne 411 ou 401 — celle
			 * de la créance ou de la dette. Les lignes de produit (70x) et de
			 * charge (60x), qui sont précisément celles que ventilent les
			 * notes 21A et 22, n'en portent aucun.
			 *
			 * Chercher le tiers sur la ligne renvoyait donc toujours « aucun »,
			 * et TOUT le chiffre d'affaires retombait sur l'État partie : la
			 * ventilation existait dans le code sans jamais rien ventiler.
			 *
			 * On remonte donc à l'écriture, par trois voies successives : le
			 * tiers de la ligne s'il en a un, celui de la pièce (correspondance
			 * du grand livre auxiliaire), ou celui de n'importe quelle autre
			 * ligne de la même écriture — c'est ainsi qu'on retrouve le client
			 * d'une vente et le fournisseur d'un achat.
			 */
			$rows = FKC_DB::q(
				'WITH ' . $tmap . '
				 SELECT COALESCE(t.zone, ?) zone, COALESCE(t.groupe, 0) grp, COALESCE(SUM(l.debit - l.credit),0) s
				 FROM ecriture_lignes l
				 JOIN ecritures e ON e.id = l.ecriture_id
				 JOIN comptes c ON c.id = l.compte_id
				 LEFT JOIN tmap m ON m.eid = e.id
				 LEFT JOIN ' . $table . ' t ON t.id = COALESCE(
					l.tiers_id,
					m.tid,
					(SELECT l2.tiers_id FROM ecriture_lignes l2
					  WHERE l2.ecriture_id = e.id AND l2.tiers_id IS NOT NULL
					    AND l2.tiers_type = ? LIMIT 1)
				 )
				 WHERE e.date_ecriture BETWEEN ? AND ? AND (' . implode( ' OR ', $ou ) . ')
				 GROUP BY zone, grp',
				array_merge( array( 'etat_partie', ( 'fournisseur' === $sens ) ? 'fournisseur' : 'client' ), $args )
			)->fetchAll();
		} catch ( \Throwable $e ) {
			// Base ancienne, sans colonne `zone` : on rend tout sur l'État
			// partie plutôt que de perdre le montant.
			$out[0] = abs( self::net( $prefixes, $d1, $d2 ) );
			return $out;
		}
		$idx = array( 'etat_partie' => 0, 'region' => 1, 'hors_region' => 2 );
		foreach ( $rows as $r ) {
			$s = abs( (float) $r['s'] );
			if ( $s < 0.005 ) { continue; }
			if ( ! empty( $r['grp'] ) ) { $out[3] += $s; continue; }
			$out[ $idx[ (string) $r['zone'] ] ?? 0 ] += $s;
		}
		return $out;
	}

	/**
	 * Notes annexes que FinaKop sait remplir SEUL, et leurs comptes.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * POURQUOI SEULEMENT CELLES-CI
	 *
	 * Les notes du modèle sont indexées par POSITION de ligne, et chaque
	 * position porte un libellé qui dit ce qu'elle attend. Beaucoup réclament
	 * des ventilations que FinaKop NE TIENT PAS : géographiques (« dans l'État
	 * partie », « dans les autres États de la Région », « hors Région ») pour
	 * les achats, les ventes et les services extérieurs ; par ÉCHÉANCE (« à un
	 * an au plus », « de un à deux ans », « à plus de deux ans ») pour les
	 * créances et les dettes.
	 *
	 * Ces ventilations ne se déduisent pas du grand livre. Les remplir
	 * reviendrait à répartir au jugé, dans un document qui part à
	 * l'administration et qui écrase ce qui était saisi. On s'abstient donc, et
	 * l'écran dit quelles notes restent à saisir.
	 *
	 * Celles retenues ci-dessous se lisent en revanche EXACTEMENT sur le plan
	 * de comptes : le modèle y suit la subdivision SYSCOHADA ligne à ligne —
	 * 311 marchandises, 32 matières premières, 33 autres approvisionnements…
	 *
	 * Structure : position => préfixes de comptes, ou 'total' pour une ligne
	 * de sous-total, ou 'brut'/'net' pour les totaux avant et après
	 * dépréciations.
	 */
	protected static function notesEdiComptes() {
		return array(
			// Note 6 — Stocks et encours.
			'NOTE6' => array(
				1 => array( '31' ), 2 => array( '32' ), 3 => array( '33' ), 4 => array( '34' ),
				5 => array( '35' ), 6 => array( '36' ), 7 => array( '37' ), 8 => array( '38' ),
				9 => 'brut', 10 => array( '39' ), 11 => 'net',
			),
			// Note 9 — Titres de placement.
			'NOTE9' => array(
				1 => array( '501' ), 2 => array( '502' ), 3 => array( '503' ), 4 => array( '504' ),
				5 => array( '505' ), 6 => array( '506' ), 7 => array( '508' ),
				8 => 'brut', 9 => array( '590' ), 10 => 'net',
			),
			// Note 10 — Valeurs à encaisser.
			'NOTE10' => array(
				1 => array( '511' ), 2 => array( '512' ), 3 => array( '513' ), 4 => array( '514' ),
				5 => array( '515' ), 6 => array( '518' ),
				7 => 'brut', 8 => array( '591' ), 9 => 'net',
			),
			// Note 11 — Disponibilités.
			'NOTE11' => array(
				1 => array( '521' ), 2 => array( '522' ), 3 => array( '525' ),
				4 => array( '523', '524' ), 5 => array( '526' ), 6 => array( '531' ),
				7 => array( '532', '533', '536', '538' ), 8 => array( '5386' ),
				9 => array( '54' ), 10 => array( '545' ), 11 => array( '57' ), 12 => array( '58' ),
				13 => 'brut', 14 => array( '592', '593', '594' ), 15 => 'net',
			),
			// Note 20 — Banques, crédits d'escompte et de trésorerie.
			'NOTE20' => array(
				1 => array( '564' ), 2 => array( '565' ), 3 => 'total:1,2',
				4 => array( '561' ), 5 => array( '5612' ), 6 => array( '5618' ),
				7 => array( '566' ), 8 => array( '560' ), 9 => 'total:4,5,6,7,8',
				10 => 'total:3,9',
			),
		);
	}

	/**
	 * Notes annexes réclamant une VENTILATION en plus du solde.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * Ces notes-là étaient les grandes absentes du fichier EDI : elles se
	 * lisent bien sur le plan de comptes, ligne à ligne, mais elles ajoutent
	 * en regard une répartition que le grand livre seul ne porte pas.
	 *
	 *   — 7, 8, 17, 18, 19 : par TERME restant à courir. Rendue possible par
	 *     la colonne `echeance` de la ligne d'écriture.
	 *   — 21A, 22 : par ZONE du tiers. Rendue possible par la colonne `zone`
	 *     de la fiche client ou fournisseur.
	 *
	 * Le format d'une entrée : position => array( comptes, options ). Les
	 * options disent ce qu'il faut ajouter au solde :
	 *   'ech'  => ventilation par terme (3 colonnes de plus) ;
	 *   'zone' => la position ne prend qu'UNE part de zone, indiquée.
	 */
	protected static function notesEdiVentilees() {
		return array(
			// Note 7 — Clients. Lignes = subdivisions du 41.
			'NOTE7' => array(
				'ech'    => true,
				'lignes' => array(
					1 => array( '4111', '4112' ), 2 => array( '412' ), 3 => array( '4113' ),
					4 => array( '4114', '4115' ), 5 => array( '414' ), 6 => array( '415' ),
					7 => array( '416' ), 8 => array( '418' ),
					9 => 'brut', 10 => array( '491' ), 11 => 'net',
					12 => array( '4191' ), 13 => array( '4192' ), 14 => array( '4198' ), 15 => 'total:12,13,14',
				),
			),
			// Note 8 — Autres créances. Lignes = 42 à 47 débiteurs.
			'NOTE8' => array(
				'ech'    => true,
				'lignes' => array(
					1 => array( '42' ), 2 => array( '43' ), 3 => array( '44' ), 4 => array( '45' ),
					/*
					 * LE 461 MANQUAIT À CETTE LIGNE (1.721.0), et il y
					 * manquait déjà quand 4611 et 4612 y sont entrés. La
					 * ligne prend « 462 » en entier, « 463 », « 465 »,
					 * « 467 » : elle prenait donc les associés et le groupe,
					 * mais pas les apporteurs. Un capital appelé non versé —
					 * une créance sur l'apporteur, souvent la plus grosse du
					 * premier exercice — figurait au bilan en BJ « Autres
					 * créances » et dans AUCUNE note. La liasse s'équilibrait
					 * quand même : c'est ce qui rend ce genre de trou
					 * invisible jusqu'au contrôle.
					 */
					5 => array( '461', '462', '463', '465', '467' ), 6 => array( '475' ), 7 => array( '4718' ),
					8 => array( '451' ), 9 => array( '452' ), 10 => array( '453' ),
					11 => 'brut', 12 => array( '492', '493', '494', '495', '496', '497', '498' ), 13 => 'net',
				),
			),
			// Note 17 — Fournisseurs. Lignes = subdivisions du 40.
			'NOTE17' => array(
				'ech'    => true,
				'lignes' => array(
					1 => array( '4011' ), 2 => array( '4012' ), 3 => array( '4013' ), 4 => array( '4014' ),
					5 => array( '402' ), 6 => array( '4016', '4026' ), 7 => array( '481' ), 8 => array( '408' ),
					9 => array( '4086' ), 10 => 'total:1,2,3,4,5,6,7,8,9',
					11 => array( '4091' ), 12 => array( '4092' ), 13 => array( '4098' ), 14 => 'total:11,12,13',
				),
			),
			// Note 18 — Dettes sociales et fiscales. Lignes = 42 et 44 créditeurs.
			'NOTE18' => array(
				'ech'    => true, 'variation' => true,
				'lignes' => array(
					1 => array( '422' ), 2 => array( '4281' ), 3 => array( '4286' ), 4 => array( '421', '423', '424', '425', '426', '427' ),
					5 => array( '431' ), 6 => array( '432' ), 7 => array( '433' ), 8 => array( '434' ),
					9 => array( '4386' ), 10 => array( '435', '436', '437', '438' ), 11 => 'total:1,2,3,4,5,6,7,8,9,10',
					12 => array( '441' ), 13 => array( '442' ), 14 => array( '443', '444' ), 15 => array( '447' ),
					16 => array( '445', '446', '448', '449' ), 17 => 'total:12,13,14,15,16', 18 => 'total:11,17',
				),
			),
			// Note 19 — Autres dettes. Lignes = 46, 47, 48 créditeurs.
			'NOTE19' => array(
				'ech'    => true, 'variation' => true,
				'lignes' => array(
					1 => array( '45' ),
					/*
					 * LES HUIT DIVISIONNAIRES, PAS LE SEUL 4611 (1.721.0).
					 *
					 * La ligne 2 est « apporteurs, opérations sur le capital ».
					 * Elle ne captait que les apports en nature parce que
					 * c'était, avec 4612, le seul enfant déclaré du 461. Les
					 * versements anticipés et les fonds reçus sur augmentation
					 * de capital sont des DETTES envers l'apporteur : ils
					 * appartiennent à cette note, et à cette ligne.
					 *
					 * ON N'ÉCRIT PAS « 461 » ICI, alors que ce serait plus
					 * court : le préfixe engloberait 4619, qui a sa propre
					 * ligne 6 avec ses homologues 4629 et 4669. Le capital à
					 * rembourser serait compté deux fois, et le total 7 de la
					 * note cesserait d'égaler le poste DM du bilan.
					 */
					2 => array( '4611', '4612', '4613', '4614', '4615', '4616', '4617', '4618' ),
					3 => array( '4621' ), 4 => array( '465' ),
					5 => array( '4663' ), 6 => array( '4619', '4629', '4669' ), 7 => 'total:1,2,3,4,5,6',
					8 => array( '4712' ), 9 => array( '4713' ), 10 => array( '4714' ), 11 => array( '4715' ),
					12 => array( '4716' ), 13 => array( '4751' ), 14 => array( '4718', '4719' ), 15 => 'total:8,9,10,11,12,13,14',
					16 => array( '451' ), 17 => array( '452' ), 18 => array( '453' ), 19 => 'total:16,17,18',
					20 => 'total:7,15,19', 21 => array( '499', '599' ),
				),
			),
		);
	}

	/**
	 * Notes 21A et 22 — ventilation géographique des ventes et des achats.
	 *
	 * Une position prend soit une PART de zone d'un groupe de comptes (les
	 * quatre premières lignes de chaque bloc), soit un groupe entier (le
	 * détail par nature des autres achats, qui ne se ventile pas).
	 *
	 * Format : position => array( comptes, part ) où part vaut 0 (État
	 * partie), 1 (autres États de la Région), 2 (hors Région), 3 (groupe) ou
	 * null (tout le groupe, sans ventilation).
	 */
	protected static function notesEdiZone() {
		return array(
			'NOTE21A' => array( 'sens' => 'client', 'lignes' => array(
				1 => array( array( '701' ), 0 ), 2 => array( array( '701' ), 1 ),
				3 => array( array( '701' ), 2 ), 4 => array( array( '701' ), 3 ),
				5 => array( array( '7011' ), null ), 6 => 'total:1,2,3,4',
				7 => array( array( '702' ), 0 ), 8 => array( array( '702' ), 1 ),
				9 => array( array( '702' ), 2 ), 10 => array( array( '702' ), 3 ),
				11 => array( array( '7021' ), null ), 12 => 'total:7,8,9,10',
				13 => array( array( '704', '705', '706' ), 0 ), 14 => array( array( '704', '705', '706' ), 1 ),
				15 => array( array( '704', '705', '706' ), 2 ), 16 => array( array( '704', '705', '706' ), 3 ),
				17 => array( array( '7061' ), null ), 18 => 'total:13,14,15,16',
				19 => array( array( '707' ), null ), 20 => 'total:6,12,18,19',
				21 => array( array( '72' ), null ), 22 => array( array( '71' ), null ),
				23 => array( array( '75' ), null ), 24 => 'total:21,22,23', 25 => 'total:20,24',
			) ),
			'NOTE22' => array( 'sens' => 'fournisseur', 'lignes' => array(
				1 => array( array( '601' ), 0 ), 2 => array( array( '601' ), 1 ),
				3 => array( array( '601' ), 2 ), 4 => array( array( '601' ), 3 ), 5 => 'total:1,2,3,4',
				6 => array( array( '602' ), 0 ), 7 => array( array( '602' ), 1 ),
				8 => array( array( '602' ), 2 ), 9 => array( array( '602' ), 3 ), 10 => 'total:6,7,8,9',
				11 => array( array( '6041' ), null ), 12 => array( array( '6042' ), null ),
				13 => array( array( '6043' ), null ), 14 => array( array( '6044', '6046' ), null ),
				15 => array( array( '6051' ), null ), 16 => array( array( '6052' ), null ),
				17 => array( array( '6053' ), null ), 18 => array( array( '6054' ), null ),
				19 => array( array( '6055' ), null ), 20 => array( array( '6056' ), null ),
				21 => array( array( '6057' ), null ), 22 => array( array( '608' ), null ),
				23 => array( array( '6015', '6025', '6045' ), null ),
				24 => array( array( '6019', '6029', '6049' ), null ),
				25 => 'total:11,12,13,14,15,16,17,18,19,20,21,22,23,24',
			) ),
		);
	}

	/**
	 * Valeurs des notes à ventilation — échéances (7, 8, 17, 18, 19) et
	 * zones (21A, 22).
	 *
	 * Le solde de chaque position se lit comme pour les autres notes ; ce qui
	 * s'y ajoute est la répartition. Les sous-totaux ('brut', 'net',
	 * 'total:a,b') se comportent partout de la même façon : ils additionnent
	 * les positions, ventilations comprises, de sorte qu'une colonne de terme
	 * totalise bien les termes des lignes qu'elle résume.
	 */
	protected static function valeursNotesVentilees( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		list( $p1, $p2 ) = self::bornesEx( $annee - 1 );
		$out = array();

		foreach ( self::notesEdiVentilees() as $tableau => $def ) {
			$lignes = $def['lignes'];
			$avecVar = ! empty( $def['variation'] );
			$sol = array(); $solP = array(); $ech = array();
			foreach ( $lignes as $pos => $c ) {
				if ( ! is_array( $c ) ) { continue; }
				$sol[ $pos ]  = abs( self::net( $c, $d1, $d2 ) );
				$solP[ $pos ] = abs( self::net( $c, $p1, $p2 ) );
				$ech[ $pos ]  = self::ventilationEcheance( $c, $d1, $d2 );
			}
			self::agregerSousTotaux( $lignes, $sol, $solP, $ech, 3 );
			/*
			 * UNE DÉPRÉCIATION N'A PAS DE TERME.
			 *
			 * Le modèle ne prévoit pas de colonnes d'échéance sur la ligne des
			 * dépréciations ni sur le total net qui la suit : ces montants ne
			 * sont pas exigibles, ils corrigent une valeur. Leur en donner
			 * produirait des codes de champ que le portail ne connaît pas.
			 */
			$sansTerme = array();
			foreach ( $lignes as $pos => $d ) {
				if ( 'net' === $d ) { $sansTerme[ $pos ] = true; $sansTerme[ $pos - 1 ] = true; }
			}
			$t = array();
			foreach ( $lignes as $pos => $c ) {
				$n = (float) ( $sol[ $pos ] ?? 0.0 ); $p = (float) ( $solP[ $pos ] ?? 0.0 );
				$pct = ( abs( $p ) > 0.004 ) ? round( 100 * ( $n - $p ) / abs( $p ), 2 ) : null;
				$e = isset( $sansTerme[ $pos ] ) ? array( null, null, null ) : ( $ech[ $pos ] ?? array( 0.0, 0.0, 0.0 ) );
				$t[ (string) $pos ] = $avecVar
					? array( $n, $p, $n - $p, $pct, $e[0], $e[1], $e[2] )
					: array( $n, $p, $pct, $e[0], $e[1], $e[2] );
			}
			$out[ $tableau ] = $t;
		}

		foreach ( self::notesEdiZone() as $tableau => $def ) {
			$lignes = $def['lignes']; $sens = $def['sens'];
			$sol = array(); $solP = array(); $vide = array();
			$cacheN = array(); $cacheP = array();
			foreach ( $lignes as $pos => $c ) {
				if ( ! is_array( $c ) ) { continue; }
				list( $comptes, $part ) = $c;
				$cle = implode( '|', $comptes );
				if ( null === $part ) {
					$sol[ $pos ]  = abs( self::net( $comptes, $d1, $d2 ) );
					$solP[ $pos ] = abs( self::net( $comptes, $p1, $p2 ) );
					continue;
				}
				if ( ! isset( $cacheN[ $cle ] ) ) {
					$cacheN[ $cle ] = self::ventilationZone( $comptes, $d1, $d2, $sens );
					$cacheP[ $cle ] = self::ventilationZone( $comptes, $p1, $p2, $sens );
				}
				$sol[ $pos ]  = $cacheN[ $cle ][ $part ];
				$solP[ $pos ] = $cacheP[ $cle ][ $part ];
			}
			self::agregerSousTotaux( $lignes, $sol, $solP, $vide, 0 );
			$t = array();
			foreach ( $lignes as $pos => $c ) {
				$n = (float) ( $sol[ $pos ] ?? 0.0 ); $p = (float) ( $solP[ $pos ] ?? 0.0 );
				$t[ (string) $pos ] = array( $n, $p, ( abs( $p ) > 0.004 ) ? round( 100 * ( $n - $p ) / abs( $p ), 2 ) : null );
			}
			$out[ $tableau ] = $t;
		}
		return $out;
	}

	/**
	 * Résout les sous-totaux d'une note, ventilations comprises.
	 *
	 * Une note qui totaliserait ses lignes mais pas leurs colonnes de terme
	 * afficherait un total sans échéances : le lecteur y verrait un solde
	 * exigible nulle part. Les sous-totaux additionnent donc TOUT.
	 */
	protected static function agregerSousTotaux( array $lignes, array &$sol, array &$solP, array &$vent, $nbVent ) {
		$zero = array_fill( 0, max( 1, $nbVent ), 0.0 );
		foreach ( $lignes as $pos => $def ) {
			if ( is_array( $def ) ) { continue; }
			$cumul = function ( array $positions ) use ( &$sol, &$solP, &$vent, $nbVent, $zero ) {
				$n = 0.0; $p = 0.0; $v = $zero;
				foreach ( $positions as $q ) {
					$n += $sol[ $q ] ?? 0.0; $p += $solP[ $q ] ?? 0.0;
					for ( $i = 0; $i < $nbVent; $i++ ) { $v[ $i ] += $vent[ $q ][ $i ] ?? 0.0; }
				}
				return array( $n, $p, $v );
			};
			if ( 'brut' === $def ) {
				$q = array();
				foreach ( $lignes as $k => $d ) { if ( $k < $pos && is_array( $d ) ) { $q[] = $k; } }
				list( $n, $p, $v ) = $cumul( $q );
			} elseif ( 'net' === $def ) {
				$brutPos = null; $depPos = $pos - 1;
				foreach ( $lignes as $k => $d ) { if ( 'brut' === $d ) { $brutPos = $k; } }
				$n = ( $sol[ $brutPos ] ?? 0.0 ) - ( $sol[ $depPos ] ?? 0.0 );
				$p = ( $solP[ $brutPos ] ?? 0.0 ) - ( $solP[ $depPos ] ?? 0.0 );
				$v = $zero;
				for ( $i = 0; $i < $nbVent; $i++ ) {
					$v[ $i ] = ( $vent[ $brutPos ][ $i ] ?? 0.0 ) - ( $vent[ $depPos ][ $i ] ?? 0.0 );
				}
			} elseif ( 0 === strpos( (string) $def, 'total:' ) ) {
				list( $n, $p, $v ) = $cumul( array_map( 'intval', explode( ',', substr( $def, 6 ) ) ) );
			} else {
				continue;
			}
			$sol[ $pos ] = $n; $solP[ $pos ] = $p;
			if ( $nbVent ) { $vent[ $pos ] = $v; }
		}
	}

	/**
	 * Valeurs des notes annexes pour le fichier EDI.
	 *
	 * Les montants se lisent en valeur ABSOLUE du solde : une note énumère des
	 * postes, pas des sens. Une dépréciation figure sur sa propre ligne, en
	 * positif, et le total net s'en déduit — c'est la présentation du modèle.
	 */
	protected static function valeursNotesEdi( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		list( $p1, $p2 ) = self::bornesEx( $annee - 1 );
		$out = array();

		foreach ( self::notesEdiComptes() as $tableau => $lignes ) {
			$vN = array(); $vP = array();
			foreach ( $lignes as $pos => $def ) {
				if ( ! is_array( $def ) ) { continue; }
				$vN[ $pos ] = abs( self::net( $def, $d1, $d2 ) );
				$vP[ $pos ] = abs( self::net( $def, $p1, $p2 ) );
			}
			// Sous-totaux : « brut » additionne les lignes de détail qui
			// précèdent, « net » retranche la dépréciation qui vient juste
			// avant, « total:a,b » additionne les positions nommées.
			foreach ( $lignes as $pos => $def ) {
				if ( is_array( $def ) ) { continue; }
				if ( 'brut' === $def ) {
					$vN[ $pos ] = 0.0; $vP[ $pos ] = 0.0;
					foreach ( $lignes as $q => $d ) {
						if ( $q >= $pos || ! is_array( $d ) ) { continue; }
						$vN[ $pos ] += $vN[ $q ]; $vP[ $pos ] += $vP[ $q ];
					}
				} elseif ( 'net' === $def ) {
					$brut = 0.0; $brutP = 0.0; $dep = 0.0; $depP = 0.0;
					foreach ( $lignes as $q => $d ) {
						if ( 'brut' === $d ) { $brut = $vN[ $q ]; $brutP = $vP[ $q ]; }
						if ( is_array( $d ) && $q > 1 && isset( $vN[ $q ] ) && $q === $pos - 1 ) { $dep = $vN[ $q ]; $depP = $vP[ $q ]; }
					}
					$vN[ $pos ] = $brut - $dep; $vP[ $pos ] = $brutP - $depP;
				} elseif ( 0 === strpos( $def, 'total:' ) ) {
					$vN[ $pos ] = 0.0; $vP[ $pos ] = 0.0;
					foreach ( explode( ',', substr( $def, 6 ) ) as $q ) {
						$q = (int) $q;
						$vN[ $pos ] += $vN[ $q ] ?? 0.0; $vP[ $pos ] += $vP[ $q ] ?? 0.0;
					}
				}
			}
			$t = array();
			foreach ( $lignes as $pos => $def ) {
				$n = (float) ( $vN[ $pos ] ?? 0.0 ); $p = (float) ( $vP[ $pos ] ?? 0.0 );
				$pct = ( abs( $p ) > 0.004 ) ? round( 100 * ( $n - $p ) / abs( $p ), 2 ) : null;
				// La note 6 réclame la variation EN VALEUR avant le pourcentage ;
				// les autres n'ont que le pourcentage.
				$t[ (string) $pos ] = ( 'NOTE6' === $tableau )
					? array( $n, $p, $n - $p, $pct )
					: array( $n, $p, $pct );
			}
			$out[ $tableau ] = $t;
		}

		/*
		 * Notes 3A et 3C — mouvements des immobilisations. Les positions
		 * suivent les postes du bilan ; FinaKop ne distingue pas les immeubles
		 * DE PLACEMENT des autres, toute la valeur va donc sur la ligne
		 * « hors immeuble de placement », et les colonnes « virements de poste
		 * à poste » et « réévaluation » restent vides — elles ne se déduisent
		 * pas d'un mouvement de compte.
		 */
		$mvt = self::variationImmobilisations( $annee, $d1, $d2, array( 'AE', 'AF', 'AG', 'AH', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AP', 'AR', 'AS' ) );
		$par = array();
		foreach ( $mvt as $m ) {
			$c = $m['poste']; $k = $m['nature'];
			if ( ! isset( $par[ $c ][ $k ] ) ) { $par[ $c ][ $k ] = array( 0.0, 0.0, 0.0, 0.0 ); }
			$par[ $c ][ $k ][0] += $m['ouverture']; $par[ $c ][ $k ][1] += $m['entrees'];
			$par[ $c ][ $k ][2] += $m['sorties'];   $par[ $c ][ $k ][3] += $m['cloture'];
		}
		$g = function ( $codes, $nature ) use ( $par ) {
			$t = array( 0.0, 0.0, 0.0, 0.0 );
			foreach ( (array) $codes as $c ) {
				if ( ! isset( $par[ $c ][ $nature ] ) ) { continue; }
				for ( $i = 0; $i < 4; $i++ ) { $t[ $i ] += $par[ $c ][ $nature ][ $i ]; }
			}
			return $t;
		};
		// FinaKop ne distingue pas les immeubles DE PLACEMENT : ces lignes du
		// modèle restent à zéro plutôt que de recevoir une part arbitraire.
		$vide   = array( 0.0, 0.0, 0.0, 0.0 );
		$incorp = array( 'AE', 'AF', 'AG', 'AH' );
		$corp   = array( 'AJ', 'AK', 'AL', 'AM', 'AN' );
		$fin    = array( 'AR', 'AS' );
		// 3A : ouverture, acquisitions, virements+, réévaluation, cessions, virements−, clôture
		$l3a = function ( $v ) { return array( $v[0], $v[1], 0.0, 0.0, $v[2], 0.0, $v[3] ); };
		$b = 'brut';
		$out['NOTE3A'] = array(
			'1' => $l3a( $g( $incorp, $b ) ),
			'2' => $l3a( $g( 'AE', $b ) ), '3' => $l3a( $g( 'AF', $b ) ),
			'4' => $l3a( $g( 'AG', $b ) ), '5' => $l3a( $g( 'AH', $b ) ),
			'6' => $l3a( $g( $corp, $b ) ),
			'7' => $l3a( $g( 'AJ', $b ) ), '8' => $l3a( $vide ),
			'9' => $l3a( $g( 'AK', $b ) ), '10' => $l3a( $vide ),
			'11' => $l3a( $g( 'AL', $b ) ), '12' => $l3a( $g( 'AM', $b ) ), '13' => $l3a( $g( 'AN', $b ) ),
			'14' => $l3a( $g( 'AP', $b ) ), '15' => $l3a( $vide ), '16' => $l3a( $g( 'AP', $b ) ),
			'17' => $l3a( $g( $fin, $b ) ),
			'18' => $l3a( $g( 'AR', $b ) ), '19' => $l3a( $g( 'AS', $b ) ),
			'20' => $l3a( $g( array_merge( $incorp, $corp, array( 'AP' ), $fin ), $b ) ),
		);
		// 3C : ouverture, dotations, sorties, reprises, virements, clôture
		$l3c = function ( $v ) { return array( $v[0], $v[1], $v[2], 0.0, 0.0, $v[3] ); };
		$a = 'amortissement';
		$out['NOTE3C'] = array(
			'1' => $l3c( $g( 'AE', $a ) ), '2' => $l3c( $g( 'AF', $a ) ),
			'3' => $l3c( $g( 'AG', $a ) ), '4' => $l3c( $g( 'AH', $a ) ),
			'5' => $l3c( $g( $incorp, $a ) ),
			'6' => $l3c( $g( 'AJ', $a ) ), '7' => $l3c( $vide ),
			'8' => $l3c( $g( 'AK', $a ) ), '9' => $l3c( $vide ),
			'10' => $l3c( $g( 'AL', $a ) ), '11' => $l3c( $g( 'AM', $a ) ), '12' => $l3c( $g( 'AN', $a ) ),
			'13' => $l3c( $g( $corp, $a ) ),
			'14' => $l3c( $g( array_merge( $incorp, $corp ), $a ) ),
		);
		return $out;
	}

	/**
	 * Fichier EDI XML pour le dépôt sur e-impots.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * CE QUI A CHANGÉ DEPUIS LA 1.567.1
	 *
	 * J'écrivais alors qu'il n'existait pas de format d'import publié, et que
	 * produire un fichier en le devinant serait pire que rien. C'était exact
	 * au vu des sources publiques — mais le format EXISTE : les classeurs
	 * officiels embarquent le schéma XSD de l'EDI e-impots et la macro qui le
	 * produit. Le voici donc écrit d'après le schéma lui-même, et non deviné.
	 *
	 * La structure attendue :
	 *
	 *     <EDI>
	 *       <informations><type/><ncc/><exercice/></informations>
	 *       <champsTableauxFixes>
	 *         <champTableauFixe><code/><valeur/></champTableauFixe>…
	 *       </champsTableauxFixes>
	 *       <champsTableauxVariables>
	 *         <champTableauVariable><colonne/><ligne/><valeur/></champTableauVariable>…
	 *       </champsTableauxVariables>
	 *     </EDI>
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * DEUX PRÉCAUTIONS
	 *
	 * L'import ÉCRASE tout ce qui est déjà saisi dans e-impots : le fichier
	 * doit donc être complet, ou l'être assez pour qu'on sache ce qu'on perd.
	 * Les tableaux que FinaKop ne sait pas encore alimenter sont laissés hors
	 * du fichier plutôt que remplis de zéros — un zéro déclaré n'est pas une
	 * absence de déclaration.
	 *
	 * Et le fichier n'est produit que si la liasse est COHÉRENTE, sauf
	 * forçage explicite : déposer un bilan déséquilibré à l'administration
	 * n'est pas un accident qu'on répare après coup.
	 *
	 * @param int    $annee   Millésime.
	 * @param string $systeme 'sn' → NO, 'smt' → MT.
	 * @return array array( xml, nb_champs, tableaux )
	 */
	public static function edi( $annee, $systeme = 'sn' ) {
		return self::memo( 'edi', array( $annee, $systeme ), array( __CLASS__, 'ediCalcul' ) );
	}

	protected static function ediCalcul( $annee, $systeme = 'sn' ) {
		$annee = (int) $annee;
		$type  = ( 'smt' === $systeme ) ? 'MT' : 'NO';
		$e     = self::entete( $annee );
		$lignes = self::lignesEdi();
		$lignes = $lignes[ $type ];

		$champs = array();
		$ajout = function ( $tableau, $ligne, $position, $valeur ) use ( &$champs, $type ) {
			if ( null === $valeur ) { return; }
			$champs[] = array(
				'code'   => $type . '_' . $tableau . '_' . $ligne . '_' . (int) $position,
				// Les montants partent en entiers de francs : le modèle ne
				// prévoit pas de décimales, et un arrondi tardif côté portail
				// ferait diverger les totaux qu'il recalcule.
				'valeur' => is_numeric( $valeur ) ? (string) (int) round( (float) $valeur ) : (string) $valeur,
			);
		};

		$valeurs = self::valeursEdi( $annee, $systeme );
		$servis  = array();
		foreach ( $lignes as $tableau => $codes ) {
			if ( ! isset( $valeurs[ $tableau ] ) ) { continue; }
			$n = 0;
			foreach ( $codes as $code ) {
				if ( ! isset( $valeurs[ $tableau ][ $code ] ) ) { continue; }
				$cols = (array) $valeurs[ $tableau ][ $code ];
				$max  = self::colonnesEdi( $type, $tableau );
				for ( $i = 0; $i < $max; $i++ ) {
					if ( ! array_key_exists( $i, $cols ) ) { continue; }
					$ajout( $tableau, $code, $i + 1, $cols[ $i ] );
					$n++;
				}
			}
			if ( $n ) { $servis[ $tableau ] = $n; }
		}

		$esc = function ( $v ) { return htmlspecialchars( (string) $v, ENT_XML1 | ENT_QUOTES, 'UTF-8' ); };
		$xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		$xml .= "<EDI>\n\t<informations>\n";
		$xml .= "\t\t<type>" . $esc( $type ) . "</type>\n";
		$xml .= "\t\t<ncc>" . $esc( $e['ncc'] ) . "</ncc>\n";
		$xml .= "\t\t<exercice>" . $esc( $annee ) . "</exercice>\n";
		$xml .= "\t</informations>\n\t<champsTableauxFixes>\n";
		foreach ( $champs as $c ) {
			$xml .= "\t\t<champTableauFixe><code>" . $esc( $c['code'] ) . '</code><valeur>'
				. $esc( $c['valeur'] ) . "</valeur></champTableauFixe>\n";
		}
		$xml .= "\t</champsTableauxFixes>\n\t<champsTableauxVariables>\n";
		$xml .= "\t</champsTableauxVariables>\n</EDI>\n";

		return array( 'xml' => $xml, 'nb' => count( $champs ), 'tableaux' => $servis,
			'type' => $type, 'ncc' => $e['ncc'], 'annee' => $annee );
	}

	/**
	 * Valeurs de la liasse, indexées par tableau puis par code de ligne.
	 *
	 * Chaque entrée est la liste ORDONNÉE des colonnes du modèle. Une colonne
	 * absente du tableau (l'actif SMT n'a pas de colonne brut) est simplement
	 * omise ; une colonne connue mais vide vaut zéro, ce qui n'est pas la même
	 * chose et se déclare.
	 */
	protected static function valeursEdi( $annee, $systeme ) {
		$annee = (int) $annee;
		$smt   = ( 'smt' === $systeme );
		$out   = array( 'ACTIF' => array(), 'PASSIF' => array(), 'RESULTAT' => array(), 'CHARGES' => array() );

		if ( $smt ) {
			$b = self::bilan( $annee );
			foreach ( $b['actif'] as $l )  { $out['ACTIF'][ $l['code'] ]  = array( $l['n'], $l['n1'] ); }
			$out['ACTIF']['GZ']  = array( $b['total_actif']['n'], $b['total_actif']['n1'] );
			foreach ( $b['passif'] as $l ) { $out['PASSIF'][ $l['code'] ] = array( $l['n'], $l['n1'] ); }
			$out['PASSIF']['HZ'] = array( $b['total_passif']['n'], $b['total_passif']['n1'] );

			$cr = self::resultat( $annee );
			foreach ( array_merge( $cr['produits'], $cr['charges'] ) as $l ) {
				$out['RESULTAT'][ $l['code'] ] = array( $l['n'], $l['n1'] );
			}
			foreach ( array_merge( array( $cr['kz'] ), $cr['variations'], array( $cr['jg'], $cr['kzc'] ) ) as $l ) {
				$out['RESULTAT'][ $l['code'] ] = array( $l['n'], $l['n1'] );
			}
		} else {
			$b = self::bilanSN( $annee );
			foreach ( $b['actif'] as $l ) {
				$out['ACTIF'][ $l['code'] ] = array( $l['brut'], $l['amort'], $l['net'], $l['n1'] );
			}
			foreach ( $b['passif'] as $l ) {
				$out['PASSIF'][ $l['code'] ] = array( $l['net'], $l['n1'] );
			}
			foreach ( self::resultatSN( $annee )['lignes'] as $l ) {
				$out['RESULTAT'][ $l['code'] ] = array( $l['n'], $l['n1'] );
			}
			$out['TFT'] = array();
			foreach ( self::fluxTresorerie( $annee )['lignes'] as $l ) {
				if ( '' === $l['code'] ) { continue; }
				$out['TFT'][ $l['code'] ] = array( $l['valeur'], $l['n1'] );
			}
		}

		/*
		 * COMP-CHARGES est indexé par NUMÉRO DE COMPTE à quatre chiffres, et
		 * non par code de ligne. Nos comptes en font six : on agrège sur les
		 * quatre premiers, ce qui est exactement la maille du modèle.
		 */
		list( $d1, $d2 ) = self::bornesEx( $annee );
		list( $p1, $p2 ) = self::bornesEx( $annee - 1 );
		$agg = function ( $du, $au ) {
			$r = array();
			foreach ( self::soldesClasse( '6', $du, $au ) as $num => $solde ) {
				$cle = substr( (string) $num, 0, 4 );
				$r[ $cle ] = ( $r[ $cle ] ?? 0.0 ) + $solde;
			}
			return $r;
		};
		$cN = $agg( $d1, $d2 ); $cP = $agg( $p1, $p2 );
		foreach ( array_unique( array_merge( array_keys( $cN ), array_keys( $cP ) ) ) as $cle ) {
			$n = (float) ( $cN[ $cle ] ?? 0.0 ); $p = (float) ( $cP[ $cle ] ?? 0.0 );
			$out['CHARGES'][ $cle ] = array( $n, $p, $n - $p, ( abs( $p ) > 0.004 ) ? round( 100 * ( $n - $p ) / abs( $p ), 2 ) : null );
		}
		foreach ( self::compCharges( $annee )['groupes'] as $g ) {
			if ( '' === $g['code'] ) { continue; }
			$out['CHARGES'][ $g['code'] ] = array( $g['n'], $g['n1'], $g['var']['val'], $g['var']['pct'] );
		}
		/*
		 * Notes annexes remplissables sans rien inventer. Le Système Minimal
		 * a d'autres notes, non traitées ici.
		 */
		if ( ! $smt ) {
			foreach ( self::valeursNotesEdi( $annee ) as $tableau => $lignes ) { $out[ $tableau ] = $lignes; }
			foreach ( self::valeursNotesVentilees( $annee ) as $tableau => $lignes ) { $out[ $tableau ] = $lignes; }
		}
		return $out;
	}

	/* ═══════════════════ CONTRÔLE DE COHÉRENCE DE LA LIASSE ═══════════════════ */

	/**
	 * Tout ce qu'il faut savoir AVANT de déposer la liasse.
	 *
	 * ─────────────────────────────────────────────────────────────────────────
	 * POURQUOI CETTE MÉTHODE EXISTE (1.564.0)
	 *
	 * Les états financiers étaient les seuls du produit à ne rien dire d'eux-
	 * mêmes. Ils s'affichaient, s'imprimaient et s'exportaient sans jamais
	 * indiquer sur quoi ils reposaient. Or trois choses peuvent les rendre
	 * faux sans qu'aucun chiffre n'ait l'air suspect :
	 *
	 *   LES ÉCRITURES EN ATTENTE. Depuis la 1.541.0, TOUTE écriture passe par
	 *   le journal temporaire avant d'entrer au grand livre. Un état financier
	 *   ne lit que le grand livre — c'est juste, une pièce non validée n'a
	 *   rien à faire dans un bilan. Mais la liasse pouvait être éditée et
	 *   déposée pendant que des centaines d'écritures attendaient, sans un
	 *   mot. Le module SYCEBNL annonçait déjà les siennes ; la liasse DGI, non.
	 *
	 *   LES À-NOUVEAUX MANQUANTS. Le bilan se calcule sur les mouvements de
	 *   l'exercice. C'est exact À CONDITION que les soldes d'ouverture aient
	 *   été reportés. Un dossier en deuxième année dont l'exercice n'a pas été
	 *   ouvert produit un bilan qui s'équilibre parfaitement — sur les seuls
	 *   mouvements de l'année, capital et immobilisations de l'an dernier
	 *   absents. C'est le piège le plus silencieux des trois.
	 *
	 *   LES COMPTES SANS LIGNE. Le plan de base compte plusieurs centaines de
	 *   comptes et soixante et un packs métiers en ouvrent d'autres. Le
	 *   routage est désormais exhaustif par construction, mais un compte
	 *   inconnu range dans une ligne de repli : il faut le dire.
	 *
	 * Cette méthode ne corrige rien et ne bloque rien. Elle dit ce qui est.
	 * ─────────────────────────────────────────────────────────────────────────
	 *
	 * @param int $annee Millésime de l'exercice.
	 * @return array
	 */
	public static function controle( $annee ) {
		return self::memo( 'controle', array( $annee ), array( __CLASS__, 'controleCalcul' ) );
	}

	protected static function controleCalcul( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );

		$smt  = self::bilan( $annee );
		$sn   = self::bilanSN( $annee );
		$crSmt = self::resultat( $annee );
		$sig  = self::sigBruts( $d1, $d2 );

		$resultatGl = self::resultatNet( $d1, $d2 );
		$anomalies  = array();

		/* ── Équilibre des deux bilans ─────────────────────────────────── */
		$ecartSmt = round( (float) $smt['total_actif']['n'] - (float) $smt['total_passif']['n'], 2 );
		$ecartSn  = round( (float) $sn['total_actif']['n'] - (float) $sn['total_passif']['n'], 2 );
		if ( abs( $ecartSmt ) >= 1 ) {
			$anomalies[] = array( 'niveau' => 'incoherence', 'texte' => 'Bilan SMT déséquilibré de ' . fkc_money( $ecartSmt ) . ' F CFA.' );
		}
		if ( abs( $ecartSn ) >= 1 ) {
			$anomalies[] = array( 'niveau' => 'incoherence', 'texte' => 'Bilan Système Normal déséquilibré de ' . fkc_money( $ecartSn ) . ' F CFA.' );
		}

		/* ── Le résultat doit être le même partout ─────────────────────── */
		$ecartXi  = round( (float) $sig['XI'] - $resultatGl, 2 );
		$ecartKzc = round( (float) $crSmt['kzc']['n'] - $resultatGl, 2 );
		if ( abs( $ecartXi ) >= 1 ) {
			$anomalies[] = array( 'niveau' => 'incoherence', 'texte' => 'Le résultat net du compte de résultat SN (XI) diffère de '
				. fkc_money( $ecartXi ) . ' F CFA du résultat du grand livre : des comptes de gestion échappent à la cascade.' );
		}
		if ( abs( $ecartKzc ) >= 1 ) {
			$anomalies[] = array( 'niveau' => 'incoherence', 'texte' => 'Le résultat du compte de résultat SMT diffère de '
				. fkc_money( $ecartKzc ) . ' F CFA du résultat du grand livre.' );
		}

		/* ── Le tableau des flux doit retomber sur la trésorerie du bilan ── */
		$tft = self::fluxTresorerie( $annee );
		if ( abs( (float) $tft['ecart'] ) >= 1 ) {
			$anomalies[] = array( 'niveau' => 'incoherence', 'texte' => 'Le tableau des flux de trésorerie annonce une clôture de '
				. fkc_money( $tft['cloture'] ) . ' F CFA quand le bilan en montre ' . fkc_money( $tft['tresorerie_bilan'] )
				. ' F CFA : écart de ' . fkc_money( $tft['ecart'] ) . ' F CFA.' );
		}

		/* ── Les notes annexes doivent retomber sur leurs postes ───────── */
		foreach ( array( 'sn', 'smt' ) as $sys ) {
			$nt = self::notes( $annee, $sys );
			if ( ! empty( $nt['ecarts'] ) ) {
				$anomalies[] = array( 'niveau' => 'incoherence', 'texte' => 'Notes annexes ' . strtoupper( $sys ) . ' — '
					. implode( ', ', array_keys( $nt['ecarts'] ) ) . ' : le détail ne retombe pas sur le poste détaillé.' );
			}
		}

		/*
		 * IMPUTATIONS HÉRITÉES (1.617.0). Un solde figé sur un compte de
		 * regroupement traverse la liasse sans que rien ne le signale : il est
		 * équilibré, il totalise juste, et il désigne le mauvais poste.
		 */
		if ( class_exists( 'FKC_Reclassement' ) ) {
			foreach ( FKC_Reclassement::anomalies() as $a ) {
				$anomalies[] = array( 'niveau' => 'reserve', 'texte' => $a['titre'] . ' — ' . $a['detail'] );
			}
		}

		/* ── LA LIASSE EST-ELLE SEULEMENT CELLE DU BON RÉFÉRENTIEL ? ─────
		 *
		 * Ces états sont ceux du SYSCOHADA. Un dossier qui déclare relever du
		 * SYCEBNL ou du Code CIMA obtient donc une liasse dans la MAUVAISE
		 * présentation — équilibrée, cohérente, et inutilisable pour un dépôt.
		 *
		 * Rien ne le disait. Le bandeau annonçait « liasse cohérente et
		 * complète » à une compagnie d'assurance, ce qui est vrai au sens des
		 * totaux et faux au sens de ce qu'on lui demande de déposer.
		 *
		 * La réserve ne bloque pas l'édition : une liasse SYSCOHADA reste utile
		 * en interne, et refuser de l'imprimer priverait le dossier du seul état
		 * dont il dispose. Elle dit seulement ce qu'elle est.
		 */
		if ( class_exists( 'FKC_Referentiel' ) && ! FKC_Referentiel::complet() ) {
			$ref = FKC_Referentiel::get();
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => 'Ce dossier relève du référentiel '
				. $ref['label'] . ' ; les états ci-dessous sont ceux du SYSCOHADA. Leur présentation n\'est pas celle qu\'exige '
				. $ref['label'] . ' : à réserver à un usage interne.' );
		}

		/* ── Annexe descriptive : ce que le logiciel ne peut pas écrire ── */
		$txt = self::notesTexte( $annee );
		if ( $txt['manquantes'] ) {
			$titres = array();
			foreach ( $txt['manquantes'] as $cle ) { $titres[] = 'note ' . $cle . ' (' . $txt['notes'][ $cle ]['titre'] . ')'; }
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => 'Annexe descriptive incomplète : '
				. implode( ', ', $titres ) . ' — le Système Normal les exige et elles ne se calculent pas.' );
		}
		if ( ! empty( $txt['a_completer'] ) ) {
			$titres = array();
			foreach ( $txt['a_completer'] as $cle ) { $titres[] = 'note ' . $cle . ' (' . $txt['notes'][ $cle ]['titre'] . ')'; }
			$anomalies[] = array( 'niveau' => 'information', 'texte' => 'À compléter avant le dépôt : '
				. implode( ', ', $titres ) . ' — elle peut l\'être après la clôture, exercice verrouillé compris.' );
		}

		/* ── Comptes rangés dans une ligne de repli ────────────────────── */
		$nonVentiles = array();
		foreach ( (array) ( $sn['non_ventiles'] ?? array() ) as $numero => $solde ) {
			$c = FKC_Compte::byNumero( (string) $numero );
			$nonVentiles[] = array( 'numero' => (string) $numero, 'libelle' => $c['libelle'] ?? '', 'solde' => (float) $solde );
		}
		/*
		 * Comptes de GESTION rangés en repli (1.853.0) : typiquement ceux que
		 * les Packs Métiers ouvrent hors du plan de base (Royalties 7080/7090,
		 * ONG 6895/7895…). Le résultat reste juste ; la ligne, elle, est à
		 * vérifier — on nomme donc chaque compte.
		 */
		foreach ( self::gestionNonVentiles( $d1, $d2 ) as $numero => $info ) {
			$c = FKC_Compte::byNumero( (string) $numero );
			$nonVentiles[] = array( 'numero' => (string) $numero, 'libelle' => $c['libelle'] ?? '', 'solde' => (float) $info['solde'], 'ligne' => $info['ligne'] );
		}
		if ( $nonVentiles ) {
			$noms = array();
			foreach ( array_slice( $nonVentiles, 0, 8 ) as $nv ) {
				$noms[] = $nv['numero'] . ( isset( $nv['ligne'] ) ? ' → ' . $nv['ligne'] : '' );
			}
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => count( $nonVentiles )
				. ' compte(s) mouvementé(s) ne correspondent à aucune ligne officielle et ont été rangés dans une ligne de repli ('
				. implode( ', ', $noms ) . ( count( $nonVentiles ) > 8 ? '…' : '' ) . ').' );
		}

		/* ── PONT COMPTABILITÉ : le journal temporaire ─────────────────── */
		$attente = self::enAttente( $d1, $d2 );
		if ( $attente['nb'] > 0 ) {
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => $attente['nb'] . ' écriture(s) de cet exercice attendent au journal temporaire'
				. ( $attente['montant'] > 0 ? ' (' . fkc_money( $attente['montant'] ) . ' F CFA au débit)' : '' )
				. ' : elles ne sont PAS dans ces états. Validez-les avant de déposer la liasse.' );
		}

		/* ── PONT COMPTABILITÉ : à-nouveaux et clôture ─────────────────── */
		$ouvert   = class_exists( 'FKC_Exercice' ) && FKC_Exercice::isOpen( $annee );
		$anterieur = self::mouvementsAvant( $d1 );
		if ( class_exists( 'FKC_SoldeOuverture' ) ) {
			// Diagnostic du gestionnaire des À-nouveaux (1.798.0).
			$diagAN = FKC_SoldeOuverture::diagnostic( $annee );
			foreach ( $diagAN['anomalies'] as $a ) {
				$anomalies[] = array(
					'niveau' => 'critique' === $a['niveau'] ? 'incoherence' : 'reserve',
					'texte'  => 'solde_calcule' === $a['code']
						? "Aucun À-nouveaux pour " . $annee . " : le bilan intègre un solde d'ouverture CALCULÉ depuis la clôture de " . ( $annee - 1 )
							. ". Générez les À-nouveaux avant tout dépôt."
						: 'À-nouveaux — ' . $a['texte'],
				);
			}
		} elseif ( ! $ouvert && $anterieur ) {
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => "L'exercice " . $annee . " n'a pas été ouvert : les à-nouveaux ne sont pas reportés. "
				. "Le bilan ne montre que les mouvements de l'exercice — capital, immobilisations et soldes antérieurs en sont absents." );
		}
		$clos = class_exists( 'FKC_Cloture' ) && FKC_Cloture::isExerciceClos( $d2 );
		if ( ! $clos ) {
			$anomalies[] = array( 'niveau' => 'information', 'texte' => "Exercice non clôturé : cette liasse est provisoire." );
		}

		/* ── Résultat antérieur resté en instance d'affectation ────────── */
		$instance = -self::net( array( '130' ), $d1, $d2 );
		if ( abs( $instance ) >= 1 ) {
			$nonDetermine = class_exists( 'FKC_SoldeOuverture' ) ? -FKC_SoldeOuverture::resultatNonDetermine( $annee - 1 ) : 0.0;
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => abs( $nonDetermine ) >= 1 && ! FKC_SoldeOuverture::aDesANouveaux( $annee )
				? 'Le résultat ' . ( $annee - 1 ) . ' (' . fkc_money( $nonDetermine ) . " F CFA) n'a été ni déterminé ni affecté : il figure au passif en instance d'affectation (compte 130). Clôturez " . ( $annee - 1 ) . ' puis générez les À-nouveaux.'
				: 'Un résultat de ' . fkc_money( $instance )
				. " F CFA est encore en instance d'affectation (compte 130) : l'affectation de l'exercice précédent n'a pas été enregistrée." );
		}

		/* ── Déclarations de packs ignorées (1.854.0) ─────────────────── */
		$rejets = self::correspondancesDeclarees()['_rejets'] ?? array();
		if ( $rejets ) {
			$bits = array(); foreach ( $rejets as $pref => $why ) { $bits[] = $pref . ' (' . $why . ')'; }
			$anomalies[] = array( 'niveau' => 'information', 'texte' => 'Correspondances de liasse déclarées par un pack et ignorées : ' . implode( ', ', $bits ) . '.' );
		}

		/* ── Rapprochement avec le module Fiscalité (1.854.0) ─────────── */
		$fisc = self::rapprochementFiscal( $annee );
		if ( null !== $fisc['ecart_is'] && abs( $fisc['ecart_is'] ) >= 1 ) {
			$anomalies[] = array( 'niveau' => 'reserve', 'texte' => "L'impôt sur le résultat de la liasse (RS : " . fkc_money( $fisc['is_liasse'] )
				. ' F CFA) diffère de la déclaration d\'IS ' . $annee . ' (' . fkc_money( $fisc['is_declare'] ) . ' F CFA) : écart de '
				. fkc_money( $fisc['ecart_is'] ) . ' F CFA. Comptabilisez la déclaration ou corrigez-la avant le dépôt.' );
		}
		if ( null !== $fisc['ecart_ca'] && abs( $fisc['ecart_ca'] ) >= max( 1000, 0.005 * abs( $fisc['ca_liasse'] ) ) ) {
			$anomalies[] = array( 'niveau' => 'information', 'texte' => "Chiffre d'affaires de la liasse (XB : " . fkc_money( $fisc['ca_liasse'] )
				. ' F CFA) et base des déclarations de TVA (' . fkc_money( $fisc['ca_tva'] ) . ' F CFA sur ' . $fisc['mois_tva'] . ' mois déclaré(s) / '
				. $fisc['mois_exercice'] . ') : écart de ' . fkc_money( $fisc['ecart_ca'] ) . ' F CFA à justifier (exportations et opérations exonérées, avoirs, décalages de période'
				. ( $fisc['mois_tva'] < $fisc['mois_exercice'] ? ', mois non encore déclarés' : '' ) . ').' );
		}

		/* ── Registre des immobilisations ↔ bilan (1.855.0) ───────────── */
		if ( class_exists( 'FKC_Immobilisation' ) && method_exists( 'FKC_Immobilisation', 'rapprochement' ) ) {
			try {
				$nbFiches = (int) FKC_DB::q( "SELECT COUNT(*) FROM immobilisations WHERE COALESCE(statut,'') <> 'annulee'" )->fetchColumn();
			} catch ( \Throwable $e ) { $nbFiches = 0; }
			if ( $nbFiches > 0 ) {
				$rap = FKC_Immobilisation::rapprochement( $d2 );
				if ( empty( $rap['concordant'] ) ) {
					$anomalies[] = array( 'niveau' => 'information', 'texte' => 'Le registre des immobilisations et le bilan divergent sur '
						. count( $rap['ecarts'] ) . ' compte(s) au ' . date( 'd/m/Y', strtotime( $d2 ) ) . ' (valeur brute : registre '
						. fkc_money( $rap['brut']['registre'] ) . ', grand livre ' . fkc_money( $rap['brut']['gl'] ) . ' F CFA). La note 3 et le tableau des amortissements ne se recoupent pas — rapprochement dans Immobilisations.' );
				}
			}
		}

		/* ── Liasse déposée : a-t-elle changé depuis ? (1.854.0) ─────────── */
		$depot = self::depot( $annee );
		if ( $depot ) {
			$quand = date( 'd/m/Y', strtotime( $depot['depose_le'] ) ) . ( '' !== $depot['reference'] ? ' (réf. ' . $depot['reference'] . ')' : '' );
			if ( $depot['modifiee'] ) {
				$dr = (float) ( $depot['depose']['resultat'] ?? 0 ); $ar = (float) ( $depot['actuel']['resultat'] ?? 0 );
				$anomalies[] = array( 'niveau' => 'reserve', 'texte' => 'La liasse déposée le ' . $quand . ' ne correspond plus à la comptabilité'
					. ( $depot['ecritures_apres'] ? ' — ' . $depot['ecritures_apres'] . ' écriture(s) de l\'exercice passée(s) depuis' : '' )
					. ( abs( $ar - $dr ) >= 1 ? ' ; résultat déposé ' . fkc_money( $dr ) . ', actuel ' . fkc_money( $ar ) . ' F CFA' : '' )
					. '. Un dépôt rectificatif est nécessaire.' );
			} else {
				$anomalies[] = array( 'niveau' => 'information', 'texte' => 'Liasse déposée le ' . $quand . ' : la comptabilité n\'a pas changé depuis.' );
			}
		}

		return array(
			'annee'        => $annee,
			'du'           => $d1,
			'au'           => $d2,
			'libelle'      => class_exists( 'FKC_Exercice' ) ? FKC_Exercice::libelle( $annee ) : (string) $annee,
			'resultat_gl'  => round( $resultatGl, 2 ),
			'resultat_sn'  => round( (float) $sig['XI'], 2 ),
			'resultat_smt' => round( (float) $crSmt['kzc']['n'], 2 ),
			'tft_ecart'    => (float) $tft['ecart'],
			'ecart_smt'    => $ecartSmt,
			'ecart_sn'     => $ecartSn,
			'non_ventiles' => $nonVentiles,
			'notes_texte_manquantes' => $txt['manquantes'],
			'en_attente'   => $attente,
			'exercice_ouvert' => $ouvert,
			'exercice_clos'   => $clos,
			'fiscal'       => $fisc,
			'depot'        => $depot,
			'anomalies'    => $anomalies,
			/*
			 * DEUX QUESTIONS DIFFÉRENTES, DEUX RÉPONSES DIFFÉRENTES.
			 *
			 * `coherent` : ces états se tiennent-ils ARITHMÉTIQUEMENT ? Un
			 * bilan déséquilibré ou trois résultats qui divergent ne sont pas
			 * une liasse imparfaite, c'est un document faux. Rien de légitime
			 * ne sort de son édition : le produit refuse.
			 *
			 * `deposable` : ces états sont-ils COMPLETS ? Des écritures au
			 * journal temporaire, des à-nouveaux non reportés : l'arithmétique
			 * est juste, la matière est incomplète. Refuser serait absurde —
			 * on consulte et on exporte une liasse provisoire tous les mois de
			 * l'année. Le document part, mais estampillé.
			 *
			 * Confondre les deux ferait l'un des deux dégâts : soit bloquer un
			 * travail normal, soit laisser sortir un faux.
			 */
			'coherent'     => ! array_filter( $anomalies, function ( $a ) { return 'incoherence' === $a['niveau']; } ),
			'deposable'    => ! array_filter( $anomalies, function ( $a ) { return in_array( $a['niveau'], array( 'incoherence', 'reserve' ), true ); } ),
			'ok'           => ! array_filter( $anomalies, function ( $a ) { return 'incoherence' === $a['niveau']; } ),
		);
	}

	/**
	 * Chiffres clés de l'exercice, N et N-1 (1.853.0) — la bande d'indicateurs
	 * des écrans États financiers et Liasse DGI.
	 *
	 * Rien n'est recalculé à part : chaque chiffre est lu sur l'état qui le
	 * porte (bilan, cascade SN, compte de résultat SMT), si bien qu'un KPI ne
	 * peut pas contredire le tableau affiché dessous.
	 *
	 * @param int    $annee   Millésime.
	 * @param string $systeme 'smt' | 'sn'.
	 */
	public static function synthese( $annee, $systeme = 'smt' ) {
		return self::memo( 'synthese', array( $annee, $systeme ), array( __CLASS__, 'syntheseCalcul' ) );
	}

	protected static function syntheseCalcul( $annee, $systeme = 'smt' ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		list( $p1, $p2 ) = self::bornesEx( $annee - 1 );
		$sigN = self::sigBruts( $d1, $d2 ); $sigP = self::sigBruts( $p1, $p2 );
		if ( 'sn' === $systeme ) {
			$b = self::bilanSN( $annee );
			$L = array();
			foreach ( array_merge( $b['actif'], $b['passif'] ) as $l ) { $L[ $l['code'] ] = array( (float) $l['net'], (float) $l['n1'] ); }
			$tresoN = ( $L['BT'][0] ?? 0 ) - ( $L['DT'][0] ?? 0 );
			$tresoP = ( $L['BT'][1] ?? 0 ) - ( $L['DT'][1] ?? 0 );
			$cpN = $L['CP'][0] ?? 0; $cpP = $L['CP'][1] ?? 0;
			$caN = (float) $sigN['XB']; $caP = (float) $sigP['XB'];
		} else {
			$b = self::bilan( $annee );
			$tresoN = (float) $b['actif']['GD']['n'] + (float) $b['actif']['GF']['n'];
			$tresoP = (float) $b['actif']['GD']['n1'] + (float) $b['actif']['GF']['n1'];
			$cpN = (float) $b['passif']['HA']['n'] + (float) $b['passif']['HE']['n'] + (float) $b['passif']['HB']['n'];
			$cpP = (float) $b['passif']['HA']['n1'] + (float) $b['passif']['HE']['n1'] + (float) $b['passif']['HB']['n1'];
			$cr = self::resultat( $annee );
			$caN = (float) $cr['produits']['KX']['n']; $caP = (float) $cr['produits']['KX']['n1'];
		}
		$resN = self::resultatNet( $d1, $d2 ); $resP = self::resultatNet( $p1, $p2 );
		$kpi = function ( $n, $p ) {
			return array( 'n' => round( $n, 2 ), 'n1' => round( $p, 2 ),
				'var' => abs( $p ) > 0.004 ? round( ( $n - $p ) / abs( $p ) * 100, 1 ) : null );
		};
		return array(
			'ca'         => $kpi( $caN, $caP ),
			'resultat'   => $kpi( $resN, $resP ),
			'marge'      => array( 'n' => abs( $caN ) > 0.004 ? round( $resN / $caN * 100, 1 ) : null ),
			'total'      => $kpi( (float) $b['total_actif']['n'], (float) $b['total_actif']['n1'] ),
			'tresorerie' => $kpi( $tresoN, $tresoP ),
			'capitaux'   => $kpi( $cpN, $cpP ),
		);
	}

	/* ══ DÉPÔT DE LA LIASSE ET EMPREINTE (1.854.0) ══════════════════════════
	 *
	 * Une liasse déposée à la DGI est un document figé. Le grand livre, lui,
	 * ne l'est pas : une écriture passée après le dépôt — une facture oubliée,
	 * une correction d'inventaire — change la liasse que le logiciel édite,
	 * et plus rien ne rappelait qu'elle ne correspond plus à celle que
	 * l'administration détient.
	 *
	 * Au dépôt, on fige une EMPREINTE : le condensat des soldes de tous les
	 * comptes sur N et N-1 (la matière de chaque état), de l'annexe
	 * descriptive et de l'identification du dossier. Tant qu'elle concorde,
	 * la liasse éditée EST la liasse déposée ; dès qu'elle diverge, le
	 * contrôle le dit, chiffres à l'appui, et appelle un dépôt rectificatif.
	 */

	/** Table des dépôts (créée à la demande). */
	public static function ensureDepots() {
		static $pret = false;
		if ( $pret ) { return true; }
		try {
			FKC_DB::conn()->exec(
				'CREATE TABLE IF NOT EXISTS liasse_depots(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					annee INTEGER NOT NULL,
					systeme TEXT NOT NULL,
					empreinte TEXT NOT NULL,
					resume TEXT,
					reference TEXT,
					depose_le TEXT NOT NULL,
					depose_par INTEGER,
					created_at TEXT DEFAULT(datetime(\'now\',\'localtime\'))
				);
				CREATE INDEX IF NOT EXISTS idx_liasse_depots_an ON liasse_depots(annee)'
			);
			return $pret = true;
		} catch ( \Throwable $e ) { return false; }
	}

	/** Empreinte de la liasse d'un exercice : identique tant que rien de ce qu'elle montre n'a changé. */
	public static function empreinte( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		list( $p1, $p2 ) = self::bornesEx( $annee - 1 );
		$norm = function ( array $m ) {
			$o = array();
			foreach ( $m as $k => $v ) { if ( abs( (float) $v ) >= 0.005 ) { $o[ (string) $k ] = round( (float) $v, 2 ); } }
			ksort( $o, SORT_STRING );
			return $o;
		};
		$txt = array();
		foreach ( (array) ( self::notesTexte( $annee )['notes'] ?? array() ) as $n ) { $txt[ (string) $n['cle'] ] = trim( (string) $n['contenu'] ); }
		ksort( $txt, SORT_STRING );
		$e = self::entete( $annee );
		$matiere = array(
			'v' => 1, 'du' => $d1, 'au' => $d2,
			'n' => $norm( self::soldesPeriode( $d1, $d2 ) ),
			'n1' => $norm( self::soldesPeriode( $p1, $p2 ) ),
			'notes' => $txt, 'ncc' => $e['ncc'], 'societe' => $e['societe'],
		);
		return hash( 'sha256', json_encode( $matiere ) );
	}

	/** Chiffres clés retenus avec un dépôt, pour dire ce qui a bougé. */
	protected static function resumeDepot( $annee, $systeme ) {
		$sy = self::synthese( $annee, $systeme );
		return array(
			'resultat' => $sy['resultat']['n'], 'total_bilan' => $sy['total']['n'],
			'ca' => $sy['ca']['n'], 'tresorerie' => $sy['tresorerie']['n'],
		);
	}

	/**
	 * Marque la liasse comme déposée.
	 *
	 * Refusé sur une liasse incohérente : marquer « déposé » un document faux
	 * donnerait une valeur de référence à des chiffres qui n'en ont pas.
	 *
	 * @return array{bool,string}
	 */
	public static function deposer( $annee, $systeme, $reference = '', $date = null ) {
		$annee = (int) $annee; $systeme = ( 'sn' === $systeme ) ? 'sn' : 'smt';
		if ( ! self::ensureDepots() ) { return array( false, 'Registre des dépôts indisponible.' ); }
		$ctrl = self::controle( $annee );
		if ( empty( $ctrl['coherent'] ) ) {
			return array( false, 'Liasse incohérente : elle ne peut pas être marquée déposée. Corrigez d\'abord les écarts signalés.' );
		}
		$date = ( $date && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) ? (string) $date : date( 'Y-m-d' );
		FKC_DB::q(
			'INSERT INTO liasse_depots(annee,systeme,empreinte,resume,reference,depose_le,depose_par) VALUES(?,?,?,?,?,?,?)',
			array( $annee, $systeme, self::empreinte( $annee ), json_encode( self::resumeDepot( $annee, $systeme ) ),
				mb_substr( trim( (string) $reference ), 0, 80 ), $date . ' ' . date( 'H:i:s' ),
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
		);
		return array( true, 'Liasse ' . strtoupper( $systeme ) . ' ' . $annee . ' marquée déposée le ' . date( 'd/m/Y', strtotime( $date ) )
			. ( '' !== trim( (string) $reference ) ? ' (réf. ' . trim( (string) $reference ) . ')' : '' ) . ' : son empreinte est figée.' );
	}

	/** Historique des dépôts d'un exercice, du plus récent au plus ancien. */
	public static function depots( $annee ) {
		if ( ! self::ensureDepots() ) { return array(); }
		try {
			$rows = FKC_DB::q( 'SELECT * FROM liasse_depots WHERE annee=? ORDER BY depose_le DESC, id DESC', array( (int) $annee ) )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		foreach ( $rows as &$r ) { $r['resume'] = json_decode( (string) $r['resume'], true ) ?: array(); }
		return $rows;
	}

	/**
	 * Dernier dépôt de l'exercice et sa concordance avec la liasse actuelle.
	 *
	 * @return array|null null si jamais déposée.
	 */
	public static function depot( $annee, $systeme = null ) {
		$annee = (int) $annee;
		$liste = self::depots( $annee );
		if ( ! $liste ) { return null; }
		$d = $liste[0];
		$sys = $systeme ? ( 'sn' === $systeme ? 'sn' : 'smt' ) : (string) $d['systeme'];
		$modifiee = ! hash_equals( (string) $d['empreinte'], self::empreinte( $annee ) );
		$actuel = $modifiee ? self::resumeDepot( $annee, (string) $d['systeme'] ) : $d['resume'];
		$apres = 0;
		try {
			list( $d1, $d2 ) = self::bornesEx( $annee );
			$apres = (int) FKC_DB::q( 'SELECT COUNT(*) FROM ecritures WHERE date_ecriture BETWEEN ? AND ? AND created_at > ?',
				array( $d1, $d2, (string) $d['depose_le'] ) )->fetchColumn();
		} catch ( \Throwable $e ) {}
		return array(
			'id' => (int) $d['id'], 'systeme' => (string) $d['systeme'], 'systeme_affiche' => $sys,
			'reference' => (string) $d['reference'], 'depose_le' => (string) $d['depose_le'],
			'modifiee' => $modifiee, 'depose' => $d['resume'], 'actuel' => $actuel,
			'ecritures_apres' => $apres, 'nb_depots' => count( $liste ),
		);
	}

	/* ══ RAPPROCHEMENT AVEC LE MODULE FISCALITÉ (1.854.0) ══════════════════
	 *
	 * La liasse et les déclarations fiscales disent deux fois la même chose :
	 * l'impôt sur le résultat (ligne RS, comptes 89) doit être celui de la
	 * déclaration d'IS, et le chiffre d'affaires (XB) celui qui a servi de
	 * base aux déclarations de TVA. Un écart n'est pas forcément une erreur
	 * — exportations et opérations exonérées sortent de la base TVA, un
	 * avoir de fin d'exercice peut être déclaré le mois suivant —, mais il
	 * se JUSTIFIE, et c'est la première question d'un contrôle fiscal.
	 */
	public static function rapprochementFiscal( $annee ) {
		$annee = (int) $annee;
		list( $d1, $d2 ) = self::bornesEx( $annee );
		$sig = self::sigBruts( $d1, $d2 );
		$out = array( 'disponible' => false, 'ca_liasse' => round( (float) $sig['XB'], 2 ), 'is_liasse' => round( (float) $sig['RS'], 2 ),
			'ca_tva' => null, 'mois_tva' => 0, 'mois_exercice' => self::dureeMois( $d1, $d2 ),
			'is_declare' => null, 'is_statut' => null, 'is_id' => null );
		try {
			$deb = (int) date( 'Y', strtotime( $d1 ) ) * 100 + (int) date( 'n', strtotime( $d1 ) );
			$fin = (int) date( 'Y', strtotime( $d2 ) ) * 100 + (int) date( 'n', strtotime( $d2 ) );
			$r = FKC_DB::q(
				"SELECT COUNT(DISTINCT annee*100+mois) n, COALESCE(SUM(base),0) b FROM declarations_fiscales
				 WHERE type='TVA' AND statut<>'annulee' AND (annee*100+mois) BETWEEN CAST(? AS INTEGER) AND CAST(? AS INTEGER)",
				array( $deb, $fin )
			)->fetch();
			$out['disponible'] = true;
			$out['mois_tva'] = (int) ( $r['n'] ?? 0 );
			if ( $out['mois_tva'] > 0 ) { $out['ca_tva'] = round( (float) $r['b'], 2 ); }
			$is = FKC_DB::q(
				"SELECT id, statut, montant_declare, montant_calcule FROM declarations_fiscales
				 WHERE type='IS' AND statut<>'annulee' AND annee=? ORDER BY id DESC LIMIT 1",
				array( $annee )
			)->fetch();
			if ( $is ) {
				$m = (float) $is['montant_declare'];
				$out['is_declare'] = round( $m > 0 ? $m : (float) $is['montant_calcule'], 2 );
				$out['is_statut'] = (string) $is['statut'];
				$out['is_id'] = (int) $is['id'];
			}
		} catch ( \Throwable $e ) { /* module Fiscalité absent : rien à rapprocher */ }
		$out['ecart_ca'] = null === $out['ca_tva'] ? null : round( $out['ca_liasse'] - $out['ca_tva'], 2 );
		$out['ecart_is'] = null === $out['is_declare'] ? null : round( $out['is_liasse'] - $out['is_declare'], 2 );
		return $out;
	}

	/**
	 * Mention à porter sur un document édité — vide si la liasse est déposable.
	 *
	 * Un CSV part par courriel, une impression circule en papier : ni l'un ni
	 * l'autre n'emporte le bandeau de l'écran. La mention voyage avec le
	 * document, y compris dans le nom du fichier, pour qu'on ne puisse pas
	 * confondre une liasse provisoire avec la liasse définitive six mois plus
	 * tard.
	 */
	public static function mention( array $controle ) {
		if ( empty( $controle['coherent'] ) ) { return 'NON CONFORME'; }
		if ( empty( $controle['deposable'] ) ) { return 'PROVISOIRE'; }
		return '';
	}

	/**
	 * Écritures de la période encore au journal temporaire — donc absentes des
	 * états. Le brouillard est générique : on ne l'interroge que sur les dates.
	 */
	public static function enAttente( $d1, $d2 ) {
		$vide = array( 'nb' => 0, 'montant' => 0.0 );
		try {
			$r = FKC_DB::q(
				'SELECT COUNT(DISTINCT b.id) nb, COALESCE(SUM(l.debit),0) m
				 FROM ecritures_brouillon b
				 LEFT JOIN ecriture_brouillon_lignes l ON l.brouillon_id=b.id
				 WHERE b.date_ecriture BETWEEN ? AND ?',
				array( (string) $d1, (string) $d2 )
			)->fetch();
		} catch ( \Throwable $e ) { return $vide; }
		if ( ! $r ) { return $vide; }
		return array( 'nb' => (int) $r['nb'], 'montant' => (float) $r['m'] );
	}

	/** Vrai s'il existe au moins une écriture antérieure à l'ouverture de l'exercice. */
	protected static function mouvementsAvant( $d1 ) {
		try {
			return (bool) FKC_DB::q(
				'SELECT 1 FROM ecritures WHERE date_ecriture < ? LIMIT 1',
				array( (string) $d1 )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return false; }
	}

	/**
	 * COMP-CHARGES — État complémentaire DGI : détail des charges (classe 6) par nature,
	 * regroupées sous les sous-totaux RA…RK, avec variation N/N-1 en valeur et en %.
	 */
	public static function compCharges( $annee ) {
		return self::memo( 'compCharges', array( $annee ), array( __CLASS__, 'compChargesCalcul' ) );
	}

	protected static function compChargesCalcul( $annee ) {
		$annee = (int) $annee; $n1 = $annee - 1;
		$pN = array( self::bornesEx( $annee )[0], self::bornesEx( $annee )[1] );
		$pP = array( self::bornesEx( $n1 )[0], self::bornesEx( $n1 )[1] );
		// Groupes : [code sous-total, libellé, [préfixes]]
		$groupes = array(
			array( 'RA', 'Achats de marchandises', array( '601' ) ),
			array( 'RB', 'Variation de stocks de marchandises', array( '6031' ) ),
			array( 'RC', 'Achats de matières premières et fournitures liées', array( '602' ) ),
			array( 'RD', 'Variation de stocks de matières premières', array( '6032' ) ),
			array( 'RE', 'Autres achats', array( '604', '605', '608' ) ),
			array( 'RF', 'Variation de stocks d\'autres approvisionnements', array( '6033' ) ),
			array( 'RG', 'Transports', array( '61' ) ),
			array( 'RH', 'Services extérieurs', array( '62', '63' ) ),
			array( 'RI', 'Impôts et taxes', array( '64' ) ),
			array( 'RJ', 'Autres charges', array( '65' ) ),
			array( 'RK', 'Charges de personnel', array( '66' ) ),
			array( 'RM', 'Frais financiers et charges assimilées', array( '67' ) ),
			/*
			 * RL et RN étaient fondus dans une seule ligne « 68, 69 », alors
			 * que le compte de résultat SN les sépare (RL = dotations
			 * d'exploitation 681/691, RN = dotations financières 687/697).
			 * Deux états de la même liasse donnaient donc deux ventilations
			 * différentes des mêmes comptes.
			 */
			array( 'RL', 'Dotations aux amortissements, provisions et dépréciations d\'exploitation', array( '681', '691' ) ),
			array( 'RN', 'Dotations aux provisions et dépréciations financières', array( '687', '697' ) ),
		);
		$variation = function ( $n, $p ) {
			$val = $n - $p;
			$pct = abs( $p ) > 0.004 ? round( $val / abs( $p ) * 100, 1 ) : null;
			return array( 'val' => $val, 'pct' => $pct );
		};
		/*
		 * DÉTAIL ET SOUS-TOTAUX VIENNENT DE LA MÊME CARTE (1.853.0).
		 *
		 * Le détail était relu par une requête à part, qui additionnait TOUTES
		 * les écritures — y compris celle de détermination du résultat, qui
		 * solde la classe 6 vers 131/139. Après l'étape 4 de la clôture, chaque
		 * compte affichait donc 0 alors que son sous-total, lu par net(),
		 * restait juste : un état de détail qui ne détaillait plus rien, sur
		 * l'exercice même qu'on dépose.
		 *
		 * Le rattachement suit désormais ligneResultat(), c'est-à-dire la ligne
		 * du compte de résultat SN — repli compris. COMP-CHARGES et le compte
		 * de résultat ne peuvent plus ventiler un même compte différemment, et
		 * le total vaut la classe 6 entière par construction.
		 */
		$sN = self::soldesClasse( '6', $pN[0], $pN[1] );
		$sP = self::soldesClasse( '6', $pP[0], $pP[1] );
		$nums = array_unique( array_merge( array_keys( $sN ), array_keys( $sP ) ) );
		sort( $nums, SORT_STRING );
		$libelles = self::libellesComptes();
		$parCode = array();
		foreach ( $nums as $num ) {
			$code = self::ligneResultat( $num, $repli );
			if ( null === $code ) { $code = 'RJ'; $repli = true; }
			$n = (float) ( $sN[ $num ] ?? 0.0 ); $p = (float) ( $sP[ $num ] ?? 0.0 );
			$parCode[ $code ][] = array( 'numero' => (string) $num, 'libelle' => $libelles[ (string) $num ] ?? '',
				'n' => $n, 'n1' => $p, 'var' => $variation( $n, $p ), 'repli' => (bool) $repli );
		}
		$out = array(); $totN = 0.0; $totP = 0.0;
		foreach ( $groupes as $g ) {
			$lignes = $parCode[ $g[0] ] ?? array();
			unset( $parCode[ $g[0] ] );
			$gn = 0.0; $gp = 0.0;
			foreach ( $lignes as $l ) { $gn += $l['n']; $gp += $l['n1']; }
			$out[] = array( 'code' => $g[0], 'libelle' => $g[1], 'n' => $gn, 'n1' => $gp, 'var' => $variation( $gn, $gp ), 'lignes' => $lignes );
			$totN += $gn; $totP += $gp;
		}
		// Filet : une ligne de résultat hors des groupes ci-dessus reste visible.
		foreach ( $parCode as $code => $lignes ) {
			$gn = 0.0; $gp = 0.0;
			foreach ( $lignes as $l ) { $gn += $l['n']; $gp += $l['n1']; }
			$out[] = array( 'code' => $code, 'libelle' => 'Autres charges non rattachées à une ligne de la liasse',
				'n' => $gn, 'n1' => $gp, 'var' => $variation( $gn, $gp ), 'lignes' => $lignes, 'reste' => true );
			$totN += $gn; $totP += $gp;
		}
		return array( 'annee' => $annee, 'annee_n1' => $n1, 'groupes' => $out, 'total' => $totN, 'total_n1' => $totP, 'var_total' => $variation( $totN, $totP ) );
	}
}
