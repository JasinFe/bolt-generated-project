<?php
/**
 * Immobilisations : fiches, plan d'amortissement linéaire (prorata temporis),
 * dotations (6813/28) et cessions. @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Immobilisation {

	public static function all() { return FKC_DB::q( 'SELECT * FROM immobilisations ORDER BY date_acquisition DESC, id DESC' )->fetchAll(); }

	/**
	 * Seuil d'immobilisation : montant minimum d'acquisition pour qu'un bien soit
	 * immobilisé et amorti. En-dessous, le bien est passé directement en charges
	 * (SYSCOHADA : biens de faible valeur ; montant fixé selon les règles DGI en vigueur).
	 * 0 = aucun seuil (désactivé). Paramètre société 'immo_seuil_amortissement'.
	 */
	public static function seuil() {
		$v = (float) FKC_License::param( 'immo_seuil_amortissement', '0' );
		return $v > 0 ? $v : 0.0;
	}
	public static function setSeuil( $v ) {
		$v = (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) $v );
		FKC_License::setParam( 'immo_seuil_amortissement', (string) max( 0, $v ) );
	}
	/** Vrai si la valeur est strictement sous le seuil actif (et qu'un seuil est défini). */
	public static function sousSeuil( $valeur ) {
		$s = self::seuil();
		return $s > 0 && (float) $valeur < $s;
	}
	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM immobilisations WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	/**
	 * MONTANT SAISI → NOMBRE (1.855.0).
	 *
	 * Les champs « Valeur d'acquisition », « Prix de cession »… sont des
	 * champs texte : l'utilisateur y tape « 1 500 000 », comme partout
	 * ailleurs dans le produit. `(float) '1 500 000'` vaut 1 — le bien était
	 * enregistré pour un franc, son plan d'amortissement avec. On accepte les
	 * espaces (y compris insécables), la virgule décimale et les points de
	 * milliers.
	 */
	public static function nombre( $v ) {
		if ( is_int( $v ) || is_float( $v ) ) { return (float) $v; }
		$s = preg_replace( '/[\s\x{00A0}\x{202F}]|F\s*CFA|FCFA|XOF/iu', '', trim( (string) $v ) );
		if ( '' === $s ) { return 0.0; }
		$virg = substr_count( $s, ',' ); $pts = substr_count( $s, '.' );
		if ( $virg && $pts ) {
			if ( strrpos( $s, ',' ) > strrpos( $s, '.' ) ) { $s = str_replace( ',', '.', str_replace( '.', '', $s ) ); }
			else { $s = str_replace( ',', '', $s ); }
		} elseif ( $virg ) {
			$s = ( 1 === $virg ) ? str_replace( ',', '.', $s ) : str_replace( ',', '', $s );
		} elseif ( $pts > 1 ) {
			$s = str_replace( '.', '', $s );
		}
		return is_numeric( $s ) ? (float) $s : 0.0;
	}

	/**
	 * LE BIEN S'AMORTIT-IL ? (1.855.0)
	 *
	 * Un terrain nu, des titres de participation, une avance ou une
	 * immobilisation en cours ne s'amortissent pas : ils se déprécient. Le
	 * formulaire le savait (il vidait les comptes d'amortissement) ; le modèle,
	 * non — il remettait 284100 / 681300 par défaut et calculait un plan.
	 * Un terrain de 20 millions s'amortissait ainsi en deux ans.
	 */
	public static function estAmortissable( $immo ) {
		if ( is_array( $immo ) && 'non_amortissable' === (string) ( $immo['methode'] ?? '' ) ) { return false; }
		$compte = is_array( $immo ) ? (string) ( $immo['compte_immo'] ?? '' ) : (string) $immo;
		if ( class_exists( 'FKC_MappingAmortissement' ) ) {
			$m = FKC_MappingAmortissement::pour( $compte );
			return ! empty( $m['amortissable'] );
		}
		return '2' === substr( $compte, 0, 1 ) && ! in_array( substr( $compte, 0, 2 ), array( '22', '25', '26', '27' ), true );
	}

	/** Fiche active : ni cédée, ni annulée. */
	public static function estEnService( $immo ) {
		return is_array( $immo ) && ! in_array( (string) ( $immo['statut'] ?? '' ), array( 'cede', self::STATUT_ANNULEE ), true );
	}

	public static function create( $d ) {
		foreach ( array( 'valeur_acquisition', 'valeur_residuelle', 'duree_annees' ) as $k ) {
			if ( isset( $d[ $k ] ) ) { $d[ $k ] = self::nombre( $d[ $k ] ); }
		}
		/*
		 * LES TROIS COMPTES SE DÉDUISENT DU PREMIER.
		 *
		 * Le formulaire pré-remplissait les trois champs avec 241000 / 284100 /
		 * 681300 pour tout le monde. On saisissait un logiciel en 213100 sans
		 * penser à corriger les deux autres, et son amortissement partait en
		 * 2841 « Amortissements du matériel industriel ». Le total du tableau
		 * des amortissements restait juste ; sa ventilation, non — et c'est la
		 * ventilation qu'un contrôleur regarde.
		 *
		 * FKC_MappingAmortissement applique le miroir du référentiel
		 * (2AB → 28AB) et ne corrige que ce qui est manifestement incohérent :
		 * un choix délibéré du comptable est respecté.
		 */
		if ( class_exists( 'FKC_MappingAmortissement' ) ) {
			list( $d, $corrections ) = FKC_MappingAmortissement::completer( $d );
			if ( $corrections ) {
				foreach ( $corrections as $champ => $c ) {
					/* « retenu » = le choix du comptable l'a emporté sur la règle
					   et a été mémorisé ; « corrige » = le compte saisi n'était
					   pas de la bonne catégorie et a été remplacé. */
					$type = $c[2] ?? 'corrige';
					fkc_log( 'Immobilisation : ' . $champ . ' '
						. ( 'retenu' === $type ? 'rattachement retenu ' : 'corrigé ' )
						. $c[0] . ' → ' . $c[1] . ' (compte ' . ( $d['compte_immo'] ?? '' ) . ')', 'INFO' );
				}
			}
		}
		$compteImmo   = ( $d['compte_immo'] ?? '' ) ?: '241000';
		$amortissable = self::estAmortissable( $compteImmo );
		FKC_DB::q(
			'INSERT INTO immobilisations(code,libelle,compte_immo,compte_amort,compte_dotation,date_acquisition,valeur_acquisition,valeur_residuelle,duree_annees,methode,ecriture_acq_id,ligne_acq_id,division_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array(
				// Le code d'immobilisation sert d'étiquette d'inventaire et de
				// clé de récolement : une fiche sans code n'est pas scannable,
				// et « null » se retrouve à l'écran à la place d'un repère.
				class_exists( 'FKC_CodeAuto' )
					? FKC_CodeAuto::ou( $d['code'] ?? '', 'immobilisations', FKC_CodeAuto::prefixe( 'immobilisations', 'IMMO-' ) )
					: ( trim( (string) ( $d['code'] ?? '' ) ) ?: null ),
				trim( (string) ( $d['libelle'] ?? '' ) ),
				$compteImmo,
				// Bien non amortissable (1.855.0) : ni compte d'amortissement,
				// ni compte de dotation — plus de 284100 / 681300 par défaut.
				$amortissable ? ( ( $d['compte_amort'] ?? '' ) ?: '284100' ) : '',
				$amortissable ? ( ( $d['compte_dotation'] ?? '' ) ?: '681300' ) : '',
				$d['date_acquisition'], (float) $d['valeur_acquisition'], (float) ( $d['valeur_residuelle'] ?? 0 ),
				max( 0.5, (float) ( $d['duree_annees'] ?? 1 ) ), $amortissable ? 'lineaire' : 'non_amortissable',
				isset( $d['ecriture_acq_id'] ) && $d['ecriture_acq_id'] ? (int) $d['ecriture_acq_id'] : null,
				/*
				 * LA LIGNE, ET PAS SEULEMENT L'ÉCRITURE (1.730.0). Une écriture
				 * d'apport en nature porte dix biens sur dix lignes ; ne retenir
				 * que l'écriture revenait à dire « cette pièce a servi », donc à
				 * faire disparaître les neuf autres biens de l'écran d'import.
				 */
				isset( $d['ligne_acq_id'] ) && $d['ligne_acq_id'] ? (int) $d['ligne_acq_id'] : null,
				! empty( $d['division_id'] ) ? (int) $d['division_id'] : null,
			)
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		// Code-barres d'inventaire, attribué dès la création : c'est ce qui rend
		// l'actif scannable au récolement, sans que personne ait à y penser plus
		// tard. Il s'ajoute au code interne, il ne le remplace pas.
		if ( class_exists( 'FKC_ImmoRecolement' ) ) {
			try { FKC_ImmoRecolement::attribuerCode( $id ); } catch ( \Throwable $e ) {}
		}
		return $id;
	}

	/**
	 * CORRIGER LES COMPTES D'UNE IMMOBILISATION DÉJÀ CRÉÉE (1.726.0).
	 *
	 * Les trois comptes — immobilisation, amortissement, dotation — étaient
	 * figés à la création. Or c'est justement là qu'on se trompe : au moment
	 * où l'on saisit la fiche, on ne sait pas toujours dans quelle rubrique le
	 * bien tombera, et une erreur de compte d'amortissement ne se voit qu'au
	 * tableau des amortissements de la clôture — parfois un an plus tard.
	 * N'offrir aucune correction obligeait à supprimer la fiche et à la
	 * ressaisir, ce qui détruit son historique de dotations.
	 *
	 * CE QUE CETTE MÉTHODE NE FAIT PAS, ET C'EST VOULU : elle ne réécrit
	 * AUCUNE écriture passée. Les dotations déjà comptabilisées restent sur
	 * les anciens comptes — réécrire une écriture validée n'est pas une
	 * correction, c'est une falsification. La méthode dit combien il y en a et
	 * pour quel montant ; le reclassement se passe par une OD, que
	 * `reclassementPropose()` prépare.
	 *
	 * @return array{bool,string,array} ( ok, message, comptes déjà employés )
	 */
	public static function corrigerComptes( $id, array $d ) {
		$immo = self::find( $id );
		if ( ! $immo ) { return array( false, 'Immobilisation introuvable.', array() ); }

		$champs = array(
			'compte_immo'     => array( 'Compte d\'immobilisation', array( '2' ) ),
			'compte_amort'    => array( 'Compte d\'amortissement',   array( '28', '29' ) ),
			'compte_dotation' => array( 'Compte de dotation',        array( '68', '69' ) ),
		);
		$maj = array(); $libelles = array();
		foreach ( $champs as $col => $spec ) {
			$num = trim( (string) ( $d[ $col ] ?? '' ) );
			if ( '' === $num || $num === (string) $immo[ $col ] ) { continue; }

			$c = FKC_Compte::byNumero( $num );
			if ( ! $c ) {
				return array( false, $spec[0] . ' : le compte ' . $num . ' n\'existe pas au plan comptable.', array() );
			}
			if ( 'titre' === (string) ( $c['type'] ?? '' ) ) {
				return array( false, $spec[0] . ' : ' . $num . ' est un compte de regroupement, on n\'impute pas dessus.', array() );
			}
			/*
			 * LA CLASSE EST CONTRÔLÉE. Une dotation sur un compte de classe 4
			 * passerait sans bruit et ne se verrait qu'au compte de résultat,
			 * où personne ne cherche l'erreur d'une fiche d'immobilisation.
			 */
			$ok = false;
			foreach ( $spec[1] as $prefixe ) { if ( 0 === strpos( $num, $prefixe ) ) { $ok = true; break; } }
			if ( ! $ok ) {
				return array( false, $spec[0] . ' : ' . $num . ' ne relève pas des comptes attendus ('
					. implode( ' ou ', $spec[1] ) . 'xx).', array() );
			}
			$maj[ $col ] = $num;
			$libelles[]  = $spec[0] . ' : ' . $immo[ $col ] . ' → ' . $num;
		}
		if ( ! $maj ) { return array( false, 'Aucun compte modifié.', array() ); }

		$sets = array(); $args = array();
		foreach ( $maj as $col => $val ) { $sets[] = $col . '=?'; $args[] = $val; }
		$args[] = (int) $id;
		FKC_DB::q( 'UPDATE immobilisations SET ' . implode( ',', $sets ) . ' WHERE id=?', $args );

		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'immo_comptes', 'immo=' . (int) $id . ' · ' . implode( ' · ', $libelles ) );
		}
		/*
		 * LA CORRECTION SERT AUSSI AUX FICHES SUIVANTES (1.729.0). Corriger un
		 * rattachement une fois par fiche serait un travail sans fin : le
		 * couple compte d'immobilisation → compte d'amortissement est mémorisé,
		 * et la prochaine immobilisation sur le même compte le proposera.
		 */
		if ( isset( $maj['compte_amort'] ) && class_exists( 'FKC_MappingAmortissement' ) ) {
			FKC_MappingAmortissement::definirCorrespondance(
				(string) ( $maj['compte_immo'] ?? $immo['compte_immo'] ), $maj['compte_amort'] );
		}

		$passe = self::dotationsComptabilisees( $id );
		$msg = implode( ' · ', $libelles ) . '.';
		if ( $passe['nombre'] > 0 ) {
			$msg .= ' ' . $passe['nombre'] . ' dotation(s) déjà comptabilisée(s) pour '
				. fkc_money( $passe['montant'] ) . ' restent sur les anciens comptes :'
				. ' les écritures passées ne sont pas réécrites. Passez une OD de reclassement.';
		}
		return array( true, $msg, $passe );
	}

	/** Ce qui a déjà été comptabilisé sur les anciens comptes. */
	public static function dotationsComptabilisees( $id ) {
		try {
			$r = FKC_DB::q(
				"SELECT COUNT(*) n, COALESCE(SUM(montant),0) m FROM immo_dotations
				 WHERE immobilisation_id=? AND ecriture_id IS NOT NULL",
				array( (int) $id )
			)->fetch();
			return array( 'nombre' => (int) ( $r['n'] ?? 0 ), 'montant' => (float) ( $r['m'] ?? 0 ) );
		} catch ( \Throwable $e ) { return array( 'nombre' => 0, 'montant' => 0.0 ); }
	}

	/**
	 * PROPOSE L'OD DE RECLASSEMENT — une proposition, jamais une écriture.
	 *
	 * On rend les quatre lignes telles qu'elles devraient être passées :
	 * l'ancien compte est soldé, le nouveau reçoit le cumul. Le comptable les
	 * relit, les date et les valide lui-même depuis la saisie d'écriture. Le
	 * produit ne passe pas d'écriture à sa place sur des exercices peut-être
	 * déjà arrêtés — il n'a aucun moyen de savoir lesquels le sont pour de
	 * bon.
	 *
	 * @return array Lignes proposées (compte, libelle, debit, credit).
	 */
	public static function reclassementPropose( $immo, $ancienAmort, $ancienDotation ) {
		$cumul = round( self::cumulAmorti( $immo['id'] ), 2 );
		$lignes = array();
		if ( $cumul <= 0 ) { return $lignes; }
		$lib = 'Reclassement ' . $immo['code'] . ' — ' . $immo['libelle'];
		if ( $ancienAmort && $ancienAmort !== $immo['compte_amort'] ) {
			$lignes[] = array( 'compte' => $ancienAmort, 'libelle' => $lib, 'debit' => $cumul, 'credit' => 0 );
			$lignes[] = array( 'compte' => $immo['compte_amort'], 'libelle' => $lib, 'debit' => 0, 'credit' => $cumul );
		}
		/*
		 * LA DOTATION N'EST PAS RECLASSÉE AU-DELÀ DE L'EXERCICE EN COURS.
		 * Un compte de charge des exercices antérieurs est soldé par le
		 * résultat : le reclasser aujourd'hui modifierait un résultat déjà
		 * arrêté. On ne propose donc rien pour les dotations passées, et on le
		 * dit à l'écran plutôt que de faire semblant.
		 */
		return $lignes;
	}

	/** Immobilisations encore en service. */
	public static function enService() {
		return FKC_DB::q( "SELECT * FROM immobilisations WHERE statut='en_service' ORDER BY libelle ASC" )->fetchAll();
	}

	/**
	 * Lance l'amortissement d'un exercice pour toutes les immobilisations en service
	 * dont la dotation n'est pas encore comptabilisée.
	 * @return array{int, int, float} ( int comptabilisees, int ignorees, float total )
	 */
	public static function lancerAmortissement( $exercice, $mois = null ) {
		$exercice = (int) $exercice;
		$mois = ( null === $mois || '' === $mois ) ? null : (int) $mois;
		$ok = 0; $skip = 0; $total = 0.0;
		foreach ( self::enService() as $im ) {
			// En mensuel, seul le mois demandé est regardé : les autres mois
			// de l'exercice restent à passer (1.765.0).
			if ( self::dotationExiste( $im['id'], $exercice, $mois ) ) { $skip++; continue; }
			$prevu = self::dotationPrevue( $im, $exercice, $mois );
			if ( $prevu <= 0 ) { $skip++; continue; }
			list( $r ) = self::comptabiliserDotation( $im, $exercice, $mois );
			if ( $r ) { $ok++; $total += $prevu; } else { $skip++; }
		}
		return array( $ok, $skip, $total );
	}

	/**
	 * Lignes d'écritures imputées sur un compte d'immobilisation (classe 2) au débit,
	 * non encore rattachées à une fiche immobilisation. Sert à « Importer depuis écriture ».
	 */
	/**
	 * LES LIGNES D'ACQUISITION PAS ENCORE RATTACHÉES À UNE FICHE.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LE DÉFAUT CORRIGÉ EN 1.730.0 : L'EXCLUSION SE FAISAIT PAR ÉCRITURE.
	 *
	 * La requête écartait toute écriture déjà citée par une fiche
	 * (`e.id NOT IN (…)`). Or un apport en nature à la constitution tient en
	 * UNE écriture de dix lignes — dix biens distincts, chacun méritant sa
	 * fiche et son plan d'amortissement. Dès qu'on rattachait le premier, les
	 * neuf autres disparaissaient de l'écran, qui annonçait alors : « Toutes
	 * les acquisitions de classe 2 sont déjà rattachées à une fiche ».
	 *
	 * Le message était doublement trompeur : il affirmait un fait faux, et il
	 * fermait la seule porte par laquelle ces biens pouvaient entrer. Neuf
	 * immobilisations restaient donc au bilan sans jamais s'amortir.
	 *
	 * L'exclusion porte désormais sur la LIGNE.
	 *
	 * LES FICHES ANTÉRIEURES n'ont pas de ligne enregistrée. Pour elles, on
	 * retire UNE ligne de leur écriture — celle dont le montant correspond à
	 * leur valeur d'acquisition, à défaut aucune. On préfère laisser
	 * apparaître une ligne déjà rattachée, que l'utilisateur reconnaîtra, à
	 * cacher neuf biens qu'il ne soupçonne pas.
	 */
	public static function ecrituresImmobilisables() {
		$lignes = FKC_DB::q(
			"SELECT l.id AS ligne_id, e.id AS ecriture_id, e.date_ecriture, e.piece, e.libelle AS ecriture_libelle,
				l.libelle AS ligne_libelle, l.debit, c.numero AS compte_numero, c.libelle AS compte_libelle
			 FROM ecriture_lignes l
			 JOIN ecritures e ON e.id=l.ecriture_id
			 JOIN comptes c ON c.id=l.compte_id
			 LEFT JOIN journaux j ON j.id=e.journal_id
			 WHERE c.numero LIKE '2%' AND l.debit > 0
			   /*
			    * CE QUI N'EST PAS UNE ACQUISITION (1.855.0) :
			    *  — les amortissements et dépréciations (28, 29), débités à la
			    *    cession : la reprise d'amortissement d'un véhicule vendu
			    *    était proposée comme un bien à immobiliser ;
			    *  — les À-NOUVEAUX, qui re-débitent chaque année tout l'actif
			    *    immobilisé : chaque bien réapparaissait, un an après l'autre ;
			    *  — les écritures de cession ou de dotation du module lui-même,
			    *    les contre-passations et les écritures contre-passées.
			    */
			   AND substr(c.numero,1,2) NOT IN ('28','29')
			   AND COALESCE(j.code,'') <> 'AN' AND COALESCE(e.reference,'') NOT LIKE 'AN-%'
			   AND COALESCE(e.source,'') NOT IN ('anouveaux','immobilisations','reclassement','annulation')
			   AND COALESCE(e.type_ecriture,'normale') <> 'annulation'
			   AND NOT EXISTS (SELECT 1 FROM ecritures x WHERE x.reference = 'ANN#' || e.id)
			 ORDER BY e.date_ecriture DESC, e.id DESC, l.id ASC"
		)->fetchAll();
		if ( ! $lignes ) { return array(); }

		$prises = array();          // ligne_id déjà rattachée
		$legacy = array();          // fiches sans ligne : ecriture_id => [valeurs]
		try {
			$fiches = FKC_DB::q(
				'SELECT ecriture_acq_id, ligne_acq_id, valeur_acquisition FROM immobilisations
				 WHERE ecriture_acq_id IS NOT NULL OR ligne_acq_id IS NOT NULL'
			)->fetchAll();
		} catch ( \Throwable $e ) { $fiches = array(); }
		foreach ( $fiches as $f ) {
			if ( ! empty( $f['ligne_acq_id'] ) ) { $prises[ (int) $f['ligne_acq_id'] ] = true; continue; }
			if ( ! empty( $f['ecriture_acq_id'] ) ) {
				$legacy[ (int) $f['ecriture_acq_id'] ][] = round( (float) $f['valeur_acquisition'], 2 );
			}
		}

		$out = array();
		foreach ( $lignes as $l ) {
			$lid = (int) $l['ligne_id'];
			if ( isset( $prises[ $lid ] ) ) { continue; }
			$eid = (int) $l['ecriture_id'];
			if ( isset( $legacy[ $eid ] ) ) {
				$montant = round( (float) $l['debit'], 2 );
				$k = array_search( $montant, $legacy[ $eid ], true );
				if ( false !== $k ) { unset( $legacy[ $eid ][ $k ] ); continue; }
			}
			$out[] = $l;
		}
		return $out;
	}

	/** Plan d'amortissement linéaire (prorata temporis, base 360, mois de 30 j). */
	public static function plan( $immo ) {
		if ( ! self::estAmortissable( $immo ) ) { return array(); }
		$rows = self::planTheorique( $immo );
		/*
		 * UN BIEN CÉDÉ N'A PLUS DE PLAN APRÈS SA SORTIE (1.855.0).
		 *
		 * Le plan continuait comme si de rien n'était : le tableau des
		 * amortissements de l'extraction annonçait des dotations futures sur
		 * un bien vendu. Il s'arrête à l'exercice de cession, qui porte ce
		 * qui a réellement été doté — la dotation complémentaire comprise.
		 */
		if ( 'cede' === (string) ( $immo['statut'] ?? '' ) && ! empty( $immo['date_cession'] ) ) {
			$exC = self::exerciceDe( $immo['date_cession'] );
			$va = (float) $immo['valeur_acquisition'];
			$out = array(); $cumul = 0.0;
			foreach ( $rows as $r ) {
				if ( (int) $r['exercice'] > $exC ) { break; }
				if ( (int) $r['exercice'] === $exC ) {
					$r['dotation'] = self::doteSurExercice( (int) $immo['id'], $exC );
				}
				$cumul += (float) $r['dotation'];
				$r['cumul'] = $cumul; $r['vnc'] = $va - $cumul;
				$out[] = $r;
			}
			return $out;
		}
		return $rows;
	}

	/** Montant déjà enregistré en dotations sur un exercice (comptabilisé ou en attente). */
	public static function doteSurExercice( $id, $exercice ) {
		try {
			return (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant),0) FROM immo_dotations WHERE immobilisation_id=? AND exercice=?',
				array( (int) $id, (int) $exercice ) )->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/** Plan linéaire théorique, sans tenir compte d'une cession. */
	protected static function planTheorique( $immo ) {
		$va   = (float) $immo['valeur_acquisition'];
		$vr   = (float) $immo['valeur_residuelle'];
		$base = max( 0.0, $va - $vr );
		$duree = max( 0.5, (float) $immo['duree_annees'] );
		$annuite = $base / $duree;

		/*
		 * PRORATA TEMPORIS SUR L'EXERCICE, PAS SUR L'ANNÉE CIVILE (1.544.0).
		 *
		 * Le premier exercice d'amortissement court de la date de mise en
		 * service à la CLÔTURE, et non au 31 décembre. Chez un dossier
		 * clôturant au 30/06, un bien acquis en mai était amorti sur huit mois
		 * au lieu de deux : la première dotation était quatre fois trop
		 * forte, et tout le plan décalé d'un exercice.
		 *
		 * Base 360 conservée (usage OHADA), et le calcul redonne exactement
		 * l'ancien résultat sur un exercice calendaire.
		 */
		$ts = strtotime( $immo['date_acquisition'] );
		$y0 = self::exerciceDe( $immo['date_acquisition'] );
		$finEx = strtotime( self::finExercice( $y0 ) );
		$m = (int) date( 'n', $ts ); $j = min( 30, (int) date( 'j', $ts ) );
		$mFin = (int) date( 'n', $finEx ); $jFin = min( 30, (int) date( 'j', $finEx ) );
		// Nombre de mois pleins entre la date d'acquisition et la clôture.
		$moisEcart = ( (int) date( 'Y', $finEx ) - (int) date( 'Y', $ts ) ) * 12 + ( $mFin - $m );
		$joursAnnee1 = $moisEcart * 30 + ( $jFin - $j + 1 );
		$prorata1 = max( 0.0, min( 1.0, $joursAnnee1 / 360 ) );

		$rows = array(); $cumul = 0.0; $annee = $y0; $i = 0;
		while ( $cumul < $base - 0.005 && $i < 60 ) {
			$dot = ( $annee === $y0 ) ? $annuite * $prorata1 : $annuite;
			if ( $cumul + $dot > $base ) { $dot = $base - $cumul; }
			$dot = round( $dot );
			if ( $cumul + $dot > $base ) { $dot = $base - $cumul; }
			$cumul += $dot;
			$rows[] = array( 'exercice' => $annee, 'dotation' => $dot, 'cumul' => $cumul, 'vnc' => $va - $cumul );
			$annee++; $i++;
		}
		return $rows;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * AMORTISSEMENT MENSUEL (1.765.0)
	 *
	 * Le module ne savait comptabiliser qu'une dotation par EXERCICE, datée
	 * de la clôture. C'est l'usage d'un cabinet qui arrête les comptes une
	 * fois l'an ; ce n'est pas celui d'une entreprise qui suit son résultat
	 * au mois. Chez elle, onze mois affichaient une charge d'amortissement
	 * nulle, puis décembre en portait douze d'un coup : la marge mensuelle
	 * était fausse toute l'année, et juste une seule fois.
	 *
	 * La dotation mensuelle est un DÉCOUPAGE de l'annuité, jamais un calcul
	 * parallèle : la somme des mois d'un exercice redonne exactement la
	 * dotation annuelle du plan, au franc près, le dernier mois absorbant
	 * l'arrondi. Un dossier qui reste en annuel ne voit aucun changement.
	 *
	 * Le premier mois suit le prorata temporis déjà en place : un bien acquis
	 * le 15 porte la moitié d'un mois, en base 360 comme le reste du module.
	 * ═══════════════════════════════════════════════════════════════════ */

	/** 'annuelle' (défaut) ou 'mensuelle'. */
	public static function periodicite() {
		$v = class_exists( 'FKC_License' ) ? (string) FKC_License::param( 'immo_periodicite', 'annuelle' ) : 'annuelle';
		return 'mensuelle' === $v ? 'mensuelle' : 'annuelle';
	}

	public static function definirPeriodicite( $v ) {
		$v = 'mensuelle' === (string) $v ? 'mensuelle' : 'annuelle';
		if ( class_exists( 'FKC_License' ) ) { FKC_License::setParam( 'immo_periodicite', $v ); }
		return $v;
	}

	public static function mensuel() { return 'mensuelle' === self::periodicite(); }

	/**
	 * Découpe le plan annuel en mois.
	 *
	 * @return array lignes { exercice, mois, date, libelle_periode, dotation, cumul, vnc }
	 */
	public static function planMensuel( $immo ) {
		$va = (float) $immo['valeur_acquisition'];
		$ts = strtotime( (string) $immo['date_acquisition'] );
		$jAcq = min( 30, (int) date( 'j', $ts ) );
		$moisAcq = (int) date( 'n', $ts ); $anAcq = (int) date( 'Y', $ts );
		$rows = array(); $cumul = 0.0;

		foreach ( self::plan( $immo ) as $ex ) {
			$annuelle = (float) $ex['dotation'];
			if ( $annuelle <= 0 ) { continue; }
			$fin = strtotime( self::finExercice( (int) $ex['exercice'] ) );
			$debut = strtotime( '+1 day', strtotime( self::finExercice( (int) $ex['exercice'] - 1 ) ) );
			// Le premier exercice ne commence à amortir qu'à l'acquisition.
			$premier = strtotime( date( 'Y-m-01', $ts ) );
			if ( $debut < $premier ) { $debut = $premier; }

			/*
			 * POIDS DE CHAQUE MOIS. Un mois plein pèse 1, le mois
			 * d'acquisition pèse les jours restants sur 30. Les poids servent
			 * de clé de répartition : c'est l'annuité du plan qui commande le
			 * total, pas l'inverse.
			 */
			$mois = array(); $poids = array(); $somme = 0.0;
			$cur = $debut;
			while ( $cur <= $fin ) {
				$y = (int) date( 'Y', $cur ); $m = (int) date( 'n', $cur );
				$p = ( $y === $anAcq && $m === $moisAcq ) ? max( 0.0, ( 30 - $jAcq + 1 ) / 30 ) : 1.0;
				$mois[] = array( 'y' => $y, 'm' => $m );
				$poids[] = $p; $somme += $p;
				$cur = strtotime( '+1 month', $cur );
			}
			if ( $somme <= 0 ) { continue; }

			$reste = $annuelle; $n = count( $mois );
			foreach ( $mois as $i => $mm ) {
				$dot = ( $i === $n - 1 ) ? $reste : round( $annuelle * $poids[ $i ] / $somme );
				if ( $dot > $reste ) { $dot = $reste; }
				$reste -= $dot;
				if ( $dot <= 0 && $i !== $n - 1 ) { continue; }
				$cumul += $dot;
				$rows[] = array(
					'exercice' => (int) $ex['exercice'],
					'mois'     => (int) $mm['m'],
					'annee'    => (int) $mm['y'],
					'date'     => date( 'Y-m-t', mktime( 0, 0, 0, (int) $mm['m'], 1, (int) $mm['y'] ) ),
					'periode'  => sprintf( '%02d/%04d', $mm['m'], $mm['y'] ),
					'dotation' => $dot,
					'cumul'    => $cumul,
					'vnc'      => $va - $cumul,
				);
			}
		}
		return $rows;
	}

	/** Dotation prévue pour une période (mois = null → l'exercice entier). */
	public static function dotationPrevue( $immo, $exercice, $mois = null ) {
		if ( null === $mois ) {
			foreach ( self::plan( $immo ) as $r ) {
				if ( (int) $r['exercice'] === (int) $exercice ) { return (float) $r['dotation']; }
			}
			return 0.0;
		}
		foreach ( self::planMensuel( $immo ) as $r ) {
			if ( (int) $r['exercice'] === (int) $exercice && (int) $r['mois'] === (int) $mois ) { return (float) $r['dotation']; }
		}
		return 0.0;
	}

	/** Colonne `mois` d'immo_dotations, ajoutée à la demande (1.765.0). */
	protected static function assurerColonneMois() {
		static $fait = false;
		if ( $fait ) { return; }
		$fait = true;
		try {
			$cols = array();
			foreach ( FKC_DB::q( 'PRAGMA table_info(immo_dotations)' )->fetchAll() as $c ) { $cols[] = $c['name']; }
			if ( $cols && ! in_array( 'mois', $cols, true ) ) {
				FKC_DB::conn()->exec( 'ALTER TABLE immo_dotations ADD COLUMN mois INTEGER' );
			}
		} catch ( \Throwable $e ) { /* le mode annuel continue de fonctionner */ }
	}

	/** Année civile du mois d'un exercice (utile si l'exercice est décalé). */
	public static function anneeDuMois( $immo, $exercice, $mois ) {
		foreach ( self::planMensuel( $immo ) as $r ) {
			if ( (int) $r['exercice'] === (int) $exercice && (int) $r['mois'] === (int) $mois ) { return (int) $r['annee']; }
		}
		// Hors plan : l'exercice porte son millésime, sauf mois d'un exercice
		// décalé qui retombe sur l'année suivante.
		$fin = strtotime( self::finExercice( (int) $exercice ) );
		$mFin = (int) date( 'n', $fin );
		return ( 12 === $mFin || (int) $mois <= $mFin ) ? (int) date( 'Y', $fin ) : (int) date( 'Y', $fin ) - 1;
	}

	/** Une dotation ANNUELLE (sans mois) a-t-elle déjà été passée ? */
	public static function dotationAnnuelleExiste( $id, $exercice ) {
		return '' !== self::dotationEtatAnnuelle( $id, $exercice );
	}

	/** État de la seule dotation annuelle : ''|'attente'|'comptabilisee'. */
	public static function dotationEtatAnnuelle( $id, $exercice ) {
		self::assurerColonneMois();
		try {
			$r = FKC_DB::q( 'SELECT ecriture_id FROM immo_dotations WHERE immobilisation_id=? AND exercice=? AND mois IS NULL ORDER BY id DESC LIMIT 1',
				array( (int) $id, (int) $exercice ) )->fetch();
		} catch ( \Throwable $e ) { return ''; }
		if ( ! $r ) { return ''; }
		return empty( $r['ecriture_id'] ) ? 'attente' : 'comptabilisee';
	}

	public static function dotations( $id ) {
		return FKC_DB::q( 'SELECT * FROM immo_dotations WHERE immobilisation_id=? ORDER BY exercice ASC', array( (int) $id ) )->fetchAll();
	}
	public static function cumulAmorti( $id ) {
		return (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant),0) s FROM immo_dotations WHERE immobilisation_id=?', array( (int) $id ) )->fetch()['s'];
	}
	/**
	 * Valeur nette comptable. Un bien CÉDÉ ou une fiche ANNULÉE n'est plus à
	 * l'actif : sa VNC est nulle (1.855.0). L'index, l'extraction et les
	 * totaux affichaient jusqu'ici la VNC d'avant la sortie.
	 */
	public static function vnc( $immo ) {
		if ( ! self::estEnService( $immo ) ) { return 0.0; }
		return (float) $immo['valeur_acquisition'] - self::cumulAmorti( $immo['id'] );
	}
	/** Dernier jour de l'exercice (repli sur le 31/12 si le module est absent). */
	protected static function finExercice( $annee ) {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'finDe' ) ) {
			return FKC_Exercice::finDe( (int) $annee );
		}
		return sprintf( '%04d-12-31', (int) $annee );
	}

	/** Millésime de l'exercice auquel appartient une date. */
	protected static function exerciceDe( $date ) {
		if ( class_exists( 'FKC_Exercice' ) && method_exists( 'FKC_Exercice', 'annee' ) ) {
			return (int) FKC_Exercice::annee( $date );
		}
		return (int) date( 'Y', strtotime( (string) $date ) );
	}

	public static function dotationExiste( $id, $exercice, $mois = null ) {
		return '' !== self::dotationEtat( $id, $exercice, $mois );
	}

	/**
	 * État de la dotation d'un exercice : ''|'attente'|'comptabilisee'.
	 *
	 * POURQUOI « EXISTE » NE SUFFIT PLUS (1.542.0)
	 *
	 * Depuis que la dotation passe par le contrôle avant comptabilisation, sa
	 * ligne de suivi peut exister alors que l'écriture attend encore au
	 * journal temporaire. Confondre les deux serait grave dans un sens
	 * précis : la clôture annuelle vérifie que les amortissements sont passés
	 * avant d'arrêter le résultat. Si elle prenait une dotation EN ATTENTE
	 * pour une dotation faite, elle clôturerait sur un résultat amputé — et
	 * l'exercice étant clos, la dotation en attente ne pourrait plus être
	 * validée. Exactement l'erreur définitive que ce garde-fou existe pour
	 * empêcher.
	 *
	 * @return string '' (aucune), 'attente' (écriture non comptabilisée),
	 *                'comptabilisee'.
	 */
	public static function dotationEtat( $id, $exercice, $mois = null ) {
		self::assurerColonneMois();
		try {
			if ( null === $mois ) {
				// Sans mois : l'exercice est servi dès qu'une dotation existe,
				// annuelle comme mensuelle — c'est ce que la clôture demande.
				$r = FKC_DB::q( 'SELECT ecriture_id FROM immo_dotations WHERE immobilisation_id=? AND exercice=? ORDER BY id DESC LIMIT 1',
					array( (int) $id, (int) $exercice ) )->fetch();
			} else {
				$r = FKC_DB::q( 'SELECT ecriture_id FROM immo_dotations WHERE immobilisation_id=? AND exercice=? AND mois=? ORDER BY id DESC LIMIT 1',
					array( (int) $id, (int) $exercice, (int) $mois ) )->fetch();
			}
		} catch ( \Throwable $e ) { return ''; }
		if ( ! $r ) { return ''; }
		return empty( $r['ecriture_id'] ) ? 'attente' : 'comptabilisee';
	}

	protected static function journalOD() {
		foreach ( FKC_Journal::all() as $j ) { if ( 'OD' === $j['code'] ) { return (int) $j['id']; } }
		return 0;
	}

	/** Comptabilise la dotation d'un exercice : D 6813 / C 28xx. */
	public static function comptabiliserDotation( $immo, $exercice, $mois = null ) {
		self::assurerColonneMois();
		/*
		 * UNE FICHE SORTIE NE S'AMORTIT PLUS (1.855.0). Le bouton était masqué
		 * pour un bien cédé mais pas pour une fiche annulée, et la route
		 * elle-même ne vérifiait rien : on dotait un bien vendu, ou une fiche
		 * annulée faute d'avoir existé.
		 */
		if ( self::estAnnulee( $immo ) ) { return array( false, 'Fiche annulée : elle ne s\'amortit plus.' ); }
		if ( 'cede' === (string) ( $immo['statut'] ?? '' ) ) {
			return array( false, 'Bien cédé le ' . date( 'd/m/Y', strtotime( (string) $immo['date_cession'] ) )
				. ' : la dotation de l\'exercice de cession a été passée avec la sortie, il n\'y en a plus d\'autre.' );
		}
		if ( ! self::estAmortissable( $immo ) ) { return array( false, 'Ce bien ne s\'amortit pas (terrain, titres, avance ou immobilisation en cours) : il se déprécie.' ); }
		$mois = ( null === $mois || '' === $mois ) ? null : (int) $mois;
		if ( null !== $mois && ( $mois < 1 || $mois > 12 ) ) { return array( false, 'Mois invalide.' ); }
		$periode = ( null === $mois ) ? 'l\'exercice ' . (int) $exercice : sprintf( '%02d/%04d', $mois, self::anneeDuMois( $immo, $exercice, $mois ) );
		// En annuel, on regarde la dotation ANNUELLE seule : une mensualité
		// déjà passée mérite son propre message, plus bas.
		$etat = ( null === $mois )
			? self::dotationEtatAnnuelle( $immo['id'], $exercice )
			: self::dotationEtat( $immo['id'], $exercice, $mois );
		if ( 'comptabilisee' === $etat ) { return array( false, 'La dotation de ' . $periode . ' est déjà comptabilisée.' ); }
		if ( 'attente' === $etat ) {
			return array( false, 'La dotation de ' . $periode . ' attend déjà au journal temporaire : '
				. 'validez-la depuis Comptabilité › Journal temporaire plutôt que d\'en créer une seconde.' );
		}
		/*
		 * Une dotation ANNUELLE ne se passe pas par-dessus des mensualités
		 * déjà comptabilisées, et inversement : les deux se cumuleraient sur
		 * le même exercice et amortiraient le bien deux fois (1.765.0).
		 */
		if ( null === $mois && '' !== self::dotationEtat( $immo['id'], $exercice, null ) ) {
			return array( false, 'Des dotations mensuelles existent déjà sur l\'exercice ' . (int) $exercice . ' : comptabilisez les mois restants.' );
		}
		if ( null !== $mois && self::dotationAnnuelleExiste( $immo['id'], $exercice ) ) {
			return array( false, 'La dotation annuelle ' . (int) $exercice . ' est déjà passée : le détail mensuel ne peut plus s\'y ajouter.' );
		}
		$montant = self::dotationPrevue( $immo, $exercice, $mois );
		if ( $montant <= 0 ) {
			return array( false, ( null === $mois )
				? 'Aucune dotation prévue pour cet exercice.'
				: 'Aucune dotation prévue pour ' . $periode . '.' );
		}
		$date = ( null === $mois )
			? self::finExercice( (int) $exercice )
			: date( 'Y-m-t', mktime( 0, 0, 0, $mois, 1, self::anneeDuMois( $immo, $exercice, $mois ) ) );
		$lib = 'Dotation amortissement ' . $immo['libelle'] . ' (' . ( null === $mois ? $exercice : $periode ) . ')';
		return self::passerDotation( $immo, $exercice, $mois, $montant, $date, $lib, $periode );
	}

	/**
	 * Écrit une dotation : ligne de suivi, puis écriture D 68 / C 28 (1.855.0 :
	 * extrait de comptabiliserDotation() pour servir aussi la dotation
	 * complémentaire de cession).
	 *
	 * @return array{0:bool,1:string,2:int|null,3:int|null} ok, message, écriture, brouillon
	 */
	protected static function passerDotation( $immo, $exercice, $mois, $montant, $date, $lib, $periode ) {
		/*
		 * Les comptes doivent EXISTER au moment d'écrire.
		 *
		 * L'ancienne version abandonnait sans rien dire d'utile quand le compte
		 * d'amortissement n'avait pas été créé dans le dossier : l'utilisateur
		 * voyait le plan d'amortissement se remplir et aucune écriture partir.
		 * On les ouvre depuis le référentiel plutôt que d'échouer.
		 */
		if ( class_exists( 'FKC_MappingAmortissement' ) ) {
			FKC_MappingAmortissement::assurerComptes( array(
				'amortissement' => $immo['compte_amort'],
				'dotation'      => $immo['compte_dotation'],
				'libelles'      => array(),
			) );
		}
		$cDot = FKC_Compte::byNumero( $immo['compte_dotation'] ); $cAmo = FKC_Compte::byNumero( $immo['compte_amort'] );
		if ( ! $cDot || ! $cAmo ) { return array( false, 'Comptes de dotation/amortissement introuvables.', null, null ); }
		/*
		 * Dernier jour de l'EXERCICE, pas le 31 décembre (1.544.0).
		 *
		 * Une dotation datée du 31/12 chez un dossier clôturant au 30/06
		 * tombait dans l'exercice SUIVANT : elle amputait le résultat d'une
		 * année qui n'était pas la sienne, et manquait à celle qu'elle
		 * concernait. Sur un exercice calendaire, la date est inchangée.
		 */
		/*
		 * En mensuel, la dotation est datée du dernier jour du MOIS : la
		 * charge tombe dans le mois qu'elle concerne, sinon la marge
		 * mensuelle resterait fausse — ce que ce mode vient corriger.
		 */

		// Imputation analytique de la charge de dotation (6813) : division portée
		// par la fiche si la colonne existe (pont Immobilisations ↔ Analytique).
		$div = ! empty( $immo['division_id'] ) ? (int) $immo['division_id'] : null;
		/*
		 * LA LIGNE DE SUIVI EST CRÉÉE AVANT L'ÉCRITURE (1.542.0).
		 *
		 * Jusqu'ici ce code forçait `brouillard = false` : la dotation partait
		 * DIRECTEMENT au grand livre, sans jamais passer par le contrôle
		 * avant comptabilisation. Le motif invoqué était que
		 * `immo_dotations` doit référencer l'écriture — donc qu'il fallait un
		 * identifiant tout de suite.
		 *
		 * Ce n'était pas une nécessité, c'était un ORDRE D'ÉCRITURE. On insère
		 * d'abord la ligne de suivi sans référence, puis on passe son
		 * identifiant en `lien` : FKC_Brouillard::backfill() renseigne
		 * `ecriture_id` au moment où l'écriture est réellement comptabilisée,
		 * qu'elle le soit sur-le-champ ou après validation. Le mécanisme
		 * existait déjà — la table manquait simplement à la liste blanche.
		 *
		 * Si l'écriture est refusée, la ligne de suivi est retirée : une
		 * dotation « existante » sans écriture ferait croire à la clôture
		 * annuelle que l'amortissement est passé.
		 */
		$dotId = null;
		try {
			FKC_DB::q( 'INSERT INTO immo_dotations(immobilisation_id,exercice,mois,date_dotation,montant,ecriture_id) VALUES(?,?,?,?,?,NULL)',
				array( (int) $immo['id'], (int) $exercice, $mois, $date, $montant ) );
			$dotId = (int) FKC_DB::conn()->lastInsertId();
		} catch ( \Throwable $e ) { return array( false, 'Suivi de dotation impossible : ' . $e->getMessage() ); }

		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer(
			array(
				'journal_id' => self::journalOD(), 'date_ecriture' => $date, 'libelle' => $lib,
				'piece' => 'IMMO-' . $exercice . ( null === $mois ? '' : sprintf( '-%02d', $mois ) ), 'created_by' => FKC_Auth::id(),
				/*
				 * ÉCRITURE D'INVENTAIRE. Une dotation est toujours datée du
				 * 31/12 et passée après coup : elle butait sur la clôture
				 * mensuelle de décembre, si bien qu'un dossier tenu
				 * proprement — mois clôturés au fil de l'eau — ne pouvait
				 * plus amortir. Elle reste refusée si l'EXERCICE est clos,
				 * car elle changerait alors un résultat déjà arrêté.
				 */
				'inventaire' => true,
			),
			array(
				array( 'compte_id' => (int) $cDot['id'], 'libelle' => $lib, 'debit' => $montant, 'credit' => 0, 'division_id' => $div ),
				array( 'compte_id' => (int) $cAmo['id'], 'libelle' => $lib, 'debit' => 0, 'credit' => $montant ),
			),
			array(
				'source' => 'immobilisations',
				'lien'   => array( 'table' => 'immo_dotations', 'colonne' => 'ecriture_id', 'ids' => array( $dotId ) ),
			)
		);
		if ( ! $ok ) {
			FKC_DB::q( 'DELETE FROM immo_dotations WHERE id=?', array( $dotId ) );
			return array( false, $msg, null, null );
		}

		/*
		 * Le bus n'annonce l'événement QUE si l'écriture est comptabilisée.
		 * Une dotation au journal temporaire n'a encore rien changé au
		 * résultat : prévenir les packs qu'elle est « comptabilisée » leur
		 * ferait calculer un coût d'équipement sur une charge qui n'existe
		 * pas encore. Ils seront prévenus à la validation, par le brouillard.
		 */
		if ( $eid && class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'immo_dotation_comptabilisee', array(
				'immobilisation_id' => (int) $immo['id'], 'libelle' => (string) $immo['libelle'],
				'exercice' => (int) $exercice, 'mois' => $mois, 'montant' => $montant, 'date' => $date,
				'ecriture_id' => (int) $eid, 'division_id' => $div,
			), array( 'poster' => false ) );
		}
		if ( $bid ) {
			return array( true, 'Dotation ' . $periode . ' de ' . fkc_money( $montant )
				. ' FCFA déposée au journal temporaire — à vérifier avant comptabilisation.', null, (int) $bid );
		}
		return array( true, 'Dotation ' . $periode . ' comptabilisée : ' . fkc_money( $montant ) . ' FCFA.', (int) $eid, null );
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * ANNULER UNE FICHE (1.761.0)
	 *
	 * Le module savait tout faire d'une immobilisation SAUF revenir en
	 * arrière : ni annulation, ni suppression, nulle part — pas même dans la
	 * maintenance administrateur. Une fiche créée sur une écriture erronée
	 * restait donc là, et continuait de s'amortir au prochain « Lancer
	 * l'amortissement », alors même que son écriture d'acquisition venait
	 * d'être contre-passée.
	 *
	 * Le geste par défaut est une ANNULATION, pas un effacement : la fiche
	 * sort de l'amortissement, des totaux et du récolement, mais son code
	 * d'inventaire et son code-barres restent lisibles. Effacer une fiche qui
	 * a porté une étiquette scannée, c'est perdre la trace de ce qui a été
	 * inventorié.
	 *
	 * La suppression définitive existe (supprimer()), réservée à
	 * l'administrateur et à la fiche qui n'a rien laissé derrière elle.
	 * ═══════════════════════════════════════════════════════════════════ */

	const STATUT_ANNULEE = 'annulee';

	public static function estAnnulee( $im ) {
		return is_array( $im ) && self::STATUT_ANNULEE === (string) ( $im['statut'] ?? '' );
	}

	/**
	 * Ce qui empêche d'annuler la fiche, en clair.
	 *
	 * Une dotation, même en attente au journal temporaire, compte : la
	 * charge est engagée et le cumul amorti la retient déjà.
	 *
	 * @return array liste de phrases ; vide = annulation possible
	 */
	public static function blocages( $id ) {
		$im = self::find( $id );
		if ( ! $im ) { return array( 'Immobilisation introuvable.' ); }
		$out = array();
		if ( self::estAnnulee( $im ) ) { $out[] = 'Cette fiche est déjà annulée.'; }
		if ( 'cede' === (string) $im['statut'] ) {
			$out[] = 'Le bien a été cédé le ' . (string) $im['date_cession'] . ' : c\'est l\'écriture de cession qu\'il faut contre-passer, pas la fiche.';
		}
		$n = (int) FKC_DB::q( 'SELECT COUNT(*) FROM immo_dotations WHERE immobilisation_id=?', array( (int) $id ) )->fetchColumn();
		if ( $n ) {
			$comptas = self::dotationsComptabilisees( $id );
			$out[] = $n . ' dotation(s) enregistrée(s)' . ( $comptas['nombre'] ? ', dont ' . (int) $comptas['nombre'] . ' comptabilisée(s)' : ' en attente au journal temporaire' )
				. ' : contre-passez-les d\'abord depuis l\'écriture, l\'amortissement passé ne s\'efface pas d\'un clic.';
		}
		return $out;
	}

	/**
	 * Annule la fiche. L'écriture d'acquisition, elle, n'est pas touchée :
	 * elle vit sa vie de pièce comptable et se contre-passe depuis l'écran
	 * des écritures. Les deux gestes sont distincts parce que les deux
	 * responsabilités le sont.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function annuler( $id, $motif = '' ) {
		$im = self::find( $id );
		if ( ! $im ) { return array( false, 'Immobilisation introuvable.' ); }
		$blocages = self::blocages( $id );
		if ( $blocages ) { return array( false, 'Annulation refusée : ' . implode( ' ', $blocages ) ); }
		self::assurerColonnes();
		$motif = trim( (string) $motif );
		FKC_DB::q(
			"UPDATE immobilisations SET statut=?, annule_at=datetime('now','localtime'), annule_motif=? WHERE id=?",
			array( self::STATUT_ANNULEE, '' !== $motif ? $motif : 'Fiche annulée', (int) $id )
		);
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'immobilisation_annulee', 'Immobilisation #' . (int) $id . ' « ' . (string) $im['libelle'] . ' » ('
				. fkc_money( $im['valeur_acquisition'] ) . ' F)' . ( '' !== $motif ? ' — ' . $motif : '' ) );
		}
		$suite = '';
		if ( ! empty( $im['ecriture_acq_id'] ) && null === self::acquisitionContrepassee( $im ) ) {
			$suite = ' Son écriture d\'acquisition n°' . (int) $im['ecriture_acq_id'] . ' reste en place : contre-passez-la si elle est erronée.';
		}
		return array( true, 'Fiche annulée : elle ne s\'amortira plus et sort des totaux.' . $suite );
	}

	/** Ce qui empêche la suppression définitive (en plus des blocages d'annulation). */
	public static function blocagesSuppression( $id ) {
		$out = array();
		$im = self::find( $id );
		if ( ! $im ) { return array( 'Immobilisation introuvable.' ); }
		foreach ( self::blocages( $id ) as $b ) {
			// « Déjà annulée » n'empêche pas de supprimer : c'est même le cas courant.
			if ( false === strpos( $b, 'déjà annulée' ) ) { $out[] = $b; }
		}
		if ( class_exists( 'FKC_PieceJointe' ) ) {
			$n = (int) FKC_PieceJointe::count( 'immobilisation', (int) $id );
			if ( $n ) { $out[] = $n . ' justificatif(s) attaché(s) à la fiche.'; }
		}
		try {
			$n = (int) FKC_DB::q( 'SELECT COUNT(*) FROM immo_recolement_lignes WHERE immobilisation_id=?', array( (int) $id ) )->fetchColumn();
			if ( $n ) { $out[] = 'Le bien a été inventorié lors de ' . $n . ' récolement(s) : la fiche peut être annulée, pas effacée.'; }
		} catch ( \Throwable $e ) { /* module de récolement absent */ }
		return $out;
	}

	/**
	 * Suppression définitive — administrateur, et fiche vierge uniquement.
	 *
	 * @return array{0:bool,1:string}
	 */
	public static function supprimer( $id, $motif = '' ) {
		$im = self::find( $id );
		if ( ! $im ) { return array( false, 'Immobilisation introuvable.' ); }
		$blocages = self::blocagesSuppression( $id );
		if ( $blocages ) { return array( false, 'Suppression refusée : ' . implode( ' ', $blocages ) ); }
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'immobilisation_supprimee', 'Immobilisation #' . (int) $id . ' « ' . (string) $im['libelle'] . ' » ('
				. fkc_money( $im['valeur_acquisition'] ) . ' F, code ' . (string) $im['code'] . ')' . ( '' !== trim( (string) $motif ) ? ' — ' . trim( (string) $motif ) : '' ) );
		}
		FKC_DB::q( 'DELETE FROM immobilisations WHERE id=?', array( (int) $id ) );
		return array( true, 'Fiche supprimée définitivement. L\'écriture d\'acquisition, elle, n\'est pas touchée.' );
	}

	/**
	 * L'écriture d'acquisition a-t-elle été contre-passée ? (1.761.0)
	 *
	 * La fiche n'est pas rattachée à son écriture dans la carte des
	 * dépendances — sa colonne se nomme `ecriture_acq_id`, quand la carte ne
	 * connaît que `ecriture_id`. Contre-passer l'acquisition laissait donc la
	 * fiche intacte, et rien nulle part ne le disait.
	 *
	 * @return int|null identifiant de la contre-passation
	 */
	public static function acquisitionContrepassee( $im ) {
		$eid = (int) ( is_array( $im ) ? ( $im['ecriture_acq_id'] ?? 0 ) : $im );
		if ( $eid <= 0 || ! class_exists( 'FKC_EcritureAnnulation' ) ) { return null; }
		try {
			$r = FKC_DB::q( 'SELECT id FROM ecritures WHERE reference=? LIMIT 1',
				array( FKC_EcritureAnnulation::MARQUEUR . $eid ) )->fetch();
		} catch ( \Throwable $e ) { return null; }
		return $r ? (int) $r['id'] : null;
	}

	/** Fiches encore actives dont l'écriture d'acquisition a été contre-passée. */
	public static function acquisitionsContrepassees() {
		$out = array();
		try {
			$rows = FKC_DB::q( "SELECT * FROM immobilisations WHERE ecriture_acq_id IS NOT NULL AND statut<>'annulee'" )->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( $rows as $im ) {
			$c = self::acquisitionContrepassee( $im );
			if ( $c ) { $im['contrepassation_id'] = $c; $out[] = $im; }
		}
		return $out;
	}

	/** Colonnes de traçabilité de l'annulation, ajoutées à la demande. */
	protected static function assurerColonnes() {
		static $fait = false;
		if ( $fait ) { return; }
		$fait = true;
		try {
			$cols = array();
			foreach ( FKC_DB::q( 'PRAGMA table_info(immobilisations)' )->fetchAll() as $c ) { $cols[] = $c['name']; }
			if ( $cols && ! in_array( 'annule_at', $cols, true ) ) { FKC_DB::conn()->exec( 'ALTER TABLE immobilisations ADD COLUMN annule_at TEXT' ); }
			if ( $cols && ! in_array( 'annule_motif', $cols, true ) ) { FKC_DB::conn()->exec( 'ALTER TABLE immobilisations ADD COLUMN annule_motif TEXT' ); }
		} catch ( \Throwable $e ) { /* schéma indisponible : l'annulation reste possible sans motif */ }
	}

	/** Écart en jours, base 360 (mois de 30 jours) : $b exclu. */
	protected static function jours360( $a, $b ) {
		$ta = strtotime( (string) $a ); $tb = strtotime( (string) $b );
		if ( ! $ta || ! $tb || $tb <= $ta ) { return 0; }
		return ( (int) date( 'Y', $tb ) - (int) date( 'Y', $ta ) ) * 360
			+ ( (int) date( 'n', $tb ) - (int) date( 'n', $ta ) ) * 30
			+ ( min( 30, (int) date( 'j', $tb ) ) - min( 30, (int) date( 'j', $ta ) ) );
	}

	/**
	 * DOTATION COMPLÉMENTAIRE DE CESSION (1.855.0).
	 *
	 * Un bien vendu en cours d'exercice s'est consommé jusqu'au jour de sa
	 * sortie : le SYSCOHADA veut la dotation de l'exercice, au prorata, AVANT
	 * de calculer la valeur comptable de sortie. La cession ne la passait pas —
	 * et la clôture ne la réclamait pas non plus, puisqu'elle écarte les biens
	 * cédés. Chaque cession surévaluait donc la VNC (81) et sous-évaluait la
	 * plus-value, du montant exact de l'amortissement de l'année.
	 *
	 * Montant : l'annuité du plan pour l'exercice, au prorata des jours (base
	 * 360) entre le début d'amortissement de l'exercice et la date de cession incluse,
	 * moins ce qui a déjà été doté sur cet exercice (mensualités).
	 */
	public static function dotationComplementaire( $immo, $date ) {
		if ( ! self::estAmortissable( $immo ) ) { return 0.0; }
		$ex = self::exerciceDe( $date );
		$annuite = 0.0;
		foreach ( self::planTheorique( $immo ) as $r ) {
			if ( (int) $r['exercice'] === $ex ) { $annuite = (float) $r['dotation']; break; }
		}
		if ( $annuite <= 0 ) { return 0.0; }
		$debutEx = date( 'Y-m-d', strtotime( '+1 day', strtotime( self::finExercice( $ex - 1 ) ) ) );
		$debut = max( $debutEx, (string) $immo['date_acquisition'] );
		$fin = self::finExercice( $ex );
		$total = self::jours360( $debut, $fin ) + 1;
		if ( $total <= 0 ) { return 0.0; }
		// Jour de cession INCLUS, comme le jour d'acquisition l'est au plan : une
		// sortie au 30/09 porte neuf mois pleins.
		$part = round( $annuite * min( 1, ( self::jours360( $debut, $date ) + 1 ) / $total ) );
		$reste = max( 0.0, (float) $immo['valeur_acquisition'] - (float) $immo['valeur_residuelle'] - self::cumulAmorti( $immo['id'] ) );
		return max( 0.0, min( $reste, $part - self::doteSurExercice( (int) $immo['id'], $ex ) ) );
	}

	/**
	 * Comptes de cession selon la nature du bien (1.855.0) : 811/821
	 * incorporelles, 816/826 financières, 812/822 corporelles. Tout passait en
	 * 812/822 : le tableau des flux, qui sépare FI (incorporelles et
	 * corporelles) de FJ (financières), rangeait la vente d'un titre avec
	 * celle d'un camion. Le compte est ouvert s'il manque au plan.
	 */
	public static function numerosCession( $compteImmo ) {
		$p2 = substr( (string) $compteImmo, 0, 2 );
		if ( in_array( $p2, array( '20', '21' ), true ) ) { return array( 'vc' => '811', 'produit' => '821', 'nature' => 'incorporelles' ); }
		if ( in_array( $p2, array( '26', '27' ), true ) ) { return array( 'vc' => '816', 'produit' => '826', 'nature' => 'financières' ); }
		return array( 'vc' => '812', 'produit' => '822', 'nature' => 'corporelles' );
	}

	/** Comptes de cession, ouverts au plan s'ils manquent (à l'écriture seulement). */
	public static function comptesCession( $compteImmo ) {
		$nc = self::numerosCession( $compteImmo );
		$lib = $nc['nature'];
		$out = array();
		foreach ( array( 'vc' => $nc['vc'], 'produit' => $nc['produit'] ) as $k => $n ) {
			$c = FKC_Compte::byNumero( $n );
			if ( ! $c ) {
				try {
					FKC_Compte::create( $n . '000', ( '81' === substr( $n, 0, 2 ) ? 'Valeurs comptables des cessions — immobilisations ' : 'Produits des cessions — immobilisations ' ) . $lib, 'detail',
						class_exists( 'FKC_PlanSyscohada' ) && FKC_PlanSyscohada::estOfficiel( $n ) ? 'ohada' : 'societe' );
				} catch ( \Throwable $e ) {}
				$c = FKC_Compte::byNumero( $n );
			}
			$out[ $k ] = $c;
		}
		return $out;
	}

	/**
	 * Cession ou mise au rebut d'une immobilisation.
	 *
	 * 1.855.0 : dotation complémentaire passée d'abord, comptes 81x/82x selon
	 * la nature du bien, mise au rebut sans trésorerie (prix nul), aucune ligne
	 * à zéro, fiche annulée refusée, dotation en attente refusée (la reprise
	 * débiterait le 28 d'un montant qu'aucune écriture n'a encore crédité).
	 *
	 * @param array $opts complement (bool, défaut true)
	 */
	public static function ceder( $immo, $date, $prix, $tresId, array $opts = array() ) {
		if ( 'cede' === $immo['statut'] ) { return array( false, 'Immobilisation déjà cédée.' ); }
		if ( self::estAnnulee( $immo ) ) { return array( false, 'Fiche annulée : il n\'y a pas de bien à céder.' ); }
		$date = (string) $date;
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! strtotime( $date ) ) { return array( false, 'Date de cession invalide.' ); }
		if ( $date < (string) $immo['date_acquisition'] ) { return array( false, 'La cession ne peut pas précéder l\'acquisition (' . date( 'd/m/Y', strtotime( $immo['date_acquisition'] ) ) . ').' ); }
		$prix = self::nombre( $prix );
		if ( $prix < 0 ) { return array( false, 'Le prix de cession ne peut pas être négatif.' ); }
		try {
			$attente = (int) FKC_DB::q( 'SELECT COUNT(*) FROM immo_dotations WHERE immobilisation_id=? AND ecriture_id IS NULL', array( (int) $immo['id'] ) )->fetchColumn();
		} catch ( \Throwable $e ) { $attente = 0; }
		if ( $attente ) {
			return array( false, 'Une dotation de ce bien attend au journal temporaire : validez-la avant la cession, faute de quoi la reprise des amortissements porterait sur une charge non comptabilisée.' );
		}

		$cImmo = FKC_Compte::byNumero( $immo['compte_immo'] );
		$cs = self::comptesCession( $immo['compte_immo'] );
		$tres = $prix > 0 ? FKC_Tresorerie::find( (int) $tresId ) : null;
		if ( ! $cImmo || empty( $cs['vc'] ) || ( $prix > 0 && empty( $cs['produit'] ) ) ) { return array( false, 'Comptes de cession introuvables.' ); }
		if ( $prix > 0 && ! $tres ) { return array( false, 'Choisissez le compte de trésorerie qui encaisse le prix.' ); }

		// 1. Dotation complémentaire de l'exercice de cession.
		$complement = 0.0; $noteComp = '';
		if ( ! array_key_exists( 'complement', $opts ) || $opts['complement'] ) {
			$complement = self::dotationComplementaire( $immo, $date );
			if ( $complement > 0 ) {
				$ex = self::exerciceDe( $date );
				list( $okD, $msgD ) = self::passerDotation( $immo, $ex, null, $complement, $date,
					'Dotation complémentaire (cession) ' . $immo['libelle'] . ' — ' . date( 'd/m/Y', strtotime( $date ) ), 'la cession' );
				if ( ! $okD ) { return array( false, 'Dotation complémentaire impossible : ' . $msgD ); }
				$noteComp = 'Dotation complémentaire ' . fkc_money( $complement ) . ' · ';
			}
		}

		$va = (float) $immo['valeur_acquisition']; $cumul = self::cumulAmorti( $immo['id'] ); $vnc = $va - $cumul;
		$cAmo = $cumul > 0.004 ? FKC_Compte::byNumero( $immo['compte_amort'] ) : null;
		if ( $cumul > 0.004 && ! $cAmo ) { return array( false, 'Compte d\'amortissement ' . $immo['compte_amort'] . ' introuvable.' ); }
		$lignes = array(
			array( 'compte_id' => (int) $cs['vc']['id'], 'libelle' => 'VC cession ' . $immo['libelle'], 'debit' => $vnc, 'credit' => 0 ),
			array( 'compte_id' => $cAmo ? (int) $cAmo['id'] : 0, 'libelle' => 'Reprise amortissements', 'debit' => $cumul, 'credit' => 0 ),
			array( 'compte_id' => (int) $cImmo['id'], 'libelle' => 'Sortie immobilisation', 'debit' => 0, 'credit' => $va ),
			array( 'compte_id' => $tres ? (int) $tres['compte_id'] : 0, 'libelle' => 'Encaissement cession', 'debit' => $prix, 'credit' => 0 ),
			array( 'compte_id' => $prix > 0 ? (int) $cs['produit']['id'] : 0, 'libelle' => 'Produit de cession', 'debit' => 0, 'credit' => $prix ),
		);
		// Aucune ligne à zéro : un bien non amorti n'a pas de reprise, une mise au rebut pas d'encaissement.
		$lignes = array_values( array_filter( $lignes, function ( $l ) { return $l['compte_id'] > 0 && ( $l['debit'] > 0.004 || $l['credit'] > 0.004 ); } ) );
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer(
			array( 'journal_id' => self::journalOD(), 'date_ecriture' => $date,
				'libelle' => ( $prix > 0 ? 'Cession ' : 'Mise au rebut ' ) . $immo['libelle'], 'created_by' => FKC_Auth::id() ),
			$lignes,
			/*
			 * 1.542.0 — la cession suit la politique comme le reste. Le statut
			 * bascule tout de suite : le bien EST cédé, quel que soit le moment
			 * où l'écriture sera comptabilisée.
			 */
			array( 'source' => 'immobilisations' )
		);
		if ( ! $ok ) { return array( false, $msg ); }
		FKC_DB::q( 'UPDATE immobilisations SET statut=?, date_cession=?, valeur_cession=? WHERE id=?', array( 'cede', $date, $prix, (int) $immo['id'] ) );
		$pv = $prix - $vnc;
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( 'immo_cedee', array(
				'immobilisation_id' => (int) $immo['id'], 'libelle' => (string) $immo['libelle'],
				'date' => (string) $date, 'prix' => (float) $prix, 'vnc' => (float) $vnc,
				'plus_value' => (float) $pv, 'ecriture_id' => $eid ? (int) $eid : null,
				'dotation_complementaire' => (float) $complement,
			), array( 'poster' => false ) );
		}
		$fin = $noteComp . 'VNC ' . fkc_money( $vnc ) . ' · ' . ( $pv >= 0 ? '+value ' : '−value ' ) . fkc_money( abs( $pv ) ) . ' FCFA.';
		$quoi = $prix > 0 ? 'Cession enregistrée. ' : 'Mise au rebut enregistrée. ';
		if ( $bid ) { return array( true, $quoi . $fin . ' L\'écriture attend au journal temporaire.' ); }
		return array( true, $quoi . $fin );
	}

	/* ══ RAPPROCHEMENT REGISTRE ↔ GRAND LIVRE (1.855.0) ══════════════════════
	 *
	 * Le registre des immobilisations et le bilan décrivent le même actif, par
	 * deux chemins : les fiches d'un côté, les comptes de classe 2 et 28 de
	 * l'autre. Rien ne les confrontait. Un achat imputé en 2 sans fiche ne
	 * s'amortit jamais ; une fiche sans écriture d'acquisition amortit un bien
	 * que le bilan ne porte pas. La clôture confrontait déjà les DOTATIONS de
	 * l'exercice ; ce rapprochement confronte les SOLDES, compte par compte.
	 */
	public static function rapprochement( $date = null ) {
		$date = $date ?: date( 'Y-m-d' );
		$registre = array(); $amort = array();
		foreach ( self::all() as $im ) {
			if ( ! self::estEnService( $im ) || (string) $im['date_acquisition'] > $date ) { continue; }
			$ci = (string) $im['compte_immo'];
			$registre[ $ci ] = ( $registre[ $ci ] ?? 0.0 ) + (float) $im['valeur_acquisition'];
			if ( '' !== (string) $im['compte_amort'] ) {
				try {
					$cum = (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant),0) FROM immo_dotations WHERE immobilisation_id=? AND ecriture_id IS NOT NULL AND date_dotation<=?',
						array( (int) $im['id'], $date ) )->fetchColumn();
				} catch ( \Throwable $e ) { $cum = 0.0; }
				$ca = (string) $im['compte_amort'];
				$amort[ $ca ] = ( $amort[ $ca ] ?? 0.0 ) + $cum;
			}
		}
		$gl = class_exists( 'FKC_SoldeOuverture' ) ? FKC_SoldeOuverture::soldesAu( $date ) : array();
		$libs = array();
		try { foreach ( FKC_DB::q( "SELECT numero, libelle FROM comptes WHERE numero LIKE '2%'" )->fetchAll() as $r ) { $libs[ (string) $r['numero'] ] = (string) $r['libelle']; } } catch ( \Throwable $e ) {}
		$lignes = array();
		$cles = array();
		foreach ( array_keys( $registre ) as $k ) { $cles[ $k ] = 'brut'; }
		foreach ( array_keys( $amort ) as $k ) { $cles[ $k ] = 'amort'; }
		foreach ( $gl as $num => $solde ) {
			$num = (string) $num;
			if ( '2' !== substr( $num, 0, 1 ) || '29' === substr( $num, 0, 2 ) ) { continue; }
			if ( ! isset( $cles[ $num ] ) ) { $cles[ $num ] = '28' === substr( $num, 0, 2 ) ? 'amort' : 'brut'; }
		}
		ksort( $cles, SORT_STRING );
		$tot = array( 'brut' => array( 0.0, 0.0 ), 'amort' => array( 0.0, 0.0 ) );
		foreach ( $cles as $num => $nature ) {
			$num = (string) $num;
			$r = 'amort' === $nature ? (float) ( $amort[ $num ] ?? 0.0 ) : (float) ( $registre[ $num ] ?? 0.0 );
			$g = 'amort' === $nature ? -(float) ( $gl[ $num ] ?? 0.0 ) : (float) ( $gl[ $num ] ?? 0.0 );
			if ( abs( $r ) < 0.005 && abs( $g ) < 0.005 ) { continue; }
			$tot[ $nature ][0] += $r; $tot[ $nature ][1] += $g;
			$lignes[] = array( 'compte' => $num, 'libelle' => $libs[ $num ] ?? '', 'nature' => $nature,
				'registre' => round( $r, 2 ), 'gl' => round( $g, 2 ), 'ecart' => round( $g - $r, 2 ) );
		}
		$ecarts = array_values( array_filter( $lignes, function ( $l ) { return abs( $l['ecart'] ) >= 1; } ) );
		return array(
			'date' => $date, 'lignes' => $lignes, 'ecarts' => $ecarts,
			'brut' => array( 'registre' => round( $tot['brut'][0], 2 ), 'gl' => round( $tot['brut'][1], 2 ) ),
			'amort' => array( 'registre' => round( $tot['amort'][0], 2 ), 'gl' => round( $tot['amort'][1], 2 ) ),
			'a_rattacher' => count( self::ecrituresImmobilisables() ),
			'concordant' => ! $ecarts,
		);
	}

	/**
	 * Chiffres clés du parc (1.855.0) — bande d'indicateurs de l'écran.
	 */
	public static function synthese( $exercice = null ) {
		$exercice = $exercice ?: self::exerciceDe( date( 'Y-m-d' ) );
		$o = array( 'nb' => 0, 'en_service' => 0, 'cedees' => 0, 'annulees' => 0, 'non_amortissables' => 0,
			'brut' => 0.0, 'cumul' => 0.0, 'vnc' => 0.0, 'dotation_prevue' => 0.0, 'dotation_passee' => 0.0,
			'totalement_amorties' => 0, 'exercice' => (int) $exercice );
		foreach ( self::all() as $im ) {
			$o['nb']++;
			if ( self::estAnnulee( $im ) ) { $o['annulees']++; continue; }
			if ( 'cede' === (string) $im['statut'] ) { $o['cedees']++; continue; }
			$o['en_service']++;
			$cum = self::cumulAmorti( $im['id'] );
			$o['brut'] += (float) $im['valeur_acquisition']; $o['cumul'] += $cum;
			if ( ! self::estAmortissable( $im ) ) { $o['non_amortissables']++; continue; }
			$o['dotation_prevue'] += self::dotationPrevue( $im, $exercice );
			$o['dotation_passee'] += self::doteSurExercice( (int) $im['id'], $exercice );
			if ( $cum >= (float) $im['valeur_acquisition'] - (float) $im['valeur_residuelle'] - 0.5 ) { $o['totalement_amorties']++; }
		}
		$o['vnc'] = $o['brut'] - $o['cumul'];
		return $o;
	}
}
