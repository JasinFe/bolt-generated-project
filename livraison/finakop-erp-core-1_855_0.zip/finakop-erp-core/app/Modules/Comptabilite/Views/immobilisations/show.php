<?php /** @var array $im @var array $plan @var array $faits @var float $cumul @var float $vnc @var array $comptes @var array|null $flash @var string $tab */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$cede = 'cede'===$im['statut'];
$annulee = FKC_Immobilisation::estAnnulee( $im );
$blocages = (array) ( $blocages ?? array() );
$blocagesSuppression = (array) ( $blocagesSuppression ?? array() );
$contrepassation = $contrepassation ?? null;
$isAdmin = (bool) ( $isAdmin ?? true );
$amortissable = (bool) ( $amortissable ?? true );
$complement = (float) ( $complementAujourdhui ?? 0 );
?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $flash ) : ?><div class="alert alert-<?= 'err'===$flash['type']?'err':'ok' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<?php if ( $contrepassation && ! $annulee ) : ?>
	<div class="alert alert-err">L'écriture d'acquisition de cette fiche a été contre-passée (écriture n°<?= (int) $contrepassation ?>),
		mais la fiche, elle, est toujours en service : elle produira une dotation au prochain amortissement.
		Annulez-la ci-dessous si le bien ne doit pas figurer à l'actif.</div>
<?php endif; ?>
<?php if ( $annulee ) : ?>
	<div class="alert alert-warn">Fiche annulée<?= ! empty( $im['annule_at'] ) ? ' le ' . e( date( 'd/m/Y', strtotime( (string) $im['annule_at'] ) ) ) : '' ?><?= ! empty( $im['annule_motif'] ) ? ' — ' . e( (string) $im['annule_motif'] ) : '' ?>.
		Elle ne s'amortit plus et sort des totaux.
		<a href="<?= e( url( 'comptabilite/immobilisations/nouvelle?copie=' . (int) $im['id'] ) ) ?>">Reprendre la saisie dans une nouvelle fiche →</a></div>
<?php endif; ?>
<div class="card"><div class="card-head"><h2><?= e($im['libelle']) ?> <?php if($cede):?><span class="modbadge b-off">Cédée</span><?php endif;?><?php if($annulee):?><span class="modbadge b-err">Annulée</span><?php endif;?></h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url('comptabilite/immobilisations') ) ?>">← Immobilisations</a></div>
	<div class="card-body"><div class="stats" style="margin:0">
		<div class="stat"><span class="stat-label">Valeur d'acquisition</span><span class="stat-value" style="font-size:18px"><?= e( fkc_money($im['valeur_acquisition']) ) ?></span></div>
		<div class="stat"><span class="stat-label">Amortissements cumulés</span><span class="stat-value" style="font-size:18px"><?= e( fkc_money($cumul) ) ?></span></div>
		<div class="stat stat-accent"><span class="stat-label">Valeur nette comptable</span><span class="stat-value" style="font-size:18px;color:var(--orange)"><?= e( fkc_money($vnc) ) ?></span></div>
		<div class="stat"><span class="stat-label">Durée · acquisition</span><span class="stat-value" style="font-size:15px"><?= e($im['duree_annees']) ?> ans · <?= e( date('d/m/Y',strtotime($im['date_acquisition'])) ) ?></span></div>
	</div>

	<?php
	// Identification physique : le code-barres rend l'actif scannable au
	// récolement, le code interne l'identifie dans les comptes. Les deux
	// coexistent — l'un ne remplace pas l'autre.
	$cb = (string) ( $im['code_barres'] ?? '' );
	?>
	<div style="border-top:1px solid var(--line);margin-top:16px;padding-top:14px;display:flex;gap:22px;align-items:center;flex-wrap:wrap">
		<div style="min-width:180px">
			<div class="stat-label">Identification</div>
			<div style="font-family:monospace;font-size:13px;margin-top:4px">
				Code interne : <strong><?= e( (string) ( $im['code'] ?? '—' ) ) ?></strong><br>
				Code-barres : <strong><?= e( $cb ?: '—' ) ?></strong>
			</div>
			<?php if ( ! empty( $im['emplacement'] ) || ! empty( $im['detenteur'] ) ) : ?>
				<div class="muted" style="font-size:12.5px;margin-top:6px">
					<?= e( (string) ( $im['emplacement'] ?? '' ) ) ?><?= ! empty( $im['detenteur'] ) ? ' · ' . e( (string) $im['detenteur'] ) : '' ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $im['dernier_recolement'] ) ) : ?>
				<div class="muted" style="font-size:12.5px">Dernier récolement : <?= e( date( 'd/m/Y', strtotime( (string) $im['dernier_recolement'] ) ) ) ?></div>
			<?php endif; ?>
		</div>
		<?php if ( $cb ) : ?>
			<div style="text-align:center">
				<img src="<?= e( url( 'scan/image?code=' . rawurlencode( $cb ) . '&type=ean13&h=52' ) ) ?>" alt="code-barres" style="max-width:230px">
				<div style="margin-top:6px">
					<a class="btn btn-ghost btn-sm" target="_blank" href="<?= e( url( 'scan/planche?codes=' . rawurlencode( $cb ) . '&qte=1' ) ) ?>">🏷️ Imprimer l'étiquette</a>
				</div>
			</div>
		<?php endif; ?>
	</div>
	</div>
</div>
<?php
/*
 * CORRIGER LES COMPTES SANS DÉTRUIRE LA FICHE (1.726.0).
 *
 * Une erreur de compte d'amortissement ne se voit qu'au tableau des
 * amortissements de la clôture, parfois un an plus tard. Sans ce bloc, il
 * fallait supprimer l'immobilisation et la ressaisir — ce qui emportait son
 * historique de dotations avec elle.
 */
$fkcPasse = $dejaPasse ?? array( 'nombre' => 0, 'montant' => 0 );
?>
<div class="card" style="max-width:760px"><div class="card-head"><h2>Comptes d'imputation</h2></div>
<div class="card-body">
	<?php if ( ! empty( $reclassement ) ) : ?>
		<div class="alert alert-warn">
			<strong>Reclassement à passer vous-même.</strong>
			Les dotations déjà comptabilisées restent sur les anciens comptes : une écriture validée ne se
			réécrit pas, cela ne serait pas une correction. Voici l'OD telle qu'elle devrait être passée
			depuis <a href="<?= e( url( 'comptabilite/ecritures/nouvelle' ) ) ?>">Saisie d'écriture</a> —
            datez-la dans un exercice ouvert :
			<table class="table" style="margin-top:8px">
				<thead><tr><th>Compte</th><th>Libellé</th><th style="text-align:right">Débit</th><th style="text-align:right">Crédit</th></tr></thead>
				<tbody>
				<?php foreach ( $reclassement as $l ) : ?>
					<tr><td class="code"><?= e( $l['compte'] ) ?></td><td><?= e( $l['libelle'] ) ?></td>
						<td style="text-align:right"><?= $l['debit'] ? e( fkc_money( $l['debit'] ) ) : '' ?></td>
						<td style="text-align:right"><?= $l['credit'] ? e( fkc_money( $l['credit'] ) ) : '' ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="help" style="margin-bottom:0">
				Seul le cumul d'AMORTISSEMENT est proposé. La dotation des exercices antérieurs a déjà été
				soldée par le résultat : la reclasser aujourd'hui modifierait un résultat arrêté.
			</p>
		</div>
	<?php endif; ?>

	<form method="post" action="<?= e( url( 'comptabilite/immobilisations/' . (int) $im['id'] . '/comptes' ) ) ?>">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid">
			<label class="fld"><span>Immobilisation (classe 2)</span>
				<input type="text" name="compte_immo" value="<?= e( $im['compte_immo'] ) ?>"></label>
			<label class="fld"><span>Amortissement (28xx)</span>
				<input type="text" name="compte_amort" value="<?= e( $im['compte_amort'] ) ?>"></label>
			<label class="fld"><span>Dotation (68xx)</span>
				<input type="text" name="compte_dotation" value="<?= e( $im['compte_dotation'] ) ?>"></label>
		</div>
		<p class="help">
			Le compte doit exister au plan, ne pas être un compte de regroupement, et relever de sa classe —
			une dotation posée sur un compte de classe 4 passerait sans bruit et ne se verrait qu'au compte
			de résultat, là où personne ne cherche l'erreur d'une fiche d'immobilisation.
			<?php if ( $fkcPasse['nombre'] > 0 ) : ?>
				<br><strong><?= (int) $fkcPasse['nombre'] ?> dotation(s) déjà comptabilisée(s)</strong>
				pour <?= e( fkc_money( $fkcPasse['montant'] ) ) ?> : elles ne seront pas réécrites.
			<?php endif; ?>
		</p>
		<button class="btn btn-primary btn-sm">Corriger les comptes</button>
	</form>
</div></div>

<?php
/*
 * PLAN MENSUEL (1.765.0). En périodicité mensuelle, chaque exercice se
 * déplie en mois : la dotation est datée de la fin du mois qu'elle concerne,
 * et la somme des mois redonne exactement l'annuité affichée en tête de
 * groupe. En annuel, l'écran est inchangé.
 */
$mensuel = ! empty( $mensuel );
$planMensuel = $planMensuel ?? array();
$faitsMois = $faitsMois ?? array();
$moisNoms = array( 1 => 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre' );
$parExercice = array();
foreach ( $planMensuel as $r ) { $parExercice[ (int) $r['exercice'] ][] = $r; }
?>
<?php if ( ! $amortissable ) : ?>
<div class="card"><div class="card-body"><p class="help" style="margin:0"><strong>Bien non amortissable.</strong>
	Un terrain, des titres, une avance ou une immobilisation en cours ne se consomment pas : ils ne s'amortissent pas, ils se <em>déprécient</em>
	si leur valeur actuelle devient inférieure à leur valeur comptable. Aucun plan d'amortissement n'est donc calculé.</p></div></div>
<?php elseif ( $mensuel ) : ?>
<div class="card card-flush"><div class="card-head"><h2>Plan d'amortissement mensuel</h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/immobilisations/amortir' ) ) ?>">Périodicité →</a></div>
	<table class="table">
		<thead><tr><th>Période</th><th class="num">Dotation</th><th class="num">Cumul</th><th class="num">VNC fin</th><th>État</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $parExercice as $ex => $mois ) :
			$totalEx = array_sum( array_column( $mois, 'dotation' ) );
			$restants = array();
			foreach ( $mois as $m ) { if ( ! isset( $faitsMois[ $ex . '-' . (int) $m['mois'] ] ) ) { $restants[] = (int) $m['mois']; } }
		?>
			<tr class="total"><td><strong>Exercice <?= (int) $ex ?></strong></td>
				<td class="num"><strong><?= e( fkc_money( $totalEx ) ) ?></strong></td>
				<td colspan="3" class="muted"><?= count( $mois ) ?> mensualité(s)<?= $restants ? ', ' . count( $restants ) . ' à passer' : ' — toutes passées' ?></td>
				<td class="right"><?php if ( $restants && ! $cede && ! $annulee ) : ?>
					<form method="post" action="<?= e( url( 'comptabilite/immobilisations/' . $im['id'] . '/doter' ) ) ?>" style="margin:0"
						onsubmit="return confirm('Comptabiliser les <?= count( $restants ) ?> mensualité(s) restantes de <?= (int) $ex ?> ?')">
						<?= FKC_Csrf::field() ?><input type="hidden" name="exercice" value="<?= (int) $ex ?>">
						<input type="hidden" name="mois" value="<?= (int) $restants[0] ?>">
						<button class="btn btn-ghost btn-sm" type="submit">Comptabiliser <?= $moisNoms[ (int) $restants[0] ] ?></button>
					</form>
				<?php endif; ?></td></tr>
			<?php foreach ( $mois as $m ) : $etat = $faitsMois[ $ex . '-' . (int) $m['mois'] ] ?? ''; ?>
				<tr><td class="code" style="padding-left:24px"><?= e( $m['periode'] ) ?> · <?= e( $moisNoms[ (int) $m['mois'] ] ) ?></td>
					<td class="num"><?= e( fkc_money( $m['dotation'] ) ) ?></td>
					<td class="num muted"><?= e( fkc_money( $m['cumul'] ) ) ?></td>
					<td class="num"><?= e( fkc_money( $m['vnc'] ) ) ?></td>
					<td><?php if ( 'comptabilisee' === $etat ) : ?><span class="modbadge b-on">Comptabilisée</span>
						<?php elseif ( 'attente' === $etat ) : ?><span class="modbadge b-warn">Au journal temporaire</span>
						<?php else : ?><span class="muted">À comptabiliser</span><?php endif; ?></td>
					<td class="right"><?php if ( '' === $etat && ! $cede && ! $annulee ) : ?>
						<form method="post" action="<?= e( url( 'comptabilite/immobilisations/' . $im['id'] . '/doter' ) ) ?>" style="margin:0">
							<?= FKC_Csrf::field() ?><input type="hidden" name="exercice" value="<?= (int) $ex ?>">
							<input type="hidden" name="mois" value="<?= (int) $m['mois'] ?>">
							<button class="btn btn-primary btn-sm" type="submit">Comptabiliser</button></form>
					<?php endif; ?></td></tr>
			<?php endforeach; ?>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="help" style="padding:0 14px 12px">Chaque dotation est datée du dernier jour de son mois. La somme des mensualités d'un exercice est exactement l'annuité du plan linéaire.</p>
</div>
<?php else : ?>
<div class="card card-flush"><div class="card-head"><h2>Plan d'amortissement linéaire</h2>
	<a class="btn btn-ghost btn-sm" href="<?= e( url( 'comptabilite/immobilisations/amortir' ) ) ?>">Périodicité →</a></div>
	<table class="table"><thead><tr><th>Exercice</th><th class="num">Dotation</th><th class="num">Cumul</th><th class="num">VNC fin</th><th>État</th><th></th></tr></thead>
	<tbody>
	<?php foreach ( $plan as $r ) : $fait = isset($faits[$r['exercice']]); $attente = $fait && empty( $faits[ $r['exercice'] ]['ecriture_id'] ); ?>
		<tr><td><strong><?= (int)$r['exercice'] ?></strong></td><td class="num"><?= e( fkc_money($r['dotation']) ) ?></td>
		<td class="num muted"><?= e( fkc_money($r['cumul']) ) ?></td><td class="num"><?= e( fkc_money($r['vnc']) ) ?></td>
		<td><?php if($attente):?><span class="modbadge b-warn">Au journal temporaire</span><?php elseif($fait):?><span class="modbadge b-on">Comptabilisée</span><?php elseif($cede || $annulee):?><span class="muted">—</span><?php else:?><span class="muted">À comptabiliser</span><?php endif;?></td>
		<td class="right"><?php if(!$fait && !$cede && !$annulee):?>
			<form method="post" action="<?= e( url('comptabilite/immobilisations/'.$im['id'].'/doter') ) ?>" style="margin:0"><?= FKC_Csrf::field() ?><input type="hidden" name="exercice" value="<?= (int)$r['exercice'] ?>"><button class="btn btn-primary btn-sm" type="submit">Comptabiliser</button></form>
		<?php endif;?></td></tr>
	<?php endforeach; ?>
	</tbody>
	</table>
</div>
<?php endif; ?>
<?php if ( ! $cede && ! $annulee ) : ?>
<div class="card" style="max-width:720px"><div class="card-head"><h2>Céder ou mettre au rebut</h2></div><div class="card-body">
	<?php if ( $complement > 0 ) : ?>
		<p class="help" style="margin-top:0">Une cession aujourd'hui passera d'abord la <strong>dotation complémentaire</strong> de l'exercice, au prorata jusqu'à la date de sortie :
			<strong><?= e( fkc_money( $complement ) ) ?> FCFA</strong> (VNC de sortie estimée : <?= e( fkc_money( $vnc - $complement ) ) ?> FCFA).</p>
	<?php endif; ?>
	<form method="post" action="<?= e( url('comptabilite/immobilisations/'.$im['id'].'/ceder') ) ?>" onsubmit="return confirm('Confirmer la cession ? Cette action génère l\'écriture de sortie.')">
		<?= FKC_Csrf::field() ?>
		<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
			<label class="fld"><span>Date de cession</span><input type="date" name="date_cession" value="<?= e(date('Y-m-d')) ?>" required></label>
			<label class="fld"><span>Prix de cession</span><input class="num" name="valeur_cession" placeholder="0 = mise au rebut" inputmode="decimal"></label>
			<label class="fld"><span>Encaissé sur</span><select name="tresorerie_id"><option value="0">— aucun (mise au rebut) —</option><?php foreach($comptes as $c):?><option value="<?= (int)$c['id'] ?>"><?= e($c['libelle']) ?></option><?php endforeach;?></select></label>
		</div>
		<div class="actions"><button class="btn btn-ghost" type="submit" style="border-color:var(--danger);color:var(--danger)">Enregistrer la cession</button></div>
		<?php $csn = FKC_Immobilisation::numerosCession( $im['compte_immo'] ); ?>
		<p class="help" style="margin-top:8px">Écriture : valeur comptable (<?= e( $csn['vc'] ) ?>)<?= '' !== (string) $im['compte_amort'] ? ' + amortissements (' . e( $im['compte_amort'] ) . ')' : '' ?> au débit, immobilisation (<?= e($im['compte_immo']) ?>) au crédit, prix encaissé / produit de cession (<?= e( $csn['produit'] ) ?>). Sans prix : mise au rebut, sans encaissement.</p>
	</form>
</div></div>
<?php else : ?>
	<div class="alert" style="background:var(--bg2);border:1px solid var(--line);color:var(--text)">Immobilisation cédée le <?= e( date('d/m/Y',strtotime($im['date_cession'])) ) ?> pour <?= e( fkc_money($im['valeur_cession']) ) ?> FCFA.</div>
<?php endif; ?>

<?php FKC_View::partial( 'comptabilite::_pieces', array(
	'pieces'       => $pieces ?? array(),
	'piecesUpload' => 'comptabilite/immobilisations/' . (int) $im['id'] . '/pieces',
	'piecesBase'   => 'comptabilite/immobilisations/piece',
) ); ?>

<?php
/*
 * ANNULER OU SUPPRIMER LA FICHE (1.761.0).
 *
 * Le module n'offrait aucun retour en arrière : une fiche créée sur une
 * écriture erronée restait à l'actif et continuait de s'amortir. L'annulation
 * est le geste courant ; la suppression définitive est réservée à
 * l'administrateur et à la fiche qui n'a rien laissé derrière elle.
 */
?>
<div class="card" style="max-width:760px"><div class="card-head"><h2>Annuler la fiche</h2></div><div class="card-body">
<?php if ( $annulee ) : ?>
	<p class="help" style="margin-top:0">Cette fiche est déjà annulée. Elle reste consultable, avec son code d'inventaire, pour la trace de ce qui a été scanné.</p>
<?php elseif ( $blocages ) : ?>
	<p class="help" style="margin-top:0">Annulation impossible en l'état :</p>
	<ul class="help"><?php foreach ( $blocages as $b ) : ?><li><?= e( $b ) ?></li><?php endforeach; ?></ul>
<?php else : ?>
	<p class="help" style="margin-top:0">Aucune dotation n'a été passée sur ce bien : la fiche peut être annulée.
		Elle sortira de l'amortissement, des totaux et du récolement, mais restera consultable.
		<strong>L'écriture d'acquisition n'est pas touchée</strong> — contre-passez-la depuis l'écran des écritures si elle est erronée<?= ! empty( $im['ecriture_acq_id'] ) ? ' (écriture n°' . (int) $im['ecriture_acq_id'] . ')' : '' ?>.</p>
	<form method="post" action="<?= e( url( 'comptabilite/immobilisations/' . (int) $im['id'] . '/annuler' ) ) ?>"
		onsubmit="return confirm('Annuler cette fiche ? Elle ne s\'amortira plus.')" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0;min-width:280px"><span>Motif</span><input name="motif" placeholder="Erreur sur l'écriture d'origine"></label>
		<button class="btn btn-primary" type="submit">Annuler la fiche</button>
	</form>
<?php endif; ?>

<?php if ( $isAdmin ) : ?>
	<hr style="border-color:var(--line);margin:14px 0">
	<?php if ( $blocagesSuppression ) : ?>
		<p class="help" style="margin:0">Suppression définitive impossible :</p>
		<ul class="help"><?php foreach ( $blocagesSuppression as $b ) : ?><li><?= e( $b ) ?></li><?php endforeach; ?></ul>
	<?php else : ?>
		<p class="help" style="margin:0">Cette fiche n'a ni dotation, ni cession, ni justificatif, ni passage au récolement : elle peut être effacée sans laisser de trou.
			L'annulation reste préférable si le bien a existé.</p>
		<form method="post" action="<?= e( url( 'comptabilite/immobilisations/' . (int) $im['id'] . '/supprimer' ) ) ?>"
			onsubmit="return confirm('Supprimer DÉFINITIVEMENT cette fiche ? Cette action est irréversible.')" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;margin-top:8px">
			<?= FKC_Csrf::field() ?>
			<label class="fld" style="margin:0;min-width:280px"><span>Motif (tracé au journal de sécurité)</span><input name="motif" placeholder="Saisie en double"></label>
			<button class="btn btn-ghost" type="submit">Supprimer définitivement</button>
		</form>
	<?php endif; ?>
<?php endif; ?>
</div></div>
