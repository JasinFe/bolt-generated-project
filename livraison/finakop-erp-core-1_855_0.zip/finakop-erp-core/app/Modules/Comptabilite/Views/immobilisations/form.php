<?php /** @var array $plan @var array $errors @var string $tab @var float $seuil @var array $old @var bool $belowSeuil */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$old = $old ?? array(); $seuil = $seuil ?? 0; $belowSeuil = $belowSeuil ?? false;
$v = function ( $k, $def = '' ) use ( $old ) { return e( $old[ $k ] ?? $def ); };
$copie = (int) ( $old['__copie'] ?? 0 );
?>
<?php FKC_View::partial( 'comptabilite::_immo_subnav' ); ?>
<?php if ( $copie ) : ?>
	<div class="alert alert-warn">Reprise de la fiche n°<?= $copie ?> : les valeurs sont recopiées, mais le code d'inventaire et le code-barres ne le sont pas —
		ils appartiennent à la fiche d'origine, qui les garde.</div>
<?php endif; ?>
<?php foreach ( $errors as $e ) : ?><div class="alert alert-err"><?= e( $e ) ?></div><?php endforeach; ?>
<?php if ( $belowSeuil ) : ?>
<div class="alert alert-warn">
	<strong>Bien de faible valeur.</strong> La valeur d'acquisition saisie est inférieure au seuil d'immobilisation
	(<?= e( fkc_money( $seuil ) ) ?> FCFA). Selon le SYSCOHADA et les règles DGI, un tel bien peut être <strong>comptabilisé directement en charges</strong>
	(compte de classe 6) plutôt qu'immobilisé et amorti. Pour l'immobiliser malgré tout, cochez la case ci-dessous puis enregistrez.
</div>
<?php endif; ?>
<div class="card" style="max-width:760px"><div class="card-head"><h2>Nouvelle immobilisation</h2></div><div class="card-body">
<form method="post" action="<?= e( url('comptabilite/immobilisations') ) ?>">
	<?= FKC_Csrf::field() ?>
	<div class="form-grid" style="grid-template-columns:1fr 2fr">
		<label class="fld"><span>Code</span><input name="code" value="<?= $v('code') ?>" placeholder="auto — IMMO-00001">
			<small class="help">Laissez vide : le code d'inventaire est attribué automatiquement.</small></label>
		<label class="fld"><span>Libellé</span><input name="libelle" required value="<?= $v('libelle') ?>" placeholder="Ordinateur portable Dell"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr">
		<label class="fld"><span>Date d'acquisition</span><input type="date" name="date_acquisition" value="<?= $v('date_acquisition', date('Y-m-d')) ?>" required></label>
		<label class="fld"><span>Valeur d'acquisition</span><input class="num" id="immoVal" name="valeur_acquisition" value="<?= $v('valeur_acquisition') ?>" required<?php if ( $seuil > 0 ) : ?> data-seuil="<?= e( $seuil ) ?>"<?php endif; ?>>
			<?php if ( $seuil > 0 ) : ?><small class="help">Seuil d'immobilisation : <?= e( fkc_money( $seuil ) ) ?> FCFA</small><?php endif; ?>
			<small class="help" id="immoSeuilHint" style="display:none;color:var(--orange)">⚠ Sous le seuil — à passer en charges, sauf si vous immobilisez volontairement.</small>
		</label>
		<label class="fld"><span>Valeur résiduelle</span><input class="num" name="valeur_residuelle" value="<?= $v('valeur_residuelle', '0') ?>"></label>
	</div>
	<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr 1fr">
		<label class="fld"><span>Durée (années)</span><input class="num" name="duree_annees" value="<?= $v('duree_annees', '3') ?>" required></label>
		<label class="fld"><span>Compte immo</span>
			<input class="code" id="immoCompte" name="compte_immo" list="immoComptesDispo" value="<?= $v('compte_immo', '241000') ?>">
			<small class="help" id="immoCompteLib"></small>
		</label>
		<label class="fld"><span>Compte amort.</span><input class="code" id="immoAmort" name="compte_amort" value="<?= $v('compte_amort', '284100') ?>">
			<?php
			/*
			 * TÉMOIN DE RATTACHEMENT MANUEL (1.729.0).
			 *
			 * Il distingue un CHOIX d'un vestige d'écran. Le champ est
			 * pré-rempli d'après le compte d'immobilisation ; si l'utilisateur
			 * change ensuite ce dernier sans que le script suive, la valeur
			 * restée là n'est pas un choix. Le témoin n'est posé que lorsque le
			 * champ a réellement été touché — et alors le rattachement est
			 * retenu tel quel, même s'il ne ressemble pas au numéro d'origine :
			 * 241110 → 284410 est licite, et c'était impossible jusqu'ici.
			 */
			?>
			<input type="hidden" id="immoAmortManuel" name="amort_manuel" value="">
			<small class="help" id="immoAmortLib"></small>
		</label>
		<label class="fld"><span>Compte dotation</span><input class="code" id="immoDotation" name="compte_dotation" value="<?= $v('compte_dotation', '681300') ?>"></label>
	</div>
	<?php
	/*
	 * LA CORRESPONDANCE EST DÉDUITE, PAS SAISIE.
	 *
	 * Les trois champs arrivaient pré-remplis avec les mêmes valeurs pour tout
	 * le monde. On choisissait un logiciel en 213100 sans penser à corriger les
	 * deux autres, et l'amortissement partait en 2841 « matériel industriel ».
	 * Le total du tableau des amortissements restait juste, sa ventilation non
	 * — et c'est la ventilation qu'un contrôleur regarde.
	 *
	 * La table est posée en clair dans la page : le modèle refait le même
	 * calcul à l'enregistrement, de sorte qu'un navigateur sans script obtienne
	 * exactement le même résultat.
	 */
	$mapImmo = class_exists( 'FKC_MappingAmortissement' ) ? FKC_MappingAmortissement::table() : array();
	?>
	<?php if ( $mapImmo ) : ?>
	<datalist id="immoComptesDispo">
		<?php foreach ( $mapImmo as $racine => $m ) : ?>
			<option value="<?= e( $racine ) ?>000"><?= e( $m['libelle_immo'] ) ?></option>
		<?php endforeach; ?>
	</datalist>
	<div class="alert" id="immoMapInfo" style="display:none;background:rgba(70,130,200,.12);color:var(--text);border:1px solid rgba(70,130,200,.35)"></div>
	<script>
	(function () {
		var MAP = <?= json_encode( array_map( function ( $m ) {
			return array(
				'l' => $m['libelle_immo'],
				'a' => $m['amortissement'], 'al' => $m['libelles']['amortissement'] ?? '',
				'd' => $m['dotation'],      'dl' => $m['libelles']['dotation'] ?? '',
				'p' => $m['depreciation'],  'pl' => $m['libelles']['depreciation'] ?? '',
				'ok' => $m['amortissable'] ? 1 : 0, 'm' => $m['motif'],
			);
		}, $mapImmo ), JSON_UNESCAPED_UNICODE ) ?>;
		var immo = document.getElementById('immoCompte'),
		    amo = document.getElementById('immoAmort'),
		    dot = document.getElementById('immoDotation'),
		    info = document.getElementById('immoMapInfo'),
		    libI = document.getElementById('immoCompteLib'),
		    libA = document.getElementById('immoAmortLib'),
		    manuel = document.getElementById('immoAmortManuel');

		if (amo && manuel) {
			/* Une frappe de l'utilisateur pose le témoin ; un changement de
			   compte d'immobilisation le retire, puisque la proposition va
			   être recalculée. */
			amo.addEventListener('input', function () { manuel.value = '1'; });
			if (immo) { immo.addEventListener('input', function () { manuel.value = ''; }); }
		}
		if (!immo) { return; }
		function appliquer(force) {
			var n = (immo.value || '').replace(/[^0-9]/g, '');
			var m = MAP[n.substring(0, 3)];
			libI.textContent = m ? m.l : '';
			if (!m) { info.style.display = 'none'; libA.textContent = ''; return; }
			if (!m.ok) {
				// Un terrain nu ou un titre ne s'amortit pas : il se déprécie.
				// Le dire ici évite un plan d'amortissement sur un bien qui ne
				// se consomme pas.
				amo.value = ''; dot.value = '';
				libA.textContent = '';
				// Sans amortissement, la durée ne sert à rien : elle n'est plus exigée (1.855.0).
				var du = document.querySelector('[name=duree_annees]'); if (du) { du.required = false; }
                info.innerHTML = '<strong>Bien non amortissable.</strong> ' + m.m
					+ (m.p ? ' Compte de dépréciation : <span class="code">' + m.p + '</span> — ' + m.pl + '.' : '');
				info.style.display = '';
				return;
			}
			// On ne remplace un compte saisi que s'il ne partage pas la racine
			// attendue : un choix délibéré du comptable est respecté.
			if (force || !amo.value || amo.value.substring(0, 3) !== m.a.substring(0, 3)) { amo.value = m.a; }
			if (force || !dot.value || dot.value.substring(0, 3) !== m.d.substring(0, 3)) { dot.value = m.d; }
			libA.textContent = m.al;
			info.innerHTML = 'Amortissement <span class="code">' + m.a + '</span> ' + m.al
				+ ' · dotation <span class="code">' + m.d + '</span> ' + m.dl
				+ (m.p ? ' · dépréciation <span class="code">' + m.p + '</span>' : '');
			info.style.display = '';
		}
		immo.addEventListener('change', function () { appliquer(true); });
		immo.addEventListener('blur', function () { appliquer(false); });
		appliquer(false);
	})();
	</script>
	<?php endif; ?>
	<?php
	// Pont Immobilisations ↔ Analytique : la dotation (6813) est imputée à cette division.
	$immoDivisions = ( class_exists( 'FKC_Division' ) && class_exists( 'FKC_License' ) && FKC_License::moduleEnabled( 'analytique' ) ) ? FKC_Division::all( true ) : array();
	if ( $immoDivisions ) : $immoDiv = (int) $v( 'division_id', '0' ); ?>
	<div class="form-grid" style="grid-template-columns:1fr 1fr">
		<label class="fld"><span>Division (analytique)</span>
			<select name="division_id">
				<option value="">— non imputé —</option>
				<?php foreach ( $immoDivisions as $dv ) : ?><option value="<?= (int) $dv['id'] ?>" <?= $immoDiv === (int) $dv['id'] ? 'selected' : '' ?>><?= e( $dv['libelle'] ) ?></option><?php endforeach; ?>
			</select>
			<small class="help">La charge de dotation annuelle sera imputée à cette division.</small>
		</label>
	</div>
	<?php endif; ?>
	<?php if ( $belowSeuil ) : ?>
	<label class="fld inline" style="margin:4px 0 10px"><input type="checkbox" name="immo_force" value="1" style="width:auto"> <span>Immobiliser malgré tout (au-dessus de mon appréciation, ne pas passer en charges)</span></label>
	<?php endif; ?>
	<div class="actions"><button class="btn btn-primary" type="submit"><?= $belowSeuil ? 'Confirmer l\'immobilisation' : 'Enregistrer' ?></button><a class="btn btn-ghost" href="<?= e( url('comptabilite/immobilisations') ) ?>">Annuler</a></div>
	<p class="help" style="margin-top:8px">Amortissement linéaire calculé au prorata temporis (base 360 jours). Le plan d'amortissement s'affiche après création.</p>
</form>
</div></div>
<script>
(function(){
	var inp=document.getElementById('immoVal'); if(!inp||!inp.dataset.seuil)return;
	var seuil=parseFloat(inp.dataset.seuil), hint=document.getElementById('immoSeuilHint');
	function chk(){ var val=parseFloat((inp.value||'').replace(/[ ,]/g,function(c){return c===','?'.':'';})); hint.style.display=(!isNaN(val)&&val>0&&val<seuil)?'block':'none'; }
	inp.addEventListener('input',chk); chk();
})();
</script>
