<?php /** @var string $annee @var array $annees @var array $d @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$ef = $d['effectif']; $ms = $d['masse']; $al = $d['alertes']; $k = $d['kpi'];
$nbAlertes = count( $al['contrats'] ) + count( $al['essais'] ) + count( $al['visites'] ); ?>
<?php FKC_View::partial( 'rh::_subnav', array( 'tab' => 'dashboard' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="bar"><span class="muted">Vue d'ensemble RH — exercice <?= e( $annee ) ?></span>
	<form method="get" style="display:flex;gap:6px;align-items:center"><span class="muted">Exercice</span>
		<select name="annee" onchange="this.form.submit()"><?php foreach ( $annees as $y ) : ?><option value="<?= e( $y ) ?>" <?= $y===$annee?'selected':'' ?>><?= e( $y ) ?></option><?php endforeach; ?></select></form>
</div>

<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Effectif actif</span><div style="font-size:1.6em;font-weight:700"><?= (int) $ef['actifs'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Recrutements <?= e( $annee ) ?></span><div style="font-size:1.6em;font-weight:700;color:var(--ok)">+<?= (int) $ef['nouveaux'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Départs <?= e( $annee ) ?></span><div style="font-size:1.6em;font-weight:700;color:var(--danger)">−<?= (int) $ef['departs'] ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Alertes</span><div style="font-size:1.6em;font-weight:700;color:<?= $nbAlertes?'var(--orange)':'var(--ok)' ?>"><?= (int) $nbAlertes ?></div></div></div>
</div>

<div class="form-grid" style="margin-bottom:16px">
	<div class="card"><div class="card-body"><span class="muted">Masse salariale (mois)</span><div style="font-size:1.3em;font-weight:700"><?= e( fkc_money( $ms['mois'] ) ) ?></div><span class="muted" style="font-size:.8em">Théorique, employés actifs</span></div></div>
	<div class="card"><div class="card-body"><span class="muted">Masse salariale (année)</span><div style="font-size:1.3em;font-weight:700"><?= e( fkc_money( $ms['annee'] ) ) ?></div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Absentéisme</span><div style="font-size:1.3em;font-weight:700"><?= e( $k['absenteisme'] ) ?> %</div></div></div>
	<div class="card"><div class="card-body"><span class="muted">Turnover</span><div style="font-size:1.3em;font-weight:700"><?= e( $k['turnover'] ) ?> %</div></div></div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>Alertes RH</h2></div>
	<table class="table">
		<thead><tr><th>Type</th><th>Employé</th><th>Échéance</th></tr></thead>
		<tbody>
		<?php
		$blocs = array(
			'Contrat expirant' => $al['contrats'],
			'Fin de période d\'essai' => $al['essais'],
			'Visite médicale' => $al['visites'],
		);
		$vide = true;
		foreach ( $blocs as $lib => $rows ) : foreach ( $rows as $r ) : $vide = false; $ech = $r['ech']; $urgent = $ech < date( 'Y-m-d' ); ?>
			<tr><td><span class="modbadge <?= $urgent?'b-off':'' ?>"><?= e( $lib ) ?></span></td>
				<td><a href="<?= e( url( 'rh/employes/' . (int) $r['id'] ) ) ?>"><?= e( trim( ( $r['prenom'] ?? '' ) . ' ' . $r['nom'] ) ) ?></a></td>
				<td class="code" style="<?= $urgent?'color:var(--danger)':'' ?>"><?= e( $ech ) ?><?= $urgent?' (dépassée)':'' ?></td></tr>
		<?php endforeach; endforeach; ?>
		<?php if ( $vide ) : ?><tr><td colspan="3" class="empty">Aucune alerte sur les 60 prochains jours.</td></tr><?php endif; ?>
		</tbody>
	</table>
</div>
