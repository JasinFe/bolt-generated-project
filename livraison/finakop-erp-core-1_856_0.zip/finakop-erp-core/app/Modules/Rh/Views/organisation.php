<?php /** @var array $depts @var array $effectifs @var array $managers @var mixed $flash */ defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$nom = function ( $m ) { return FKC_Employe::nomComplet( $m ); }; ?>
<?php FKC_View::partial( 'rh::_subnav', array( 'tab' => 'organisation' ) ); ?>
<?php if ( $flash ) : ?><div class="alert alert-ok"><?= e( $flash ) ?></div><?php endif; ?>
<div class="card"><div class="card-head"><h2>Nouveau département / service</h2></div><div class="card-body">
	<form method="post" action="<?= e( url( 'rh/organisation' ) ) ?>" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap">
		<?= FKC_Csrf::field() ?>
		<label class="fld" style="margin:0"><span>Code</span><input name="code" maxlength="20" required style="width:110px;text-transform:uppercase"></label>
		<label class="fld" style="margin:0;min-width:200px"><span>Libellé</span><input name="libelle" required></label>
		<label class="fld" style="margin:0"><span>Site</span><input name="site"></label>
		<label class="fld" style="margin:0;min-width:180px"><span>Responsable</span><select name="responsable_id"><option value="">—</option><?php foreach ( $managers as $m ) : ?><option value="<?= (int) $m['id'] ?>"><?= e( $nom( $m ) ) ?></option><?php endforeach; ?></select></label>
		<button class="btn btn-primary" type="submit">Ajouter</button>
	</form>
</div></div>
<div class="card card-flush"><table class="table">
	<thead><tr><th>Code</th><th>Département</th><th>Site</th><th class="num">Effectif</th><th></th></tr></thead>
	<tbody>
	<?php if ( ! $depts ) : ?><tr><td colspan="5" class="empty">Aucun département.</td></tr>
	<?php else : foreach ( $depts as $d ) : ?>
		<tr><td class="code"><?= e( $d['code'] ) ?></td><td><strong><?= e( $d['libelle'] ) ?></strong><?= empty( $d['actif'] ) ? ' <span class="modbadge b-off">Inactif</span>' : '' ?></td>
			<td><?= e( $d['site'] ?: '—' ) ?></td>
			<td class="num"><?= (int) ( $effectifs[ (int) $d['id'] ] ?? 0 ) ?></td>
			<td class="right"><form method="post" action="<?= e( url( 'rh/organisation/' . (int) $d['id'] . '/supprimer' ) ) ?>" onsubmit="return confirm('Supprimer ce département ?')"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm">Supprimer</button></form></td></tr>
	<?php endforeach; endif; ?>
	</tbody>
</table></div>
