<?php
/**
 * Écrans stock des packs de commerce de détail (brique stock du moteur
 * vertical) : catalogue d'articles, entrées (achats), ventes (sorties
 * valorisées au CUMP) et historique des mouvements. Comptabilité générée
 * automatiquement par le moteur d'événements.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpStockController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpStock::ensure();
		/*
		 * BAZ-001 — le catalogue doit exister AVANT que la fiche article ne
		 * propose son sélecteur de catégories. Les deux appels sont
		 * idempotents : la semence est protégée par une sentinelle en base,
		 * le rattrapage ne touche que les articles encore sans catégorie.
		 */
		if ( class_exists( 'FKC_VpCategorie' ) ) {
			FKC_VpCategorie::ensure();
			FKC_VpCategorie::semer( (array) ( $this->cfg['stock']['categories'] ?? array() ), null, (string) ( $this->cfg['stock']['categories_origine'] ?? FKC_VpCategorie::SYSTEME ) );
			FKC_VpCategorie::rattraperArticles();
		}
		if ( class_exists( 'FKC_VpAttribut' ) ) { FKC_VpAttribut::ensure(); }
		if ( class_exists( 'FKC_VpCapacite' ) ) { FKC_VpCapacite::ensure(); }
		if ( class_exists( 'FKC_VpMarque' ) ) { FKC_VpMarque::ensure(); }
		if ( class_exists( 'FKC_VpArticleLie' ) ) { FKC_VpArticleLie::ensure(); }
		if ( class_exists( 'FKC_VpLot' ) ) { FKC_VpLot::ensure(); }
		if ( class_exists( 'FKC_VpDepot' ) && FKC_VpDepot::actif( $this->cfg ) ) {
			FKC_VpDepot::ensure();
			// Idempotent : n'affecte que le stock qui n'est ventilé nulle part.
			// Sans lui, activer le multi-dépôt bloquerait toutes les ventes
			// d'un magasin dont le stock existait déjà.
			FKC_VpDepot::rattraper();
		}
	}

	/** Catalogue + KPI stock. */
	public function index() {
		FKC_View::render( 'vertical.stock', array(
			'title' => 'Articles & stock', 'module' => $this->module, 'cfg' => $this->cfg,
			'kpi'   => FKC_VpStock::kpi(),
			'rows'  => FKC_VpStock::articles( true ),
			'alertes' => FKC_VpStock::alertes(),
			'flash' => $this->flash(),
		) );
	}

	public function articleCreate() {
		FKC_View::render( 'vertical.stock_article_form', array(
			'title' => 'Nouvel article', 'module' => $this->module, 'cfg' => $this->cfg,
			'row'   => null, 'reference' => FKC_VpStock::nextRef(),
			// BAZ-002 : à la création, la catégorie n'est pas encore choisie —
			// on ne propose donc que les caractéristiques valables partout.
			// Celles du rayon apparaissent dès le premier enregistrement.
			'attributs' => class_exists( 'FKC_VpAttribut' ) ? FKC_VpAttribut::pourCategorie( null ) : array(),
			'attributsValeurs' => array(),
			'capacitesOffertes' => class_exists( 'FKC_VpCapacite' ) ? FKC_VpCapacite::offertes( $this->cfg ) : array(),
			'capacitesActives'  => class_exists( 'FKC_VpCapacite' ) ? FKC_VpCapacite::actives( array() ) : array(),
			'marques'  => $this->marquesProposees(),
			'articlesLies' => array(),
			'typesLien'    => class_exists( 'FKC_VpArticleLie' ) ? FKC_VpArticleLie::types() : array(),
			'articlesLiables' => array(),
			// Seuls les articles qui ne sont pas déjà eux-mêmes des variantes
			// peuvent servir de modèle (COM-021 : pas d'imbrication).
			'modeles' => array_values( array_filter( FKC_VpStock::articles( true ), function ( $a ) { return empty( $a['variante_parent_id'] ); } ) ),
			'variantesDuModele' => array(),
		) );
	}

	public function articleStore() {
		list( $ok, $msg, $id ) = FKC_VpStock::createArticle( $_POST );
		if ( $ok && $id ) { $msg = $this->enregistrerAttributs( (int) $id, $msg ); }
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock' );
	}

	/**
	 * BAZ-002 — enregistre les caractéristiques saisies. L'article existe
	 * déjà à ce stade : un refus de validation ne l'annule pas, il le laisse
	 * enregistré SANS ses caractéristiques, et le dit clairement plutôt que
	 * de faire croire que tout est passé.
	 */
	protected function enregistrerAttributs( $articleId, $msgBase ) {
		$msgBase = $this->enregistrerCapacites( (int) $articleId, $msgBase );
		if ( ! class_exists( 'FKC_VpAttribut' ) ) { return $msgBase; }
		$saisie = isset( $_POST['attributs'] ) && is_array( $_POST['attributs'] ) ? $_POST['attributs'] : array();
		list( $okAtt, $msgAtt ) = FKC_VpAttribut::enregistrer( (int) $articleId, $saisie );
		if ( ! $okAtt ) {
			return $msgBase . ' En revanche, les caractéristiques n\'ont pas été retenues : ' . $msgAtt;
		}
		return $msgBase;
	}

	public function articleEdit( $id ) {
		$a = FKC_VpStock::article( $id );
		if ( ! $a ) { redirect( $this->module . '/stock' ); }
		FKC_View::render( 'vertical.stock_article_form', array(
			'title' => 'Modifier — ' . $a['libelle'], 'module' => $this->module, 'cfg' => $this->cfg,
			'row'   => $a, 'reference' => $a['reference'],
			'modeles' => array_values( array_filter( FKC_VpStock::articles( true ), function ( $x ) use ( $id ) {
				return empty( $x['variante_parent_id'] ) && (int) $x['id'] !== (int) $id;
			} ) ),
			'variantesDuModele' => empty( $a['variante_parent_id'] ) ? FKC_VpStock::variantes( $id ) : array(),
			'unites' => class_exists( 'FKC_VpUnite' ) ? FKC_VpUnite::pourArticle( $id ) : array(),
			'attributs' => class_exists( 'FKC_VpAttribut' ) ? FKC_VpAttribut::pourArticle( $a ) : array(),
			'attributsValeurs' => class_exists( 'FKC_VpAttribut' ) ? FKC_VpAttribut::valeursParId( (int) $a['id'] ) : array(),
			'capacitesOffertes' => class_exists( 'FKC_VpCapacite' ) ? FKC_VpCapacite::offertes( $this->cfg ) : array(),
			'capacitesActives'  => class_exists( 'FKC_VpCapacite' ) ? FKC_VpCapacite::actives( $a ) : array(),
			'marques'  => $this->marquesProposees(),
			'articlesLies' => class_exists( 'FKC_VpArticleLie' ) ? FKC_VpArticleLie::pourArticle( (int) $a['id'] ) : array(),
			'typesLien'    => class_exists( 'FKC_VpArticleLie' ) ? FKC_VpArticleLie::types() : array(),
			// Tout le catalogue sauf l'article lui-même : on ne s'associe pas
			// à soi-même, et le proposer dans la liste inviterait à essayer.
			'articlesLiables' => array_values( array_filter( FKC_VpStock::articles(), function ( $x ) use ( $a ) {
				return (int) $x['id'] !== (int) $a['id'];
			} ) ),
		) );
	}

	/**
	 * ELM-001 — enregistre les capacités cochées. Le formulaire n'envoie le
	 * témoin `capacites_form` que si le pack en propose : sans lui, on ne
	 * touche à rien plutôt que d'interpréter une absence comme un « tout
	 * décoché », ce qui retirerait la gestion de stock à chaque
	 * enregistrement — un article vidé de sa capacité la plus élémentaire
	 * par un formulaire qui ne la connaissait même pas.
	 */
	protected function enregistrerCapacites( $articleId, $msgBase ) {
		if ( ! class_exists( 'FKC_VpCapacite' ) || ! isset( $_POST['capacites_form'] ) ) { return $msgBase; }
		$demandees = isset( $_POST['capacites'] ) && is_array( $_POST['capacites'] ) ? $_POST['capacites'] : array();
		list( $ok, $note ) = FKC_VpCapacite::definir( (int) $articleId, $demandees, $this->cfg );
		if ( ! $ok ) { return $msgBase . ' Les capacités n\'ont pas été modifiées : ' . $note; }
		return $note ? $msgBase . ' ' . $note : $msgBase;
	}

	/**
	 * ELM-004 — Marques proposées à la fiche. Vide si le métier ne les
	 * déclare pas : la fiche n'affiche alors aucun sélecteur, plutôt qu'une
	 * liste toujours vide qu'il faudrait expliquer.
	 */
	/**
	 * ELM-005 — accessoires proposables par article, pour l'écran de vente.
	 * Seuls les articles qui en ont figurent dans la table : inutile de
	 * charger le catalogue entier pour une poignée d'associations.
	 */
	protected function suggestionsParArticle() {
		if ( ! class_exists( 'FKC_VpArticleLie' ) ) { return array(); }
		$out = array();
		foreach ( FKC_VpStock::articles() as $a ) {
			$sug = FKC_VpArticleLie::suggestions( (int) $a['id'] );
			if ( ! $sug ) { continue; }
			$out[ (int) $a['id'] ] = array_map( function ( $l ) {
				return array( 'libelle' => $l['libelle'], 'prix' => (float) $l['prix_vente'], 'type' => FKC_VpArticleLie::labelType( $l['type'] ) );
			}, $sug );
		}
		return $out;
	}

	/** Dépôts proposés aux écrans — vide si le métier n'en gère qu'un. */
	protected function depotsProposes() {
		if ( ! class_exists( 'FKC_VpDepot' ) || ! FKC_VpDepot::actif( $this->cfg ) ) { return array(); }
		return FKC_VpDepot::options();
	}

	protected function marquesProposees() {
		if ( ! class_exists( 'FKC_VpMarque' ) || ! FKC_VpMarque::offert( $this->cfg ) ) { return array(); }
		return FKC_VpMarque::options();
	}

	/* ── Unités de vente multiples (COM-023) ──────────────────────────────── */

	public function uniteStore( $id ) {
		list( $ok, $msg ) = FKC_VpUnite::creer( (int) $id, $_POST['libelle'] ?? '', $_POST['facteur'] ?? 0 );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock/article/' . (int) $id . '/modifier' );
	}

	public function uniteDelete( $id, $uniteId ) {
		FKC_VpUnite::supprimer( (int) $uniteId );
		redirect( $this->module . '/stock/article/' . (int) $id . '/modifier' );
	}

	public function articleUpdate( $id ) {
		list( $ok, $msg ) = FKC_VpStock::updateArticle( (int) $id, $_POST );
		if ( $ok ) { $msg = $this->enregistrerAttributs( (int) $id, $msg ); }
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock' );
	}

	/** Retire un article : suppression s'il n'a jamais servi, archivage sinon. */
	public function articleDelete( $id ) {
		list( $ok, $msg ) = FKC_VpStock::supprimer( (int) $id, ! empty( $_POST['archiver'] ) );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock' );
	}

	/** Réactive un article archivé. */
	public function articleRestore( $id ) {
		list( $ok, $msg ) = FKC_VpStock::restaurer( (int) $id );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock' );
	}

	/* ── Ventes ──────────────────────────────────────────────────────────── */

	public function sellForm() {
		FKC_View::render( 'vertical.stock_vente', array(
			'title' => 'Enregistrer une vente', 'module' => $this->module, 'cfg' => $this->cfg,
			'articles' => FKC_VpStock::articles(),
			'unitesParArticle' => $this->unitesParArticle(),
			// ELM-005 : ce qu'on peut PROPOSER avec chaque article. Rien n'est
			// ajouté au ticket : la suggestion s'affiche, le vendeur décide.
			'suggestionsParArticle' => $this->suggestionsParArticle(),
			'dossiers' => FKC_VpDossier::all( 'ouvert' ),
			// Clients du référentiel comptable (COM-002) : proposés uniquement
			// pour le mode « à crédit ». Comme pour les fournisseurs côté
			// entrée de stock, les proposer ici est ce qui rend la vente
			// à crédit possible — sans client identifié, pas de facture.
			'clients' => class_exists( 'FKC_Client' ) ? FKC_Client::all( true ) : array(),
			'depots' => $this->depotsProposes(),
			'flash' => $this->flash(),
		) );
	}

	public function sell() {
		$mode = ( 'credit' === ( $_POST['mode_reglement'] ?? 'comptant' ) ) ? 'credit' : 'comptant';
		$series = $_POST['series'] ?? null;
		$uniteId = ! empty( $_POST['unite_id'] ) ? (int) $_POST['unite_id'] : null;
		if ( 'credit' === $mode ) {
			list( $ok, $msg ) = FKC_VpStock::venteCredit(
				(int) ( $_POST['article_id'] ?? 0 ), (float) ( $_POST['qte'] ?? 0 ),
				(float) ( $_POST['pu'] ?? 0 ), $this->cfg,
				(int) ( $_POST['client_id'] ?? 0 ),
				! empty( $_POST['dossier_id'] ) ? (int) $_POST['dossier_id'] : null,
				trim( (string) ( $_POST['motif'] ?? '' ) ),
				! empty( $_POST['forcer_encours'] ),
				$series, $uniteId
			);
		} else {
			list( $ok, $msg ) = FKC_VpStock::vente(
				(int) ( $_POST['article_id'] ?? 0 ), (float) ( $_POST['qte'] ?? 0 ),
				(float) ( $_POST['pu'] ?? 0 ), $this->cfg,
				! empty( $_POST['dossier_id'] ) ? (int) $_POST['dossier_id'] : null,
				trim( (string) ( $_POST['motif'] ?? '' ) ),
				$series, $uniteId,
				! empty( $_POST['depot_id'] ) ? (int) $_POST['depot_id'] : null,
				// Moyen de règlement : il commande le compte de trésorerie.
				// Absent, la vente reste en espèces, comme avant.
				trim( (string) ( $_POST['moyen'] ?? '' ) )
			);
		}
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock/vendre' );
	}

	/* ── Entrées ─────────────────────────────────────────────────────────── */

	public function entryForm() {
		FKC_View::render( 'vertical.stock_entree', array(
			'title' => 'Réapprovisionner', 'module' => $this->module, 'cfg' => $this->cfg,
			'articles' => FKC_VpStock::articles(),
			'unitesParArticle' => $this->unitesParArticle(),
			// Fournisseurs du référentiel comptable : les proposer ici est ce
			// qui rend la dette attribuable, donc payable.
			'fournisseurs' => class_exists( 'FKC_Fournisseur' ) ? FKC_Fournisseur::all() : array(),
			'depots' => $this->depotsProposes(),
			'flash' => $this->flash(),
		) );
	}

	public function entry() {
		list( $ok, $msg ) = FKC_VpStock::entree(
			(int) ( $_POST['article_id'] ?? 0 ), (float) ( $_POST['qte'] ?? 0 ),
			(float) ( $_POST['pu'] ?? 0 ), $this->cfg, trim( (string) ( $_POST['motif'] ?? '' ) ),
			! empty( $_POST['fournisseur_id'] ) ? (int) $_POST['fournisseur_id'] : null,
			$_POST['series'] ?? null,
			! empty( $_POST['unite_id'] ) ? (int) $_POST['unite_id'] : null,
			// COM-060 : lot et péremption de cette réception. Le moteur ne
			// les exige que si l'article porte la capacité correspondante.
			array( 'lot' => $_POST['lot'] ?? '', 'peremption' => $_POST['peremption'] ?? '' ),
			! empty( $_POST['depot_id'] ) ? (int) $_POST['depot_id'] : null
		);
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock/entrer' );
	}

	/**
	 * COM-060 — Chute de découpe. Ce n'est ni une vente ni une correction
	 * d'inventaire : c'est de la marchandise perdue au moment de couper, et
	 * elle doit être imputable à un article et à un mois.
	 */
	public function chute() {
		list( $ok, $msg ) = FKC_VpLot::chute(
			(int) ( $_POST['article_id'] ?? 0 ), (float) ( $_POST['qte'] ?? 0 ),
			$this->cfg, (string) ( $_POST['motif'] ?? '' )
		);
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock/lots' );
	}

	/** COM-070 — Magasins et dépôts : répartition, transferts, écarts. */
	public function depots() {
		FKC_VpDepot::ensure();
		FKC_VpDepot::rattraper();
		FKC_View::render( 'vertical.depots', array(
			'title'  => 'Magasins & dépôts',
			'module' => $this->module,
			'cfg'    => $this->cfg,
			'depots'   => FKC_VpDepot::tous( false ),
			'articles' => FKC_VpStock::articles(),
			'valeurs'  => FKC_VpDepot::valeurParDepot(),
			// Un écart entre le stock global et la somme des dépôts ne devrait
			// jamais exister : s'il apparaît, mieux vaut le voir ici qu'à
			// l'inventaire annuel.
			'ecarts'   => FKC_VpDepot::ecarts(),
			'flash'    => $this->flash(),
		) );
	}

	public function depotStore() {
		list( $ok, $msg ) = FKC_VpDepot::creer( $_POST );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock/depots' );
	}

	public function transfert() {
		list( $ok, $msg ) = FKC_VpDepot::transferer(
			(int) ( $_POST['article_id'] ?? 0 ), (float) ( $_POST['qte'] ?? 0 ),
			(int) ( $_POST['source_id'] ?? 0 ), (int) ( $_POST['dest_id'] ?? 0 ),
			(string) ( $_POST['motif'] ?? '' )
		);
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/stock/depots' );
	}

	/** Écran des lots : ce qui périme bientôt, et ce qui est déjà périmé. */
	public function lots() {
		FKC_VpLot::ensure();
		FKC_View::render( 'vertical.lots', array(
			'title'  => 'Lots & péremption',
			'module' => $this->module,
			'cfg'    => $this->cfg,
			'perimes'   => FKC_VpLot::perimes(),
			'echeances' => FKC_VpLot::echeances( 60 ),
			'coutChutes' => FKC_VpLot::coutChutesMois(),
			// Articles déclarés « à découper » : eux seuls peuvent porter une chute.
			'articlesDecoupe' => array_values( array_filter( FKC_VpStock::articles(), function ( $a ) {
				return class_exists( 'FKC_VpCapacite' ) && FKC_VpCapacite::actif( $a, 'decoupe' );
			} ) ),
			'flash' => $this->flash(),
		) );
	}

	/** COM-023 : unités de vente multiples, groupées par article, pour les sélecteurs JS des écrans vente/entrée. */
	protected function unitesParArticle() {
		if ( ! class_exists( 'FKC_VpUnite' ) ) { return array(); }
		$out = array();
		foreach ( FKC_VpStock::articles() as $a ) {
			$u = FKC_VpUnite::pourArticle( $a['id'] );
			if ( $u ) { $out[ $a['id'] ] = $u; }
		}
		return $out;
	}

	public function movements() {
		FKC_View::render( 'vertical.stock_mouvements', array(
			'title' => 'Mouvements de stock', 'module' => $this->module, 'cfg' => $this->cfg,
			'rows'  => FKC_VpStock::mouvements( 200 ),
			'flash' => $this->flash(),
		) );
	}

	/* ── Retours (COM-017) ──────────────────────────────────────────────── */

	public function returnForm( $mouvementId ) {
		$mv = FKC_DB::q(
			'SELECT m.*, a.libelle AS article_libelle, a.unite, a.serialise FROM vp_mouvements m JOIN vp_articles a ON a.id=m.article_id WHERE m.id=? AND m.pack=? AND m.sens=?',
			array( (int) $mouvementId, FKC_Packs::activeCode(), 'sortie' )
		)->fetch();
		if ( ! $mv ) { redirect( $this->module . '/stock/mouvements' ); }
		FKC_View::render( 'vertical.stock_retour', array(
			'title' => 'Enregistrer un retour', 'module' => $this->module, 'cfg' => $this->cfg,
			'mv' => $mv, 'restant' => (float) $mv['qte'] - FKC_VpStock::qteRetournee( (int) $mv['id'] ),
			'seriesVendues' => ( ! empty( $mv['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) ? FKC_VpSerie::duMouvementSortie( (int) $mv['id'] ) : array(),
			'flash' => $this->flash(),
		) );
	}

	public function returnStore( $mouvementId ) {
		list( $ok, $msg ) = FKC_VpStock::retour(
			(int) $mouvementId, (float) ( $_POST['qte'] ?? 0 ), $this->cfg,
			trim( (string) ( $_POST['motif'] ?? '' ) ), $_POST['series'] ?? null
		);
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $ok ? $this->module . '/stock/mouvements' : $this->module . '/stock/mouvements/' . (int) $mouvementId . '/retour' );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
