<?php
/**
 * LOTS, PÉREMPTION ET DÉCOUPE (COM-060).
 *
 * ── POURQUOI UNE TABLE PROPRE, ET NON LE RACCORDEMENT ANNONCÉ ────────────
 *
 * L'audit précédent concluait qu'il n'y avait rien à écrire : le module
 * Inventaire tient déjà une table `inv_lots` avec ses alertes. En regardant
 * de près, ce raccordement était le mauvais choix, et je l'ai abandonné.
 *
 * `inv_lots` est rattachée à `inv_articles` et à un entrepôt, et ses
 * quantités sont maintenues par le flux de réception de l'Inventaire. Y faire
 * écrire aussi la brique verticale aurait donné DEUX flux entretenant les
 * mêmes quantités selon deux logiques : le jour où elles divergent — et elles
 * divergent toujours — plus personne ne saurait laquelle croit dire vrai.
 *
 * Le moteur a déjà résolu exactement ce problème pour les numéros de série :
 * COM-010 n'a pas réutilisé le registre de scan, il a créé `vp_series`. Cette
 * brique suit le même chemin, et se lit comme sa jumelle.
 *
 * ── LE LOT EST UNE QUANTITÉ, LA SÉRIE EST UNE UNITÉ ──────────────────────
 *
 * C'est toute la différence de traitement. Un numéro de série identifie UN
 * exemplaire : on le sort, il est vendu. Un lot porte une quantité qui se
 * consomme partiellement, sur plusieurs ventes, jusqu'à épuisement.
 *
 * ── FEFO, ET PAS FIFO ────────────────────────────────────────────────────
 *
 * On sort d'abord ce qui périme le plus tôt — *First Expired, First Out* —
 * et non ce qui est entré le plus tôt. Un lot reçu hier avec deux semaines de
 * durée de vie doit partir avant un lot reçu le mois dernier qui en a six.
 * Sortir en FIFO ferait périmer en rayon de la marchandise qu'on avait en
 * main, et c'est la perte la plus bête d'un commerce.
 *
 * ── LA DÉCOUPE ET LA CHUTE ───────────────────────────────────────────────
 *
 * Couper 3 m dans un rouleau de 10 en laisse 7 : la quantité décimale suffit.
 * Mais couper de la mousse, un tapis ou du tissu produit une CHUTE — la
 * bande inutilisable au bout du rouleau, le morceau qui ne fait plus une
 * taille vendable. Si elle n'est pas enregistrée, le stock théorique reste
 * supérieur au stock réel, l'écart grandit de quelques pourcents par mois, et
 * il n'apparaît qu'à l'inventaire annuel sans qu'on puisse dire d'où il
 * vient. La chute est donc une SORTIE tracée, avec son motif.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpLot {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_lots(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				lot TEXT NOT NULL,
				date_peremption TEXT,
				qte_initiale REAL NOT NULL DEFAULT 0,
				qte_restante REAL NOT NULL DEFAULT 0,
				mouvement_entree_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, article_id, lot)
			);
			CREATE INDEX IF NOT EXISTS idx_vplot_article ON vp_lots(article_id, qte_restante);
			CREATE INDEX IF NOT EXISTS idx_vplot_perem ON vp_lots(pack, date_peremption);
			CREATE TABLE IF NOT EXISTS vp_lot_mouvements(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				lot_id INTEGER NOT NULL,
				mouvement_id INTEGER,
				qte REAL NOT NULL,
				motif TEXT,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_vplotm_lot ON vp_lot_mouvements(lot_id);
		" );
		self::$ready = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/* ── Entrée ──────────────────────────────────────────────────────────── */

	/**
	 * Valide un lot avant réception.
	 *
	 * @return array{bool, string}
	 */
	public static function validerEntree( $articleId, $lot, $peremption, $qte, ?array $article = null ) {
		self::ensure();
		$article = $article ?: FKC_VpStock::article( $articleId );
		if ( ! $article ) { return array( false, 'Article introuvable.' ); }
		if ( ! self::suivi( $article ) ) { return array( true, '' ); }

		$lot = trim( (string) $lot );
		if ( '' === $lot ) {
			return array( false, '« ' . $article['libelle'] . ' » est suivi par lot : indiquez le numéro de lot de cette réception. Sans lui, la traçabilité s\'arrête à la porte du magasin.' );
		}
		$existe = FKC_DB::q( 'SELECT id FROM vp_lots WHERE pack=? AND article_id=? AND lot=?',
			array( self::pack(), (int) $articleId, $lot ) )->fetch();
		if ( $existe ) {
			return array( false, 'Le lot « ' . $lot . ' » a déjà été reçu pour cet article. Un même numéro de lot ne peut pas entrer deux fois : si c\'est un arrivage différent, il porte un autre numéro.' );
		}

		if ( self::peremptionSuivie( $article ) ) {
			$d = self::dateOuNull( $peremption );
			if ( ! $d ) {
				return array( false, '« ' . $article['libelle'] . ' » suit les dates de péremption : indiquez celle du lot « ' . $lot . ' ».' );
			}
			/*
			 * Réceptionner de la marchandise DÉJÀ périmée n'est pas une saisie
			 * anodine à corriger plus tard : elle entre en stock, ressort à la
			 * vente, et c'est le client qui découvre le problème. On refuse.
			 */
			if ( $d < date( 'Y-m-d' ) ) {
				return array( false, 'Le lot « ' . $lot . ' » est déjà périmé (' . self::jolie( $d ) . ') : il ne peut pas entrer en stock. Refusez la livraison ou passez-le en perte.' );
			}
		}
		return array( true, '' );
	}

	/** Enregistre le lot reçu, une fois le mouvement d'entrée créé. */
	public static function enregistrerEntree( $articleId, $lot, $peremption, $qte, $mouvementId ) {
		self::ensure();
		$lot = trim( (string) $lot );
		if ( '' === $lot ) { return null; }
		FKC_DB::q(
			'INSERT INTO vp_lots(pack,article_id,lot,date_peremption,qte_initiale,qte_restante,mouvement_entree_id) VALUES(?,?,?,?,?,?,?)',
			array( self::pack(), (int) $articleId, $lot, self::dateOuNull( $peremption ), (float) $qte, (float) $qte, $mouvementId ? (int) $mouvementId : null )
		);
		return (int) FKC_DB::conn()->lastInsertId();
	}

	/* ── Sortie : FEFO ───────────────────────────────────────────────────── */

	/**
	 * Peut-on sortir cette quantité, et de quels lots ?
	 *
	 * @return array{0:bool,1:string,2:array} ( ok, message, plan de prélèvement )
	 */
	public static function planSortie( $articleId, $qte, ?array $article = null ) {
		self::ensure();
		$article = $article ?: FKC_VpStock::article( $articleId );
		if ( ! $article || ! self::suivi( $article ) ) { return array( true, '', array() ); }

		$qte = (float) $qte;
		$dispos = self::disponibles( $articleId );

		/*
		 * Un lot périmé reste en base — il faut pouvoir le constater et le
		 * passer en perte — mais il ne se vend pas. Le message dit combien il
		 * en reste, parce que c'est une marchandise à sortir du rayon
		 * aujourd'hui, pas une information à consulter plus tard.
		 */
		$perimes = 0.0; $ouvrables = array();
		foreach ( $dispos as $l ) {
			if ( self::estPerime( $l ) ) { $perimes += (float) $l['qte_restante']; continue; }
			$ouvrables[] = $l;
		}

		$total = 0.0;
		foreach ( $ouvrables as $l ) { $total += (float) $l['qte_restante']; }
		if ( $qte > $total + 0.00001 ) {
			$msg = 'Lots insuffisants : ' . fkc_money( $total ) . ' ' . $article['unite'] . ' disponible(s) en lots non périmés.';
			if ( $perimes > 0 ) {
				$msg .= ' ' . fkc_money( $perimes ) . ' ' . $article['unite'] . ' sont périmés et ne peuvent pas être vendus — sortez-les du rayon et passez-les en perte.';
			}
			return array( false, $msg, array() );
		}

		// FEFO : le plus tôt périmé part le premier ; à égalité, le plus ancien.
		$plan = array(); $reste = $qte;
		foreach ( $ouvrables as $l ) {
			if ( $reste <= 0.00001 ) { break; }
			$pris = min( $reste, (float) $l['qte_restante'] );
			$plan[] = array( 'lot_id' => (int) $l['id'], 'lot' => (string) $l['lot'], 'qte' => $pris, 'peremption' => $l['date_peremption'] );
			$reste -= $pris;
		}
		return array( true, '', $plan );
	}

	/** Applique un plan de prélèvement — après que le mouvement a été créé. */
	public static function consommer( array $plan, $mouvementId, $motif = 'vente' ) {
		self::ensure();
		foreach ( $plan as $p ) {
			FKC_DB::q( 'UPDATE vp_lots SET qte_restante = qte_restante - ? WHERE id=?', array( (float) $p['qte'], (int) $p['lot_id'] ) );
			FKC_DB::q( 'INSERT INTO vp_lot_mouvements(lot_id,mouvement_id,qte,motif) VALUES(?,?,?,?)',
				array( (int) $p['lot_id'], $mouvementId ? (int) $mouvementId : null, -(float) $p['qte'], (string) $motif ) );
		}
	}

	/** Rend au lot ce qu'un retour lui restitue (mêmes lots, ordre inverse). */
	public static function restituer( $mouvementSortieId ) {
		self::ensure();
		try {
			$rows = FKC_DB::q( 'SELECT lot_id, qte FROM vp_lot_mouvements WHERE mouvement_id=? AND qte<0', array( (int) $mouvementSortieId ) )->fetchAll();
			foreach ( $rows as $r ) {
				FKC_DB::q( 'UPDATE vp_lots SET qte_restante = qte_restante + ? WHERE id=?', array( abs( (float) $r['qte'] ), (int) $r['lot_id'] ) );
				FKC_DB::q( 'INSERT INTO vp_lot_mouvements(lot_id,mouvement_id,qte,motif) VALUES(?,?,?,?)',
					array( (int) $r['lot_id'], (int) $mouvementSortieId, abs( (float) $r['qte'] ), 'retour' ) );
			}
		} catch ( \Throwable $e ) { fkc_log( 'VpLot::restituer ' . $e->getMessage(), 'ERROR' ); }
	}

	/* ── Lecture et alertes ──────────────────────────────────────────────── */

	/** Lots encore disponibles, dans l'ordre FEFO. */
	public static function disponibles( $articleId ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT * FROM vp_lots WHERE pack=? AND article_id=? AND qte_restante > 0.00001
			 ORDER BY date_peremption IS NULL, date_peremption, id",
			array( self::pack(), (int) $articleId )
		)->fetchAll();
	}

	public static function estPerime( array $lot, $date = null ) {
		if ( empty( $lot['date_peremption'] ) ) { return false; }
		return (string) $lot['date_peremption'] < ( $date ?: date( 'Y-m-d' ) );
	}

	/**
	 * Lots qui périment dans les N prochains jours — la liste à traiter
	 * pendant qu'ils sont encore vendables. Passé la date, il est trop tard :
	 * c'est une perte, pas une promotion.
	 */
	public static function echeances( $jours = 30 ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT l.*, a.libelle, a.unite FROM vp_lots l JOIN vp_articles a ON a.id=l.article_id
			 WHERE l.pack=? AND l.qte_restante > 0.00001 AND l.date_peremption IS NOT NULL
			   AND date(l.date_peremption) >= date('now','localtime')
			   AND date(l.date_peremption) <= date('now','localtime','+' || ? || ' days')
			 ORDER BY l.date_peremption",
			array( self::pack(), (int) $jours )
		)->fetchAll();
	}

	/** Lots déjà périmés encore en stock — à sortir du rayon aujourd'hui. */
	public static function perimes() {
		self::ensure();
		return FKC_DB::q(
			"SELECT l.*, a.libelle, a.unite FROM vp_lots l JOIN vp_articles a ON a.id=l.article_id
			 WHERE l.pack=? AND l.qte_restante > 0.00001 AND l.date_peremption IS NOT NULL
			   AND date(l.date_peremption) < date('now','localtime')
			 ORDER BY l.date_peremption",
			array( self::pack() )
		)->fetchAll();
	}

	public static function compteurs() {
		$out = array( 'perimes' => 0, 'perimes_qte' => 0.0, 'proches' => 0 );
		try {
			foreach ( self::perimes() as $l ) { $out['perimes']++; $out['perimes_qte'] += (float) $l['qte_restante']; }
			$out['proches'] = count( self::echeances( 30 ) );
		} catch ( \Throwable $e ) { /* tables absentes */ }
		return $out;
	}

	/* ── Capacités ───────────────────────────────────────────────────────── */

	public static function suivi( array $article ) {
		return class_exists( 'FKC_VpCapacite' ) && FKC_VpCapacite::actif( $article, 'lot' );
	}

	public static function peremptionSuivie( array $article ) {
		return class_exists( 'FKC_VpCapacite' ) && FKC_VpCapacite::actif( $article, 'peremption' );
	}

	/* ── Découpe ─────────────────────────────────────────────────────────── */

	/**
	 * Enregistre la CHUTE d'une découpe.
	 *
	 * Ce n'est pas une vente : c'est de la marchandise sortie du stock que
	 * personne n'achètera. Elle passe donc par une sortie tracée avec son
	 * motif, et non par une correction d'inventaire anonyme — pour qu'à la
	 * fin du mois on puisse dire combien la découpe a coûté, et sur quels
	 * articles.
	 *
	 * @return array{bool, string}
	 */
	public static function chute( $articleId, $qte, array $cfg, $motif = '' ) {
		self::ensure();
		$a = FKC_VpStock::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.' ); }
		if ( ! class_exists( 'FKC_VpCapacite' ) || ! FKC_VpCapacite::actif( $a, 'decoupe' ) ) {
			return array( false, '« ' . $a['libelle'] . ' » n\'est pas déclaré comme article à découper : activez la capacité « Découpe » sur sa fiche.' );
		}
		$qte = (float) $qte;
		if ( $qte <= 0 ) { return array( false, 'La quantité de chute doit être positive.' ); }
		if ( $qte > (float) $a['qte_stock'] + 0.00001 ) {
			return array( false, 'Chute supérieure au stock : ' . fkc_money( $a['qte_stock'] ) . ' ' . $a['unite'] . ' disponible(s).' );
		}

		$libelle = 'Chute de découpe' . ( $motif ? ' — ' . trim( (string) $motif ) : '' );
		list( $ok, $msg, $movId ) = FKC_VpStock::sortirStockSansEcriture( $articleId, $qte, $libelle );
		if ( ! $ok ) { return array( false, $msg ); }

		// La chute part des mêmes lots que la vente, en FEFO : une chute
		// prélevée sur un lot différent de celui qu'on a coupé fausserait la
		// traçabilité au premier rappel de lot.
		if ( self::suivi( $a ) ) {
			list( $okP, , $plan ) = self::planSortie( $articleId, $qte, $a );
			if ( $okP && $plan ) { self::consommer( $plan, $movId, 'chute' ); }
		}

		$cout = round( $qte * (float) $a['cump'], 2 );
		return array( true, 'Chute enregistrée : ' . fkc_money( $qte ) . ' ' . $a['unite']
			. ' sortis du stock, soit ' . fkc_money( $cout ) . ' F de coût de revient. Sans cet enregistrement, l\'écart n\'apparaîtrait qu\'à l\'inventaire.' );
	}

	/** Coût des chutes du mois — ce que la découpe coûte réellement. */
	public static function coutChutesMois( $ym = null ) {
		self::ensure();
		$m = $ym ?: date( 'Y-m' );
		try {
			return (float) FKC_DB::q(
				"SELECT COALESCE(SUM(mo.qte * a.cump),0) FROM vp_mouvements mo JOIN vp_articles a ON a.id=mo.article_id
				 WHERE mo.pack=? AND mo.sens='sortie' AND mo.motif LIKE 'Chute de découpe%' AND substr(mo.created_at,1,7)=?",
				array( self::pack(), $m )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/* ── Utilitaires ─────────────────────────────────────────────────────── */

	public static function dateOuNull( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return null; }
		foreach ( array( 'd/m/Y', 'd-m-Y', 'Y-m-d' ) as $fmt ) {
			$d = DateTime::createFromFormat( $fmt, $v );
			if ( $d && $d->format( $fmt ) === $v ) { return $d->format( 'Y-m-d' ); }
		}
		$d = date_create( $v );
		return $d ? $d->format( 'Y-m-d' ) : null;
	}

	public static function jolie( $v ) {
		$d = date_create( (string) $v );
		return $d ? $d->format( 'd/m/Y' ) : (string) $v;
	}
}
