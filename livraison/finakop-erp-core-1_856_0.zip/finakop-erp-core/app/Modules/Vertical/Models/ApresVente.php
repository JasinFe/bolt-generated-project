<?php
/**
 * APRÈS-VENTE (ELM-002) — garantie, SAV, livraison, installation.
 *
 * CE QUI REND CETTE BRIQUE NÉCESSAIRE
 *
 * Vendre un réfrigérateur ne s'arrête pas à l'encaissement. Il faut le
 * livrer, parfois l'installer, et le réparer pendant deux ans sans le
 * refacturer. Trois engagements qui courent APRÈS la vente et qu'aucune
 * écriture comptable ne porte : une facture soldée ne dit rien de la
 * garantie qui court encore.
 *
 * ── LA GARANTIE SUIT LA MACHINE, PAS LA FACTURE ──────────────────────────
 *
 * C'est la décision structurante. Quand l'article est sérialisé (COM-010),
 * chaque numéro de série reçoit SA garantie. Un client qui revient avec un
 * appareil et son numéro est reconnu immédiatement — même s'il a perdu sa
 * facture, même si la facture portait cinq appareils dont trois ont été
 * revendus. Une garantie rattachée à la seule facture obligerait à
 * retrouver un papier et à croire le client sur parole quant à l'appareil
 * concerné ; rattachée au numéro, elle ne se discute pas.
 *
 * Sans sérialisation, on retombe sur une garantie par ligne de vente : moins
 * précis, mais mieux que rien, et cela reste vrai pour un lot de cinq
 * ventilateurs.
 *
 * ── LA RÈGLE COMPTABLE QUE PRESQUE TOUS LES ERP LOCAUX RATENT ────────────
 *
 * Une pièce sortie du stock pour une réparation SOUS GARANTIE n'est PAS une
 * vente. Il n'y a ni produit, ni TVA collectée, ni créance : il y a une
 * charge, et rien en face. La constater comme une vente à prix nul créerait
 * un produit fantôme à zéro ; l'oublier laisserait le stock physique
 * diminuer sans que la comptabilité le sache.
 *
 * En inventaire permanent SYSCOHADA, la sortie s'écrit donc :
 *   D 603x Variation de stocks / C 31xx Stock
 * — exactement comme une sortie de vente, mais SANS la contrepartie de
 * produit. La charge reste, le produit n'existe pas, et la marge de
 * l'exercice dit enfin la vérité sur ce que coûte le service après-vente.
 *
 * Une réparation PAYANTE, elle, suit le chemin normal : les pièces se
 * vendent, la main-d'œuvre se facture.
 *
 * ── UNE SEULE TABLE D'INTERVENTIONS POUR CINQ MÉTIERS ────────────────────
 *
 * SAV sous garantie, réparation payante, livraison, installation, mise en
 * service : cinq types, un seul objet. Tous répondent aux mêmes questions —
 * qui, quel appareil, quand, par qui, à quel prix, où en est-on — et les
 * séparer en cinq tables aurait imposé cinq écrans pour un même geste :
 * ouvrir, planifier, clôturer.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpApresVente {

	protected static $ready = false;

	public static function ensure() {
		if ( self::$ready ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_garanties(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				article_libelle TEXT,
				mouvement_id INTEGER,
				numero_serie TEXT,
				client_id INTEGER,
				client_nom TEXT,
				type TEXT NOT NULL DEFAULT 'constructeur',
				date_debut TEXT NOT NULL,
				duree_mois INTEGER NOT NULL DEFAULT 12,
				date_fin TEXT NOT NULL,
				annulee INTEGER NOT NULL DEFAULT 0,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_vpgar_pack ON vp_garanties(pack, date_fin);
			CREATE INDEX IF NOT EXISTS idx_vpgar_serie ON vp_garanties(numero_serie);
			CREATE INDEX IF NOT EXISTS idx_vpgar_article ON vp_garanties(article_id);

			CREATE TABLE IF NOT EXISTS vp_interventions(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				numero TEXT NOT NULL,
				type TEXT NOT NULL DEFAULT 'sav',
				sous_garantie INTEGER NOT NULL DEFAULT 0,
				garantie_id INTEGER,
				article_id INTEGER,
				article_libelle TEXT,
				numero_serie TEXT,
				client_id INTEGER,
				client_nom TEXT,
				description TEXT,
				technicien TEXT,
				statut TEXT NOT NULL DEFAULT 'ouverte',
				date_ouverture TEXT NOT NULL,
				date_prevue TEXT,
				date_cloture TEXT,
				montant_ht REAL NOT NULL DEFAULT 0,
				cout_pieces REAL NOT NULL DEFAULT 0,
				facture_id INTEGER,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, numero)
			);
			CREATE INDEX IF NOT EXISTS idx_vpint_pack ON vp_interventions(pack, statut);
			CREATE INDEX IF NOT EXISTS idx_vpint_serie ON vp_interventions(numero_serie);
		" );
		self::$ready = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/* ── Vocabulaire ─────────────────────────────────────────────────────── */

	public static function typesGarantie() {
		return array(
			'constructeur' => 'Garantie constructeur',
			'magasin'      => 'Garantie magasin',
			'extension'    => 'Extension de garantie',
		);
	}

	/**
	 * `facturable` : ce type d'intervention donne-t-il lieu à facturation par
	 * défaut ? Une livraison offerte reste facturable à 0 — c'est le montant
	 * qui tranche, pas le type.
	 */
	public static function typesIntervention() {
		return array(
			'sav'          => array( 'label' => 'SAV / réparation',      'icone' => '🛠️', 'facturable' => true ),
			'livraison'    => array( 'label' => 'Livraison',             'icone' => '🚚', 'facturable' => true ),
			'installation' => array( 'label' => 'Installation',          'icone' => '🔧', 'facturable' => true ),
			'mise_service' => array( 'label' => 'Mise en service',       'icone' => '⚡', 'facturable' => true ),
			'diagnostic'   => array( 'label' => 'Diagnostic',            'icone' => '🔎', 'facturable' => true ),
		);
	}

	public static function statuts() {
		return array(
			'ouverte'   => 'Ouverte',
			'planifiee' => 'Planifiée',
			'en_cours'  => 'En cours',
			'cloturee'  => 'Clôturée',
			'annulee'   => 'Annulée',
		);
	}

	public static function labelType( $t ) {
		$d = self::typesIntervention();
		return isset( $d[ (string) $t ] ) ? $d[ (string) $t ]['label'] : (string) $t;
	}

	/* ── Garanties ───────────────────────────────────────────────────────── */

	/**
	 * Ouvre une garantie. Appelée automatiquement à la vente d'un article
	 * portant la capacité « garantie », ou à la main (extension vendue plus
	 * tard, garantie commerciale accordée après coup).
	 *
	 * @return array{bool, string, int|null}
	 */
	public static function ouvrirGarantie( array $d ) {
		self::ensure();
		$articleId = (int) ( $d['article_id'] ?? 0 );
		$a = class_exists( 'FKC_VpStock' ) ? FKC_VpStock::article( $articleId ) : null;
		if ( ! $a ) { return array( false, 'Article introuvable.', null ); }

		$duree = (int) ( $d['duree_mois'] ?? 12 );
		if ( $duree <= 0 ) { return array( false, 'La durée de garantie doit être d\'au moins un mois.', null ); }

		$type = (string) ( $d['type'] ?? 'constructeur' );
		if ( ! array_key_exists( $type, self::typesGarantie() ) ) { $type = 'constructeur'; }

		$debut = self::dateOuAujourdhui( $d['date_debut'] ?? '' );
		$fin   = date( 'Y-m-d', strtotime( $debut . ' +' . $duree . ' months' ) );
		$serie = trim( (string) ( $d['numero_serie'] ?? '' ) ) ?: null;

		/*
		 * Un numéro de série ne peut pas porter deux garanties actives du même
		 * type : l'appareil serait couvert deux fois et le SAV ne saurait pas
		 * laquelle invoquer. Une EXTENSION, en revanche, se superpose
		 * légitimement à une garantie constructeur — c'est tout son objet.
		 */
		if ( $serie ) {
			$exist = FKC_DB::q(
				"SELECT id FROM vp_garanties WHERE pack=? AND numero_serie=? AND type=? AND annulee=0 AND date_fin>=date('now','localtime')",
				array( self::pack(), $serie, $type )
			)->fetch();
			if ( $exist ) {
				return array( false, 'Le numéro ' . $serie . ' porte déjà une ' . fkc_lc( self::typesGarantie()[ $type ] ) . ' en cours.', null );
			}
		}

		FKC_DB::q(
			'INSERT INTO vp_garanties(pack,article_id,article_libelle,mouvement_id,numero_serie,client_id,client_nom,type,date_debut,duree_mois,date_fin)
			 VALUES(?,?,?,?,?,?,?,?,?,?,?)',
			array(
				self::pack(), $articleId, (string) $a['libelle'],
				! empty( $d['mouvement_id'] ) ? (int) $d['mouvement_id'] : null,
				$serie,
				! empty( $d['client_id'] ) ? (int) $d['client_id'] : null,
				trim( (string) ( $d['client_nom'] ?? '' ) ) ?: null,
				$type, $debut, $duree, $fin,
			)
		);
		return array( true, 'Garantie de ' . $duree . ' mois ouverte jusqu\'au ' . $fin . '.', (int) FKC_DB::conn()->lastInsertId() );
	}

	/**
	 * Ouverture AUTOMATIQUE à la vente — le geste que personne ne pense à
	 * faire au comptoir, et sans lequel la garantie n'existe que sur le
	 * ticket papier.
	 *
	 * Un appareil sérialisé reçoit une garantie PAR NUMÉRO ; sinon, une
	 * garantie couvre la ligne de vente.
	 *
	 * @return int Nombre de garanties ouvertes.
	 */
	public static function garantiesAutoVente( array $article, $mouvementId, $qte, array $cfg, $series = null, ?array $client = null ) {
		if ( ! class_exists( 'FKC_VpCapacite' ) || ! FKC_VpCapacite::actif( $article, 'garantie' ) ) { return 0; }
		self::ensure();

		$duree = (int) ( $cfg['stock']['garantie_mois'] ?? 12 );
		$base  = array(
			'article_id'   => (int) $article['id'],
			'mouvement_id' => $mouvementId ? (int) $mouvementId : null,
			'duree_mois'   => $duree,
			'type'         => 'constructeur',
			'client_id'    => $client['id'] ?? null,
			'client_nom'   => $client['nom'] ?? null,
		);

		$numeros = array();
		if ( ! empty( $article['serialise'] ) && class_exists( 'FKC_VpStock' ) ) {
			$numeros = FKC_VpStock::seriesEnTableau( $series );
		}

		$n = 0;
		if ( $numeros ) {
			foreach ( $numeros as $num ) {
				list( $ok ) = self::ouvrirGarantie( $base + array( 'numero_serie' => $num ) );
				if ( $ok ) { $n++; }
			}
		} else {
			list( $ok ) = self::ouvrirGarantie( $base );
			if ( $ok ) { $n++; }
		}
		return $n;
	}

	public static function garantie( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_garanties WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	/**
	 * La garantie couvrant CET appareil aujourd'hui, ou null.
	 * Le numéro de série prime : c'est lui qui identifie la machine.
	 */
	public static function couverture( $numeroSerie = null, $articleId = null, $date = null ) {
		self::ensure();
		$date = $date ?: date( 'Y-m-d' );
		if ( $numeroSerie ) {
			$r = FKC_DB::q(
				'SELECT * FROM vp_garanties WHERE pack=? AND numero_serie=? AND annulee=0 AND date_debut<=? AND date_fin>=? ORDER BY date_fin DESC LIMIT 1',
				array( self::pack(), trim( (string) $numeroSerie ), $date, $date )
			)->fetch();
			if ( $r ) { return $r; }
			// Un numéro connu mais hors garantie doit se dire ainsi, pas
			// retomber sur la garantie d'un autre exemplaire du même modèle.
			$connu = FKC_DB::q( 'SELECT 1 FROM vp_garanties WHERE pack=? AND numero_serie=?', array( self::pack(), trim( (string) $numeroSerie ) ) )->fetch();
			if ( $connu ) { return null; }
		}
		if ( $articleId ) {
			$r = FKC_DB::q(
				'SELECT * FROM vp_garanties WHERE pack=? AND article_id=? AND numero_serie IS NULL AND annulee=0 AND date_debut<=? AND date_fin>=? ORDER BY date_fin DESC LIMIT 1',
				array( self::pack(), (int) $articleId, $date, $date )
			)->fetch();
			if ( $r ) { return $r; }
		}
		return null;
	}

	public static function estCouvert( $numeroSerie = null, $articleId = null, $date = null ) {
		return (bool) self::couverture( $numeroSerie, $articleId, $date );
	}

	/** Garanties arrivant à échéance dans les N prochains jours (relance commerciale). */
	public static function echeances( $jours = 30 ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT * FROM vp_garanties WHERE pack=? AND annulee=0 AND date_fin>=date('now','localtime')
			 AND date_fin<=date('now','localtime','+' || ? || ' days') ORDER BY date_fin",
			array( self::pack(), (int) $jours )
		)->fetchAll();
	}

	public static function garantiesActives() {
		self::ensure();
		return (int) FKC_DB::q(
			"SELECT COUNT(*) FROM vp_garanties WHERE pack=? AND annulee=0 AND date_fin>=date('now','localtime')",
			array( self::pack() )
		)->fetchColumn();
	}

	/* ── Interventions ───────────────────────────────────────────────────── */

	/**
	 * Ouvre une intervention. Si l'appareil est sous garantie ET que
	 * l'intervention est un SAV, elle est marquée « sous garantie » — ce qui
	 * décide de tout le traitement comptable qui suivra.
	 *
	 * @return array{bool, string, int|null}
	 */
	public static function ouvrirIntervention( array $d ) {
		self::ensure();
		$type = (string) ( $d['type'] ?? 'sav' );
		if ( ! array_key_exists( $type, self::typesIntervention() ) ) {
			return array( false, 'Type d\'intervention inconnu.', null );
		}
		$articleId = ! empty( $d['article_id'] ) ? (int) $d['article_id'] : null;
		$a = $articleId && class_exists( 'FKC_VpStock' ) ? FKC_VpStock::article( $articleId ) : null;
		$serie = trim( (string) ( $d['numero_serie'] ?? '' ) ) ?: null;

		/*
		 * LA CAPACITÉ DE L'ARTICLE COMMANDE LE TYPE D'INTERVENTION.
		 *
		 * Ouvrir une installation sur une rallonge, ou un SAV sur un article
		 * qui n'en porte pas la capacité, n'est pas une erreur de saisie
		 * anodine : cela crée un engagement envers le client sur une
		 * prestation que le magasin n'a jamais prévu de rendre, et fausse le
		 * compteur d'interventions en cours qui sert au pilotage.
		 *
		 * Le contrôle ne s'applique QUE si un article est désigné : une
		 * intervention sans article (diagnostic au comptoir, dépannage sur un
		 * appareil qui n'est pas au catalogue) reste possible — le magasin
		 * intervient parfois sur ce qu'il n'a pas vendu.
		 */
		$capaciteRequise = array( 'sav' => 'sav', 'livraison' => 'livraison', 'installation' => 'installation', 'mise_service' => 'installation' );
		if ( $a && isset( $capaciteRequise[ $type ] ) && class_exists( 'FKC_VpCapacite' ) ) {
			$cap = $capaciteRequise[ $type ];
			if ( ! FKC_VpCapacite::actif( $a, $cap ) ) {
				return array( false, '« ' . $a['libelle'] . ' » ne porte pas la capacité « ' . FKC_VpCapacite::label( $cap )
					. ' » : activez-la sur sa fiche article, ou ouvrez l\'intervention sans désigner d\'article si vous dépannez un appareil hors catalogue.', null );
			}
		}

		$garantie = null;
		if ( 'sav' === $type ) {
			$garantie = self::couverture( $serie, $articleId );
		}

		$numero = self::prochainNumero();
		FKC_DB::q(
			'INSERT INTO vp_interventions(pack,numero,type,sous_garantie,garantie_id,article_id,article_libelle,numero_serie,client_id,client_nom,description,technicien,statut,date_ouverture,date_prevue,created_by)
			 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
			array(
				self::pack(), $numero, $type, $garantie ? 1 : 0, $garantie ? (int) $garantie['id'] : null,
				$articleId, $a ? (string) $a['libelle'] : ( trim( (string) ( $d['article_libelle'] ?? '' ) ) ?: null ),
				$serie,
				! empty( $d['client_id'] ) ? (int) $d['client_id'] : null,
				trim( (string) ( $d['client_nom'] ?? '' ) ) ?: null,
				trim( (string) ( $d['description'] ?? '' ) ) ?: null,
				trim( (string) ( $d['technicien'] ?? '' ) ) ?: null,
				'ouverte', date( 'Y-m-d' ),
				self::dateOuNull( $d['date_prevue'] ?? '' ),
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
			)
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		$msg = self::labelType( $type ) . ' ' . $numero . ' ouverte';
		if ( $garantie ) {
			$msg .= ' — appareil SOUS GARANTIE jusqu\'au ' . $garantie['date_fin'] . ', l\'intervention ne sera pas facturée.';
		} elseif ( 'sav' === $type && ( $serie || $articleId ) ) {
			$msg .= ' — appareil hors garantie, l\'intervention sera facturée.';
		} else {
			$msg .= '.';
		}
		return array( true, $msg, $id );
	}

	public static function intervention( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_interventions WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	public static function interventions( $statut = null ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( $statut ) { $w .= ' AND statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT * FROM vp_interventions {$w} ORDER BY id DESC", $p )->fetchAll();
	}

	/** @return array{bool, string} */
	public static function changerStatut( $id, $statut, $datePrevue = null, $technicien = null ) {
		self::ensure();
		$i = self::intervention( $id );
		if ( ! $i ) { return array( false, 'Intervention introuvable.' ); }
		if ( ! array_key_exists( (string) $statut, self::statuts() ) ) { return array( false, 'Statut inconnu.' ); }
		if ( 'cloturee' === (string) $i['statut'] ) {
			return array( false, 'Cette intervention est clôturée — sa comptabilisation est faite, on ne la rouvre pas.' );
		}
		if ( 'cloturee' === (string) $statut ) {
			return array( false, 'Une clôture passe par la fonction de clôture, qui décide de la facturation.' );
		}
		FKC_DB::q(
			'UPDATE vp_interventions SET statut=?, date_prevue=COALESCE(?,date_prevue), technicien=COALESCE(?,technicien) WHERE id=? AND pack=?',
			array( (string) $statut, self::dateOuNull( $datePrevue ?? '' ), $technicien ?: null, (int) $i['id'], self::pack() )
		);
		return array( true, $i['numero'] . ' — ' . self::statuts()[ $statut ] . '.' );
	}

	/**
	 * SORTIE D'UNE PIÈCE POUR UNE INTERVENTION — le cœur de la décision D7.
	 *
	 * Sous garantie : la pièce quitte le stock, sa valeur devient une CHARGE,
	 * et AUCUN produit n'est constaté. Facturée : la pièce se vend
	 * normalement, par le chemin de vente habituel.
	 *
	 * @return array{bool, string}
	 */
	public static function consommerPiece( $interventionId, $articleId, $qte, array $cfg, $puVente = null ) {
		self::ensure();
		$i = self::intervention( $interventionId );
		if ( ! $i ) { return array( false, 'Intervention introuvable.' ); }
		if ( in_array( (string) $i['statut'], array( 'cloturee', 'annulee' ), true ) ) {
			return array( false, 'Intervention ' . fkc_lc( self::statuts()[ $i['statut'] ] ) . ' : on n\'y ajoute plus de pièce.' );
		}
		$a = FKC_VpStock::article( $articleId );
		if ( ! $a ) { return array( false, 'Pièce introuvable.' ); }
		$qte = (float) $qte;
		if ( $qte <= 0 ) { return array( false, 'La quantité doit être positive.' ); }

		/*
		 * RÉPARATION PAYANTE — chemin normal. La pièce est vendue, avec sa
		 * TVA et son produit : rien de particulier, et surtout rien de
		 * dupliqué ici.
		 */
		if ( empty( $i['sous_garantie'] ) ) {
			$pu = null !== $puVente ? (float) $puVente : (float) $a['prix_vente'];
			list( $ok, $msg ) = FKC_VpStock::vente( $articleId, $qte, $pu, $cfg, 'Pièce — ' . $i['numero'] );
			if ( ! $ok ) { return array( false, $msg ); }
			FKC_DB::q( 'UPDATE vp_interventions SET montant_ht = montant_ht + ? WHERE id=?', array( round( $qte * $pu, 2 ), (int) $i['id'] ) );
			return array( true, 'Pièce facturée à l\'intervention. ' . $msg );
		}

		/*
		 * SOUS GARANTIE — la pièce sort du stock sans produit en face.
		 *
		 * On passe par sortirStockSansEcriture() : elle décrémente le stock et
		 * trace le mouvement, sans rien comptabiliser. C'est ici, et ici
		 * seulement, qu'on émet l'écriture de charge — D 603x / C 31xx — pour
		 * que la valeur sortie devienne un coût sans devenir un produit.
		 */
		$cout = round( $qte * (float) $a['cump'], 2 );
		list( $okS, $msgS, $movId ) = FKC_VpStock::sortirStockSansEcriture( $articleId, $qte, 'SAV sous garantie — ' . $i['numero'] );
		if ( ! $okS ) { return array( false, $msgS ); }

		$suffixe = '';
		$evt = (string) ( $cfg['stock']['evt_sav_garantie'] ?? '' );
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			$ctx = array(
				'montant' => $cout, 'montant_ht' => $cout, 'cout' => $cout, 'ht' => $cout,
				'article' => $a['libelle'], 'reference' => $a['reference'],
				'piece' => 'SAV-' . $i['numero'], 'date' => date( 'Y-m-d' ),
			);
			list( $okP, $msgP, $eid ) = FKC_Posting::emettre( $evt, $ctx );
			if ( $okP ) {
				if ( $movId ) { FKC_DB::q( 'UPDATE vp_mouvements SET ecriture_id=? WHERE id=?', array( $eid, (int) $movId ) ); }
			} else {
				$suffixe = ' ⚠ La comptabilisation a échoué (' . $msgP . ') — la pièce est bien sortie du stock, mais la charge n\'a pas été constatée.';
			}
		} elseif ( $cout > 0 ) {
			$suffixe = ' ⚠ Aucun schéma « SAV sous garantie » n\'est déclaré pour ce métier : la pièce est sortie du stock, mais sa valeur n\'a pas été passée en charge.';
		}

		FKC_DB::q( 'UPDATE vp_interventions SET cout_pieces = cout_pieces + ? WHERE id=?', array( $cout, (int) $i['id'] ) );
		return array( true, 'Pièce sortie sous garantie : ' . fkc_money( $cout ) . ' F de charge, aucun produit constaté (l\'appareil est couvert).' . $suffixe );
	}

	/**
	 * Clôture. Sous garantie : rien à facturer, le coût reste une charge.
	 * Hors garantie : la main-d'œuvre devient une facture client.
	 *
	 * @return array{bool, string, int|null} ( ok, message, facture_id )
	 */
	public static function cloturer( $id, array $cfg, $mainOeuvreHt = 0, $forcerEncours = false ) {
		self::ensure();
		$i = self::intervention( $id );
		if ( ! $i ) { return array( false, 'Intervention introuvable.', null ); }
		if ( 'cloturee' === (string) $i['statut'] ) { return array( false, 'Intervention déjà clôturée.', null ); }
		if ( 'annulee' === (string) $i['statut'] ) { return array( false, 'Intervention annulée : elle ne se clôture pas.', null ); }

		$mainOeuvreHt = max( 0, (float) $mainOeuvreHt );

		if ( ! empty( $i['sous_garantie'] ) ) {
			if ( $mainOeuvreHt > 0 ) {
				return array( false, 'Cette intervention est SOUS GARANTIE : la main-d\'œuvre ne peut pas être facturée au client. '
					. 'Si la panne n\'est en réalité pas couverte, retirez la garantie de l\'intervention avant de clôturer.', null );
			}
			FKC_DB::q( "UPDATE vp_interventions SET statut='cloturee', date_cloture=date('now','localtime') WHERE id=? AND pack=?", array( (int) $i['id'], self::pack() ) );
			return array( true, $i['numero'] . ' clôturée sous garantie — ' . fkc_money( $i['cout_pieces'] ) . ' F de pièces passés en charge, rien facturé au client.', null );
		}

		// Hors garantie : main-d'œuvre facturée si elle est chiffrée. Les
		// pièces ont déjà été vendues au fil de l'intervention (voir
		// consommerPiece) — les refacturer ici les compterait deux fois.
		if ( $mainOeuvreHt <= 0 ) {
			FKC_DB::q( "UPDATE vp_interventions SET statut='cloturee', date_cloture=date('now','localtime') WHERE id=? AND pack=?", array( (int) $i['id'], self::pack() ) );
			return array( true, $i['numero'] . ' clôturée sans main-d\'œuvre facturée.', null );
		}
		if ( empty( $i['client_id'] ) || ! class_exists( 'FKC_Client' ) || ! class_exists( 'FKC_Facture' ) ) {
			return array( false, 'Facturer la main-d\'œuvre demande un client identifié et le module Facturation.', null );
		}
		$client = FKC_Client::find( (int) $i['client_id'] );
		if ( ! $client ) { return array( false, 'Client introuvable.', null ); }

		$tva = class_exists( 'FKC_CategorieFiscale' )
			? FKC_CategorieFiscale::tauxNatureDossier( self::pack(), 'sav', (float) ( $cfg['stock']['tva'] ?? 0 ) )
			: (float) ( $cfg['stock']['tva'] ?? 0 );
		$ttc = round( $mainOeuvreHt * ( 1 + $tva / 100 ), 2 );

		$avisMsg = '';
		if ( class_exists( 'FKC_CreditManagement' ) ) {
			$avis = FKC_CreditManagement::avisCommande( (int) $client['id'], $ttc );
			if ( 'refus' === ( $avis['avis'] ?? '' ) && ! $forcerEncours ) {
				return array( false, 'Facturation refusée par le contrôle d\'encours — ' . ( $avis['message'] ?? '' ), null );
			}
			if ( in_array( $avis['avis'] ?? '', array( 'attention', 'refus' ), true ) ) {
				$avisMsg = ' ⚠ Contrôle d\'encours : ' . ( $avis['message'] ?? '' );
			}
		}

		try {
			return FKC_Tx::executer( function () use ( $i, $client, $mainOeuvreHt, $tva, $avisMsg ) {
				$delai = max( 0, (int) ( $client['delai_paiement'] ?? 0 ) );
				list( $ok, $msg, $fid ) = FKC_Facture::save(
					array(
						'client_id' => (int) $client['id'], 'client_nom' => $client['nom'],
						'date_facture' => date( 'Y-m-d' ), 'echeance' => date( 'Y-m-d', strtotime( '+' . $delai . ' days' ) ),
						'devise' => $client['devise'] ?? 'XOF', 'payment_method' => 'credit', 'template' => 'standard',
						'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
					),
					array( array(
						'designation' => self::labelType( $i['type'] ) . ' ' . $i['numero']
							. ( $i['article_libelle'] ? ' — ' . $i['article_libelle'] : '' ),
						'quantite' => 1, 'pu_ht' => $mainOeuvreHt,
						'tva_code' => FKC_VpStock::codeTvaFor( $tva ), 'unite' => 'forfait',
						'compte' => '706100',
					) )
				);
				if ( ! $ok ) { throw new \RuntimeException( $msg ); }
				list( $okC, $msgC, $eid ) = FKC_Facture::comptabiliser( $fid );
				if ( ! $okC ) { throw new \RuntimeException( 'Comptabilisation : ' . $msgC ); }
				if ( $eid ) { FKC_DB::q( "UPDATE factures SET statut='validee' WHERE id=? AND statut='brouillon'", array( $fid ) ); }

				FKC_DB::q(
					"UPDATE vp_interventions SET statut='cloturee', date_cloture=date('now','localtime'), montant_ht = montant_ht + ?, facture_id=? WHERE id=?",
					array( $mainOeuvreHt, $fid, (int) $i['id'] )
				);
				$f = FKC_Facture::find( $fid );
				return array( true, $i['numero'] . ' clôturée — facture ' . ( $f['numero'] ?? '' ) . ' de '
					. fkc_money( $f['montant_ttc'] ?? 0 ) . ' F TTC.' . $avisMsg, $fid );
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpApresVente::cloturer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Clôture annulée : ' . $e->getMessage(), null );
		}
	}

	public static function annuler( $id, $motif = '' ) {
		self::ensure();
		$i = self::intervention( $id );
		if ( ! $i ) { return array( false, 'Intervention introuvable.' ); }
		if ( 'cloturee' === (string) $i['statut'] ) {
			return array( false, 'Une intervention clôturée ne s\'annule pas : sa comptabilisation est faite. Passez par un avoir si la facture doit être reprise.' );
		}
		/*
		 * Une intervention n'est annulable que si RIEN n'en est sorti. Deux
		 * cas distincts, et il a fallu les traiter séparément :
		 *
		 *   - sous garantie, les pièces ont creusé le stock et constitué une
		 *     charge : annuler laisserait le stock diminué sans motif ;
		 *   - facturée, les pièces ont été VENDUES et comptabilisées :
		 *     annuler laisserait la vente debout, orpheline d'un dossier qui
		 *     n'existe plus. La reprise passe par un retour ou un avoir, qui
		 *     contre-passe vraiment l'écriture — pas par un statut qu'on
		 *     change dans un coin.
		 */
		if ( (float) $i['cout_pieces'] > 0 ) {
			return array( false, 'Des pièces ont déjà été sorties du stock sous garantie sur cette intervention (' . fkc_money( $i['cout_pieces'] )
				. ' F). Régularisez ces sorties avant d\'annuler, sinon le stock resterait creusé sans motif.' );
		}
		if ( (float) $i['montant_ht'] > 0 ) {
			return array( false, 'Des pièces ont déjà été VENDUES sur cette intervention (' . fkc_money( $i['montant_ht'] )
				. ' F HT) : ces ventes sont comptabilisées. Passez par un retour ou un avoir pour les reprendre — annuler l\'intervention les laisserait debout, sans dossier.' );
		}
		FKC_DB::q( "UPDATE vp_interventions SET statut='annulee', description = COALESCE(description,'') || ? WHERE id=? AND pack=?",
			array( $motif ? "\nAnnulée : " . $motif : "\nAnnulée.", (int) $i['id'], self::pack() ) );
		return array( true, $i['numero'] . ' annulée.' );
	}

	/* ── Indicateurs ─────────────────────────────────────────────────────── */

	public static function compteurs() {
		self::ensure();
		$out = array( 'ouvertes' => 0, 'sous_garantie' => 0, 'garanties_actives' => self::garantiesActives(), 'cout_sav_mois' => 0.0 );
		try {
			$out['ouvertes'] = (int) FKC_DB::q(
				"SELECT COUNT(*) FROM vp_interventions WHERE pack=? AND statut IN ('ouverte','planifiee','en_cours')", array( self::pack() ) )->fetchColumn();
			$out['sous_garantie'] = (int) FKC_DB::q(
				"SELECT COUNT(*) FROM vp_interventions WHERE pack=? AND sous_garantie=1 AND statut IN ('ouverte','planifiee','en_cours')", array( self::pack() ) )->fetchColumn();
			$out['cout_sav_mois'] = (float) FKC_DB::q(
				"SELECT COALESCE(SUM(cout_pieces),0) FROM vp_interventions WHERE pack=? AND sous_garantie=1 AND strftime('%Y-%m',date_ouverture)=strftime('%Y-%m','now','localtime')",
				array( self::pack() ) )->fetchColumn();
		} catch ( \Throwable $e ) { /* tables absentes : compteurs à zéro */ }
		return $out;
	}

	/* ── Utilitaires ─────────────────────────────────────────────────────── */

	protected static function prochainNumero() {
		$prefixe = 'INT-' . date( 'ym' ) . '-';
		$dernier = FKC_DB::q(
			'SELECT numero FROM vp_interventions WHERE pack=? AND numero LIKE ? ORDER BY numero DESC LIMIT 1',
			array( self::pack(), $prefixe . '%' )
		)->fetchColumn();
		$n = $dernier ? ( (int) substr( (string) $dernier, -4 ) ) + 1 : 1;
		return $prefixe . str_pad( (string) $n, 4, '0', STR_PAD_LEFT );
	}

	protected static function dateOuNull( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return null; }
		foreach ( array( 'd/m/Y', 'd-m-Y', 'Y-m-d' ) as $fmt ) {
			$d = DateTime::createFromFormat( $fmt, $v );
			if ( $d && $d->format( $fmt ) === $v ) { return $d->format( 'Y-m-d' ); }
		}
		$d = date_create( $v );
		return $d ? $d->format( 'Y-m-d' ) : null;
	}

	protected static function dateOuAujourdhui( $v ) {
		return self::dateOuNull( $v ) ?: date( 'Y-m-d' );
	}
}
