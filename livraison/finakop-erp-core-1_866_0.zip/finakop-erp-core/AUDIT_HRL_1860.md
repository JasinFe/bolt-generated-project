# Audit — Famille « Restauration, Hôtellerie & Loisirs » (1.860.0)

Base analysée : 1.859.0. Périmètre : les sept packs de la famille — Restaurant, Maquis, Fast-food, Bar, Boulangerie (sous-famille Restauration), Hôtel (Hôtellerie), Loisirs — et leur socle commun : « Hospitality Core » (`Core/Hospitality*.php` : folio, règlements, annulations/avoirs, réservations de ressources, commandes rapides), le moteur de caisse (`Core/Pos*.php`), la brique verticale (pièces, schémas d'écritures) et `FKC_StockCompta`.

Cette famille avait déjà été auditée en profondeur (série 1.520.x : moyens de paiement, écarts de caisse, remises, annulations, numérotation). Ce lot traite ce qui restait.

Test de non-régression : `tests/hrl_1860.php` — 26 vérifications sur 5 packs.

---

## 1. Socle commun — défauts corrigés

| # | Gravité | Défaut | Correction |
|---|---|---|---|
| C-1 | Majeur | **Créances hôtel et loisirs sans débiteur.** La réservation connaît le client (`client_id`, `facture_a_client_id` pour l'agence ou l'entreprise), mais la note du folio, les règlements, remboursements et avoirs débitaient ou créditaient 411 avec un simple nom. Au grand livre, la créance n'appartenait à personne : la balance âgée ne la voyait pas, l'écran Règlements ne pouvait pas la solder. Les pièces du moteur vertical des deux packs, elles, ignoraient le client pourtant attaché au dossier. Pour Loisirs, en plus, la créance tombait sur 411119 alors que l'écran Règlements crédite le compte du client (411100) : les deux soldes s'opposaient sans jamais se compenser. | `FKC_HospitalityPayment::ctxClient()` apporte le client et son compte au contexte de toutes ces écritures. Les 22 lignes 411 des schémas Hôtel et Loisirs imputent maintenant `{compte_client}` avec le tiers (repli : le compte collectif). |
| C-2 | Majeur | **Recettes toujours « en caisse ».** Les pièces de recette (repas, boissons, entrées, pain…) débitent la trésorerie via un rôle, mais la pièce ne disait jamais comment elle avait été payée. Une recette Wave, carte ou virement finissait dans le tiroir : le rapprochement était faux par construction. | Champ « Encaissé par » sur les pièces dont le schéma débite la trésorerie (colonne `vp_pieces.moyen`). Le compte est choisi selon le moyen de paiement (552100 pour Wave, etc.). |
| C-3 | Technique | **Tables créées pour une seule société.** 20 modèles de la famille (Hospitality, Pos*, packs) gardaient en mémoire, sous forme d'un simple drapeau, que leurs tables étaient prêtes. Après un changement de société en cours de session, la deuxième base n'avait pas ses tables → erreur « no such table ». | Ce drapeau est maintenant tenu société par société. |
| C-4 | Majeur | **Stock cuisine et bar sans entrée comptable.** La consommation des fiches techniques, les pertes et les écarts d'inventaire créditaient le stock (31), mais aucune réception n'y entrait. L'action « appro » de Restaurant, Maquis et Fast-food n'était appelée par **aucun écran**, et ne prenait qu'une quantité : le coût unitaire restait figé à sa valeur de création, donc le food cost aussi. Le bouton « Ajuster » du Bar modifiait la quantité sans rien écrire. | `FKC_StockCompta::comptabiliserReception()`. `FKC_RestoCuisine::approvisionner()` enregistre quantité et prix, recalcule le coût moyen pondéré et passe l'achat en comptabilité, avec un formulaire « 📦 Réception » dans l'écran Cuisine partagé par les trois packs. `FKC_BarCatalogue::ajusterComptabilise()` : une entrée est un achat, une sortie une perte. |

## 2. Spécificités par pack

- **Hôtel**
  - *H-1 — Commission des plateformes (OTA).* Le pourcentage saisi sur la réservation n'allait nulle part. La commission est désormais constatée **une fois**, au départ du client, sur l'hébergement : charge 632220, dette envers la plateforme (fournisseur créé au besoin). La marge du canal OTA devient enfin lisible.
  - *H-2 — Taxe de séjour.* Nouveau paramètre « par nuitée », dans l'écran Tarifs. Elle est ajoutée au départ, hors TVA, et portée en dette à reverser (442210), jamais en chiffre d'affaires.
  - *H-3 — Nombre de nuits.* Il se calcule maintenant en jours calendaires ; l'arrondi en secondes pouvait décaler d'une nuit.
  - Remboursements et avoirs sont portés au client débiteur : l'agence si elle est désignée, sinon le client.
- **Loisirs — L-1 : abonnements et cartes membres.** Ils se vendaient comme un simple ticket d'entrée : pas d'abonné, pas de date de fin, pas de contrôle à l'accueil. Et un abonnement annuel était compté en chiffre d'affaires du jour. Nouvel écran « 💳 Abonnés » :
  - chaque formule vendue au comptoir ouvre automatiquement la carte du membre ;
  - durée paramétrable par formule ;
  - contrôle d'accès par code, téléphone ou nom, avec refus d'une carte expirée, suspendue ou pas encore active ;
  - fréquentation suivie : passages du jour, abonnés inactifs, cartes qui expirent sous 30 jours ;
  - à la clôture, la part des abonnements restant à servir est calculée au prorata des jours. L'écart avec le dernier solde constaté est passé en produits constatés d'avance : débit 707802, crédit 477100 (écriture inverse quand cette part diminue).
- **Boulangerie — B-1**
  - Un lot dont la date limite (DLC) était dépassée restait vendable : l'ordre FIFO incluait les lots périmés. Il n'est plus vendable ; il reste en boutique, à déclarer en invendu.
  - Le stock sortait dès l'ajout d'un produit au ticket : un ticket abandonné faisait disparaître des pains jamais vendus. La quantité est maintenant réservée sur le ticket et sort à l'encaissement, avec un nouveau bouton « Annuler la vente ».
- **Restaurant — R-1.** On pouvait réserver une table sur un créneau déjà passé ; c'est refusé.
- **Maquis, Fast-food.** Ils utilisent le moteur Cuisine du Restaurant et profitent de C-4 : réception avec prix d'achat et food cost à jour.

## 3. Ponts avec les autres modules

- **Comptabilité / Règlements / Recouvrement :** créances nominatives (C-1), balance âgée et relances opérantes.
- **Trésorerie :** recettes ventilées par moyen de paiement (C-2).
- **Stock / Achats :** réceptions cuisine et bar en « factures non parvenues » (408), à rapprocher de la facture du fournisseur ; compte 31 = stock réel valorisé.
- **Fournisseurs :** plateformes OTA, dette réglable.
- **Fiscalité :** taxe de séjour distincte de la TVA, examen exonéré.
- **Clôture :** produits constatés d'avance sur abonnements.

## 4. Design

- Kit partagé `fk-*` dans `app.css` : grilles qui se replient sur tablette et mobile, bandeaux d'indicateurs, badges, zone de contrôle d'accès.
- 16 écrans de la famille passent de grilles en pixels fixes (« 1fr 340px », « 280px 1fr »…) au kit adaptatif.
- Nouveaux écrans : Abonnés, bloc Taxe de séjour, Réception d'ingrédients, Annulation de vente en boulangerie.

## 5. Recommandations (non faites dans ce lot)

1. **Livraison fast-food.** Comptabiliser la commission des applications de livraison (Glovo, Yango…) comme pour les OTA : la recette « livraison » est aujourd'hui brute.
2. **Hôtel.**
   - Taxe de séjour par personne et par nuit, avec exonérations (enfants, séjours professionnels selon la commune).
   - Night audit quotidien : facturation de la nuitée chaque nuit plutôt qu'au départ, pour que le chiffre d'affaires soit mensualisé pour les longs séjours.
3. **Réceptions.** Rattacher les réceptions cuisine et bar à un fournisseur nommé, et les rapprocher de sa facture (écran Achats) ; aujourd'hui elles restent en 408 sans tiers.
4. **Loisirs.**
   - Carte membre imprimable avec QR code (le module Scan existe).
   - Renouvellement en un clic.
   - Relance automatique des cartes qui expirent.
5. **Boulangerie.** Prévision de production par jour de la semaine à partir de l'historique des ventes et des invendus.
6. **Bar.** Rapprochement « vendu en caisse / consommé en dosage » par produit, pour mesurer le coulage.

## 6. Recommandations appliquées (1.861.0)

Les six recommandations du § 5 sont livrées en 1.861.0. Test : `tests/hrl_recommandations_1861.php` (31 vérifications).

| # | Recommandation | Ce qui change |
|---|---|---|
| R1 | Commission des plateformes de livraison | Un point de vente « livraison » peut désigner sa plateforme (Glovo, Yango…) et son taux de commission. La recette devient une créance sur la plateforme (411, client de type entreprise créé à la volée), nette de la commission passée en charge (632230). Sans plateforme, la recette reste encaissée en trésorerie. |
| R2 | Hôtel : audit de nuit et taxe de séjour | Nouveau bouton « Audit de nuit » (Réservations) : chaque nuit écoulée d'un séjour en cours est facturée au folio et comptabilisée (hébergement + taxe), une seule fois. Le check-out ne facture que les nuits restantes ; la commission OTA porte toujours sur le séjour entier. Taxe de séjour « par chambre et par nuit » ou « par personne et par nuit » (nombre de personnes à la réservation) ; case « exonéré » par séjour. |
| R3 | Réceptions rattachées au fournisseur | Réceptions cuisine (restaurant, maquis, fast-food) et entrées bar : choix du fournisseur. La facture à recevoir (408) porte le fournisseur en tiers et la réception entre au registre des achats (`achat_receptions`), prête à être rapprochée de la facture. |
| R4 | Loisirs : carte, renouvellement, relances | Carte membre imprimable avec QR code (le code de la carte, lisible par douchette au contrôle d'accès). Renouvellement en un clic : même formule, même prix, départ le lendemain de la fin (ou aujourd'hui si la carte est déjà expirée), une seule fois par carte. Liste « À relancer » des cartes qui expirent sous 7 jours avec message WhatsApp / SMS prêt et trace de la relance. |
| R5 | Boulangerie : prévision de fournée | Écran Boutique : pour le jour choisi (demain par défaut), moyenne des ventes encaissées les 4 mêmes jours de semaine ouverts, invendus moyens, stock encore vendable ce jour-là (DLC) et quantité à produire. |
| R6 | Bar : coulage | Journal des mouvements (`br_mouvements` : vente, perte, réception, inventaire). Écran Inventaire : par produit, vendu, pertes, manquant d'inventaire, taux de coulage (manquant / vendu) et valeur perdue. |

