<?php
/** Factures clients + lignes (calcul HT/TVA/TTC, numérotation, transaction). @package FinaKop_ERP_Core */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Facture {

	/** Codes de taxe FNE et taux associés (la plateforme FNE recalcule la TVA). */
	/**
	 * Codes de taxe proposés à la ligne de facture.
	 *
	 * LES TAUX SONT PARAMÉTRÉS, PLUS CODÉS EN DUR (1.557.0). L'écran
	 * « Fiscalité · Régime & paramètres » propose depuis toujours de saisir le
	 * taux normal et le taux réduit — et personne ne les lisait : 18 et 9
	 * étaient écrits ici, dans le code. Un exploitant qui corrigeait un taux
	 * après une loi de finances continuait à facturer à l'ancien, sans le
	 * moindre avertissement. C'est le défaut « réglage décoratif » déjà
	 * corrigé sur les capacités du commerce (1.520.140) et sur les
	 * interrupteurs de licence (1.520.156).
	 *
	 * Le repli reste 18 / 9 si la configuration est absente : aucune
	 * installation existante ne change de comportement.
	 */
	public static function taxes() {
		$n = 18.0; $r = 9.0;
		if ( class_exists( 'FKC_FiscalConfig' ) ) {
			try {
				$t = FKC_FiscalConfig::tauxTva();
				$n = (float) $t['normal']; $r = (float) $t['reduit'];
			} catch ( \Throwable $e ) { /* configuration illisible : repli */ }
		}
		$fmt = function ( $v ) { return rtrim( rtrim( number_format( (float) $v, 2, ',', '' ), '0' ), ',' ); };
		/*
		 * LES CODES SONT CEUX DE LA PLATEFORME FNE (1.753.0).
		 *
		 * La procédure d'interfaçage de la DGI ferme la liste des taxes
		 * acceptées : TVA (normal), TVAB (réduit), TVAC (exonération
		 * conventionnelle) et TVAD (exonération légale, régimes TEE et RME).
		 *
		 * Deux écarts vivaient ici :
		 *   — `TEX` n'existe PAS côté DGI, et partait pourtant tel quel dans
		 *     le corps de la certification. C'est le code que produisaient le
		 *     folio d'acompte, le socle prestations, la vente verticale et les
		 *     reçus dès que le taux était nul ;
		 *   — `TVAD`, le seul code juste pour un dossier à l'Entreprenant ou à
		 *     la Microentreprise, n'était utilisé nulle part — un tel dossier
		 *     retombait sur le repli `TVA`, soit 18 % chez qui n'a pas le
		 *     droit de collecter la TVA.
		 *
		 * `TEX` reste LU (lignes et articles enregistrés avant cette version)
		 * et se traduit à l'envoi ; il n'est plus proposé à la saisie.
		 */
		return array(
			'TVA'  => array( 'label' => 'TVA ' . $fmt( $n ) . ' % (taux normal)', 'taux' => $n, 'fne' => 'TVA' ),
			'TVAB' => array( 'label' => 'TVA ' . $fmt( $r ) . ' % (taux réduit)',  'taux' => $r, 'fne' => 'TVAB' ),
			'TVAC' => array( 'label' => 'Exonération conventionnelle — 0 %', 'taux' => 0, 'fne' => 'TVAC' ),
			'TVAD' => array( 'label' => 'Exonération légale (TEE / RME) — 0 %', 'taux' => 0, 'fne' => 'TVAD' ),
			'TEX'  => array( 'label' => 'Exonéré (TEX — code hérité)', 'taux' => 0, 'fne' => null, 'heritee' => true ),
		);
	}

	/** Codes réellement proposés à la saisie (sans les codes hérités). */
	public static function taxesSaisissables() {
		$out = array();
		foreach ( self::taxes() as $code => $t ) {
			if ( empty( $t['heritee'] ) ) { $out[ $code ] = $t; }
		}
		return $out;
	}

	/**
	 * Code d'exonération applicable au dossier.
	 *
	 * Sous l'Entreprenant ou la Microentreprise, l'exonération est LÉGALE —
	 * c'est le régime lui-même qui interdit de collecter : TVAD. Ailleurs,
	 * une ligne à taux nul relève d'une exonération conventionnelle : TVAC.
	 */
	public static function codeExonere() {
		if ( class_exists( 'FKC_FiscalConfig' ) ) {
			try {
				if ( FKC_FiscalConfig::regimeForfaitaire() ) { return 'TVAD'; }
			} catch ( \Throwable $e ) { /* repli conventionnel */ }
		}
		return 'TVAC';
	}

	/**
	 * Code retenu quand rien n'est précisé.
	 *
	 * Le repli était `TVA` — 18 % — pour tout le monde, y compris pour les
	 * régimes qui n'ont pas le droit de facturer la TVA.
	 */
	public static function codeDefaut() {
		$assujetti = ! class_exists( 'FKC_FiscalConfig' ) || FKC_FiscalConfig::assujettiTva();
		if ( ! $assujetti ) { return self::codeExonere(); }
		$d = class_exists( 'FKC_License' ) ? (string) FKC_License::param( 'fne_tva_default', 'TVA' ) : 'TVA';
		return isset( self::taxes()[ $d ] ) ? $d : 'TVA';
	}

	/** Code valide, ou le code par défaut du dossier. */
	public static function codeTaxeValide( $code ) {
		$code = strtoupper( trim( (string) $code ) );
		return isset( self::taxes()[ $code ] ) ? $code : self::codeDefaut();
	}

	public static function tauxFor( $code ) {
		$t = self::taxes();
		if ( isset( $t[ $code ] ) ) { return (float) $t[ $code ]['taux']; }
		$d = self::codeDefaut();
		return (float) ( $t[ $d ]['taux'] ?? $t['TVA']['taux'] );
	}

	public static function paymentMethods() {
		return array(
			'cash'         => 'Espèces',
			'card'         => 'Carte bancaire',
			'mobile-money' => 'Mobile Money',
			'bank-transfer'=> 'Virement',
			'check'        => 'Chèque',
			'credit'       => 'Crédit (à terme)',
		);
	}

	public static function all( $limit = 200 ) {
		$limit = (int) $limit;
		return FKC_DB::q( "SELECT * FROM factures ORDER BY date_facture DESC, id DESC LIMIT {$limit}" )->fetchAll();
	}

	/** Recherche filtrée des factures. $f: q, client_id, fne, type, from, to. */
	public static function search( $f = array(), $limit = 300 ) {
		$w = array(); $p = array();
		if ( ! empty( $f['q'] ) )        { $w[] = '(numero LIKE ? OR client_nom LIKE ?)'; $p[] = '%' . $f['q'] . '%'; $p[] = '%' . $f['q'] . '%'; }
		if ( ! empty( $f['client_id'] ) ) { $w[] = 'client_id=?'; $p[] = (int) $f['client_id']; }
		if ( ! empty( $f['fne'] ) )       { $w[] = 'fne_status=?'; $p[] = $f['fne']; }
		if ( ! empty( $f['type'] ) )      { $w[] = 'type=?'; $p[] = $f['type']; }
		if ( ! empty( $f['from'] ) )      { $w[] = 'date_facture>=?'; $p[] = $f['from']; }
		if ( ! empty( $f['to'] ) )        { $w[] = 'date_facture<=?'; $p[] = $f['to']; }
		$sql = 'SELECT * FROM factures';
		if ( $w ) { $sql .= ' WHERE ' . implode( ' AND ', $w ); }
		$sql .= ' ORDER BY date_facture DESC, id DESC LIMIT ' . (int) $limit;
		return FKC_DB::q( $sql, $p )->fetchAll();
	}

	public static function find( $id ) {
		$f = FKC_DB::q( 'SELECT * FROM factures WHERE id=?', array( (int) $id ) )->fetch();
		if ( ! $f ) { return null; }
		$f['lignes'] = FKC_DB::q( 'SELECT * FROM facture_lignes WHERE facture_id=? ORDER BY ordre ASC, id ASC', array( (int) $id ) )->fetchAll();
		return $f;
	}

	/**
	 * CETTE FACTURE TIENT-ELLE ENCORE ? (1.693.0)
	 *
	 * ────────────────────────────────────────────────────────────────────
	 * POURQUOI CETTE QUESTION VIT ICI, ET PAS DANS CHAQUE MOTEUR
	 *
	 * La réponse est un fait sur la FACTURE. Elle a d'abord été écrite
	 * dans FKC_ServiceOrder (1.691.0), parce que c'est là que le KPI
	 * faux avait été trouvé — le chiffre d'affaires du Studio comptait
	 * indéfiniment une facture annulée par avoir FNE.
	 *
	 * Mais FinaKop porte DEUX moteurs de vente de prestations : celui des
	 * commandes (ServiceOrder, pack Studio) et celui des missions
	 * (FKC_Mission, neuf packs — agences, cabinets, créateurs, structures
	 * culturelles). Le second portait exactement le même défaut, et
	 * l'aurait gardé tant que la réponse serait restée la propriété du
	 * premier. Une vérité sur une facture qui n'existe que dans un moteur
	 * est une vérité que l'autre moteur ignorera.
	 *
	 * ────────────────────────────────────────────────────────────────────
	 * DEUX MORTS DIFFÉRENTES, DEUX CONTRÔLES
	 *
	 * L'avoir FNE écrit `statut='annulee'` sur la facture d'origine ;
	 * l'avoir ordinaire (createAvoir) crée une pièce séparée pointant
	 * `avoir_origine_id` et laisse l'origine intacte, ses montants se
	 * nettant par agrégation. Ne tester que l'un laisse passer l'autre.
	 *
	 * Et une pièce de type « avoir » n'est jamais une créance : elle
	 * diminue, elle ne facture pas.
	 */
	public static function estVivante( $factureId ) {
		if ( empty( $factureId ) ) { return false; }
		try {
			$f = FKC_DB::q( "SELECT id, COALESCE(type,'facture') type, COALESCE(statut,'') statut FROM factures WHERE id=?",
				array( (int) $factureId ) )->fetch();
		} catch ( \Throwable $e ) { return false; }
		if ( ! $f ) { return false; }
		if ( 'avoir' === $f['type'] || 'annulee' === $f['statut'] ) { return false; }
		try {
			$av = (int) FKC_DB::q(
				"SELECT COUNT(*) FROM factures WHERE avoir_origine_id=? AND COALESCE(statut,'')<>'annulee'",
				array( (int) $factureId )
			)->fetchColumn();
		} catch ( \Throwable $e ) { $av = 0; }
		return 0 === $av;
	}

	/** Génère un numéro FAC-YYYY-NNNN séquentiel. */
	public static function nextNumero( $date = null ) {
		/*
		 * Le rang vient du PLUS GRAND numéro attribué, non du nombre de pièces
		 * existantes (1.616.0). Compter suppose que rien ne disparaît jamais :
		 * après une purge, le compte retombe et la pièce suivante réutilise un
		 * numéro déjà vivant. Deux pièces, un seul numéro, et aucune contrainte
		 * de base pour s'y opposer.
		 */
		/*
		 * L'ANNÉE VIENT DE LA DATE DE LA PIÈCE (1.726.0), pas de l'horloge.
		 * Une facture datée du 31/12 saisie le 3 janvier appartient à
		 * l'exercice précédent : son numéro doit le dire.
		 */
		return FKC_Numerotation::suivant( 'FAC', 'factures', "type IS NULL OR type<>'avoir'",
			FKC_Numerotation::anneeDe( $date ) );
	}

	/**
	 * LE NUMÉRO EST-IL DANS LE MILLÉSIME DE SA DATE ? (1.728.0)
	 *
	 * Ne vaut que pour les numéros de NOTRE série : un numéro repris d'un
	 * ancien logiciel n'a aucune raison d'en suivre la forme, et il ne doit pas
	 * être signalé comme fautif.
	 */
	public static function millesimeIncoherent( $f ) {
		$num = (string) ( $f['numero'] ?? '' );
		$prefixe = ( 'avoir' === (string) ( $f['type'] ?? '' ) ) ? 'AV' : 'FAC';
		if ( ! preg_match( '/^' . $prefixe . '-(\d{4})-\d+$/', $num, $m ) ) { return false; }
		return (int) $m[1] !== (int) FKC_Numerotation::anneeDe( (string) $f['date_facture'] );
	}

	/**
	 * RÉATTRIBUE LE NUMÉRO D'UNE FACTURE MAL MILLÉSIMÉE (1.728.0).
	 *
	 * Un numéro attribué ne change pas — c'est la règle, et elle est bonne.
	 * L'exception est étroite et se justifie : une facture encore en brouillon,
	 * jamais comptabilisée, jamais certifiée, jamais réglée et jamais remise
	 * n'a pas encore de numéro au sens où le contrôle l'entend. Le corriger
	 * vaut mieux que de laisser une pièce de 2025 vivre dans la série 2026, ce
	 * qui creuse un trou dans l'une et une avance dans l'autre.
	 *
	 * Dès qu'une de ces conditions tombe, on REFUSE : le document est sorti,
	 * et un document sorti ne se renumérote pas.
	 *
	 * @return array{bool,string}
	 */
	public static function renumeroter( $id ) {
		$f = self::find( $id );
		if ( ! $f ) { return array( false, 'Facture introuvable.' ); }
		if ( ! empty( $f['ecriture_id'] ) ) {
			return array( false, 'Facture déjà comptabilisée : son numéro est celui de l\'écriture, il ne change plus.' );
		}
		if ( 'NON_CERTIFIE' !== (string) ( $f['fne_status'] ?? 'NON_CERTIFIE' ) ) {
			return array( false, 'Facture certifiée FNE : la plateforme connaît ce numéro, il ne peut plus changer.' );
		}
		if ( 'brouillon' !== (string) $f['statut'] ) {
			return array( false, 'Seule une facture en brouillon peut être renumérotée (statut actuel : ' . $f['statut'] . ').' );
		}
		try {
			$nb = (int) FKC_DB::q( 'SELECT COUNT(*) FROM reglements WHERE facture_id=?', array( (int) $id ) )->fetchColumn();
			if ( $nb > 0 ) { return array( false, 'Des règlements sont rattachés à cette facture.' ); }
		} catch ( \Throwable $e ) { /* table absente : rien à vérifier */ }

		$ancien = (string) $f['numero'];
		$nouveau = ( 'avoir' === (string) ( $f['type'] ?? '' ) )
			? self::nextNumeroAvoir( $f['date_facture'] )
			: self::nextNumero( $f['date_facture'] );
		if ( $nouveau === $ancien ) { return array( false, 'Le numéro est déjà celui de l\'exercice de la facture.' ); }

		try {
			FKC_DB::q( 'UPDATE factures SET numero=? WHERE id=?', array( $nouveau, (int) $id ) );
		} catch ( \Throwable $e ) {
			return array( false, 'Renumérotation impossible : ' . $e->getMessage() );
		}
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'facture_renumerotee', $ancien . ' → ' . $nouveau );
		}
		return array( true, 'Facture renumérotée : ' . $ancien . ' → ' . $nouveau
			. '. L\'ancien numéro laisse un trou dans sa série, ce qui s\'explique et se justifie.' );
	}

	/**
	 * Crée une facture + ses lignes (transaction). Calcule HT/TVA/TTC.
	 * @return array{bool, string, int|null} ( bool, string, int|null )
	 */
	public static function save( $entete, $lignes ) {
		$clean = array();
		foreach ( $lignes as $l ) {
			$des = trim( (string) ( $l['designation'] ?? '' ) );
			$qte = (float) ( $l['quantite'] ?? 0 );
			$pu  = (float) ( $l['pu_ht'] ?? 0 );
			if ( '' === $des && $qte <= 0 && $pu <= 0 ) { continue; }
			if ( '' === $des ) { return array( false, 'Chaque ligne doit avoir une désignation.', null ); }
			if ( $qte <= 0 || $pu < 0 ) { return array( false, 'Quantité/prix invalides sur une ligne.', null ); }
			$code = self::codeTaxeValide( $l['tva_code'] ?? '' );
			$clean[] = array(
				'designation' => $des, 'quantite' => $qte, 'pu_ht' => $pu,
				'tva_code' => $code, 'tva_taux' => self::tauxFor( $code ),
				'montant_ht' => round( $qte * $pu, 2 ),
				'unite' => trim( (string) ( $l['unite'] ?? 'pièce' ) ) ?: 'pièce',
				'compte' => trim( (string) ( $l['compte'] ?? '' ) ) ?: null,
				'item_id' => ! empty( $l['item_id'] ) ? (int) $l['item_id'] : null,
			);
		}
		if ( ! $clean ) { return array( false, 'Ajoutez au moins une ligne.', null ); }

		$ht = 0; $tva = 0;
		foreach ( $clean as $l ) { $ht += $l['montant_ht']; $tva += round( $l['montant_ht'] * $l['tva_taux'] / 100, 2 ); }
		$ttc = round( $ht + $tva, 2 );

		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $entete, $clean, $ht, $tva, $ttc ) {
			/*
			 * `?:` LIT LA CLÉ AVANT DE TESTER, `??` NON (correctif 1.622.0).
			 *
			 * Ces trois clés sont facultatives : un appelant qui construit son
			 * en-tête à la main — FKC_VpCommande::facturer() au premier chef —
			 * ne les fournit pas. Chaque facture B2B émettait donc trois
			 * E_WARNING « Undefined array key ». Invisible en production, où
			 * l'affichage des erreurs est coupé ; parfaitement visible dans un
			 * journal d'erreurs, où le bruit finit par masquer le signal.
			 */
			$numero = ( $entete['numero'] ?? '' ) ?: self::nextNumero( $entete['date_facture'] ?? null );
			$stmt = $db->prepare(
				'INSERT INTO factures(numero,client_id,client_nom,date_facture,echeance,devise,payment_method,template,commercial_message,footer,montant_ht,montant_tva,montant_ttc,statut,created_by,division_id,axe_id,valeur_id)
				 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
			);
			$stmt->execute( array(
				/*
				 * LE MÊME DÉFAUT QU'EN 1.622.0, SUR CINQ CLÉS DE PLUS (1.726.0).
				 * Trois avaient été corrigées alors ; `client_id`, `echeance`,
				 * `devise`, `payment_method` et `template` étaient restées en
				 * accès direct. Tout appelant qui ne les fournit pas — un
				 * import, un pack, un adaptateur de terminal — émettait donc
				 * cinq E_WARNING par facture. Invisible en production, où
				 * l'affichage des erreurs est coupé ; parfaitement visible
				 * dans un journal d'erreurs, où le bruit masque le signal.
				 */
				$numero, ( $entete['client_id'] ?? null ) ?: null, $entete['client_nom'] ?? '',
				$entete['date_facture'], ( $entete['echeance'] ?? '' ) ?: null,
				( $entete['devise'] ?? '' ) ?: 'XOF',
				/* `payment_method` et `template` sont NOT NULL en base : y passer
				   null faisait échouer l'insertion avec le message générique
				   « Erreur lors de l'enregistrement », sans dire laquelle des
				   dix-huit colonnes était en cause. On reprend les défauts que
				   le schéma déclare lui-même. */
				( $entete['payment_method'] ?? '' ) ?: 'cash',
				( $entete['template'] ?? '' ) ?: 'B2C',
				( $entete['commercial_message'] ?? '' ) ?: null, ( $entete['footer'] ?? '' ) ?: null,
				$ht, $tva, $ttc, 'brouillon', $entete['created_by'] ?? null,
				! empty( $entete['division_id'] ) ? (int) $entete['division_id'] : null,
				! empty( $entete['axe_id'] ) ? (int) $entete['axe_id'] : null,
				! empty( $entete['valeur_id'] ) ? (int) $entete['valeur_id'] : null,
			) );
			$fid = (int) $db->lastInsertId();
			$il = $db->prepare( 'INSERT INTO facture_lignes(facture_id,designation,quantite,pu_ht,tva_code,tva_taux,montant_ht,unite,compte,item_id,ordre) VALUES(?,?,?,?,?,?,?,?,?,?,?)' );
			$i = 0;
			foreach ( $clean as $l ) {
				$il->execute( array( $fid, $l['designation'], $l['quantite'], $l['pu_ht'], $l['tva_code'], $l['tva_taux'], $l['montant_ht'], $l['unite'], $l['compte'], $l['item_id'], $i++ ) );
			}
			return array( true, "Facture {$numero} créée.", $fid );
			} );
		} catch ( Throwable $e ) {
			fkc_log( 'Facture::save ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de l\'enregistrement de la facture.', null );
		}
	}

	/** Prochain numéro d'avoir : AV-YYYY-NNNN. */
	public static function nextNumeroAvoir( $date = null ) {
		/*
		 * Le rang vient du PLUS GRAND numéro attribué, non du nombre de pièces
		 * existantes (1.616.0). Compter suppose que rien ne disparaît jamais :
		 * après une purge, le compte retombe et la pièce suivante réutilise un
		 * numéro déjà vivant. Deux pièces, un seul numéro, et aucune contrainte
		 * de base pour s'y opposer.
		 */
		/*
		 * L'ANNÉE VIENT DE LA DATE DE LA PIÈCE (1.726.0), pas de l'horloge.
		 * Une facture datée du 31/12 saisie le 3 janvier appartient à
		 * l'exercice précédent : son numéro doit le dire.
		 */
		return FKC_Numerotation::suivant( 'AV', 'factures', "type='avoir'",
			FKC_Numerotation::anneeDe( $date ) );
	}

	/**
	 * Crée une facture d'avoir (note de crédit) annulant entièrement une facture d'origine.
	 * Les montants sont stockés en NÉGATIF afin que toutes les agrégations (recouvrement,
	 * chiffre d'affaires, analyse) se nettent automatiquement.
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null id )
	 */
	public static function createAvoir( $origineId ) {
		$o = self::find( $origineId );
		if ( ! $o ) { return array( false, 'Facture d\'origine introuvable.', null ); }
		if ( 'avoir' === ( $o['type'] ?? 'facture' ) ) { return array( false, 'Impossible de créer un avoir sur un avoir.', null ); }
		/*
		 * UN AVOIR ANNULE UNE VENTE COMPTABILISÉE — PAS UN BROUILLON (1.850.0).
		 *
		 * L'avoir se comptabilise aussitôt (D 70 / C 411). Émis sur une facture
		 * jamais comptabilisée, il inscrivait un chiffre d'affaires NÉGATIF sans
		 * aucune vente en face — constaté : CA à −2 000 F après l'avoir d'une
		 * facture brouillon de 2 000 F — et laissait la facture elle-même
		 * modifiable, puis comptabilisable. Une facture non comptabilisée se
		 * modifie (elle garde son numéro) ou s'annule ; seule une facture
		 * passée au journal, ou certifiée FNE, appelle un avoir.
		 */
		if ( empty( $o['ecriture_id'] ) && 'CERTIFIE' !== (string) ( $o['fne_status'] ?? '' ) && empty( $o['specimen'] ) ) {
			if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'factures', (int) $origineId ) ) {
				return array( false, 'L\'écriture de cette facture attend encore au brouillard : rien n\'est comptabilisé, un avoir n\'a pas lieu d\'être. '
					. 'Modifiez la facture (l\'écriture en attente sera retirée, le numéro conservé), ou validez d\'abord le brouillard.', null );
			}
			return array( false, 'Cette facture n\'est pas comptabilisée : un avoir inscrirait un chiffre d\'affaires négatif sans vente en face. '
				. 'Modifiez-la (elle garde son numéro) ou annulez-la.', null );
		}
		$exist = FKC_DB::q( "SELECT id,numero FROM factures WHERE avoir_origine_id=? LIMIT 1", array( (int) $origineId ) )->fetch();
		if ( $exist ) { return array( false, 'Un avoir existe déjà pour cette facture (' . $exist['numero'] . ').', (int) $exist['id'] ); }
		if ( empty( $o['lignes'] ) ) { return array( false, 'La facture d\'origine n\'a aucune ligne.', null ); }

		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $o, $origineId ) {
			/* L'avoir est daté du jour : c'est SA date qui commande sa série,
			   pas celle de la facture qu'il annule — un avoir de janvier sur
			   une facture de décembre appartient bien à l'exercice en cours. */
			$numero = self::nextNumeroAvoir( date( 'Y-m-d' ) );
			$db->prepare(
				'INSERT INTO factures(numero,type,avoir_origine_id,client_id,client_nom,date_facture,echeance,devise,payment_method,template,commercial_message,footer,montant_ht,montant_tva,montant_ttc,statut,created_by,division_id)
				 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
			)->execute( array(
				$numero, 'avoir', (int) $origineId, $o['client_id'] ?: null, $o['client_nom'],
				date( 'Y-m-d' ), null, $o['devise'] ?: 'XOF', $o['payment_method'], $o['template'],
				'Avoir sur facture ' . $o['numero'], $o['footer'] ?: null,
				-1 * (float) $o['montant_ht'], -1 * (float) $o['montant_tva'], -1 * (float) $o['montant_ttc'],
				'brouillon', FKC_Auth::id(), ! empty( $o['division_id'] ) ? (int) $o['division_id'] : null,
			) );
			$aid = (int) $db->lastInsertId();
			$il = $db->prepare( 'INSERT INTO facture_lignes(facture_id,designation,quantite,pu_ht,tva_code,tva_taux,montant_ht,unite,compte,item_id,ordre) VALUES(?,?,?,?,?,?,?,?,?,?,?)' );
			$i = 0;
			foreach ( $o['lignes'] as $l ) {
				$il->execute( array(
					$aid, $l['designation'], (float) $l['quantite'], -1 * (float) $l['pu_ht'],
					$l['tva_code'], (float) $l['tva_taux'], -1 * (float) $l['montant_ht'],
					$l['unite'] ?? 'pièce', $l['compte'] ?? null, ! empty( $l['item_id'] ) ? (int) $l['item_id'] : null, $i++,
				) );
			}
			// Comptabilisation automatique de l'avoir (écriture inverse) : APRÈS
			// validation, pour qu'un avoir annulé ne laisse jamais d'écriture.
			FKC_Tx::apresCommit( function () use ( $aid, $o ) {
				/*
				 * L'avoir d'un SPÉCIMEN hérite de sa nature (1.802.0) : pièce
				 * d'essai, donc jamais comptabilisée. Sans cela, le dossier de
				 * validation DGI laissait deux écritures d'annulation dans une
				 * comptabilité où la vente correspondante n'existait pas.
				 */
				if ( ! empty( $o['specimen'] ) ) {
					FKC_DB::q( 'UPDATE factures SET specimen=1, specimen_cle=? WHERE id=?', array( 'avoir_' . (string) $o['specimen_cle'], (int) $aid ) );
				} else {
					try { self::comptabiliser( $aid ); } catch ( Throwable $e ) { fkc_log( 'Avoir auto-compta ' . $e->getMessage(), 'WARN' ); }
				}
			} );
			return array( true, 'Avoir ' . $numero . ' créé (note de crédit sur ' . $o['numero'] . ').', $aid );
			} );
		} catch ( Throwable $e ) {
			fkc_log( 'Facture::createAvoir ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de la création de l\'avoir.', null );
		}
	}

	/**
	 * Avoir PARTIEL (1.865.0) : ne crédite que les quantités rendues, ligne par
	 * ligne (clé = ordre de la ligne d'origine). Plusieurs avoirs partiels
	 * peuvent se succéder sur une même facture, sans jamais dépasser, ligne
	 * par ligne, la quantité facturée (les avoirs déjà émis, partiels ou
	 * total, sont déduits). Même comptabilisation que l'avoir total.
	 * @param array $quantites ordre de la ligne d'origine => quantité rendue
	 * @return array{0: bool, 1: string, 2: int|null}
	 */
	public static function createAvoirPartiel( $origineId, array $quantites, $motif = '' ) {
		$o = self::find( $origineId );
		if ( ! $o ) { return array( false, 'Facture d\'origine introuvable.', null ); }
		if ( 'avoir' === ( $o['type'] ?? 'facture' ) ) { return array( false, 'Impossible de créer un avoir sur un avoir.', null ); }
		if ( empty( $o['ecriture_id'] ) && 'CERTIFIE' !== (string) ( $o['fne_status'] ?? '' ) && empty( $o['specimen'] ) ) {
			return array( false, 'Cette facture n\'est pas comptabilisée : modifiez-la plutôt que d\'émettre un avoir.', null );
		}
		// Quantités déjà créditées, par ordre de ligne.
		$deja = array();
		foreach ( FKC_DB::q( "SELECT l.ordre, SUM(ABS(l.quantite)) q FROM facture_lignes l JOIN factures f ON f.id=l.facture_id WHERE f.avoir_origine_id=? AND f.type='avoir' GROUP BY l.ordre", array( (int) $origineId ) )->fetchAll() as $r ) {
			$deja[ (int) $r['ordre'] ] = (float) $r['q'];
		}
		$lignes = array(); $i = 0; $ht = 0.0; $tvaTot = 0.0;
		foreach ( $o['lignes'] as $idx => $l ) {
			$ordre = isset( $l['ordre'] ) ? (int) $l['ordre'] : (int) $idx;
			$q = (float) ( $quantites[ $ordre ] ?? 0 );
			if ( $q <= 0 ) { continue; }
			$reste = (float) $l['quantite'] - ( $deja[ $ordre ] ?? 0 );
			if ( $q > $reste + 0.00001 ) {
				return array( false, '« ' . $l['designation'] . ' » : ' . rtrim( rtrim( number_format( $reste, 3, ',', ' ' ), '0' ), ',' ) . ' seulement restent à créditer.', null );
			}
			$mht = round( $q * (float) $l['pu_ht'], 2 );
			$ht += $mht; $tvaTot += round( $mht * (float) $l['tva_taux'] / 100, 2 );
			$lignes[] = array( $l, $q, $mht, $ordre );
		}
		if ( ! $lignes ) { return array( false, 'Indiquez au moins une quantité rendue.', null ); }
		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $o, $origineId, $lignes, $ht, $tvaTot, $motif ) {
				$numero = self::nextNumeroAvoir( date( 'Y-m-d' ) );
				$db->prepare(
					'INSERT INTO factures(numero,type,avoir_origine_id,client_id,client_nom,date_facture,echeance,devise,payment_method,template,commercial_message,footer,montant_ht,montant_tva,montant_ttc,statut,created_by,division_id)
					 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
				)->execute( array(
					$numero, 'avoir', (int) $origineId, $o['client_id'] ?: null, $o['client_nom'],
					date( 'Y-m-d' ), null, $o['devise'] ?: 'XOF', $o['payment_method'], $o['template'],
					'Avoir partiel sur facture ' . $o['numero'] . ( '' !== trim( (string) $motif ) ? ' — ' . trim( (string) $motif ) : '' ), $o['footer'] ?: null,
					-1 * round( $ht, 2 ), -1 * round( $tvaTot, 2 ), -1 * round( $ht + $tvaTot, 2 ),
					'brouillon', class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null, ! empty( $o['division_id'] ) ? (int) $o['division_id'] : null,
				) );
				$aid = (int) $db->lastInsertId();
				$il = $db->prepare( 'INSERT INTO facture_lignes(facture_id,designation,quantite,pu_ht,tva_code,tva_taux,montant_ht,unite,compte,item_id,ordre) VALUES(?,?,?,?,?,?,?,?,?,?,?)' );
				foreach ( $lignes as list( $l, $q, $mht, $ordre ) ) {
					$il->execute( array( $aid, $l['designation'], $q, -1 * (float) $l['pu_ht'], $l['tva_code'], (float) $l['tva_taux'], -1 * $mht,
						$l['unite'] ?? 'pièce', $l['compte'] ?? null, ! empty( $l['item_id'] ) ? (int) $l['item_id'] : null, $ordre ) );
				}
				FKC_Tx::apresCommit( function () use ( $aid, $o ) {
					if ( empty( $o['specimen'] ) ) {
						try { self::comptabiliser( $aid ); } catch ( \Throwable $e ) { fkc_log( 'Avoir partiel auto-compta ' . $e->getMessage(), 'WARN' ); }
					}
				} );
				return array( true, 'Avoir partiel ' . $numero . ' créé sur ' . $o['numero'] . ' (' . fkc_money( $ht + $tvaTot ) . ' F TTC).', $aid );
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'Facture::createAvoirPartiel ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de la création de l\'avoir partiel.', null );
		}
	}

	/**
	 * Une facture est-elle modifiable ? Tant que rien n'est COMPTABILISÉ ni
	 * CERTIFIÉ, oui — numéro inchangé.
	 *
	 * 1.850.0 — une facture dont l'écriture ATTEND au brouillard redevient
	 * modifiable : rien n'est passé au journal, et la seule issue était
	 * jusqu'ici un avoir (nouveau numéro, et chiffre d'affaires faussé).
	 * La modifier retire l'écriture en attente ; on la recomptabilise ensuite.
	 * Un avoir existant sur la facture la fige, lui.
	 */
	public static function editable( $f ) {
		if ( ! is_array( $f ) ) { return false; }
		if ( ! empty( $f['ecriture_id'] ) ) { return false; }
		if ( 'CERTIFIE' === ( $f['fne_status'] ?? '' ) ) { return false; }
		if ( 'annulee' === ( $f['statut'] ?? '' ) ) { return false; }
		if ( 'avoir' === ( $f['type'] ?? 'facture' ) && class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'factures', (int) $f['id'] ) ) { return false; }
		try {
			if ( FKC_DB::q( 'SELECT 1 FROM factures WHERE avoir_origine_id=? LIMIT 1', array( (int) $f['id'] ) )->fetchColumn() ) { return false; }
		} catch ( \Throwable $e ) {}
		return true;
	}

	/** L'avoir émis sur une facture, s'il existe. */
	public static function avoirDe( $id ) {
		try {
			$r = FKC_DB::q( "SELECT id, numero FROM factures WHERE avoir_origine_id=? LIMIT 1", array( (int) $id ) )->fetch();
			return $r ?: null;
		} catch ( \Throwable $e ) { return null; }
	}

	/** L'écriture de la facture attend-elle au brouillard ? */
	public static function enAttenteAuBrouillard( $id ) {
		return class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'factures', (int) $id );
	}

	/**
	 * Annule une facture qui n'a jamais été comptabilisée ni certifiée
	 * (1.850.0). Elle garde son numéro — la série reste continue, la pièce
	 * reste consultable, marquée annulée — sans avoir ni écriture : il n'y a
	 * rien à contre-passer. Une écriture en attente au brouillard est retirée.
	 */
	public static function annulerNonComptabilisee( $id ) {
		$f = self::find( $id );
		if ( ! $f ) { return array( false, 'Facture introuvable.' ); }
		if ( 'avoir' === ( $f['type'] ?? 'facture' ) ) { return array( false, 'Un avoir ne s\'annule pas ainsi.' ); }
		if ( ! self::editable( $f ) ) {
			return array( false, 'Cette facture est comptabilisée ou certifiée : elle s\'annule par un avoir.' );
		}
		$encaisse = 0.0;
		if ( class_exists( 'FKC_Imputation' ) ) {
			try { $encaisse += (float) ( FKC_Imputation::parFacture( array( (int) $id ), 'client' )[ (int) $id ] ?? 0 ); } catch ( \Throwable $e ) {}
		}
		try {
			$encaisse += (float) FKC_DB::q( "SELECT COUNT(*) FROM recus WHERE facture_id=? AND statut NOT IN ('annule','annulee','brouillon')", array( (int) $id ) )->fetchColumn();
		} catch ( \Throwable $e ) {}
		if ( $encaisse > 0.005 ) {
			return array( false, 'Un encaissement est rattaché à cette facture : retirez-le ou annulez-le d\'abord.' );
		}
		$retires = 0;
		if ( self::enAttenteAuBrouillard( (int) $id ) ) {
			foreach ( FKC_Brouillard::pendingFor( 'factures', (int) $id ) as $bid ) { FKC_Brouillard::delete( (int) $bid ); $retires++; }
		}
		FKC_DB::q( "UPDATE factures SET statut='annulee' WHERE id=?", array( (int) $id ) );
		if ( class_exists( 'FKC_BPE' ) ) {
			FKC_BPE::auditer( 'facture_annulee_non_comptabilisee', 'facture', (int) $id, 'n° ' . $f['numero'] . ' — ' . fkc_money( $f['montant_ttc'] ) . ' F TTC' );
		}
		return array( true, 'Facture ' . $f['numero'] . ' annulée. Elle n\'était pas comptabilisée : aucun avoir n\'était nécessaire'
			. ( $retires ? ', et son écriture en attente a été retirée du brouillard' : '' ) . '. Son numéro reste dans la série, marqué annulé.' );
	}

	/** Met à jour une facture brouillon (en-tête + lignes), numéro inchangé. */
	public static function update( $id, $entete, $lignes ) {
		$f = self::find( $id );
		if ( ! $f ) { return array( false, 'Facture introuvable.', null ); }
		if ( ! self::editable( $f ) ) { return array( false, 'Cette facture n\'est plus modifiable (comptabilisée, certifiée ou annulée).', null ); }

		$clean = array();
		foreach ( $lignes as $l ) {
			$des = trim( (string) ( $l['designation'] ?? '' ) );
			$qte = (float) ( $l['quantite'] ?? 0 );
			$pu  = (float) ( $l['pu_ht'] ?? 0 );
			if ( '' === $des && $qte <= 0 && $pu <= 0 ) { continue; }
			if ( '' === $des ) { return array( false, 'Chaque ligne doit avoir une désignation.', null ); }
			if ( $qte <= 0 || $pu < 0 ) { return array( false, 'Quantité/prix invalides sur une ligne.', null ); }
			$code = self::codeTaxeValide( $l['tva_code'] ?? '' );
			$clean[] = array(
				'designation' => $des, 'quantite' => $qte, 'pu_ht' => $pu,
				'tva_code' => $code, 'tva_taux' => self::tauxFor( $code ),
				'montant_ht' => round( $qte * $pu, 2 ),
				'unite' => trim( (string) ( $l['unite'] ?? 'pièce' ) ) ?: 'pièce',
				'compte' => trim( (string) ( $l['compte'] ?? '' ) ) ?: null,
				'item_id' => ! empty( $l['item_id'] ) ? (int) $l['item_id'] : null,
			);
		}
		if ( ! $clean ) { return array( false, 'Ajoutez au moins une ligne.', null ); }

		$ht = 0; $tva = 0;
		foreach ( $clean as $l ) { $ht += $l['montant_ht']; $tva += round( $l['montant_ht'] * $l['tva_taux'] / 100, 2 ); }
		$ttc = round( $ht + $tva, 2 );

		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $entete, $clean, $ht, $tva, $ttc, $id, $f ) {
			/* 1.850.0 — l'écriture en attente décrit l'ancienne version : on la
			   retire, et la facture redevient un brouillon à recomptabiliser. */
			$retiree = false;
			if ( self::enAttenteAuBrouillard( (int) $id ) ) {
				foreach ( FKC_Brouillard::pendingFor( 'factures', (int) $id ) as $bid ) { FKC_Brouillard::delete( (int) $bid ); }
				$db->prepare( "UPDATE factures SET statut='brouillon' WHERE id=? AND statut='validee'" )->execute( array( (int) $id ) );
				$retiree = true;
			}
			$db->prepare(
				'UPDATE factures SET client_id=?,client_nom=?,date_facture=?,echeance=?,payment_method=?,template=?,commercial_message=?,footer=?,division_id=?,axe_id=?,valeur_id=?,montant_ht=?,montant_tva=?,montant_ttc=? WHERE id=?'
			)->execute( array(
				$entete['client_id'] ?: null, $entete['client_nom'], $entete['date_facture'], $entete['echeance'] ?: null,
				$entete['payment_method'], $entete['template'], $entete['commercial_message'] ?: null, $entete['footer'] ?: null,
				! empty( $entete['division_id'] ) ? (int) $entete['division_id'] : null,
				! empty( $entete['axe_id'] ) ? (int) $entete['axe_id'] : null,
				! empty( $entete['valeur_id'] ) ? (int) $entete['valeur_id'] : null,
				$ht, $tva, $ttc, (int) $id,
			) );
			$db->prepare( 'DELETE FROM facture_lignes WHERE facture_id=?' )->execute( array( (int) $id ) );
			$il = $db->prepare( 'INSERT INTO facture_lignes(facture_id,designation,quantite,pu_ht,tva_code,tva_taux,montant_ht,unite,compte,item_id,ordre) VALUES(?,?,?,?,?,?,?,?,?,?,?)' );
			$i = 0;
			foreach ( $clean as $l ) {
				$il->execute( array( (int) $id, $l['designation'], $l['quantite'], $l['pu_ht'], $l['tva_code'], $l['tva_taux'], $l['montant_ht'], $l['unite'], $l['compte'], $l['item_id'], $i++ ) );
			}
			return array( true, 'Facture ' . $f['numero'] . ' mise à jour' . ( $retiree
				? ' — son écriture en attente au brouillard a été retirée : comptabilisez-la à nouveau.' : '.' ), (int) $id );
			} );
		} catch ( Throwable $e ) {
			fkc_log( 'Facture::update ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de la mise à jour de la facture.', null );
		}
	}

	/**
	 * Génère l'écriture comptable de vente (411 D TTC / 70x C HT / 4421 C TVA).
	 * @return array{bool, string, int|null} ( bool, string, int|null ecriture_id )
	 */
	public static function comptabiliser( $factureId ) {
		$f = self::find( $factureId );
		if ( ! $f ) { return array( false, 'Facture introuvable.', null ); }
		if ( ! empty( $f['ecriture_id'] ) ) { return array( false, 'Facture déjà comptabilisée (écriture n°' . (int) $f['ecriture_id'] . ').', (int) $f['ecriture_id'] ); }
		/*
		 * UN SPÉCIMEN NE SE COMPTABILISE PAS (1.802.0). Les factures du dossier
		 * de validation DGI sont des pièces d'essai, certifiées dans le bac à
		 * sable : elles ne représentent aucune vente. Comptabilisées, elles
		 * gonfleraient le chiffre d'affaires, la TVA collectée et le poste
		 * client — et fausseraient la liasse pour de bon.
		 */
		if ( ! empty( $f['specimen'] ) ) {
			return array( false, 'Spécimen de validation FNE : cette pièce d\'essai ne se comptabilise pas. Supprimez les spécimens une fois votre clé de production obtenue.', null );
		}
		if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'factures', $factureId ) ) {
			return array( false, 'Cette facture est déjà au brouillard, en attente de vérification.', null );
		}

		$compteVente = FKC_License::param( 'fne_compte_vente', '701100' ) ?: '701100';
		/*
		 * LE COMPTE CLIENT — 411100, et le compte auxiliaire du client s'il
		 * en a un.
		 *
		 * Cette ligne résolvait « 411 », que FKC_Compte::byNumero complète en
		 * 411000 : le compte PRINCIPAL du référentiel, celui qui totalise, et
		 * sur lequel on n'impute pas. Le compte de tiers est 411100. Quinze
		 * packs y écrivaient déjà correctement — la facturation, elle,
		 * écrivait à côté, si bien qu'un même client pouvait être débiteur
		 * sur un compte et créditeur sur un autre.
		 *
		 * Le compte auxiliaire éventuel du client est désormais honoré, comme
		 * il l'est déjà pour les fournisseurs au règlement : l'écran des
		 * clients propose ce champ, il doit servir à quelque chose.
		 */
		$cClient = null;
		$cli = ( ! empty( $f['client_id'] ) && class_exists( 'FKC_Client' ) ) ? FKC_Client::find( (int) $f['client_id'] ) : null;
		if ( $cli && ! empty( $cli['compte'] ) ) {
			$cClient = FKC_Compte::byNumero( $cli['compte'] );
			// 1.864.0 — compte auxiliaire du client absent du plan : il est créé,
			// comme le fait le moteur d'écritures (acomptes, règlements). Retomber
			// sur 411100 éclatait le client entre deux comptes.
			if ( ! $cClient && class_exists( 'FKC_Posting' ) && preg_match( '/^41\d+$/', (string) $cli['compte'] ) ) {
				FKC_Posting::compteId( (string) $cli['compte'], 'Client ' . ( $cli['nom'] ?? '' ) );
				$cClient = FKC_Compte::byNumero( $cli['compte'] );
			}
		}
		if ( ! $cClient ) { $cClient = FKC_Compte::byNumero( FKC_PlanMetier::COMPTE_CLIENT ); }
		// Compte de TVA collectée : paramétrable par société ('facturation_cpt_tva'),
		// repli sur 4421 (historique du module) puis 443100 (SYSCOHADA « État,
		// TVA facturée » — compte des packs métier), créé en dernier recours.
		// La Fiscalité lit les deux familles (443x + 4421) : aucune TVA n'échappe
		// à la déclaration quel que soit le compte retenu.
		$tvaNum = trim( (string) FKC_License::param( 'facturation_cpt_tva', '' ) );
		$cTva   = $tvaNum ? FKC_Compte::byNumero( $tvaNum ) : null;
		if ( ! $cTva ) { $cTva = FKC_Compte::byNumero( '4421' ); }
		if ( ! $cTva ) { $cTva = FKC_Compte::byNumero( '443100' ); }
		if ( ! $cTva ) {
			FKC_Compte::create( '443100', 'État, TVA facturée sur ventes' );
			$cTva = FKC_Compte::byNumero( '443100' );
		}
		if ( ! $cClient ) { return array( false, 'Compte ' . FKC_PlanMetier::COMPTE_CLIENT . ' (Clients) absent du plan comptable.', null ); }

		$isAvoir = ( 'avoir' === ( $f['type'] ?? 'facture' ) );

		// Répartition du HT par compte de produit (item), en valeur absolue ; repli sur compte de vente par défaut.
		$parProduit = array();
		foreach ( (array) ( $f['lignes'] ?? array() ) as $l ) {
			$num = trim( (string) ( $l['compte'] ?? '' ) ) ?: $compteVente;
			$parProduit[ $num ] = ( $parProduit[ $num ] ?? 0 ) + abs( (float) $l['montant_ht'] );
		}
		if ( ! $parProduit ) { $parProduit[ $compteVente ] = abs( (float) $f['montant_ht'] ); }
		$absTtc = abs( (float) $f['montant_ttc'] );
		$absTva = abs( (float) $f['montant_tva'] );

		$journaux = FKC_Journal::all();
		$ve = null;
		foreach ( $journaux as $j ) { if ( 'VE' === $j['code'] ) { $ve = $j; break; } }
		if ( ! $ve ) { return array( false, 'Journal des ventes (VE) introuvable.', null ); }

		/*
		 * LE TIERS ET L'ÉCHÉANCE SUR LA LIGNE CLIENT.
		 *
		 * La facture fournisseur marquait depuis toujours son tiers sur la
		 * ligne 401 ; la facture client, non. Le grand livre auxiliaire s'en
		 * sortait en retombant sur la pièce, mais la ligne elle-même ne disait
		 * pas à qui la créance était due — et surtout, elle ne pouvait porter
		 * aucune échéance.
		 *
		 * Or les notes annexes 7 et 17 ventilent créances et dettes par terme
		 * restant à courir. Sans échéance sur la ligne, cette ventilation est
		 * impossible : c'est ici qu'elle se gagne, à l'enregistrement.
		 */
		$auxCli = array( 'tiers_type' => 'client', 'tiers_id' => (int) ( $f['client_id'] ?? 0 ) );
		if ( ! $auxCli['tiers_id'] ) { unset( $auxCli['tiers_type'], $auxCli['tiers_id'] ); }
		if ( ! empty( $f['echeance'] ) ) { $auxCli['echeance'] = (string) $f['echeance']; }

		$div = ! empty( $f['division_id'] ) ? (int) $f['division_id'] : null;
		$axe = ! empty( $f['axe_id'] ) ? (int) $f['axe_id'] : null;
		$val = ! empty( $f['valeur_id'] ) ? (int) $f['valeur_id'] : null;

		// Pré-affectation auto de l'axe analytique « Clients » sur les lignes de produit
		// (uniquement si aucune imputation analytique n'a été choisie manuellement sur la facture).
		$impAxe = $axe; $impVal = $val;
		if ( ! $impAxe && ! empty( $f['client_id'] ) && class_exists( 'FKC_AnalytiqueLink' ) ) {
			$cliCode = ''; $cliNom = (string) ( $f['client_nom'] ?? '' );
			try {
				$cr = FKC_DB::q( 'SELECT code, nom FROM clients WHERE id=?', array( (int) $f['client_id'] ) )->fetch();
				if ( $cr ) { $cliCode = (string) ( $cr['code'] ?? '' ); if ( ! empty( $cr['nom'] ) ) { $cliNom = (string) $cr['nom']; } }
			} catch ( \Throwable $e ) { /* table clients différente : on garde le nom de la facture */ }
			$cv = (int) FKC_AnalytiqueLink::sync( 'client', (int) $f['client_id'], $cliCode, $cliNom );
			if ( $cv ) {
				$ca = (int) FKC_AnalytiqueLink::axeFor( 'client' );
				if ( $ca ) { $impAxe = $ca; $impVal = $cv; }
			}
		}
		$lignes = array();
		if ( $isAvoir ) {
			// Avoir (note de crédit) : écriture inverse → 70x D HT | 4421 D TVA | 411 C TTC.
			foreach ( $parProduit as $num => $montant ) {
				if ( $montant <= 0 ) { continue; }
				$cv = FKC_Compte::byNumero( $num ) ?: FKC_Compte::byNumero( $compteVente );
				if ( ! $cv ) { return array( false, 'Compte de vente ' . $num . ' absent du plan comptable.', null ); }
				$lignes[] = array( 'compte_id' => $cv['id'], 'libelle' => 'Avoir ' . $f['numero'], 'debit' => round( $montant, 2 ), 'credit' => 0, 'division_id' => $div, 'axe_id' => $impAxe, 'valeur_id' => $impVal );
			}
			if ( $absTva > 0 && $cTva ) {
				$lignes[] = array( 'compte_id' => $cTva['id'], 'libelle' => 'TVA sur avoir ' . $f['numero'], 'debit' => $absTva, 'credit' => 0 );
			}
			$lignes[] = array( 'compte_id' => $cClient['id'], 'libelle' => 'Avoir client ' . $f['client_nom'], 'debit' => 0, 'credit' => $absTtc ) + $auxCli;
		} else {
			// Vente : 411 D TTC | 70x C HT | 4421 C TVA.
			$lignes[] = array( 'compte_id' => $cClient['id'], 'libelle' => 'Client ' . $f['client_nom'], 'debit' => $absTtc, 'credit' => 0 ) + $auxCli;
			foreach ( $parProduit as $num => $montant ) {
				if ( $montant <= 0 ) { continue; }
				$cv = FKC_Compte::byNumero( $num ) ?: FKC_Compte::byNumero( $compteVente );
				if ( ! $cv ) { return array( false, 'Compte de vente ' . $num . ' absent du plan comptable.', null ); }
				$lignes[] = array( 'compte_id' => $cv['id'], 'libelle' => 'Vente ' . $f['numero'], 'debit' => 0, 'credit' => round( $montant, 2 ), 'division_id' => $div, 'axe_id' => $impAxe, 'valeur_id' => $impVal );
			}
			if ( $absTva > 0 && $cTva ) {
				$lignes[] = array( 'compte_id' => $cTva['id'], 'libelle' => 'TVA facturée ' . $f['numero'], 'debit' => 0, 'credit' => $absTva );
			}
		}

		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( array(
			'journal_id' => (int) $ve['id'], 'date_ecriture' => $f['date_facture'],
			'piece' => $f['numero'], 'libelle' => ( $isAvoir ? 'Avoir ' : 'Facture ' ) . $f['numero'] . ' — ' . $f['client_nom'],
			'reference' => $f['fne_reference'] ?: null, 'created_by' => FKC_Auth::id(),
		), $lignes, array(
			'source' => $isAvoir ? 'avoir' : 'vente',
			'lien'   => array( 'table' => 'factures', 'colonne' => 'ecriture_id', 'ids' => array( (int) $factureId ) ),
		) );
		if ( ! $ok ) { return array( false, 'Comptabilisation : ' . $msg, null ); }

		/*
		 * UNE FACTURE COMPTABILISÉE N'EST PLUS UN BROUILLON.
		 *
		 * Le statut restait « brouillon » à vie : il n'en sortait que par la
		 * certification FNE. Trois conséquences, toutes silencieuses :
		 *
		 *   — le module Recouvrement écarte délibérément les brouillons (« un
		 *     brouillon n'est pas une créance »), si bien que TOUTE facture
		 *     émise par le chemin ordinaire lui était invisible : encours nul,
		 *     balance âgée vide, aucune relance, pendant que le 411 était bien
		 *     débité ;
		 *   — le contrôle d'encours (COM-006) jugeait donc chaque client
		 *     comme n'ayant jamais rien acheté ;
		 *   — l'écran de la facture continuait d'annoncer « en brouillon » une
		 *     pièce définitivement passée en comptabilité.
		 *
		 * La brique verticale avait déjà ce correctif depuis 1.520.104, mais
		 * appliqué à ses trois chemins seulement. On le remonte à la source,
		 * ce qui le rend valable pour tous les appelants présents et futurs.
		 *
		 * On n'usurpe pas la certification : « validee » dit que la pièce est
		 * émise et comptabilisée, « certifiee » restera le fait de la FNE. Et
		 * le statut bascule aussi quand l'écriture part au journal temporaire —
		 * la facture, elle, EST partie chez le client ; sa créance ne dépend pas
		 * du moment où le comptable validera l'écriture.
		 */
		FKC_DB::q( "UPDATE factures SET statut='validee' WHERE id=? AND statut='brouillon'", array( (int) $factureId ) );
		if ( class_exists( 'FKC_Recouvrement' ) ) { FKC_Recouvrement::oublier(); }

		if ( $bid ) {
			return array( true, 'Écriture déposée au brouillard (à vérifier avant comptabilisation).', null );
		}
		// Pont vers le bus d'événements : recouvrement, notifications, KPIs de
		// packs (« CA du jour »…) réagissent sans double comptabilisation.
		if ( class_exists( 'FKC_Events' ) ) {
			FKC_Events::emettre( $isAvoir ? 'avoir_valide' : 'facture_validee', array(
				'facture_id' => (int) $factureId, 'numero' => (string) $f['numero'],
				'client_id' => ! empty( $f['client_id'] ) ? (int) $f['client_id'] : null,
				'client' => (string) $f['client_nom'], 'date' => (string) $f['date_facture'],
				'ht' => (float) $f['montant_ht'], 'tva' => (float) $f['montant_tva'], 'ttc' => (float) $f['montant_ttc'],
				'division_id' => $div, 'ecriture_id' => (int) $eid,
			), array( 'poster' => false ) );
		}
		return array( true, 'Écriture comptable n°' . $eid . ' générée (journal VE).', $eid );
	}

	/**
	 * Auto-réparation : comptabilise tous les avoirs encore en attente (créés avant
	 * l'auto-comptabilisation, ou dont la comptabilisation avait échoué). Idempotent —
	 * ignore les avoirs déjà comptabilisés, annulés, ou en attente au brouillard.
	 * @return int nombre d'avoirs effectivement comptabilisés (ou déposés au brouillard).
	 */
	public static function comptabiliserAvoirsEnAttente( $max = 500 ) {
		// Les spécimens du dossier FNE sont exclus (1.802.0) : ce sont des
		// pièces d'essai, le rattrapage ne doit pas les comptabiliser.
		$sql = "SELECT id FROM factures
			 WHERE type='avoir' AND (ecriture_id IS NULL OR ecriture_id=0)
			   AND (statut IS NULL OR (statut NOT LIKE 'annul%' AND statut NOT LIKE 'ANNUL%'))
			   AND COALESCE(specimen,0)=0
			 ORDER BY id ASC LIMIT " . (int) $max;
		try { $rows = FKC_DB::q( $sql )->fetchAll(); }
		catch ( Throwable $e ) { $rows = FKC_DB::q( str_replace( 'AND COALESCE(specimen,0)=0', '', $sql ) )->fetchAll(); }
		$n = 0;
		foreach ( $rows as $r ) {
			$id = (int) $r['id'];
			if ( class_exists( 'FKC_Brouillard' ) && FKC_Brouillard::hasPendingFor( 'factures', $id ) ) { continue; }
			try {
				list( $ok ) = self::comptabiliser( $id );
				if ( $ok ) { $n++; }
			} catch ( Throwable $e ) { fkc_log( 'Avoir backfill ' . $e->getMessage(), 'WARN' ); }
		}
		return $n;
	}
}
