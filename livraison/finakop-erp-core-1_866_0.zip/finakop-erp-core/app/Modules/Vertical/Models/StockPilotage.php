<?php
/**
 * Socle de pilotage pour les packs à STOCK (quincaillerie, prêt-à-porter,
 * cosmétiques, menuiserie…). Ces packs enregistrent leurs ventes dans
 * vp_mouvements (sens='sortie') et non dans vp_pieces : ce modèle fournit donc
 * la même forme de données que FKC_VpPilotage, mais lue depuis le stock, afin
 * que les hooks.php de ces packs héritent des mêmes moteurs (KPI, graphiques,
 * prévisions, assistant…) sans code spécifique.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpStockPilotage {

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	protected static function table() {
		// S'assure que les tables de stock existent.
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
	}

	/* ── Chiffre d'affaires (ventes = sorties de stock) ──────────────────── */

	/*
	 * QU'EST-CE QU'UNE VENTE ? (1.857.0)
	 *
	 * Toute sortie n'en est pas une. Une chute de découpe, une pièce posée
	 * sous garantie, l'annulation d'une réception sortent du stock sans que
	 * rien ne soit vendu — les compter faisait monter le chiffre d'affaires
	 * du jour d'une perte. Et un retour client le fait BAISSER : il était
	 * ignoré, si bien qu'un article vendu puis rapporté restait vendu.
	 */
	// COALESCE : un motif NULL (mouvement importé, saisie ancienne) reste une
	// vente — « NULL NOT LIKE … » vaut NULL en SQL et l'aurait écartée.
	const HORS_VENTE = "COALESCE(motif,'') NOT LIKE 'Chute de découpe%' AND COALESCE(motif,'') NOT LIKE 'SAV sous garantie%' AND COALESCE(motif,'') NOT LIKE 'Annulation réception%' AND COALESCE(motif,'') NOT LIKE 'Inventaire%'";

	/** Chiffre d'affaires HT net des retours, pour un préfixe de date (AAAA, AAAA-MM ou AAAA-MM-JJ). */
	public static function caPeriode( $prefixe ) {
		self::table();
		$n = strlen( (string) $prefixe );
		return (float) FKC_DB::q(
			"SELECT COALESCE(SUM(CASE WHEN sens='sortie' AND " . self::HORS_VENTE . " THEN montant WHEN sens='retour' THEN -montant ELSE 0 END),0)
			 FROM vp_mouvements WHERE pack=? AND substr(created_at,1,{$n})=?",
			array( self::pack(), (string) $prefixe )
		)->fetchColumn();
	}

	public static function caJour( $date = null ) { return self::caPeriode( $date ?: date( 'Y-m-d' ) ); }

	public static function caMois( $ym = null ) { return self::caPeriode( $ym ?: date( 'Y-m' ) ); }

	public static function caAnnee( $annee = null ) { return self::caPeriode( (string) ( $annee ?: date( 'Y' ) ) ); }

	/**
	 * Marge du mois : CA − coût des ventes, nets des retours. Le coût est
	 * celui MÉMORISÉ à la sortie (1.857.0), au CUMP courant à défaut pour
	 * l'historique — le CUMP du jour réécrivait la marge des mois passés à
	 * chaque réception.
	 */
	public static function margeMois( $ym = null ) {
		self::table();
		$m = $ym ?: date( 'Y-m' );
		$r = FKC_DB::q(
			"SELECT COALESCE(SUM(CASE WHEN mo.sens='sortie' THEN mo.montant ELSE -mo.montant END),0) ca,
			        COALESCE(SUM(CASE WHEN mo.sens='sortie' THEN COALESCE(mo.cout, mo.qte * a.cump) ELSE -COALESCE(mo.cout, mo.qte * a.cump) END),0) cout
			 FROM vp_mouvements mo JOIN vp_articles a ON a.id=mo.article_id
			 WHERE mo.pack=? AND ( ( mo.sens='sortie' AND " . str_replace( 'motif', 'mo.motif', self::HORS_VENTE ) . " ) OR mo.sens='retour' ) AND substr(mo.created_at,1,7)=?",
			array( self::pack(), $m )
		)->fetch();
		$ca = (float) ( $r['ca'] ?? 0 ); $cout = (float) ( $r['cout'] ?? 0 );
		return array( 'ca' => $ca, 'cout' => $cout, 'marge' => round( $ca - $cout, 2 ), 'taux' => $ca > 0 ? round( ( $ca - $cout ) / $ca * 100, 1 ) : 0 );
	}

	/* ── Synthèse cockpit ────────────────────────────────────────────────── */
	public static function synthese() {
		self::table();
		$pk = self::pack();
		$art = FKC_DB::q( "SELECT COUNT(*) n, COALESCE(SUM(qte_stock*cump),0) v FROM vp_articles WHERE pack=? AND actif=1", array( $pk ) )->fetch();
		$alertes = (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_articles WHERE pack=? AND actif=1 AND seuil_alerte>0 AND qte_stock<=seuil_alerte", array( $pk ) )->fetchColumn();
		$nbVentesMois = (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_mouvements WHERE pack=? AND sens='sortie' AND " . self::HORS_VENTE . " AND substr(created_at,1,7)=?", array( $pk, date( 'Y-m' ) ) )->fetchColumn();
		$caMois = self::caMois();
		return array(
			'articles_actifs' => (int) ( $art['n'] ?? 0 ),
			'stock_valeur' => (float) ( $art['v'] ?? 0 ),
			'alertes_stock' => $alertes,
			'ca_jour' => self::caJour(),
			'ca_mois' => $caMois,
			'ca_annee' => self::caAnnee(),
			'nb_ventes_mois' => $nbVentesMois,
			'panier_moyen' => $nbVentesMois > 0 ? round( $caMois / $nbVentesMois ) : 0,
		);
	}

	/* ── Ventilations pour graphiques ────────────────────────────────────── */
	/** CA par catégorie d'article (pour donut / treemap). */
	public static function caParCategorie( $ym = null, $limit = 12 ) {
		self::table();
		$m = $ym ?: date( 'Y-m' );
		$rows = FKC_DB::q(
			"SELECT COALESCE(NULLIF(a.categorie,''),'Divers') cat, COALESCE(SUM(CASE WHEN mo.sens='sortie' THEN mo.montant ELSE -mo.montant END),0) ca
			 FROM vp_mouvements mo JOIN vp_articles a ON a.id=mo.article_id
			 WHERE mo.pack=? AND ( ( mo.sens='sortie' AND " . str_replace( 'motif', 'mo.motif', self::HORS_VENTE ) . " ) OR mo.sens='retour' ) AND substr(mo.created_at,1,7)=?
			 GROUP BY cat ORDER BY ca DESC LIMIT " . (int) $limit,
			array( self::pack(), $m )
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) { $out[ $r['cat'] ] = (float) $r['ca']; }
		return $out;
	}

	/** Top articles par CA (pour barsH / Pareto). */
	public static function topArticles( $ym = null, $limit = 15 ) {
		self::table();
		$m = $ym ?: date( 'Y-m' );
		return FKC_DB::q(
			"SELECT a.libelle, a.reference, COALESCE(SUM(CASE WHEN mo.sens='sortie' THEN mo.montant ELSE -mo.montant END),0) ca,
			        COALESCE(SUM(CASE WHEN mo.sens='sortie' THEN mo.qte ELSE -mo.qte END),0) qte
			 FROM vp_mouvements mo JOIN vp_articles a ON a.id=mo.article_id
			 WHERE mo.pack=? AND ( ( mo.sens='sortie' AND " . str_replace( 'motif', 'mo.motif', self::HORS_VENTE ) . " ) OR mo.sens='retour' ) AND substr(mo.created_at,1,7)=?
			 GROUP BY mo.article_id ORDER BY ca DESC LIMIT " . (int) $limit,
			array( self::pack(), $m )
		)->fetchAll();
	}

	/* ── Séries temporelles ──────────────────────────────────────────────── */
	public static function evolutionMensuelle( $mois = 6 ) {
		self::table();
		$out = array();
		for ( $i = $mois - 1; $i >= 0; $i-- ) {
			$ym = date( 'Y-m', strtotime( "first day of -$i month" ) );
			$out[ $ym ] = self::caMois( $ym );
		}
		return $out;
	}

	/**
	 * Série des N derniers jours, INDEXÉE PAR DATE (1.857.0). Les sections
	 * cockpit des packs (station, téléphonie, supérette, pharmacie) tirent
	 * leurs étiquettes de `array_keys()` : une liste 0..13 donnait des
	 * étiquettes vides sous chaque barre. Les prévisions, elles, prennent
	 * `array_values()` et ne voient pas la différence.
	 */
	public static function serieJournaliere( $jours = 14 ) {
		self::table();
		$out = array();
		for ( $i = $jours - 1; $i >= 0; $i-- ) {
			$d = date( 'Y-m-d', strtotime( "-$i day" ) );
			$out[ $d ] = self::caJour( $d );
		}
		return $out;
	}

	/* ── Stock dormant & compteurs ───────────────────────────────────────── */
	/** Articles actifs sans aucune vente sur le mois (stock dormant). */
	public static function articlesDormants( $ym = null ) {
		self::table();
		$m = $ym ?: date( 'Y-m' );
		return FKC_DB::q(
			"SELECT a.id, a.libelle, a.reference, a.qte_stock
			 FROM vp_articles a
			 WHERE a.pack=? AND a.actif=1 AND a.qte_stock > 0
			   AND NOT EXISTS (
			     SELECT 1 FROM vp_mouvements mo
			     WHERE mo.article_id=a.id AND mo.sens='sortie' AND substr(mo.created_at,1,7)=?
			   )
			 ORDER BY a.qte_stock*a.cump DESC",
			array( self::pack(), $m )
		)->fetchAll();
	}

	/* ══════════════════════════════════════════════════════════════════════
	   ROTATION & PÉREMPTIONS — calculés ICI, pour les vingt et un packs de
	   commerce à la fois (1.536.0)
	   ══════════════════════════════════════════════════════════════════════

	   Ces deux chiffres manquaient à presque tous les packs de commerce, et
	   c'était le même manque à chaque fois. Les écrire dans chaque hooks.php
	   aurait produit vingt et une copies d'une même requête — dont vingt
	   auraient fini par diverger de la première, en silence, le jour où la
	   définition change.

	   Le moteur de stock vertical est déjà partagé par tous ces packs : c'est
	   ici que le calcul appartient. Un ajout, vingt et un métiers servis. */

	/**
	 * Rotation du stock, exprimée en JOURS D'ÉCOULEMENT.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * POURQUOI DES JOURS ET NON UN COEFFICIENT
	 *
	 * La formule classique — coût des ventes ÷ stock moyen — rend un nombre de
	 * « tours par an » : 6, 12, 24. C'est juste, et parfaitement illisible
	 * pour un commerçant. « Quarante-cinq jours de stock » se comprend
	 * immédiatement, et se compare à ce qu'il sait déjà : le délai de son
	 * fournisseur, la durée de vie de sa marchandise.
	 *
	 * Le calcul reste le même, retourné à l'endroit : valeur du stock ÷ coût
	 * des ventes quotidien.
	 *
	 * SUR QUELLE PÉRIODE
	 *
	 * Quatre-vingt-dix jours glissants, et non le mois en cours. Un commerce
	 * qui calcule sa rotation le 2 du mois n'a que deux jours de ventes :
	 * il afficherait des centaines de jours de stock et croirait crouler sous
	 * la marchandise. Le trimestre lisse les à-coups sans effacer une
	 * tendance.
	 *
	 * @return float|null null quand rien n'a été vendu — pas 0, qui se lirait
	 *                    « stock parfaitement fluide » alors qu'il ne bouge pas.
	 */
	public static function rotationJours() {
		self::table();
		$pk = self::pack();
		try {
			$cout = (float) FKC_DB::q(
				"SELECT COALESCE(SUM(mo.qte * a.cump),0)
				 FROM vp_mouvements mo JOIN vp_articles a ON a.id=mo.article_id
				 WHERE mo.pack=? AND mo.sens='sortie' AND date(mo.created_at) >= date('now','-90 days')",
				array( $pk )
			)->fetchColumn();
			if ( $cout <= 0 ) { return null; }
			$valeur = (float) FKC_DB::q(
				'SELECT COALESCE(SUM(qte_stock*cump),0) FROM vp_articles WHERE pack=? AND actif=1',
				array( $pk )
			)->fetchColumn();
			return round( $valeur / ( $cout / 90 ), 1 );
		} catch ( \Throwable $e ) { return null; }
	}

	/**
	 * Lots dont la date limite tombe dans les $jours prochains.
	 *
	 * Les lots DÉJÀ périmés sont comptés à part : ce ne sont plus des lots à
	 * écouler mais des lots à sortir, et confondre les deux ferait espérer une
	 * vente là où il faut acter une perte.
	 *
	 * @return array{proches:int, perimes:int, valeur_proche:float}
	 */
	public static function peremptions( $jours = 30 ) {
		self::table();
		$pk = self::pack();
		$vide = array( 'proches' => 0, 'perimes' => 0, 'valeur_proche' => 0.0 );
		try {
			$r = FKC_DB::q(
				"SELECT
					SUM(CASE WHEN date(l.date_peremption) >= date('now')
					          AND date(l.date_peremption) <= date('now', ?) THEN 1 ELSE 0 END) proches,
					SUM(CASE WHEN date(l.date_peremption) < date('now') THEN 1 ELSE 0 END) perimes,
					COALESCE(SUM(CASE WHEN date(l.date_peremption) >= date('now')
					          AND date(l.date_peremption) <= date('now', ?) THEN l.qte_restante * a.cump ELSE 0 END),0) valeur
				 FROM vp_lots l JOIN vp_articles a ON a.id=l.article_id
				 WHERE l.pack=? AND l.qte_restante > 0 AND l.date_peremption IS NOT NULL AND l.date_peremption <> ''",
				array( '+' . max( 1, (int) $jours ) . ' days', '+' . max( 1, (int) $jours ) . ' days', $pk )
			)->fetch();
			if ( ! $r ) { return $vide; }
			return array(
				'proches' => (int) ( $r['proches'] ?? 0 ),
				'perimes' => (int) ( $r['perimes'] ?? 0 ),
				'valeur_proche' => round( (float) ( $r['valeur'] ?? 0 ), 2 ),
			);
		} catch ( \Throwable $e ) { return $vide; }
	}

	/**
	 * Part du stock qui n'a connu aucune vente depuis trois mois, en valeur.
	 *
	 * Le compte d'articles dormants existait déjà ; il ne disait pas COMBIEN
	 * d'argent dort. Trois références dormantes sans importance ne pèsent pas
	 * comme trois références coûteuses.
	 */
	public static function capitalDormant() {
		self::table();
		$pk = self::pack();
		try {
			return round( (float) FKC_DB::q(
				"SELECT COALESCE(SUM(a.qte_stock * a.cump),0) FROM vp_articles a
				 WHERE a.pack=? AND a.actif=1 AND a.qte_stock > 0
				   AND NOT EXISTS(
					SELECT 1 FROM vp_mouvements mo
					 WHERE mo.article_id=a.id AND mo.sens='sortie'
					   AND date(mo.created_at) >= date('now','-90 days'))",
				array( $pk )
			)->fetchColumn(), 2 );
		} catch ( \Throwable $e ) { return 0.0; }
	}

	public static function compteurs() {
		self::table();
		$pk = self::pack();
		return array(
			'alertes_stock' => (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_articles WHERE pack=? AND actif=1 AND seuil_alerte>0 AND qte_stock<=seuil_alerte", array( $pk ) )->fetchColumn(),
			'dormants' => count( self::articlesDormants() ),
		);
	}
}
