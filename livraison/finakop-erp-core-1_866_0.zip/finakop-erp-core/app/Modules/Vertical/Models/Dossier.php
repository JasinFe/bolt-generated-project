<?php
/**
 * Moteur vertical générique — DOSSIER (objet central d'un pack métier).
 *
 * Un pack « déclaratif » (Garage, Clinique, École, Restaurant…) n'écrit aucun
 * code : son manifest décrit l'objet central (véhicule, patient, élève, point
 * de vente…) via le bloc « vertical » et ce moteur fournit les tables, les
 * écrans et le cycle comptable. Le pack BTP conserve son implémentation
 * spécifique (retenues de garantie) : les deux approches coexistent.
 *
 * Bloc manifest attendu :
 *   'vertical' => array(
 *     'prefixe' => 'GA',                       // code dossier GA-2026-001
 *     'tiers'   => 'Client',                   // libellé du tiers du dossier
 *     'champs'  => array( 'cle' => array('label'=>…, 'type'=>text|number|date|select, 'options'=>…) ),
 *     'pieces'  => array( 'type' => array('label'=>…, 'evenement'=>…, 'tva'=>18) ),
 *   )
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

/*
 * Ce modèle attribue ses références par FKC_CodeAuto (1.631.0). index.php le
 * charge, mais pas les harnais qui montent un modèle seul : sans ce require,
 * la classe manque au moment précis où l'on crée une pièce. On l'exige donc
 * plutôt que de retomber sur un COUNT(*) — un repli qui réintroduirait le
 * défaut corrigé serait pire que l'absence de repli.
 */
require_once FKC_ROOT . 'Core/CodeAuto.php';

class FKC_VpDossier {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_dossiers(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				code TEXT NOT NULL UNIQUE,
				libelle TEXT NOT NULL,
				tiers_nom TEXT,
				client_id INTEGER,
				champs TEXT,
				montant_ref REAL NOT NULL DEFAULT 0,
				date_debut TEXT, date_fin TEXT,
				statut TEXT NOT NULL DEFAULT 'ouvert',
				division_id INTEGER,
				notes TEXT,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_vpd_pack ON vp_dossiers(pack, statut);
			CREATE TABLE IF NOT EXISTS vp_pieces(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				dossier_id INTEGER NOT NULL,
				type TEXT NOT NULL,
				numero INTEGER NOT NULL,
				date_piece TEXT NOT NULL,
				libelle TEXT,
				montant_ht REAL NOT NULL DEFAULT 0,
				tva_pct REAL NOT NULL DEFAULT 0,
				statut TEXT NOT NULL DEFAULT 'brouillon',
				ecriture_id INTEGER, brouillon_id INTEGER, wf_instance_id INTEGER,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				FOREIGN KEY(dossier_id) REFERENCES vp_dossiers(id)
			);
			CREATE INDEX IF NOT EXISTS idx_vpp_dossier ON vp_pieces(dossier_id);
			CREATE INDEX IF NOT EXISTS idx_vpp_statut ON vp_pieces(statut);
		" );
		/*
		 * 1.859.0 — UNE PIÈCE PEUT DÉLIVRER UN ARTICLE DU STOCK. Le type de
		 * pièce déclaré « 'stock' => true » (vente pharmacie d'une clinique,
		 * équipement d'optique) porte l'article et la quantité ; la sortie de
		 * stock et son coût (D 603 / C 31) se constatent à la comptabilisation.
		 */
		try {
			$cols = array_column( FKC_DB::q( 'PRAGMA table_info(vp_pieces)' )->fetchAll(), 'name' );
			// 1.860.0 — « moyen » : moyen d'encaissement d'une recette (espèces, Wave, carte…).
			foreach ( array( 'article_id' => 'INTEGER', 'qte_article' => 'REAL', 'stock_mouvement_id' => 'INTEGER', 'moyen' => 'TEXT' ) as $c => $t ) {
				if ( ! in_array( $c, $cols, true ) ) { FKC_DB::conn()->exec( "ALTER TABLE vp_pieces ADD COLUMN {$c} {$t}" ); }
			}
		} catch ( \Throwable $e ) {}
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function statuts() {
		return array( 'ouvert' => 'Ouvert', 'suspendu' => 'Suspendu', 'clos' => 'Clos' );
	}

	/** Pack métier courant (les dossiers sont cloisonnés par pack). */
	public static function pack() { return FKC_Packs::activeCode(); }

	public static function all( $statut = '' ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( $statut ) { $w .= ' AND statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT * FROM vp_dossiers {$w} ORDER BY statut='ouvert' DESC, created_at DESC", $p )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_dossiers WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		if ( $r ) { $r['champs_arr'] = json_decode( (string) ( $r['champs'] ?? '' ), true ) ?: array(); }
		return $r ?: null;
	}

	/** Code auto : {PREFIXE}-ANNEE-NNN. */
	public static function nextCode( $prefixe ) {
		self::ensure();
		$an = date( 'Y' );
		// Plus haut code attribué, et non nombre de dossiers : supprimer un
		// dossier faisait réattribuer son code au suivant (1.631.0).
		return FKC_CodeAuto::suivant( 'vp_dossiers', $prefixe . '-' . $an . '-', 'code', 3 );
	}

	/**
	 * CLIENT DU DOSSIER (1.866.0).
	 *
	 * Le tiers d'un dossier se saisissait en texte libre : un nom, sans fiche.
	 * Les pièces facturées au 411 restaient alors ANONYMES — ni encours, ni
	 * relance, ni bouton « Encaisser », ni balance âgée. Pour un pack dont le
	 * tiers est un client (manifeste « tiers_client »), le nom est rattaché à
	 * une fiche client : celle qui porte déjà ce nom, ou une nouvelle —
	 * jamais un doublon (FKC_RecouvrementSources::tiers).
	 */
	public static function resoudreClient( $clientId, $tiersNom, $code, array $cfg ) {
		if ( $clientId ) { return (int) $clientId; }
		$nom = trim( (string) $tiersNom );
		if ( '' === $nom || empty( $cfg['tiers_client'] ) ) { return null; }
		if ( class_exists( 'FKC_RecouvrementSources' ) ) {
			try { return (int) FKC_RecouvrementSources::tiers( 'dossier_' . self::pack(), (string) $code, $nom ) ?: null; } catch ( \Throwable $e ) { return null; }
		}
		return null;
	}

	/** @return array{bool, string, int|null} ( bool ok, string message, int|null id ) */
	public static function create( array $d, array $cfg ) {
		self::ensure();
		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le libellé est obligatoire.', null ); }
		$code = trim( (string) ( $d['code'] ?? '' ) ) ?: self::nextCode( $cfg['prefixe'] ?? 'DOS' );
		$clientId = self::resoudreClient( ! empty( $d['client_id'] ) ? (int) $d['client_id'] : 0, $d['tiers_nom'] ?? '', $code, $cfg );
		if ( $clientId && '' === trim( (string) ( $d['tiers_nom'] ?? '' ) ) && class_exists( 'FKC_Client' ) ) {
			$cl = FKC_Client::find( $clientId );
			if ( $cl ) { $d['tiers_nom'] = (string) $cl['nom']; }
		}
		try {
			FKC_DB::q(
				'INSERT INTO vp_dossiers(pack,code,libelle,tiers_nom,client_id,champs,montant_ref,date_debut,date_fin,statut,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
				array(
					self::pack(), $code, $libelle,
					trim( (string) ( $d['tiers_nom'] ?? '' ) ) ?: null,
					$clientId ?: null,
					json_encode( self::champsFromPost( $d, $cfg ), JSON_UNESCAPED_UNICODE ),
					function_exists( 'fkc_nombre' ) ? (float) fkc_nombre( $d['montant_ref'] ?? 0 ) : (float) ( $d['montant_ref'] ?? 0 ),
					(string) ( $d['date_debut'] ?? '' ) ?: null,
					(string) ( $d['date_fin'] ?? '' ) ?: null,
					'ouvert',
					trim( (string) ( $d['notes'] ?? '' ) ) ?: null,
				)
			);
		} catch ( \Throwable $e ) {
			return array( false, 'Code déjà utilisé ou données invalides.', null );
		}
		$id = (int) FKC_DB::conn()->lastInsertId();
		self::ensureDivision( $id );
		return array( true, "Dossier {$code} ouvert.", $id );
	}

	public static function update( $id, array $d, array $cfg ) {
		self::ensure();
		$statuts = self::statuts();
		/*
		 * 1.866.0 — le client se rattache aussi APRÈS la création : un dossier
		 * ouvert sans fiche restait anonyme à vie, la modification ignorant le
		 * champ. Un rattachement existant n'est jamais effacé par un envoi vide.
		 */
		$avant = self::find( $id );
		if ( $avant ) {
			$cid = self::resoudreClient( ! empty( $d['client_id'] ) ? (int) $d['client_id'] : (int) ( $avant['client_id'] ?? 0 ), $d['tiers_nom'] ?? '', (string) $avant['code'], $cfg );
			if ( $cid && (int) $cid !== (int) ( $avant['client_id'] ?? 0 ) ) {
				FKC_DB::q( 'UPDATE vp_dossiers SET client_id=? WHERE id=? AND pack=?', array( (int) $cid, (int) $id, self::pack() ) );
			}
		}
		FKC_DB::q(
			'UPDATE vp_dossiers SET libelle=?, tiers_nom=?, champs=?, montant_ref=?, date_debut=?, date_fin=?, statut=?, notes=? WHERE id=? AND pack=?',
			array(
				trim( (string) ( $d['libelle'] ?? '' ) ),
				trim( (string) ( $d['tiers_nom'] ?? '' ) ) ?: null,
				json_encode( self::champsFromPost( $d, $cfg ), JSON_UNESCAPED_UNICODE ),
				function_exists( 'fkc_nombre' ) ? (float) fkc_nombre( $d['montant_ref'] ?? 0 ) : (float) ( $d['montant_ref'] ?? 0 ),
				(string) ( $d['date_debut'] ?? '' ) ?: null,
				(string) ( $d['date_fin'] ?? '' ) ?: null,
				isset( $statuts[ $d['statut'] ?? '' ] ) ? $d['statut'] : 'ouvert',
				trim( (string) ( $d['notes'] ?? '' ) ) ?: null,
				(int) $id, self::pack(),
			)
		);
		return array( true, 'Dossier mis à jour.' );
	}

	/** Champs personnalisés du manifest (low-code niveau 1) extraits du POST. */
	protected static function champsFromPost( array $d, array $cfg ) {
		$out = array();
		foreach ( (array) ( $cfg['champs'] ?? array() ) as $cle => $def ) {
			$k = 'ch_' . $cle;
			if ( isset( $d[ $k ] ) && '' !== trim( (string) $d[ $k ] ) ) { $out[ $cle ] = trim( (string) $d[ $k ] ); }
		}
		return $out;
	}

	/** Section analytique du dossier (créée à la demande). @return int|null */
	public static function ensureDivision( $id ) {
		$c = self::find( $id );
		if ( ! $c ) { return null; }
		if ( ! empty( $c['division_id'] ) ) { return (int) $c['division_id']; }
		try { FKC_DB::q( 'SELECT 1 FROM divisions LIMIT 1' ); } catch ( \Throwable $e ) { return null; }
		try {
			$did = FKC_DB::q( 'SELECT id FROM divisions WHERE code=?', array( $c['code'] ) )->fetchColumn();
			if ( ! $did ) {
				FKC_DB::q( 'INSERT INTO divisions(code,libelle,type) VALUES(?,?,?)', array( $c['code'], $c['libelle'], 'division' ) );
				$did = FKC_DB::conn()->lastInsertId();
			}
			FKC_DB::q( 'UPDATE vp_dossiers SET division_id=? WHERE id=?', array( (int) $did, (int) $id ) );
			return (int) $did;
		} catch ( \Throwable $e ) { return null; }
	}

	/** KPI du tableau de bord du pack. */
	public static function kpi() {
		self::ensure();
		$pk = self::pack();
		$k  = array( 'ouverts' => 0, 'attente' => 0, 'ca_ht' => 0.0, 'ttc' => 0.0 );
		$k['ouverts'] = (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_dossiers WHERE pack=? AND statut='ouvert'", array( $pk ) )->fetchColumn();
		$k['attente'] = (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id WHERE d.pack=? AND p.statut IN ('brouillon','soumise')", array( $pk ) )->fetchColumn();
		$r = FKC_DB::q(
			"SELECT COALESCE(SUM(p.montant_ht),0) ht, COALESCE(SUM(round(p.montant_ht*(1+p.tva_pct/100.0),2)),0) ttc
			 FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE d.pack=? AND p.statut='comptabilisee' AND p.date_piece BETWEEN ? AND ?",
			array_merge( array( $pk ), FKC_Periode::bornesCourantes() )
		)->fetch();
		$k['ca_ht'] = (float) ( $r['ht'] ?? 0 ); $k['ttc'] = (float) ( $r['ttc'] ?? 0 );
		return $k;
	}

	/** Cumul HT comptabilisé d'un dossier. */
	public static function cumulFacture( $dossierId ) {
		self::ensure();
		return (float) FKC_DB::q( "SELECT COALESCE(SUM(montant_ht),0) FROM vp_pieces WHERE dossier_id=? AND statut='comptabilisee'", array( (int) $dossierId ) )->fetchColumn();
	}
}
