<?php
/**
 * UNITÉS DE VENTE MULTIPLES (COM-023) — Quincaillerie et tout commerce qui
 * achète en gros conditionnement et vend au détail (ou l'inverse).
 *
 * Le stock (`vp_articles.qte_stock`, le CUMP, les mouvements) reste TOUJOURS
 * exprimé dans l'unité DE BASE de l'article (`vp_articles.unite` — souvent
 * « pièce »). Ce que cette brique ajoute, ce sont des unités DE VENTE
 * alternatives pour un même article — « Carton de 12 », « Lot de 6 »,
 * « Botte de 25 » — chacune avec un facteur de conversion vers l'unité de
 * base. Vendre « 2 cartons de 12 » sort 24 pièces du stock, mais se vend et
 * se facture comme 2 cartons à leur propre prix — jamais confondu avec 24
 * lignes de pièces au détail.
 *
 * Volontairement une brique À PART (comme FKC_VpSerie pour COM-010) :
 * n'existe que pour les articles qui déclarent des unités alternatives, et
 * n'entrave en rien les 7 autres packs qui n'en ont pas besoin.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpUnite {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_unites(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				libelle TEXT NOT NULL,
				facteur REAL NOT NULL,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, article_id, libelle)
			);
			CREATE INDEX IF NOT EXISTS idx_vpu_article ON vp_unites(article_id);
		" );
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	public static function pourArticle( $articleId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM vp_unites WHERE pack=? AND article_id=? ORDER BY facteur', array( self::pack(), (int) $articleId ) )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_unites WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	/** @return array{bool, string, int|null} */
	public static function creer( $articleId, $libelle, $facteur ) {
		self::ensure();
		$libelle = trim( (string) $libelle );
		$facteur = fkc_nombre( $facteur );
		if ( '' === $libelle ) { return array( false, 'Le libellé de l\'unité (« Carton de 12 »…) est obligatoire.', null ); }
		if ( $facteur <= 0 ) { return array( false, 'Le facteur de conversion doit être positif (combien d\'unités de base dans une unité de vente).', null ); }
		if ( abs( $facteur - 1.0 ) < 0.0000001 ) { return array( false, 'Un facteur de 1 ne convertit rien — inutile, l\'unité de base suffit.', null ); }
		try {
			FKC_DB::q( 'INSERT INTO vp_unites(pack,article_id,libelle,facteur) VALUES(?,?,?,?)', array( self::pack(), (int) $articleId, $libelle, $facteur ) );
		} catch ( \Throwable $e ) {
			return array( false, 'Cette unité existe déjà pour cet article.', null );
		}
		return array( true, 'Unité créée.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function supprimer( $id ) {
		self::ensure();
		FKC_DB::q( 'DELETE FROM vp_unites WHERE id=? AND pack=?', array( (int) $id, self::pack() ) );
		return array( true, 'Unité supprimée.' );
	}

	/**
	 * Résout une unité choisie pour un article : renvoie le facteur (1.0 si
	 * aucune unité alternative demandée) et son libellé. Vérifie que
	 * l'unité appartient bien à CET article — on ne peut pas emprunter le
	 * « Carton de 12 » d'un autre produit.
	 * @return array{bool, string, float, string} ( ok, message d'erreur, facteur, libellé )
	 */
	public static function resoudre( $articleId, $uniteId, $libeliteBase ) {
		if ( ! $uniteId ) { return array( true, '', 1.0, $libeliteBase ); }
		self::ensure();
		$u = self::find( $uniteId );
		if ( ! $u || (int) $u['article_id'] !== (int) $articleId ) {
			return array( false, 'Cette unité de vente ne correspond pas à l\'article choisi.', 1.0, $libeliteBase );
		}
		return array( true, '', (float) $u['facteur'], $u['libelle'] );
	}
}
