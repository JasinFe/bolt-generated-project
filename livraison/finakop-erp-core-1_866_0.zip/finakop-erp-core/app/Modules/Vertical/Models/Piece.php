<?php
/**
 * Moteur vertical générique — PIÈCE (document facturable d'un dossier).
 *
 * Une pièce (facture de réparation, frais de scolarité, quittance de loyer,
 * recette journalière, subvention…) suit le processus générique
 * « {pack}_validation_piece » : brouillon → soumise → validée → comptabilisée
 * automatiquement par l'événement déclaré dans le manifest pour son type.
 * Le handler d'effet « vp.piece » synchronise le statut local et rattache
 * l'écriture générée (même mécanique que le pack BTP).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpPiece {

	public static function statuts() {
		return array(
			'brouillon' => 'Brouillon', 'soumise' => 'Soumise', 'validee' => 'Validée',
			'comptabilisee' => 'Comptabilisée', 'rejetee' => 'Rejetée',
		);
	}

	public static function find( $id ) {
		FKC_VpDossier::ensure();
		$r = FKC_DB::q(
			'SELECT p.*, d.pack, d.code AS dossier_code, d.libelle AS dossier_libelle, d.tiers_nom, d.division_id
			 FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id WHERE p.id=?',
			array( (int) $id )
		)->fetch();
		return $r ?: null;
	}

	public static function duDossier( $dossierId ) {
		FKC_VpDossier::ensure();
		return FKC_DB::q( 'SELECT * FROM vp_pieces WHERE dossier_id=? ORDER BY id DESC', array( (int) $dossierId ) )->fetchAll();
	}

	/** Pièces récentes du pack courant (en attente en tête). */
	public static function recentes( $limit = 100 ) {
		FKC_VpDossier::ensure();
		return FKC_DB::q(
			"SELECT p.*, d.code AS dossier_code, d.libelle AS dossier_libelle
			 FROM vp_pieces p JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE d.pack=?
			 ORDER BY p.statut IN ('soumise','brouillon') DESC, p.date_piece DESC, p.id DESC LIMIT " . (int) $limit,
			array( FKC_VpDossier::pack() )
		)->fetchAll();
	}

	/** Montants dérivés : HT, TVA, TTC. */
	public static function montants( array $p ) {
		$ht  = round( (float) $p['montant_ht'], 2 );
		$tva = round( $ht * (float) $p['tva_pct'] / 100, 2 );
		return array( 'ht' => $ht, 'tva' => $tva, 'ttc' => round( $ht + $tva, 2 ) );
	}

	/**
	 * Crée une pièce en brouillon et démarre le processus de validation du pack.
	 * @param array $cfg bloc « vertical » du manifest.
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null id )
	 */
	/** Le schéma d'une pièce comporte-t-il une ligne de TVA (base ou conditionnelle) ? */
	public static function schemaPorteTva( $schema ) {
		$lignes = (array) ( $schema['lignes'] ?? array() );
		foreach ( (array) ( $schema['conditionnel'] ?? array() ) as $b ) { $lignes = array_merge( $lignes, (array) ( $b['lignes'] ?? array() ) ); }
		foreach ( $lignes as $l ) {
			if ( 'tva' === (string) ( $l['montant'] ?? '' ) || 0 === strpos( (string) ( $l['compte'] ?? '' ), '443' ) ) { return true; }
		}
		return false;
	}

	public static function create( $dossierId, array $d, array $cfg ) {
		FKC_VpDossier::ensure();
		$dos = FKC_VpDossier::find( $dossierId );
		if ( ! $dos ) { return array( false, 'Dossier introuvable.', null ); }
		if ( 'clos' === $dos['statut'] ) { return array( false, 'Dossier clos : aucune pièce ne peut être créée.', null ); }
		$types = (array) ( $cfg['pieces'] ?? array() );
		$type  = (string) ( $d['type'] ?? '' );
		if ( ! isset( $types[ $type ] ) ) { $type = (string) array_key_first( $types ); }
		if ( '' === $type ) { return array( false, 'Aucun type de pièce déclaré par le pack.', null ); }
		/*
		 * 1.866.0 — « 100 000 » saisi dans le montant d'une note d'honoraires,
		 * d'une facture de réparation ou d'une quittance était lu 100 :
		 * (float) s'arrête à la première espace. Toutes les pièces de tous
		 * les packs passaient par là.
		 */
		$ht = function_exists( 'fkc_nombre' ) ? (float) fkc_nombre( $d['montant_ht'] ?? 0 ) : (float) ( $d['montant_ht'] ?? 0 );
		/*
		 * 1.859.0 — pièce délivrant un article du stock (type « 'stock' => true »).
		 * Le montant se déduit du prix de vente s'il n'est pas saisi ; la
		 * disponibilité est contrôlée dès la saisie, la sortie se fait à la
		 * comptabilisation (voir le gestionnaire d'effet plus bas).
		 */
		$articleId = 0; $qteArt = 0.0;
		if ( ! empty( $types[ $type ]['stock'] ) && ! empty( $d['article_id'] ) && class_exists( 'FKC_VpStock' ) ) {
			$art = FKC_VpStock::article( (int) $d['article_id'] );
			$qteArt = (float) str_replace( ',', '.', (string) ( $d['qte_article'] ?? 1 ) );
			if ( ! $art ) { return array( false, 'Article introuvable.', null ); }
			if ( $qteArt <= 0 ) { return array( false, 'La quantité de l\'article doit être positive.', null ); }
			list( $okS, $msgS ) = FKC_VpStock::controlerSortie( $art, $qteArt );
			if ( ! $okS ) { return array( false, $msgS, null ); }
			$articleId = (int) $art['id'];
			if ( $ht <= 0 ) { $ht = round( $qteArt * (float) $art['prix_vente'], 2 ); }
			if ( '' === trim( (string) ( $d['libelle'] ?? '' ) ) ) { $d['libelle'] = $art['libelle'] . ' × ' . rtrim( rtrim( number_format( $qteArt, 2, '.', '' ), '0' ), '.' ); }
		}
		if ( $ht <= 0 ) { return array( false, 'Le montant HT doit être positif.', null ); }

		/*
		 * UNE REPRISE DE PROVISION EXIGE SON MOTIF (1.722.0).
		 *
		 * `FKC_Provision::reprendre()` refuse une reprise sans motif — le seul
		 * refus dur de tout le moteur du fait économique, et il est justifié :
		 * une reprise améliore le résultat sans le moindre mouvement de
		 * trésorerie, et c'est le premier point qu'un contrôle regarde.
		 *
		 * Or le libellé d'une pièce est FACULTATIF : laissé vide, il se
		 * remplit tout seul avec « Reprise de provision (PSAP) n°3 ». La
		 * pièce se serait donc comptabilisée pendant que le registre, lui,
		 * aurait refusé l'écriture — écriture passée, provision restée
		 * ouverte, et personne pour le voir. On refuse ICI, à la saisie, là
		 * où l'utilisateur peut encore répondre.
		 *
		 * Le contrôle porte sur le FAIT déclaré par le schéma, jamais sur le
		 * nom du type de pièce : un autre pack qui déclarera demain sa propre
		 * reprise sera tenu par la même règle sans écrire une ligne.
		 */
		$evtType = (string) ( $types[ $type ]['evenement'] ?? '' );
		if ( $evtType && class_exists( 'FKC_Posting' ) ) {
			$sch = FKC_Posting::schema( $evtType );
			$fait = strtoupper( (string) ( $sch['fait'] ?? '' ) );
			if ( 'REPRISE_PROVISION' === $fait && '' === trim( (string) ( $d['libelle'] ?? '' ) ) ) {
				return array( false, 'Une reprise de provision doit porter son motif : indiquez-le dans le libellé de la pièce.', null );
			}
		}

		$numero = 1 + (int) FKC_DB::q( 'SELECT COALESCE(MAX(numero),0) FROM vp_pieces WHERE dossier_id=? AND type=?', array( (int) $dossierId, $type ) )->fetchColumn();
		/*
		 * TVA par défaut de la pièce (COM-001) — résolue par nature de pièce,
		 * paramétrable écran Fiscalité, plutôt que le 'tva' figé du manifest.
		 * La saisie manuelle ($d['tva_pct']) garde priorité absolue : c'est
		 * la valeur que l'utilisateur voit et confirme à l'écran.
		 */
		$repliType = (float) ( $types[ $type ]['tva'] ?? 0 );
		$tvaDefaut = ( class_exists( 'FKC_CategorieFiscale' ) )
			? FKC_CategorieFiscale::tauxNatureDossier( FKC_VpDossier::pack(), $type, $repliType )
			: $repliType;
		$tvaSaisie = isset( $d['tva_pct'] ) && '' !== $d['tva_pct']
			? max( 0, min( 25, function_exists( 'fkc_nombre' ) ? (float) fkc_nombre( $d['tva_pct'] ) : (float) $d['tva_pct'] ) )
			: $tvaDefaut;
		/*
		 * 1.866.0 — UNE PIÈCE SANS LIGNE DE TVA NE PORTE PAS DE TVA. Les débours
		 * refacturés (cabinets, avocats) se comptabilisent au HT, sans TVA : si
		 * l'utilisateur laissait 18 % sur la pièce, elle affichait 118 000 à
		 * payer quand l'écriture n'en constatait que 100 000. Le taux suit le
		 * schéma d'écriture de la pièce.
		 */
		if ( $evtType && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evtType ) && ! self::schemaPorteTva( FKC_Posting::schema( $evtType ) ) ) {
			$tvaSaisie = 0.0;
		}
		FKC_DB::q(
			'INSERT INTO vp_pieces(dossier_id,type,numero,date_piece,libelle,montant_ht,tva_pct,statut,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
			array(
				(int) $dossierId, $type, $numero,
				(string) ( $d['date_piece'] ?? '' ) ?: date( 'Y-m-d' ),
				trim( (string) ( $d['libelle'] ?? '' ) ) ?: ( ( $types[ $type ]['label'] ?? ucfirst( $type ) ) . ' n°' . $numero ),
				$ht,
				$tvaSaisie,
				'brouillon',
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
			)
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		if ( $articleId > 0 ) { FKC_DB::q( 'UPDATE vp_pieces SET article_id=?, qte_article=? WHERE id=?', array( $articleId, $qteArt, $id ) ); }
		/*
		 * 1.860.0 — LE MOYEN D'ENCAISSEMENT D'UNE RECETTE. Les schémas de recette
		 * (restaurant, maquis, bar, boulangerie, loisirs…) débitent « la
		 * trésorerie » par rôle, mais la pièce ne disait jamais comment elle
		 * avait été payée : tout tombait en caisse, et la recette Wave ou carte
		 * du jour se retrouvait dans le tiroir — rapprochement faux par
		 * construction.
		 */
		$moyen = class_exists( 'FKC_MoyenPaiement' ) ? FKC_MoyenPaiement::normaliser( (string) ( $d['moyen'] ?? '' ) ) : '';
		if ( '' !== $moyen ) { FKC_DB::q( 'UPDATE vp_pieces SET moyen=? WHERE id=?', array( $moyen, $id ) ); }

		$p   = self::find( $id );
		$wf  = FKC_VpDossier::pack() . '_validation_piece';
		$wid = FKC_WorkflowEngine::start( $wf, 'vp.piece', $id, self::contexte( $p, $cfg ) );
		if ( $wid ) { FKC_DB::q( 'UPDATE vp_pieces SET wf_instance_id=? WHERE id=?', array( $wid, $id ) ); }
		return array( true, ( $types[ $type ]['label'] ?? 'Pièce' ) . " n°{$numero} créée (brouillon). Soumettez-la pour validation.", $id );
	}

	/** Le schéma de ce type de pièce débite-t-il la trésorerie (recette encaissée) ? */
	public static function encaisse( array $cfg, $type ) {
		$evt = (string) ( $cfg['pieces'][ $type ]['evenement'] ?? '' );
		if ( '' === $evt || ! class_exists( 'FKC_Posting' ) || ! FKC_Posting::has( $evt ) ) { return false; }
		$sch = (array) FKC_Posting::schema( $evt );
		$lignes = (array) ( $sch['lignes'] ?? array() );
		$cond = (array) ( $sch['conditionnel'] ?? array() );
		if ( isset( $cond['lignes'] ) ) { $cond = array( $cond ); }
		foreach ( $cond as $b ) { $lignes = array_merge( $lignes, (array) ( $b['lignes'] ?? array() ) ); }
		foreach ( $lignes as $l ) {
			if ( 'TRESORERIE' === strtoupper( (string) ( $l['role'] ?? '' ) ) && 'D' === strtoupper( (string) ( $l['sens'] ?? '' ) ) ) { return true; }
		}
		return false;
	}

	/**
	 * Sortie de stock d'une pièce comptabilisée qui délivre un article
	 * (1.859.0) : mouvement au CUMP + coût des ventes (D 603 / C 31).
	 * Idempotent : une pièce ne sort son article qu'une fois.
	 * @return int|null mouvement créé
	 */
	public static function sortirArticle( $pieceId ) {
		$p = self::find( (int) $pieceId );
		if ( ! $p || empty( $p['article_id'] ) || ! empty( $p['stock_mouvement_id'] ) || ! class_exists( 'FKC_VpStock' ) ) { return null; }
		$a = FKC_VpStock::article( (int) $p['article_id'] );
		if ( ! $a ) { return null; }
		$cump = (float) $a['cump'];
		list( $ok, , $movId ) = FKC_VpStock::sortirStockSansEcriture( (int) $a['id'], (float) $p['qte_article'], 'Pièce ' . $p['type'] . ' n°' . $p['numero'], (int) $p['dossier_id'] );
		if ( ! $ok || ! $movId ) { return null; }
		FKC_DB::q( 'UPDATE vp_pieces SET stock_mouvement_id=? WHERE id=?', array( (int) $movId, (int) $p['id'] ) );
		$cfg = class_exists( 'FKC_Packs' ) ? (array) FKC_Packs::verticalConfig() : array();
		FKC_VpStock::constaterCout( $cfg, $a, round( $cump * (float) $p['qte_article'], 2 ), 'sortie', $movId );
		return (int) $movId;
	}

	/** @var array hooks d'enrichissement du contexte : callable( array &$ctx, array $piece, array $dossier ) */
	protected static $ctxHooks = array();

	/** Un pack peut enrichir le contexte comptable de ses pièces (ex. courtage : commission/net). */
	public static function onContexte( $callable ) {
		if ( is_callable( $callable ) ) { self::$ctxHooks[] = $callable; }
	}

	/** Contexte transmis au workflow puis au moteur d'événements comptables. */
	public static function contexte( array $p, array $cfg ) {
		$m = self::montants( $p );
		FKC_VpDossier::ensureDivision( (int) $p['dossier_id'] );
		$dos   = FKC_VpDossier::find( (int) $p['dossier_id'] );
		$types = (array) ( $cfg['pieces'] ?? array() );
		$tdef  = $types[ $p['type'] ] ?? array();
		$ctx = array_merge( $m, array(
			'numero'      => (int) $p['numero'],
			'piece_id'    => (int) $p['id'],
			'piece_type'  => (string) $p['type'],
			'piece_label' => (string) ( $tdef['label'] ?? ucfirst( $p['type'] ) ),
			'evenement'   => (string) ( $tdef['evenement'] ?? '' ), // interpolé par l'effet posting du workflow
			'dossier'     => $dos ? ( $dos['code'] . ' ' . $dos['libelle'] ) : '',
			'tiers'       => $dos['tiers_nom'] ?? '',
			'date'        => $p['date_piece'],
			'piece'       => ( $dos['code'] ?? 'DOS' ) . '-' . strtoupper( substr( $p['type'], 0, 3 ) ) . '-' . str_pad( (string) $p['numero'], 3, '0', STR_PAD_LEFT ),
			'reference'   => 'vp.piece#' . (int) $p['id'],
			'division_id' => $dos['division_id'] ?? null,
			'montant'     => $m['ttc'],
			/*
			 * LE MOTIF, ET LA PROVISION QU'ON REPREND (1.722.0).
			 *
			 * Le schéma de reprise interpole « {motif} » sur sa ligne de
			 * produit : sans cette clé, la contrepartie d'une reprise
			 * s'inscrivait au journal sans un mot de justification.
			 *
			 * `provision_id` est ce qui permet au registre de RAPPROCHER la
			 * reprise de sa dotation, donc de solder la provision et de
			 * mesurer l'écart d'estimation. On le résout depuis le dossier —
			 * mais SEULEMENT s'il n'y a aucune ambiguïté : une provision
			 * ouverte et une seule sur ce dossier. Deux provisions, ou zéro,
			 * et l'on ne rattache rien plutôt que de choisir à la place du
			 * comptable. L'écriture passe, le registre reste ouvert, et
			 * l'écran des faits économiques le montre — une vue incomplète
			 * vaut mieux qu'une vue fausse (même arbitrage qu'en 1.624.0 sur
			 * deux séjours en cours dans une même chambre).
			 */
			'motif'       => (string) ( $p['libelle'] ?? '' ),
		) );
		if ( ! empty( $p['moyen'] ) ) { $ctx['moyen'] = (string) $p['moyen']; }
		/*
		 * 1.857.0 — LE CLIENT DU DOSSIER PORTE LA CRÉANCE. Une pièce facturée
		 * (facture de gros, commission…) débitait le 411 général : le compte
		 * du revendeur restait vierge, son encours à zéro, et le recouvrement
		 * ne savait pas qui relancer. Les lignes marquées « tiers » du schéma
		 * reçoivent désormais le client rattaché au dossier.
		 */
		if ( ! empty( $dos['client_id'] ) && empty( $ctx['tiers_id'] ) ) {
			$ctx['tiers_type'] = 'client';
			$ctx['tiers_id']   = (int) $dos['client_id'];
		}
		/*
		 * 1.858.0 — LE COMPTE DU CLIENT, ET LA PART DE CHACUN.
		 *
		 * « {compte_client} » laisse un schéma imputer la créance sur le compte
		 * PROPRE du client — celui que l'écran Règlements crédite. Débiter un
		 * 411 collectif et encaisser sur 411100 laissait deux soldes opposés
		 * que rien ne rapprochait.
		 *
		 * « part_patient » / « part_assurance » : sans pack qui les répartit
		 * (tiers payant santé), tout revient au client — exactement le
		 * comportement d'avant pour un schéma qui les emploierait.
		 */
		if ( ! isset( $ctx['compte_client'] ) ) {
			$cliCpt = '';
			if ( ! empty( $dos['client_id'] ) && class_exists( 'FKC_Client' ) ) {
				$cli = FKC_Client::find( (int) $dos['client_id'] );
				$cliCpt = $cli ? (string) ( $cli['compte'] ?? '' ) : '';
			}
			$ctx['compte_client'] = '' !== $cliCpt ? $cliCpt : ( class_exists( 'FKC_PlanMetier' ) ? FKC_PlanMetier::COMPTE_CLIENT : '411100' );
		}
		$ctx['part_patient']   = $ctx['ttc'];
		$ctx['part_assurance'] = 0.0;
		if ( class_exists( 'FKC_Provision' ) && ! empty( $ctx['dossier'] ) ) {
			$candidates = array();
			foreach ( FKC_Provision::ouvertes() as $pv ) {
				if ( (string) $pv['objet'] === (string) $ctx['dossier'] && (float) $pv['solde'] > 0 ) {
					$candidates[] = (int) $pv['id'];
				}
			}
			if ( 1 === count( $candidates ) ) { $ctx['provision_id'] = $candidates[0]; }
		}
		// Champs personnalisés du dossier disponibles au posting (ex. compagnie, taux_commission).
		foreach ( (array) ( $dos['champs_arr'] ?? array() ) as $k => $v ) {
			if ( ! isset( $ctx[ $k ] ) ) { $ctx[ $k ] = $v; }
		}
		// Hooks des packs (enrichissement métier du contexte).
		foreach ( self::$ctxHooks as $h ) { $h( $ctx, $p, (array) $dos ); }
		return $ctx;
	}
}

/* ── Handler d'effet du workflow : synchronisation du statut de la pièce ───── */
if ( class_exists( 'FKC_WorkflowEngine' ) ) {
	FKC_WorkflowEngine::onEffet( 'vp.piece', function ( $effet, $instance, &$ctx ) {
		$pid = (int) ( $ctx['piece_id'] ?? $instance['ref_id'] ?? 0 );
		if ( ! $pid ) { return; }
		$statut  = (string) ( $effet['statut'] ?? '' );
		$statuts = FKC_VpPiece::statuts();
		if ( ! isset( $statuts[ $statut ] ) ) { return; }
		FKC_DB::q( 'UPDATE vp_pieces SET statut=? WHERE id=?', array( $statut, $pid ) );
		if ( 'comptabilisee' === $statut ) {
			FKC_DB::q( 'UPDATE vp_pieces SET ecriture_id=?, brouillon_id=? WHERE id=?', array(
				! empty( $ctx['ecriture_id'] ) ? (int) $ctx['ecriture_id'] : null,
				! empty( $ctx['brouillon_id'] ) ? (int) $ctx['brouillon_id'] : null,
				$pid,
			) );
			FKC_VpPiece::sortirArticle( $pid );
		}
	} );
}
