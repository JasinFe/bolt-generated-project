<?php
/**
 * Brique STOCK du moteur vertical (optionnelle, activée par le manifest via le
 * bloc « stock »). Pour les packs de commerce de détail : articles, entrées
 * (achats), sorties (ventes) et valorisation au Coût Unitaire Moyen Pondéré
 * (CUMP), avec écritures SYSCOHADA générées par le moteur d'événements.
 *
 * Le stock est cloisonné par pack (comme les dossiers) : chaque commerce ne
 * voit que ses propres articles. Une vente peut être rattachée à un dossier
 * (point de vente / rayon) pour l'analytique.
 *
 * Bloc manifest attendu :
 *   'stock' => array(
 *     'categories' => array( 'Cat A', 'Cat B', … ),   // facultatif
 *     'evt_entree' => 'commerce_entree_stock',         // événement d'achat
 *     'evt_sortie' => 'commerce_vente',                // événement de vente
 *     'tva'        => 18,                              // TVA des ventes
 *   )
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpStock {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_articles(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				reference TEXT NOT NULL,
				libelle TEXT NOT NULL,
				categorie TEXT,
				categorie_id INTEGER,
				marque_id INTEGER,
				marque TEXT,
				modele TEXT,
				unite TEXT DEFAULT 'u',
				prix_achat REAL NOT NULL DEFAULT 0,
				prix_vente REAL NOT NULL DEFAULT 0,
				tva_pct REAL NOT NULL DEFAULT 18,
				categorie_fiscale_id INTEGER,
				qte_stock REAL NOT NULL DEFAULT 0,
				cump REAL NOT NULL DEFAULT 0,
				seuil_alerte REAL NOT NULL DEFAULT 0,
				capacite_max REAL,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, reference)
			);
			CREATE INDEX IF NOT EXISTS idx_vpa_pack ON vp_articles(pack, actif);
			CREATE TABLE IF NOT EXISTS vp_mouvements(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				sens TEXT NOT NULL,
				qte REAL NOT NULL,
				pu REAL NOT NULL DEFAULT 0,
				montant REAL NOT NULL DEFAULT 0,
				dossier_id INTEGER,
				motif TEXT,
				ecriture_id INTEGER, brouillon_id INTEGER,
				moyen TEXT,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				FOREIGN KEY(article_id) REFERENCES vp_articles(id)
			);
			CREATE INDEX IF NOT EXISTS idx_vpm_pack ON vp_mouvements(pack, created_at);
			CREATE INDEX IF NOT EXISTS idx_vpm_article ON vp_mouvements(article_id);
		" );
		// Migration douce : les installations existantes ont vp_articles sans
		// cette colonne (CREATE TABLE IF NOT EXISTS ne la rajoute pas).
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN categorie_fiscale_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// Idem (COM-002) : traçabilité de la facture née d'une vente à crédit.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN facture_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// COM-017 : lien vers le mouvement de vente d'origine, pour les retours.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN origine_mouvement_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// 1.606.0 : moyen de règlement d'une vente au comptant, code canonique
		// du référentiel FKC_MoyenPaiement. C'est lui qui commande le compte de
		// trésorerie, et il rend le rapprochement possible a posteriori.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN moyen TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		/*
		 * 1.622.0 — « POURQUOI LE STOCK A-T-IL DIMINUÉ ? »
		 *
		 * Une livraison de commande sortait le stock en n'inscrivant que le
		 * libellé « Livraison N° » dans `motif`. Une chaîne de caractères
		 * n'est pas un lien : on ne remonte pas de la marchandise partie à la
		 * commande qui l'explique, et surtout on ne peut pas savoir ce qui a
		 * été livré et jamais facturé. Ces deux colonnes rendent le lien
		 * matériel, et la facturation s'en sert pour marquer précisément les
		 * mouvements qu'elle solde.
		 */
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN commande_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN commande_ligne_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// COM-009 : capacité maximale (cuve station-service, silo…) — générique,
		// mais c'est ce manque précis qui a motivé son ajout.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN capacite_max REAL' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// 1.865.0 — extension de garantie vendue (mois couverts, produit étalé) et son registre.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN extension_mois INTEGER NOT NULL DEFAULT 0' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_extensions(
				id INTEGER PRIMARY KEY AUTOINCREMENT, pack TEXT NOT NULL,
				mouvement_id INTEGER, article_id INTEGER NOT NULL, client_nom TEXT DEFAULT '',
				montant_ht REAL NOT NULL, compte TEXT NOT NULL, debut TEXT NOT NULL, fin TEXT NOT NULL, annule INTEGER NOT NULL DEFAULT 0,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS vp_pca(
				id INTEGER PRIMARY KEY AUTOINCREMENT, pack TEXT NOT NULL, date TEXT NOT NULL, compte TEXT NOT NULL,
				solde REAL NOT NULL, ajustement REAL NOT NULL, ecriture_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
		" );
		// 1.864.0 — prix affiché TTC (carburant, rayon de proximité) : la TVA est incluse, pas ajoutée.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN prix_ttc INTEGER NOT NULL DEFAULT 0' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// COM-010 : article à suivi individuel (IMEI, numéro de série).
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN serialise INTEGER NOT NULL DEFAULT 0' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// COM-021 : variantes (Mode) — un article peut être rattaché à un
		// article « parent » (le modèle) avec sa propre taille/couleur.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN variante_parent_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN variante_taille TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN variante_couleur TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// BAZ-001 : rattachement au catalogue libre (FKC_VpCategorie). Posée
		// ici AUSSI, et pas seulement par FKC_VpCategorie::ensure(), pour que
		// la colonne existe même sur un pack qui n'active pas le catalogue.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN categorie_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		// ELM-004 : marque (référentiel) et modèle (référence du fabricant).
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN marque_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN marque TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN modele TEXT' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		/*
		 * 1.857.0 — COÛT DES VENTES. Le coût CUMP d'une sortie est mémorisé
		 * sur le mouvement : c'est lui qu'un retour doit reprendre (et non le
		 * CUMP du jour du retour), et l'écriture qui le constate y est liée.
		 */
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN cout REAL' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN cout_ecriture_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/* ── Articles ────────────────────────────────────────────────────────── */

	public static function articles( $inclureInactifs = false ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( ! $inclureInactifs ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_articles {$w} ORDER BY libelle ASC", $p )->fetchAll();
	}

	public static function article( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_articles WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	public static function nextRef() {
		self::ensure();
		$n = 1 + (int) FKC_DB::q( 'SELECT COUNT(*) FROM vp_articles WHERE pack=?', array( self::pack() ) )->fetchColumn();
		return sprintf( 'ART-%04d', $n );
	}

	/**
	 * COM-021 — Validation d'une variante (Mode) : le parent doit exister,
	 * ne doit pas être lui-même une variante (pas d'imbrication — un modèle
	 * a des déclinaisons, une déclinaison n'a pas de sous-déclinaisons), et
	 * la combinaison taille/couleur doit être unique parmi les variantes de
	 * ce même parent (sinon deux lignes indiscernables pour la même
	 * référence physique).
	 * @return array{bool, string}
	 */
	protected static function validerVariante( array $d, $excludeId = null ) {
		if ( empty( $d['variante_parent_id'] ) ) { return array( true, '' ); }
		$parent = self::article( (int) $d['variante_parent_id'] );
		if ( ! $parent ) { return array( false, 'L\'article parent choisi est introuvable.' ); }
		if ( ! empty( $parent['variante_parent_id'] ) ) {
			return array( false, 'Impossible de rattacher une variante à un article qui est lui-même une variante — rattachez-la directement au modèle d\'origine.' );
		}
		/*
		 * La capacité « Variantes » du MODÈLE commande vraiment quelque chose :
		 * sans elle, on ne lui rattache pas de déclinaison. Le contrôle porte
		 * sur le parent et non sur la variante, parce que c'est le modèle qui
		 * décide s'il se décline — une déclinaison ne se décide pas elle-même.
		 *
		 * Le refus explique où cocher : découvrir qu'une case existait ailleurs
		 * est plus pénible que de se l'entendre dire.
		 */
		if ( class_exists( 'FKC_VpCapacite' ) && ! FKC_VpCapacite::actif( $parent, 'variante' ) ) {
			return array( false, '« ' . $parent['libelle'] . ' » n\'est pas déclaré comme modèle à variantes. Activez la capacité « Variantes » sur sa fiche avant de lui rattacher des déclinaisons.' );
		}
		$taille  = trim( (string) ( $d['variante_taille'] ?? '' ) );
		$couleur = trim( (string) ( $d['variante_couleur'] ?? '' ) );
		if ( '' === $taille && '' === $couleur ) {
			return array( false, 'Une variante doit préciser au moins une taille ou une couleur qui la distingue du modèle.' );
		}
		$w = 'WHERE pack=? AND variante_parent_id=? AND COALESCE(variante_taille,"")=? AND COALESCE(variante_couleur,"")=?';
		$p = array( self::pack(), (int) $parent['id'], $taille, $couleur );
		if ( $excludeId ) { $w .= ' AND id<>?'; $p[] = (int) $excludeId; }
		$doublon = FKC_DB::q( "SELECT libelle FROM vp_articles {$w}", $p )->fetch();
		if ( $doublon ) {
			return array( false, 'Une variante ' . ( $taille ? 'taille ' . $taille . ' ' : '' ) . ( $couleur ? 'couleur ' . $couleur . ' ' : '' ) . 'existe déjà pour ce modèle (' . $doublon['libelle'] . ').' );
		}
		return array( true, '' );
	}

	/**
	 * BAZ-001 — Rattachement d'un article au CATALOGUE.
	 *
	 * L'article se rattache désormais à une catégorie par son identifiant
	 * (`categorie_id`). La colonne texte `categorie` continue d'être
	 * alimentée avec le libellé : sept packs de commerce, les cockpits
	 * (caParCategorie), l'analytique et le pont Inventaire la lisent encore.
	 * Ce n'est pas une redondance de confort — c'est ce qui permet d'ajouter
	 * le catalogue libre sans toucher une ligne de tout ce qui existait.
	 *
	 * Si le formulaire ne renvoie qu'un texte libre (pack sans catalogue
	 * activé, import, API), on le conserve tel quel : rien ne casse.
	 *
	 * @return array{0:int|null,1:string|null} ( categorie_id, libellé )
	 */
	protected static function resoudreCategorie( array $d ) {
		$texte = trim( (string) ( $d['categorie'] ?? '' ) );
		$id    = ! empty( $d['categorie_id'] ) ? (int) $d['categorie_id'] : null;
		if ( $id && class_exists( 'FKC_VpCategorie' ) ) {
			$c = FKC_VpCategorie::find( $id );
			if ( $c ) { return array( (int) $c['id'], (string) $c['libelle'] ); }
			$id = null; // catégorie disparue : on ne rattache pas à un identifiant mort.
		}
		return array( null, $texte ?: null );
	}

	/**
	 * ELM-004 — Rattachement d'un article à sa MARQUE.
	 *
	 * Même principe que la catégorie : l'article porte l'identifiant ET une
	 * copie du libellé. Le libellé sert aux états et à la section analytique
	 * MARQUE ; l'identifiant sert au filtrage et garantit qu'un rebaptême se
	 * propage.
	 *
	 * Un libellé libre qui ne correspond à aucune marque connue est conservé
	 * tel quel sans en créer une : la moindre faute de frappe dans un import
	 * polluerait sinon le référentiel de marques fantômes.
	 *
	 * @return array{0:int|null,1:string|null}
	 */
	protected static function resoudreMarque( array $d ) {
		if ( ! class_exists( 'FKC_VpMarque' ) ) {
			return array( null, trim( (string) ( $d['marque'] ?? '' ) ) ?: null );
		}
		return FKC_VpMarque::resoudre( $d );
	}

	/** Variantes d'un article modèle, dans un ordre stable (taille puis couleur). */
	public static function variantes( $parentId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM vp_articles WHERE pack=? AND variante_parent_id=? ORDER BY variante_taille, variante_couleur',
			array( self::pack(), (int) $parentId ) )->fetchAll();
	}

	/** @return array{bool, string, int|null} ( bool ok, string message, int|null id ) */
	public static function createArticle( array $d ) {
		self::ensure();
		$lib = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $lib ) { return array( false, 'Le libellé de l\'article est obligatoire.', null ); }
		list( $okVar, $msgVar ) = self::validerVariante( $d );
		if ( ! $okVar ) { return array( false, $msgVar, null ); }
		$ref = trim( (string) ( $d['reference'] ?? '' ) ) ?: self::nextRef();
		list( $catId, $catLibelle ) = self::resoudreCategorie( $d );
		list( $marqueId, $marqueLib ) = self::resoudreMarque( $d );
		try {
			FKC_DB::q(
				'INSERT INTO vp_articles(pack,reference,libelle,categorie,categorie_id,marque_id,marque,modele,unite,prix_achat,prix_vente,tva_pct,categorie_fiscale_id,qte_stock,cump,seuil_alerte,capacite_max,serialise,variante_parent_id,variante_taille,variante_couleur,prix_ttc)
				 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
				array(
					self::pack(), $ref, $lib,
					$catLibelle, $catId,
					$marqueId, $marqueLib, trim( (string) ( $d['modele'] ?? '' ) ) ?: null,
					trim( (string) ( $d['unite'] ?? 'u' ) ) ?: 'u',
					fkc_nombre( $d['prix_achat'] ?? 0 ),
					fkc_nombre( $d['prix_vente'] ?? 0 ),
					max( 0, min( 25, fkc_nombre( $d['tva_pct'] ?? 18, 18 ) ) ),
					( ! empty( $d['categorie_fiscale_id'] ) ? (int) $d['categorie_fiscale_id'] : null ),
					0, fkc_nombre( $d['prix_achat'] ?? 0 ),
					fkc_nombre( $d['seuil_alerte'] ?? 0 ),
					( isset( $d['capacite_max'] ) && '' !== $d['capacite_max'] ? max( 0, fkc_nombre( $d['capacite_max'] ) ) : null ),
					! empty( $d['serialise'] ) ? 1 : 0,
					! empty( $d['variante_parent_id'] ) ? (int) $d['variante_parent_id'] : null,
					trim( (string) ( $d['variante_taille'] ?? '' ) ) ?: null,
					trim( (string) ( $d['variante_couleur'] ?? '' ) ) ?: null,
					( array_key_exists( 'prix_ttc', $d ) || array_key_exists( 'prix_ttc_present', $d ) ) ? ( ! empty( $d['prix_ttc'] ) ? 1 : 0 ) : ( self::prixTtcParDefaut() ? 1 : 0 ),
				)
			);
			$nid = (int) FKC_DB::conn()->lastInsertId();
			if ( ! empty( $d['extension_mois'] ) ) { FKC_DB::q( 'UPDATE vp_articles SET extension_mois=? WHERE id=?', array( max( 0, min( 120, (int) $d['extension_mois'] ) ), $nid ) ); }
			return array( true, 'Article créé.', $nid );
		} catch ( \Throwable $e ) {
			return array( false, 'Référence déjà utilisée pour ce commerce.', null );
		}
		return array( true, 'Article créé.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function updateArticle( $id, array $d ) {
		self::ensure();
		if ( ! empty( $d['variante_parent_id'] ) && (int) $d['variante_parent_id'] === (int) $id ) {
			return array( false, 'Un article ne peut pas être sa propre variante.' );
		}
		if ( FKC_DB::q( 'SELECT 1 FROM vp_articles WHERE pack=? AND variante_parent_id=?', array( self::pack(), (int) $id ) )->fetch() && ! empty( $d['variante_parent_id'] ) ) {
			return array( false, 'Cet article a déjà des variantes qui lui sont rattachées — il ne peut pas devenir lui-même une variante.' );
		}
		list( $okVar, $msgVar ) = self::validerVariante( $d, (int) $id );
		if ( ! $okVar ) { return array( false, $msgVar ); }
		/*
		 * 1.864.0 — PASSER UN ARTICLE EN SUIVI PAR NUMÉRO DE SÉRIE alors qu'il
		 * a déjà du stock sans numéros rendait ces unités invendables (la
		 * vente exige un numéro « en stock » par unité) et leurs numéros
		 * inconnus. On refuse tant que le stock n'est pas à zéro.
		 */
		$avant = self::article( $id );
		if ( $avant && ! empty( $d['serialise'] ) && empty( $avant['serialise'] ) && (float) $avant['qte_stock'] > 0.00001 ) {
			return array( false, 'Cet article a ' . fkc_money( $avant['qte_stock'] ) . ' ' . $avant['unite'] . ' en stock sans numéro de série : écoulez ou sortez ce stock avant d\'activer le suivi par série, puis réceptionnez avec les numéros.' );
		}
		list( $catId, $catLibelle ) = self::resoudreCategorie( $d );
		list( $marqueId, $marqueLib ) = self::resoudreMarque( $d );
		FKC_DB::q(
			'UPDATE vp_articles SET libelle=?, categorie=?, categorie_id=?, marque_id=?, marque=?, modele=?, unite=?, prix_achat=?, prix_vente=?, tva_pct=?, categorie_fiscale_id=?, seuil_alerte=?, capacite_max=?, serialise=?, variante_parent_id=?, variante_taille=?, variante_couleur=?, actif=? WHERE id=? AND pack=?',
			array(
				trim( (string) ( $d['libelle'] ?? '' ) ),
				$catLibelle, $catId,
				$marqueId, $marqueLib, trim( (string) ( $d['modele'] ?? '' ) ) ?: null,
				trim( (string) ( $d['unite'] ?? 'u' ) ) ?: 'u',
				fkc_nombre( $d['prix_achat'] ?? 0 ),
				fkc_nombre( $d['prix_vente'] ?? 0 ),
				max( 0, min( 25, fkc_nombre( $d['tva_pct'] ?? 18, 18 ) ) ),
				( ! empty( $d['categorie_fiscale_id'] ) ? (int) $d['categorie_fiscale_id'] : null ),
				fkc_nombre( $d['seuil_alerte'] ?? 0 ),
				( isset( $d['capacite_max'] ) && '' !== $d['capacite_max'] ? max( 0, fkc_nombre( $d['capacite_max'] ) ) : null ),
				! empty( $d['serialise'] ) ? 1 : 0,
				! empty( $d['variante_parent_id'] ) ? (int) $d['variante_parent_id'] : null,
				trim( (string) ( $d['variante_taille'] ?? '' ) ) ?: null,
				trim( (string) ( $d['variante_couleur'] ?? '' ) ) ?: null,
				! empty( $d['actif'] ) ? 1 : 0,
				(int) $id, self::pack(),
			)
		);
		if ( array_key_exists( 'extension_mois', $d ) ) {
			FKC_DB::q( 'UPDATE vp_articles SET extension_mois=? WHERE id=? AND pack=?', array( max( 0, min( 120, (int) $d['extension_mois'] ) ), (int) $id, self::pack() ) );
		}
		if ( array_key_exists( 'prix_ttc', $d ) || array_key_exists( 'prix_ttc_present', $d ) ) {
			FKC_DB::q( 'UPDATE vp_articles SET prix_ttc=? WHERE id=? AND pack=?', array( ! empty( $d['prix_ttc'] ) ? 1 : 0, (int) $id, self::pack() ) );
		}
		return array( true, 'Article mis à jour.' );
	}

	/* ── Retrait d'un article ────────────────────────────────────────────── */

	/**
	 * Ce qui rattache l'article à l'histoire de l'entreprise.
	 *
	 * Calculé AVANT d'agir, et affiché : l'utilisateur doit savoir ce qu'il
	 * retire. Un article jamais utilisé peut disparaître sans conséquence ;
	 * un article qui a bougé appartient à la valorisation du stock et au
	 * grand livre, et l'effacer rendrait les deux incohérents.
	 *
	 * @return array{article:?array,supprimable:bool,raisons:array}
	 */
	public static function analyseSuppression( $id ) {
		self::ensure();
		$a = self::article( $id );
		if ( ! $a ) {
			return array( 'article' => null, 'supprimable' => false, 'raisons' => array( 'Article introuvable.' ) );
		}
		$raisons = array();

		$stock = (float) ( $a['qte_stock'] ?? 0 );
		if ( abs( $stock ) > 0.00001 ) {
			$raisons[] = 'Il reste ' . fkc_money( $stock ) . ' en stock. Sortez ou régularisez ce stock avant de retirer la fiche.';
		}

		try {
			$n = (int) FKC_DB::q( 'SELECT COUNT(*) FROM vp_mouvements WHERE article_id=?', array( (int) $a['id'] ) )->fetchColumn();
			if ( $n ) { $raisons[] = $n . ' mouvement(s) de stock enregistré(s).'; }
		} catch ( \Throwable $ex ) {
			fkc_log( 'VpStock::analyseSuppression ' . $ex->getMessage(), 'ERROR' );
		}

		return array( 'article' => $a, 'supprimable' => empty( $raisons ), 'raisons' => $raisons );
	}

	/**
	 * Retire un article : suppression réelle s'il n'a jamais servi, archivage
	 * sinon. L'appelant ne choisit pas — c'est l'histoire de l'article qui
	 * décide, et le message dit toujours ce qui s'est passé.
	 *
	 * @param bool $forcer Archiver directement, sans tenter la suppression.
	 * @return array{0:bool,1:string,2:string} ok, message, action ('supprime'|'archive'|'aucune')
	 */
	public static function supprimer( $id, $forcer = false ) {
		$an = self::analyseSuppression( $id );
		if ( ! $an['article'] ) { return array( false, 'Article introuvable.', 'aucune' ); }
		$id   = (int) $an['article']['id'];
		$lib  = (string) $an['article']['libelle'];
		$pack = self::pack();

		if ( ! $forcer && $an['supprimable'] ) {
			try {
				FKC_Tx::executer( function () use ( $id, $pack ) {
					FKC_DB::q( 'DELETE FROM vp_mouvements WHERE article_id=?', array( $id ) );
					// BAZ-002 : les caractéristiques saisies disparaissent avec
					// la fiche — sans quoi elles resteraient en base, rattachées
					// à un identifiant qu'un futur article pourrait réutiliser.
					if ( class_exists( 'FKC_VpAttribut' ) ) { FKC_VpAttribut::oublierArticle( $id ); }
					// ELM-005 : les associations disparaissent aussi, DANS LES
					// DEUX SENS — sinon l'article supprimé resterait proposé
					// comme accessoire d'un autre.
					if ( class_exists( 'FKC_VpArticleLie' ) ) { FKC_VpArticleLie::oublierArticle( $id ); }
					FKC_DB::q( 'DELETE FROM vp_articles WHERE id=? AND pack=?', array( $id, $pack ) );
				} );
			} catch ( \Throwable $ex ) {
				fkc_log( 'VpStock::supprimer ' . $ex->getMessage(), 'ERROR' );
				return array( false, 'Suppression impossible : aucune modification n\'a été enregistrée.', 'aucune' );
			}
			if ( class_exists( 'FKC_Security' ) ) {
				FKC_Security::audit( 'article_supprime', 'Pack ' . $pack . ' — « ' . $lib . ' » (jamais utilisé)' );
			}
			return array( true, 'Article « ' . $lib . ' » supprimé : il n\'avait jamais servi.', 'supprime' );
		}

		try {
			FKC_DB::q( 'UPDATE vp_articles SET actif=0 WHERE id=? AND pack=?', array( $id, $pack ) );
		} catch ( \Throwable $ex ) {
			fkc_log( 'VpStock::supprimer/archive ' . $ex->getMessage(), 'ERROR' );
			return array( false, 'Archivage impossible.', 'aucune' );
		}
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'article_archive', 'Pack ' . $pack . ' — « ' . $lib . ' » : ' . implode( ' ', $an['raisons'] ) );
		}
		$msg = 'Article « ' . $lib . ' » archivé plutôt que supprimé : il a une histoire qui doit rester lisible.';
		if ( $an['raisons'] ) { $msg .= ' (' . implode( ' ', $an['raisons'] ) . ')'; }
		return array( true, $msg, 'archive' );
	}

	/** Réactive un article archivé. */
	public static function restaurer( $id ) {
		self::ensure();
		try {
			FKC_DB::q( 'UPDATE vp_articles SET actif=1 WHERE id=? AND pack=?', array( (int) $id, self::pack() ) );
			return array( true, 'Article réactivé.' );
		} catch ( \Throwable $ex ) { return array( false, 'Réactivation impossible.' ); }
	}

	/* ── Mouvements valorisés ────────────────────────────────────────────── */

	/**
	 * Entrée en stock (achat). Met à jour le CUMP, comptabilise l'achat et
	 * inscrit la marchandise au registre des factures à recevoir.
	 *
	 * Chemin commun à sept packs (supérette, station-service, téléphonie,
	 * pharmacie, prêt-à-porter, cosmétiques, quincaillerie) : le corriger ici
	 * les corrige tous, sans dupliquer la logique dans chaque pack.
	 *
	 * @param int    $fournisseurId Fournisseur du référentiel comptable. Sans
	 *                              lui, la dette reste au collectif du pack et
	 *                              aucun règlement ne pourra s'y imputer.
	 * @return array{bool, string} ( ok, message )
	 */
	/**
	 * @param array|null $lot COM-060 — array( 'lot' => …, 'peremption' => … )
	 *                        pour un article suivi par lot. Passé en fin de
	 *                        signature : aucun appelant existant ne bouge.
	 */
	public static function entree( $articleId, $qte, $puAchat, array $cfg, $motif = '', $fournisseurId = null, $series = null, $uniteId = null, $lot = null, $depotId = null ) {
		self::ensure();
		$a = self::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.' ); }
		$qteSaisie = (float) $qte; $puSaisi = (float) $puAchat;
		if ( $qteSaisie <= 0 ) { return array( false, 'La quantité entrée doit être positive.' ); }

		/*
		 * COM-023 — Unités de vente multiples (Quincaillerie…) : le stock
		 * (qte, CUMP) reste TOUJOURS en unité de base. Une réception « 10
		 * cartons de 12 » se convertit ici en 120 pièces avant tout calcul —
		 * ni la valorisation, ni les mouvements n'ont jamais à connaître
		 * l'existence des cartons.
		 */
		$facteur = 1.0; $libelleUnite = $a['unite'];
		if ( $uniteId && class_exists( 'FKC_VpUnite' ) ) {
			list( $okU, $msgU, $facteur, $libelleUnite ) = FKC_VpUnite::resoudre( $articleId, $uniteId, $a['unite'] );
			if ( ! $okU ) { return array( false, $msgU ); }
		}
		$qte = round( $qteSaisie * $facteur, 6 );
		// 1.864.0 — toute unité ≠ 1 se convertit (un « demi-carton » de facteur 0,5 aussi).
		$pu  = abs( $facteur - 1.0 ) > 1e-9 ? round( $puSaisi / $facteur, 6 ) : $puSaisi;
		if ( abs( $facteur - 1.0 ) > 1e-9 ) {
			$motif = trim( ( $motif ?: 'Achat' ) . ' (' . fkc_money( $qteSaisie ) . ' ' . $libelleUnite . ' = ' . fkc_money( $qte ) . ' ' . $a['unite'] . ')' );
		}

		/*
		 * COM-010 — validé AVANT tout mouvement : un article sérialisé (IMEI…)
		 * exige exactement un numéro par unité reçue, chacun inédit dans ce
		 * commerce. Échec ici = rien n'est encore écrit.
		 */
		if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
			list( $okSer, $msgSer ) = FKC_VpSerie::validerEntree( $articleId, self::seriesEnTableau( $series ), $qte );
			if ( ! $okSer ) { return array( false, $msgSer ); }
		}

		/*
		 * COM-060 — Le lot est validé AVANT toute écriture, au même endroit
		 * que les numéros de série : un lot déjà reçu, absent, ou déjà périmé
		 * doit faire échouer la réception entière et non la laisser à
		 * moitié faite.
		 */
		if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) ) {
			list( $okLot, $msgLot ) = FKC_VpLot::validerEntree(
				$articleId, $lot['lot'] ?? '', $lot['peremption'] ?? '', $qte, $a
			);
			if ( ! $okLot ) { return array( false, $msgLot ); }
		}

		// Valorisation déléguée au moteur unique (voir FKC_Valorisation).
		$etat        = FKC_Valorisation::appliquerEntree( (float) $a['qte_stock'], (float) $a['cump'], $qte, $pu );
		$nouvelleQte = $etat['quantite'];
		$cump        = $etat['cump'];
		$pu          = $etat['pu_entree'];
		$montant     = $etat['valeur'];

		/*
		 * COM-009 — Capacité maximale (cuve station-service, silo, réservoir…).
		 * Générique (n'importe quel article de n'importe quel pack peut la
		 * porter), mais c'est le manque précis qui manquait à Station-service :
		 * rien n'empêchait de réceptionner plus de carburant que la cuve ne
		 * peut physiquement contenir. Une réception qui dépasserait la
		 * capacité est un signal (erreur de saisie, ou de VRAIS litres livrés
		 * en trop) — jamais un stock qui se met simplement à mentir.
		 */
		/*
		 * ELM-001 — Une entrée en stock sur un article qui n'est PAS suivi en
		 * stock n'a aucun sens : elle constituerait une quantité que plus
		 * rien ne consomme et que la valorisation ignore. On refuse en
		 * disant quoi faire, plutôt que d'accepter une réception fantôme.
		 */
		if ( ! self::gereStock( $a ) ) {
			return array( false, '« ' . $a['libelle'] . ' » n\'est pas suivi en stock : il ne peut pas être réceptionné. Activez la capacité « Gestion du stock » sur sa fiche si cet article doit être stocké.' );
		}

		if ( null !== $a['capacite_max'] && '' !== $a['capacite_max'] && (float) $a['capacite_max'] > 0 && $nouvelleQte > (float) $a['capacite_max'] + 0.00001 ) {
			return array( false, 'Capacité maximale dépassée : ' . fkc_money( $a['capacite_max'] ) . ' ' . $a['unite']
				. ' max, ' . fkc_money( $a['qte_stock'] ) . ' ' . $a['unite'] . ' déjà en stock — cette réception de '
				. fkc_money( $qte ) . ' ' . $a['unite'] . ' porterait le total à ' . fkc_money( $nouvelleQte ) . ' ' . $a['unite'] . '.' );
		}

		// Stock et mouvement forment une seule opération : une panne entre les
		// deux laisserait un CUMP recalculé sans trace du mouvement qui l'a
		// justifié, donc une valorisation invérifiable.
		/*
		 * COM-070 — Où pose-t-on cette marchandise ? Sans dépôt désigné, le
		 * principal, créé au besoin : une réception ne doit jamais échouer
		 * parce qu'un commerçant n'a pas encore déclaré ses murs.
		 */
		$depotId = self::depotOuPrincipal( $depotId, $cfg );

		$movId = FKC_Tx::executer( function () use ( $a, $nouvelleQte, $cump, $pu, $qte, $montant, $motif, $series, $lot, $depotId ) {
			FKC_DB::q( 'UPDATE vp_articles SET qte_stock=?, cump=?, prix_achat=? WHERE id=?', array( $nouvelleQte, $cump, $pu, (int) $a['id'] ) );
			FKC_DB::q(
				'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,motif,created_by) VALUES(?,?,?,?,?,?,?,?)',
				array( self::pack(), (int) $a['id'], 'entree', $qte, $pu, $montant, $motif ?: 'Achat', class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
			);
			$mid = (int) FKC_DB::conn()->lastInsertId();
			if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
				FKC_VpSerie::enregistrerEntree( (int) $a['id'], self::seriesEnTableau( $series ), $mid );
			}
			if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) ) {
				FKC_VpLot::enregistrerEntree( (int) $a['id'], $lot['lot'] ?? '', $lot['peremption'] ?? '', $qte, $mid, $pu );
			}
			if ( $depotId && class_exists( 'FKC_VpDepot' ) ) {
				FKC_VpDepot::ajuster( (int) $a['id'], $depotId, $qte );
				FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( $depotId, $mid ) );
			}
			return $mid;
		} );

		// Fournisseur : résolu vers le référentiel comptable, seul répertoire
		// depuis lequel un règlement peut être émis.
		$frn = ( $fournisseurId && class_exists( 'FKC_Fournisseur' ) ) ? FKC_Fournisseur::find( (int) $fournisseurId ) : null;
		$piece = 'ACH-' . str_pad( (string) $movId, 5, '0', STR_PAD_LEFT );

		$evt = (string) ( $cfg['stock']['evt_entree'] ?? '' );
		$eid = null;
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			$schema = FKC_Posting::schema( $evt );
			$repli  = '401600';
			foreach ( (array) ( $schema['lignes'] ?? array() ) as $l ) {
				if ( 'C' === strtoupper( (string) ( $l['sens'] ?? '' ) ) && preg_match( '/^40\d+$/', (string) ( $l['compte'] ?? '' ) ) ) { $repli = $l['compte']; }
			}
			$ctx = array(
				'montant_ht' => $montant, 'montant' => $montant,
				'article' => $a['libelle'], 'reference' => $a['reference'],
				'piece' => $piece, 'date' => date( 'Y-m-d' ),
				'fournisseur'    => $frn ? (string) $frn['nom'] : 'Fournisseur non designe',
				'tiers_type'     => $frn ? 'fournisseur' : null,
				'tiers_id'       => $frn ? (int) $frn['id'] : null,
				// 408 vaut aussi sans fournisseur identifié : c'est la nature de
				// l'opération qui le commande, pas le nom du tiers.
				'compte_attente' => class_exists( 'FKC_AchatReception' ) ? FKC_AchatReception::compteAttente() : $repli,
			);
			list( $ok, $msg, $eid, $bid ) = FKC_Posting::emettre( $evt, $ctx );
			if ( $ok ) { FKC_DB::q( 'UPDATE vp_mouvements SET ecriture_id=?, brouillon_id=? WHERE id=?', array( $eid, $bid, $movId ) ); }
		}

		/*
		 * Registre des factures à recevoir. La réception y entre même quand le
		 * fournisseur n'a pas été désigné : l'écriture est passée, la dette
		 * existe, et l'écarter du registre laissait un engagement au bilan sans
		 * document à régler. Le fournisseur s'attribue ensuite (Comptabilité →
		 * Achats), ce qui reporte aussi le tiers sur l'écriture.
		 */
		if ( class_exists( 'FKC_AchatReception' ) ) {
			FKC_AchatReception::enregistrer( array(
				'fournisseur_id' => $frn ? (int) $frn['id'] : null,
				'fournisseur_nom' => $frn ? (string) $frn['nom'] : null,
				'pack' => self::pack(), 'objet_type' => 'vp_article', 'objet_id' => (int) $a['id'],
				'piece' => $piece, 'libelle' => (string) $a['libelle'],
				'date_reception' => date( 'Y-m-d' ), 'montant_ht' => $montant, 'quantite' => $qte,
				'ecriture_id' => $eid ? (int) $eid : null,
				'cle' => 'vp:entree:' . $movId,
			) );
		}
		return array( true, 'Entrée enregistrée : ' . fkc_money( $qte ) . ' ' . $a['unite'] . ' · nouveau stock ' . fkc_money( $nouvelleQte ) . ' ' . $a['unite'] . '.' );
	}

	/**
	 * Résolution DYNAMIQUE du taux de TVA d'une vente (COM-001), partagée par
	 * vente() [comptant] et venteCredit() [B2B]. Voir l'ordre de priorité
	 * détaillé dans vente() ci-dessous.
	 */
	/** COM-010 : normalise l'entrée $series (déjà un tableau, ou une saisie brute une ligne/un numéro) — accepté par entree()/vente()/venteCredit(). */
	/**
	 * Les nouveaux articles de ce commerce ont-ils un prix affiché TTC ?
	 * Manifeste du pack (stock.prix_ttc), réglable par société
	 * (paramètre vp_prix_ttc_{pack}).
	 */
	public static function prixTtcParDefaut( ?array $cfg = null ) {
		try {
			$v = FKC_DB::q( 'SELECT valeur FROM parametres WHERE cle=?', array( 'vp_prix_ttc_' . self::pack() ) )->fetchColumn();
			if ( false !== $v && '' !== (string) $v ) { return '1' === (string) $v; }
		} catch ( \Throwable $e ) { /* table absente */ }
		$cfg = $cfg ?? ( class_exists( 'FKC_Packs' ) && method_exists( 'FKC_Packs', 'verticalConfig' ) ? (array) FKC_Packs::verticalConfig() : array() );
		return ! empty( $cfg['stock']['prix_ttc'] );
	}

	/**
	 * Prix unitaire HT d'une vente, en unité de base, à partir du prix saisi
	 * (dans la convention de l'article : HT, ou TTC si prix_ttc).
	 * @return array{0: float, 1: float} ( pu HT, pu dans la convention de l'article )
	 */
	public static function puHt( array $a, $puConvention, $tva ) {
		$puConvention = (float) $puConvention;
		$ht = ! empty( $a['prix_ttc'] ) && (float) $tva > 0 ? round( $puConvention / ( 1 + (float) $tva / 100 ), 6 ) : $puConvention;
		return array( $ht, $puConvention );
	}

	/**
	 * Prix de référence d'une vente sans prix saisi : le tarif applicable
	 * (promotion en cours, palier de quantité, prix spécial du client), à
	 * défaut le prix de l'article. 1.864.0 — la vente prenait toujours le
	 * prix de l'article : une promotion saisie n'était jamais appliquée.
	 */
	public static function prixApplicable( array $a, $qte = 1, $clientId = null ) {
		if ( class_exists( 'FKC_VpTarif' ) ) {
			$r = FKC_VpTarif::resoudre( $a, $qte, $clientId );
			if ( null !== ( $r['prix'] ?? null ) && (float) $r['prix'] > 0 ) { return (float) $r['prix']; }
		}
		return (float) $a['prix_vente'];
	}

	public static function seriesEnTableau( $series ) {
		if ( null === $series ) { return array(); }
		return class_exists( 'FKC_VpSerie' ) ? FKC_VpSerie::nettoyer( $series ) : ( is_array( $series ) ? $series : array() );
	}


	/**
	 * ELM-001 — L'article est-il suivi en stock ?
	 *
	 * Un article dont la capacité « Gestion du stock » est décochée (une
	 * prestation, un service de pose, un article livré en direct par le
	 * fournisseur) n'a pas de quantité à comparer : le refuser pour « stock
	 * insuffisant » serait le rendre invendable. Toute la comptabilisation
	 * de la vente reste inchangée — seul le contrôle de disponibilité et le
	 * décrément de quantité sont sautés.
	 *
	 * Défaut TOUJOURS oui : un article dont la colonne n'a jamais été
	 * renseignée (tout le parc installé) reste suivi exactement comme avant.
	 */
	public static function gereStock( array $a ) {
		return class_exists( 'FKC_VpCapacite' ) ? FKC_VpCapacite::gereStock( $a ) : true;
	}


	/**
	 * BAZ-003 — Contrôles commerciaux communs à toute sortie de stock : la
	 * quantité est-elle compatible avec les modes de vente de l'article, et
	 * un stock insuffisant doit-il être refusé sèchement ou renvoyé vers le
	 * cycle de commande ?
	 *
	 * Regroupés ici parce que vente(), venteCredit() et la livraison d'une
	 * commande doivent répondre exactement la même chose : trois réponses
	 * différentes à la même question seraient un écart qui ne se voit qu'en
	 * production.
	 *
	 * @return array{bool, string} ( ok, message de refus )
	 */
	/**
	 * COM-070 — Le dépôt d'un mouvement, ou le principal à défaut.
	 *
	 * Renvoie null quand le métier ne gère pas plusieurs lieux : la
	 * ventilation ne se déclenche alors nulle part, et un pack mono-magasin
	 * fonctionne exactement comme avant, sans même créer de dépôt.
	 */
	public static function depotOuPrincipal( $depotId, array $cfg = array() ) {
		if ( ! class_exists( 'FKC_VpDepot' ) || ! FKC_VpDepot::actif( $cfg ) ) { return null; }
		if ( $depotId ) { return (int) $depotId; }
		$p = FKC_VpDepot::principal();
		return $p ? (int) $p['id'] : null;
	}

	public static function controlerSortie( array $a, $qte, $depotId = null ) {
		if ( class_exists( 'FKC_VpTarif' ) ) {
			list( $okQ, $msgQ ) = FKC_VpTarif::validerQuantite( $a, $qte );
			if ( ! $okQ ) { return array( false, $msgQ ); }
		}
		/*
		 * COM-060 — Les lots se contrôlent AVANT la quantité globale : un
		 * article peut avoir 40 unités en stock dont 30 périmées. Le stock
		 * global dirait oui, les lots disent non — et c'est la bonne réponse.
		 */
		if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) && self::gereStock( $a ) ) {
			list( $okLot, $msgLot ) = FKC_VpLot::planSortie( (int) $a['id'], $qte, $a );
			if ( ! $okLot ) { return array( false, $msgLot ); }
		}
		/*
		 * COM-070 — Le dépôt se contrôle avant le stock global : quatre
		 * matelas en stock dont zéro dans la boutique, c'est « non » ici et
		 * « oui » au global. Le message dit où se trouve la marchandise,
		 * parce que la question suivante du vendeur est toujours celle-là.
		 */
		if ( $depotId && class_exists( 'FKC_VpDepot' ) && self::gereStock( $a ) ) {
			list( $okD, $msgD ) = FKC_VpDepot::controlerSortie( $a, $qte, $depotId );
			if ( ! $okD ) { return array( false, $msgD ); }
		}
		if ( self::gereStock( $a ) && (float) $qte > (float) $a['qte_stock'] ) {
			/*
			 * « Sur commande » : refuser sèchement serait faux — l'article se
			 * vend justement sans être en rayon. On refuse la sortie
			 * IMMÉDIATE (il n'y a rien à sortir) mais on dit où aller : le
			 * cycle de commande sait tenir un engagement sans marchandise,
			 * puis livrer et facturer quand elle arrive.
			 */
			if ( class_exists( 'FKC_VpTarif' ) && FKC_VpTarif::surCommande( $a ) ) {
				return array( false, 'Stock insuffisant : ' . fkc_money( $a['qte_stock'] ) . ' ' . $a['unite']
					. ' disponible(s). « ' . $a['libelle'] . ' » se vend sur commande — passez par Commandes clients pour engager la vente dès maintenant et livrer à réception.' );
			}
			return array( false, 'Stock insuffisant : ' . fkc_money( $a['qte_stock'] ) . ' ' . $a['unite'] . ' disponible(s).' );
		}
		return array( true, '' );
	}

	/**
	 * BAZ-003 — Trace commerciale d'une sortie, et alerte de prix plancher.
	 *
	 * Le prix reste TOUJOURS celui qu'a décidé le vendeur : on enregistre
	 * seulement à quel tarif il aurait dû vendre et de combien il s'en est
	 * écarté, et on signale une vente sous le coût de revient. Aucun blocage :
	 * dans un commerce où l'on négocie, un logiciel qui impose son prix est un
	 * logiciel qu'on n'ouvre plus.
	 *
	 * @return string Message d'alerte à accoler au message de succès (souvent vide).
	 */
	public static function tracerTarif( $mouvementId, array $a, $qte, $pu, $clientId = null ) {
		if ( ! class_exists( 'FKC_VpTarif' ) || ! $mouvementId ) { return ''; }
		$ref = FKC_VpTarif::resoudre( $a, $qte, $clientId );
		FKC_VpTarif::tracer( (int) $mouvementId, $ref, $pu );
		return FKC_VpTarif::alertePlancher( $a, $pu );
	}

	/**
	 * COMPTES DE STOCK DU PACK (1.857.0) — le compte de stock (3x) et celui de
	 * variation (603x) sont lus dans le schéma de RÉCEPTION du pack : c'est
	 * celui qui a fait entrer la marchandise, et la sortie doit mouvementer
	 * exactement les mêmes comptes (311550 pour le carburant, 311570 pour
	 * les terminaux…). Repli : la nature stockée du pack (FKC_StockCompta).
	 *
	 * Null quand le pack ne comptabilise pas ses réceptions (Retail,
	 * Distribution tiennent leur propre comptabilité) : aucun coût n'est
	 * alors constaté ici, pour ne pas écrire une sortie sans entrée.
	 *
	 * @return array{stock:string,stock_libelle:string,variation:string,variation_libelle:string}|null
	 */
	public static function comptesStockPack( array $cfg ) {
		$evt = (string) ( $cfg['stock']['evt_entree'] ?? '' );
		if ( '' === $evt || ! class_exists( 'FKC_Posting' ) || ! FKC_Posting::has( $evt ) ) { return null; }
		$out = array( 'stock' => '', 'stock_libelle' => '', 'variation' => '', 'variation_libelle' => '' );
		foreach ( (array) ( FKC_Posting::schema( $evt )['lignes'] ?? array() ) as $l ) {
			$num = (string) ( $l['compte'] ?? '' ); $sens = strtoupper( (string) ( $l['sens'] ?? '' ) );
			if ( 'D' === $sens && '' === $out['stock'] && preg_match( '/^3\d+$/', $num ) ) {
				$out['stock'] = $num; $out['stock_libelle'] = (string) ( $l['compte_libelle'] ?? 'Stock' );
			}
			if ( 'C' === $sens && '' === $out['variation'] && preg_match( '/^603\d*$/', $num ) ) {
				$out['variation'] = $num; $out['variation_libelle'] = (string) ( $l['compte_libelle'] ?? 'Variation des stocks' );
			}
		}
		if ( ( '' === $out['stock'] || '' === $out['variation'] ) && class_exists( 'FKC_StockCompta' ) ) {
			$c = FKC_StockCompta::comptes( FKC_StockCompta::natureDuPack( self::pack() ) );
			if ( '' === $out['stock'] ) { $out['stock'] = $c['stock']; $out['stock_libelle'] = $c['stock_libelle']; }
			if ( '' === $out['variation'] ) { $out['variation'] = $c['variation']; $out['variation_libelle'] = $c['variation_libelle']; }
		}
		return ( '' !== $out['stock'] && '' !== $out['variation'] ) ? $out : null;
	}

	/**
	 * CONSTATE LE COÛT D'UNE SORTIE — OU LE REPREND SUR UN RETOUR (1.857.0).
	 *
	 * Sous inventaire permanent, la réception a porté la marchandise au
	 * compte de stock (D 31 / C 603). La vente doit l'en faire sortir au
	 * CUMP : D 603 Variation / C 31 Stock. La brique verticale ne le faisait
	 * pas — le schéma « {pack}_vente » en est volontairement dépourvu, parce
	 * qu'il sert aussi la CAISSE, où l'inventaire constate déjà le coût. Le
	 * compte 31 gardait donc toute la marchandise jamais vendue, et la marge
	 * valait 100 % du chiffre d'affaires.
	 *
	 * $sens : 'sortie' (vente, livraison, SAV) ou 'retour' (reprise en stock).
	 * $contrepartie : autre compte de charge que la variation (chute de découpe
	 * → pertes sur stocks), facultatif.
	 *
	 * @return int|null écriture créée (ou null : rien à constater, pack sans
	 *                  comptabilité de stock, ou écriture au brouillard)
	 */
	public static function constaterCout( array $cfg, array $a, $montant, $sens, $movId, $libelle = '', $contrepartie = null ) {
		$montant = round( (float) $montant, 2 );
		if ( $movId ) {
			try { FKC_DB::q( 'UPDATE vp_mouvements SET cout=? WHERE id=?', array( $montant, (int) $movId ) ); } catch ( \Throwable $e ) {}
		}
		if ( $montant < 0.01 || ! self::gereStock( $a ) ) { return null; }
		$c = self::comptesStockPack( $cfg );
		if ( ! $c || ! class_exists( 'FKC_Ecriture' ) ) { return null; }
		$jid = FKC_Posting::journalId( 'OD' );
		if ( ! $jid ) { return null; }
		$charge = $contrepartie ? (string) $contrepartie : $c['variation'];
		$chargeLib = $contrepartie ? 'Autres charges diverses (écarts sur stocks)' : $c['variation_libelle'];
		$cCharge = FKC_Posting::compteId( $charge, $chargeLib );
		$cStock  = FKC_Posting::compteId( $c['stock'], $c['stock_libelle'] );
		if ( ! $cCharge || ! $cStock ) { return null; }
		$retour = ( 'retour' === $sens );
		$lib = $libelle ?: ( ( $retour ? 'Reprise en stock — ' : 'Coût des ventes — ' ) . $a['libelle'] );
		list( $ok, $msg, $eid ) = FKC_Ecriture::enregistrer(
			array( 'journal_id' => $jid, 'date_ecriture' => date( 'Y-m-d' ), 'libelle' => $lib,
				'piece' => ( $retour ? 'RST-' : 'CMV-' ) . str_pad( (string) (int) $movId, 5, '0', STR_PAD_LEFT ),
				'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null ),
			$retour
				? array(
					array( 'compte_id' => $cStock, 'libelle' => $lib, 'debit' => $montant, 'credit' => 0 ),
					array( 'compte_id' => $cCharge, 'libelle' => $lib, 'debit' => 0, 'credit' => $montant ),
				)
				: array(
					array( 'compte_id' => $cCharge, 'libelle' => $lib, 'debit' => $montant, 'credit' => 0 ),
					array( 'compte_id' => $cStock, 'libelle' => $lib, 'debit' => 0, 'credit' => $montant ),
				),
			/*
			 * L'écriture porte son origine (le mouvement de stock) : le
			 * contrôle d'intégrité ne la compte pas parmi les écritures sans
			 * pièce, et le brouillard renseigne `cout_ecriture_id` à la
			 * validation.
			 */
			array( 'source' => 'stock',
				'lien' => $movId ? array( 'table' => 'vp_mouvements', 'colonne' => 'cout_ecriture_id', 'ids' => array( (int) $movId ) ) : null )
		);
		if ( ! $ok ) {
			if ( function_exists( 'fkc_log' ) ) { fkc_log( 'FKC_VpStock::constaterCout ' . $msg, 'WARN' ); }
			return null;
		}
		if ( $eid && $movId ) {
			try { FKC_DB::q( 'UPDATE vp_mouvements SET cout_ecriture_id=? WHERE id=?', array( (int) $eid, (int) $movId ) ); } catch ( \Throwable $e ) {}
		}
		return $eid ? (int) $eid : null;
	}

	/**
	 * Coût d'une sortie d'article suivi par lots, au coût des lots que le
	 * plan FEFO consomme (null : pas de lots, ou lot sans coût connu).
	 * Appelé AVANT consommation (plan lu, pas appliqué) ; avec $movId, relit
	 * les lots déjà consommés par ce mouvement.
	 */
	public static function coutLotSortie( array $a, $qte, $movId = null ) {
		if ( ! class_exists( 'FKC_VpLot' ) || ! FKC_VpLot::suivi( $a ) ) { return null; }
		if ( $movId ) {
			$plan = array();
			foreach ( FKC_DB::q( 'SELECT lot_id, -qte qte FROM vp_lot_mouvements WHERE mouvement_id=? AND qte<0', array( (int) $movId ) )->fetchAll() as $r ) { $plan[] = array( 'lot_id' => (int) $r['lot_id'], 'qte' => (float) $r['qte'] ); }
		} else {
			list( $ok, , $plan ) = FKC_VpLot::planSortie( (int) $a['id'], $qte, $a );
			if ( ! $ok ) { return null; }
		}
		return FKC_VpLot::coutPlan( $plan );
	}

	/**
	 * Après une sortie valorisée au coût des lots, le CUMP du reste est
	 * recalculé pour que stock × CUMP égale toujours le compte de stock.
	 */
	public static function reajusterCump( array $a, $qteSortie, $coutSortie ) {
		$avant = (float) $a['qte_stock'];
		$reste = $avant - (float) $qteSortie;
		if ( $reste <= 0.00001 ) { return; }
		$valeur = max( 0.0, $avant * (float) $a['cump'] - (float) $coutSortie );
		FKC_DB::q( 'UPDATE vp_articles SET cump=? WHERE id=?', array( round( $valeur / $reste, 6 ), (int) $a['id'] ) );
	}

	/**
	 * Une marchandise qui revient au stock à son coût de sortie re-pondère
	 * le CUMP (1.865.0 — elle revenait jusqu'ici au CUMP du jour, ce qui
	 * écartait peu à peu la valeur physique du compte de stock).
	 */
	public static function reponderer( array $a, $qte, $coutUnitaire ) {
		$frais = self::article( (int) $a['id'] );
		if ( ! $frais ) { return; }
		$apres = (float) $frais['qte_stock'];
		$avant = $apres - (float) $qte;
		if ( $apres <= 0.00001 ) { return; }
		$valeur = max( 0.0, $avant ) * (float) $frais['cump'] + (float) $qte * (float) $coutUnitaire;
		FKC_DB::q( 'UPDATE vp_articles SET cump=? WHERE id=?', array( round( $valeur / $apres, 6 ), (int) $a['id'] ) );
	}

	/** Coût unitaire d'une sortie, relu sur le mouvement (repli : CUMP courant). */
	protected static function coutUnitaireSortie( array $mv, array $a ) {
		if ( isset( $mv['cout'] ) && null !== $mv['cout'] && (float) $mv['qte'] > 0 ) {
			return (float) $mv['cout'] / (float) $mv['qte'];
		}
		return (float) $a['cump'];
	}

	public static function resolverTva( array $a, array $cfg ) {
		$repli = ( null !== $a['tva_pct'] && '' !== $a['tva_pct'] )
			? (float) $a['tva_pct']
			: (float) ( $cfg['stock']['tva'] ?? 0 );
		/*
		 * BAZ-001 — la CATÉGORIE du catalogue peut porter la catégorie
		 * fiscale, héritée par tous ses articles. Sans ce maillon, un
		 * catalogue entièrement libre (le commerçant crée ses rayons) ne
		 * pourrait jamais distinguer un rayon exonéré d'un rayon taxable
		 * autrement qu'article par article. L'article garde le dernier mot :
		 * sa propre catégorie fiscale, si elle est renseignée, l'emporte.
		 */
		$catFiscale = $a['categorie_fiscale_id'] ?? null;
		if ( empty( $catFiscale ) && class_exists( 'FKC_VpCategorie' ) ) {
			$catFiscale = FKC_VpCategorie::categorieFiscalePour( $a );
		}
		return class_exists( 'FKC_CategorieFiscale' )
			? FKC_CategorieFiscale::tauxNatureDossier( self::pack(), 'vente', $repli, $catFiscale )
			: $repli;
	}

	/**
	 * Compte de vente (70x) à créditer, retrouvé dans le SCHÉMA D'ÉCRITURE
	 * déjà déclaré par le pack (ecritures.php) plutôt que dupliqué en dur —
	 * pour que la facture à crédit (COM-002) porte EXACTEMENT le même compte
	 * analytique que la vente comptant du même article (taxable vs exonéré).
	 */
	public static function compteVenteFor( array $cfg, $tva, ?array $article = null ) {
		/*
		 * BAZ-001 / décision D4 — une catégorie du catalogue peut imposer son
		 * propre compte de vente (70x), hérité par ses articles. C'est ce qui
		 * évite qu'un catalogue libre — « Rideaux », « Jouets », « Vaisselle »,
		 * créés par le commerçant — ne tombe intégralement dans un unique
		 * 701100 où plus aucune ventilation n'est lisible. Le schéma du pack
		 * reste la règle par défaut : la catégorie ne fait que la préciser.
		 */
		if ( $article && class_exists( 'FKC_VpCategorie' ) ) {
			$impose = FKC_VpCategorie::compteVentePour( $article );
			if ( $impose ) { return $impose; }
		}
		$evt = (string) ( $cfg['stock']['evt_sortie'] ?? '' );
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			$schema = FKC_Posting::schema( $evt );
			$cible  = ( (float) $tva > 0 ) ? 'tva > 0' : 'tva == 0';
			/*
			 * 1.857.0 — LA CONDITION EST ÉVALUÉE, PLUS COMPARÉE COMME UN TEXTE.
			 * Station-service et Téléphonie écrivent « regime == "" && tva == 0 »
			 * pour leurs ventes exonérées : la comparaison littérale à « tva == 0 »
			 * ne les reconnaissait pas, et une vente à crédit ou un retour de gaz
			 * subventionné tombait en 701100 au lieu de 701112. On évalue chaque
			 * bloc avec le contexte d'une vente comptoir (régime non renseigné).
			 */
			$ctxCond = array( 'tva' => (float) $tva, 'ht' => 1, 'ttc' => 1, 'regime' => '' );
			foreach ( (array) ( $schema['conditionnel'] ?? array() ) as $bloc ) {
				$si = trim( (string) ( $bloc['si'] ?? '' ) );
				$vrai = ( $si === $cible );
				if ( ! $vrai && method_exists( 'FKC_Posting', 'evalCondition' ) ) {
					try { $vrai = (bool) FKC_Posting::evalCondition( $si, $ctxCond ); } catch ( \Throwable $e ) { $vrai = false; }
				}
				if ( ! $vrai ) { continue; }
				foreach ( (array) ( $bloc['lignes'] ?? array() ) as $l ) {
					if ( 'C' === strtoupper( (string) ( $l['sens'] ?? '' ) ) && preg_match( '/^70\d+$/', (string) ( $l['compte'] ?? '' ) ) ) {
						return $l['compte'];
					}
				}
			}
			// Pas de bloc conditionnel (packs sans distinction taxable/exonéré, ex. pretaporter) : compte unique.
			foreach ( (array) ( $schema['lignes'] ?? array() ) as $l ) {
				if ( 'C' === strtoupper( (string) ( $l['sens'] ?? '' ) ) && preg_match( '/^70\d+$/', (string) ( $l['compte'] ?? '' ) ) ) {
					return $l['compte'];
				}
			}
		}
		return '701100';
	}

	/**
	 * Code taxe FNE le plus proche du taux résolu dynamiquement. Le module
	 * Facturation (COM-002 s'appuie dessus pour les ventes à crédit) ne
	 * connaît que 4 codes fixes (18/9/0/0) — limite connue, documentée dans
	 * l'analyse COM-002 : un taux dynamique « exotique » (ex. 5 %) est
	 * arrondi au code le plus proche, jamais silencieusement ignoré.
	 */
	public static function codeTvaFor( $taux ) {
		$taux = (float) $taux;
		if ( abs( $taux - 18.0 ) <= abs( $taux - 9.0 ) && $taux > 4.5 ) { return 'TVA'; }
		if ( $taux > 4.5 ) { return 'TVAB'; }
		// Taux nul : le code d'exonération dépend du régime (1.753.0).
		return FKC_Facture::codeExonere();
	}

	/**
	 * SORTIE DE STOCK SEULE, SANS ÉCRITURE (COM-045).
	 *
	 * Le moteur de commandes (FKC_VpCommande) a besoin de séparer LIVRAISON
	 * (sortie physique) de FACTURATION (créance) — exactement la distinction
	 * que votre table imposait déjà entre les deux. vente()/venteCredit()
	 * font les deux À LA FOIS (comptoir), ce qui est juste pour une vente
	 * immédiate mais faux pour une commande livrée aujourd'hui et facturée
	 * dans huit jours : facturer À LA LIVRAISON poserait une créance avant
	 * l'accord définitif sur les quantités réellement livrées (une livraison
	 * partielle est fréquente en B2B).
	 *
	 * Ne décrémente QUE le stock physique et trace le mouvement — la
	 * comptabilisation reste entièrement à la charge de l'appelant (ici,
	 * FKC_VpCommande::facturer(), qui passe par FKC_Facture comme
	 * venteCredit()).
	 *
	 * @return array{bool, string, int|null} ( ok, message, id du mouvement )
	 */
	public static function sortirStockSansEcriture( $articleId, $qte, $motif = '', $dossierId = null, $depotId = null, $pu = null ) {
		self::ensure();
		$a = self::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.', null ); }
		$qte = (float) $qte;
		if ( $qte <= 0 ) { return array( false, 'La quantité doit être positive.', null ); }
		$suivi = self::gereStock( $a );
		$depotId = self::depotOuPrincipal( $depotId );
		list( $okSortie, $msgSortie ) = self::controlerSortie( $a, $qte, $depotId );
		if ( ! $okSortie ) { return array( false, $msgSortie, null ); }
		$reste = (float) $a['qte_stock'] - ( $suivi ? $qte : 0 );
		if ( $suivi ) { FKC_DB::q( 'UPDATE vp_articles SET qte_stock=? WHERE id=?', array( $reste, (int) $a['id'] ) ); }
		FKC_DB::q(
			'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,dossier_id,motif,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
			// 1.864.0 — valorisée au prix de la commande quand il est connu (le CA du tableau de bord lit ce montant).
			array( self::pack(), (int) $a['id'], 'sortie', $qte, null !== $pu ? (float) $pu : (float) $a['prix_vente'], round( $qte * ( null !== $pu ? (float) $pu : (float) $a['prix_vente'] ), 2 ),
				$dossierId ? (int) $dossierId : null, $motif ?: 'Livraison', class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
		);
		$movId = (int) FKC_DB::conn()->lastInsertId();
		/*
		 * COM-060 — Une livraison de commande consomme les lots comme une
		 * vente : c'est la même marchandise qui quitte le magasin. Ne
		 * l'imputer que sur la vente comptant laisserait les lots gonflés du
		 * volume livré en B2B, et la traçabilité d'un rappel désignerait des
		 * lots déjà partis.
		 *
		 * La CHUTE de découpe, elle, passe aussi par ici mais impute ses lots
		 * elle-même (FKC_VpLot::chute), avec son propre motif : on doit
		 * pouvoir distinguer ce qui a été vendu de ce qui a été perdu.
		 */
		if ( $depotId && class_exists( 'FKC_VpDepot' ) && $suivi ) {
			FKC_VpDepot::ajuster( (int) $a['id'], $depotId, -$qte );
			FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( $depotId, $movId ) );
		}
		if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) && 0 !== strpos( (string) $motif, 'Chute de découpe' ) ) {
			list( , , $planLot ) = FKC_VpLot::planSortie( (int) $a['id'], $qte, $a );
			FKC_VpLot::consommer( $planLot, $movId, 'livraison' );
		}
		return array( true, 'Stock sorti : ' . fkc_money( $qte ) . ' ' . $a['unite'] . ' · restant ' . fkc_money( $reste ) . ' ' . $a['unite'] . '.', $movId );
	}

	/**
	 * VENTE COMPTANT — sortie de stock au CUMP + écriture directe (Caisse
	 * D / TVA+Ventes C). Chemin STRICTEMENT INCHANGÉ par COM-002 : c'est
	 * `venteCredit()` (ci-dessous) qui porte la séparation vente/facture/
	 * encaissement, pour les ventes à un client identifié non payées
	 * immédiatement.
	 * @return array{bool, string} ( ok, message )
	 */
	/*
	 * $moyen (1.606.0) — LE MOYEN DE RÈGLEMENT, ENFIN DEMANDÉ.
	 *
	 * Jusqu'ici, toute vente au comptant de la brique verticale débitait la
	 * caisse, qu'elle ait été réglée en espèces, par Wave, par carte ou par
	 * chèque. Le compte 571100 était écrit dans le schéma du pack : le geste
	 * métier n'avait aucun moyen de dire autre chose, et le rapprochement
	 * bancaire d'une supérette encaissant la moitié de ses ventes en mobile
	 * money était faux par construction.
	 *
	 * Le paramètre est en DERNIÈRE position et facultatif : les appelants
	 * existants — et les sept packs de commerce antérieurs — continuent de
	 * fonctionner à l'identique, en espèces implicites.
	 */
	public static function vente( $articleId, $qte, $puVente, array $cfg, $dossierId = null, $motif = '', $series = null, $uniteId = null, $depotId = null, $moyen = '' ) {
		self::ensure();
		$a = self::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.' ); }
		$qteSaisie = (float) $qte; $puSaisi = (float) $puVente;
		if ( $qteSaisie <= 0 ) { return array( false, 'La quantité vendue doit être positive.' ); }

		// COM-023 : normalisé en unité de base AVANT tout calcul — même principe
		// qu'entree(). qteSaisie×puSaisi = qte(base)×pu(base) : le total facturé
		// ne change pas, seule la façon de compter la quantité change.
		$facteur = 1.0; $libelleUnite = $a['unite'];
		if ( $uniteId && class_exists( 'FKC_VpUnite' ) ) {
			list( $okU, $msgU, $facteur, $libelleUnite ) = FKC_VpUnite::resoudre( $articleId, $uniteId, $a['unite'] );
			if ( ! $okU ) { return array( false, $msgU ); }
		}
		$qte = round( $qteSaisie * $facteur, 6 );
		// 1.864.0 — toute unité ≠ 1 se convertit (un « demi-carton » de facteur 0,5 aussi).
		// 1.864.0 — sans prix saisi : le tarif applicable (promotion, palier), pas le seul prix de l'article.
		$puConv = $puSaisi > 0 ? ( abs( $facteur - 1.0 ) > 1e-9 ? round( $puSaisi / $facteur, 6 ) : $puSaisi ) : self::prixApplicable( $a, $qteSaisie * $facteur );
		if ( abs( $facteur - 1.0 ) > 1e-9 ) {
			$motif = trim( ( $motif ?: 'Vente' ) . ' (' . fkc_money( $qteSaisie ) . ' ' . $libelleUnite . ' = ' . fkc_money( $qte ) . ' ' . $a['unite'] . ')' );
		}

		$depotId = self::depotOuPrincipal( $depotId, $cfg );
		list( $okSortie, $msgSortie ) = self::controlerSortie( $a, $qte, $depotId );
		if ( ! $okSortie ) { return array( false, $msgSortie ); }
		if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
			list( $okSer, $msgSer ) = FKC_VpSerie::validerSortie( $articleId, self::seriesEnTableau( $series ), $qte );
			if ( ! $okSer ) { return array( false, $msgSer ); }
		}

		/*
		 * TVA résolue DYNAMIQUEMENT (COM-001) — plus jamais un taux codé dans
		 * pack.php. Ordre de priorité :
		 *   1. catégorie fiscale rattachée à L'ARTICLE (fiscal_categories) —
		 *      l'article a toujours le dernier mot sur sa propre fiscalité ;
		 *   2. catégorie paramétrée pour la nature « vente » DE CE PACK
		 *      (écran Fiscalité → Catégories, fiscal_nature_{pack}_vente) —
		 *      modifiable par l'exploitant sans toucher au code ;
		 *   3. repli : l'ancien tva_pct de l'article, puis le tva du manifest
		 *      — comportement strictement identique à avant pour toute
		 *      installation qui n'a rien paramétré (rétrocompatible).
		 */
		$tva = self::resolverTva( $a, $cfg );
		list( $pu ) = self::puHt( $a, $puConv, $tva );
		if ( ! empty( $a['prix_ttc'] ) ) {
			// Prix affiché TTC : c'est le TTC qui est exact, la TVA en est extraite.
			$ttc  = round( $qte * $puConv, 2 );
			$ht   = round( $ttc / ( 1 + $tva / 100 ), 2 );
			$tvaM = round( $ttc - $ht, 2 );
		} else {
			$ht      = round( $qte * $pu, 2 );
			$tvaM    = round( $ht * $tva / 100, 2 );
			$ttc     = round( $ht + $tvaM, 2 );
		}
		$coutCump = round( $qte * (float) $a['cump'], 2 );
		// 1.865.0 — article suivi par lots : coût des lots consommés (FEFO), à défaut le CUMP.
		$coutLot = self::coutLotSortie( $a, $qte );
		if ( null !== $coutLot ) { $coutCump = $coutLot; }

		/*
		 * 1.864.0 — UNE VENTE, UNE OPÉRATION. Stock, mouvement, numéros de
		 * série, lots, dépôt et coût des ventes s'écrivaient l'un après
		 * l'autre, sans transaction : une panne au milieu laissait un stock
		 * diminué sans mouvement, ou un IMEI vendu sans vente. Ils sont
		 * désormais validés ensemble (comme la vente à crédit).
		 */
		try {
		list( $reste, $div, $movId, $moyenCode, $alerteTarif ) = FKC_Tx::executer( function () use ( $a, $qte, $pu, $puConv, $ht, $cfg, $dossierId, $motif, $series, $depotId, $moyen, $coutCump, $coutLot ) {
			// ELM-001 : un article non suivi en stock se vend sans que sa quantité
			// (restée à zéro) ne parte en négatif — seule la comptabilisation compte.
			$suiviStock = self::gereStock( $a );
			$reste = (float) $a['qte_stock'] - ( $suiviStock ? $qte : 0 );
			if ( $suiviStock ) { FKC_DB::q( 'UPDATE vp_articles SET qte_stock=? WHERE id=?', array( $reste, (int) $a['id'] ) ); }

			$div = null;
			if ( $dossierId ) {
				$div = FKC_VpDossier::ensureDivision( (int) $dossierId );
			}
			FKC_DB::q(
				'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,dossier_id,motif,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
				array( self::pack(), (int) $a['id'], 'sortie', $qte, $pu, $ht, $dossierId ? (int) $dossierId : null, $motif ?: 'Vente', class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
			);
			$movId = (int) FKC_DB::conn()->lastInsertId();
			/*
			 * Le moyen est NORMALISÉ par le référentiel, jamais stocké tel que
			 * saisi : « om », « orange », « Orange Money » désignent le même
			 * opérateur et doivent se retrouver ensemble au rapprochement. Un
			 * moyen que le référentiel ne reconnaît pas n'est pas inventé —
			 * il reste vide, et l'écriture retombe sur le compte du schéma.
			 */
			$moyenCode = '';
			if ( '' !== trim( (string) $moyen ) && class_exists( 'FKC_MoyenPaiement' ) ) {
				$moyenCode = FKC_MoyenPaiement::normaliser( $moyen );
			}
			if ( '' !== $moyenCode ) {
				try { FKC_DB::q( 'UPDATE vp_mouvements SET moyen=? WHERE id=?', array( $moyenCode, $movId ) ); }
				catch ( \Throwable $e ) { /* colonne absente sur une base ancienne : la vente reste juste */ }
			}
			if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
				FKC_VpSerie::consommerVente( (int) $a['id'], self::seriesEnTableau( $series ), $movId );
			}
			// BAZ-003 : à quel tarif aurait-on dû vendre, et de combien s'en
			// est-on écarté ? Enregistré sur le mouvement, jamais imposé au prix.
			if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) ) {
				list( , , $planLot ) = FKC_VpLot::planSortie( (int) $a['id'], $qte, $a );
				FKC_VpLot::consommer( $planLot, $movId, 'vente' );
			}
			if ( $depotId && class_exists( 'FKC_VpDepot' ) && $suiviStock ) {
				FKC_VpDepot::ajuster( (int) $a['id'], $depotId, -$qte );
				FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( $depotId, $movId ) );
			}
			$alerteTarif = self::tracerTarif( $movId, $a, $qte, $puConv );
			// 1.857.0 — coût des ventes (D 603 / C 31), au CUMP de la sortie (1.865.0 : au coût des lots).
			self::constaterCout( $cfg, $a, $coutCump, 'sortie', $movId );
			if ( null !== $coutLot ) { self::reajusterCump( $a, $qte, $coutLot ); }
			/*
			 * ELM-002 : la garantie s'ouvre AU MOMENT DE LA VENTE, automatiquement.
			 * C'est le geste que personne ne pense à faire au comptoir, et sans
			 * lequel la garantie n'existe que sur le ticket papier du client.
			 */
			if ( class_exists( 'FKC_VpApresVente' ) ) {
				FKC_VpApresVente::garantiesAutoVente( $a, $movId, $qte, $cfg, $series );
			}
			self::enregistrerExtension( $a, $movId, $ht, $cfg, '' );

			return array( $reste, $div, $movId, $moyenCode, $alerteTarif );
		} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpStock::vente ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Vente annulée, rien n\'a été enregistré : ' . $e->getMessage() );
		}

		$evt = (string) ( $cfg['stock']['evt_sortie'] ?? '' );
		/*
		 * Suivi honnête de la comptabilisation — trouvé en testant COM-002 :
		 * jusqu'ici, si l'écriture partait au brouillard (FKC_Brouillard, actif
		 * PAR DÉFAUT) ou si sa génération échouait, la vente se disait quand
		 * même « enregistrée » sans que rien ne le distingue d'une vente
		 * réellement comptabilisée. La vente EST enregistrée (stock sorti,
		 * mouvement tracé) — mais l'utilisateur doit savoir si l'écriture
		 * attend encore une vérification, ou n'a pas été générée du tout.
		 */
		$suffixe = '';
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			$ctx = array(
				'ht' => $ht, 'tva' => $tvaM, 'ttc' => $ttc, 'cout' => $coutCump,
				'montant' => $ttc, 'article' => $a['libelle'], 'reference' => $a['reference'],
				'piece' => 'VTE-' . str_pad( (string) $movId, 5, '0', STR_PAD_LEFT ),
				'date' => date( 'Y-m-d' ), 'division_id' => $div,
				// Le résolveur central lit cette clé pour choisir le compte de
				// trésorerie. Vide, il retombe sur celui du schéma.
				'moyen' => $moyenCode,
			);
			list( $ok, $msg, $eid, $bid ) = FKC_Posting::emettre( $evt, $ctx );
			if ( $ok ) {
				FKC_DB::q( 'UPDATE vp_mouvements SET ecriture_id=?, brouillon_id=? WHERE id=?', array( $eid, $bid, $movId ) );
				if ( $bid && ! $eid ) {
					$suffixe = ' Écriture déposée au brouillard, en attente de vérification (Comptabilité → Brouillard).';
				}
			} else {
				$suffixe = ' ⚠ La comptabilisation a échoué (' . $msg . ') — le stock est bien sorti, mais aucune écriture n\'a été générée : vérifiez le journal des ventes.';
			}
		}
		return array( true, 'Vente enregistrée : ' . fkc_money( $ttc ) . ' F TTC · stock restant ' . fkc_money( $reste ) . ' ' . $a['unite'] . '.'
			. $suffixe . ( $alerteTarif ? ' ' . $alerteTarif : '' ) );
	}

	/**
	 * VENTE À CRÉDIT (COM-002) — « vente ≠ encaissement ».
	 *
	 * vente() (ci-dessus) reste le chemin COMPTANT : encaissement immédiat en
	 * caisse, écriture directe, INCHANGÉ. Mais rien, jusqu'ici, ne permettait
	 * de vendre à un client identifié SANS encaisser tout de suite — chaque
	 * sortie de stock des 7 packs de la brique verticale posait D 571100
	 * Caisse, qu'un règlement ait ou non eu lieu.
	 *
	 * Ce chemin sépare les deux faits :
	 *   1. LA VENTE  → une créance sur le client (compte 411, via une vraie
	 *      facture du module Facturation — FKC_Facture — pas une écriture
	 *      ad hoc). C'est ce que fait CETTE méthode.
	 *   2. L'ENCAISSEMENT → un fait ultérieur et distinct, quand le client
	 *      règle : les écrans Facturation → Règlements existants (FKC_Recu /
	 *      FKC_Reglement::imputer(), déjà génériques et déjà utilisés
	 *      ailleurs dans l'ERP) s'en chargent SANS rien ajouter ici — c'est
	 *      précisément pour ça qu'on les réutilise plutôt que d'inventer une
	 *      troisième notion.
	 *
	 * Le stock sort exactement comme au comptant (même CUMP, même méthode
	 * « pas de double charge du coût ») ; seule la comptabilisation change de
	 * nature : c'est FKC_Facture::comptabiliser() qui la produit, au compte
	 * de vente RETROUVÉ dans le schéma du pack (compteVenteFor()) — donc la
	 * même ventilation taxable/exonérée qu'au comptant.
	 *
	 * @return array{bool, string, int|null} ( ok, message, id de la facture créée )
	 */
	public static function venteCredit( $articleId, $qte, $puVente, array $cfg, $clientId, $dossierId = null, $motif = '', $forcerEncours = false, $series = null, $uniteId = null, $depotId = null ) {
		self::ensure();
		$a = self::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.', null ); }
		if ( ! class_exists( 'FKC_Facture' ) || ! class_exists( 'FKC_Client' ) ) {
			return array( false, 'Le module Facturation n\'est pas disponible : vente à crédit impossible.', null );
		}
		$client = FKC_Client::find( (int) $clientId );
		if ( ! $client ) { return array( false, 'Client introuvable : choisissez un client du référentiel (ou créez-le d\'abord).', null ); }
		$qteSaisie = (float) $qte; $puSaisi = (float) $puVente;
		if ( $qteSaisie <= 0 ) { return array( false, 'La quantité vendue doit être positive.', null ); }

		// COM-023 : même normalisation que vente() — voir son commentaire.
		$facteur = 1.0; $libelleUnite = $a['unite'];
		if ( $uniteId && class_exists( 'FKC_VpUnite' ) ) {
			list( $okU, $msgU, $facteur, $libelleUnite ) = FKC_VpUnite::resoudre( $articleId, $uniteId, $a['unite'] );
			if ( ! $okU ) { return array( false, $msgU, null ); }
		}
		$qte = round( $qteSaisie * $facteur, 6 );
		// 1.864.0 — toute unité ≠ 1 se convertit (un « demi-carton » de facteur 0,5 aussi).
		$puConv = $puSaisi > 0 ? ( abs( $facteur - 1.0 ) > 1e-9 ? round( $puSaisi / $facteur, 6 ) : $puSaisi ) : self::prixApplicable( $a, $qteSaisie * $facteur, (int) $client['id'] );
		if ( abs( $facteur - 1.0 ) > 1e-9 ) {
			$motif = trim( ( $motif ?: ( 'Vente à crédit — ' . $client['nom'] ) ) . ' (' . fkc_money( $qteSaisie ) . ' ' . $libelleUnite . ' = ' . fkc_money( $qte ) . ' ' . $a['unite'] . ')' );
		}

		// 1.857.0 : le dépôt choisi par le vendeur est respecté (il était ignoré).
		$depotId = self::depotOuPrincipal( $depotId, $cfg );
		list( $okSortie, $msgSortie ) = self::controlerSortie( $a, $qte, $depotId );
		if ( ! $okSortie ) { return array( false, $msgSortie, null ); }
		if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
			list( $okSer, $msgSer ) = FKC_VpSerie::validerSortie( $articleId, self::seriesEnTableau( $series ), $qte );
			if ( ! $okSer ) { return array( false, $msgSer, null ); }
		}

		$tva  = self::resolverTva( $a, $cfg );
		list( $pu ) = self::puHt( $a, $puConv, $tva );
		$ht   = round( $qte * $pu, 2 );
		$compteVente = self::compteVenteFor( $cfg, $tva, $a );
		$ttcPrevisionnel = round( $ht + round( $ht * $tva / 100, 2 ), 2 );

		/*
		 * COM-006 — Crédit et encours client.
		 *
		 * Jusqu'ici, venteCredit() (COM-002) créait une facture quel que soit
		 * l'encours déjà dû par le client : aucune limite, aucun avertissement.
		 * FKC_CreditManagement (module Depreciation) porte déjà tout ce qu'il
		 * faut — limite par client, garanties, exposition nette, historique de
		 * retard — mais rien ne l'interrogeait avant une vente à crédit.
		 *
		 * avisCommande() est volontairement un AVIS, pas un verdict binaire
		 * (« c'est un avis, adressé à quelqu'un qui décide ») : « ok » et
		 * « attention » laissent la vente continuer (le second est remonté dans
		 * le message, pour que l'utilisateur sache), seul « refus » bloque —
		 * et seulement si $forcerEncours n'a pas été explicitement coché,
		 * exactement comme le trop-perçu ou le dépassement de devis ailleurs
		 * dans l'ERP : le contrôle protège par défaut, sans jamais confisquer
		 * la décision finale à un responsable qui a de bonnes raisons de passer
		 * outre.
		 */
		$avisMsg = '';
		if ( class_exists( 'FKC_CreditManagement' ) ) {
			$avis = FKC_CreditManagement::avisCommande( (int) $client['id'], $ttcPrevisionnel );
			if ( 'refus' === ( $avis['avis'] ?? '' ) && ! $forcerEncours ) {
				return array( false, 'Vente à crédit refusée par le contrôle d\'encours — ' . ( $avis['message'] ?? '' )
					. ' Cochez « forcer » pour passer outre si la situation le justifie.', null );
			}
			if ( in_array( $avis['avis'] ?? '', array( 'attention', 'refus' ), true ) ) {
				$avisMsg = ' ⚠ Contrôle d\'encours : ' . ( $avis['message'] ?? '' );
			}
		}

		return self::executerVenteCredit( $a, $qte, $pu, $ht, $tva, $compteVente, $cfg, $client, $dossierId, $motif, $avisMsg, $series, $depotId );
	}

	/*
	 * 1.857.0 — $depotId est désormais un PARAMÈTRE. La closure ci-dessous le
	 * capturait sans qu'il existe dans cette portée : il valait toujours null,
	 * et une vente à crédit ne décrémentait jamais le stock du dépôt — le
	 * magasin affichait une marchandise déjà partie chez le client.
	 */
	protected static function executerVenteCredit( array $a, $qte, $pu, $ht, $tva, $compteVente, array $cfg, array $client, $dossierId, $motif, $avisMsg = '', $series = null, $depotId = null ) {
		try {
			return FKC_Tx::executer( function () use ( $a, $qte, $pu, $ht, $tva, $compteVente, $cfg, $client, $dossierId, $motif, $avisMsg, $series, $depotId ) {
			$suiviStock = self::gereStock( $a );
			$reste = (float) $a['qte_stock'] - ( $suiviStock ? $qte : 0 );
			if ( $suiviStock ) { FKC_DB::q( 'UPDATE vp_articles SET qte_stock=? WHERE id=?', array( $reste, (int) $a['id'] ) ); }

			$div = $dossierId ? FKC_VpDossier::ensureDivision( (int) $dossierId ) : null;
			FKC_DB::q(
				'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,dossier_id,motif,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
				array( self::pack(), (int) $a['id'], 'sortie', $qte, $pu, $ht, $dossierId ? (int) $dossierId : null,
					$motif ?: ( 'Vente à crédit — ' . $client['nom'] ), class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
			);
			$movId = (int) FKC_DB::conn()->lastInsertId();
			if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
				FKC_VpSerie::consommerVente( (int) $a['id'], self::seriesEnTableau( $series ), $movId );
			}
			// BAZ-003 : ici le client est identifié — son prix spécial, s'il
			// en a un, sert de référence à la trace. C'est exactement le cas
			// où un écart apparent (« vendu 15 % sous le tarif ») ne serait
			// qu'un tarif négocié de longue date, mal lu faute de contexte.
			if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) ) {
				list( , , $planLot ) = FKC_VpLot::planSortie( (int) $a['id'], $qte, $a );
				FKC_VpLot::consommer( $planLot, $movId, 'vente' );
			}
			if ( $depotId && class_exists( 'FKC_VpDepot' ) && $suiviStock ) {
				FKC_VpDepot::ajuster( (int) $a['id'], $depotId, -$qte );
				FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( $depotId, $movId ) );
			}
			self::tracerTarif( $movId, $a, $qte, ! empty( $a['prix_ttc'] ) ? round( $pu * ( 1 + $tva / 100 ), 6 ) : $pu, (int) $client['id'] );
			// 1.857.0 — coût des ventes, comme au comptant (1.865.0 : au coût des lots s'ils sont suivis).
			$coutLot = self::coutLotSortie( $a, $qte, $movId );
			self::constaterCout( $cfg, $a, null !== $coutLot ? $coutLot : round( $qte * (float) $a['cump'], 2 ), 'sortie', $movId );
			if ( null !== $coutLot ) { self::reajusterCump( $a, $qte, $coutLot ); }
			// ELM-002 : ici le client est identifié — la garantie porte son
			// nom, ce qui permet de le reconnaître au SAV même sans facture.
			if ( class_exists( 'FKC_VpApresVente' ) ) {
				FKC_VpApresVente::garantiesAutoVente( $a, $movId, $qte, $cfg, $series, $client );
			}
			self::enregistrerExtension( $a, $movId, $ht, $cfg, (string) $client['nom'] );

			$delai = max( 0, (int) ( $client['delai_paiement'] ?? 0 ) );
			list( $ok, $msg, $fid ) = FKC_Facture::save(
				array(
					'client_id' => (int) $client['id'], 'client_nom' => $client['nom'],
					'date_facture' => date( 'Y-m-d' ),
					'echeance' => date( 'Y-m-d', strtotime( '+' . $delai . ' days' ) ),
					'devise' => $client['devise'] ?? 'XOF', 'payment_method' => 'credit',
					'template' => 'standard', 'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
					'division_id' => $div,
				),
				array( array(
					'designation' => $a['libelle'], 'quantite' => $qte, 'pu_ht' => $pu,
					'tva_code' => self::codeTvaFor( $tva ), 'unite' => $a['unite'], 'compte' => $compteVente,
				) )
			);
			if ( ! $ok ) { throw new \RuntimeException( 'Facturation : ' . $msg ); }

			FKC_DB::q( 'UPDATE vp_mouvements SET facture_id=? WHERE id=?', array( $fid, $movId ) );

			list( $okC, $msgC, $eid ) = FKC_Facture::comptabiliser( $fid );
			if ( ! $okC ) { throw new \RuntimeException( 'Comptabilisation de la facture : ' . $msgC ); }
			if ( $eid ) { FKC_DB::q( 'UPDATE vp_mouvements SET ecriture_id=? WHERE id=?', array( $eid, $movId ) ); }

			/*
			 * Trouvé en testant COM-006 : FKC_Facture::save() insère TOUJOURS
			 * la facture en statut « brouillon », qui n'en sort que via la
			 * certification FNE (Modules/Facturation/Services/Fne.php →
			 * « certifiee »). Une facture « brouillon » est délibérément
			 * exclue de l'encours par FKC_Recouvrement (« un brouillon n'est
			 * pas une créance ») — ce qui est juste pour une facture qu'on
			 * rédige encore, mais PAS pour celle-ci : elle vient d'être
			 * COMPTABILISÉE (écriture réelle, client 411 débité). La laisser
			 * en « brouillon » la rendrait invisible du contrôle d'encours
			 * (COM-006) et de tout recouvrement, alors que la créance existe
			 * bel et bien au grand livre. On la fait donc sortir du brouillon
			 * dès la comptabilisation — la certification FNE proprement dite
			 * reste un geste séparé, que le commerçant fait comme pour
			 * n'importe quelle autre facture, depuis Facturation → Factures.
			 */
			if ( $eid ) { FKC_DB::q( "UPDATE factures SET statut='validee' WHERE id=? AND statut='brouillon'", array( $fid ) ); }

			$f = FKC_Facture::find( $fid );
			return array( true,
				'Vente à crédit enregistrée : facture ' . ( $f['numero'] ?? '' ) . ' — ' . fkc_money( $f['montant_ttc'] ?? 0 )
				. ' F TTC dus par ' . $client['nom'] . ' (échéance ' . ( $f['echeance'] ?? '' ) . '). Le règlement se fait depuis Facturation → Règlements, quand il aura lieu.' . $avisMsg,
				$fid,
			);
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpStock::venteCredit ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Vente à crédit annulée : ' . $e->getMessage(), null );
		}
	}

	/**
	 * Compte de TVA collectée (443x) retrouvé dans le schéma du pack — même
	 * principe que compteVenteFor(), pour que le retour comptant (COM-017)
	 * contre-passe EXACTEMENT les comptes utilisés à la vente.
	 */
	public static function compteTvaFor( array $cfg ) {
		$evt = (string) ( $cfg['stock']['evt_sortie'] ?? '' );
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			$schema = FKC_Posting::schema( $evt );
			$blocs = array_merge( array( $schema ), (array) ( $schema['conditionnel'] ?? array() ) );
			foreach ( $blocs as $bloc ) {
				foreach ( (array) ( $bloc['lignes'] ?? array() ) as $l ) {
					if ( 'C' === strtoupper( (string) ( $l['sens'] ?? '' ) ) && preg_match( '/^44\d+$/', (string) ( $l['compte'] ?? '' ) ) ) {
						return $l['compte'];
					}
				}
			}
		}
		return '443100';
	}

	/** Compte de caisse (57x) retrouvé dans le schéma — même principe. */
	public static function compteCaisseFor( array $cfg ) {
		$evt = (string) ( $cfg['stock']['evt_sortie'] ?? '' );
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			$schema = FKC_Posting::schema( $evt );
			foreach ( (array) ( $schema['lignes'] ?? array() ) as $l ) {
				if ( 'D' === strtoupper( (string) ( $l['sens'] ?? '' ) ) && preg_match( '/^57\d+$/', (string) ( $l['compte'] ?? '' ) ) ) {
					return $l['compte'];
				}
			}
		}
		return '571100';
	}

	/** Quantité déjà retournée sur un mouvement de vente donné. */
	public static function qteRetournee( $mouvementId ) {
		self::ensure();
		return (float) FKC_DB::q( "SELECT COALESCE(SUM(qte),0) FROM vp_mouvements WHERE origine_mouvement_id=? AND sens='retour'", array( (int) $mouvementId ) )->fetchColumn();
	}

	/**
	 * RETOUR DE MARCHANDISE (COM-017) — le stock revient, l'argent ressort
	 * (comptant) ou une note de crédit est émise (crédit facturé). Deux faits
	 * distincts (cf. votre table : « Retour » = mouvement physique,
	 * « Remboursement » = sortie de trésorerie) traités ici comme un seul
	 * geste comptoir, parce qu'un retour comptant se règle dans le même
	 * instant — exactement comme une vente comptant encaisse dans le même
	 * instant (vente() n'a jamais séparé les deux non plus).
	 *
	 * COMPTANT (mouvement sans facture) : retour PARTIEL possible, autant de
	 * fois que nécessaire tant que la quantité restante le permet. Contre-passe
	 * exactement le compte de vente et le compte de TVA d'origine.
	 *
	 * CRÉDIT (mouvement facturé) : un avoir se fait sur la FACTURE entière
	 * (FKC_Facture::createAvoir(), qui refuse tout second avoir sur la même
	 * facture) — retour partiel non pris en charge ici, limite assumée de
	 * l'avoir générique existant plutôt qu'un mécanisme dupliqué pour la
	 * famille Commerce seule.
	 *
	 * @return array{bool, string, int|null} ( ok, message, id du mouvement de retour )
	 */
	public static function retour( $mouvementId, $qte, array $cfg, $motif = '', $series = null ) {
		self::ensure();
		$mv = FKC_DB::q( 'SELECT * FROM vp_mouvements WHERE id=? AND pack=?', array( (int) $mouvementId, self::pack() ) )->fetch();
		if ( ! $mv || 'sortie' !== $mv['sens'] ) { return array( false, 'Mouvement de vente introuvable.', null ); }
		$a = self::article( $mv['article_id'] );
		if ( ! $a ) { return array( false, 'Article introuvable.', null ); }
		$qte = (float) $qte;
		if ( $qte <= 0 ) { return array( false, 'La quantité retournée doit être positive.', null ); }
		$restant = (float) $mv['qte'] - self::qteRetournee( $mouvementId );
		if ( $qte > $restant + 0.00001 ) {
			return array( false, 'Impossible de retourner ' . fkc_money( $qte ) . ' ' . $a['unite'] . ' : seulement ' . fkc_money( $restant ) . ' ' . $a['unite'] . ' restent retournables sur cette vente.', null );
		}
		// 1.865.0 — numéros exigés aussi sur un retour PARTIEL de vente à crédit (le retour total les reprend tous).
		$retourCreditTotal = ! empty( $mv['facture_id'] ) && abs( $qte - (float) $mv['qte'] ) < 0.00001 && abs( $restant - (float) $mv['qte'] ) < 0.00001;
		if ( ! empty( $a['serialise'] ) && ! $retourCreditTotal && class_exists( 'FKC_VpSerie' ) ) {
			$numeros = self::seriesEnTableau( $series );
			if ( count( $numeros ) !== (int) round( $qte ) ) {
				return array( false, 'Cet article se suit par numéro de série : indiquez exactement ' . (int) round( $qte ) . ' numéro(s) retourné(s).', null );
			}
			foreach ( $numeros as $n ) {
				$r = FKC_DB::q( 'SELECT statut FROM vp_series WHERE pack=? AND numero_serie=? AND article_id=? AND mouvement_sortie_id=?',
					array( self::pack(), $n, (int) $a['id'], (int) $mv['id'] ) )->fetch();
				if ( ! $r ) { return array( false, 'Le numéro ' . $n . ' ne correspond pas à un exemplaire vendu par ce mouvement.', null ); }
			}
		}

		if ( ! empty( $mv['facture_id'] ) ) {
			// 1.865.0 — avoir partiel : seules les quantités rendues sont créditées.
			return self::executerRetourCredit( $a, $mv, $qte, $motif, $retourCreditTotal ? null : self::seriesEnTableau( $series ) );
		}
		return self::executerRetourComptant( $a, $mv, $qte, $cfg, $motif, $series );
	}

	protected static function executerRetourCredit( array $a, array $mv, $qte, $motif, $numeros = null ) {
		try {
			return FKC_Tx::executer( function () use ( $a, $mv, $qte, $motif, $numeros ) {
				$fo = FKC_Facture::find( (int) $mv['facture_id'] );
				$ordre = $fo && ! empty( $fo['lignes'] ) ? (int) ( $fo['lignes'][0]['ordre'] ?? 0 ) : 0;
				$total = abs( $qte - (float) $mv['qte'] ) < 0.00001 && abs( self::qteRetournee( (int) $mv['id'] ) ) < 0.00001;
				list( $ok, $msg, $aid ) = $total ? FKC_Facture::createAvoir( (int) $mv['facture_id'] ) : FKC_Facture::createAvoirPartiel( (int) $mv['facture_id'], array( $ordre => $qte ), $motif );
				if ( ! $ok ) { throw new \RuntimeException( $msg ); }

				$nouveauStock = (float) $a['qte_stock'] + $qte;
				FKC_DB::q( 'UPDATE vp_articles SET qte_stock=? WHERE id=?', array( $nouveauStock, (int) $a['id'] ) );
				FKC_DB::q(
					'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,motif,origine_mouvement_id,facture_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',
					array( self::pack(), (int) $a['id'], 'retour', $qte, (float) $mv['pu'], round( $qte * (float) $mv['pu'], 2 ),
						$motif ?: 'Retour sur vente à crédit', (int) $mv['id'], $aid, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
				);
				$movId = (int) FKC_DB::conn()->lastInsertId();
				// 1.857.0 — la marchandise revient au stock à son coût de sortie.
				self::constaterCout( (array) ( class_exists( 'FKC_Packs' ) ? FKC_Packs::verticalConfig() : array() ), $a,
					round( $qte * self::coutUnitaireSortie( $mv, $a ), 2 ), 'retour', $movId );
				self::reponderer( $a, $qte, self::coutUnitaireSortie( $mv, $a ) );
				if ( ! empty( $mv['depot_id'] ) && class_exists( 'FKC_VpDepot' ) ) {
					FKC_VpDepot::ajuster( (int) $a['id'], (int) $mv['depot_id'], $qte );
					FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( (int) $mv['depot_id'], $movId ) );
				}
				// 1.864.0 — la marchandise rendue retourne aussi à son lot (le retour crédit l'oubliait).
				if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) ) { FKC_VpLot::restituer( (int) $mv['id'], $qte ); }
				// COM-010 : un retour crédit est TOUJOURS total (avoir en une fois) —
				// tous les numéros vendus par ce mouvement reviennent, sans que
				// l'appelant ait à les resaisir.
				if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
					$rendus = null !== $numeros ? $numeros : array_column( FKC_VpSerie::duMouvementSortie( (int) $mv['id'] ), 'numero_serie' );
					if ( $rendus ) { FKC_VpSerie::restituer( $rendus ); }
				}
				$avoir = FKC_Facture::find( $aid );
				return array( true,
					'Retour enregistré : avoir ' . ( $avoir['numero'] ?? '' ) . ' — ' . fkc_money( abs( $avoir['montant_ttc'] ?? 0 ) )
					. ' F TTC crédités à ' . ( $avoir['client_nom'] ?? 'client' ) . '. Stock repris : ' . fkc_money( $qte ) . ' ' . $a['unite'] . '.',
					$movId,
				);
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpStock::retour (crédit) ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Retour annulé : ' . $e->getMessage(), null );
		}
	}

	protected static function executerRetourComptant( array $a, array $mv, $qte, array $cfg, $motif, $series = null ) {
		try {
			return FKC_Tx::executer( function () use ( $a, $mv, $qte, $cfg, $motif, $series ) {
				$puOrigine = (float) $mv['pu'];
				$ht = round( $qte * $puOrigine, 2 );

				/*
				 * Le taux de TVA appliqué EST CELUI DE LA VENTE D'ORIGINE, pas le
				 * taux courant de l'article : si le paramétrage fiscal a changé
				 * entre-temps, le retour doit contre-passer ce qui a RÉELLEMENT
				 * été facturé, pas ce qui serait facturé aujourd'hui. Retrouvé
				 * dans l'écriture d'origine quand elle existe ; à défaut (vente
				 * partie au brouillard, cf. correctif 1.520.104), on retombe sur
				 * le taux courant — seule source encore disponible.
				 */
				$tauxTva = null;
				if ( ! empty( $mv['ecriture_id'] ) ) {
					$compteTvaOrigine = self::compteTvaFor( $cfg );
					$ligneTva = FKC_DB::q(
						"SELECT l.credit FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id WHERE l.ecriture_id=? AND c.numero=?",
						array( (int) $mv['ecriture_id'], $compteTvaOrigine )
					)->fetch();
					$htOrigineTotal = (float) $mv['montant'];
					if ( $ligneTva && $htOrigineTotal > 0 ) {
						$tauxTva = round( (float) $ligneTva['credit'] / $htOrigineTotal * 100, 4 );
					}
				}
				if ( null === $tauxTva ) { $tauxTva = self::resolverTva( $a, $cfg ); }

				$tvaM = round( $ht * $tauxTva / 100, 2 );
				$ttc  = round( $ht + $tvaM, 2 );

				$nouveauStock = (float) $a['qte_stock'] + $qte;
				FKC_DB::q( 'UPDATE vp_articles SET qte_stock=? WHERE id=?', array( $nouveauStock, (int) $a['id'] ) );
				FKC_DB::q(
					'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,motif,origine_mouvement_id,created_by) VALUES(?,?,?,?,?,?,?,?,?)',
					array( self::pack(), (int) $a['id'], 'retour', $qte, $puOrigine, $ht,
						$motif ?: 'Retour comptant', (int) $mv['id'], class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
				);
				$movId = (int) FKC_DB::conn()->lastInsertId();
				if ( ! empty( $a['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
					FKC_VpSerie::restituer( self::seriesEnTableau( $series ) );
				}
				/*
				 * COM-060 — Un retour rend la marchandise AUX LOTS D'ORIGINE,
				 * relus depuis le mouvement de vente. Rendre au lot le plus
				 * proche de la péremption serait plus simple mais faux : on
				 * réattribuerait au client suivant une date qui n'est pas
				 * celle du produit qu'il a en main, et la traçabilité d'un
				 * rappel désignerait les mauvais acheteurs.
				 */
				if ( class_exists( 'FKC_VpLot' ) && FKC_VpLot::suivi( $a ) ) {
					FKC_VpLot::restituer( (int) $mv['id'], $qte );
				}
				/*
				 * COM-070 — La marchandise revient dans le dépôt d'OÙ ELLE
				 * EST PARTIE, relu sur le mouvement de vente. La rendre au
				 * dépôt principal serait plus simple, mais un client qui rend
				 * un article acheté en boutique verrait son retour crédité au
				 * dépôt de l'autre bout de la ville — et la boutique
				 * chercherait toute la journée un article qu'elle n'a pas.
				 */
				if ( ! empty( $mv['depot_id'] ) && class_exists( 'FKC_VpDepot' ) ) {
					FKC_VpDepot::ajuster( (int) $a['id'], (int) $mv['depot_id'], $qte );
					FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( (int) $mv['depot_id'], $movId ) );
				}

				// 1.857.0 — la marchandise revient au stock à son coût de sortie.
				self::constaterCout( $cfg, $a, round( $qte * self::coutUnitaireSortie( $mv, $a ), 2 ), 'retour', $movId );
				self::reponderer( $a, $qte, self::coutUnitaireSortie( $mv, $a ) );

				$suffixe = '';
				/*
				 * 1.857.0 — on ne rembourse EN COMPTABILITÉ que ce qui a été
				 * encaissé en comptabilité. Un pack sans schéma de vente
				 * (Retail, Distribution) n'avait passé aucune écriture à la
				 * vente : son retour contre-passait un chiffre d'affaires qui
				 * n'existait pas.
				 */
				$venteComptabilisee = ! empty( $mv['ecriture_id'] ) || ! empty( $mv['brouillon_id'] )
					|| ( '' !== (string) ( $cfg['stock']['evt_sortie'] ?? '' ) && class_exists( 'FKC_Posting' ) && FKC_Posting::has( (string) $cfg['stock']['evt_sortie'] ) );
				if ( $venteComptabilisee && class_exists( 'FKC_Compte' ) && class_exists( 'FKC_Journal' ) && class_exists( 'FKC_Ecriture' ) ) {
					/*
					 * 1.857.0 — remboursé par le MOYEN de la vente : une vente
					 * encaissée par Orange Money se rembourse sur le compte de
					 * l'opérateur, pas dans le tiroir-caisse (le rapprochement
					 * des deux comptes était faux de ce montant).
					 */
					$numCaisse = self::compteCaisseFor( $cfg );
					if ( ! empty( $mv['moyen'] ) && class_exists( 'FKC_Resolveur' ) ) {
						$r = FKC_Resolveur::resoudre( 'TRESORERIE', array( 'moyen' => (string) $mv['moyen'] ), $numCaisse );
						if ( $r && '' !== (string) $r['numero'] ) {
							$numCaisse = (string) $r['numero'];
							if ( ! FKC_Compte::byNumero( $numCaisse ) && class_exists( 'FKC_Posting' ) ) { FKC_Posting::compteId( $numCaisse, (string) ( $r['libelle'] ?? 'Trésorerie' ) ); }
						}
					}
					$cCaisse = FKC_Compte::byNumero( $numCaisse );
					$cTva    = $tvaM > 0 ? FKC_Compte::byNumero( self::compteTvaFor( $cfg ) ) : null;
					$cVente  = FKC_Compte::byNumero( self::compteVenteFor( $cfg, $tauxTva, $a ) );
					$ve = null;
					foreach ( (array) FKC_Journal::all() as $j ) { if ( 'VE' === $j['code'] ) { $ve = $j; break; } }
					if ( $cCaisse && $cVente && $ve ) {
						$lignes = array(
							array( 'compte_id' => $cVente['id'], 'libelle' => 'Retour — ' . $a['libelle'], 'debit' => $ht, 'credit' => 0 ),
						);
						if ( $cTva && $tvaM > 0 ) {
							$lignes[] = array( 'compte_id' => $cTva['id'], 'libelle' => 'TVA sur retour — ' . $a['libelle'], 'debit' => $tvaM, 'credit' => 0 );
						}
						$lignes[] = array( 'compte_id' => $cCaisse['id'], 'libelle' => 'Remboursement comptoir — ' . $a['libelle'], 'debit' => 0, 'credit' => $ttc );
						list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( array(
							'journal_id' => (int) $ve['id'], 'date_ecriture' => date( 'Y-m-d' ),
							'piece' => 'RET-' . str_pad( (string) $movId, 5, '0', STR_PAD_LEFT ),
							'libelle' => 'Retour comptoir — ' . $a['libelle'],
							'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
						), $lignes, array( 'source' => 'retour' ) );
						if ( $ok ) {
							FKC_DB::q( 'UPDATE vp_mouvements SET ecriture_id=?, brouillon_id=? WHERE id=?', array( $eid, $bid, $movId ) );
							if ( $bid && ! $eid ) { $suffixe = ' Écriture déposée au brouillard, en attente de vérification.'; }
						} else {
							$suffixe = ' ⚠ La comptabilisation du remboursement a échoué (' . $msg . ') — le stock est bien repris, vérifiez le journal des ventes.';
						}
					}
				}
				return array( true,
					'Retour enregistré : ' . fkc_money( $ttc ) . ' F TTC remboursés · stock repris ' . fkc_money( $qte ) . ' ' . $a['unite'] . '.' . $suffixe,
					$movId,
				);
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpStock::retour (comptant) ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Retour annulé : ' . $e->getMessage(), null );
		}
	}

	public static function mouvements( $limit = 100 ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT m.*, a.libelle AS article_libelle, a.reference AS article_ref, a.unite
			 FROM vp_mouvements m JOIN vp_articles a ON a.id=m.article_id
			 WHERE m.pack=? ORDER BY m.id DESC LIMIT " . (int) $limit,
			array( self::pack() )
		)->fetchAll();
	}

	/* ── KPI stock ───────────────────────────────────────────────────────── */

	public static function kpi() {
		self::ensure();
		$pk = self::pack();
		$k  = array( 'articles' => 0, 'valeur' => 0.0, 'alertes' => 0, 'ca_jour' => 0.0 );
		$r  = FKC_DB::q( "SELECT COUNT(*) n, COALESCE(SUM(qte_stock*cump),0) v FROM vp_articles WHERE pack=? AND actif=1", array( $pk ) )->fetch();
		$k['articles'] = (int) ( $r['n'] ?? 0 ); $k['valeur'] = (float) ( $r['v'] ?? 0 );
		$k['alertes']  = (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_articles WHERE pack=? AND actif=1 AND seuil_alerte>0 AND qte_stock<=seuil_alerte", array( $pk ) )->fetchColumn();
		// 1.857.0 : même définition de la vente que le pilotage (hors chutes et
		// pièces sous garantie, nette des retours).
		$k['ca_jour'] = class_exists( 'FKC_VpStockPilotage' ) ? FKC_VpStockPilotage::caJour()
			: (float) FKC_DB::q( "SELECT COALESCE(SUM(montant),0) FROM vp_mouvements WHERE pack=? AND sens='sortie' AND substr(created_at,1,10)=?", array( $pk, date( 'Y-m-d' ) ) )->fetchColumn();
		$k['rapprochement'] = self::rapprochementComptable();
		return $k;
	}

	/**
	 * STOCK PHYSIQUE ↔ COMPTE DE STOCK (1.857.0).
	 *
	 * La valeur du stock au CUMP (quantités × coût) et le solde du compte 31x
	 * décrivent la même marchandise. Jusqu'à 1.856.0, la vente ne sortait
	 * jamais la marchandise du compte 31 : l'écart grandissait à chaque
	 * vente. Il est désormais affiché ; un écart hérité se régularise par une
	 * écriture d'inventaire (D 603 / C 31).
	 *
	 * @return array|null { compte, physique, comptable, ecart } — null si le pack ne comptabilise pas son stock
	 */
	public static function rapprochementComptable() {
		self::ensure();
		$cfg = class_exists( 'FKC_Packs' ) ? (array) FKC_Packs::verticalConfig() : array();
		$c = self::comptesStockPack( $cfg );
		if ( ! $c ) { return null; }
		$physique = (float) FKC_DB::q( 'SELECT COALESCE(SUM(qte_stock*cump),0) FROM vp_articles WHERE pack=?', array( self::pack() ) )->fetchColumn();
		try {
			$comptable = (float) FKC_DB::q(
				'SELECT COALESCE(SUM(l.debit-l.credit),0) FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id WHERE c.numero=?',
				array( $c['stock'] )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return null; }
		return array( 'compte' => $c['stock'], 'libelle' => $c['stock_libelle'], 'physique' => round( $physique, 2 ),
			'comptable' => round( $comptable, 2 ), 'ecart' => round( $comptable - $physique, 2 ) );
	}

	/**
	 * Régularise l'écart entre le compte de stock et le stock physique
	 * valorisé (1.864.0 — recommandation 1 de l'audit 1.857.0).
	 *
	 * L'écart typique est l'héritage des ventes antérieures à 1.857.0, qui
	 * ne sortaient pas le coût du compte 31 : on passe l'écriture
	 * d'inventaire D 603 / C 31 (ou l'inverse si le compte est inférieur au
	 * stock). Rien n'est touché au stock physique : c'est lui qui fait foi.
	 * @return array{0: bool, 1: string}
	 */
	public static function regulariserEcart() {
		$r = self::rapprochementComptable();
		if ( ! $r ) { return array( false, 'Aucun compte de stock n\'est déclaré pour ce métier.' ); }
		$ecart = (float) $r['ecart'];
		if ( abs( $ecart ) < 1 ) { return array( false, 'Stock et comptabilité concordent déjà.' ); }
		$cfg = class_exists( 'FKC_Packs' ) && method_exists( 'FKC_Packs', 'verticalConfig' ) ? (array) FKC_Packs::verticalConfig() : array();
		$c = self::comptesStockPack( $cfg );
		$jid = class_exists( 'FKC_Posting' ) ? FKC_Posting::journalId( 'OD' ) : 0;
		if ( ! $c || ! $jid || ! class_exists( 'FKC_Ecriture' ) ) { return array( false, 'Journal ou comptes indisponibles.' ); }
		$cVar = FKC_Posting::compteId( $c['variation'], $c['variation_libelle'] );
		$cStk = FKC_Posting::compteId( $c['stock'], $c['stock_libelle'] );
		$m = round( abs( $ecart ), 2 );
		$lib = 'Régularisation d\'inventaire — rapprochement du compte ' . $c['stock'] . ' au stock physique';
		$lignes = $ecart > 0
			? array( array( 'compte_id' => $cVar, 'libelle' => $lib, 'debit' => $m, 'credit' => 0 ), array( 'compte_id' => $cStk, 'libelle' => $lib, 'debit' => 0, 'credit' => $m ) )
			: array( array( 'compte_id' => $cStk, 'libelle' => $lib, 'debit' => $m, 'credit' => 0 ), array( 'compte_id' => $cVar, 'libelle' => $lib, 'debit' => 0, 'credit' => $m ) );
		list( $ok, $msg, $eid, $bid ) = FKC_Ecriture::enregistrer( array(
			'journal_id' => $jid, 'date_ecriture' => date( 'Y-m-d' ), 'libelle' => $lib, 'piece' => 'REG-STK-' . date( 'ymd' ),
			'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
		), $lignes, array( 'source' => 'stock' ) );
		if ( ! $ok ) { return array( false, 'Écriture refusée : ' . $msg ); }
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'vp_regularisation_stock', self::pack() . ' : ' . $ecart . ' F' ); }
		return array( true, ( $bid && ! $eid ? 'Régularisation déposée au brouillard' : 'Régularisation passée' ) . ' : ' . fkc_money( $m ) . ' F ' . ( $ecart > 0 ? 'sortis du' : 'portés au' ) . ' compte ' . $c['stock'] . '.' );
	}

	/* ── Extensions de garantie (1.865.0) ─────────────────────────────── */

	/**
	 * Une extension de garantie vendue se rend pendant toute sa durée :
	 * son prix n'est pas un produit du jour. Chaque vente d'un article
	 * « extension » (extension_mois > 0) est inscrite au registre ; à la
	 * clôture, la part restant à courir passe en produits constatés
	 * d'avance (ajusterPcaExtensions).
	 */
	protected static function enregistrerExtension( array $a, $movId, $ht, array $cfg, $clientNom ) {
		$mois = (int) ( $a['extension_mois'] ?? 0 );
		if ( $mois <= 0 || (float) $ht <= 0 ) { return; }
		$debut = date( 'Y-m-d' );
		$fin = date( 'Y-m-d', strtotime( $debut . ' +' . $mois . ' month -1 day' ) );
		FKC_DB::q( 'INSERT INTO vp_extensions(pack,mouvement_id,article_id,client_nom,montant_ht,compte,debut,fin) VALUES(?,?,?,?,?,?,?,?)',
			array( self::pack(), (int) $movId, (int) $a['id'], (string) $clientNom, round( (float) $ht, 2 ), self::compteVenteFor( $cfg, self::resolverTva( $a, $cfg ), $a ), $debut, $fin ) );
	}

	/** Part restant à courir des extensions à une date, par compte de produit. */
	public static function pcaExtensions( $date ) {
		self::ensure();
		$out = array();
		foreach ( FKC_DB::q( 'SELECT * FROM vp_extensions WHERE pack=? AND annule=0', array( self::pack() ) )->fetchAll() as $x ) {
			$tot = max( 1, (int) round( ( strtotime( $x['fin'] ) - strtotime( $x['debut'] ) ) / 86400 ) + 1 );
			if ( $date < $x['debut'] ) { $reste = $tot; }
			elseif ( $date >= $x['fin'] ) { $reste = 0; }
			else { $reste = (int) round( ( strtotime( $x['fin'] ) - strtotime( $date ) ) / 86400 ); }
			$out[ $x['compte'] ] = ( $out[ $x['compte'] ] ?? 0 ) + (float) $x['montant_ht'] * $reste / $tot;
		}
		return array_map( function ( $v ) { return round( $v, 2 ); }, $out );
	}

	/** Solde déjà constaté en 477, par compte de produit. */
	public static function pcaConstate() {
		self::ensure();
		$out = array();
		foreach ( FKC_DB::q( 'SELECT compte, solde FROM vp_pca WHERE id IN (SELECT MAX(id) FROM vp_pca WHERE pack=? GROUP BY compte)', array( self::pack() ) )->fetchAll() as $r ) { $out[ $r['compte'] ] = (float) $r['solde']; }
		return $out;
	}

	/**
	 * Ajuste les produits constatés d'avance des extensions au solde cible :
	 * seul l'écart est passé (D produit / C 477, ou l'inverse), compte par compte.
	 * @return array{0: bool, 1: string}
	 */
	public static function ajusterPcaExtensions( $date = null ) {
		self::ensure();
		$date = $date ?: date( 'Y-m-d' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) { return array( false, 'Date invalide.' ); }
		$cible = self::pcaExtensions( $date ); $deja = self::pcaConstate();
		$n = 0; $total = 0.0;
		foreach ( array_unique( array_merge( array_keys( $cible ), array_keys( $deja ) ) ) as $compte ) {
			$delta = round( ( $cible[ $compte ] ?? 0 ) - ( $deja[ $compte ] ?? 0 ), 2 );
			if ( abs( $delta ) < 1 ) { continue; }
			$r = FKC_Posting::emettre( 'vp_pca_extensions', array( 'montant' => abs( $delta ), 'date' => $date, 'compte_produit' => $compte,
				'reference' => 'au ' . date( 'd/m/Y', strtotime( $date ) ), 'piece' => 'PCA-EXT-' . str_replace( '-', '', $date ) ),
				array( 'source' => 'stock', 'inverser' => $delta < 0 ) );
			if ( empty( $r[0] ) ) { return array( false, 'Écriture refusée : ' . (string) ( $r[1] ?? '' ) ); }
			FKC_DB::q( 'INSERT INTO vp_pca(pack,date,compte,solde,ajustement,ecriture_id) VALUES(?,?,?,?,?,?)', array( self::pack(), $date, $compte, $cible[ $compte ] ?? 0, $delta, ! empty( $r[2] ) ? (int) $r[2] : null ) );
			$n++; $total += $delta;
		}
		return array( true, $n ? 'Extensions de garantie : ' . fkc_money( array_sum( $cible ) ) . ' F restent à courir (ajustement ' . ( $total > 0 ? '+' : '' ) . fkc_money( $total ) . ' F).' : 'Produits constatés d\'avance des extensions déjà à jour (' . fkc_money( array_sum( $cible ) ) . ' F).' );
	}

	public static function schemasCommerce() {
		return array(
			'vp_pca_extensions' => array(
				'journal' => 'OD',
				'libelle' => 'Extensions de garantie restant à courir ({reference})',
				'lignes'  => array(
					array( 'compte' => '{compte_produit}', 'compte_repli' => '706100', 'compte_libelle' => 'Extensions de garantie vendues',
					       'sens' => 'D', 'montant' => 'montant', 'libelle' => 'Part restant à courir' ),
					array( 'compte' => '477100', 'compte_libelle' => 'Produits constatés d\'avance',
					       'sens' => 'C', 'montant' => 'montant', 'libelle' => 'Extensions de garantie' ),
				),
			),
		);
	}

	/* ── Proximité : Supérette et catalogue Retail (1.865.0) ──────────── */

	/**
	 * Vue unifiée des deux catalogues d'un commerce de proximité : la brique
	 * verticale (Supérette) et le catalogue Retail (rt_articles), quand les
	 * deux coexistent. Articles, valeur de stock, et DOUBLONS — un même
	 * produit suivi dans les deux stocks (même référence ou même libellé),
	 * donc vendu à deux endroits et compté deux fois. Premier pas vers un
	 * catalogue unique (recommandation 7 de l'audit 1.864.0).
	 * @return array|null null si pas de catalogue Retail
	 */
	public static function proximiteUnifiee() {
		self::ensure();
		try { FKC_DB::q( 'SELECT 1 FROM rt_articles LIMIT 1' ); } catch ( \Throwable $e ) { return null; }
		$rt = FKC_DB::q( 'SELECT COUNT(*) n, COALESCE(SUM(qte_stock*cump),0) v FROM rt_articles WHERE actif=1' )->fetch();
		if ( ! (int) $rt['n'] ) { return null; }
		$vp = FKC_DB::q( 'SELECT COUNT(*) n, COALESCE(SUM(qte_stock*cump),0) v FROM vp_articles WHERE pack=? AND actif=1', array( self::pack() ) )->fetch();
		$doublons = FKC_DB::q(
			"SELECT v.id, v.reference, v.libelle, v.qte_stock vq, r.qte_stock rq FROM vp_articles v JOIN rt_articles r
			 ON r.actif=1 AND ( lower(trim(r.reference))=lower(trim(v.reference)) OR lower(trim(r.libelle))=lower(trim(v.libelle)) )
			 WHERE v.pack=? AND v.actif=1 ORDER BY v.libelle LIMIT 50", array( self::pack() ) )->fetchAll();
		return array( 'vertical' => array( 'articles' => (int) $vp['n'], 'valeur' => round( (float) $vp['v'], 2 ) ),
			'retail' => array( 'articles' => (int) $rt['n'], 'valeur' => round( (float) $rt['v'], 2 ) ), 'doublons' => $doublons );
	}

	/* ── Inventaire d'un article (1.865.0) ───────────────────────────── */

	/**
	 * Ajuste le stock d'un article à la quantité comptée (inventaire,
	 * relevé de cuve…). Le socle vertical n'avait aucun geste d'inventaire :
	 * l'écart restait invisible ou se « vendait ». Manquant : D 658800
	 * (écarts sur stocks) / C 31 au CUMP ; excédent : D 31 / C 603. Hors CA.
	 * @return array{0: bool, 1: string, 2: float} ( ok, message, écart )
	 */
	public static function inventorier( $articleId, $qteComptee, array $cfg, $motif = '' ) {
		self::ensure();
		$a = self::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.', 0.0 ); }
		if ( ! self::gereStock( $a ) ) { return array( false, 'Article non suivi en stock.', 0.0 ); }
		$qteComptee = (float) $qteComptee;
		if ( $qteComptee < 0 ) { return array( false, 'La quantité comptée ne peut pas être négative.', 0.0 ); }
		$ecart = round( $qteComptee - (float) $a['qte_stock'], 6 );
		if ( abs( $ecart ) < 0.00001 ) { return array( true, 'Aucun écart : le stock est juste.', 0.0 ); }
		$valeur = round( abs( $ecart ) * (float) $a['cump'], 2 );
		$lib = 'Inventaire — ' . ( trim( (string) $motif ) ?: ( $ecart < 0 ? 'manquant' : 'excédent' ) );
		try {
			FKC_Tx::executer( function () use ( $a, $ecart, $valeur, $cfg, $lib, $qteComptee ) {
				FKC_DB::q( 'UPDATE vp_articles SET qte_stock=? WHERE id=?', array( $qteComptee, (int) $a['id'] ) );
				FKC_DB::q( 'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,motif,created_by) VALUES(?,?,?,?,?,?,?,?)',
					array( self::pack(), (int) $a['id'], $ecart < 0 ? 'sortie' : 'entree', abs( $ecart ), (float) $a['cump'], 0, $lib, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null ) );
				$mid = (int) FKC_DB::conn()->lastInsertId();
				$dep = self::depotOuPrincipal( null, $cfg );
				if ( $dep && class_exists( 'FKC_VpDepot' ) ) { FKC_VpDepot::ajuster( (int) $a['id'], $dep, $ecart ); FKC_DB::q( 'UPDATE vp_mouvements SET depot_id=? WHERE id=?', array( $dep, $mid ) ); }
				// Compte des écarts d'inventaire, le même que FKC_StockCompta (paramètre stock_compte_ecart).
				$cpt = '658800';
				try { $v = FKC_DB::q( 'SELECT valeur FROM parametres WHERE cle=?', array( 'stock_compte_ecart' ) )->fetchColumn(); if ( $v ) { $cpt = trim( (string) $v ); } } catch ( \Throwable $e ) {}
				if ( $ecart < 0 ) { self::constaterCout( $cfg, $a, $valeur, 'sortie', $mid, $lib, $cpt ); }
				else { self::constaterCout( $cfg, $a, $valeur, 'retour', $mid, $lib ); }
			} );
		} catch ( \Throwable $e ) { return array( false, 'Inventaire non enregistré : ' . $e->getMessage(), 0.0 ); }
		return array( true, ( $ecart < 0 ? 'Manquant' : 'Excédent' ) . ' de ' . fkc_money( abs( $ecart ) ) . ' ' . $a['unite'] . ' (' . fkc_money( $valeur ) . ' F) — stock ajusté à ' . fkc_money( $qteComptee ) . ' ' . $a['unite'] . '.', $ecart );
	}

	public static function alertes() {
		self::ensure();
		return FKC_DB::q( "SELECT * FROM vp_articles WHERE pack=? AND actif=1 AND seuil_alerte>0 AND qte_stock<=seuil_alerte ORDER BY qte_stock ASC", array( self::pack() ) )->fetchAll();
	}
}

/**
 * Reprise du stock lors de l'annulation d'une entrée erronée, pour les sept
 * packs bâtis sur la brique verticale. Déclaré une fois, valable pour tous.
 */
if ( class_exists( 'FKC_AchatReception' ) ) {
	FKC_AchatReception::surAnnulation( 'vp_article', function ( array $r ) {
		$aid = (int) $r['objet_id'];
		$qte = (float) $r['quantite'];
		if ( ! $aid || $qte <= 0 ) { return false; }
		$a = FKC_DB::q( 'SELECT qte_stock FROM vp_articles WHERE id=?', array( $aid ) )->fetch();
		if ( ! $a ) { return false; }
		if ( (float) $a['qte_stock'] < $qte - 0.00001 ) {
			throw new \RuntimeException(
				'Le stock disponible (' . fkc_money( (float) $a['qte_stock'] ) . ') est inférieur à la quantité entrée ('
				. fkc_money( $qte ) . ') : une partie a déjà été vendue. Passez par un avoir fournisseur.'
			);
		}
		FKC_DB::q( 'UPDATE vp_articles SET qte_stock = qte_stock - ? WHERE id=?', array( $qte, $aid ) );
		FKC_DB::q(
			'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,motif,created_by) VALUES(?,?,?,?,?,?,?,?)',
			array( (string) $r['pack'], $aid, 'sortie', $qte, 0, 0,
				'Annulation réception ' . (string) $r['piece'], class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
		);
		return true;
	} );
}

if ( class_exists( 'FKC_Posting' ) ) {
	FKC_Posting::register( FKC_VpStock::schemasCommerce(), 'stock' );
}
