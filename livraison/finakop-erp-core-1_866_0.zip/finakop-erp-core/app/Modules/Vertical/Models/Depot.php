<?php
/**
 * MULTI-MAGASINS ET MULTI-DÉPÔTS (COM-070).
 *
 * LE DERNIER POINT DU CAHIER DES CHARGES
 *
 * « multi-magasins ; multi-dépôts » figurait parmi les capacités natives
 * attendues du Bazar. Jusqu'ici, `vp_articles.qte_stock` était une quantité
 * GLOBALE par pack : un commerçant tenant une boutique et un dépôt de
 * quartier voyait un seul chiffre, et ne pouvait pas savoir où se trouvait
 * sa marchandise. Concrètement : un client demande un matelas, l'écran dit
 * qu'il en reste quatre, ils sont tous à l'autre bout de la ville.
 *
 * ── POURQUOI JE RÉUTILISE inv_entrepots ICI, ALORS QUE J'AI REFUSÉ
 *    inv_lots POUR LES LOTS ──────────────────────────────────────────────
 *
 * La décision paraît contradictoire, elle ne l'est pas — et la différence
 * mérite d'être écrite, parce qu'elle est la règle générale.
 *
 * `inv_lots` porte des QUANTITÉS, maintenues par le flux de réception de
 * l'Inventaire. Y faire écrire aussi la brique verticale aurait donné deux
 * flux entretenant le même chiffre selon deux logiques : elles divergent
 * toujours, et personne ne sait plus laquelle croire.
 *
 * `inv_entrepots` ne porte AUCUNE quantité : c'est une liste de lieux
 * physiques — un bâtiment, une boutique, une réserve. Ces lieux appartiennent
 * à la SOCIÉTÉ, pas à un module : le magasin de la rue X est le même que
 * l'ERP le regarde par l'Inventaire ou par le Commerce. En dupliquer la
 * liste obligerait le commerçant à déclarer deux fois ses murs, et à les
 * tenir synchronisés à la main.
 *
 * La règle est donc : on partage les RÉFÉRENTIELS, on ne partage jamais les
 * COMPTEURS.
 *
 * ── LE CUMP RESTE GLOBAL, ET C'EST VOULU ────────────────────────────────
 *
 * `vp_stock_depot` ventile les quantités ; la valorisation, elle, ne se
 * découpe pas. Un CUMP par dépôt supposerait un compte de stock par dépôt et
 * une écriture à chaque transfert : ce n'est pas ce que fait une entreprise
 * qui déplace sa propre marchandise entre ses propres murs. Le stock vaut
 * la même chose des deux côtés de la ville.
 *
 * Conséquence directe : un TRANSFERT ne génère AUCUNE écriture comptable. Le
 * patrimoine n'a pas bougé, seule sa localisation a changé.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpDepot {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS inv_entrepots(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				code TEXT NOT NULL UNIQUE, libelle TEXT NOT NULL,
				adresse TEXT, principal INTEGER NOT NULL DEFAULT 0, actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS vp_stock_depot(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				depot_id INTEGER NOT NULL,
				qte REAL NOT NULL DEFAULT 0,
				UNIQUE(pack, article_id, depot_id)
			);
			CREATE INDEX IF NOT EXISTS idx_vpsd_article ON vp_stock_depot(article_id);
			CREATE INDEX IF NOT EXISTS idx_vpsd_depot ON vp_stock_depot(pack, depot_id);
		" );
		// Localisation de chaque mouvement, et destination pour un transfert.
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN depot_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_mouvements ADD COLUMN depot_dest_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/** Le métier gère-t-il plusieurs lieux ? Déclaré au manifest. */
	public static function actif( ?array $cfg = null ) {
		if ( is_array( $cfg ) && isset( $cfg['stock']['multi_depot'] ) ) { return ! empty( $cfg['stock']['multi_depot'] ); }
		$p = class_exists( 'FKC_Packs' ) ? FKC_Packs::get( self::pack() ) : null;
		return ! empty( $p['stock']['multi_depot'] );
	}

	/* ── Référentiel des lieux ───────────────────────────────────────────── */

	public static function tous( $actifsSeuls = true ) {
		self::ensure();
		$w = $actifsSeuls ? 'WHERE actif=1' : '';
		return FKC_DB::q( "SELECT * FROM inv_entrepots {$w} ORDER BY principal DESC, libelle" )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM inv_entrepots WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	public static function options( $actifsSeuls = true ) {
		$out = array();
		foreach ( self::tous( $actifsSeuls ) as $d ) {
			$out[ (int) $d['id'] ] = $d['libelle'] . ( ! empty( $d['principal'] ) ? ' (principal)' : '' );
		}
		return $out;
	}

	/**
	 * Le dépôt par défaut, créé au besoin.
	 *
	 * Il DOIT exister : sans lui, une réception n'aurait nulle part où poser
	 * sa marchandise, et tout le stock antérieur au multi-dépôt serait
	 * orphelin. On le crée donc silencieusement plutôt que de refuser la
	 * première entrée d'un commerçant qui n'a jamais entendu parler de dépôts.
	 */
	public static function principal() {
		self::ensure();
		$d = FKC_DB::q( 'SELECT * FROM inv_entrepots WHERE principal=1 AND actif=1 LIMIT 1' )->fetch();
		if ( $d ) { return $d; }
		$d = FKC_DB::q( 'SELECT * FROM inv_entrepots WHERE actif=1 ORDER BY id LIMIT 1' )->fetch();
		if ( $d ) { return $d; }
		FKC_DB::q( "INSERT INTO inv_entrepots(code,libelle,principal,actif) VALUES('PRINCIPAL','Magasin principal',1,1)" );
		return self::find( (int) FKC_DB::conn()->lastInsertId() );
	}

	/** @return array{bool, string, int|null} */
	public static function creer( array $d ) {
		self::ensure();
		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom du magasin ou du dépôt est obligatoire.', null ); }
		$code = strtoupper( trim( (string) ( $d['code'] ?? '' ) ) );
		if ( '' === $code ) {
			$code = strtoupper( substr( preg_replace( '/[^A-Za-z0-9]/', '', $libelle ), 0, 8 ) ) ?: 'DEP';
		}
		$base = $code; $i = 2;
		while ( FKC_DB::q( 'SELECT 1 FROM inv_entrepots WHERE code=?', array( $code ) )->fetch() ) { $code = $base . $i; $i++; }

		FKC_DB::q( 'INSERT INTO inv_entrepots(code,libelle,adresse,principal,actif) VALUES(?,?,?,?,1)', array(
			$code, $libelle, trim( (string) ( $d['adresse'] ?? '' ) ) ?: null,
			! empty( $d['principal'] ) ? 1 : 0,
		) );
		$id = (int) FKC_DB::conn()->lastInsertId();
		if ( ! empty( $d['principal'] ) ) {
			FKC_DB::q( 'UPDATE inv_entrepots SET principal=0 WHERE id<>?', array( $id ) );
		}
		return array( true, '« ' . $libelle . ' » créé.', $id );
	}

	/* ── Ventilation ─────────────────────────────────────────────────────── */

	/** Quantité d'un article dans UN dépôt. */
	public static function stock( $articleId, $depotId ) {
		self::ensure();
		$v = FKC_DB::q( 'SELECT qte FROM vp_stock_depot WHERE pack=? AND article_id=? AND depot_id=?',
			array( self::pack(), (int) $articleId, (int) $depotId ) )->fetchColumn();
		return false === $v ? 0.0 : (float) $v;
	}

	/** Répartition d'un article sur tous ses dépôts. */
	public static function repartition( $articleId ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT s.depot_id, s.qte, e.libelle, e.code FROM vp_stock_depot s
			 JOIN inv_entrepots e ON e.id=s.depot_id
			 WHERE s.pack=? AND s.article_id=? AND s.qte <> 0 ORDER BY e.principal DESC, e.libelle",
			array( self::pack(), (int) $articleId )
		)->fetchAll();
	}

	/** Ajoute (ou retire, si négatif) une quantité dans un dépôt. */
	public static function ajuster( $articleId, $depotId, $delta ) {
		self::ensure();
		if ( ! $depotId ) { return; }
		FKC_DB::q(
			'INSERT INTO vp_stock_depot(pack,article_id,depot_id,qte) VALUES(?,?,?,?)
			 ON CONFLICT(pack,article_id,depot_id) DO UPDATE SET qte = qte + excluded.qte',
			array( self::pack(), (int) $articleId, (int) $depotId, (float) $delta )
		);
	}

	/**
	 * Une sortie est-elle possible DEPUIS CE DÉPÔT ?
	 *
	 * Le stock global peut dire oui alors que le dépôt dit non — c'est
	 * précisément le cas que le multi-dépôt existe pour révéler. Le message
	 * indique où se trouve la marchandise, parce que la question suivante du
	 * vendeur est toujours « alors elle est où ? ».
	 *
	 * @return array{bool, string}
	 */
	public static function controlerSortie( array $article, $qte, $depotId ) {
		self::ensure();
		if ( ! $depotId ) { return array( true, '' ); }
		$dispo = self::stock( (int) $article['id'], (int) $depotId );
		if ( (float) $qte <= $dispo + 0.00001 ) { return array( true, '' ); }

		$d = self::find( $depotId );
		$msg = 'Stock insuffisant dans « ' . ( $d['libelle'] ?? 'ce dépôt' ) . ' » : ' . fkc_money( $dispo ) . ' ' . $article['unite'] . ' sur place.';
		$ailleurs = array();
		foreach ( self::repartition( (int) $article['id'] ) as $r ) {
			if ( (int) $r['depot_id'] === (int) $depotId || (float) $r['qte'] <= 0 ) { continue; }
			$ailleurs[] = fkc_money( $r['qte'] ) . ' à « ' . $r['libelle'] . ' »';
		}
		if ( $ailleurs ) { $msg .= ' Disponible ailleurs : ' . implode( ', ', $ailleurs ) . ' — faites un transfert.'; }
		return array( false, $msg );
	}

	/* ── Transfert ───────────────────────────────────────────────────────── */

	/**
	 * Déplace de la marchandise d'un dépôt à un autre.
	 *
	 * AUCUNE ÉCRITURE COMPTABLE n'est générée, et ce n'est pas un oubli : le
	 * patrimoine de l'entreprise n'a pas bougé, seule sa localisation a
	 * changé. Constater une sortie et une entrée en comptabilité ferait
	 * apparaître un achat et une vente à soi-même.
	 *
	 * Le stock GLOBAL de l'article est également inchangé — seule la
	 * ventilation bouge. C'est pourquoi ce transfert ne passe pas par
	 * vente()/entree(), qui toucheraient au CUMP.
	 *
	 * @return array{bool, string}
	 */
	public static function transferer( $articleId, $qte, $depotSource, $depotDest, $motif = '' ) {
		self::ensure();
		$a = FKC_VpStock::article( $articleId );
		if ( ! $a ) { return array( false, 'Article introuvable.' ); }
		$qte = (float) $qte;
		if ( $qte <= 0 ) { return array( false, 'La quantité à transférer doit être positive.' ); }
		if ( (int) $depotSource === (int) $depotDest ) {
			return array( false, 'Le dépôt de départ et celui d\'arrivée sont les mêmes.' );
		}
		$src = self::find( $depotSource ); $dst = self::find( $depotDest );
		if ( ! $src || ! $dst ) { return array( false, 'Dépôt de départ ou d\'arrivée introuvable.' ); }

		list( $ok, $msg ) = self::controlerSortie( $a, $qte, (int) $depotSource );
		if ( ! $ok ) { return array( false, $msg ); }

		try {
			FKC_Tx::executer( function () use ( $a, $qte, $depotSource, $depotDest, $src, $dst, $motif ) {
				self::ajuster( (int) $a['id'], (int) $depotSource, -$qte );
				self::ajuster( (int) $a['id'], (int) $depotDest, $qte );
				/*
				 * Le mouvement est tracé en sens « transfert » : ni entrée ni
				 * sortie. Le compter comme une sortie fausserait le chiffre
				 * d'affaires et les statistiques de vente de la journée.
				 */
				FKC_DB::q(
					'INSERT INTO vp_mouvements(pack,article_id,sens,qte,pu,montant,motif,depot_id,depot_dest_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',
					array( self::pack(), (int) $a['id'], 'transfert', $qte, (float) $a['cump'], round( $qte * (float) $a['cump'], 2 ),
						'Transfert ' . $src['libelle'] . ' → ' . $dst['libelle'] . ( $motif ? ' — ' . trim( (string) $motif ) : '' ),
						(int) $depotSource, (int) $depotDest, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
				);
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'VpDepot::transferer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Transfert annulé : aucune modification n\'a été enregistrée.' );
		}
		return array( true, fkc_money( $qte ) . ' ' . $a['unite'] . ' transférés de « ' . $src['libelle'] . ' » vers « ' . $dst['libelle']
			. ' ». Aucune écriture comptable : votre patrimoine n\'a pas changé, seulement sa localisation.' );
	}

	/* ── Rattrapage ──────────────────────────────────────────────────────── */

	/**
	 * Affecte au dépôt principal tout stock qui n'est ventilé nulle part.
	 *
	 * Sans ce rattrapage, activer le multi-dépôt ferait passer d'un coup tout
	 * le stock existant à « zéro partout » : l'écran global afficherait
	 * toujours les quantités, mais plus aucune vente ne passerait. C'est le
	 * genre de bascule qui bloque un magasin un lundi matin.
	 *
	 * @return int Nombre d'articles rattachés.
	 */
	public static function rattraper() {
		self::ensure();
		$principal = self::principal();
		if ( ! $principal ) { return 0; }
		$rows = FKC_DB::q(
			"SELECT a.id, a.qte_stock FROM vp_articles a
			 WHERE a.pack=? AND a.qte_stock <> 0
			   AND NOT EXISTS ( SELECT 1 FROM vp_stock_depot s WHERE s.pack=a.pack AND s.article_id=a.id )",
			array( self::pack() )
		)->fetchAll();
		foreach ( $rows as $r ) { self::ajuster( (int) $r['id'], (int) $principal['id'], (float) $r['qte_stock'] ); }
		return count( $rows );
	}

	/**
	 * Écart entre le stock global d'un article et la somme de ses dépôts.
	 *
	 * Il devrait toujours valoir zéro. S'il ne vaut pas zéro, c'est qu'un
	 * mouvement a été enregistré sans dépôt — et mieux vaut le savoir par un
	 * contrôle que le découvrir à l'inventaire.
	 */
	public static function ecart( $articleId ) {
		self::ensure();
		$a = FKC_VpStock::article( $articleId );
		if ( ! $a ) { return 0.0; }
		$somme = (float) FKC_DB::q( 'SELECT COALESCE(SUM(qte),0) FROM vp_stock_depot WHERE pack=? AND article_id=?',
			array( self::pack(), (int) $articleId ) )->fetchColumn();
		return round( (float) $a['qte_stock'] - $somme, 4 );
	}

	/** Tous les articles dont la ventilation ne colle pas au stock global. */
	public static function ecarts() {
		self::ensure();
		$out = array();
		foreach ( FKC_VpStock::articles() as $a ) {
			$e = self::ecart( (int) $a['id'] );
			if ( abs( $e ) > 0.0001 ) { $out[] = array( 'article' => $a, 'ecart' => $e ); }
		}
		return $out;
	}

	/** Valeur du stock par dépôt (au CUMP global — voir l'en-tête). */
	public static function valeurParDepot() {
		self::ensure();
		try {
			$rows = FKC_DB::q(
				"SELECT e.libelle, COALESCE(SUM(s.qte * a.cump),0) valeur
				 FROM vp_stock_depot s JOIN vp_articles a ON a.id=s.article_id
				 JOIN inv_entrepots e ON e.id=s.depot_id
				 WHERE s.pack=? GROUP BY e.id ORDER BY valeur DESC",
				array( self::pack() )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		$out = array();
		foreach ( $rows as $r ) { $out[ $r['libelle'] ] = (float) $r['valeur']; }
		return $out;
	}
}
