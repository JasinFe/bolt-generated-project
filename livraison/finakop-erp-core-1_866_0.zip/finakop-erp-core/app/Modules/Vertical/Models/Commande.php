<?php
/**
 * MOTEUR DE COMMANDES CLIENTS (COM-045) — cycle commercial B2B (COM-003).
 *
 * Complète la famille Commerce & Distribution avec les quatre étapes de
 * votre table qui manquaient encore : Devis (proposition commerciale) →
 * Commande (engagement client) → Livraison (sortie physique) → Facture
 * (créance). Les étapes suivantes — Avoir, Encaissement, Retour — existent
 * déjà (COM-002/006/017) et ne sont pas reconstruites ici.
 *
 * POURQUOI LIVRAISON ET FACTURATION SONT DEUX GESTES SÉPARÉS
 *
 * `FKC_VpStock::vente()`/`venteCredit()` font sortir le stock ET posent la
 * créance dans le même geste — juste pour un comptoir, où les deux
 * coïncident toujours. Une commande B2B ne se comporte pas comme ça : elle
 * se livre souvent en plusieurs fois (rupture partielle, plusieurs
 * camions), et la facture ne doit porter que ce qui a RÉELLEMENT été livré
 * et accepté — jamais une quantité encore incertaine. `livrer()` ne
 * décrémente que le stock physique (`FKC_VpStock::sortirStockSansEcriture()`,
 * COM-045) ; `facturer()` regroupe ensuite tout ce qui a été livré et pas
 * encore facturé en UNE facture, en passant par le même moteur générique que
 * `venteCredit()` (FKC_Facture, FKC_CreditManagement) — jamais dupliqué.
 *
 * LIMITE ASSUMÉE DE CETTE PREMIÈRE VERSION
 *
 * facturer() facture, en un seul geste, tout ce qui est livré-et-pas-encore-
 * facturé sur la commande entière — pas ligne par ligne, pas en plusieurs
 * factures partielles étalées dans le temps. C'est le même choix que
 * l'avoir de COM-017 : couvrir le cas réel le plus courant (facturer au fur
 * et à mesure des livraisons) sans construire un moteur de facturation
 * partielle multi-lots, qui est un chantier à part entière.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpCommande {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_commandes(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				numero TEXT NOT NULL,
				client_id INTEGER NOT NULL,
				client_nom TEXT,
				statut TEXT NOT NULL DEFAULT 'devis',
				dossier_id INTEGER,
				notes TEXT,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, numero)
			);
			CREATE INDEX IF NOT EXISTS idx_vpc_pack ON vp_commandes(pack, statut);
			CREATE TABLE IF NOT EXISTS vp_commande_lignes(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				commande_id INTEGER NOT NULL,
				article_id INTEGER NOT NULL,
				qte REAL NOT NULL,
				pu REAL NOT NULL,
				qte_livree REAL NOT NULL DEFAULT 0,
				qte_facturee REAL NOT NULL DEFAULT 0,
				FOREIGN KEY(commande_id) REFERENCES vp_commandes(id) ON DELETE CASCADE
			);
			CREATE INDEX IF NOT EXISTS idx_vpcl_commande ON vp_commande_lignes(commande_id);
			CREATE TABLE IF NOT EXISTS vp_acomptes(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				commande_id INTEGER NOT NULL,
				montant REAL NOT NULL,
				moyen TEXT,
				ecriture_id INTEGER,
				facture_id INTEGER,
				date_acompte TEXT NOT NULL,
				created_by INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				FOREIGN KEY(commande_id) REFERENCES vp_commandes(id) ON DELETE CASCADE
			);
			CREATE INDEX IF NOT EXISTS idx_vpacc_commande ON vp_acomptes(commande_id);
		" );
		// 1.865.0 — devis chantier : chaque ligne peut appartenir à une étape (fondations, gros œuvre…).
		try { FKC_DB::conn()->exec( "ALTER TABLE vp_commande_lignes ADD COLUMN etape TEXT DEFAULT ''" ); } catch ( \Throwable $e ) { /* déjà présente */ }
		/*
		 * 1.857.0 — IMPUTATION PARTIELLE. Un acompte de 100 000 sur une
		 * commande facturée en deux fois (60 000 puis 50 000) n'était marqué
		 * « imputé » que s'il tenait entier dans une facture : il restait donc
		 * disponible après la première, et la seconde le déduisait EN
		 * ENTIER — 110 000 imputés pour 100 000 reçus. On suit désormais le
		 * montant déjà imputé.
		 */
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_acomptes ADD COLUMN montant_impute REAL NOT NULL DEFAULT 0' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready[ self::cleBaseReady() ] = true;
	}

	/*
	 * 1.857.0 — SCHÉMAS D'ACOMPTE COMMUNS. Seul le pack Électroménager
	 * déclarait les siens : dans les sept autres packs à commandes, un
	 * acompte encaissé n'était jamais comptabilisé (la caisse et la dette
	 * envers le client manquaient au grand livre). Le pack garde la main —
	 * son schéma, s'il en déclare un, l'emporte.
	 */
	const EVT_ACOMPTE = 'vp_acompte';
	const EVT_IMPUTATION = 'vp_acompte_imputation';
	const EVT_REMBOURSEMENT = 'vp_acompte_remboursement';

	protected static function schemasCommuns() {
		self::schemaRemboursement();
		if ( ! class_exists( 'FKC_Posting' ) || FKC_Posting::has( self::EVT_ACOMPTE ) ) { return; }
		FKC_Posting::register( array(
			self::EVT_ACOMPTE => array(
				'journal' => 'CS',
				'libelle' => 'Acompte reçu — {tiers}',
				'lignes'  => array(
					array( 'role' => 'TRESORERIE', 'compte' => '571100', 'compte_libelle' => 'Caisse',
						'sens' => 'D', 'montant' => 'montant', 'libelle' => 'Acompte {tiers}' ),
					array( 'compte' => '419100', 'compte_libelle' => 'Clients, avances et acomptes reçus',
						'sens' => 'C', 'montant' => 'montant', 'libelle' => 'Acompte {tiers}', 'tiers' => true ),
				),
			),
			self::EVT_IMPUTATION => array(
				'journal' => 'OD',
				'libelle' => 'Imputation d\'acompte — {tiers}',
				'lignes'  => array(
					array( 'compte' => '419100', 'compte_libelle' => 'Clients, avances et acomptes reçus',
						'sens' => 'D', 'montant' => 'montant', 'libelle' => 'Imputation {tiers}', 'tiers' => true ),
					// 1.864.0 — le compte propre du client, celui que la facture a débité.
					array( 'compte' => '{compte_client}', 'compte_repli' => '411100', 'compte_libelle' => 'Clients',
						'sens' => 'C', 'montant' => 'montant', 'libelle' => 'Imputation {tiers}', 'tiers' => true ),
				),
			),
		), 'socle:commerce' );
	}

	protected static function schemaRemboursement() {
		if ( ! class_exists( 'FKC_Posting' ) || FKC_Posting::has( self::EVT_REMBOURSEMENT ) ) { return; }
		FKC_Posting::register( array(
			self::EVT_REMBOURSEMENT => array(
				'journal' => 'CS',
				'libelle' => 'Remboursement d\'acompte — {tiers}',
				'lignes'  => array(
					array( 'compte' => '{compte_avance}', 'compte_repli' => '419100', 'compte_libelle' => 'Clients, avances et acomptes reçus',
						'sens' => 'D', 'montant' => 'montant', 'libelle' => 'Remboursement {tiers}', 'tiers' => true ),
					array( 'role' => 'TRESORERIE', 'compte' => '571100', 'compte_libelle' => 'Caisse',
						'sens' => 'C', 'montant' => 'montant', 'libelle' => 'Remboursement acompte {tiers}' ),
				),
			),
		), 'socle:commerce' );
	}

	/** Événement d'acompte du pack, ou le schéma commun. */
	public static function evtAcompte( array $cfg, $imputation = false ) {
		$evt = (string) ( $cfg['stock'][ $imputation ? 'evt_acompte_imputation' : 'evt_acompte' ] ?? '' );
		if ( '' !== $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) { return $evt; }
		self::schemasCommuns();
		return $imputation ? self::EVT_IMPUTATION : self::EVT_ACOMPTE;
	}

	/** Total TTC d'une commande (TVA résolue article par article, comme à la facture). */
	public static function totalTtc( array $c, array $cfg ) {
		$t = 0.0;
		foreach ( $c['lignes'] as $l ) {
			$ht = round( (float) $l['qte'] * (float) $l['pu'], 2 );
			$a = FKC_VpStock::article( (int) $l['article_id'] );
			$tva = $a ? (float) FKC_VpStock::resolverTva( $a, $cfg ) : 0.0;
			$t += round( $ht + round( $ht * $tva / 100, 2 ), 2 );
		}
		return round( $t, 2 );
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	public static function statuts() {
		return array(
			'devis'            => 'Devis',
			'confirmee'        => 'Confirmée',
			'livree_partielle' => 'Livrée partiellement',
			'livree'           => 'Livrée',
			'facturee'         => 'Facturée',
			'annulee'          => 'Annulée',
		);
	}

	/**
	 * Prochain numéro de commande.
	 *
	 * Le rang vient du PLUS GRAND numéro attribué, non du nombre de commandes
	 * existantes (1.616.0). Compter suppose que rien ne disparaît jamais :
	 * après une suppression, le compte retombe et la commande suivante
	 * réutilise un numéro déjà vivant.
	 *
	 * Cette série n'est PAS annuelle — elle court depuis l'origine du dossier,
	 * par pack — d'où le calcul local plutôt qu'un appel à FKC_Numerotation,
	 * dont toutes les séries sont datées. La lui confier lui ferait recommencer
	 * à 1 chaque 1er janvier, sur des numéros déjà attribués.
	 */
	protected static function nextNumero() {
		$max = 0;
		try {
			foreach ( FKC_DB::q( 'SELECT numero FROM vp_commandes WHERE pack=?', array( self::pack() ) )->fetchAll() as $r ) {
				$suffixe = substr( (string) $r['numero'], 4 );   // « CMD-0042 » → « 0042 »
				if ( 0 === strpos( (string) $r['numero'], 'CMD-' ) && ctype_digit( $suffixe ) ) {
					$max = max( $max, (int) $suffixe );
				}
			}
		} catch ( \Throwable $e ) { $max = 0; }
		return sprintf( 'CMD-%04d', $max + 1 );
	}

	public static function all( $statut = null ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( $statut ) { $w .= ' AND statut=?'; $p[] = $statut; }
		return FKC_DB::q( "SELECT * FROM vp_commandes {$w} ORDER BY id DESC", $p )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$c = FKC_DB::q( 'SELECT * FROM vp_commandes WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		if ( ! $c ) { return null; }
		$c['lignes'] = FKC_DB::q(
			'SELECT l.*, a.libelle AS article_libelle, a.unite, a.reference AS article_ref
			 FROM vp_commande_lignes l JOIN vp_articles a ON a.id=l.article_id
			 WHERE l.commande_id=? ORDER BY l.id', array( (int) $id )
		)->fetchAll();
		return $c;
	}

	/**
	 * DEVIS — proposition commerciale, sans aucun effet sur le stock ni la
	 * comptabilité. $lignes : array de { article_id, qte, pu (facultatif —
	 * repli sur le prix de vente catalogue) }.
	 * @return array{bool, string, int|null} ( ok, message, id )
	 */
	public static function creerDevis( $clientId, array $lignes, $dossierId = null, $notes = '' ) {
		self::ensure();
		if ( ! class_exists( 'FKC_Client' ) ) { return array( false, 'Le module Facturation n\'est pas disponible.', null ); }
		$client = FKC_Client::find( (int) $clientId );
		if ( ! $client ) { return array( false, 'Client introuvable : choisissez un client du référentiel (ou créez-le d\'abord).', null ); }

		$clean = array();
		foreach ( $lignes as $l ) {
			$aid = (int) ( $l['article_id'] ?? 0 );
			$qte = fkc_nombre( $l['qte'] ?? 0 );
			if ( ! $aid || $qte <= 0 ) { continue; }
			$a = FKC_VpStock::article( $aid );
			if ( ! $a ) { return array( false, 'Un article de la commande est introuvable.', null ); }
			// 1.864.0 — saisie « 150 000 » acceptée ; sans prix, le tarif applicable au client et à la quantité.
			$pu = isset( $l['pu'] ) && '' !== trim( (string) $l['pu'] ) ? fkc_nombre( $l['pu'] )
				: ( class_exists( 'FKC_VpTarif' ) ? (float) ( FKC_VpTarif::resoudre( $a, $qte, $clientId )['prix'] ?? $a['prix_vente'] ) : (float) $a['prix_vente'] );
			if ( $pu < 0 ) { return array( false, 'Prix invalide sur une ligne.', null ); }
			$clean[] = array( 'article_id' => $aid, 'qte' => $qte, 'pu' => $pu, 'etape' => mb_substr( trim( (string) ( $l['etape'] ?? '' ) ), 0, 60 ) );
		}
		if ( ! $clean ) { return array( false, 'Ajoutez au moins une ligne avec une quantité positive.', null ); }

		return FKC_Tx::executer( function () use ( $clientId, $client, $clean, $dossierId, $notes ) {
			FKC_DB::q(
				'INSERT INTO vp_commandes(pack,numero,client_id,client_nom,statut,dossier_id,notes,created_by) VALUES(?,?,?,?,?,?,?,?)',
				array( self::pack(), self::nextNumero(), (int) $clientId, $client['nom'], 'devis',
					$dossierId ? (int) $dossierId : null, trim( (string) $notes ) ?: null, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
			);
			$id = (int) FKC_DB::conn()->lastInsertId();
			foreach ( $clean as $l ) {
				FKC_DB::q( 'INSERT INTO vp_commande_lignes(commande_id,article_id,qte,pu,etape) VALUES(?,?,?,?,?)',
					array( $id, $l['article_id'], $l['qte'], $l['pu'], $l['etape'] ?? '' ) );
			}
			$c = FKC_DB::q( 'SELECT numero FROM vp_commandes WHERE id=?', array( $id ) )->fetch();
			return array( true, 'Devis ' . $c['numero'] . ' créé pour ' . $client['nom'] . '.', $id );
		} );
	}

	/** COMMANDE — le devis devient un engagement du client. Aucun effet stock/compta : juste un changement d'état. */
	public static function confirmer( $id ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Commande introuvable.' ); }
		if ( 'devis' !== $c['statut'] ) { return array( false, 'Seul un devis peut être confirmé (statut actuel : ' . ( self::statuts()[ $c['statut'] ] ?? $c['statut'] ) . ').' ); }
		FKC_DB::q( "UPDATE vp_commandes SET statut='confirmee' WHERE id=?", array( (int) $id ) );
		return array( true, 'Commande ' . $c['numero'] . ' confirmée — engagement du client enregistré.' );
	}

	public static function annuler( $id, $motif = '', $moyenRemboursement = '' ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Commande introuvable.' ); }
		$dejaLivre = array_sum( array_column( $c['lignes'], 'qte_livree' ) );
		if ( $dejaLivre > 0 ) {
			return array( false, 'Impossible d\'annuler : des articles ont déjà été livrés sur cette commande. Passez par un retour (COM-017) si nécessaire.' );
		}
		if ( in_array( $c['statut'], array( 'facturee', 'annulee' ), true ) ) {
			return array( false, 'Cette commande ne peut plus être annulée (statut : ' . ( self::statuts()[ $c['statut'] ] ?? $c['statut'] ) . ').' );
		}
		/*
		 * 1.864.0 — ACOMPTE D'UNE COMMANDE ANNULÉE. L'avance restait au 419
		 * du client, sans chemin pour la lui rendre : une dette éternelle au
		 * bilan et un client qui attend son argent. L'annulation rembourse
		 * désormais l'avance non imputée (même moyen, ou celui indiqué).
		 */
		$avance = round( self::acomptesNonImputes( (int) $id ), 2 );
		$suffixe = '';
		if ( $avance > 0.009 ) {
			list( $okR, $msgR ) = self::rembourserAcompte( $c, $avance, $moyenRemboursement );
			if ( ! $okR ) { return array( false, 'Annulation impossible : ' . $msgR ); }
			$suffixe = ' ' . $msgR;
		}
		FKC_DB::q( "UPDATE vp_commandes SET statut='annulee', notes=? WHERE id=?",
			array( trim( ( $c['notes'] ? $c['notes'] . ' — ' : '' ) . 'Annulée : ' . ( $motif ?: 'sans motif' ) ), (int) $id ) );
		return array( true, 'Commande ' . $c['numero'] . ' annulée.' . $suffixe );
	}

	/**
	 * LIVRAISON — sortie physique du stock, PAS de facture. $quantites :
	 * array [ ligne_id => qté à livrer maintenant ] — permet une livraison
	 * partielle, répétable jusqu'à épuisement de chaque ligne.
	 * @return array{bool, string} ( ok, message )
	 */
	/**
	 * @param array $series 1.864.0 — ligne_id => numéros de série livrés (articles suivis par IMEI / série)
	 */
	public static function livrer( $id, array $quantites, array $series = array() ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Commande introuvable.' ); }
		if ( ! in_array( $c['statut'], array( 'confirmee', 'livree_partielle' ), true ) ) {
			return array( false, 'Seule une commande confirmée peut être livrée (statut actuel : ' . ( self::statuts()[ $c['statut'] ] ?? $c['statut'] ) . ').' );
		}
		$aLivrer = array();
		foreach ( $c['lignes'] as $l ) {
			$qte = (float) ( $quantites[ $l['id'] ] ?? 0 );
			if ( $qte <= 0 ) { continue; }
			$restant = (float) $l['qte'] - (float) $l['qte_livree'];
			if ( $qte > $restant + 0.00001 ) {
				return array( false, $l['article_libelle'] . ' : impossible de livrer ' . fkc_money( $qte ) . ' ' . $l['unite'] . ', il n\'en reste que ' . fkc_money( $restant ) . ' à livrer sur cette commande.' );
			}
			/*
			 * 1.864.0 — ARTICLE SUIVI PAR NUMÉRO DE SÉRIE. La livraison sortait
			 * la quantité sans consommer aucun numéro : l'IMEI livré restait
			 * « en stock », revendable une seconde fois, et la garantie du
			 * client n'était jamais ouverte.
			 */
			$art = FKC_VpStock::article( (int) $l['article_id'] );
			$num = array();
			if ( $art && ! empty( $art['serialise'] ) && class_exists( 'FKC_VpSerie' ) ) {
				$num = FKC_VpStock::seriesEnTableau( $series[ $l['id'] ] ?? null );
				list( $okS, $msgS ) = FKC_VpSerie::validerSortie( (int) $l['article_id'], $num, $qte );
				if ( ! $okS ) { return array( false, $l['article_libelle'] . ' : ' . $msgS ); }
			}
			$aLivrer[] = array( 'ligne' => $l, 'qte' => $qte, 'series' => $num, 'article' => $art );
		}
		if ( ! $aLivrer ) { return array( false, 'Indiquez au moins une quantité à livrer.' ); }

		try {
			return FKC_Tx::executer( function () use ( $c, $aLivrer ) {
				foreach ( $aLivrer as $x ) {
					list( $ok, $msg, $movId ) = FKC_VpStock::sortirStockSansEcriture(
						(int) $x['ligne']['article_id'], $x['qte'], 'Livraison ' . $c['numero'], $c['dossier_id'] ?? null, null, (float) $x['ligne']['pu']
					);
					if ( ! $ok ) { throw new \RuntimeException( $x['ligne']['article_libelle'] . ' : ' . $msg ); }
					/*
					 * 1.857.0 — COÛT DES VENTES À LA LIVRAISON. La marchandise
					 * quitte le magasin maintenant : c'est maintenant que le
					 * stock (31) doit baisser, au CUMP, même si la facture ne
					 * part que dans huit jours.
					 */
					$art = FKC_VpStock::article( (int) $x['ligne']['article_id'] );
					if ( $art && $movId ) {
						// 1.865.0 — au coût des lots consommés quand l'article est suivi par lots.
						$coutLot = FKC_VpStock::coutLotSortie( $art, (float) $x['qte'], (int) $movId );
						FKC_VpStock::constaterCout( class_exists( 'FKC_Packs' ) ? (array) FKC_Packs::verticalConfig() : array(), $art,
							null !== $coutLot ? $coutLot : round( (float) $x['qte'] * (float) $art['cump'], 2 ), 'sortie', (int) $movId, 'Coût des ventes — livraison ' . $c['numero'] );
						if ( null !== $coutLot ) {
							$avantLiv = $art; $avantLiv['qte_stock'] = (float) $art['qte_stock'] + (float) $x['qte'];
							FKC_VpStock::reajusterCump( $avantLiv, (float) $x['qte'], $coutLot );
						}
					}
					/*
					 * TRAÇABILITÉ DE LA LIVRAISON (1.622.0). Le mouvement
					 * portait seulement le libellé « Livraison N° » : un
					 * texte, pas un lien. On inscrit la commande ET la ligne,
					 * ce qui permet ensuite de savoir exactement ce qui a été
					 * livré, ce qui reste à facturer, et de répondre à
					 * « quelle livraison explique cette facture ? ».
					 */
					if ( $movId ) {
						try {
							FKC_DB::q( 'UPDATE vp_mouvements SET commande_id=?, commande_ligne_id=? WHERE id=?',
								array( (int) $c['id'], (int) $x['ligne']['id'], (int) $movId ) );
						} catch ( \Throwable $e ) { /* colonne absente sur une base ancienne : la livraison reste juste */ }
						if ( class_exists( 'FKC_ChaineDoc' ) ) {
							FKC_ChaineDoc::poserSilencieux( 'commande', (int) $c['id'], 'mouvement_stock', (int) $movId, 'livre' );
						}
					}
					if ( $movId && $x['series'] && class_exists( 'FKC_VpSerie' ) ) {
						FKC_VpSerie::consommerVente( (int) $x['ligne']['article_id'], $x['series'], (int) $movId );
					}
					if ( $movId && $art && class_exists( 'FKC_VpApresVente' ) ) {
						$cli = ( ! empty( $c['client_id'] ) && class_exists( 'FKC_Client' ) ) ? FKC_Client::find( (int) $c['client_id'] ) : null;
						FKC_VpApresVente::garantiesAutoVente( $art, (int) $movId, $x['qte'], class_exists( 'FKC_Packs' ) ? (array) FKC_Packs::verticalConfig() : array(), $x['series'] ?: null, $cli ?: null );
					}
					FKC_DB::q( 'UPDATE vp_commande_lignes SET qte_livree = qte_livree + ? WHERE id=?', array( $x['qte'], (int) $x['ligne']['id'] ) );
				}
				$fresh = self::find( (int) $c['id'] );
				$totalQte = array_sum( array_column( $fresh['lignes'], 'qte' ) );
				$totalLivree = array_sum( array_column( $fresh['lignes'], 'qte_livree' ) );
				$statut = ( $totalLivree >= $totalQte - 0.00001 ) ? 'livree' : 'livree_partielle';
				FKC_DB::q( 'UPDATE vp_commandes SET statut=? WHERE id=?', array( $statut, (int) $c['id'] ) );
				return array( true, 'Livraison enregistrée sur ' . $c['numero'] . ' (' . ( self::statuts()[ $statut ] ?? $statut ) . ').' );
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpCommande::livrer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Livraison annulée : ' . $e->getMessage() );
		}
	}

	/**
	 * FACTURATION — regroupe tout ce qui est livré et pas encore facturé en
	 * UNE facture (toujours à crédit : c'est le sens même d'une commande
	 * B2B — voir la note de limite en tête de fichier). Réutilise le même
	 * moteur que venteCredit() (FKC_Facture, FKC_CreditManagement) : rien de
	 * dupliqué.
	 * @return array{bool, string, int|null} ( ok, message, id facture )
	 */
	/* ── ACOMPTES (ELM-002) ───────────────────────────────────────────────
	 *
	 * Un acompte n'est PAS un produit. Encaisser 30 % sur un réfrigérateur
	 * commandé ne vend rien : la marchandise n'est pas livrée, le transfert
	 * de propriété n'a pas eu lieu, et la TVA n'est pas exigible sur une
	 * livraison de biens. L'argent reçu est une DETTE envers le client tant
	 * que la commande n'est pas honorée — d'où le compte 4191, « Clients,
	 * avances et acomptes reçus », au passif.
	 *
	 * Le comptabiliser en vente gonflerait le chiffre d'affaires du mois de
	 * la commande, ferait payer une TVA non due, et laisserait une seconde
	 * constatation à la facturation : le même argent compté deux fois.
	 *
	 * À la facturation, l'acompte s'IMPUTE : D 4191 / C 411 — la dette
	 * s'éteint, la créance client diminue d'autant, et il ne reste dû que le
	 * solde. */

	/** @return array{bool, string, int|null} */
	public static function acompte( $id, $montant, array $cfg, $moyen = 'especes' ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Commande introuvable.', null ); }
		if ( 'annulee' === (string) $c['statut'] ) { return array( false, 'Commande annulée : aucun acompte ne peut y être encaissé.', null ); }
		if ( 'devis' === (string) $c['statut'] ) {
			return array( false, 'Un devis n\'engage personne — confirmez la commande avant d\'encaisser un acompte.', null );
		}
		$montant = round( (float) $montant, 2 );
		if ( $montant <= 0 ) { return array( false, 'Le montant de l\'acompte doit être positif.', null ); }

		/*
		 * Un acompte ne peut pas dépasser ce qui reste dû sur la commande :
		 * au-delà, ce n'est plus une avance mais un trop-perçu, qui appelle un
		 * remboursement et non une écriture d'acompte.
		 */
		/*
		 * 1.857.0 — le client paie TTC : le plafond l'est aussi. Comparé au
		 * seul HT, un acompte couvrant la commande entière était refusé
		 * (18 % de TVA de trop, disait-on, alors qu'elle est due).
		 */
		$total = self::totalTtc( $c, $cfg );
		$deja  = self::totalAcomptes( (int) $c['id'] );
		if ( $montant > ( $total - $deja ) + 0.01 ) {
			return array( false, 'Acompte trop élevé : la commande représente ' . fkc_money( $total ) . ' F TTC et '
				. fkc_money( $deja ) . ' F ont déjà été reçus. Au-delà, ce serait un trop-perçu à rembourser, pas une avance.', null );
		}

		$evt = self::evtAcompte( $cfg );
		$eid = null; $suffixe = '';
		$moyenCode = ( '' !== trim( (string) $moyen ) && class_exists( 'FKC_MoyenPaiement' ) ) ? FKC_MoyenPaiement::normaliser( $moyen ) : '';
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			list( $okP, $msgP, $eidP ) = FKC_Posting::emettre( $evt, array(
				'montant' => $montant, 'ttc' => $montant, 'ht' => $montant, 'tva' => 0,
				'client' => $c['client_nom'], 'tiers' => $c['client_nom'],
				// 1.857.0 : le client porte la ligne 419 (compte auxiliaire),
				// et le moyen choisit le compte de trésorerie.
				'tiers_type' => 'client', 'tiers_id' => (int) $c['client_id'], 'moyen' => $moyenCode,
				'piece' => 'ACO-' . $c['numero'], 'date' => date( 'Y-m-d' ),
			) );
			if ( $okP ) { $eid = $eidP; }
			else { $suffixe = ' ⚠ La comptabilisation a échoué (' . $msgP . ') — l\'acompte est enregistré, mais aucune écriture n\'a été générée.'; }
		} else {
			$suffixe = ' ⚠ Aucun schéma « acompte » n\'est déclaré pour ce métier : l\'encaissement est enregistré, mais pas comptabilisé.';
		}

		FKC_DB::q(
			'INSERT INTO vp_acomptes(pack,commande_id,montant,moyen,ecriture_id,date_acompte,created_by) VALUES(?,?,?,?,?,?,?)',
			array( self::pack(), (int) $c['id'], $montant, (string) $moyen, $eid, date( 'Y-m-d' ),
				class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null )
		);
		$acoId = (int) FKC_DB::conn()->lastInsertId();
		if ( class_exists( 'FKC_ChaineDoc' ) ) {
			FKC_ChaineDoc::poserSilencieux( 'commande', (int) $c['id'], 'acompte', $acoId, 'acompte' );
		}
		return array( true, 'Acompte de ' . fkc_money( $montant ) . ' F reçu sur ' . $c['numero']
			. ' — enregistré comme avance client, pas comme vente.' . $suffixe, $acoId );
	}

	/**
	 * Livre tout le reste d'une étape de chantier (1.865.0 — recommandation 6
	 * de l'audit 1.857.0) : les lignes de l'étape sont livrées ensemble.
	 */
	public static function livrerEtape( $id, $etape, array $series = array() ) {
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Commande introuvable.' ); }
		$q = array();
		foreach ( $c['lignes'] as $l ) {
			if ( (string) ( $l['etape'] ?? '' ) !== (string) $etape ) { continue; }
			$reste = (float) $l['qte'] - (float) $l['qte_livree'];
			if ( $reste > 0.00001 ) { $q[ (int) $l['id'] ] = $reste; }
		}
		if ( ! $q ) { return array( false, 'Rien à livrer sur l\'étape « ' . $etape . ' ».' ); }
		list( $ok, $msg ) = self::livrer( $id, $q, $series );
		return array( $ok, $ok ? 'Étape « ' . $etape . ' » livrée. ' . $msg : $msg );
	}

	/** Étapes d'une commande, avec leur montant et leur avancement. */
	public static function etapes( array $c ) {
		$out = array();
		foreach ( $c['lignes'] as $l ) {
			$e = (string) ( $l['etape'] ?? '' );
			if ( '' === $e ) { continue; }
			if ( ! isset( $out[ $e ] ) ) { $out[ $e ] = array( 'montant' => 0.0, 'livre' => 0.0 ); }
			$out[ $e ]['montant'] += (float) $l['qte'] * (float) $l['pu'];
			$out[ $e ]['livre'] += (float) $l['qte_livree'] * (float) $l['pu'];
		}
		return $out;
	}

	/** Rembourse l'avance non imputée d'une commande (D 419 client / C trésorerie). */
	protected static function rembourserAcompte( array $c, $montant, $moyen = '' ) {
		self::schemasCommuns();
		$acs = FKC_DB::q( 'SELECT * FROM vp_acomptes WHERE pack=? AND commande_id=? AND montant - montant_impute > 0.004 ORDER BY id', array( self::pack(), (int) $c['id'] ) )->fetchAll();
		$moyen = '' !== trim( (string) $moyen ) ? $moyen : (string) ( $acs[0]['moyen'] ?? 'espece' );
		$moyenCode = class_exists( 'FKC_MoyenPaiement' ) ? FKC_MoyenPaiement::normaliser( $moyen ) : '';
		$cli = ( ! empty( $c['client_id'] ) && class_exists( 'FKC_Client' ) ) ? FKC_Client::find( (int) $c['client_id'] ) : null;
		if ( class_exists( 'FKC_Posting' ) && FKC_Posting::has( self::EVT_REMBOURSEMENT ) ) {
			list( $ok, $msg ) = FKC_Posting::emettre( self::EVT_REMBOURSEMENT, array(
				'montant' => $montant, 'client' => $c['client_nom'], 'tiers' => $c['client_nom'],
				'tiers_type' => 'client', 'tiers_id' => (int) $c['client_id'], 'moyen' => $moyenCode,
				'compte_avance' => self::compteAvance(), 'piece' => 'RMB-' . $c['numero'], 'date' => date( 'Y-m-d' ),
			) );
			if ( ! $ok ) { return array( false, 'remboursement de l\'acompte refusé en comptabilité (' . $msg . ').' ); }
		}
		foreach ( $acs as $ac ) {
			FKC_DB::q( 'UPDATE vp_acomptes SET montant_impute=montant WHERE id=?', array( (int) $ac['id'] ) );
		}
		return array( true, 'Acompte de ' . fkc_money( $montant ) . ' F remboursé à ' . ( $cli['nom'] ?? $c['client_nom'] ) . '.' );
	}

	/** Compte d'avances du pack (419350 en électroménager, 419100 sinon). */
	protected static function compteAvance() {
		$cfg = class_exists( 'FKC_Packs' ) ? (array) FKC_Packs::verticalConfig() : array();
		$evt = self::evtAcompte( $cfg );
		foreach ( (array) ( FKC_Posting::schema( $evt )['lignes'] ?? array() ) as $l ) {
			if ( 0 === strpos( (string) ( $l['compte'] ?? '' ), '419' ) ) { return (string) $l['compte']; }
		}
		return '419100';
	}

	public static function acomptes( $commandeId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM vp_acomptes WHERE pack=? AND commande_id=? ORDER BY id',
			array( self::pack(), (int) $commandeId ) )->fetchAll();
	}

	public static function totalAcomptes( $commandeId ) {
		self::ensure();
		return (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant),0) FROM vp_acomptes WHERE pack=? AND commande_id=?',
			array( self::pack(), (int) $commandeId ) )->fetchColumn();
	}

	public static function acomptesNonImputes( $commandeId ) {
		self::ensure();
		return (float) FKC_DB::q( 'SELECT COALESCE(SUM(montant - montant_impute),0) FROM vp_acomptes WHERE pack=? AND commande_id=? AND montant - montant_impute > 0.004',
			array( self::pack(), (int) $commandeId ) )->fetchColumn();
	}

	/**
	 * Impute les acomptes reçus sur la facture qui vient d'être émise :
	 * D 4191 / C 411. La dette envers le client s'éteint, sa créance diminue,
	 * et il ne reste dû que le solde.
	 *
	 * @return array{0:float,1:string} ( montant imputé, message éventuel )
	 */
	protected static function imputerAcomptes( $commandeId, $factureId, array $cfg, $ttcFacture ) {
		$restant = self::acomptesNonImputes( $commandeId );
		if ( $restant <= 0 ) { return array( 0.0, '' ); }

		// On n'impute jamais plus que la facture : un acompte qui excède la
		// première facture d'une commande livrée en plusieurs fois reste
		// disponible pour la suivante.
		$aImputer = min( $restant, round( (float) $ttcFacture, 2 ) );
		if ( $aImputer <= 0 ) { return array( 0.0, '' ); }

		$suffixe = '';
		$evt = self::evtAcompte( $cfg, true );
		$cmd = self::find( $commandeId );
		if ( $evt && class_exists( 'FKC_Posting' ) && FKC_Posting::has( $evt ) ) {
			list( $okP, $msgP ) = FKC_Posting::emettre( $evt, array(
				'montant' => $aImputer, 'ttc' => $aImputer, 'ht' => $aImputer, 'tva' => 0,
				// 1.857.0 : sans le client, le 411 général était crédité et le
				// compte du client restait débiteur de l'avance déjà payée.
				'client' => (string) ( $cmd['client_nom'] ?? '' ), 'tiers' => (string) ( $cmd['client_nom'] ?? '' ),
				'tiers_type' => 'client', 'tiers_id' => (int) ( $cmd['client_id'] ?? 0 ),
				// 1.864.0 — le compte propre du client, celui que la facture a débité.
				'compte_client' => (string) ( ( ! empty( $cmd['client_id'] ) && class_exists( 'FKC_Client' ) ? ( FKC_Client::find( (int) $cmd['client_id'] )['compte'] ?? '' ) : '' ) ?: FKC_PlanMetier::COMPTE_CLIENT ),
				'piece' => 'IMP-' . (int) $factureId, 'date' => date( 'Y-m-d' ),
			) );
			if ( ! $okP ) { $suffixe = ' ⚠ L\'imputation comptable de l\'acompte a échoué (' . $msgP . ').'; }
		} else {
			$suffixe = ' ⚠ Aucun schéma d\'imputation d\'acompte n\'est déclaré : la facture ne déduit pas l\'avance en comptabilité.';
		}

		// Marquage FIFO : les plus anciens acomptes s'imputent en premier,
		// y compris en partie (1.857.0) ; facture_id désigne la dernière
		// facture qui a consommé l'acompte.
		$reste = $aImputer;
		foreach ( self::acomptes( $commandeId ) as $ac ) {
			if ( $reste <= 0.001 ) { break; }
			$dispo = (float) $ac['montant'] - (float) ( $ac['montant_impute'] ?? 0 );
			if ( $dispo <= 0.004 ) { continue; }
			$pris = min( $dispo, $reste );
			FKC_DB::q( 'UPDATE vp_acomptes SET montant_impute = montant_impute + ?, facture_id=? WHERE id=?', array( $pris, (int) $factureId, (int) $ac['id'] ) );
			$reste -= $pris;
		}
		return array( $aImputer, $suffixe );
	}

	public static function facturer( $id, array $cfg, $forcerEncours = false ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Commande introuvable.', null ); }
		if ( ! class_exists( 'FKC_Facture' ) || ! class_exists( 'FKC_Client' ) ) {
			return array( false, 'Le module Facturation n\'est pas disponible.', null );
		}
		if ( in_array( $c['statut'], array( 'devis', 'confirmee', 'annulee' ), true ) ) {
			return array( false, 'Rien n\'a encore été livré sur cette commande — livrez avant de facturer.', null );
		}
		$client = FKC_Client::find( (int) $c['client_id'] );
		if ( ! $client ) { return array( false, 'Client introuvable.', null ); }

		$aFacturer = array();
		$ttcPrevisionnel = 0.0;
		foreach ( $c['lignes'] as $l ) {
			$delta = (float) $l['qte_livree'] - (float) $l['qte_facturee'];
			if ( $delta <= 0.00001 ) { continue; }
			$a = FKC_VpStock::article( $l['article_id'] );
			if ( ! $a ) { continue; }
			$tva = FKC_VpStock::resolverTva( $a, $cfg );
			$ht  = round( $delta * (float) $l['pu'], 2 );
			$aFacturer[] = array(
				'ligne_id' => $l['id'], 'delta' => $delta, 'designation' => $l['article_libelle'],
				'pu' => (float) $l['pu'], 'unite' => $l['unite'], 'tva' => $tva,
				'compte' => FKC_VpStock::compteVenteFor( $cfg, $tva, $a ), 'ht' => $ht,
			);
			$ttcPrevisionnel += round( $ht + round( $ht * $tva / 100, 2 ), 2 );
		}
		if ( ! $aFacturer ) { return array( false, 'Rien à facturer : tout ce qui a été livré est déjà facturé.', null ); }

		/* COM-006, comme venteCredit() : même contrôle, même possibilité de forcer. */
		$avisMsg = '';
		if ( class_exists( 'FKC_CreditManagement' ) ) {
			// 1.857.0 : l'avance déjà reçue n'est pas un risque de crédit.
			$avis = FKC_CreditManagement::avisCommande( (int) $client['id'], max( 0, $ttcPrevisionnel - self::acomptesNonImputes( (int) $c['id'] ) ) );
			if ( 'refus' === ( $avis['avis'] ?? '' ) && ! $forcerEncours ) {
				return array( false, 'Facturation refusée par le contrôle d\'encours — ' . ( $avis['message'] ?? '' )
					. ' Cochez « forcer » pour passer outre si la situation le justifie.', null );
			}
			if ( in_array( $avis['avis'] ?? '', array( 'attention', 'refus' ), true ) ) {
				$avisMsg = ' ⚠ Contrôle d\'encours : ' . ( $avis['message'] ?? '' );
			}
		}

		try {
			return FKC_Tx::executer( function () use ( $c, $client, $aFacturer, $avisMsg, $cfg ) {
				$delai = max( 0, (int) ( $client['delai_paiement'] ?? 0 ) );
				$lignesFacture = array();
				foreach ( $aFacturer as $x ) {
					$lignesFacture[] = array(
						'designation' => $x['designation'], 'quantite' => $x['delta'], 'pu_ht' => $x['pu'],
						'tva_code' => FKC_VpStock::codeTvaFor( $x['tva'] ), 'unite' => $x['unite'], 'compte' => $x['compte'],
					);
				}
				list( $ok, $msg, $fid ) = FKC_Facture::save(
					array(
						'client_id' => (int) $client['id'], 'client_nom' => $client['nom'],
						'date_facture' => date( 'Y-m-d' ), 'echeance' => date( 'Y-m-d', strtotime( '+' . $delai . ' days' ) ),
						'devise' => $client['devise'] ?? 'XOF', 'payment_method' => 'credit', 'template' => 'standard',
						'created_by' => class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null,
						'division_id' => $c['dossier_id'] ? FKC_VpDossier::ensureDivision( (int) $c['dossier_id'] ) : null,
					),
					$lignesFacture
				);
				if ( ! $ok ) { throw new \RuntimeException( $msg ); }

				list( $okC, $msgC, $eid ) = FKC_Facture::comptabiliser( $fid );
				if ( ! $okC ) { throw new \RuntimeException( 'Comptabilisation : ' . $msgC ); }
				if ( $eid ) { FKC_DB::q( "UPDATE factures SET statut='validee' WHERE id=? AND statut='brouillon'", array( $fid ) ); }

				foreach ( $aFacturer as $x ) {
					FKC_DB::q( 'UPDATE vp_commande_lignes SET qte_facturee = qte_facturee + ? WHERE id=?', array( $x['delta'], (int) $x['ligne_id'] ) );
				}

				/*
				 * « QUELLE LIVRAISON EXPLIQUE CETTE FACTURE ? » (1.622.0)
				 *
				 * Les mouvements de livraison de cette commande qui n'étaient
				 * rattachés à aucune facture le sont maintenant à celle-ci.
				 * Sans ce marquage, la marchandise livrée restait
				 * indéfiniment « sortie et non facturée », y compris après
				 * facturation : le contrôle d'intégrité aurait signalé comme
				 * anomalie une situation parfaitement saine, et on aurait
				 * appris à l'ignorer.
				 *
				 * Le rattachement se fait sur les mouvements NON ENCORE
				 * facturés, pas sur tous : une commande facturée en deux fois
				 * ne doit pas voir sa première facture réécrite par la
				 * seconde.
				 */
				$movs = array();
				try {
					foreach ( FKC_DB::q(
						"SELECT id FROM vp_mouvements WHERE commande_id=? AND sens='sortie' AND facture_id IS NULL",
						array( (int) $c['id'] )
					)->fetchAll() as $m ) { $movs[] = (int) $m['id']; }
					if ( $movs ) {
						$place = implode( ',', array_fill( 0, count( $movs ), '?' ) );
						FKC_DB::q( 'UPDATE vp_mouvements SET facture_id=? WHERE id IN (' . $place . ')',
							array_merge( array( (int) $fid ), $movs ) );
					}
				} catch ( \Throwable $e ) { /* colonne absente : la facture reste juste */ }

				if ( class_exists( 'FKC_ChaineDoc' ) ) {
					FKC_ChaineDoc::poserSilencieux( 'commande', (int) $c['id'], 'facture', (int) $fid, 'facture' );
					foreach ( $movs as $mid ) {
						FKC_ChaineDoc::poserSilencieux( 'mouvement_stock', $mid, 'facture', (int) $fid, 'facture' );
					}
				}
				$fresh = self::find( (int) $c['id'] );
				$totalQte = array_sum( array_column( $fresh['lignes'], 'qte' ) );
				$totalFacturee = array_sum( array_column( $fresh['lignes'], 'qte_facturee' ) );
				if ( $totalFacturee >= $totalQte - 0.00001 ) {
					FKC_DB::q( "UPDATE vp_commandes SET statut='facturee' WHERE id=?", array( (int) $c['id'] ) );
				}

				$f = FKC_Facture::find( $fid );
				$ttcF = (float) ( $f['montant_ttc'] ?? 0 );
				// ELM-002 : l'avance déjà reçue s'impute ici — sans quoi le
				// client se verrait réclamer une seconde fois ce qu'il a payé
				// à la commande.
				list( $impute, $msgImp ) = self::imputerAcomptes( (int) $c['id'], $fid, $cfg, $ttcF );
				$detteMsg = $impute > 0
					? ' Acompte de ' . fkc_money( $impute ) . ' F imputé — solde dû : ' . fkc_money( max( 0, $ttcF - $impute ) ) . ' F.'
					: '';
				return array( true,
					'Facture ' . ( $f['numero'] ?? '' ) . ' créée sur ' . $c['numero'] . ' — ' . fkc_money( $ttcF ) . ' F TTC.' . $detteMsg . $avisMsg . $msgImp,
					$fid,
				);
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'FKC_VpCommande::facturer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Facturation annulée : ' . $e->getMessage(), null );
		}
	}

	/**
	 * Commandes confirmées au client et jamais livrées.
	 *
	 * ─────────────────────────────────────────────────────────────────────
	 * LE SYMÉTRIQUE DES COMMANDES D'ACHAT DORMANTES (1.677.0)
	 *
	 * Le côté achat a son contrôle depuis 1.651.0 — une commande passée et
	 * jamais reçue immobilise du budget. Le côté VENTE n'avait pas le sien,
	 * et l'oubli coûte davantage : une commande confirmée ENGAGE l'entreprise
	 * envers son client. Passé quelques semaines, ce n'est plus un délai de
	 * préparation — la commande a été oubliée, le stock manquait, ou le
	 * dossier a été classé sans suite.
	 *
	 * CE QUE CELA COÛTE NE SE VOYAIT NULLE PART. Le chiffre d'affaires
	 * n'arrive pas, le client attend sans être prévenu, et la marchandise
	 * qu'il a réservée reste immobilisée. Aucun des dix-neuf contrôles
	 * existants ne le disait : `livraisonsNonFacturees` regarde ce qui EST
	 * sorti, jamais ce qui aurait dû sortir.
	 *
	 * UN DEVIS N'Y FIGURE PAS. Il n'engage personne — c'est une proposition,
	 * et une proposition sans suite est le métier ordinaire d'un commerçant.
	 * Seule la CONFIRMATION crée l'obligation.
	 *
	 * @param int $jours Délai de préparation au-delà duquel l'attente est anormale.
	 * @return array
	 */
	public static function commandesNonLivrees( $jours = 30, $limit = 50 ) {
		$limit = max( 1, min( 200, (int) $limit ) );
		$avant = date( 'Y-m-d', time() - max( 1, (int) $jours ) * 86400 );
		try {
			$lignes = FKC_DB::q(
				"SELECT c.* FROM vp_commandes c
				 WHERE c.statut='confirmee' AND date(c.created_at) <= ?
				 ORDER BY c.created_at ASC LIMIT " . $limit,
				array( $avant )
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }

		$out = array();
		foreach ( $lignes as $l ) {
			try {
				$r = FKC_DB::q(
					'SELECT COALESCE(SUM(qte),0) q, COALESCE(SUM(qte_livree),0) v FROM vp_commande_lignes WHERE commande_id=?',
					array( (int) $l['id'] )
				)->fetch();
				$reste = round( (float) $r['q'] - (float) $r['v'], 4 );
			} catch ( \Throwable $e ) { $reste = 0.0; }
			// Une commande confirmée dont tout est livré n'attend plus rien,
			// même si son statut n'a pas suivi : on ne signale que le dû.
			if ( $reste <= 0.0001 ) { continue; }
			$l['a_livrer'] = $reste;
			$out[] = $l;
		}
		return $out;
	}
}
