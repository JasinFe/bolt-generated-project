<?php
/**
 * ATTRIBUTS PRODUIT DYNAMIQUES (BAZ-002) — le commerçant décrit ses produits
 * avec SON vocabulaire.
 *
 * LE PROBLÈME
 *
 * Une fiche article livrait sept champs fixes : libellé, référence, catégorie,
 * unité, prix, stock, seuil. C'est suffisant pour un boulon. Ce ne l'est pas
 * pour un matelas (densité, épaisseur, dimensions), un tissu (matière,
 * laize, grammage), un climatiseur (BTU, classe énergétique, gaz) ni un tapis
 * (fibre, tissage). Un pack ne peut PAS connaître d'avance les
 * caractéristiques de produits qu'il ne connaît pas : il doit connaître les
 * RÈGLES, et laisser le commerçant écrire le reste.
 *
 * LA RÈGLE QUI SÉPARE UN ATTRIBUT D'UNE VARIANTE — à ne jamais perdre de vue
 *
 *   Si la caractéristique doit avoir SON PROPRE STOCK ou SON PROPRE PRIX,
 *   c'est une VARIANTE (COM-021, un vrai article rattaché à un modèle).
 *   Sinon, c'est un ATTRIBUT.
 *
 * Un matelas 140×190 et un 160×200 sont deux variantes : on en compte deux
 * piles distinctes et on les vend à deux prix. Leur densité et leur matière
 * sont des attributs : elles décrivent, elles ne se comptent pas. Confondre
 * les deux produit un catalogue où le stock ment — c'est l'erreur classique,
 * et cette brique refuse par construction d'y participer : elle ne touche ni
 * à `qte_stock`, ni au prix, ni à aucune écriture.
 *
 * PORTÉE : GLOBALE OU PAR CATÉGORIE
 *
 * Un attribut sans catégorie s'applique à tout le catalogue (« Marque »,
 * « Pays d'origine »). Un attribut rattaché à une catégorie n'apparaît que
 * sur ses articles — et sur ceux de ses sous-catégories, parce qu'une
 * caractéristique vraie pour « Réfrigérateurs » l'est aussi pour
 * « Réfrigérateurs › Combinés ». C'est cet héritage qui évite de redéclarer
 * les mêmes six champs sous chaque sous-rayon.
 *
 * SIX TYPES, PAS DAVANTAGE
 *
 * texte, nombre, booleen, liste, date, dimension. La dimension est le seul
 * type « métier » : elle porte une unité (cm, m, kg…) affichée avec la
 * valeur, parce qu'un 190 sans unité ne veut rien dire sur une fiche matelas.
 * Tout le reste se ramène à ces six-là ; en ajouter d'autres serait déplacer
 * la complexité du commerçant vers le paramétrage.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpAttribut {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_attributs(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				code TEXT NOT NULL,
				libelle TEXT NOT NULL,
				type TEXT NOT NULL DEFAULT 'texte',
				categorie_id INTEGER,
				options TEXT,
				unite TEXT,
				obligatoire INTEGER NOT NULL DEFAULT 0,
				ordre INTEGER NOT NULL DEFAULT 100,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, code)
			);
			CREATE INDEX IF NOT EXISTS idx_vpatt_pack ON vp_attributs(pack, actif, ordre);
			CREATE INDEX IF NOT EXISTS idx_vpatt_cat ON vp_attributs(categorie_id);
			CREATE TABLE IF NOT EXISTS vp_attribut_valeurs(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				article_id INTEGER NOT NULL,
				attribut_id INTEGER NOT NULL,
				valeur TEXT,
				UNIQUE(article_id, attribut_id),
				FOREIGN KEY(attribut_id) REFERENCES vp_attributs(id) ON DELETE CASCADE
			);
			CREATE INDEX IF NOT EXISTS idx_vpattv_article ON vp_attribut_valeurs(article_id);
		" );
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/** Les six types, avec leur libellé d'écran. */
	public static function types() {
		return array(
			'texte'     => 'Texte libre',
			'nombre'    => 'Nombre',
			'booleen'   => 'Oui / Non',
			'liste'     => 'Liste de choix',
			'date'      => 'Date',
			'dimension' => 'Dimension (avec unité)',
		);
	}

	public static function typeValide( $type ) {
		return array_key_exists( (string) $type, self::types() );
	}

	/* ── Définitions ─────────────────────────────────────────────────────── */

	public static function tous( $inclureInactifs = false ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( ! $inclureInactifs ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_attributs {$w} ORDER BY categorie_id IS NOT NULL, ordre, libelle", $p )->fetchAll();
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_attributs WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	public static function parCode( $code ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_attributs WHERE code=? AND pack=?', array( (string) $code, self::pack() ) )->fetch();
		return $r ?: null;
	}

	/**
	 * Attributs applicables à une catégorie : les GLOBAUX (sans catégorie),
	 * ceux de la catégorie elle-même, et ceux de sa catégorie PARENTE — une
	 * caractéristique vraie d'un rayon l'est de ses sous-rayons.
	 *
	 * @param int|null $categorieId null = uniquement les attributs globaux.
	 */
	public static function pourCategorie( $categorieId = null, $inclureInactifs = false ) {
		self::ensure();
		$ids = array();
		if ( $categorieId ) {
			$ids[] = (int) $categorieId;
			if ( class_exists( 'FKC_VpCategorie' ) ) {
				$c = FKC_VpCategorie::find( (int) $categorieId );
				if ( $c && ! empty( $c['parent_id'] ) ) { $ids[] = (int) $c['parent_id']; }
			}
		}
		$w = 'WHERE pack=? AND (categorie_id IS NULL';
		$p = array( self::pack() );
		if ( $ids ) {
			$w .= ' OR categorie_id IN (' . implode( ',', array_map( 'intval', $ids ) ) . ')';
		}
		$w .= ')';
		if ( ! $inclureInactifs ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_attributs {$w} ORDER BY categorie_id IS NOT NULL, ordre, libelle", $p )->fetchAll();
	}

	/** Attributs applicables à un ARTICLE (via sa catégorie). */
	public static function pourArticle( array $article, $inclureInactifs = false ) {
		return self::pourCategorie( ! empty( $article['categorie_id'] ) ? (int) $article['categorie_id'] : null, $inclureInactifs );
	}

	/** @return array{bool, string, int|null} */
	public static function creer( array $d ) {
		self::ensure();
		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom de la caractéristique est obligatoire.', null ); }

		$type = (string) ( $d['type'] ?? 'texte' );
		if ( ! self::typeValide( $type ) ) { return array( false, 'Type de caractéristique inconnu.', null ); }

		$options = self::optionsNettoyees( $d['options'] ?? '' );
		if ( 'liste' === $type && count( $options ) < 2 ) {
			return array( false, 'Une liste de choix a besoin d\'au moins deux valeurs possibles — sinon il n\'y a rien à choisir.', null );
		}

		$categorieId = ! empty( $d['categorie_id'] ) ? (int) $d['categorie_id'] : null;
		if ( $categorieId && class_exists( 'FKC_VpCategorie' ) && ! FKC_VpCategorie::find( $categorieId ) ) {
			return array( false, 'La catégorie choisie est introuvable.', null );
		}
		if ( self::libelleExiste( $libelle, $categorieId ) ) {
			return array( false, 'Une caractéristique « ' . $libelle . ' » existe déjà à cette portée.', null );
		}

		try {
			FKC_DB::q(
				'INSERT INTO vp_attributs(pack,code,libelle,type,categorie_id,options,unite,obligatoire,ordre,actif) VALUES(?,?,?,?,?,?,?,?,?,1)',
				array(
					self::pack(), self::codeLibre( $libelle ), $libelle, $type, $categorieId,
					$options ? json_encode( array_values( $options ), JSON_UNESCAPED_UNICODE ) : null,
					'dimension' === $type ? ( trim( (string) ( $d['unite'] ?? '' ) ) ?: null ) : null,
					! empty( $d['obligatoire'] ) ? 1 : 0,
					isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : self::prochainOrdre( $categorieId ),
				)
			);
		} catch ( \Throwable $e ) {
			return array( false, 'Création impossible : ' . $e->getMessage(), null );
		}
		return array( true, 'Caractéristique « ' . $libelle . ' » créée.', (int) FKC_DB::conn()->lastInsertId() );
	}

	/**
	 * Modifie une définition.
	 *
	 * LE TYPE NE CHANGE JAMAIS. Passer « Épaisseur » de nombre à liste
	 * rendrait d'un coup invalides toutes les valeurs déjà saisies sur les
	 * articles — sans qu'aucun écran ne puisse dire laquelle était juste.
	 * Un besoin réel de changer de type se traite en créant la bonne
	 * caractéristique et en retirant l'ancienne, geste explicite et visible.
	 *
	 * @return array{bool, string}
	 */
	public static function modifier( $id, array $d ) {
		self::ensure();
		$a = self::find( $id );
		if ( ! $a ) { return array( false, 'Caractéristique introuvable.' ); }

		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom de la caractéristique est obligatoire.' ); }

		if ( isset( $d['type'] ) && (string) $d['type'] !== (string) $a['type'] ) {
			return array( false, 'Le type d\'une caractéristique ne se change pas : les valeurs déjà saisies sur les articles deviendraient invalides sans qu\'on puisse dire lesquelles. Créez la bonne caractéristique et retirez celle-ci.' );
		}

		$categorieId = array_key_exists( 'categorie_id', $d )
			? ( ! empty( $d['categorie_id'] ) ? (int) $d['categorie_id'] : null )
			: ( $a['categorie_id'] ? (int) $a['categorie_id'] : null );
		if ( $categorieId && class_exists( 'FKC_VpCategorie' ) && ! FKC_VpCategorie::find( $categorieId ) ) {
			return array( false, 'La catégorie choisie est introuvable.' );
		}
		if ( self::libelleExiste( $libelle, $categorieId, (int) $a['id'] ) ) {
			return array( false, 'Une caractéristique « ' . $libelle . ' » existe déjà à cette portée.' );
		}

		$options = self::optionsNettoyees( $d['options'] ?? self::options( $a ) );
		if ( 'liste' === (string) $a['type'] && count( $options ) < 2 ) {
			return array( false, 'Une liste de choix a besoin d\'au moins deux valeurs possibles.' );
		}
		/*
		 * Retirer une valeur d'une liste alors que des articles la portent
		 * les laisserait avec une valeur que le formulaire ne sait plus
		 * proposer — invisible tant qu'on ne rouvre pas la fiche, puis perdue
		 * au premier enregistrement. On refuse, en disant lesquelles.
		 */
		if ( 'liste' === (string) $a['type'] ) {
			$orphelines = self::valeursOrphelines( (int) $a['id'], $options );
			if ( $orphelines ) {
				return array( false, 'Impossible de retirer ' . implode( ', ', array_map( function ( $v ) { return '« ' . $v . ' »'; }, $orphelines ) )
					. ' : des articles portent encore cette valeur. Modifiez ces articles d\'abord.' );
			}
		}

		FKC_DB::q(
			'UPDATE vp_attributs SET libelle=?, categorie_id=?, options=?, unite=?, obligatoire=?, ordre=?, actif=? WHERE id=? AND pack=?',
			array(
				$libelle, $categorieId,
				$options ? json_encode( array_values( $options ), JSON_UNESCAPED_UNICODE ) : null,
				'dimension' === (string) $a['type'] ? ( trim( (string) ( $d['unite'] ?? $a['unite'] ?? '' ) ) ?: null ) : null,
				! empty( $d['obligatoire'] ) ? 1 : 0,
				isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : (int) $a['ordre'],
				array_key_exists( 'actif', $d ) ? ( ! empty( $d['actif'] ) ? 1 : 0 ) : (int) $a['actif'],
				(int) $a['id'], self::pack(),
			)
		);
		return array( true, 'Caractéristique mise à jour.' );
	}

	public static function basculer( $id ) {
		self::ensure();
		$a = self::find( $id );
		if ( ! $a ) { return array( false, 'Caractéristique introuvable.' ); }
		$nouvel = empty( $a['actif'] ) ? 1 : 0;
		FKC_DB::q( 'UPDATE vp_attributs SET actif=? WHERE id=? AND pack=?', array( $nouvel, (int) $a['id'], self::pack() ) );
		return array( true, $nouvel
			? 'Caractéristique « ' . $a['libelle'] . ' » réactivée.'
			: 'Caractéristique « ' . $a['libelle'] . ' » retirée des fiches — les valeurs déjà saisies restent conservées.' );
	}

	/**
	 * Supprime une définition ET les valeurs saisies. Le nombre d'articles
	 * concernés est annoncé AVANT (voir compteValeurs) : effacer une
	 * caractéristique renseignée sur deux cents articles n'est pas un geste
	 * anodin, et l'écran doit le dire.
	 */
	public static function supprimer( $id ) {
		self::ensure();
		$a = self::find( $id );
		if ( ! $a ) { return array( false, 'Caractéristique introuvable.' ); }
		$n = self::compteValeurs( (int) $a['id'] );
		try {
			FKC_Tx::executer( function () use ( $a ) {
				FKC_DB::q( 'DELETE FROM vp_attribut_valeurs WHERE attribut_id=?', array( (int) $a['id'] ) );
				FKC_DB::q( 'DELETE FROM vp_attributs WHERE id=? AND pack=?', array( (int) $a['id'], self::pack() ) );
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'VpAttribut::supprimer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Suppression impossible : aucune modification n\'a été enregistrée.' );
		}
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'attribut_supprime', 'Pack ' . self::pack() . ' — « ' . $a['libelle'] . ' » (' . $n . ' valeur(s))' );
		}
		return array( true, 'Caractéristique « ' . $a['libelle'] . ' » supprimée'
			. ( $n ? ', ainsi que les ' . $n . ' valeur(s) saisie(s) sur les articles.' : '.' ) );
	}

	/* ── Valeurs portées par les articles ────────────────────────────────── */

	/** Valeurs brutes d'un article : code d'attribut => valeur. */
	public static function valeurs( $articleId ) {
		self::ensure();
		$rows = FKC_DB::q(
			'SELECT a.code, v.valeur FROM vp_attribut_valeurs v JOIN vp_attributs a ON a.id=v.attribut_id WHERE v.article_id=? AND a.pack=?',
			array( (int) $articleId, self::pack() )
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) { $out[ (string) $r['code'] ] = $r['valeur']; }
		return $out;
	}

	/** Valeurs par identifiant d'attribut (ce dont les formulaires ont besoin). */
	public static function valeursParId( $articleId ) {
		self::ensure();
		$rows = FKC_DB::q( 'SELECT attribut_id, valeur FROM vp_attribut_valeurs WHERE article_id=?', array( (int) $articleId ) )->fetchAll();
		$out = array();
		foreach ( $rows as $r ) { $out[ (int) $r['attribut_id'] ] = $r['valeur']; }
		return $out;
	}

	/**
	 * Caractéristiques d'un article, prêtes à afficher : libellé, valeur
	 * formatée (Oui/Non, unité accolée à une dimension), type.
	 *
	 * @return array<int,array{code:string,libelle:string,type:string,valeur:string,brut:string}>
	 */
	public static function fiche( array $article ) {
		$vals = self::valeursParId( (int) $article['id'] );
		$out  = array();
		foreach ( self::pourArticle( $article ) as $att ) {
			$brut = $vals[ (int) $att['id'] ] ?? null;
			if ( null === $brut || '' === $brut ) { continue; }
			$out[] = array(
				'code'    => (string) $att['code'],
				'libelle' => (string) $att['libelle'],
				'type'    => (string) $att['type'],
				'valeur'  => self::formater( $att, $brut ),
				'brut'    => (string) $brut,
			);
		}
		return $out;
	}

	/** Rendu lisible d'une valeur selon son type. */
	public static function formater( array $att, $valeur ) {
		$v = (string) $valeur;
		switch ( (string) $att['type'] ) {
			case 'booleen':
				return ( '1' === $v || 'oui' === strtolower( $v ) ) ? 'Oui' : 'Non';
			case 'dimension':
				$u = trim( (string) ( $att['unite'] ?? '' ) );
				return $u ? $v . ' ' . $u : $v;
			case 'nombre':
				return is_numeric( $v ) ? fkc_money( $v, ( (float) $v == (int) $v ) ? 0 : 2 ) : $v;
			default:
				return $v;
		}
	}

	/**
	 * Enregistre les valeurs d'un article. Attend le tableau POST
	 * `attributs[{attribut_id}] = valeur`. Toutes les valeurs sont VALIDÉES
	 * avant qu'une seule ne soit écrite : une fiche à moitié enregistrée est
	 * pire qu'un refus.
	 *
	 * @return array{bool, string}
	 */
	public static function enregistrer( $articleId, array $saisie, ?array $article = null ) {
		self::ensure();
		$article = $article ?: ( class_exists( 'FKC_VpStock' ) ? FKC_VpStock::article( $articleId ) : null );
		if ( ! $article ) { return array( false, 'Article introuvable.' ); }

		$applicables = self::pourArticle( $article );
		if ( ! $applicables ) { return array( true, '' ); }

		$aEcrire = array();
		foreach ( $applicables as $att ) {
			$id  = (int) $att['id'];
			$brut = array_key_exists( $id, $saisie ) ? $saisie[ $id ] : null;
			$brut = is_array( $brut ) ? implode( ', ', $brut ) : ( null === $brut ? '' : trim( (string) $brut ) );

			if ( '' === $brut ) {
				if ( ! empty( $att['obligatoire'] ) ) {
					return array( false, '« ' . $att['libelle'] . ' » est une caractéristique obligatoire pour cet article.' );
				}
				$aEcrire[ $id ] = null;
				continue;
			}
			list( $ok, $msg, $normalise ) = self::valider( $att, $brut );
			if ( ! $ok ) { return array( false, $msg ); }
			$aEcrire[ $id ] = $normalise;
		}

		try {
			FKC_Tx::executer( function () use ( $articleId, $aEcrire ) {
				foreach ( $aEcrire as $attId => $val ) {
					if ( null === $val ) {
						FKC_DB::q( 'DELETE FROM vp_attribut_valeurs WHERE article_id=? AND attribut_id=?', array( (int) $articleId, (int) $attId ) );
						continue;
					}
					FKC_DB::q(
						'INSERT INTO vp_attribut_valeurs(article_id,attribut_id,valeur) VALUES(?,?,?)
						 ON CONFLICT(article_id,attribut_id) DO UPDATE SET valeur=excluded.valeur',
						array( (int) $articleId, (int) $attId, (string) $val )
					);
				}
			} );
		} catch ( \Throwable $e ) {
			fkc_log( 'VpAttribut::enregistrer ' . $e->getMessage(), 'ERROR' );
			return array( false, 'Les caractéristiques n\'ont pas pu être enregistrées.' );
		}
		return array( true, '' );
	}

	/**
	 * Valide UNE valeur selon le type de sa caractéristique.
	 * @return array{0:bool,1:string,2:string|null} ( ok, message, valeur normalisée )
	 */
	public static function valider( array $att, $valeur ) {
		$v = trim( (string) $valeur );
		switch ( (string) $att['type'] ) {
			case 'nombre':
			case 'dimension':
				$v = str_replace( array( ' ', ',' ), array( '', '.' ), $v );
				if ( ! is_numeric( $v ) ) {
					return array( false, '« ' . $att['libelle'] .' » attend un nombre — « ' . $valeur . ' » n\'en est pas un.', null );
				}
				return array( true, '', (string) ( 0 + $v ) );

			case 'booleen':
				$vrai = in_array( strtolower( $v ), array( '1', 'oui', 'true', 'on' ), true );
				return array( true, '', $vrai ? '1' : '0' );

			case 'date':
				/*
				 * Le format écrit ici est JJ/MM/AAAA. date_create() lit une
				 * date à slash comme une date AMÉRICAINE : « 15/03/2026 »
				 * y devient un mois 15, donc une erreur, alors que
				 * « 03/04/2026 » passerait en silence pour le 4 mars. On
				 * essaie donc le format local D'ABORD — c'est le seul moyen
				 * qu'une date saisie normalement veuille dire ce qu'elle dit.
				 */
				$d = false;
				foreach ( array( 'd/m/Y', 'd-m-Y', 'd.m.Y' ) as $fmt ) {
					$essai = DateTime::createFromFormat( $fmt, $v );
					if ( $essai && $essai->format( $fmt ) === $v ) { $d = $essai; break; }
				}
				if ( ! $d ) { $d = date_create( $v ); }
				if ( ! $d ) {
					return array( false, '« ' . $att['libelle'] . ' » attend une date — « ' . $valeur . ' » n\'a pas pu être lue.', null );
				}
				return array( true, '', $d->format( 'Y-m-d' ) );

			case 'liste':
				$opts = self::options( $att );
				if ( $opts && ! in_array( $v, $opts, true ) ) {
					return array( false, '« ' . $v . ' » ne fait pas partie des choix possibles pour « ' . $att['libelle'] . ' » (' . implode( ', ', $opts ) . ').', null );
				}
				return array( true, '', $v );

			default:
				return array( true, '', $v );
		}
	}

	/** Efface les valeurs d'un article (appelé quand l'article est supprimé). */
	public static function oublierArticle( $articleId ) {
		self::ensure();
		try { FKC_DB::q( 'DELETE FROM vp_attribut_valeurs WHERE article_id=?', array( (int) $articleId ) ); }
		catch ( \Throwable $e ) { fkc_log( 'VpAttribut::oublierArticle ' . $e->getMessage(), 'ERROR' ); }
	}

	/* ── Utilitaires ─────────────────────────────────────────────────────── */

	/** Choix possibles d'un attribut de type liste. */
	public static function options( array $att ) {
		if ( empty( $att['options'] ) ) { return array(); }
		$dec = json_decode( (string) $att['options'], true );
		return is_array( $dec ) ? array_values( array_map( 'strval', $dec ) ) : array();
	}

	/** Nombre d'articles portant une valeur pour cette caractéristique. */
	public static function compteValeurs( $attributId ) {
		self::ensure();
		try {
			return (int) FKC_DB::q( "SELECT COUNT(*) FROM vp_attribut_valeurs WHERE attribut_id=? AND valeur IS NOT NULL AND TRIM(valeur)<>''", array( (int) $attributId ) )->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	/** Valeurs de liste encore portées par des articles mais absentes des nouveaux choix. */
	protected static function valeursOrphelines( $attributId, array $options ) {
		$rows = FKC_DB::q( "SELECT DISTINCT valeur FROM vp_attribut_valeurs WHERE attribut_id=? AND valeur IS NOT NULL AND TRIM(valeur)<>''", array( (int) $attributId ) )->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$v = (string) $r['valeur'];
			if ( ! in_array( $v, $options, true ) ) { $out[] = $v; }
		}
		return $out;
	}

	/** Accepte une saisie « Rouge, Bleu, Vert » ou une ligne par choix, ou un tableau. */
	public static function optionsNettoyees( $brut ) {
		if ( is_array( $brut ) ) { $liste = $brut; }
		else {
			$brut  = (string) $brut;
			$liste = preg_split( '/[\r\n,;|]+/', $brut ) ?: array();
		}
		$out = array();
		foreach ( $liste as $v ) {
			$v = trim( (string) $v );
			if ( '' !== $v && ! in_array( $v, $out, true ) ) { $out[] = $v; }
		}
		return $out;
	}

	protected static function libelleExiste( $libelle, $categorieId, $excludeId = null ) {
		$w = 'WHERE pack=? AND libelle=? AND ' . ( $categorieId ? 'categorie_id=?' : 'categorie_id IS NULL' );
		$p = array( self::pack(), $libelle );
		if ( $categorieId ) { $p[] = (int) $categorieId; }
		if ( $excludeId ) { $w .= ' AND id<>?'; $p[] = (int) $excludeId; }
		return (bool) FKC_DB::q( "SELECT 1 FROM vp_attributs {$w}", $p )->fetch();
	}

	protected static function prochainOrdre( $categorieId ) {
		$w = 'WHERE pack=? AND ' . ( $categorieId ? 'categorie_id=?' : 'categorie_id IS NULL' );
		$p = array( self::pack() );
		if ( $categorieId ) { $p[] = (int) $categorieId; }
		return 10 + (int) FKC_DB::q( "SELECT COALESCE(MAX(ordre),0) FROM vp_attributs {$w}", $p )->fetchColumn();
	}

	/**
	 * Translittération pour les identifiants techniques. Le repli sans
	 * mbstring compte : « Épaisseur » saisi en majuscule accentuée doit
	 * donner « epaisseur », jamais « paisseur » — un code amputé se propage
	 * ensuite partout où l'attribut est lu par son code.
	 */
	protected static function translit( $s ) {
		$s = fkc_lc( (string) $s );
		return strtr( $s, array(
			'à' => 'a', 'á' => 'a', 'â' => 'a', 'ä' => 'a', 'ã' => 'a', 'å' => 'a',
			'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
			'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
			'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'ö' => 'o', 'õ' => 'o',
			'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
			'ç' => 'c', 'ñ' => 'n', 'ý' => 'y', 'ÿ' => 'y', 'œ' => 'oe', 'æ' => 'ae',
			// Repli sans mbstring : fkc_lc laisse alors les majuscules
			// accentuées intactes, il faut donc les traiter aussi.
			'À' => 'a', 'Á' => 'a', 'Â' => 'a', 'Ä' => 'a', 'Ã' => 'a', 'Å' => 'a',
			'É' => 'e', 'È' => 'e', 'Ê' => 'e', 'Ë' => 'e',
			'Í' => 'i', 'Ì' => 'i', 'Î' => 'i', 'Ï' => 'i',
			'Ó' => 'o', 'Ò' => 'o', 'Ô' => 'o', 'Ö' => 'o', 'Õ' => 'o',
			'Ú' => 'u', 'Ù' => 'u', 'Û' => 'u', 'Ü' => 'u',
			'Ç' => 'c', 'Ñ' => 'n', 'Œ' => 'oe', 'Æ' => 'ae',
		) );
	}

	public static function codeLibre( $libelle ) {
		$base = trim( (string) preg_replace( '/[^a-z0-9]+/', '_', self::translit( $libelle ) ), '_' );
		if ( '' === $base ) { $base = 'attr'; }
		$base = substr( $base, 0, 40 );
		$code = $base; $i = 2;
		while ( FKC_DB::q( 'SELECT 1 FROM vp_attributs WHERE pack=? AND code=?', array( self::pack(), $code ) )->fetch() ) {
			$code = $base . '_' . $i; $i++;
			if ( $i > 999 ) { $code = $base . '_' . bin2hex( random_bytes( 2 ) ); break; }
		}
		return $code;
	}
}
