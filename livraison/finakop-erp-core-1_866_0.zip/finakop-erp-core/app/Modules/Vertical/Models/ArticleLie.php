<?php
/**
 * ACCESSOIRES ET ARTICLES LIÉS (ELM-005).
 *
 * LE BESOIN, TEL QU'IL A ÉTÉ POSÉ
 *
 * Le cahier des charges de l'Électroménager citait les accessoires à deux
 * niveaux : parmi les capacités du métier, et parmi ce que le commerçant
 * ajoute à son catalogue. C'est structurant dans ce commerce — un téléviseur
 * se vend avec son support mural, une machine à laver avec son tuyau
 * d'arrivée, un climatiseur avec ses fixations. Le vendeur qui l'oublie perd
 * une marge à chaque vente, et le client revient le lendemain pour un
 * accessoire à 3 000 F qu'il aurait pris sans y penser.
 *
 * UN LIEN ORIENTÉ, PAS UNE ÉQUIVALENCE
 *
 * « Le support mural est un accessoire du téléviseur » ne veut pas dire
 * « le téléviseur est un accessoire du support mural ». Le lien porte donc
 * un sens : de l'article PRINCIPAL vers l'article LIÉ. C'est ce qui permet
 * de proposer le bon complément au bon moment.
 *
 * La réciprocité reste possible quand elle a du sens — un client venu pour
 * le support cherche peut-être un téléviseur — mais elle se DEMANDE, elle ne
 * se déduit pas. Une réciprocité automatique remplirait chaque fiche
 * d'accessoire de suggestions absurdes.
 *
 * TROIS NATURES DE LIEN, PARCE QU'ELLES NE SE PROPOSENT PAS PAREIL
 *
 *   accessoire  — un complément qu'on propose (support, housse, câble).
 *   consommable — ce qu'il faudra racheter (filtre, sac, cartouche) : c'est
 *                 une vente future, et le vendeur a intérêt à la signaler
 *                 dès l'achat de l'appareil.
 *   service     — une prestation associée (pose, mise en service), qui se
 *                 planifie et ne se met pas dans un sac.
 *
 * CE QUE CETTE BRIQUE NE FAIT PAS
 *
 * Elle ne vend rien et n'impose rien. Un accessoire lié n'est jamais ajouté
 * automatiquement au ticket : il est PROPOSÉ. Un logiciel qui ajouterait
 * seul des lignes à une vente ferait payer au client ce qu'il n'a pas
 * demandé — et le commerçant ne s'en apercevrait qu'à la réclamation.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpArticleLie {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_articles_lies(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				article_id INTEGER NOT NULL,
				lie_id INTEGER NOT NULL,
				type TEXT NOT NULL DEFAULT 'accessoire',
				note TEXT,
				ordre INTEGER NOT NULL DEFAULT 100,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(article_id, lie_id, type)
			);
			CREATE INDEX IF NOT EXISTS idx_vpal_article ON vp_articles_lies(article_id);
			CREATE INDEX IF NOT EXISTS idx_vpal_lie ON vp_articles_lies(lie_id);
		" );
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	public static function types() {
		return array(
			'accessoire'  => array( 'label' => 'Accessoire',  'icone' => '🔌', 'aide' => 'Un complément qu\'on propose avec l\'article (support, housse, câble).' ),
			'consommable' => array( 'label' => 'Consommable', 'icone' => '🧴', 'aide' => 'Ce qu\'il faudra racheter (filtre, sac, cartouche) — une vente future à signaler dès l\'achat.' ),
			'service'     => array( 'label' => 'Service',     'icone' => '🔧', 'aide' => 'Une prestation associée (pose, mise en service), qui se planifie.' ),
		);
	}

	public static function labelType( $t ) {
		$d = self::types();
		return isset( $d[ (string) $t ] ) ? $d[ (string) $t ]['label'] : (string) $t;
	}

	/* ── Lecture ─────────────────────────────────────────────────────────── */

	/**
	 * Articles liés à un article principal, enrichis de leur fiche (libellé,
	 * prix, stock) — c'est ce dont l'écran de vente a besoin pour proposer.
	 */
	public static function pourArticle( $articleId, $type = null ) {
		self::ensure();
		$w = 'WHERE l.pack=? AND l.article_id=?';
		$p = array( self::pack(), (int) $articleId );
		if ( $type ) { $w .= ' AND l.type=?'; $p[] = (string) $type; }
		return FKC_DB::q(
			"SELECT l.*, a.libelle, a.reference, a.prix_vente, a.qte_stock, a.unite, a.actif
			 FROM vp_articles_lies l JOIN vp_articles a ON a.id=l.lie_id
			 {$w} ORDER BY l.type, l.ordre, a.libelle", $p
		)->fetchAll();
	}

	/** Articles dont CET article est l'accessoire — l'autre sens du lien. */
	public static function principauxDe( $articleId ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT l.*, a.libelle, a.reference FROM vp_articles_lies l JOIN vp_articles a ON a.id=l.article_id
			 WHERE l.pack=? AND l.lie_id=? ORDER BY a.libelle",
			array( self::pack(), (int) $articleId )
		)->fetchAll();
	}

	/**
	 * Ce qu'on peut proposer au moment de vendre CET article : les liens
	 * actifs, disponibles en stock quand ils sont stockés.
	 *
	 * Un accessoire en rupture n'est pas proposé — suggérer ce qu'on ne peut
	 * pas livrer transforme une vente complémentaire en promesse non tenue.
	 */
	public static function suggestions( $articleId ) {
		$out = array();
		foreach ( self::pourArticle( $articleId ) as $l ) {
			if ( empty( $l['actif'] ) ) { continue; }
			$dispo = true;
			if ( class_exists( 'FKC_VpCapacite' ) ) {
				$art = FKC_VpStock::article( (int) $l['lie_id'] );
				if ( $art && FKC_VpCapacite::gereStock( $art ) && (float) $art['qte_stock'] <= 0 ) { $dispo = false; }
			}
			if ( ! $dispo ) { continue; }
			$out[] = $l;
		}
		return $out;
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_articles_lies WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	/* ── Écriture ────────────────────────────────────────────────────────── */

	/**
	 * @return array{bool, string, int|null}
	 */
	public static function lier( $articleId, $lieId, $type = 'accessoire', array $d = array() ) {
		self::ensure();
		$articleId = (int) $articleId; $lieId = (int) $lieId;
		if ( ! array_key_exists( (string) $type, self::types() ) ) { return array( false, 'Nature de lien inconnue.', null ); }

		$a = FKC_VpStock::article( $articleId );
		$b = $lieId ? FKC_VpStock::article( $lieId ) : null;
		if ( ! $a ) { return array( false, 'Article principal introuvable.', null ); }
		if ( ! $b ) { return array( false, 'Choisissez l\'article à associer.', null ); }
		if ( $articleId === $lieId ) {
			return array( false, 'Un article ne peut pas être son propre accessoire.', null );
		}

		$existe = FKC_DB::q( 'SELECT 1 FROM vp_articles_lies WHERE pack=? AND article_id=? AND lie_id=? AND type=?',
			array( self::pack(), $articleId, $lieId, (string) $type ) )->fetch();
		if ( $existe ) {
			return array( false, '« ' . $b['libelle'] . ' » est déjà associé à « ' . $a['libelle'] . ' » comme ' . fkc_lc( self::labelType( $type ) ) . '.', null );
		}

		FKC_DB::q( 'INSERT INTO vp_articles_lies(pack,article_id,lie_id,type,note,ordre) VALUES(?,?,?,?,?,?)', array(
			self::pack(), $articleId, $lieId, (string) $type,
			trim( (string) ( $d['note'] ?? '' ) ) ?: null,
			isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : self::prochainOrdre( $articleId ),
		) );
		$id = (int) FKC_DB::conn()->lastInsertId();

		$msg = '« ' . $b['libelle'] . ' » associé à « ' . $a['libelle'] . ' » (' . fkc_lc( self::labelType( $type ) ) . ').';

		/*
		 * La réciprocité se DEMANDE. Elle a du sens pour un accessoire — un
		 * client venu pour le support cherche peut-être un téléviseur — mais
		 * jamais pour un consommable ni pour un service : proposer une
		 * machine à laver à qui achète un filtre n'aiderait personne.
		 */
		if ( ! empty( $d['reciproque'] ) && 'accessoire' === (string) $type ) {
			$inverse = FKC_DB::q( 'SELECT 1 FROM vp_articles_lies WHERE pack=? AND article_id=? AND lie_id=? AND type=?',
				array( self::pack(), $lieId, $articleId, 'accessoire' ) )->fetch();
			if ( ! $inverse ) {
				FKC_DB::q( 'INSERT INTO vp_articles_lies(pack,article_id,lie_id,type,ordre) VALUES(?,?,?,?,?)',
					array( self::pack(), $lieId, $articleId, 'accessoire', self::prochainOrdre( $lieId ) ) );
				$msg .= ' Le lien inverse a également été créé.';
			}
		}
		return array( true, $msg, $id );
	}

	/** @return array{bool, string} */
	public static function delier( $id ) {
		self::ensure();
		$l = self::find( $id );
		if ( ! $l ) { return array( false, 'Association introuvable.' ); }
		FKC_DB::q( 'DELETE FROM vp_articles_lies WHERE id=? AND pack=?', array( (int) $l['id'], self::pack() ) );
		return array( true, 'Association retirée.' );
	}

	/**
	 * Efface tous les liens d'un article, dans LES DEUX SENS — appelé à sa
	 * suppression. Ne nettoyer qu'un sens laisserait l'article supprimé
	 * proposé comme accessoire d'un autre, avec une jointure qui ne ramène
	 * plus rien et une ligne vide à l'écran.
	 */
	public static function oublierArticle( $articleId ) {
		self::ensure();
		try {
			FKC_DB::q( 'DELETE FROM vp_articles_lies WHERE article_id=? OR lie_id=?', array( (int) $articleId, (int) $articleId ) );
		} catch ( \Throwable $e ) { fkc_log( 'VpArticleLie::oublierArticle ' . $e->getMessage(), 'ERROR' ); }
	}

	protected static function prochainOrdre( $articleId ) {
		return 10 + (int) FKC_DB::q( 'SELECT COALESCE(MAX(ordre),0) FROM vp_articles_lies WHERE pack=? AND article_id=?',
			array( self::pack(), (int) $articleId ) )->fetchColumn();
	}
}
