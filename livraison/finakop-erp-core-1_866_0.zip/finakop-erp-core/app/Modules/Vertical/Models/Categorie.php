<?php
/**
 * CATALOGUE LIBRE (BAZ-001) — catégories gérées par le COMMERÇANT.
 *
 * LE PROBLÈME QUE CETTE BRIQUE RÉSOUT
 *
 * Jusqu'ici, les catégories d'un pack de commerce vivaient dans une seule
 * ligne de son manifest — `'stock' => array( 'categories' => array( … ) )` —
 * et ne servaient qu'à peupler un menu déroulant dans la fiche article. Ce
 * n'était pas un catalogue : c'était une liste figée, non modifiable, sans
 * sous-catégorie, sans paramètre, identique pour tous les commerçants d'un
 * même métier. Un bazar dont l'assortiment change trois fois par an ne
 * pouvait rien y faire, et un magasin d'électroménager ne pouvait pas
 * désactiver un rayon qu'il ne tient pas.
 *
 * LE MODÈLE — DEUX ORIGINES, JAMAIS CONFONDUES
 *
 *   « système »       : catégorie SEMÉE par le pack (le catalogue métier
 *                       préconfiguré de l'Électroménager). Renommable,
 *                       désactivable, réordonnable — mais JAMAIS supprimable :
 *                       elle est susceptible de porter de l'historique de
 *                       vente, et la faire disparaître rendrait des états
 *                       passés illisibles.
 *   « personnalisée » : catégorie créée par le commerçant. Entièrement à lui,
 *                       supprimable tant qu'aucun article ni aucune
 *                       sous-catégorie ne s'y rattache.
 *
 * LA SEMENCE N'EST PAS UNE LISTE
 *
 * Le manifest ne DÉCRIT PLUS le catalogue : il le SÈME, une seule fois par
 * société, protégé par une sentinelle en base (même principe que les comptes
 * de pack, voir FKC_Packs::syncPack). Sans cette sentinelle, une catégorie
 * supprimée par le commerçant renaîtrait à la requête suivante — le genre de
 * bug qui donne l'impression que le logiciel « ne retient rien ».
 *
 * LE PONT COMPTABLE (décision D4 du chantier)
 *
 * Un catalogue totalement libre est un piège comptable : si le commerçant
 * crée « Rideaux », « Vaisselle » et « Jouets » sans rien d'autre, TOUT
 * tombe sur le même compte de vente et la ventilation SYSCOHADA ne veut plus
 * rien dire. Une catégorie porte donc, en option, sa catégorie fiscale et son
 * compte de vente, HÉRITÉS par ses articles (et par ses sous-catégories) et
 * surchargeables au niveau de l'article. C'est ce qui fait tenir ensemble
 * « le commerçant décide de ce qu'il vend » et « la liasse reste juste ».
 *
 * LIMITE ASSUMÉE : DEUX NIVEAUX
 *
 * Catégorie → sous-catégorie, pas au-delà. C'est le modèle décrit par le
 * cahier des charges, c'est ce que les écrans savent afficher lisiblement, et
 * cela rend impossible par construction le cycle parent/enfant qu'une
 * profondeur libre imposerait de surveiller à chaque écriture.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpCategorie {

	/* 1.864.0 — cache tenu par base : après bascule de société, la nouvelle base reçoit ses tables. */
	protected static $ready = array();
	protected static function cleBaseReady() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	const SYSTEME       = 'systeme';
	const PERSONNALISEE = 'personnalise';

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBaseReady() ] ) ) { return; }
		// vp_articles doit exister avant qu'on tente d'y ajouter la colonne
		// de rattachement : sur une base neuve, l'ALTER échouerait en silence
		// et le catalogue ne se rattacherait jamais à rien.
		if ( class_exists( 'FKC_VpStock' ) ) { FKC_VpStock::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS vp_categories(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				code TEXT NOT NULL,
				libelle TEXT NOT NULL,
				parent_id INTEGER,
				origine TEXT NOT NULL DEFAULT 'personnalise',
				categorie_fiscale_id INTEGER,
				compte_vente TEXT,
				ordre INTEGER NOT NULL DEFAULT 100,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, code)
			);
			CREATE INDEX IF NOT EXISTS idx_vpcat_pack ON vp_categories(pack, actif, ordre);
			CREATE INDEX IF NOT EXISTS idx_vpcat_parent ON vp_categories(parent_id);
		" );
		/*
		 * L'article se rattache désormais à une catégorie par SON IDENTIFIANT.
		 * La colonne texte `categorie` reste alimentée avec le libellé : sept
		 * packs, les cockpits (caParCategorie), l'analytique et le pont
		 * Inventaire la lisent encore. La retirer serait une régression
		 * silencieuse sur tout le parc installé.
		 */
		try { FKC_DB::conn()->exec( 'ALTER TABLE vp_articles ADD COLUMN categorie_id INTEGER' ); } catch ( \Throwable $e ) { /* déjà présente */ }
		self::$ready[ self::cleBaseReady() ] = true;
	}

	public static function pack() { return FKC_Packs::activeCode(); }

	/* ── Semence (catalogue métier préconfiguré du manifest) ─────────────── */

	/**
	 * Sème, UNE SEULE FOIS par société et par pack, les catégories déclarées
	 * dans le manifest. Idempotent par sentinelle : le commerçant qui
	 * supprime ou désactive une catégorie semée ne la voit jamais revenir.
	 *
	 * Accepte deux écritures dans le manifest :
	 *   'categories' => array( 'Télévisions', 'Réfrigérateurs' )
	 *   'categories' => array(
	 *       array( 'libelle' => 'Télévisions', 'enfants' => array( 'LED', 'OLED' ),
	 *              'compte_vente' => '701100' ),
	 *   )
	 *
	 * @return int Nombre de catégories réellement créées.
	 */
	public static function semer( array $categories, $pack = null, $origine = self::SYSTEME ) {
		self::ensure();
		$pack = $pack ?: self::pack();
		if ( ! $categories ) { return 0; }
		/*
		 * BAZ-003 — L'ORIGINE DE LA SEMENCE EST UN CHOIX DE MÉTIER.
		 *
		 * L'Électroménager sème en « système » : ses neuf rayons sont un
		 * catalogue métier, renommable et désactivable mais jamais
		 * supprimable, parce qu'il porte de l'historique de vente.
		 *
		 * Le Bazar sème en « personnalisé » : ses rayons ne sont qu'une
		 * commodité de démarrage. Un catalogue annoncé « entièrement libre »
		 * qui commencerait par onze rayons indéboulonnables ne serait pas
		 * libre — le commerçant doit pouvoir tout effacer et repartir de zéro.
		 */
		if ( self::SYSTEME !== $origine && self::PERSONNALISEE !== $origine ) { $origine = self::SYSTEME; }
		$sentinelle = 'vp_categories_seed_' . $pack;
		try {
			$deja = FKC_DB::q( 'SELECT valeur FROM parametres WHERE cle=?', array( $sentinelle ) )->fetchColumn();
			if ( $deja ) { return 0; }
		} catch ( \Throwable $e ) { return 0; } // table parametres absente : on ne sème pas à l'aveugle.

		$n = 0; $ordre = 10;
		foreach ( $categories as $def ) {
			$def = is_array( $def ) ? $def : array( 'libelle' => (string) $def );
			$libelle = trim( (string) ( $def['libelle'] ?? '' ) );
			if ( '' === $libelle ) { continue; }
			$id = self::insererBrut( $pack, $libelle, null, $origine, $ordre, $def );
			if ( ! $id ) { continue; }
			$n++; $ordre += 10;
			$sousOrdre = 10;
			foreach ( (array) ( $def['enfants'] ?? array() ) as $enfant ) {
				$enfant  = is_array( $enfant ) ? $enfant : array( 'libelle' => (string) $enfant );
				$libEnf  = trim( (string) ( $enfant['libelle'] ?? '' ) );
				if ( '' === $libEnf ) { continue; }
				if ( self::insererBrut( $pack, $libEnf, $id, $origine, $sousOrdre, $enfant ) ) { $n++; $sousOrdre += 10; }
			}
		}
		try {
			FKC_DB::q( "INSERT INTO parametres(cle,valeur) VALUES(?,datetime('now','localtime')) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur", array( $sentinelle ) );
		} catch ( \Throwable $e ) { fkc_log( 'VpCategorie::semer sentinelle ' . $e->getMessage(), 'ERROR' ); }
		return $n;
	}

	/** Insertion sans validation (semence uniquement) : le manifest fait foi. */
	protected static function insererBrut( $pack, $libelle, $parentId, $origine, $ordre, array $def = array() ) {
		try {
			FKC_DB::q(
				'INSERT INTO vp_categories(pack,code,libelle,parent_id,origine,categorie_fiscale_id,compte_vente,ordre) VALUES(?,?,?,?,?,?,?,?)',
				array(
					$pack, self::codeLibre( $libelle, $pack ), $libelle,
					$parentId ? (int) $parentId : null, $origine,
					! empty( $def['categorie_fiscale_id'] ) ? (int) $def['categorie_fiscale_id'] : null,
					trim( (string) ( $def['compte_vente'] ?? '' ) ) ?: null,
					(int) $ordre,
				)
			);
			return (int) FKC_DB::conn()->lastInsertId();
		} catch ( \Throwable $e ) { return null; }
	}

	/**
	 * Translittération pour les identifiants techniques. Le repli sans
	 * mbstring compte : « Épaisseur » saisi en majuscule accentuée doit
	 * donner « epaisseur », jamais « paisseur » — un code amputé se propage
	 * ensuite partout où l'attribut est lu par son code.
	 */
	protected static function translit( $s ) {
		$s = fkc_lc( (string) $s );
		return strtr( $s, array(
			'à' => 'a', 'á' => 'a', 'â' => 'a', 'ä' => 'a', 'ã' => 'a', 'å' => 'a',
			'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
			'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
			'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'ö' => 'o', 'õ' => 'o',
			'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
			'ç' => 'c', 'ñ' => 'n', 'ý' => 'y', 'ÿ' => 'y', 'œ' => 'oe', 'æ' => 'ae',
			// Repli sans mbstring : fkc_lc laisse alors les majuscules
			// accentuées intactes, il faut donc les traiter aussi.
			'À' => 'a', 'Á' => 'a', 'Â' => 'a', 'Ä' => 'a', 'Ã' => 'a', 'Å' => 'a',
			'É' => 'e', 'È' => 'e', 'Ê' => 'e', 'Ë' => 'e',
			'Í' => 'i', 'Ì' => 'i', 'Î' => 'i', 'Ï' => 'i',
			'Ó' => 'o', 'Ò' => 'o', 'Ô' => 'o', 'Ö' => 'o', 'Õ' => 'o',
			'Ú' => 'u', 'Ù' => 'u', 'Û' => 'u', 'Ü' => 'u',
			'Ç' => 'c', 'Ñ' => 'n', 'Œ' => 'oe', 'Æ' => 'ae',
		) );
	}

	/** Slug stable et unique pour ce pack (le code ne change jamais, le libellé oui). */
	public static function codeLibre( $libelle, $pack = null ) {
		$pack = $pack ?: self::pack();
		$base = preg_replace( '/[^a-z0-9]+/', '_', self::translit( $libelle ) );
		$base = trim( (string) $base, '_' );
		if ( '' === $base ) { $base = 'cat'; }
		$base = substr( $base, 0, 40 );
		$code = $base; $i = 2;
		while ( FKC_DB::q( 'SELECT 1 FROM vp_categories WHERE pack=? AND code=?', array( $pack, $code ) )->fetch() ) {
			$code = $base . '_' . $i; $i++;
			if ( $i > 999 ) { $code = $base . '_' . bin2hex( random_bytes( 2 ) ); break; }
		}
		return $code;
	}

	/* ── Lecture ─────────────────────────────────────────────────────────── */

	public static function toutes( $inclureInactives = false ) {
		self::ensure();
		$w = 'WHERE pack=?'; $p = array( self::pack() );
		if ( ! $inclureInactives ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_categories {$w} ORDER BY COALESCE(parent_id,id), parent_id IS NOT NULL, ordre, libelle", $p )->fetchAll();
	}

	public static function racines( $inclureInactives = false ) {
		self::ensure();
		$w = 'WHERE pack=? AND parent_id IS NULL'; $p = array( self::pack() );
		if ( ! $inclureInactives ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_categories {$w} ORDER BY ordre, libelle", $p )->fetchAll();
	}

	public static function enfants( $parentId, $inclureInactives = false ) {
		self::ensure();
		$w = 'WHERE pack=? AND parent_id=?'; $p = array( self::pack(), (int) $parentId );
		if ( ! $inclureInactives ) { $w .= ' AND actif=1'; }
		return FKC_DB::q( "SELECT * FROM vp_categories {$w} ORDER BY ordre, libelle", $p )->fetchAll();
	}

	/** Arbre à deux niveaux : chaque racine porte ses enfants sous la clé 'enfants'. */
	public static function arbre( $inclureInactives = false ) {
		$out = array();
		foreach ( self::racines( $inclureInactives ) as $r ) {
			$r['enfants'] = self::enfants( (int) $r['id'], $inclureInactives );
			$out[] = $r;
		}
		return $out;
	}

	public static function find( $id ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_categories WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch();
		return $r ?: null;
	}

	public static function parCode( $code ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_categories WHERE code=? AND pack=?', array( (string) $code, self::pack() ) )->fetch();
		return $r ?: null;
	}

	/** Retrouve une catégorie par son libellé exact (sert à raccrocher l'historique texte). */
	public static function parLibelle( $libelle ) {
		self::ensure();
		$r = FKC_DB::q( 'SELECT * FROM vp_categories WHERE pack=? AND libelle=? ORDER BY parent_id IS NOT NULL LIMIT 1',
			array( self::pack(), trim( (string) $libelle ) ) )->fetch();
		return $r ?: null;
	}

	/** « Maison › Rideaux » — le chemin complet, pour les écrans et les états. */
	public static function chemin( $id ) {
		$c = self::find( $id );
		if ( ! $c ) { return ''; }
		if ( empty( $c['parent_id'] ) ) { return (string) $c['libelle']; }
		$p = self::find( (int) $c['parent_id'] );
		return ( $p ? $p['libelle'] . ' › ' : '' ) . $c['libelle'];
	}

	/** Options hiérarchisées (id => libellé indenté) pour les sélecteurs. */
	public static function options( $inclureInactives = false ) {
		$out = array();
		foreach ( self::arbre( $inclureInactives ) as $r ) {
			$out[ (int) $r['id'] ] = ( $r['actif'] ? '' : '(inactive) ' ) . $r['libelle'];
			foreach ( $r['enfants'] as $e ) {
				$out[ (int) $e['id'] ] = '   › ' . ( $e['actif'] ? '' : '(inactive) ' ) . $e['libelle'];
			}
		}
		return $out;
	}

	/* ── Écriture ────────────────────────────────────────────────────────── */

	/**
	 * @return array{bool, string, int|null} ( ok, message, id )
	 */
	public static function creer( array $d ) {
		self::ensure();
		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom de la catégorie est obligatoire.', null ); }

		$parentId = ! empty( $d['parent_id'] ) ? (int) $d['parent_id'] : null;
		if ( $parentId ) {
			$parent = self::find( $parentId );
			if ( ! $parent ) { return array( false, 'La catégorie parente choisie est introuvable.', null ); }
			if ( ! empty( $parent['parent_id'] ) ) {
				return array( false, 'Le catalogue s\'organise sur deux niveaux : une sous-catégorie ne peut pas elle-même en contenir. Rattachez-la directement à « ' . $parent['libelle'] . ' » ou créez une catégorie principale.', null );
			}
		}
		if ( self::libelleExiste( $libelle, $parentId ) ) {
			return array( false, 'Une catégorie « ' . $libelle .' » existe déjà à cet endroit du catalogue.', null );
		}

		$ordre = isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : self::prochainOrdre( $parentId );
		try {
			FKC_DB::q(
				'INSERT INTO vp_categories(pack,code,libelle,parent_id,origine,categorie_fiscale_id,compte_vente,ordre,actif) VALUES(?,?,?,?,?,?,?,?,1)',
				array(
					self::pack(), self::codeLibre( $libelle ), $libelle, $parentId, self::PERSONNALISEE,
					! empty( $d['categorie_fiscale_id'] ) ? (int) $d['categorie_fiscale_id'] : null,
					self::compteValide( $d['compte_vente'] ?? '' ),
					$ordre,
				)
			);
		} catch ( \Throwable $e ) {
			return array( false, 'Création impossible : ' . $e->getMessage(), null );
		}
		return array( true, 'Catégorie « ' . $libelle . ' » créée.', (int) FKC_DB::conn()->lastInsertId() );
	}

	/**
	 * Modifie une catégorie. Le CODE n'est jamais modifié — c'est l'identité
	 * technique de la catégorie, y compris pour une catégorie système que le
	 * commerçant rebaptise à sa façon.
	 *
	 * @return array{bool, string}
	 */
	public static function modifier( $id, array $d ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Catégorie introuvable.' ); }

		$libelle = trim( (string) ( $d['libelle'] ?? '' ) );
		if ( '' === $libelle ) { return array( false, 'Le nom de la catégorie est obligatoire.' ); }

		$parentId = array_key_exists( 'parent_id', $d ) ? ( ! empty( $d['parent_id'] ) ? (int) $d['parent_id'] : null ) : ( $c['parent_id'] ? (int) $c['parent_id'] : null );
		if ( $parentId ) {
			if ( $parentId === (int) $c['id'] ) { return array( false, 'Une catégorie ne peut pas être sa propre catégorie parente.' ); }
			$parent = self::find( $parentId );
			if ( ! $parent ) { return array( false, 'La catégorie parente choisie est introuvable.' ); }
			if ( ! empty( $parent['parent_id'] ) ) {
				return array( false, 'Le catalogue s\'organise sur deux niveaux : « ' . $parent['libelle'] . ' » est déjà une sous-catégorie.' );
			}
			if ( self::enfants( (int) $c['id'], true ) ) {
				return array( false, 'Cette catégorie contient déjà des sous-catégories — elle ne peut pas devenir elle-même une sous-catégorie.' );
			}
		}
		if ( self::libelleExiste( $libelle, $parentId, (int) $c['id'] ) ) {
			return array( false, 'Une catégorie « ' . $libelle . ' » existe déjà à cet endroit du catalogue.' );
		}

		FKC_DB::q(
			'UPDATE vp_categories SET libelle=?, parent_id=?, categorie_fiscale_id=?, compte_vente=?, ordre=?, actif=? WHERE id=? AND pack=?',
			array(
				$libelle, $parentId,
				! empty( $d['categorie_fiscale_id'] ) ? (int) $d['categorie_fiscale_id'] : null,
				self::compteValide( $d['compte_vente'] ?? '' ),
				isset( $d['ordre'] ) && '' !== $d['ordre'] ? (int) $d['ordre'] : (int) $c['ordre'],
				array_key_exists( 'actif', $d ) ? ( ! empty( $d['actif'] ) ? 1 : 0 ) : (int) $c['actif'],
				(int) $c['id'], self::pack(),
			)
		);
		/*
		 * Le libellé change : les articles rattachés portent une copie
		 * dénormalisée de ce libellé (colonne texte `categorie`, lue par les
		 * cockpits et l'analytique). Sans cette propagation, un rayon
		 * rebaptisé apparaîtrait sous deux noms dans les états.
		 */
		if ( $libelle !== (string) $c['libelle'] ) { self::propagerLibelle( (int) $c['id'], $libelle ); }
		return array( true, 'Catégorie mise à jour.' );
	}

	/** Active / désactive. Une catégorie inactive disparaît des sélecteurs sans rien perdre. */
	public static function basculer( $id ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( false, 'Catégorie introuvable.' ); }
		$nouvel = empty( $c['actif'] ) ? 1 : 0;
		FKC_DB::q( 'UPDATE vp_categories SET actif=? WHERE id=? AND pack=?', array( $nouvel, (int) $c['id'], self::pack() ) );
		// Désactiver une catégorie principale retire aussi ses sous-catégories
		// des sélecteurs : les laisser visibles sans leur parent n'aurait
		// aucun sens dans un menu à deux niveaux.
		if ( empty( $c['parent_id'] ) ) {
			FKC_DB::q( 'UPDATE vp_categories SET actif=? WHERE parent_id=? AND pack=?', array( $nouvel, (int) $c['id'], self::pack() ) );
		}
		return array( true, $nouvel ? 'Catégorie « ' . $c['libelle'] . ' » réactivée.' : 'Catégorie « ' . $c['libelle'] . ' » désactivée — elle ne sera plus proposée, mais son historique reste intact.' );
	}

	/**
	 * Ce qui empêche de supprimer une catégorie, calculé AVANT d'agir et
	 * affiché : l'utilisateur doit savoir pourquoi, pas seulement que.
	 *
	 * @return array{categorie:?array,supprimable:bool,raisons:array}
	 */
	public static function analyseSuppression( $id ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return array( 'categorie' => null, 'supprimable' => false, 'raisons' => array( 'Catégorie introuvable.' ) ); }
		$raisons = array();
		if ( self::SYSTEME === (string) $c['origine'] ) {
			$raisons[] = 'C\'est une catégorie du catalogue métier livré avec le pack : elle peut être renommée ou désactivée, jamais supprimée (elle peut porter de l\'historique de vente).';
		}
		$enf = self::enfants( (int) $c['id'], true );
		if ( $enf ) { $raisons[] = count( $enf ) . ' sous-catégorie(s) y sont rattachées.'; }
		$n = self::compteArticles( (int) $c['id'] );
		if ( $n ) { $raisons[] = $n . ' article(s) y sont rattaché(s).'; }
		return array( 'categorie' => $c, 'supprimable' => empty( $raisons ), 'raisons' => $raisons );
	}

	/** @return array{bool, string} */
	public static function supprimer( $id ) {
		$an = self::analyseSuppression( $id );
		if ( ! $an['categorie'] ) { return array( false, 'Catégorie introuvable.' ); }
		if ( ! $an['supprimable'] ) {
			return array( false, 'Suppression impossible : ' . implode( ' ', $an['raisons'] ) );
		}
		$lib = (string) $an['categorie']['libelle'];
		FKC_DB::q( 'DELETE FROM vp_categories WHERE id=? AND pack=?', array( (int) $an['categorie']['id'], self::pack() ) );
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'categorie_supprimee', 'Pack ' . self::pack() . ' — « ' . $lib . ' »' );
		}
		return array( true, 'Catégorie « ' . $lib . ' » supprimée.' );
	}

	/* ── Pont comptable (décision D4) ────────────────────────────────────── */

	/**
	 * Catégorie fiscale applicable à un article : la sienne d'abord, sinon
	 * celle de sa catégorie, sinon celle de la catégorie parente. Retourne
	 * null si rien n'est paramétré — l'appelant retombe alors sur le taux du
	 * pack, comme avant cette brique.
	 */
	public static function categorieFiscalePour( array $article ) {
		if ( ! empty( $article['categorie_fiscale_id'] ) ) { return (int) $article['categorie_fiscale_id']; }
		return self::heritage( $article, 'categorie_fiscale_id' );
	}

	/**
	 * Compte de vente imposé par la catégorie (ou sa parente), ou null. C'est
	 * ce qui empêche un catalogue libre de faire tomber « Rideaux », « Jouets »
	 * et « Vaisselle » dans un unique 701100 indifférencié.
	 */
	public static function compteVentePour( array $article ) {
		return self::heritage( $article, 'compte_vente' );
	}

	/** Remonte la chaîne catégorie → parente jusqu'à trouver le champ renseigné. */
	protected static function heritage( array $article, $champ ) {
		if ( empty( $article['categorie_id'] ) ) { return null; }
		self::ensure();
		$c = self::find( (int) $article['categorie_id'] );
		if ( ! $c ) { return null; }
		if ( ! empty( $c[ $champ ] ) ) { return 'compte_vente' === $champ ? (string) $c[ $champ ] : (int) $c[ $champ ]; }
		if ( ! empty( $c['parent_id'] ) ) {
			$p = self::find( (int) $c['parent_id'] );
			if ( $p && ! empty( $p[ $champ ] ) ) { return 'compte_vente' === $champ ? (string) $p[ $champ ] : (int) $p[ $champ ]; }
		}
		return null;
	}

	/* ── Utilitaires internes ────────────────────────────────────────────── */

	/** Nombre d'articles rattachés (par identifiant OU par le libellé hérité). */
	public static function compteArticles( $id ) {
		self::ensure();
		$c = self::find( $id );
		if ( ! $c ) { return 0; }
		try {
			return (int) FKC_DB::q(
				'SELECT COUNT(*) FROM vp_articles WHERE pack=? AND (categorie_id=? OR (categorie_id IS NULL AND categorie=?))',
				array( self::pack(), (int) $c['id'], (string) $c['libelle'] )
			)->fetchColumn();
		} catch ( \Throwable $e ) { return 0; }
	}

	protected static function libelleExiste( $libelle, $parentId, $excludeId = null ) {
		$w = 'WHERE pack=? AND libelle=? AND ' . ( $parentId ? 'parent_id=?' : 'parent_id IS NULL' );
		$p = array( self::pack(), $libelle );
		if ( $parentId ) { $p[] = (int) $parentId; }
		if ( $excludeId ) { $w .= ' AND id<>?'; $p[] = (int) $excludeId; }
		return (bool) FKC_DB::q( "SELECT 1 FROM vp_categories {$w}", $p )->fetch();
	}

	protected static function prochainOrdre( $parentId ) {
		$w = 'WHERE pack=? AND ' . ( $parentId ? 'parent_id=?' : 'parent_id IS NULL' );
		$p = array( self::pack() );
		if ( $parentId ) { $p[] = (int) $parentId; }
		$max = (int) FKC_DB::q( "SELECT COALESCE(MAX(ordre),0) FROM vp_categories {$w}", $p )->fetchColumn();
		return $max + 10;
	}

	/** Un compte de vente doit ressembler à un compte de produits (70x). */
	protected static function compteValide( $compte ) {
		$compte = trim( (string) $compte );
		if ( '' === $compte ) { return null; }
		return preg_match( '/^7\d{2,5}$/', $compte ) ? $compte : null;
	}

	/** Recopie le libellé sur les articles rattachés (colonne texte dénormalisée). */
	protected static function propagerLibelle( $id, $libelle ) {
		try {
			FKC_DB::q( 'UPDATE vp_articles SET categorie=? WHERE pack=? AND categorie_id=?', array( $libelle, self::pack(), (int) $id ) );
		} catch ( \Throwable $e ) { fkc_log( 'VpCategorie::propagerLibelle ' . $e->getMessage(), 'ERROR' ); }
	}

	/**
	 * RATTRAPAGE DE L'EXISTANT — les articles créés AVANT cette brique n'ont
	 * qu'un libellé texte. On leur retrouve leur catégorie quand elle porte
	 * exactement le même nom, et on crée les manquantes comme catégories
	 * personnalisées : le commerçant retrouve son catalogue tel qu'il l'avait
	 * saisi, sans ressaisie et sans article orphelin.
	 *
	 * @return int Nombre d'articles raccrochés.
	 */
	public static function rattraperArticles() {
		self::ensure();
		$rows = FKC_DB::q(
			"SELECT DISTINCT categorie FROM vp_articles WHERE pack=? AND categorie_id IS NULL AND categorie IS NOT NULL AND TRIM(categorie)<>''",
			array( self::pack() )
		)->fetchAll();
		$n = 0;
		foreach ( $rows as $r ) {
			$lib = trim( (string) $r['categorie'] );
			$cat = self::parLibelle( $lib );
			if ( ! $cat ) {
				list( $ok, , $id ) = self::creer( array( 'libelle' => $lib ) );
				if ( ! $ok ) { continue; }
			} else {
				$id = (int) $cat['id'];
			}
			$n += (int) FKC_DB::q( 'UPDATE vp_articles SET categorie_id=? WHERE pack=? AND categorie_id IS NULL AND categorie=?',
				array( (int) $id, self::pack(), $lib ) )->rowCount();
		}
		return $n;
	}
}
