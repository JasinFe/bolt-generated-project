<?php
/**
 * Écrans du moteur de commandes clients (COM-045) : devis → commande →
 * livraison → facturation, pour les packs de commerce de détail à brique
 * stock (mêmes conditions d'activation que FKC_VpStockController).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_VpCommandeController {

	protected $module;
	protected $cfg;

	public function __construct() {
		FKC_Packs::ensureSociete();
		$this->module = FKC_Packs::verticalModule();
		$this->cfg    = FKC_Packs::verticalConfig() ?: array();
		if ( ! FKC_Packs::hasStock() ) { redirect( $this->module ); }
		FKC_VpStock::ensure();
		FKC_VpCommande::ensure();
	}

	public function index() {
		FKC_View::render( 'vertical.commandes', array(
			'title' => 'Commandes clients', 'module' => $this->module, 'cfg' => $this->cfg,
			'rows' => FKC_VpCommande::all(), 'statuts' => FKC_VpCommande::statuts(),
			'flash' => $this->flash(),
		) );
	}

	public function createForm() {
		FKC_View::render( 'vertical.commande_form', array(
			'title' => 'Nouveau devis', 'module' => $this->module, 'cfg' => $this->cfg,
			'articles' => FKC_VpStock::articles(),
			'clients' => class_exists( 'FKC_Client' ) ? FKC_Client::all( true ) : array(),
			'flash' => $this->flash(),
		) );
	}

	public function store() {
		$lignes = array();
		foreach ( (array) ( $_POST['article_id'] ?? array() ) as $i => $aid ) {
			$lignes[] = array( 'article_id' => (int) $aid, 'qte' => fkc_nombre( $_POST['qte'][ $i ] ?? 0 ), 'pu' => $_POST['pu'][ $i ] ?? '', 'etape' => (string) ( $_POST['etape'][ $i ] ?? '' ) );
		}
		list( $ok, $msg, $id ) = FKC_VpCommande::creerDevis(
			(int) ( $_POST['client_id'] ?? 0 ), $lignes,
			! empty( $_POST['dossier_id'] ) ? (int) $_POST['dossier_id'] : null,
			trim( (string) ( $_POST['notes'] ?? '' ) )
		);
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $ok ? $this->module . '/commandes/' . (int) $id : $this->module . '/commandes/nouveau' );
	}

	public function show( $id ) {
		$c = FKC_VpCommande::find( (int) $id );
		if ( ! $c ) { redirect( $this->module . '/commandes' ); }
		FKC_View::render( 'vertical.commande_show', array(
			'title' => $c['numero'], 'module' => $this->module, 'cfg' => $this->cfg,
			'c' => $c, 'statuts' => FKC_VpCommande::statuts(),
			// ELM-002 : les acomptes existaient en base sans écran pour les
			// saisir ni les consulter — le moteur était livré, pas son usage.
			'acomptes' => FKC_VpCommande::acomptes( (int) $c['id'] ),
			'acomptesNonImputes' => FKC_VpCommande::acomptesNonImputes( (int) $c['id'] ),
			// 1.622.0 : le parcours réel de la commande — devis, livraisons,
			// facture, écriture — lu dans le registre des liens plutôt que
			// reconstitué à l'écran.
			'chaine' => class_exists( 'FKC_ChaineDoc' ) ? FKC_ChaineDoc::lisible( 'commande', (int) $c['id'] ) : null,
			'flash' => $this->flash(),
		) );
	}

	/**
	 * Encaissement d'un acompte. Le montant et le moyen sont saisis à
	 * l'écran ; tous les contrôles (devis, dépassement du montant de la
	 * commande) restent dans le moteur, qui reste la seule autorité.
	 */
	public function acompte( $id ) {
		list( $ok, $msg ) = FKC_VpCommande::acompte(
			(int) $id, fkc_nombre( $_POST['montant'] ?? 0 ), $this->cfg,
			(string) ( $_POST['moyen'] ?? 'especes' )
		);
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/commandes/' . (int) $id );
	}

	public function confirmer( $id ) {
		list( $ok, $msg ) = FKC_VpCommande::confirmer( (int) $id );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/commandes/' . (int) $id );
	}

	public function annuler( $id ) {
		list( $ok, $msg ) = FKC_VpCommande::annuler( (int) $id, trim( (string) ( $_POST['motif'] ?? '' ) ), (string) ( $_POST['moyen'] ?? '' ) );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/commandes/' . (int) $id );
	}

	/** 1.865.0 — livraison de toute une étape de chantier. */
	public function livrerEtape( $id ) {
		list( $ok, $msg ) = FKC_VpCommande::livrerEtape( (int) $id, (string) ( $_POST['etape'] ?? '' ), (array) ( $_POST['series'] ?? array() ) );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/commandes/' . (int) $id );
	}

	public function livrer( $id ) {
		$quantites = array();
		foreach ( (array) ( $_POST['livrer'] ?? array() ) as $ligneId => $qte ) {
			if ( fkc_nombre( $qte ) > 0 ) { $quantites[ (int) $ligneId ] = fkc_nombre( $qte ); }
		}
		list( $ok, $msg ) = FKC_VpCommande::livrer( (int) $id, $quantites, (array) ( $_POST['series'] ?? array() ) );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/commandes/' . (int) $id );
	}

	public function facturer( $id ) {
		list( $ok, $msg ) = FKC_VpCommande::facturer( (int) $id, $this->cfg, ! empty( $_POST['forcer_encours'] ) );
		$_SESSION['__vp_flash'] = array( 'type' => $ok ? 'ok' : 'err', 'msg' => $msg );
		redirect( $this->module . '/commandes/' . (int) $id );
	}

	protected function flash() {
		$f = $_SESSION['__vp_flash'] ?? null;
		unset( $_SESSION['__vp_flash'] );
		return $f;
	}
}
