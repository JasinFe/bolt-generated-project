<?php
/**
 * Brouillard de saisie : écritures déposées en attente de contrôle avant leur
 * comptabilisation définitive dans les comptes. Permet de vérifier et de modifier
 * toute écriture (saisie manuelle, ventes, achats, règlements, OD de paie…) avant
 * de la valider. Une écriture en brouillard n'impacte aucun état comptable.
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_Brouillard {

	const PARAM = 'compta_verif_avant';

	/** Tables/colonnes autorisées pour le rattachement d'une pièce après validation. */
	const LIENS = array(
		'factures'               => 'ecriture_id',
		'factures_fournisseurs'  => 'ecriture_id',
		'paie_bulletins'         => 'ecriture_id',
		// 1.843.3 — paiement des salaires nets (sortie de trésorerie, débit 421).
		'paie_paiements'         => 'ecriture_id',
		'reglements'             => 'ecriture_id',
		/*
		 * Ajoutés en 1.542.0 — dotations d'amortissement et dépréciations de
		 * créances. Elles échappaient au contrôle avant comptabilisation
		 * faute de figurer ici : leur code forçait la publication directe
		 * parce que la table à renseigner n'était pas raccordable. La liste
		 * blanche était donc la cause, pas la conséquence.
		 */
		'immo_dotations'         => 'ecriture_id',
		'immo_depreciations'     => 'ecriture_id', // 1.856.0 — dépréciations des immobilisations (29x)
		// 1.857.0 — coût des ventes de la brique verticale (D 603 / C 31).
		'vp_mouvements'          => array( 'ecriture_id', 'cout_ecriture_id' ),
		// 1.866.0 — mouvements de pièces de l'atelier garage (pose, retour, réception).
		'ga_mouvements'          => 'ecriture_id',
		// 1.866.0 — gérance immobilière : appel, honoraires, reversement, dépôt.
		'im_operations'          => 'ecriture_id',
		// 1.866.0 — cabinet juridique : avance et refacturation des débours, séquestre.
		'jr_debours'             => array( 'ecriture_id', 'refacture_ecriture_id' ),
		'jr_sequestre'           => 'ecriture_id',
		'depreciations'          => 'ecriture_id',
		/*
		 * Ajouté en 1.557.0 — déclarations fiscales. Deux colonnes, et c'est
		 * la raison pour laquelle la valeur peut désormais être une LISTE :
		 * une déclaration porte l'écriture de constatation de l'impôt ET,
		 * plus tard, celle de son règlement. Faute de figurer ici, ni l'une
		 * ni l'autre n'était jamais renseignée lorsque l'écriture passait par
		 * le journal temporaire : la fiche affichait « Déposée au brouillard »
		 * à vie, sans jamais retrouver son écriture.
		 */
		'declarations_fiscales'  => array( 'ecriture_id', 'ecriture_paiement_id' ),
		/*
		 * Ajoutés en 1.779.0 — moteur des revenus numériques. Une tranche de
		 * rapport, un produit à recouvrir (sa constatation ET sa
		 * contrepassation) et un encaissement retrouvent leur écriture quand
		 * elle sort du journal temporaire.
		 */
		'rn_tranches'            => 'ecriture_id',
		'rn_estimations'         => array( 'ecriture_id', 'contrepassation_id' ),
		'rn_encaissements'       => 'ecriture_id',
		// 1.784.0 — versement d'un acompte d'IS validé au journal temporaire.
		'acomptes_is'            => 'ecriture_id',
		/*
		 * Ajouté en 1.562.0 — missions RH. Le pont Missions → Comptabilité a
		 * été écrit sans passer par ici, et le contrôle empirique a montré
		 * ce que cet oubli produit : l'écriture partait bien au grand livre,
		 * mais `rh_missions.ecriture_id` restait NULL, si bien que la même
		 * mission se comptabilisait AUTANT DE FOIS qu'on cliquait — la garde
		 * « déjà comptabilisée » lisait une colonne que rien ne renseignait.
		 * La liste blanche est la cause, pas la conséquence.
		 */
		'rh_missions'            => 'ecriture_id',
		// Versement d'avance / prêt au personnel (1.563.0).
		'rh_avances'             => 'ecriture_id',
		/*
		 * Ajouté en 1.745.0 — reçus d'encaissement. FKC_Recu::comptabiliser()
		 * déclare bien ce lien, mais la table manquait ici : un reçu contrôlé
		 * au journal temporaire puis validé ne recevait JAMAIS son écriture.
		 * Il n'éteignait donc pas la facture qu'il payait (le poste client ne
		 * compte que les reçus rattachés à une écriture), et ne pouvait pas
		 * être contre-passé. Toujours la même leçon : la liste blanche est la
		 * cause, pas la conséquence.
		 */
		'recus'                  => 'ecriture_id',
	);

	/** La vérification avant comptabilisation est-elle activée globalement ? */
	/**
	 * Le brouillard est-il actif ?
	 *
	 * ACTIF PAR DÉFAUT depuis la 1.223.0, et ce changement est le plus important
	 * de cette version. Auparavant le paramètre valait '0' : toute écriture
	 * générée par un module — facture, achat, reçu, caisse, paie, royalties,
	 * dotation — partait DIRECTEMENT au grand livre définitif, sans relecture ni
	 * possibilité de correction. Or l'article 20 de l'Acte uniforme interdit
	 * toute altération d'une écriture enregistrée : une erreur ne se corrige
	 * qu'en contre-passant, ce qui alourdit le grand livre de deux écritures là
	 * où une relecture de trente secondes aurait suffi.
	 *
	 * Le brouillard rétablit l'ordre normal du travail comptable : la pièce
	 * produit une proposition d'écriture, un humain la contrôle et la corrige au
	 * besoin, puis la comptabilise. Le désactiver reste possible — certains
	 * flux de caisse à fort volume le justifient — mais c'est désormais un choix
	 * explicite, pas un défaut silencieux.
	 */
	public static function enabled() {
		return '1' === (string) FKC_License::param( self::PARAM, '1' );
	}
	public static function setEnabled( $on ) {
		FKC_License::setParam( self::PARAM, $on ? '1' : '0' );
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'brouillard_parametre', $on ? 'activé' : 'DÉSACTIVÉ — les écritures partent directement au grand livre' );
		}
	}

	/**
	 * Colonnes additives du brouillard, créées à la demande.
	 *
	 * Les lignes de brouillon ne portaient ni tiers ni devise : une écriture
	 * transitant par le brouillard perdait donc son montant d'origine et son
	 * cours, et la revalorisation de clôture ne la voyait plus.
	 */
	public static function assurerSchema() {
				/*
		 * Sentinelle indexée par BASE DE DONNÉES, et non un simple booléen.
		 *
		 * Un cabinet qui enchaîne deux dossiers dans la même requête — clôture
		 * de portefeuille, tâche planifiée, appel API — voyait la seconde
		 * société privée de ces tables : la sentinelle était déjà levée par la
		 * première, et le schéma n'était jamais créé. Les écritures échouaient
		 * alors sans que la cause soit lisible.
		 */
		static $faits = array();
		$cle = FKC_DB::file();
		if ( isset( $faits[ $cle ] ) ) { return; }
		$faits[ $cle ] = true;
		$cols = array(
			'tiers_type'     => 'TEXT',
			'tiers_id'       => 'INTEGER',
			'devise'         => 'TEXT',
			'montant_devise' => 'REAL',
			'taux_change'    => 'REAL',
			/*
			 * 1.745.0 — AFFECTATIONS MULTI-AXES. Une ligne n'y gardait qu'un
			 * couple axe/valeur : une charge ventilée sur un client ET un
			 * projet perdait un des deux axes en passant par le journal
			 * temporaire. Stockées telles quelles (JSON axe => valeur).
			 */
			'affectations'   => 'TEXT',
		);
		try {
			$info = FKC_DB::q( 'PRAGMA table_info(ecriture_brouillon_lignes)' )->fetchAll();
		} catch ( \Throwable $e ) { return; }
		if ( ! $info ) { return; }
		$presentes = array();
		foreach ( $info as $c ) { $presentes[ $c['name'] ] = true; }
		foreach ( $cols as $nom => $type ) {
			if ( isset( $presentes[ $nom ] ) ) { continue; }
			try { FKC_DB::conn()->exec( "ALTER TABLE ecriture_brouillon_lignes ADD COLUMN {$nom} {$type}" ); } catch ( \Throwable $e ) {}
		}

		/*
		 * RETENUE — le frein à main de la temporisation (1.538.0).
		 *
		 * Le mode temporisé publie une écriture au bout d'un délai si
		 * personne n'a rien dit. Encore faut-il pouvoir dire quelque chose :
		 * sans ce drapeau, la personne qui met une pièce douteuse de côté pour
		 * réunir un justificatif la retrouverait publiée le lendemain. Retenir
		 * suspend l'horloge, sans rien décider d'autre — ce n'est ni un refus
		 * ni une validation, c'est « pas encore ».
		 */
		try {
			$infoB = FKC_DB::q( 'PRAGMA table_info(ecritures_brouillon)' )->fetchAll();
		} catch ( \Throwable $e ) { return; }
		$colB = array();
		foreach ( $infoB as $c ) { $colB[ $c['name'] ] = true; }
		if ( ! isset( $colB['retenu'] ) ) {
			try { FKC_DB::conn()->exec( 'ALTER TABLE ecritures_brouillon ADD COLUMN retenu INTEGER NOT NULL DEFAULT 0' ); } catch ( \Throwable $e ) {}
		}
		if ( ! isset( $colB['retenu_motif'] ) ) {
			try { FKC_DB::conn()->exec( 'ALTER TABLE ecritures_brouillon ADD COLUMN retenu_motif TEXT' ); } catch ( \Throwable $e ) {}
		}
		/*
		 * NATURE D'INVENTAIRE — à retenir, sinon elle se perd (1.542.0).
		 *
		 * Une dotation d'amortissement ou une dépréciation est datée du
		 * dernier jour de l'exercice : c'est une écriture d'inventaire, et
		 * FKC_Ecriture::prepare() l'autorise dans un mois déjà verrouillé
		 * (seule la clôture de l'EXERCICE l'arrête).
		 *
		 * Mais dès lors qu'elle transite par le journal temporaire, elle est
		 * ré-préparée à la validation à partir de ce qui est stocké ici. Sans
		 * cette colonne, elle y perdrait sa nature et se heurterait au verrou
		 * mensuel : déposée sans problème, impossible à valider. On aurait
		 * refermé le piège à l'aller et rouvert au retour.
		 */
		if ( ! isset( $colB['inventaire'] ) ) {
			try { FKC_DB::conn()->exec( 'ALTER TABLE ecritures_brouillon ADD COLUMN inventaire INTEGER NOT NULL DEFAULT 0' ); } catch ( \Throwable $e ) {}
		}
		/*
		 * PROVENANCE — même raisonnement que la nature d'inventaire ci-dessus,
		 * et exactement le même piège : ce que le brouillon ne stocke pas, la
		 * validation ne peut pas le rendre. `source` et `lien` existaient déjà ;
		 * l'origine, le fait et le référentiel leur manquaient.
		 */
		/*
		 * 1.745.0 — NUMÉRO ET TYPE D'ÉCRITURE. Une contre-passation porte le
		 * numéro de l'écriture qu'elle annule et le type « annulation ».
		 * Déposée au journal temporaire sans ces deux colonnes, elle aurait
		 * été validée comme une opération nouvelle, sous un autre numéro.
		 */
		foreach ( array( 'origine', 'fait', 'referentiel', 'regime', 'numero', 'type_ecriture' ) as $col ) {
			if ( isset( $colB[ $col ] ) ) { continue; }
			try { FKC_DB::conn()->exec( 'ALTER TABLE ecritures_brouillon ADD COLUMN ' . $col . ' TEXT' ); } catch ( \Throwable $e ) {}
		}
	}

	/**
	 * Retient (ou relâche) une écriture : la temporisation ne la publiera pas.
	 *
	 * @param int    $id
	 * @param bool   $on
	 * @param string $motif Raison de la retenue — utile à celui qui reprendra
	 *                      le dossier, et à celui qui se demandera pourquoi
	 *                      cette pièce est encore là dans trois semaines.
	 * @return array{bool, string}
	 */
	public static function retenir( $id, $on = true, $motif = '' ) {
		self::assurerSchema();
		if ( ! self::find( $id ) ) { return array( false, 'Écriture en attente introuvable.' ); }
		try {
			FKC_DB::q( 'UPDATE ecritures_brouillon SET retenu=?, retenu_motif=? WHERE id=?',
				array( $on ? 1 : 0, $on ? trim( (string) $motif ) : null, (int) $id ) );
		} catch ( \Throwable $e ) { return array( false, 'Retenue impossible : ' . $e->getMessage() ); }
		if ( class_exists( 'FKC_Security' ) ) {
			FKC_Security::audit( 'brouillard_retenue', ( $on ? 'retenue #' : 'relâchée #' ) . (int) $id . ( $motif ? ' — ' . $motif : '' ) );
		}
		return array( true, $on
			? 'Écriture retenue : elle ne sera pas publiée automatiquement tant que vous ne l\'aurez pas relâchée.'
			: 'Retenue levée : l\'écriture reprend son cours normal.' );
	}

	/**
	 * Contrôles à présenter AVANT de comptabiliser un brouillon.
	 *
	 * Le bouton « Comptabiliser » existait sans qu'aucun état des lieux ne soit
	 * affiché : l'utilisateur validait sans savoir ce qu'il validait. Cette
	 * méthode renvoie une liste de vérifications, chacune avec son niveau —
	 * « bloquant » empêche la comptabilisation, « avertissement » la laisse
	 * passer sous la responsabilité de l'utilisateur.
	 *
	 * @param int $id Identifiant du brouillon.
	 * @return array{ok:bool,controles:array,bloquants:int,avertissements:int}
	 */
	public static function controler( $id ) {
		self::assurerSchema();
		$b = self::withLignes( $id );
		$c = array();
		if ( ! $b ) {
			return array( 'ok' => false, 'controles' => array( array( 'niveau' => 'bloquant', 'texte' => 'Brouillon introuvable.' ) ), 'bloquants' => 1, 'avertissements' => 0 );
		}

		// 1. Équilibre — la condition non négociable de la partie double.
		$td = 0.0; $tc = 0.0;
		foreach ( $b['lignes'] as $l ) { $td += (float) $l['debit']; $tc += (float) $l['credit']; }
		if ( fkc_equilibre( $td, $tc ) ) {
			$c[] = array( 'niveau' => 'ok', 'texte' => 'Écriture équilibrée : ' . fkc_money( $td ) . ' au débit comme au crédit.' );
		} else {
			$c[] = array( 'niveau' => 'bloquant', 'texte' => 'Écriture déséquilibrée : débit ' . fkc_money( $td ) . ' ≠ crédit ' . fkc_money( $tc ) . '.' );
		}

		// 2. Nombre de lignes.
		if ( count( $b['lignes'] ) < 2 ) {
			$c[] = array( 'niveau' => 'bloquant', 'texte' => 'Une écriture doit comporter au moins deux lignes.' );
		}

		/*
		 * 3. Période clôturée — avec la même distinction qu'à la saisie.
		 *
		 * Une écriture d'INVENTAIRE (dotation d'amortissement, dépréciation)
		 * est datée du dernier jour de l'exercice et produite après lui :
		 * seule la clôture de l'EXERCICE l'arrête, pas le verrou d'un mois.
		 * Ce contrôle doit donc dire exactement ce que FKC_Ecriture::prepare()
		 * fera ensuite — sinon il annoncerait un blocage qui n'aura pas lieu,
		 * ou pire, un feu vert que la comptabilisation démentirait.
		 */
		$inv = ! empty( $b['inventaire'] );
		if ( class_exists( 'FKC_Cloture' ) && $inv && FKC_Cloture::isExerciceClos( $b['date_ecriture'] ) ) {
			$c[] = array( 'niveau' => 'bloquant', 'texte' => 'L\'exercice couvrant le ' . $b['date_ecriture']
				. ' est clos : cette écriture d\'inventaire modifierait un résultat déjà déterminé.' );
		} elseif ( class_exists( 'FKC_Cloture' ) && ! $inv && FKC_Cloture::isLocked( $b['date_ecriture'] ) ) {
			$c[] = array( 'niveau' => 'bloquant', 'texte' => 'La période du ' . $b['date_ecriture'] . ' est clôturée : cette écriture ne peut pas y être comptabilisée. Changez la date ou rouvrez la période.' );
		} else {
			$c[] = array( 'niveau' => 'ok', 'texte' => $inv
				? 'Écriture d\'inventaire — exercice ' . substr( (string) $b['date_ecriture'], 0, 4 ) . ' ouvert.'
				: 'Période du ' . $b['date_ecriture'] . ' ouverte.' );
		}

		// 4. Comptes existants et de détail — on ne poste pas sur un compte
		//    collectif, ce serait irrégulier au regard du plan.
		$inconnus = array(); $collectifs = array();
		foreach ( $b['lignes'] as $l ) {
			try {
				$cpt = FKC_DB::q( 'SELECT numero, libelle, type FROM comptes WHERE id=?', array( (int) $l['compte_id'] ) )->fetch();
			} catch ( \Throwable $e ) { $cpt = null; }
			if ( ! $cpt ) { $inconnus[] = (int) $l['compte_id']; continue; }
			if ( isset( $cpt['type'] ) && 'detail' !== (string) $cpt['type'] ) { $collectifs[] = $cpt['numero']; }
		}
		if ( $inconnus )  { $c[] = array( 'niveau' => 'bloquant', 'texte' => count( $inconnus ) . ' ligne(s) pointent un compte inexistant.' ); }
		if ( $collectifs ) { $c[] = array( 'niveau' => 'avertissement', 'texte' => 'Compte(s) non détaillé(s) utilisé(s) : ' . implode( ', ', array_unique( $collectifs ) ) . '. Un compte collectif ne devrait pas recevoir d\'écriture.' ); }

		// 5. Pièce justificative — exigence de l'article 17 de l'Acte uniforme.
		$nbPieces = 0;
		if ( class_exists( 'FKC_PieceJointe' ) ) {
			try { $nbPieces = (int) FKC_DB::q( "SELECT COUNT(*) FROM pieces_jointes WHERE source_type='brouillon' AND source_id=?", array( (int) $id ) )->fetchColumn(); } catch ( \Throwable $e ) {}
		}
		if ( $nbPieces > 0 ) {
			$c[] = array( 'niveau' => 'ok', 'texte' => $nbPieces . ' justificatif(s) attaché(s).' );
		} else {
			$c[] = array( 'niveau' => 'avertissement', 'texte' => 'Aucun justificatif attaché. Toute écriture doit être appuyée d\'une pièce datée.' );
		}

		// 6. Traçabilité devise et cours disponible.
		if ( class_exists( 'FKC_Devise' ) ) {
			$pivot = FKC_Devise::pivot();
			foreach ( $b['lignes'] as $l ) {
				$dev = isset( $l['devise'] ) ? (string) $l['devise'] : '';
				if ( '' === $dev || $dev === $pivot ) { continue; }
				if ( empty( $l['taux_change'] ) || empty( $l['montant_devise'] ) ) {
					$c[] = array( 'niveau' => 'avertissement', 'texte' => 'Ligne en ' . $dev . ' sans cours ni montant d\'origine : elle ne pourra pas être revalorisée à la clôture.' );
					continue;
				}
				$c[] = array( 'niveau' => 'ok', 'texte' => 'Ligne en ' . $dev . ' au cours de ' . $l['taux_change'] . ' (montant d\'origine conservé).' );
			}
		}

		// 7. Pièce d'origine : la comptabilisation la marquera comme passée.
		if ( ! empty( $b['lien'] ) ) {
			$lien = json_decode( (string) $b['lien'], true );
			if ( is_array( $lien ) && ! empty( $lien['table'] ) ) {
				$c[] = array( 'niveau' => 'info', 'texte' => 'La comptabilisation marquera la pièce d\'origine (' . $lien['table'] . ') comme comptabilisée.' );
			}
		}

		$bloquants = 0; $avert = 0;
		foreach ( $c as $x ) {
			if ( 'bloquant' === $x['niveau'] ) { $bloquants++; }
			if ( 'avertissement' === $x['niveau'] ) { $avert++; }
		}
		return array( 'ok' => 0 === $bloquants, 'controles' => $c, 'bloquants' => $bloquants, 'avertissements' => $avert );
	}

	/** Nombre d'écritures en attente dans le brouillard. */
	public static function count() {
		return (int) FKC_DB::q( 'SELECT COUNT(*) FROM ecritures_brouillon' )->fetchColumn();
	}

	/**
	 * CE QUI ATTEND AU JOURNAL TEMPORAIRE, PAR CLASSE ET SUR UNE PÉRIODE (1.729.0).
	 *
	 * POURQUOI CETTE MÉTHODE EXISTE
	 *
	 * Le chiffre d'affaires du cockpit se lit dans le GRAND LIVRE, et il a
	 * raison : une écriture non validée n'est pas de la comptabilité. Mais la
	 * politique de comptabilisation range par défaut les ventes au journal
	 * temporaire — c'est un choix prudent, et il est juste. La conséquence ne
	 * l'était pas : un dossier pouvait afficher neuf factures émises, un
	 * encours de 255 000 au recouvrement, et un chiffre d'affaires à ZÉRO,
	 * sans qu'un seul écran explique l'écart.
	 *
	 * Le chiffre n'était pas faux. Il était incomplet, et rien ne le disait —
	 * ce qui est pire qu'une erreur, car on cherche l'erreur ailleurs.
	 *
	 * @return array{produits: float, charges: float, nombre: int}
	 */
	public static function enAttenteParClasse( $d1 = null, $d2 = null ) {
		$out = array( 'produits' => 0.0, 'charges' => 0.0, 'nombre' => 0 );
		try {
			self::assurerSchema();
			$sql = "SELECT substr(c.numero,1,1) AS cl,
			               COALESCE(SUM(l.debit),0) AS d, COALESCE(SUM(l.credit),0) AS cr,
			               COUNT(DISTINCT b.id) AS n
			        FROM ecriture_brouillon_lignes l
			        JOIN ecritures_brouillon b ON b.id = l.brouillon_id
			        JOIN comptes c ON c.id = l.compte_id
			        WHERE (c.numero LIKE '6%' OR c.numero LIKE '7%')";
			$args = array();
			if ( $d1 && $d2 ) { $sql .= ' AND b.date_ecriture BETWEEN ? AND ?'; $args = array( $d1, $d2 ); }
			$sql .= ' GROUP BY cl';
			foreach ( FKC_DB::q( $sql, $args )->fetchAll() as $r ) {
				$d = (float) $r['d']; $cr = (float) $r['cr'];
				if ( '7' === (string) $r['cl'] ) { $out['produits'] += $cr - $d; }
				else { $out['charges'] += $d - $cr; }
				$out['nombre'] = max( $out['nombre'], (int) $r['n'] );
			}
		} catch ( \Throwable $e ) { return $out; }
		$out['produits'] = round( $out['produits'], 2 );
		$out['charges']  = round( $out['charges'], 2 );
		return $out;
	}

	/** Liste des brouillons avec leurs totaux et le code journal. */
	public static function all( $limit = 300 ) {
		// La colonne `retenu` est lue par la temporisation : sans cet appel,
		// un dossier antérieur à la 1.538.0 ferait échouer la requête.
		self::assurerSchema();
		$limit = (int) $limit;
		return FKC_DB::q(
			"SELECT b.*, j.code AS journal_code, j.libelle AS journal_libelle,
				COALESCE(SUM(l.debit),0) AS total_debit, COALESCE(SUM(l.credit),0) AS total_credit,
				COUNT(l.id) AS nb_lignes
			 FROM ecritures_brouillon b
			 JOIN journaux j ON j.id=b.journal_id
			 LEFT JOIN ecriture_brouillon_lignes l ON l.brouillon_id=b.id
			 GROUP BY b.id
			 ORDER BY b.date_ecriture DESC, b.id DESC
			 LIMIT {$limit}"
		)->fetchAll();
	}

	/**
	 * Nombre d'écritures en attente, par origine — exact, quel que soit le volume.
	 *
	 * POURQUOI CETTE MÉTHODE EXISTE (1.543.0)
	 *
	 * La synthèse du journal temporaire chargeait TOUTES les écritures en
	 * mémoire — jointure sur les lignes, agrégat des débits/crédits comprise —
	 * pour n'en garder qu'un compteur par origine. Deux défauts, dont un grave :
	 *
	 *   — le travail était démesuré : agréger les lignes de milliers
	 *     d'écritures pour afficher un nombre ;
	 *   — surtout, l'appel était plafonné à 5 000 lignes. Au-delà, la synthèse
	 *     annonçait un total FAUX, plus petit que la réalité, sans le dire.
	 *     Un comptable lisant « 5 000 en attente » aurait cru avoir tout vu.
	 *
	 * Ce plafond était théorique tant que la plupart des écritures partaient
	 * directement. Depuis que TOUTE écriture passe par le journal temporaire
	 * (1.541.0), il ne l'est plus : un commerce à 200 tickets par jour
	 * l'atteint en un mois.
	 *
	 * Compter est le travail de la base, pas de PHP.
	 *
	 * @return array source => nombre.
	 */
	public static function compterParSource() {
		self::assurerSchema();
		try {
			$rows = FKC_DB::q( "SELECT COALESCE(NULLIF(source,''),'manuelle') AS source, COUNT(*) AS nb
				FROM ecritures_brouillon GROUP BY 1 ORDER BY 1" )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		$out = array();
		foreach ( $rows as $r ) { $out[ (string) $r['source'] ] = (int) $r['nb']; }
		return $out;
	}

	/** Nombre total d'écritures en attente. */
	public static function compter() {
		self::assurerSchema();
		try { return (int) FKC_DB::q( 'SELECT COUNT(*) FROM ecritures_brouillon' )->fetchColumn(); }
		catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Écritures en attente pour un ensemble d'origines.
	 *
	 * Le tri par défaut est du PLUS ANCIEN au plus récent, et ce n'est pas un
	 * détail : les traitements par lot (publication d'un déclencheur,
	 * temporisation échue) écrêtent au-delà d'une limite. Trié du plus récent
	 * au plus ancien — ce que faisait `all()` —, l'écrêtage éliminait
	 * précisément les écritures qui attendaient depuis le plus longtemps,
	 * c'est-à-dire celles qu'il fallait traiter en premier. Elles ne
	 * seraient JAMAIS parties.
	 *
	 * @param array  $sources Origines retenues. Vide ⇒ aucune ligne (et non
	 *                        toutes : un filtre vide qui renverrait tout est
	 *                        la manière classique de publier par accident ce
	 *                        qu'on voulait exclure).
	 * @param int    $limit
	 * @param string $ordre   'ancien' (défaut) ou 'recent'.
	 */
	public static function parSource( array $sources, $limit = 500, $ordre = 'ancien' ) {
		self::assurerSchema();
		$sources = array_values( array_unique( array_map( 'strval', $sources ) ) );
		if ( ! $sources ) { return array(); }
		$place = implode( ',', array_fill( 0, count( $sources ), '?' ) );
		$sens  = ( 'recent' === $ordre ) ? 'DESC' : 'ASC';
		$limit = max( 1, (int) $limit );
		try {
			return FKC_DB::q(
				"SELECT b.*, j.code AS journal_code, j.libelle AS journal_libelle,
					COALESCE(SUM(l.debit),0) AS total_debit, COALESCE(SUM(l.credit),0) AS total_credit,
					COUNT(l.id) AS nb_lignes
				 FROM ecritures_brouillon b
				 JOIN journaux j ON j.id=b.journal_id
				 LEFT JOIN ecriture_brouillon_lignes l ON l.brouillon_id=b.id
				 WHERE COALESCE(NULLIF(b.source,''),'manuelle') IN ({$place})
				 GROUP BY b.id
				 ORDER BY b.created_at {$sens}, b.id {$sens}
				 LIMIT {$limit}", $sources
			)->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
	}

	/**
	 * Ancienneté du journal temporaire : combien dorment depuis plus de N jours.
	 *
	 * Comptée en base, sur la totalité : l'écran affichait cette alerte
	 * d'après les 300 écritures qu'il avait sous la main, donc pouvait
	 * annoncer « rien d'ancien » alors que les plus vieilles étaient
	 * justement celles qu'il n'avait pas chargées.
	 *
	 * @return array{nb:int, plus_ancien:int, seuil:int}
	 */
	public static function anciennete( $seuilJours = 7 ) {
		self::assurerSchema();
		$seuil = max( 1, (int) $seuilJours );
		try {
			/*
			 * Le seuil est interpolé, pas lié — et c'est délibéré.
			 *
			 * PDO lie les paramètres en TEXTE. Or SQLite compare un REAL à un
			 * TEXT en donnant la priorité au TEXT : `julianday(...) >= '7'`
			 * est TOUJOURS faux. Le compteur renvoyait donc zéro quel que
			 * soit le nombre d'écritures anciennes — une alerte d'engorgement
			 * qui ne se déclenche jamais est pire que pas d'alerte du tout.
			 * `$seuil` est un entier borné juste au-dessus : aucune valeur
			 * externe n'entre ici.
			 */
			$r = FKC_DB::q( "SELECT
					SUM(CASE WHEN julianday('now','localtime') - julianday(created_at) >= {$seuil} THEN 1 ELSE 0 END) AS nb,
					MAX(julianday('now','localtime') - julianday(created_at)) AS vieux
				 FROM ecritures_brouillon" )->fetch();
		} catch ( \Throwable $e ) { return array( 'nb' => 0, 'plus_ancien' => 0, 'seuil' => $seuil ); }
		return array(
			'nb'          => (int) ( $r['nb'] ?? 0 ),
			'plus_ancien' => (int) floor( (float) ( $r['vieux'] ?? 0 ) ),
			'seuil'       => $seuil,
		);
	}

	public static function find( $id ) {
		$r = FKC_DB::q( 'SELECT * FROM ecritures_brouillon WHERE id=?', array( (int) $id ) )->fetch();
		return $r ?: null;
	}

	public static function withLignes( $id ) {
		self::assurerSchema();
		$head = FKC_DB::q(
			'SELECT b.*, j.code AS journal_code, j.libelle AS journal_libelle
			 FROM ecritures_brouillon b JOIN journaux j ON j.id=b.journal_id WHERE b.id=?',
			array( (int) $id )
		)->fetch();
		if ( ! $head ) { return null; }
		$head['lignes'] = FKC_DB::q(
			'SELECT l.*, c.numero AS compte_numero, c.libelle AS compte_libelle
			 FROM ecriture_brouillon_lignes l JOIN comptes c ON c.id=l.compte_id
			 WHERE l.brouillon_id=? ORDER BY l.ordre ASC, l.id ASC',
			array( (int) $id )
		)->fetchAll();
		return $head;
	}

	/**
	 * Dépose une écriture au brouillard (après contrôle d'équilibre et de période).
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null brouillon_id )
	 */
	public static function save( $entete, $lignes, $source = 'manuelle', $lien = null ) {
		self::assurerSchema();
		list( $ok, $msg, $clean ) = FKC_Ecriture::prepare( $entete, $lignes );
		if ( ! $ok ) { return array( false, $msg, null ); }

		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $entete, $clean, $source, $lien ) {
			/*
			 * La provenance est DÉPOSÉE avec le brouillon pour être restituée à
			 * la validation. C'est le même piège que la nature d'inventaire de
			 * 1.542.0 : ce qui n'est pas stocké ici n'existe plus au retour.
			 */
			$db->prepare( 'INSERT INTO ecritures_brouillon(journal_id,date_ecriture,piece,libelle,reference,source,lien,inventaire,origine,fait,referentiel,regime,created_by,numero,type_ecriture) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)' )
			   ->execute( array(
					(int) $entete['journal_id'], $entete['date_ecriture'],
					isset( $entete['piece'] ) ? $entete['piece'] : null,
					$entete['libelle'],
					isset( $entete['reference'] ) ? $entete['reference'] : null,
					(string) $source,
					$lien ? (string) json_encode( $lien, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : null,
					empty( $entete['inventaire'] ) ? 0 : 1,
					! empty( $entete['origine'] ) ? (string) $entete['origine'] : null,
					! empty( $entete['fait'] ) ? (string) $entete['fait'] : null,
					! empty( $entete['referentiel'] ) ? (string) $entete['referentiel'] : null,
					! empty( $entete['regime'] ) ? (string) $entete['regime'] : null,
					isset( $entete['created_by'] ) ? $entete['created_by'] : null,
					! empty( $entete['numero'] ) ? (string) $entete['numero'] : null,
					! empty( $entete['type_ecriture'] ) ? (string) $entete['type_ecriture'] : null,
			   ) );
			$bid = (int) $db->lastInsertId();
			$ins = $db->prepare( 'INSERT INTO ecriture_brouillon_lignes(brouillon_id,compte_id,libelle,debit,credit,ordre,division_id,axe_id,valeur_id,tiers_type,tiers_id,devise,montant_devise,taux_change,affectations) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)' );
			$i = 0;
			foreach ( $clean as $l ) {
				$ins->execute( array( $bid, $l['compte_id'], $l['libelle'], $l['debit'], $l['credit'], $i++, $l['division_id'],
					$l['axe_id'] ?? null, $l['valeur_id'] ?? null, $l['tiers_type'] ?? null, $l['tiers_id'] ?? null,
					$l['devise'] ?? null, $l['montant_devise'] ?? null, $l['taux_change'] ?? null,
					! empty( $l['affectations'] ) ? json_encode( $l['affectations'] ) : null ) );
			}
			return array( true, 'Écriture déposée au brouillard (à vérifier avant comptabilisation).', $bid );
			} );
		} catch ( Throwable $ex ) {
			fkc_log( 'Brouillard::save ' . $ex->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors du dépôt au brouillard.', null );
		}
	}

	/** Met à jour l'en-tête et les lignes d'un brouillon (re-contrôle d'équilibre). */
	public static function update( $id, $entete, $lignes ) {
		self::assurerSchema();
		$b = self::find( $id );
		if ( ! $b ) { return array( false, 'Brouillon introuvable.' ); }
		list( $ok, $msg, $clean ) = FKC_Ecriture::prepare( $entete, $lignes );
		if ( ! $ok ) { return array( false, $msg ); }
		$db = FKC_DB::conn();
		try {
			return FKC_Tx::executer( function () use ( $db, $entete, $clean, $id ) {
			$db->prepare( 'UPDATE ecritures_brouillon SET journal_id=?,date_ecriture=?,piece=?,libelle=?,reference=? WHERE id=?' )
			   ->execute( array(
					(int) $entete['journal_id'], $entete['date_ecriture'],
					isset( $entete['piece'] ) ? $entete['piece'] : null,
					$entete['libelle'],
					isset( $entete['reference'] ) ? $entete['reference'] : null,
					(int) $id,
			   ) );
			$db->prepare( 'DELETE FROM ecriture_brouillon_lignes WHERE brouillon_id=?' )->execute( array( (int) $id ) );
			/*
			 * LES AFFECTATIONS MULTI-AXES SURVIVENT À UNE MODIFICATION (1.763.0).
			 *
			 * L'INSERT de la mise à jour omettait la colonne `affectations`,
			 * que celui de la création écrit pourtant : ouvrir un brouillon
			 * imputé sur trois axes et l'enregistrer — même sans y toucher —
			 * n'en gardait qu'un. Le brouillard est précisément l'endroit où
			 * l'on relit avant de comptabiliser ; il ne doit rien emporter au
			 * passage.
			 */
			$ins = $db->prepare( 'INSERT INTO ecriture_brouillon_lignes(brouillon_id,compte_id,libelle,debit,credit,ordre,division_id,axe_id,valeur_id,tiers_type,tiers_id,devise,montant_devise,taux_change,affectations) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)' );
			$i = 0;
			foreach ( $clean as $l ) {
				$ins->execute( array( (int) $id, $l['compte_id'], $l['libelle'], $l['debit'], $l['credit'], $i++, $l['division_id'],
					$l['axe_id'] ?? null, $l['valeur_id'] ?? null, $l['tiers_type'] ?? null, $l['tiers_id'] ?? null,
					$l['devise'] ?? null, $l['montant_devise'] ?? null, $l['taux_change'] ?? null,
					! empty( $l['affectations'] ) ? json_encode( $l['affectations'] ) : null ) );
			}
			return array( true, 'Brouillon mis à jour.' );
			} );
		} catch ( Throwable $ex ) {
			fkc_log( 'Brouillard::update ' . $ex->getMessage(), 'ERROR' );
			return array( false, 'Erreur lors de la mise à jour du brouillon.' );
		}
	}

	/** Supprime (rejette) un brouillon sans le comptabiliser. */
	public static function delete( $id ) {
		/*
		 * REJETER UNE CONTRE-PASSATION EN ATTENTE, C'EST RENONCER À
		 * L'ANNULATION (1.745.0). Les pièces qu'elle avait annulées — règlement,
		 * reçu, facture — retrouvent leur état : sinon un règlement resterait
		 * « annulé » alors que le grand livre, lui, n'a jamais bougé.
		 * valider() détache la contre-passation AVANT d'appeler cette méthode :
		 * une contre-passation validée ne déclenche donc rien ici.
		 */
		if ( class_exists( 'FKC_EcritureLiens' ) ) {
			try {
				$b = FKC_DB::q( 'SELECT reference FROM ecritures_brouillon WHERE id=?', array( (int) $id ) )->fetch();
				$ref = $b ? (string) $b['reference'] : '';
				if ( class_exists( 'FKC_EcritureAnnulation' ) && 0 === strpos( $ref, FKC_EcritureAnnulation::MARQUEUR ) ) {
					FKC_EcritureLiens::relierBrouillon( (int) substr( $ref, strlen( FKC_EcritureAnnulation::MARQUEUR ) ), (int) $id );
				}
			} catch ( \Throwable $e ) { fkc_log( 'Brouillard::delete relier ' . $e->getMessage(), 'ERROR' ); }
		}
		if ( class_exists( 'FKC_PieceJointe' ) ) { FKC_PieceJointe::purge( 'brouillon', $id ); }
		FKC_DB::q( 'DELETE FROM ecriture_brouillon_lignes WHERE brouillon_id=?', array( (int) $id ) );
		FKC_DB::q( 'DELETE FROM ecritures_brouillon WHERE id=?', array( (int) $id ) );
		return array( true, 'Brouillon supprimé.' );
	}

	/**
	 * Valide (comptabilise) un brouillon : crée l'écriture définitive, rattache la
	 * pièce d'origine le cas échéant, puis retire le brouillon.
	 * @return array{bool, string, int|null} ( bool ok, string message, int|null ecriture_id )
	 */
	public static function valider( $id ) {
		self::assurerSchema();
		$b = self::withLignes( $id );
		if ( ! $b ) { return array( false, 'Brouillon introuvable.', null ); }

		// Contrôles bloquants : on refuse plutôt que de laisser FKC_Ecriture
		// échouer plus loin avec un message moins parlant.
		$ctl = self::controler( $id );
		if ( ! $ctl['ok'] ) {
			$motifs = array();
			foreach ( $ctl['controles'] as $x ) {
				if ( 'bloquant' === $x['niveau'] ) { $motifs[] = $x['texte']; }
			}
			return array( false, 'Comptabilisation refusée : ' . implode( ' ', $motifs ), null );
		}
		$entete = array(
			'journal_id' => (int) $b['journal_id'], 'date_ecriture' => $b['date_ecriture'],
			'piece' => $b['piece'], 'libelle' => $b['libelle'], 'reference' => $b['reference'],
			'created_by' => $b['created_by'],
			// Restituée telle qu'elle a été déposée : sans elle, une dotation
			// ou une dépréciation d'inventaire buterait au retour sur le
			// verrou mensuel qu'elle avait le droit de franchir à l'aller.
			'inventaire' => ! empty( $b['inventaire'] ),
			/*
			 * PROVENANCE RESTITUÉE — le défaut central corrigé par ce lot.
			 *
			 * Cette méthode reportait le journal, la date, la pièce, le
			 * libellé, la référence, l'auteur et la nature d'inventaire, mais
			 * ni la source, ni l'origine, ni le fait, ni le référentiel : une
			 * écriture perdait son histoire au moment précis où elle devenait
			 * définitive.
			 *
			 * `lien` est reporté LUI AUSSI, en plus du backfill vers la pièce
			 * (qui écrit dans l'autre sens). Les deux directions sont utiles :
			 * la pièce doit connaître son écriture, et l'écriture sa pièce.
			 */
			'source'      => $b['source'] ?? null,
			'origine'     => $b['origine'] ?? null,
			'fait'        => $b['fait'] ?? null,
			'referentiel' => $b['referentiel'] ?? null,
			'regime'      => $b['regime'] ?? null,
			'lien'        => $b['lien'] ?? null,
			'numero'        => $b['numero'] ?? null,
			'type_ecriture' => $b['type_ecriture'] ?? null,
		);
		if ( empty( $entete['numero'] ) ) { unset( $entete['numero'] ); }
		if ( empty( $entete['type_ecriture'] ) ) { unset( $entete['type_ecriture'] ); }
		$lignes = array();
		foreach ( $b['lignes'] as $l ) {
			$lignes[] = array( 'compte_id' => (int) $l['compte_id'], 'libelle' => $l['libelle'],
				'debit' => (float) $l['debit'], 'credit' => (float) $l['credit'],
				'division_id' => $l['division_id'], 'axe_id' => $l['axe_id'] ?? null, 'valeur_id' => $l['valeur_id'] ?? null,
				'tiers_type' => $l['tiers_type'] ?? null, 'tiers_id' => $l['tiers_id'] ?? null,
				// Traçabilité devise reportée telle quelle : sans elle, la
				// revalorisation de clôture perdrait la position dès qu'une
				// écriture passe par le brouillard.
				'devise' => $l['devise'] ?? null, 'montant_devise' => $l['montant_devise'] ?? null,
				'taux_change' => $l['taux_change'] ?? null,
				'affectations' => ! empty( $l['affectations'] ) ? (array) json_decode( (string) $l['affectations'], true ) : array() );
		}
		list( $ok, $msg, $eid ) = FKC_Ecriture::save( $entete, $lignes );
		if ( ! $ok ) { return array( false, $msg, null ); }
		// Une contre-passation validée devient la contre-passation de référence
		// des pièces qu'elle a annulées (et cesse d'être « en attente »).
		if ( class_exists( 'FKC_EcritureLiens' ) && 0 === strpos( (string) $b['reference'], 'ANN#' ) ) {
			FKC_EcritureLiens::rattacherContrepassation( (int) $id, (int) $eid );
		}

		if ( ! empty( $b['lien'] ) ) {
			$lien = json_decode( $b['lien'], true );
			if ( is_array( $lien ) ) { self::backfill( $lien, $eid ); }
		} elseif ( class_exists( 'FKC_Origine' ) ) {
			/*
			 * Le journal temporaire est l'AUTRE chemin par lequel une
			 * écriture naît. Le pont posé sur la comptabilisation immédiate
			 * n'aurait rien couvert ici — et comme la temporisation est le
			 * réglage par défaut du produit depuis 1.541.0, le trou aurait
			 * concerné la majorité des dossiers tout en restant invisible
			 * sur ceux qui publient en direct.
			 */
			try { FKC_Origine::demander(); } catch ( \Throwable $e ) { /* la trace attendra */ }
		}
		/*
		 * PIÈCES DES DOSSIERS MÉTIERS (1.841.6).
		 *
		 * Une pièce verticale (note d'honoraires, pièce d'un dossier Santé…)
		 * ne pose pas de `lien` : elle est reconnue par sa référence
		 * « vp.piece#<id> ». Validée depuis le journal temporaire — le réglage
		 * par défaut — elle restait donc sans écriture : `vp_pieces.ecriture_id`
		 * demeurait vide, et tout ce qui la lit par ce lien (recouvrement,
		 * dossiers, Maestro) la tenait pour non comptabilisée.
		 */
		if ( preg_match( '/^vp\.piece#(\d+)$/', (string) ( $b['reference'] ?? '' ), $mm ) ) {
			try {
				FKC_DB::q( 'UPDATE vp_pieces SET ecriture_id=? WHERE id=? AND ( ecriture_id IS NULL OR ecriture_id=0 )', array( (int) $eid, (int) $mm[1] ) );
			} catch ( \Throwable $e ) { /* table absente : pack sans dossiers */ }
		}
		if ( class_exists( 'FKC_PieceJointe' ) ) { FKC_PieceJointe::reassign( 'brouillon', $id, 'ecriture', $eid ); }
		self::delete( $id );
		return array( true, 'Écriture comptabilisée (n°' . $eid . ').', $eid );
	}

	/** Valide tous les brouillons équilibrés. @return array( int ok, int echecs ) */
	public static function validerTout() {
		$ok = 0; $ko = 0;
		foreach ( self::all( 1000 ) as $b ) {
			list( $r ) = self::valider( $b['id'] );
			if ( $r ) { $ok++; } else { $ko++; }
		}
		return array( $ok, $ko );
	}

	/** Existe-t-il déjà un brouillon en attente rattaché à cette pièce ? */
	public static function hasPendingFor( $table, $docId ) {
		return (bool) self::pendingFor( $table, $docId );
	}

	/**
	 * Identifiants des brouillons EN ATTENTE rattachés à un document.
	 *
	 * `hasPendingFor()` répondait par oui ou non, ce qui suffit pour verrouiller
	 * un écran. Annuler ou corriger un document demande davantage : il faut
	 * pouvoir ATTEINDRE le brouillon pour le retirer. Sans cela, une facture
	 * annulée dont l'écriture dormait encore au brouillard voyait celle-ci
	 * validée plus tard, et comptabilisait une pièce qui n'existait plus.
	 *
	 * @return int[]
	 */
	public static function pendingFor( $table, $docId ) {
		$docId = (int) $docId;
		$out   = array();
		try {
			$rows = FKC_DB::q( "SELECT id, lien FROM ecritures_brouillon WHERE lien IS NOT NULL AND lien LIKE ?", array( '%"' . $table . '"%' ) )->fetchAll();
		} catch ( \Throwable $e ) { return array(); }
		foreach ( $rows as $r ) {
			$lien = json_decode( $r['lien'], true );
			if ( is_array( $lien ) && ( $lien['table'] ?? '' ) === $table && in_array( $docId, array_map( 'intval', (array) ( $lien['ids'] ?? array() ) ), true ) ) {
				$out[] = (int) $r['id'];
			}
		}
		return $out;
	}

	/**
	 * Brouillons EN ATTENTE pour toute une liste de documents, en UNE requête
	 * (1.742.0).
	 *
	 * `pendingFor()` interroge la table à chaque appel : parfait pour une
	 * fiche, ruineux pour une liste de 300 factures (300 lectures complètes du
	 * journal temporaire). Les listes appellent celle-ci.
	 *
	 * @param string $table
	 * @param int[]  $ids
	 * @return array<int, int[]> id du document => ids des brouillons (absent si aucun)
	 */
	public static function pendingMap( $table, array $ids ) {
		$ids = array_flip( array_filter( array_map( 'intval', $ids ) ) );
		$out = array();
		if ( ! $ids ) { return $out; }
		try {
			$rows = FKC_DB::q( "SELECT id, lien FROM ecritures_brouillon WHERE lien IS NOT NULL AND lien LIKE ?", array( '%"' . $table . '"%' ) )->fetchAll();
		} catch ( \Throwable $e ) { return $out; }
		foreach ( $rows as $r ) {
			$lien = json_decode( (string) $r['lien'], true );
			if ( ! is_array( $lien ) || ( $lien['table'] ?? '' ) !== $table ) { continue; }
			foreach ( (array) ( $lien['ids'] ?? array() ) as $docId ) {
				$docId = (int) $docId;
				if ( isset( $ids[ $docId ] ) ) { $out[ $docId ][] = (int) $r['id']; }
			}
		}
		return $out;
	}

	/** Rattache l'écriture créée à sa/ses pièce(s) d'origine (colonne ecriture_id). */
	public static function backfill( $lien, $eid ) {
		$table = isset( $lien['table'] ) ? (string) $lien['table'] : '';
		$col   = isset( $lien['colonne'] ) ? (string) $lien['colonne'] : 'ecriture_id';
		$ids   = array_values( array_filter( array_map( 'intval', (array) ( $lien['ids'] ?? array() ) ) ) );
		if ( ! isset( self::LIENS[ $table ] ) || ! $ids ) { return; }
		$autorisees = (array) self::LIENS[ $table ];
		if ( ! in_array( $col, $autorisees, true ) ) { return; }
		$place = implode( ',', array_fill( 0, count( $ids ), '?' ) );
		try {
			FKC_DB::q( "UPDATE {$table} SET {$col}=? WHERE id IN ({$place})", array_merge( array( (int) $eid ), $ids ) );
		} catch ( Throwable $e ) {
			fkc_log( 'Brouillard::backfill ' . $e->getMessage(), 'ERROR' );
		}
	}
}
