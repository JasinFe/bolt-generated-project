<?php
/**
 * Contrôleur Santé — écrans partagés de la famille Santé : planning des
 * consultations, praticiens & rétrocessions, hospitalisation, DME. Chaque
 * pack n'en reçoit que ce que son métier pratique (voir index.php).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteController {

	protected function module() { return FKC_Packs::activeCode(); }
	protected function setFlash( $ok, $msg ) { $_SESSION['__sante_flash'] = array( 'ok' => (bool) $ok, 'msg' => (string) $msg ); }
	protected function flash() { $f = $_SESSION['__sante_flash'] ?? null; unset( $_SESSION['__sante_flash'] ); return $f; }

	/* ── Planning des consultations ──────────────────────────────────────── */
	public function planning() {
		$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $_GET['date'] ?? '' ) ) && strtotime( $_GET['date'] ) ? $_GET['date'] : date( 'Y-m-d' );
		$lundi = date( 'Y-m-d', strtotime( 'monday this week', strtotime( $date ) ) );
		FKC_View::render( 'sante::planning', array(
			'title' => 'Planning des consultations', 'module' => $this->module(),
			'date' => $date,
			'rdvs' => FKC_SantePlanning::jour( $date, (int) ( $_GET['praticien'] ?? 0 ) ),
			'praticienFiltre' => (int) ( $_GET['praticien'] ?? 0 ),
			'rappels' => FKC_SantePlanning::rappels(),
			'tauxAbsence' => FKC_SantePlanning::tauxAbsence( 90 ),
			'etablissement' => class_exists( 'FKC_Tenant' ) ? (string) ( ( (array) FKC_Tenant::current() )['raison_sociale'] ?? '' ) : '',
			'semaine' => FKC_SantePlanning::periode( $lundi, date( 'Y-m-d', strtotime( $lundi . ' +6 day' ) ) ),
			'lundi' => $lundi,
			'praticiens' => FKC_SantePraticien::tous(),
			'compteurs' => FKC_SantePlanning::compteursJour( $date ),
			'typePiece' => FKC_SantePlanning::typeConsultation(),
			'flash' => $this->flash(),
		) );
	}

	/** Date du rendez-vous, pour revenir sur le bon jour après une action. */
	protected function jourRdv( $id ) {
		$r = FKC_SantePlanning::find( (int) $id );
		return $r ? '?date=' . urlencode( (string) $r['date'] ) : '';
	}

	public function rdvCreer() {
		list( $ok, $msg ) = FKC_SantePlanning::create( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning?date=' . urlencode( (string) ( $_POST['date'] ?? date( 'Y-m-d' ) ) ) );
	}

	public function rdvFacturer( $id ) {
		$retour = $this->jourRdv( $id );
		list( $ok, $msg ) = FKC_SantePlanning::facturer( (int) $id );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning' . $retour );
	}

	public function rdvAbsent( $id ) {
		$retour = $this->jourRdv( $id );
		list( $ok, $msg ) = FKC_SantePlanning::absent( (int) $id );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning' . $retour );
	}

	public function rdvRappel( $id ) {
		list( $ok, $msg ) = FKC_SantePlanning::marquerRappel( (int) $id );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning' );
	}

	public function rdvAnnuler( $id ) {
		$retour = $this->jourRdv( $id );
		list( $ok, $msg ) = FKC_SantePlanning::annuler( (int) $id );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/planning' . $retour );
	}

	/* ── Praticiens & rétrocessions ──────────────────────────────────────── */
	public function praticiens() {
		$ym = preg_match( '/^\d{4}-\d{2}$/', (string) ( $_GET['mois'] ?? '' ) ) ? $_GET['mois'] : date( 'Y-m' );
		FKC_View::render( 'sante::praticiens', array(
			'title' => 'Praticiens & rétrocessions', 'module' => $this->module(),
			'praticiens' => FKC_SantePraticien::tous( false ),
			'mois' => $ym,
			'bordereau' => FKC_SantePraticien::bordereauRetrocessions( $ym ),
			'flash' => $this->flash(),
		) );
	}

	/** Mise à jour d'un praticien (tarif, taux, activation). */
	public function praticienMaj( $id ) {
		list( $ok, $msg ) = FKC_SantePraticien::update( (int) $id, $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/praticiens' );
	}

	/** Constate en comptabilité les rétrocessions du mois (632460 / 401140). */
	public function retrocessionsComptabiliser() {
		$ym = preg_match( '/^\d{4}-\d{2}$/', (string) ( $_POST['mois'] ?? '' ) ) ? $_POST['mois'] : date( 'Y-m' );
		list( $ok, $msg ) = FKC_SanteFacturation::comptabiliserRetrocessions( $ym );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/praticiens?mois=' . urlencode( $ym ) );
	}

	public function praticienCreer() {
		list( $ok, $msg ) = FKC_SantePraticien::create( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/praticiens' );
	}

	/* ── Tiers payant : conventions, bordereaux, rejets (1.859.0) ─────────── */
	public function assurances() {
		$ym  = preg_match( '/^\d{4}-\d{2}$/', (string) ( $_GET['mois'] ?? '' ) ) ? $_GET['mois'] : date( 'Y-m' );
		$ass = FKC_SanteTiersPayant::assureurs();
		$aid = (int) ( $_GET['assureur'] ?? 0 );
		if ( ! $aid && $ass ) { $aid = (int) $ass[0]['id']; }
		FKC_View::render( 'sante::assurances', array(
			'title' => 'Assurances & tiers payant', 'module' => $this->module(),
			'mois' => $ym, 'assureurs' => $ass, 'assureurId' => $aid,
			'bordereau' => $aid ? FKC_SanteTiersPayant::bordereau( $aid, $ym ) : array( 'lignes' => array(), 'delai' => 0 ),
			'conventions' => FKC_SanteTiersPayant::conventions(),
			'rejets' => $aid ? FKC_SanteTiersPayant::rejets( $aid ) : array(),
			'types' => (array) ( FKC_Packs::verticalConfig()['pieces'] ?? array() ),
			'imprimer' => ! empty( $_GET['imprimer'] ),
			'flash' => $this->flash(),
		) );
	}

	public function assurancesAction() {
		$retour = '?mois=' . urlencode( (string) ( $_POST['mois'] ?? date( 'Y-m' ) ) ) . '&assureur=' . (int) ( $_POST['assureur_id'] ?? 0 );
		switch ( (string) ( $_POST['action'] ?? '' ) ) {
			case 'convention':
				list( $ok, $msg ) = FKC_SanteTiersPayant::enregistrerConvention( $_POST );
				break;
			case 'supprimer_convention':
				list( $ok, $msg ) = FKC_SanteTiersPayant::supprimerConvention( (int) ( $_POST['id'] ?? 0 ) );
				break;
			case 'rejet':
				list( $ok, $msg ) = FKC_SanteTiersPayant::rejeter( (int) ( $_POST['pec_id'] ?? 0 ), (float) str_replace( array( ' ', ',' ), array( '', '.' ), (string) ( $_POST['montant'] ?? 0 ) ), (string) ( $_POST['motif'] ?? '' ), (string) ( $_POST['imputation'] ?? 'patient' ) );
				break;
			default:
				$ok = false; $msg = 'Action inconnue.';
		}
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/assurances' . $retour );
	}

	/* ── Hospitalisation ─────────────────────────────────────────────────── */
	public function hospitalisation() {
		FKC_View::render( 'sante::hospitalisation', array(
			'title' => 'Hospitalisation', 'module' => $this->module(),
			'lits' => FKC_SanteHospit::lits(),
			'occupation' => FKC_SanteHospit::occupation(),
			'sejours' => FKC_SanteHospit::sejoursEnCours(),
			'sorties' => FKC_SanteHospit::sortiesRecentes( 8 ),
			'dms' => FKC_SanteHospit::dms(),
			'services' => FKC_SanteHospit::services(),
			'flash' => $this->flash(),
		) );
	}

	public function litCreer() {
		list( $ok, $msg ) = FKC_SanteHospit::creerLit( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function admettre() {
		list( $ok, $msg ) = FKC_SanteHospit::admettre( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function sejourFacturer( $sejourId ) {
		list( $ok, $msg ) = FKC_SanteHospit::facturerIntermediaire( (int) $sejourId, (string) ( $_POST['date'] ?? '' ) ?: null );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function sejourTransferer( $sejourId ) {
		list( $ok, $msg ) = FKC_SanteHospit::transferer( (int) $sejourId, (int) ( $_POST['lit_id'] ?? 0 ), (string) ( $_POST['date'] ?? '' ) ?: null );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function forfaitService() {
		list( $ok, $msg ) = FKC_SanteHospit::enregistrerForfait( (string) ( $_POST['service'] ?? '' ), (float) ( $_POST['forfait_jour'] ?? 0 ) );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	public function sortir( $sejourId ) {
		list( $ok, $msg ) = FKC_SanteHospit::sortir( (int) $sejourId, (string) ( $_POST['sortie'] ?? '' ) ?: null );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/hospitalisation' );
	}

	/* ── Dossier médical électronique (DME) ──────────────────────────────── */

	public function dossiers() {
		FKC_View::render( 'sante::dossiers', array(
			'title' => 'Dossiers médicaux', 'module' => $this->module(),
			'patients' => FKC_SanteDossier::patients( (string) ( $_GET['q'] ?? '' ) ),
			'q' => (string) ( $_GET['q'] ?? '' ),
			'flash' => $this->flash(),
		) );
	}

	public function patientCreer() {
		list( $ok, $msg, $id ) = FKC_SanteDossier::creerPatient( $_POST );
		$this->setFlash( $ok, $msg );
		redirect( $this->module() . '/dme' . ( $ok && $id ? '/' . $id : '' ) );
	}

	public function dossier( $id ) {
		$p = FKC_SanteDossier::patient( (int) $id );
		if ( ! $p ) { $this->setFlash( false, 'Patient introuvable.' ); return redirect( $this->module() . '/dme' ); }
		FKC_SanteDossier::tracer( (int) $id, 'consultation du dossier' );
		$consults = FKC_SanteDossier::consultations( (int) $id );
		$prescr = array();
		foreach ( $consults as $c ) { $prescr[ (int) $c['id'] ] = FKC_SanteDossier::prescriptions( (int) $c['id'] ); }
		FKC_View::render( 'sante::dossier', array(
			'title' => 'Dossier · ' . $p['nom'], 'module' => $this->module(),
			'p' => $p, 'age' => FKC_SanteDossier::age( $p ),
			'allergies' => FKC_SanteDossier::allergies( (int) $id ),
			'antecedents' => FKC_SanteDossier::antecedents( (int) $id ),
			'consultations' => $consults, 'prescriptions' => $prescr,
			'praticiens' => FKC_SantePraticien::tous(),
			'facturation' => $this->syntheseFacturation( $p ),
			'acces' => FKC_SanteDossier::acces( (int) $id ),
			'flash' => $this->flash(),
		) );
	}

	/** Pièces du dossier de facturation lié au patient (lecture seule, sans donnée clinique). */
	protected function syntheseFacturation( array $p ) {
		$did = (int) ( $p['dossier_id'] ?? 0 );
		if ( $did <= 0 || ! FKC_VpDossier::find( $did ) ) { return null; }
		$pieces = FKC_DB::q( 'SELECT id, type, numero, date_piece, libelle, montant_ht, tva_pct, statut FROM vp_pieces WHERE dossier_id=? ORDER BY date_piece DESC, id DESC LIMIT 10', array( $did ) )->fetchAll();
		$total = 0.0;
		foreach ( $pieces as $pc ) { $total += (float) $pc['montant_ht'] * ( 1 + (float) $pc['tva_pct'] / 100 ); }
		return array( 'dossier_id' => $did, 'pieces' => $pieces, 'total' => $total );
	}

	/** Ordonnance imprimable d'une consultation (1.859.0). */
	public function ordonnance( $id, $cid ) {
		$p = FKC_SanteDossier::patient( (int) $id );
		$c = $p ? FKC_DB::q( 'SELECT c.*, pr.nom praticien, pr.specialite FROM sante_consultations c LEFT JOIN sante_praticiens pr ON pr.id=c.praticien_id WHERE c.id=? AND c.patient_id=?', array( (int) $cid, (int) $id ) )->fetch() : null;
		if ( ! $c ) { $this->setFlash( false, 'Consultation introuvable.' ); return redirect( $this->module() . '/dme' . ( $p ? '/' . (int) $id : '' ) ); }
		FKC_SanteDossier::tracer( (int) $id, 'impression d\'ordonnance' );
		$soc = class_exists( 'FKC_Tenant' ) && method_exists( 'FKC_Tenant', 'current' ) ? (array) FKC_Tenant::current() : array();
		FKC_View::render( 'sante::ordonnance', array(
			'title' => 'Ordonnance · ' . $p['nom'], 'module' => $this->module(),
			'p' => $p, 'age' => FKC_SanteDossier::age( $p ), 'c' => $c,
			'lignes' => FKC_SanteDossier::prescriptions( (int) $cid ),
			'etablissement' => (string) ( $soc['raison_sociale'] ?? '' ),
		) );
	}

	/** Ouvre (ou crée) le dossier de facturation du patient, puis y conduit. */
	public function dossierFacturation( $id ) {
		list( $ok, $msg, $did ) = FKC_SanteDossier::dossierFacturation( (int) $id );
		if ( ! $ok ) { $this->setFlash( false, $msg ); return redirect( $this->module() . '/dme/' . (int) $id ); }
		redirect( $this->module() . '/dossiers/' . (int) $did );
	}

	public function dossierAction( $id ) {
		$id = (int) $id;
		if ( ! FKC_SanteDossier::patient( $id ) ) { $this->setFlash( false, 'Patient introuvable.' ); return redirect( $this->module() . '/dme' ); }
		FKC_SanteDossier::tracer( $id, 'saisie : ' . preg_replace( '/[^a-z_]/', '', (string) ( $_POST['action'] ?? '' ) ) );
		switch ( (string) ( $_POST['action'] ?? '' ) ) {
			case 'antecedent':
				list( $ok, $msg ) = FKC_SanteDossier::ajouterAntecedent( $id, $_POST['type'] ?? 'autre', $_POST['libelle'] ?? '', $_POST['depuis'] ?? '' );
				$this->setFlash( $ok, $msg );
				break;
			case 'allergie':
				list( $ok, $msg ) = FKC_SanteDossier::ajouterAllergie( $id, $_POST['substance'] ?? '', $_POST['severite'] ?? 'moderee', $_POST['note'] ?? '' );
				$this->setFlash( $ok, $msg );
				break;
			case 'consultation':
				list( $ok, $msg, $cid ) = FKC_SanteDossier::creerConsultation( array_merge( $_POST, array( 'patient_id' => $id ) ) );
				$this->setFlash( $ok, $msg );
				break;
			case 'prescription':
				$r = FKC_SanteDossier::prescrire( $_POST['consultation_id'] ?? 0, $_POST['medicament'] ?? '', $_POST['posologie'] ?? '', $_POST['duree'] ?? '', $id );
				$this->setFlash( $r['ok'] && ! $r['alerte'], $r['ok'] ? ( $r['alerte'] ? $r['alerte'] . ' Prescription enregistrée : à confirmer par le praticien.' : 'Prescription ajoutée.' ) : 'Échec de la prescription.' );
				break;
			default:
				$this->setFlash( false, 'Action inconnue.' );
		}
		redirect( $this->module() . '/dme/' . $id );
	}
}
