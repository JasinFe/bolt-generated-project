<?php
/**
 * Tiers payant santé — conventions, registre des prises en charge,
 * bordereaux et rejets (1.859.0).
 *
 * 1.858.0 a fait exister la part assurance au grand livre. Restait ce qui fait
 * le quotidien d'un service de facturation médicale :
 *
 *   CONVENTIONS — chaque assureur a SES règles : un taux par nature d'acte
 *     (consultation 80 %, pharmacie 70 %…), un plafond annuel par assuré, une
 *     franchise laissée au patient sur chaque acte, et un délai de production
 *     au-delà duquel il ne paie plus. Un taux unique au dossier ne sait rien
 *     de tout cela.
 *
 *   REGISTRE — chaque pièce prise en charge y inscrit sa part : c'est lui qui
 *     mesure le plafond consommé et qui alimente le bordereau.
 *
 *   BORDEREAU — ce que l'on envoie à l'assureur chaque mois : pièces, patients,
 *     montants, âge de chaque créance au regard du délai de production.
 *
 *   REJET — l'assureur refuse tout ou partie d'une prise en charge. Le
 *     montant rejeté quitte le compte de l'assureur : soit il REDEVIENT dû par
 *     le patient (D compte du patient / C 411116), soit il est abandonné
 *     (D 651100 Pertes sur créances / C 411116). Sans cela, le 411116
 *     gardait éternellement des créances que personne ne paiera.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteTiersPayant {

	const COMPTE_PERTE = '651100';

	protected static $pret = array();

	public static function ensure() {
		$cle = method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x';
		if ( isset( self::$pret[ $cle ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_conventions(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				assureur_id INTEGER NOT NULL,
				type_piece TEXT NOT NULL DEFAULT '',
				taux REAL NOT NULL DEFAULT 0,
				plafond_annuel REAL NOT NULL DEFAULT 0,
				franchise REAL NOT NULL DEFAULT 0,
				delai_jours INTEGER NOT NULL DEFAULT 0,
				actif INTEGER NOT NULL DEFAULT 1,
				UNIQUE(pack, assureur_id, type_piece)
			);
			CREATE TABLE IF NOT EXISTS sante_pec(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				piece_id INTEGER NOT NULL UNIQUE,
				patient_id INTEGER,
				assureur_id INTEGER NOT NULL,
				annee TEXT NOT NULL,
				montant REAL NOT NULL DEFAULT 0,
				rejete REAL NOT NULL DEFAULT 0,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_pec ON sante_pec(pack, assureur_id, annee);
			CREATE TABLE IF NOT EXISTS sante_rejets(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pec_id INTEGER NOT NULL,
				montant REAL NOT NULL,
				motif TEXT NOT NULL,
				imputation TEXT NOT NULL,
				ecriture_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
		" );
		self::$pret[ $cle ] = true;
	}

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	/* ── Conventions ─────────────────────────────────────────────────────── */

	/** Enregistre (ou remplace) la convention d'un assureur pour une nature de pièce ('' = toutes). */
	public static function enregistrerConvention( array $d ) {
		self::ensure();
		$aid = (int) ( $d['assureur_id'] ?? 0 );
		if ( $aid <= 0 && '' !== trim( (string) ( $d['assureur'] ?? '' ) ) && class_exists( 'FKC_SanteFacturation' ) ) {
			$aid = FKC_SanteFacturation::clientPayeur( (string) $d['assureur'] );
		}
		if ( $aid <= 0 ) { return array( false, 'Assureur requis.' ); }
		$type = preg_replace( '/[^a-z0-9_]/', '', strtolower( (string) ( $d['type_piece'] ?? '' ) ) );
		$taux = max( 0, min( 100, (float) ( $d['taux'] ?? 0 ) ) );
		FKC_DB::q(
			'INSERT INTO sante_conventions(pack, assureur_id, type_piece, taux, plafond_annuel, franchise, delai_jours, actif) VALUES(?,?,?,?,?,?,?,1)
			 ON CONFLICT(pack, assureur_id, type_piece) DO UPDATE SET taux=excluded.taux, plafond_annuel=excluded.plafond_annuel,
			   franchise=excluded.franchise, delai_jours=excluded.delai_jours, actif=1',
			array( self::pack(), $aid, $type, $taux,
				max( 0, (float) ( $d['plafond_annuel'] ?? 0 ) ), max( 0, (float) ( $d['franchise'] ?? 0 ) ),
				max( 0, (int) ( $d['delai_jours'] ?? 0 ) ) )
		);
		return array( true, 'Convention enregistrée.' );
	}

	public static function supprimerConvention( $id ) {
		self::ensure();
		FKC_DB::q( 'DELETE FROM sante_conventions WHERE id=? AND pack=?', array( (int) $id, self::pack() ) );
		return array( true, 'Convention supprimée.' );
	}

	/** Convention applicable : celle de la nature de pièce, sinon la convention générale de l'assureur. */
	public static function convention( $assureurId, $type ) {
		self::ensure();
		$r = FKC_DB::q(
			"SELECT * FROM sante_conventions WHERE pack=? AND assureur_id=? AND actif=1 AND type_piece IN (?, '')
			 ORDER BY type_piece='' ASC LIMIT 1",
			array( self::pack(), (int) $assureurId, (string) $type )
		)->fetch();
		return $r ?: null;
	}

	public static function conventions() {
		self::ensure();
		return FKC_DB::q(
			'SELECT c.*, cl.nom assureur FROM sante_conventions c LEFT JOIN clients cl ON cl.id=c.assureur_id
			 WHERE c.pack=? ORDER BY cl.nom, c.type_piece', array( self::pack() )
		)->fetchAll();
	}

	/** Plafond déjà consommé par un assuré auprès d'un assureur sur une année (hors pièce donnée). */
	public static function consomme( $patientId, $assureurId, $annee, $saufPiece = 0 ) {
		self::ensure();
		return (float) FKC_DB::q(
			"SELECT COALESCE(SUM(s.montant - (SELECT COALESCE(SUM(rj.montant),0) FROM sante_rejets rj WHERE rj.pec_id=s.id)),0) FROM sante_pec s JOIN vp_pieces p ON p.id=s.piece_id
			 WHERE s.pack=? AND s.patient_id=? AND s.assureur_id=? AND s.annee=? AND s.piece_id<>? AND p.statut<>'rejetee'",
			array( self::pack(), (int) $patientId, (int) $assureurId, (string) $annee, (int) $saufPiece )
		)->fetchColumn();
	}

	/**
	 * Applique la convention à une part assurance brute : taux de l'acte,
	 * franchise laissée au patient, plafond annuel restant.
	 * @return array{taux: float, part: float, regle: string}
	 */
	public static function appliquer( $assureurId, $patientId, $type, $ttc, $tauxDossier, $annee, $pieceId = 0 ) {
		$conv = self::convention( $assureurId, $type );
		$taux = $conv ? (float) $conv['taux'] : (float) $tauxDossier;
		if ( 'convention' === (string) $type ) { $taux = 100.0; }
		$part = $taux > 0 ? round( (float) $ttc * $taux / 100 ) : 0.0;
		$regle = $conv ? ( '' === (string) $conv['type_piece'] ? 'convention générale' : 'convention « ' . $conv['type_piece'] . ' »' ) : 'taux du dossier';
		if ( $conv && (float) $conv['franchise'] > 0 ) {
			$part = min( $part, max( 0.0, (float) $ttc - (float) $conv['franchise'] ) );
		}
		if ( $conv && (float) $conv['plafond_annuel'] > 0 && $patientId > 0 ) {
			$reste = max( 0.0, (float) $conv['plafond_annuel'] - self::consomme( $patientId, $assureurId, $annee, $pieceId ) );
			if ( $part > $reste ) { $part = $reste; $regle .= ' — plafond annuel atteint'; }
		}
		return array( 'taux' => $taux, 'part' => min( (float) $ttc, max( 0.0, $part ) ), 'regle' => $regle );
	}

	/** Inscrit (ou met à jour) la prise en charge d'une pièce au registre. */
	public static function inscrire( $pieceId, $patientId, $assureurId, $annee, $montant ) {
		if ( (int) $pieceId <= 0 ) { return; }
		self::ensure();
		if ( (float) $montant <= 0 ) {
			FKC_DB::q( 'DELETE FROM sante_pec WHERE piece_id=? AND id NOT IN (SELECT pec_id FROM sante_rejets)', array( (int) $pieceId ) );
			return;
		}
		FKC_DB::q(
			'INSERT INTO sante_pec(pack, piece_id, patient_id, assureur_id, annee, montant) VALUES(?,?,?,?,?,?)
			 ON CONFLICT(piece_id) DO UPDATE SET patient_id=excluded.patient_id, assureur_id=excluded.assureur_id, annee=excluded.annee, montant=excluded.montant',
			array( self::pack(), (int) $pieceId, (int) $patientId ?: null, (int) $assureurId, (string) $annee, (float) $montant )
		);
	}

	/* ── Bordereaux ──────────────────────────────────────────────────────── */

	/** Assureurs ayant des prises en charge (ou une convention), avec leur encours. */
	public static function assureurs() {
		self::ensure();
		$rows = FKC_DB::q(
			"SELECT cl.id, cl.nom,
			   (SELECT COALESCE(SUM(s.montant - (SELECT COALESCE(SUM(rj.montant),0) FROM sante_rejets rj WHERE rj.pec_id=s.id)),0) FROM sante_pec s JOIN vp_pieces p ON p.id=s.piece_id WHERE s.assureur_id=cl.id AND s.pack=? AND p.statut='comptabilisee') pris_en_charge,
			   (SELECT COUNT(*) FROM sante_conventions c WHERE c.assureur_id=cl.id AND c.pack=?) conventions
			 FROM clients cl WHERE cl.compte=? ORDER BY cl.nom",
			array( self::pack(), self::pack(), FKC_SanteFacturation::COMPTE_PAYEUR )
		)->fetchAll();
		foreach ( $rows as &$r ) { $r['solde'] = self::soldeAssureur( (int) $r['id'] ); }
		return $rows;
	}

	/** Solde du compte de l'assureur au grand livre (411116, son tiers). */
	public static function soldeAssureur( $assureurId ) {
		return round( (float) FKC_DB::q(
			"SELECT COALESCE(SUM(l.debit-l.credit),0) FROM ecriture_lignes l JOIN comptes c ON c.id=l.compte_id
			 WHERE c.numero=? AND l.tiers_type='client' AND l.tiers_id=?",
			array( FKC_SanteFacturation::COMPTE_PAYEUR, (int) $assureurId )
		)->fetchColumn(), 2 );
	}

	/**
	 * Bordereau d'un assureur pour un mois : pièces comptabilisées, patients,
	 * parts, rejets, âge et dépassement du délai de production.
	 */
	public static function bordereau( $assureurId, $ym ) {
		self::ensure();
		// Délai de production : le plus long déclaré dans les conventions de l'assureur.
		$delai = (int) FKC_DB::q( 'SELECT COALESCE(MAX(delai_jours),0) FROM sante_conventions WHERE pack=? AND assureur_id=? AND actif=1', array( self::pack(), (int) $assureurId ) )->fetchColumn();
		$rows = FKC_DB::q(
			"SELECT s.*, (SELECT COALESCE(SUM(rj.montant),0) FROM sante_rejets rj WHERE rj.pec_id=s.id) rejete_calc, p.type, p.numero, p.date_piece, p.libelle, p.montant_ht, p.tva_pct, d.code dossier, d.tiers_nom patient_nom
			 FROM sante_pec s JOIN vp_pieces p ON p.id=s.piece_id JOIN vp_dossiers d ON d.id=p.dossier_id
			 WHERE s.pack=? AND s.assureur_id=? AND substr(p.date_piece,1,7)=? AND p.statut='comptabilisee'
			 ORDER BY p.date_piece, p.id",
			array( self::pack(), (int) $assureurId, (string) $ym )
		)->fetchAll();
		$auj = new \DateTime( 'today' );
		foreach ( $rows as &$r ) {
			$r['ttc'] = round( (float) $r['montant_ht'] * ( 1 + (float) $r['tva_pct'] / 100 ), 2 );
			$r['age'] = ( new \DateTime( $r['date_piece'] ) )->diff( $auj )->days;
			$r['hors_delai'] = $delai > 0 && $r['age'] > $delai;
			$r['rejete'] = (float) $r['rejete_calc']; // recalculé : un rejet contre-passé disparaît du registre
			$r['du'] = round( (float) $r['montant'] - $r['rejete'], 2 );
		}
		return array( 'lignes' => $rows, 'delai' => $delai );
	}

	/* ── Rejets ──────────────────────────────────────────────────────────── */

	/**
	 * Rejet (total ou partiel) d'une prise en charge par l'assureur.
	 * $imputation : 'patient' (le montant redevient dû par le patient) ou
	 * 'perte' (abandonné, 651100).
	 * @return array{0: bool, 1: string}
	 */
	public static function rejeter( $pecId, $montant, $motif, $imputation = 'patient' ) {
		self::ensure();
		$s = FKC_DB::q( 'SELECT s.*, (SELECT COALESCE(SUM(rj.montant),0) FROM sante_rejets rj WHERE rj.pec_id=s.id) rejete_calc FROM sante_pec s WHERE s.id=? AND s.pack=?', array( (int) $pecId, self::pack() ) )->fetch();
		if ( ! $s ) { return array( false, 'Prise en charge introuvable.' ); }
		$motif = trim( (string) $motif );
		if ( '' === $motif ) { return array( false, 'Le motif du rejet est obligatoire (il se relit au contrôle).' ); }
		$montant = round( (float) $montant, 2 );
		$du = round( (float) $s['montant'] - (float) $s['rejete_calc'], 2 );
		if ( $montant <= 0 || $montant > $du + 0.001 ) { return array( false, 'Montant du rejet invalide (dû par l\'assureur : ' . fkc_money( $du ) . ' F).' ); }
		$imputation = 'perte' === $imputation ? 'perte' : 'patient';
		$piece = FKC_VpPiece::find( (int) $s['piece_id'] );
		if ( ! $piece || 'comptabilisee' !== $piece['statut'] ) { return array( false, 'La pièce n\'est pas comptabilisée : rien à rejeter au grand livre.' ); }
		if ( 'patient' === $imputation && empty( $s['patient_id'] ) ) { return array( false, 'Patient inconnu : rejet imputable seulement en perte.' ); }
		$cli = ! empty( $s['patient_id'] ) && class_exists( 'FKC_Client' ) ? FKC_Client::find( (int) $s['patient_id'] ) : null;
		$ass = class_exists( 'FKC_Client' ) ? FKC_Client::find( (int) $s['assureur_id'] ) : null;
		$evt = 'patient' === $imputation ? 'sante_rejet_pec_patient' : 'sante_rejet_pec_perte';
		$r = FKC_Posting::emettre( $evt, array(
			'montant' => $montant, 'date' => date( 'Y-m-d' ), 'motif' => $motif,
			'payeur' => $ass ? (string) $ass['nom'] : 'Assureur', 'tiers' => $cli ? (string) $cli['nom'] : '',
			'compte_client' => $cli && ! empty( $cli['compte'] ) ? (string) $cli['compte'] : FKC_SanteFacturation::comptePatient( self::pack() ),
			'tiers_type' => $cli ? 'client' : null, 'tiers_id' => $cli ? (int) $cli['id'] : null,
			'payeur_tiers_type' => 'client', 'payeur_tiers_id' => (int) $s['assureur_id'],
			'piece' => ( $piece['dossier_code'] ?? '' ) . '-REJ-' . (int) $s['id'],
			'reference' => 'sante.rejet#' . (int) $s['id'],
		) );
		if ( empty( $r[0] ) ) { return array( false, 'Écriture refusée : ' . (string) ( $r[1] ?? '' ) ); }
		FKC_DB::q( 'INSERT INTO sante_rejets(pec_id, montant, motif, imputation, ecriture_id) VALUES(?,?,?,?,?)',
			array( (int) $s['id'], $montant, $motif, $imputation, ! empty( $r[2] ) ? (int) $r[2] : null ) );
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_rejet_pec', 'Rejet PEC #' . (int) $s['id'] . ' — ' . $montant . ' F (' . $imputation . ') : ' . $motif ); }
		return array( true, 'Rejet enregistré : ' . fkc_money( $montant ) . ' F ' . ( 'patient' === $imputation ? 'remis à la charge du patient.' : 'passés en pertes sur créances (651100).' ) );
	}

	public static function rejets( $assureurId = 0 ) {
		self::ensure();
		$sql = 'SELECT r.*, s.piece_id, s.assureur_id FROM sante_rejets r JOIN sante_pec s ON s.id=r.pec_id WHERE s.pack=?';
		$a = array( self::pack() );
		if ( $assureurId ) { $sql .= ' AND s.assureur_id=?'; $a[] = (int) $assureurId; }
		return FKC_DB::q( $sql . ' ORDER BY r.id DESC LIMIT 50', $a )->fetchAll();
	}

	public static function schemas() {
		return array(
			'sante_rejet_pec_patient' => array(
				'journal' => 'OD',
				'libelle' => 'Rejet de prise en charge {payeur} — {tiers}',
				'lignes'  => array(
					array( 'compte' => '{compte_client}', 'compte_repli' => '411100', 'compte_libelle' => 'Patients',
					       'sens' => 'D', 'montant' => 'montant', 'libelle' => 'Reste à charge après rejet : {motif}', 'tiers' => true ),
					array( 'compte' => FKC_SanteFacturation::COMPTE_PAYEUR, 'compte_libelle' => 'Assurances et mutuelles — tiers payant',
					       'sens' => 'C', 'montant' => 'montant', 'libelle' => 'Rejet {payeur} : {motif}', 'tiers' => 'payeur' ),
				),
			),
			'sante_rejet_pec_perte' => array(
				'journal' => 'OD',
				'libelle' => 'Rejet de prise en charge {payeur} — abandon',
				'lignes'  => array(
					array( 'compte' => self::COMPTE_PERTE, 'compte_libelle' => 'Pertes sur créances clients',
					       'sens' => 'D', 'montant' => 'montant', 'libelle' => 'Rejet {payeur} : {motif}' ),
					array( 'compte' => FKC_SanteFacturation::COMPTE_PAYEUR, 'compte_libelle' => 'Assurances et mutuelles — tiers payant',
					       'sens' => 'C', 'montant' => 'montant', 'libelle' => 'Rejet {payeur} : {motif}', 'tiers' => 'payeur' ),
				),
			),
		);
	}
}

if ( class_exists( 'FKC_Posting' ) && class_exists( 'FKC_SanteFacturation' ) ) {
	// Origine « reglement » : un rejet ajuste une créance, comme un règlement la solde.
	FKC_Posting::register( FKC_SanteTiersPayant::schemas(), 'reglement' );
}
