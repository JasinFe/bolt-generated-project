<?php
/**
 * Facturation santé — le pont commun entre le soin et la comptabilité (1.858.0).
 *
 * Ce que les cinq packs de soins (cabinet médical, clinique, hôpital,
 * laboratoire, optique) faisaient mal, ensemble :
 *
 *   1. LA CRÉANCE SANS DÉBITEUR. Chaque facture débitait un 411 collectif
 *      (411115, 411118, 411116…) SANS tiers : le compte « patients » montait,
 *      personne n'était relançable, et l'écran Règlements — qui crédite le
 *      compte PROPRE du client (411100 par défaut) — ne pouvait jamais solder
 *      la facture. Le 411 de la clinique grossissait pendant que 411100
 *      devenait créditeur du même montant.
 *
 *   2. LE TIERS PAYANT DÉCLARÉ, JAMAIS APPLIQUÉ. Tous les manifestes
 *      demandent « Assurance / mutuelle », aucun schéma ne s'en servait :
 *      100 % de la facture restait à la charge du patient. Or c'est LA
 *      réalité du secteur — la part assurance (souvent 70 à 80 %) se
 *      recouvre auprès de l'assureur, avec ses délais, pas au guichet.
 *
 *   3. L'OPTIQUE DÉBITAIT LE PATIENT SUR 411116, le compte que le référentiel
 *      réserve aux ASSURANCES ET MUTUELLES : la balance âgée des assureurs
 *      mélangeait les montures payées cash.
 *
 * Réponse, par le contexte de la pièce (aucun moteur réécrit) :
 *
 *   - le patient du dossier devient un CLIENT du référentiel (créé une fois,
 *     sur le compte patients du pack) : la créance a un débiteur, le
 *     règlement la solde sur le même compte ;
 *   - l'assurance nommée au dossier devient un client « organisme payeur »
 *     (411116, dédoublonné par nom), et le taux de prise en charge du dossier
 *     scinde la facture : part patient / part assurance, chacune sur son
 *     compte et son tiers ;
 *   - une pièce « convention » (facturation directe à l'assureur) est prise
 *     en charge à 100 % quand un assureur est nommé.
 *
 * Et le dernier pont manquant : les RÉTROCESSIONS. Le bordereau calculait ce
 * que l'établissement doit à ses praticiens, sans jamais le constater : la
 * charge n'existait pas au compte de résultat, la dette pas au bilan. Elle se
 * comptabilise désormais (632460 / 401140, praticien = fournisseur réglable),
 * une fois par mois, avec un complément si le mois s'enrichit ensuite.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteFacturation {

	/** Packs de soins facturant des patients (la pharmacie encaisse au comptoir). */
	const PACKS = array( 'cabinet_medical', 'clinique', 'hopital', 'laboratoire', 'optique' );

	/** Compte « patients » propre à chaque pack (celui du référentiel métier). */
	const COMPTE_PATIENT = array(
		'cabinet_medical' => '411118',
		'clinique'        => '411115',
		'hopital'         => '411115',
		'laboratoire'     => '411118',
		'optique'         => '411100',
	);

	/** Assurances et mutuelles — tiers payant (référentiel santé). */
	const COMPTE_PAYEUR = '411116';

	/** Rétrocessions : charge et dette envers les praticiens. */
	const COMPTE_RETRO_CHARGE = '632460';
	const COMPTE_RETRO_DETTE  = '401140';

	protected static $pret = array();

	public static function estSante( $pack ) { return in_array( (string) $pack, self::PACKS, true ); }

	public static function comptePatient( $pack ) {
		return self::COMPTE_PATIENT[ (string) $pack ] ?? FKC_PlanMetier::COMPTE_CLIENT;
	}

	/** Taux de prise en charge déclaré au dossier (0–100). */
	public static function taux( array $dos ) {
		$ch = (array) ( $dos['champs_arr'] ?? array() );
		$t  = (float) str_replace( array( ' ', ',', '%' ), array( '', '.', '' ), (string) ( $ch['taux_pec'] ?? '0' ) );
		return max( 0.0, min( 100.0, $t ) );
	}

	/** Nom de l'organisme payeur déclaré au dossier (champ « assurance »). */
	public static function assureur( array $dos ) {
		$a = trim( (string) ( ( (array) ( $dos['champs_arr'] ?? array() ) )['assurance'] ?? '' ) );
		// « Aucune », « néant », « - » : le patient déclare explicitement ne pas en avoir.
		return preg_match( '/^(-+|—|aucune?|n[ée]ant|sans|non)$/iu', $a ) ? '' : $a;
	}

	/** Garantit l'existence d'un compte avant qu'un règlement ne le cherche. */
	protected static function assurerCompte( $numero ) {
		if ( class_exists( 'FKC_Posting' ) ) {
			try { FKC_Posting::compteId( $numero ); } catch ( \Throwable $e ) {}
		}
	}

	/**
	 * Client du dossier ; créé à la première facture s'il manque (le patient
	 * devient un débiteur identifiable), et rattaché au dossier.
	 * @return int id client, 0 si impossible
	 */
	public static function clientPatient( array $dos ) {
		if ( ! empty( $dos['client_id'] ) ) { return (int) $dos['client_id']; }
		if ( ! class_exists( 'FKC_Client' ) || empty( $dos['id'] ) ) { return 0; }
		$nom = trim( (string) ( $dos['tiers_nom'] ?? '' ) ) ?: trim( (string) ( $dos['libelle'] ?? '' ) );
		if ( '' === $nom ) { return 0; }
		$compte = self::comptePatient( (string) ( $dos['pack'] ?? '' ) );
		self::assurerCompte( $compte );
		try {
			$cid = (int) FKC_Client::create( array(
				'nom' => $nom, 'type' => 'B2C', 'compte' => $compte,
				'notes' => 'Patient — créé automatiquement depuis le dossier ' . ( $dos['code'] ?? '#' . (int) $dos['id'] ) . '.',
			) );
		} catch ( \Throwable $e ) { return 0; }
		if ( $cid > 0 ) {
			FKC_DB::q( 'UPDATE vp_dossiers SET client_id=? WHERE id=? AND client_id IS NULL', array( $cid, (int) $dos['id'] ) );
		}
		return $cid;
	}

	/**
	 * Organisme payeur : un client par assureur (dédoublonné par nom, sans
	 * tenir compte de la casse), porté par le compte « tiers payant ».
	 */
	public static function clientPayeur( $nom, $compte = self::COMPTE_PAYEUR ) {
		$nom = trim( (string) $nom );
		if ( '' === $nom || ! class_exists( 'FKC_Client' ) ) { return 0; }
		$id = (int) FKC_DB::q(
			'SELECT id FROM clients WHERE lower(trim(nom))=lower(?) AND compte=? ORDER BY id LIMIT 1',
			array( $nom, (string) $compte )
		)->fetchColumn();
		if ( $id > 0 ) { return $id; }
		self::assurerCompte( (string) $compte );
		try {
			return (int) FKC_Client::create( array(
				'nom' => $nom, 'type' => 'B2B', 'compte' => (string) $compte,
				'notes' => 'Organisme de tiers payant — créé automatiquement (santé).',
			) );
		} catch ( \Throwable $e ) { return 0; }
	}

	/**
	 * Répartition d'une facture entre patient et assurance.
	 * @return array{taux: float, part_assurance: float, part_patient: float, assureur: string}
	 */
	public static function repartition( array $dos, $type, $ttc ) {
		$ttc = (float) $ttc;
		$assureur = self::assureur( $dos );
		$taux = '' === $assureur ? 0.0 : self::taux( $dos );
		// La pièce « convention » facture l'assureur directement : 100 %.
		if ( '' !== $assureur && 'convention' === (string) $type ) { $taux = 100.0; }
		$assu = $taux > 0 ? round( $ttc * $taux / 100 ) : 0.0;
		$assu = min( $ttc, $assu );
		return array( 'taux' => $taux, 'part_assurance' => $assu, 'part_patient' => round( $ttc - $assu, 2 ), 'assureur' => $assureur );
	}

	/** Enrichissement du contexte de pièce (hook FKC_VpPiece::onContexte). */
	public static function enrichir( array &$ctx, array $piece, array $dos ) {
		if ( ! self::estSante( (string) ( $dos['pack'] ?? '' ) ) ) { return; }
		$cid = self::clientPatient( $dos );
		if ( $cid > 0 ) {
			$ctx['tiers_type'] = 'client';
			$ctx['tiers_id']   = $cid;
			$cli = class_exists( 'FKC_Client' ) ? FKC_Client::find( $cid ) : null;
			$ctx['compte_client'] = ( $cli && ! empty( $cli['compte'] ) ) ? (string) $cli['compte'] : self::comptePatient( (string) $dos['pack'] );
			if ( '' === (string) ( $ctx['tiers'] ?? '' ) && $cli ) { $ctx['tiers'] = (string) $cli['nom']; }
		} else {
			$ctx['compte_client'] = self::comptePatient( (string) $dos['pack'] );
		}
		$r = self::repartition( $dos, (string) ( $piece['type'] ?? '' ), (float) ( $ctx['ttc'] ?? 0 ) );
		/*
		 * 1.859.0 — CONVENTION DE L'ASSUREUR. Taux par nature d'acte, franchise
		 * et plafond annuel de l'assuré priment sur le taux du dossier ; la
		 * part retenue s'inscrit au registre des prises en charge (bordereau).
		 */
		$pid = '' !== $r['assureur'] ? self::clientPayeur( $r['assureur'] ) : 0;
		if ( $pid > 0 && class_exists( 'FKC_SanteTiersPayant' ) ) {
			$annee = substr( (string) ( $piece['date_piece'] ?? date( 'Y-m-d' ) ), 0, 4 );
			$ap = FKC_SanteTiersPayant::appliquer( $pid, $cid, (string) ( $piece['type'] ?? '' ), (float) ( $ctx['ttc'] ?? 0 ), self::taux( $dos ), $annee, (int) ( $piece['id'] ?? 0 ) );
			$r['taux'] = $ap['taux']; $r['part_assurance'] = $ap['part'];
			$r['part_patient'] = round( (float) ( $ctx['ttc'] ?? 0 ) - $ap['part'], 2 );
			$ctx['regle_pec'] = $ap['regle'];
			FKC_SanteTiersPayant::inscrire( (int) ( $piece['id'] ?? 0 ), $cid, $pid, $annee, $ap['part'] );
		}
		$ctx['taux_pec']       = $r['taux'];
		$ctx['part_assurance'] = $r['part_assurance'];
		$ctx['part_patient']   = $r['part_patient'];
		if ( $r['part_assurance'] > 0 ) {
			$ctx['payeur']        = $r['assureur'];
			$ctx['compte_payeur'] = self::COMPTE_PAYEUR;
			if ( $pid > 0 ) {
				$ctx['payeur_tiers_type'] = 'client';
				$ctx['payeur_tiers_id']   = $pid;
			}
		}
	}

	/* ── Émission commune (planning, hospitalisation, DME) ──────────────── */

	/**
	 * Dossier de facturation d'un patient : le dossier indiqué s'il existe
	 * dans le pack, sinon le dossier OUVERT portant ce nom, sinon un nouveau.
	 *
	 * Le planning et les sorties d'hospitalisation créaient un dossier NEUF à
	 * chaque consultation d'un patient sans dossier lié : dix visites, dix
	 * dossiers, dix fiches client — et un encours patient éclaté que personne
	 * ne pouvait plus lire.
	 * @return array{0: bool, 1: string, 2: int|null}
	 */
	public static function dossierPatient( $nom, $dossierId = 0, array $extra = array() ) {
		$cfg = FKC_Packs::verticalConfig();
		if ( (int) $dossierId > 0 ) {
			$d = FKC_VpDossier::find( (int) $dossierId );
			if ( $d && 'clos' !== ( $d['statut'] ?? '' ) ) { return array( true, '', (int) $d['id'] ); }
		}
		$nom = trim( (string) $nom );
		if ( '' === $nom ) { return array( false, 'Nom du patient manquant.', null ); }
		FKC_VpDossier::ensure();
		$id = (int) FKC_DB::q(
			"SELECT id FROM vp_dossiers WHERE pack=? AND statut<>'clos'
			   AND (lower(trim(COALESCE(tiers_nom,'')))=lower(?) OR (COALESCE(tiers_nom,'')='' AND lower(trim(libelle))=lower(?)))
			 ORDER BY id DESC LIMIT 1",
			array( FKC_VpDossier::pack(), $nom, $nom )
		)->fetchColumn();
		if ( $id > 0 ) { return array( true, '', $id ); }
		return FKC_VpDossier::create( array_merge( array( 'libelle' => $nom, 'tiers_nom' => $nom ), $extra ), $cfg );
	}

	/**
	 * Crée une pièce et la pousse jusqu'à la comptabilisation, en rendant
	 * compte de ce qui s'est RÉELLEMENT passé : un refus de validation (droits,
	 * condition) laissait la pièce en brouillon pendant que l'écran annonçait
	 * « facturée et comptabilisée ».
	 * @return array{0: bool, 1: string, 2: int|null, 3: string} ( ok, message, pieceId, statut )
	 */
	public static function emettrePiece( $dossierId, $type, $montant, $libelle, $date = null ) {
		$cfg = FKC_Packs::verticalConfig();
		list( $ok, $msg, $pid ) = FKC_VpPiece::create( (int) $dossierId, array(
			'type' => $type, 'montant_ht' => (float) $montant, 'libelle' => $libelle,
			'date_piece' => $date ?: date( 'Y-m-d' ),
		), $cfg );
		if ( ! $ok ) { return array( false, $msg, null, '' ); }
		$piece = FKC_VpPiece::find( $pid );
		$wid = (int) ( $piece['wf_instance_id'] ?? 0 );
		$note = '';
		if ( $wid > 0 && class_exists( 'FKC_WorkflowEngine' ) ) {
			foreach ( array( 'soumettre', 'valider' ) as $a ) {
				$r = FKC_WorkflowEngine::transition( $wid, $a );
				if ( empty( $r[0] ) ) { $note = (string) ( $r[1] ?? '' ); break; }
			}
		}
		$piece  = FKC_VpPiece::find( $pid );
		$statut = (string) ( $piece['statut'] ?? '' );
		if ( 'comptabilisee' === $statut ) { return array( true, 'Facture émise et comptabilisée.', (int) $pid, $statut ); }
		return array( true, 'Facture créée (statut : ' . $statut . ') — à valider dans Pièces' . ( '' !== $note ? ' : ' . $note : '.' ), (int) $pid, $statut );
	}

	/* ── Encours : ce que patients et assureurs doivent RÉELLEMENT ─────── */

	/** Solde débiteur d'un compte (bilan, à date). */
	protected static function soldeCompte( $numero ) {
		try {
			if ( class_exists( 'FKC_CockpitData' ) ) { return (float) FKC_CockpitData::solde( $numero, 'debit' ); }
			return (float) FKC_DB::q( 'SELECT COALESCE(SUM(el.debit-el.credit),0) FROM ecriture_lignes el JOIN comptes c ON c.id=el.compte_id WHERE c.numero=?', array( (string) $numero ) )->fetchColumn();
		} catch ( \Throwable $e ) { return 0.0; }
	}

	/**
	 * Créances ouvertes de la famille santé, lues au GRAND LIVRE (et non au
	 * nombre de pièces en attente de validation, que les indicateurs
	 * « Factures à recouvrer » comptaient jusqu'ici : une facture validée
	 * et impayée n'y figurait pas, une pièce en brouillon, si).
	 * @return array{patients: float, assurances: float}
	 */
	public static function encours( $pack ) {
		return array(
			'patients'   => max( 0.0, self::soldeCompte( self::comptePatient( $pack ) ) ),
			'assurances' => max( 0.0, self::soldeCompte( self::COMPTE_PAYEUR ) ),
		);
	}

	/**
	 * Indicateurs communs à un pack de soins : créances patients, créances
	 * assurances (tiers payant) — métriques, KPI, alerte et fait d'assistant.
	 */
	public static function indicateurs( $pfx, $pack ) {
		if ( ! class_exists( 'FKC_Metrics' ) || ! class_exists( 'FKC_Pilotage2' ) ) { return; }
		FKC_Metrics::register( $pfx . '_creances_patients', 'Créances patients', function () use ( $pack ) { return FKC_SanteFacturation::encours( $pack )['patients']; }, array( 'unite' => 'F', 'format' => 'money', 'sens' => 'baisse' ) );
		FKC_Metrics::register( $pfx . '_creances_assurances', 'Créances assurances (tiers payant)', function () use ( $pack ) { return FKC_SanteFacturation::encours( $pack )['assurances']; }, array( 'unite' => 'F', 'format' => 'money', 'sens' => 'baisse' ) );
		FKC_Pilotage2::registerKpi( $pfx . '_creances_patients', array(
			'libelle' => 'Créances patients', 'metric' => $pfx . '_creances_patients',
			'unite' => 'F', 'format' => 'money', 'sens' => 'baisse', 'categorie' => 'Trésorerie', 'icone' => '🧾',
		) );
		FKC_Pilotage2::registerKpi( $pfx . '_creances_assurances', array(
			'libelle' => 'Créances assurances (tiers payant)', 'metric' => $pfx . '_creances_assurances',
			'unite' => 'F', 'format' => 'money', 'sens' => 'baisse', 'categorie' => 'Trésorerie', 'icone' => '🏦',
		) );
		FKC_Pilotage2::registerAlerte( $pfx . '_creances_assurances', array(
			'libelle' => 'Tiers payant à recouvrer', 'metric' => $pfx . '_creances_assurances',
			'operateur' => '>', 'seuil' => 0, 'niveau' => 'info',
			'message' => function ( $v ) { return fkc_money( $v ) . ' F dus par les assurances et mutuelles — produire les bordereaux dans les délais de l\'assureur.'; },
			'action' => 'Voir les créances',
		) );
		// 1.859.0 — rendez-vous non honorés (90 jours) : une place perdue ne se revend pas.
		if ( class_exists( 'FKC_SantePlanning' ) ) {
			FKC_Metrics::register( $pfx . '_absences', 'RDV non honorés (90 j)', function () { return FKC_SantePlanning::tauxAbsence( 90 ); }, array( 'unite' => '%', 'format' => 'nombre', 'sens' => 'baisse' ) );
			FKC_Pilotage2::registerKpi( $pfx . '_absences', array(
				'libelle' => 'RDV non honorés (90 j)', 'metric' => $pfx . '_absences', 'cible' => 10,
				'unite' => '%', 'format' => 'nombre', 'sens' => 'baisse', 'categorie' => 'Planning', 'icone' => '🚫',
			) );
		}
		if ( class_exists( 'FKC_Assistant' ) ) {
			FKC_Assistant::fournisseur( function () use ( $pack ) {
				$e = FKC_SanteFacturation::encours( $pack );
				$faits = array();
				if ( $e['assurances'] > 0 ) {
					$faits[] = array( 'texte' => fkc_money( $e['assurances'] ) . ' F de tiers payant à recouvrer auprès des assurances et mutuelles (411116).', 'niveau' => 'info', 'categorie' => 'Trésorerie', 'url' => 'comptabilite/clients/creances' );
				}
				if ( $e['patients'] > 0 ) {
					$faits[] = array( 'texte' => fkc_money( $e['patients'] ) . ' F restent dus par les patients (reste à charge).', 'niveau' => 'info', 'categorie' => 'Trésorerie', 'url' => 'comptabilite/clients/creances' );
				}
				return $faits;
			} );
		}
	}

	/* ── Rétrocessions : constater la charge et la dette ─────────────────── */

	protected static function ensure() {
		$cle = method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x';
		if ( isset( self::$pret[ $cle ] ) ) { return; }
		if ( class_exists( 'FKC_SantePraticien' ) ) { FKC_SantePraticien::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_retro_ecritures(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				mois TEXT NOT NULL,
				praticien_id INTEGER NOT NULL,
				montant REAL NOT NULL DEFAULT 0,
				ecriture_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_retro ON sante_retro_ecritures(pack, mois, praticien_id);
		" );
		self::$pret[ $cle ] = true;
	}

	/** Montant déjà constaté pour un praticien et un mois. */
	public static function dejaConstate( $pack, $mois, $praticienId ) {
		self::ensure();
		return (float) FKC_DB::q(
			'SELECT COALESCE(SUM(montant),0) FROM sante_retro_ecritures WHERE pack=? AND mois=? AND praticien_id=?',
			array( (string) $pack, (string) $mois, (int) $praticienId )
		)->fetchColumn();
	}

	/** Fournisseur rattaché au praticien (créé au besoin) : la dette devient réglable. */
	public static function fournisseurPraticien( array $prat ) {
		if ( ! empty( $prat['fournisseur_id'] ) ) { return (int) $prat['fournisseur_id']; }
		if ( ! class_exists( 'FKC_Fournisseur' ) ) { return 0; }
		self::assurerCompte( self::COMPTE_RETRO_DETTE );
		try {
			$fid = (int) FKC_Fournisseur::create( array(
				'nom' => (string) $prat['nom'], 'compte' => self::COMPTE_RETRO_DETTE,
				'notes' => 'Praticien — rétrocessions d\'honoraires (santé).',
			) );
		} catch ( \Throwable $e ) { return 0; }
		if ( $fid > 0 ) { FKC_DB::q( 'UPDATE sante_praticiens SET fournisseur_id=? WHERE id=?', array( $fid, (int) $prat['id'] ) ); }
		return $fid;
	}

	/**
	 * Comptabilise les rétrocessions du mois : une écriture par praticien,
	 * pour la part non encore constatée. Idempotent.
	 * @return array{0: bool, 1: string, 2: int} ( ok, message, nb écritures )
	 */
	public static function comptabiliserRetrocessions( $ym = null ) {
		self::ensure();
		$ym = preg_match( '/^\d{4}-\d{2}$/', (string) $ym ) ? (string) $ym : date( 'Y-m' );
		if ( $ym > date( 'Y-m' ) ) { return array( false, 'Mois futur : rien à constater.', 0 ); }
		if ( ! class_exists( 'FKC_Posting' ) || ! FKC_Posting::has( 'sante_retrocession' ) ) {
			return array( false, 'Schéma comptable des rétrocessions indisponible.', 0 );
		}
		$pack = class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : '';
		$date = min( date( 'Y-m-d' ), date( 'Y-m-t', strtotime( $ym . '-01' ) ) );
		$n = 0; $total = 0.0; $erreurs = array();
		foreach ( FKC_SantePraticien::bordereauRetrocessions( $ym ) as $l ) {
			$du = (float) $l['retrocession'] - self::dejaConstate( $pack, $ym, (int) $l['id'] );
			if ( $du < 1 ) { continue; }
			$prat = FKC_SantePraticien::find( (int) $l['id'] );
			if ( ! $prat ) { continue; }
			$fid = self::fournisseurPraticien( $prat );
			$r = FKC_Posting::emettre( 'sante_retrocession', array(
				'montant' => $du, 'date' => $date, 'praticien' => (string) $prat['nom'], 'mois' => $ym,
				'taux' => (float) $l['taux'],
				'tiers_type' => $fid > 0 ? 'fournisseur' : null, 'tiers_id' => $fid > 0 ? $fid : null,
				'reference' => 'sante.retro#' . $pack . ':' . $ym . ':' . (int) $prat['id'],
			) );
			if ( empty( $r[0] ) ) { $erreurs[] = $prat['nom'] . ' : ' . (string) ( $r[1] ?? 'refus' ); continue; }
			FKC_DB::q(
				'INSERT INTO sante_retro_ecritures(pack, mois, praticien_id, montant, ecriture_id) VALUES(?,?,?,?,?)',
				array( $pack, $ym, (int) $prat['id'], $du, ! empty( $r[2] ) ? (int) $r[2] : null )
			);
			$n++; $total += $du;
		}
		if ( $erreurs ) { return array( false, 'Rétrocessions partiellement constatées — ' . implode( ' ; ', $erreurs ), $n ); }
		if ( 0 === $n ) { return array( true, 'Aucune rétrocession nouvelle à constater pour ' . $ym . '.', 0 ); }
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_retro_compta', $n . ' rétrocession(s) ' . $ym . ' — ' . $total . ' F' ); }
		return array( true, $n . ' rétrocession(s) constatée(s) pour ' . $ym . ' : ' . fkc_money( $total ) . ' F (632460 / 401140).', $n );
	}

	/** Schémas comptables communs à la famille santé. */
	public static function schemas() {
		return array(
			'sante_retrocession' => array(
				'journal' => 'OD',
				'libelle' => 'Rétrocession d\'honoraires {mois} — {praticien}',
				'lignes'  => array(
					array( 'compte' => self::COMPTE_RETRO_CHARGE, 'compte_libelle' => 'Honoraires — médecins vacataires',
					       'sens' => 'D', 'montant' => 'montant', 'libelle' => '{praticien} ({taux} %)' ),
					array( 'compte' => self::COMPTE_RETRO_DETTE, 'compte_libelle' => 'Praticiens — honoraires rétrocédés à payer',
					       'sens' => 'C', 'montant' => 'montant', 'libelle' => '{praticien}', 'tiers' => true ),
				),
			),
		);
	}
}

if ( class_exists( 'FKC_Posting' ) ) {
	// Origine « achat » : une rétrocession est un honoraire acheté au praticien —
	// même politique de comptabilisation que les autres dettes de services.
	FKC_Posting::register( FKC_SanteFacturation::schemas(), 'achat' );
}
if ( class_exists( 'FKC_VpPiece' ) && method_exists( 'FKC_VpPiece', 'onContexte' ) ) {
	FKC_VpPiece::onContexte( function ( array &$ctx, array $piece, array $dossier ) {
		FKC_SanteFacturation::enrichir( $ctx, $piece, $dossier );
	} );
}
