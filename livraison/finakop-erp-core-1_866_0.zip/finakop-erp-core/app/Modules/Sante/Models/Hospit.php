<?php
/**
 * Hospitalisation — module Santé (packs Clinique & Hôpital).
 *
 * Lits par service, admissions et sorties. À la sortie, le séjour est
 * facturé automatiquement (nuitées × tarif du lit) dans le circuit standard
 * des pièces. Le taux d'occupation des lits — l'indicateur roi de
 * l'hospitalisation — devient un chiffre RÉEL (lits occupés / lits ouverts).
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteHospit {

	/*
	 * 1.858.0 — mémorisé PAR BASE : un simple booléen déclarait les tables
	 * prêtes pour la première société ouverte dans le processus, et la
	 * suivante (bascule de société, harnais multi-dossiers) mourait sur
	 * « no such table ».
	 */
	protected static $ready = array();

	protected static function cleBase() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBase() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_lits(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				numero TEXT NOT NULL,
				service TEXT,
				tarif_nuit REAL NOT NULL DEFAULT 0,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_sejours(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				lit_id INTEGER NOT NULL,
				dossier_id INTEGER,
				patient TEXT NOT NULL,
				entree TEXT NOT NULL,
				sortie TEXT,
				tarif_nuit REAL NOT NULL DEFAULT 0,
				nuitees INTEGER,
				piece_id INTEGER,
				statut TEXT NOT NULL DEFAULT 'en_cours',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_sej ON sante_sejours(pack, statut, lit_id);
			CREATE TABLE IF NOT EXISTS sante_services(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				service TEXT NOT NULL,
				forfait_jour REAL NOT NULL DEFAULT 0,
				UNIQUE(pack, service)
			);
			CREATE TABLE IF NOT EXISTS sante_sejour_factures(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				sejour_id INTEGER NOT NULL,
				du TEXT NOT NULL, au TEXT NOT NULL,
				nuitees INTEGER NOT NULL, montant REAL NOT NULL,
				piece_id INTEGER, motif TEXT,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_sejfac ON sante_sejour_factures(sejour_id);
		" );
		// 1.859.0 — date jusqu'à laquelle les nuitées sont déjà facturées (facturation intermédiaire, transferts).
		$cols = array_column( FKC_DB::q( 'PRAGMA table_info(sante_sejours)' )->fetchAll(), 'name' );
		if ( ! in_array( 'facture_jusqu', $cols, true ) ) { FKC_DB::conn()->exec( 'ALTER TABLE sante_sejours ADD COLUMN facture_jusqu TEXT' ); }
		self::$ready[ self::cleBase() ] = true;
	}

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	/** Type de pièce pour la facture de séjour selon le pack. */
	public static function typeSejour() {
		$types = array_keys( (array) ( FKC_Packs::verticalConfig()['pieces'] ?? array() ) );
		if ( in_array( 'sejour', $types, true ) ) { return 'sejour'; }
		if ( in_array( 'soins', $types, true ) ) { return 'soins'; }
		return $types[0] ?? '';
	}

	/* ── Lits ────────────────────────────────────────────────────────────── */
	public static function creerLit( array $d ) {
		self::ensure();
		$numero = trim( (string) ( $d['numero'] ?? '' ) );
		if ( '' === $numero ) { return array( false, 'Le numéro du lit est requis.', null ); }
		$doublon = FKC_DB::q( 'SELECT id FROM sante_lits WHERE pack=? AND actif=1 AND lower(numero)=lower(?)', array( self::pack(), $numero ) )->fetchColumn();
		if ( $doublon ) { return array( false, 'Le lit ' . $numero . ' existe déjà.', null ); }
		FKC_DB::q(
			'INSERT INTO sante_lits(pack, numero, service, tarif_nuit) VALUES(?,?,?,?)',
			array( self::pack(), $numero, trim( (string) ( $d['service'] ?? '' ) ), max( 0, (float) ( $d['tarif_nuit'] ?? 0 ) ) )
		);
		return array( true, 'Lit enregistré.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function lits() {
		self::ensure();
		return FKC_DB::q(
			"SELECT l.*, s.id sejour_id, s.patient patient_actuel, s.entree
			 FROM sante_lits l
			 LEFT JOIN sante_sejours s ON s.lit_id=l.id AND s.statut='en_cours'
			 WHERE l.pack=? AND l.actif=1 ORDER BY l.service, l.numero",
			array( self::pack() )
		)->fetchAll();
	}

	/** Taux d'occupation réel : lits occupés / lits ouverts. */
	public static function occupation() {
		self::ensure();
		$r = FKC_DB::q(
			"SELECT COUNT(l.id) lits, COUNT(s.id) occupes
			 FROM sante_lits l LEFT JOIN sante_sejours s ON s.lit_id=l.id AND s.statut='en_cours'
			 WHERE l.pack=? AND l.actif=1",
			array( self::pack() )
		)->fetch();
		$lits = (int) ( $r['lits'] ?? 0 ); $occ = (int) ( $r['occupes'] ?? 0 );
		return array( 'lits' => $lits, 'occupes' => $occ, 'taux' => $lits > 0 ? round( $occ / $lits * 100, 1 ) : 0.0 );
	}

	/* ── Séjours ─────────────────────────────────────────────────────────── */
	/** Admet un patient dans un lit libre. @return array( ok, message, sejourId|null ) */
	public static function admettre( array $d ) {
		self::ensure();
		$lit = FKC_DB::q( 'SELECT * FROM sante_lits WHERE id=? AND pack=? AND actif=1', array( (int) ( $d['lit_id'] ?? 0 ), self::pack() ) )->fetch();
		if ( ! $lit ) { return array( false, 'Lit introuvable.', null ); }
		$dejaOccupe = FKC_DB::q( "SELECT id FROM sante_sejours WHERE lit_id=? AND statut='en_cours'", array( (int) $lit['id'] ) )->fetch();
		if ( $dejaOccupe ) { return array( false, 'Ce lit est déjà occupé.', null ); }
		$patient = trim( (string) ( $d['patient'] ?? '' ) );
		if ( '' === $patient ) { return array( false, 'Le nom du patient est requis.', null ); }
		$entree = (string) ( $d['entree'] ?? '' ) ?: date( 'Y-m-d' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $entree ) || ! strtotime( $entree ) ) { return array( false, 'Date d\'entrée invalide.', null ); }
		if ( $entree > date( 'Y-m-d' ) ) { return array( false, 'Une admission ne peut pas être datée dans le futur.', null ); }
		// 1.858.0 — un patient n'occupe qu'un lit à la fois.
		$ailleurs = FKC_DB::q(
			"SELECT l.numero FROM sante_sejours s JOIN sante_lits l ON l.id=s.lit_id WHERE s.pack=? AND s.statut='en_cours' AND lower(trim(s.patient))=lower(?) LIMIT 1",
			array( self::pack(), $patient )
		)->fetchColumn();
		if ( false !== $ailleurs && null !== $ailleurs ) { return array( false, $patient . ' est déjà hospitalisé (lit ' . $ailleurs . ').', null ); }
		$tarif = isset( $d['tarif_nuit'] ) && (float) $d['tarif_nuit'] > 0 ? (float) $d['tarif_nuit'] : (float) $lit['tarif_nuit'];
		FKC_DB::q(
			'INSERT INTO sante_sejours(pack, lit_id, dossier_id, patient, entree, tarif_nuit) VALUES(?,?,?,?,?,?)',
			array( self::pack(), (int) $lit['id'], ! empty( $d['dossier_id'] ) ? (int) $d['dossier_id'] : null, $patient, $entree, $tarif )
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_admission', 'Admission #' . $id . ' — ' . $patient . ' (lit ' . $lit['numero'] . ')' ); }
		return array( true, 'Patient admis (lit ' . $lit['numero'] . ').', $id );
	}

	public static function findSejour( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_sejours WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	public static function sejoursEnCours() {
		self::ensure();
		return FKC_DB::q(
			"SELECT s.*, l.numero lit, l.service FROM sante_sejours s JOIN sante_lits l ON l.id=s.lit_id
			 WHERE s.pack=? AND s.statut='en_cours' ORDER BY s.entree",
			array( self::pack() )
		)->fetchAll();
	}

	/** Dernières sorties (séjours clos) avec leur facture. */
	public static function sortiesRecentes( $limit = 10 ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT s.*, l.numero lit, l.service,
			   COALESCE((SELECT SUM(f.montant) FROM sante_sejour_factures f WHERE f.sejour_id=s.id), s.nuitees * s.tarif_nuit) facture
			 FROM sante_sejours s JOIN sante_lits l ON l.id=s.lit_id
			 WHERE s.pack=? AND s.statut='clos' ORDER BY s.sortie DESC, s.id DESC LIMIT " . max( 1, (int) $limit ),
			array( self::pack() )
		)->fetchAll();
	}

	/** Durée moyenne de séjour (DMS) des sorties des 90 derniers jours, en nuitées. */
	public static function dms() {
		self::ensure();
		return round( (float) FKC_DB::q(
			"SELECT COALESCE(AVG(nuitees),0) FROM sante_sejours WHERE pack=? AND statut='clos' AND sortie >= date('now','-90 day')",
			array( self::pack() )
		)->fetchColumn(), 1 );
	}

	/* ── Forfaits journaliers par service (1.859.0) ─────────────────────── */

	/** Forfait journalier d'un service (soins, repas, surveillance…), ajouté à chaque nuitée. */
	public static function forfaitService( $service ) {
		self::ensure();
		if ( '' === trim( (string) $service ) ) { return 0.0; }
		return (float) FKC_DB::q( 'SELECT forfait_jour FROM sante_services WHERE pack=? AND lower(service)=lower(?)', array( self::pack(), trim( (string) $service ) ) )->fetchColumn();
	}

	public static function enregistrerForfait( $service, $forfait ) {
		self::ensure();
		$service = trim( (string) $service );
		if ( '' === $service ) { return array( false, 'Service requis.' ); }
		FKC_DB::q( 'INSERT INTO sante_services(pack, service, forfait_jour) VALUES(?,?,?) ON CONFLICT(pack, service) DO UPDATE SET forfait_jour=excluded.forfait_jour',
			array( self::pack(), $service, max( 0, (float) $forfait ) ) );
		return array( true, 'Forfait journalier du service « ' . $service . ' » enregistré.' );
	}

	public static function services() {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_services WHERE pack=? ORDER BY service', array( self::pack() ) )->fetchAll();
	}

	/* ── Facturation du séjour par périodes ─────────────────────────────── */

	/**
	 * Facture les nuitées d'un séjour entre $du et $au (au tarif du lit + forfait
	 * du service), dans le dossier du patient. Chaque période facturée est
	 * tracée ; le séjour retient la date jusqu'à laquelle il est facturé.
	 * @return array{0: bool, 1: string, 2: int|null, 3: int} ( ok, message, pieceId, nuitées )
	 */
	protected static function facturerPeriode( array $s, $du, $au, $motif ) {
		$nuitees = (int) ( new \DateTime( $du ) )->diff( new \DateTime( $au ) )->days;
		if ( $nuitees <= 0 ) { return array( true, 'Aucune nuitée à facturer.', null, 0 ); }
		$lit = FKC_DB::q( 'SELECT numero, service FROM sante_lits WHERE id=?', array( (int) $s['lit_id'] ) )->fetch();
		$forfait = self::forfaitService( $lit['service'] ?? '' );
		$prix = (float) $s['tarif_nuit'] + $forfait;
		$montant = $nuitees * $prix;
		if ( $montant <= 0 ) { return array( false, 'Tarif de nuitée non défini pour ce séjour.', null, 0 ); }
		$type = self::typeSejour();
		if ( '' === $type ) { return array( false, 'Aucun type de pièce disponible.', null, 0 ); }
		list( $ok, $msg, $did ) = FKC_SanteFacturation::dossierPatient( $s['patient'], (int) ( $s['dossier_id'] ?? 0 ) );
		if ( ! $ok ) { return array( false, 'Dossier patient : ' . $msg, null, 0 ); }
		$libelle = $motif . ' du ' . $du . ' au ' . $au . ' (' . $nuitees . ' nuitée' . ( $nuitees > 1 ? 's' : '' ) . ')'
			. ( $lit ? ' — lit ' . $lit['numero'] . ( '' !== (string) $lit['service'] ? ', ' . $lit['service'] : '' ) : '' )
			. ( $forfait > 0 ? ' — dont forfait ' . fkc_money( $forfait ) . ' F/j' : '' );
		list( $ok, $msg, $pid ) = FKC_SanteFacturation::emettrePiece( (int) $did, $type, $montant, $libelle, $au );
		if ( ! $ok ) { return array( false, $msg, null, 0 ); }
		FKC_DB::q( 'INSERT INTO sante_sejour_factures(sejour_id, du, au, nuitees, montant, piece_id, motif) VALUES(?,?,?,?,?,?,?)',
			array( (int) $s['id'], $du, $au, $nuitees, $montant, (int) $pid, $motif ) );
		FKC_DB::q( 'UPDATE sante_sejours SET facture_jusqu=?, dossier_id=?, piece_id=? WHERE id=?', array( $au, (int) $did, (int) $pid, (int) $s['id'] ) );
		return array( true, $msg, (int) $pid, $nuitees );
	}

	protected static function dateValide( $d, array $s, $quoi ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $d ) || ! strtotime( $d ) ) { return $quoi . ' invalide.'; }
		if ( $d > date( 'Y-m-d' ) ) { return $quoi . ' ne peut pas être dans le futur.'; }
		if ( $d < ( $s['facture_jusqu'] ?: $s['entree'] ) ) { return $quoi . ' antérieure à la période déjà facturée ou à l\'entrée.'; }
		return '';
	}

	/**
	 * Facturation intermédiaire d'un long séjour (1.859.0) : les nuitées
	 * écoulées sont facturées sans clore le séjour — la trésorerie n'attend
	 * plus la sortie d'un patient hospitalisé trois semaines.
	 */
	public static function facturerIntermediaire( $sejourId, $date = null ) {
		self::ensure();
		$s = self::findSejour( $sejourId );
		if ( ! $s || 'en_cours' !== $s['statut'] ) { return array( false, 'Séjour en cours introuvable.', null ); }
		$date = $date ?: date( 'Y-m-d' );
		if ( '' !== ( $err = self::dateValide( $date, $s, 'Date' ) ) ) { return array( false, $err, null ); }
		list( $ok, $msg, $pid, $n ) = self::facturerPeriode( $s, $s['facture_jusqu'] ?: $s['entree'], $date, 'Séjour (facture intermédiaire)' );
		if ( ! $ok ) { return array( false, $msg, null ); }
		if ( 0 === $n ) { return array( false, 'Aucune nuitée écoulée depuis la dernière facture.', null ); }
		return array( true, $n . ' nuitée(s) facturée(s) — ' . $msg, $pid );
	}

	/**
	 * Transfert vers un autre lit (1.859.0) : les nuitées passées dans le lit
	 * d'origine sont facturées à SON tarif, puis le séjour continue dans le
	 * nouveau lit à son tarif. Changer de lit sans cela facturait tout le
	 * séjour au tarif du dernier lit — une réanimation au prix d'une chambre.
	 */
	public static function transferer( $sejourId, $litId, $date = null ) {
		self::ensure();
		$s = self::findSejour( $sejourId );
		if ( ! $s || 'en_cours' !== $s['statut'] ) { return array( false, 'Séjour en cours introuvable.' ); }
		$lit = FKC_DB::q( 'SELECT * FROM sante_lits WHERE id=? AND pack=? AND actif=1', array( (int) $litId, self::pack() ) )->fetch();
		if ( ! $lit ) { return array( false, 'Lit de destination introuvable.' ); }
		if ( (int) $lit['id'] === (int) $s['lit_id'] ) { return array( false, 'Le patient occupe déjà ce lit.' ); }
		if ( FKC_DB::q( "SELECT id FROM sante_sejours WHERE lit_id=? AND statut='en_cours'", array( (int) $lit['id'] ) )->fetch() ) { return array( false, 'Le lit de destination est occupé.' ); }
		$date = $date ?: date( 'Y-m-d' );
		if ( '' !== ( $err = self::dateValide( $date, $s, 'Date de transfert' ) ) ) { return array( false, $err ); }
		list( $ok, $msg, , $n ) = self::facturerPeriode( $s, $s['facture_jusqu'] ?: $s['entree'], $date, 'Séjour avant transfert' );
		if ( ! $ok ) { return array( false, $msg ); }
		FKC_DB::q( 'UPDATE sante_sejours SET lit_id=?, tarif_nuit=? WHERE id=?', array( (int) $lit['id'], (float) $lit['tarif_nuit'], (int) $s['id'] ) );
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_transfert', 'Séjour #' . (int) $s['id'] . ' → lit ' . $lit['numero'] ); }
		return array( true, 'Patient transféré au lit ' . $lit['numero'] . ( $n > 0 ? ' — ' . $n . ' nuitée(s) du lit précédent facturée(s).' : '.' ) );
	}

	/** Périodes déjà facturées d'un séjour. */
	public static function facturesSejour( $sejourId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_sejour_factures WHERE sejour_id=? ORDER BY id', array( (int) $sejourId ) )->fetchAll();
	}

	/**
	 * Sortie du patient : facture les nuitées restantes (au moins une nuitée
	 * pour un séjour jamais facturé), libère le lit. Idempotent.
	 * @return array{bool, string, mixed} ( ok, message, pieceId|null )
	 */
	public static function sortir( $sejourId, $dateSortie = null ) {
		self::ensure();
		$s = self::findSejour( $sejourId );
		if ( ! $s ) { return array( false, 'Séjour introuvable.', null ); }
		if ( 'en_cours' !== $s['statut'] ) { return array( false, 'Séjour déjà clôturé.', null ); }
		$sortie = $dateSortie ?: date( 'Y-m-d' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $sortie ) || ! strtotime( $sortie ) ) { return array( false, 'Date de sortie invalide.', null ); }
		if ( $sortie > date( 'Y-m-d' ) ) { return array( false, 'La sortie ne peut pas être datée dans le futur.', null ); }
		if ( $sortie < $s['entree'] ) { return array( false, 'La sortie ne peut précéder l\'entrée.', null ); }
		if ( ! empty( $s['facture_jusqu'] ) && $sortie < $s['facture_jusqu'] ) { return array( false, 'La sortie précède la période déjà facturée (' . $s['facture_jusqu'] . ').', null ); }
		$depuis = $s['facture_jusqu'] ?: $s['entree'];
		// Un séjour jamais facturé compte au moins une nuitée (entrée et sortie le même jour).
		$au = ( empty( $s['facture_jusqu'] ) && $sortie === $s['entree'] ) ? date( 'Y-m-d', strtotime( $sortie . ' +1 day' ) ) : $sortie;
		list( $ok, $msg, $pid, $n ) = self::facturerPeriode( $s, $depuis, $au, 'Séjour' );
		if ( ! $ok ) { return array( false, $msg, null ); }
		$total = (int) FKC_DB::q( 'SELECT COALESCE(SUM(nuitees),0) FROM sante_sejour_factures WHERE sejour_id=?', array( (int) $sejourId ) )->fetchColumn();
		$did = (int) FKC_DB::q( 'SELECT dossier_id FROM sante_sejours WHERE id=?', array( (int) $sejourId ) )->fetchColumn();
		FKC_DB::q(
			"UPDATE sante_sejours SET statut='clos', sortie=?, nuitees=?, piece_id=COALESCE(?, piece_id), dossier_id=? WHERE id=?",
			array( $sortie, $total, $pid ? (int) $pid : null, $did ?: null, (int) $sejourId )
		);
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_sortie', 'Sortie séjour #' . $sejourId . ' — ' . $total . ' nuitées au total' ); }
		return array( true, 'Sortie enregistrée : ' . $total . ' nuitée(s) au total' . ( $n > 0 ? ' — ' . $msg : ' (déjà facturées).' ), $pid ? (int) $pid : null );
	}
}
