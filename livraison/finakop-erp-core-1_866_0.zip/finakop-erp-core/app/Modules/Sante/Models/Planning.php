<?php
/**
 * Planning des consultations — module Santé (packs Clinique & Hôpital).
 *
 * Rendez-vous par praticien et par jour. Un rendez-vous honoré peut être
 * facturé en un clic : la facture part dans le circuit standard des pièces
 * (workflow de validation → écriture comptable SYSCOHADA), rattachée au
 * dossier patient. Le montant facturé alimente le bordereau de rétrocession
 * du praticien.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SantePlanning {

	/*
	 * 1.858.0 — mémorisé PAR BASE : un simple booléen déclarait les tables
	 * prêtes pour la première société ouverte dans le processus, et la
	 * suivante (bascule de société, harnais multi-dossiers) mourait sur
	 * « no such table ».
	 */
	protected static $ready = array();

	protected static function cleBase() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBase() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_rdv(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				praticien_id INTEGER NOT NULL,
				dossier_id INTEGER,
				patient TEXT NOT NULL,
				date TEXT NOT NULL,
				heure TEXT NOT NULL DEFAULT '08:00',
				motif TEXT,
				montant REAL NOT NULL DEFAULT 0,
				statut TEXT NOT NULL DEFAULT 'prevu',
				piece_id INTEGER,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_rdv_jour ON sante_rdv(pack, date, praticien_id);
		" );
		/*
		 * LA TABLE DES PRATICIENS AUSSI (1.690.0).
		 *
		 * `jour()` joint `sante_praticiens`, dont la création appartient à
		 * FKC_SantePraticien. Sans cet appel, l'écran Planning mourait sur
		 * « no such table » dans TOUT dossier où personne n'avait ouvert
		 * l'écran des praticiens avant — c'est-à-dire tout dossier neuf.
		 *
		 * L'écran était donc mort sur les DEUX packs qui le portent, cabinet
		 * médical et optique, et il l'était depuis toujours. Aucun harnais ne
		 * le voyait : la couverture de routes ne s'exécutait que sur
		 * « generique » et « bazar », qui n'ont pas le module Santé.
		 *
		 * FKC_SanteDossier::ensure() faisait déjà exactement cet appel : la
		 * convention existait, ce modèle-ci l'avait oubliée.
		 */
		if ( class_exists( 'FKC_SantePraticien' ) ) { FKC_SantePraticien::ensure(); }
		// 1.859.0 — durée du rendez-vous, téléphone du patient (rappel), rappel envoyé.
		$cols = array_column( FKC_DB::q( 'PRAGMA table_info(sante_rdv)' )->fetchAll(), 'name' );
		foreach ( array( 'duree' => 'INTEGER NOT NULL DEFAULT 20', 'telephone' => "TEXT DEFAULT ''", 'rappel_at' => 'TEXT' ) as $c => $t ) {
			if ( ! in_array( $c, $cols, true ) ) { FKC_DB::conn()->exec( "ALTER TABLE sante_rdv ADD COLUMN {$c} {$t}" ); }
		}
		self::$ready[ self::cleBase() ] = true;
	}

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	/**
	 * Type de pièce qui facture un rendez-vous, selon le pack.
	 *
	 * 1.858.0 — la recherche s'arrêtait à « soins » puis « actes » : le cabinet
	 * médical facturait ses CONSULTATIONS en « Actes & soins » (706167 au lieu
	 * de 706166) et l'opticien facturait l'EXAMEN DE VUE comme une vente de
	 * montures (701120) — un produit de marchandise sur une prestation.
	 */
	public static function typeConsultation() {
		$types = array_keys( (array) ( FKC_Packs::verticalConfig()['pieces'] ?? array() ) );
		foreach ( array( 'consultation', 'soins', 'actes', 'bilan', 'examen' ) as $t ) {
			if ( in_array( $t, $types, true ) ) { return $t; }
		}
		return $types[0] ?? '';
	}

	/** @return array{bool, string, int|null} ( ok, message, id|null ) */
	public static function create( array $d ) {
		self::ensure();
		$prat = class_exists( 'FKC_SantePraticien' ) ? FKC_SantePraticien::find( (int) ( $d['praticien_id'] ?? 0 ) ) : null;
		if ( ! $prat ) { return array( false, 'Praticien introuvable.', null ); }
		if ( empty( $prat['actif'] ) ) { return array( false, 'Ce praticien est inactif.', null ); }
		$patient = trim( (string) ( $d['patient'] ?? '' ) );
		if ( '' === $patient ) { return array( false, 'Le nom du patient est requis.', null ); }
		$date = (string) ( $d['date'] ?? date( 'Y-m-d' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! strtotime( $date ) ) { return array( false, 'Date invalide.', null ); }
		$heure = (string) ( $d['heure'] ?? '08:00' );
		if ( ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $heure ) ) { return array( false, 'Heure invalide (HH:MM).', null ); }
		/*
		 * UN CRÉNEAU, UN PATIENT (1.858.0) — ET UNE DURÉE (1.859.0). Le contrôle
		 * portait sur l'heure exacte : un RDV à 09:10 passait sur une
		 * consultation de 09:00 à 09:20. Chaque rendez-vous occupe désormais
		 * sa durée (celle du praticien par défaut) ; tout chevauchement est refusé.
		 */
		$duree = (int) ( $d['duree'] ?? 0 );
		if ( $duree <= 0 ) { $duree = (int) ( $prat['duree_creneau'] ?? 20 ) ?: 20; }
		$duree = max( 5, min( 240, $duree ) );
		$debut = self::minutes( $heure ); $fin = $debut + $duree;
		foreach ( FKC_DB::q(
			"SELECT patient, heure, duree FROM sante_rdv WHERE pack=? AND praticien_id=? AND date=? AND statut NOT IN ('annule','absent')",
			array( self::pack(), (int) $prat['id'], $date )
		)->fetchAll() as $o ) {
			$od = self::minutes( $o['heure'] ); $of = $od + max( 5, (int) $o['duree'] );
			if ( $debut < $of && $od < $fin ) {
				return array( false, 'Créneau déjà occupé : ' . $prat['nom'] . ' reçoit ' . $o['patient'] . ' le ' . $date . ' de ' . $o['heure'] . ' à ' . self::hhmm( $of ) . '.', null );
			}
		}
		$montant = (float) ( $d['montant'] ?? 0 );
		if ( $montant <= 0 ) { $montant = (float) $prat['tarif_consultation']; }
		$did = ! empty( $d['dossier_id'] ) && class_exists( 'FKC_VpDossier' ) && FKC_VpDossier::find( (int) $d['dossier_id'] ) ? (int) $d['dossier_id'] : null;
		FKC_DB::q(
			'INSERT INTO sante_rdv(pack, praticien_id, dossier_id, patient, date, heure, motif, montant, duree, telephone) VALUES(?,?,?,?,?,?,?,?,?,?)',
			array(
				self::pack(), (int) $prat['id'], $did,
				$patient, $date, $heure,
				trim( (string) ( $d['motif'] ?? '' ) ), max( 0, $montant ), $duree,
				preg_replace( '/[^0-9+ ]/', '', (string) ( $d['telephone'] ?? '' ) ),
			)
		);
		return array( true, 'Rendez-vous planifié : ' . $patient . ', ' . $date . ' à ' . $heure . '.', (int) FKC_DB::conn()->lastInsertId() );
	}

	protected static function minutes( $hhmm ) { $p = explode( ':', (string) $hhmm ); return (int) $p[0] * 60 + (int) ( $p[1] ?? 0 ); }
	protected static function hhmm( $m ) { return sprintf( '%02d:%02d', intdiv( (int) $m, 60 ) % 24, (int) $m % 60 ); }

	public static function find( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_rdv WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	/** Planning d'un jour, groupé par praticien (ou l'agenda d'un seul praticien). */
	public static function jour( $date = null, $praticienId = 0 ) {
		self::ensure();
		$d = $date ?: date( 'Y-m-d' );
		$sql = "SELECT r.*, p.nom praticien, p.specialite
			 FROM sante_rdv r JOIN sante_praticiens p ON p.id=r.praticien_id
			 WHERE r.pack=? AND r.date=?";
		$a = array( self::pack(), $d );
		if ( (int) $praticienId > 0 ) { $sql .= ' AND r.praticien_id=?'; $a[] = (int) $praticienId; }
		return FKC_DB::q( $sql . ' ORDER BY p.nom, r.heure', $a )->fetchAll();
	}

	/**
	 * Patient non venu (1.859.0). Le rendez-vous passé reste sinon « prévu »
	 * à jamais : ni facturé, ni compté comme place perdue — et le taux
	 * d'absence que lit l'analyse métier (Maestro) restait faux.
	 */
	public static function absent( $id ) {
		self::ensure();
		$r = self::find( $id );
		if ( ! $r ) { return array( false, 'Rendez-vous introuvable.' ); }
		if ( 'prevu' !== $r['statut'] ) { return array( false, 'Seul un rendez-vous prévu peut être déclaré non honoré.' ); }
		if ( $r['date'] > date( 'Y-m-d' ) ) { return array( false, 'Rendez-vous à venir : le patient peut encore venir.' ); }
		FKC_DB::q( "UPDATE sante_rdv SET statut='absent' WHERE id=?", array( (int) $id ) );
		return array( true, 'Rendez-vous marqué non honoré.' );
	}

	/** Taux de rendez-vous non honorés sur N jours (passés, hors annulations). */
	public static function tauxAbsence( $jours = 90 ) {
		self::ensure();
		$r = FKC_DB::q(
			"SELECT SUM(statut='absent') a, SUM(statut IN ('absent','honore')) t FROM sante_rdv
			 WHERE pack=? AND date <= date('now','localtime') AND date >= date('now','localtime', ?)",
			array( self::pack(), '-' . max( 1, (int) $jours ) . ' day' )
		)->fetch();
		return (int) ( $r['t'] ?? 0 ) > 0 ? round( (int) $r['a'] / (int) $r['t'] * 100, 1 ) : 0.0;
	}

	/** Rappels à faire : rendez-vous prévus d'un jour (par défaut demain), avec téléphone. */
	public static function rappels( $date = null ) {
		self::ensure();
		$d = $date ?: date( 'Y-m-d', strtotime( '+1 day' ) );
		return FKC_DB::q(
			"SELECT r.*, p.nom praticien FROM sante_rdv r JOIN sante_praticiens p ON p.id=r.praticien_id
			 WHERE r.pack=? AND r.date=? AND r.statut='prevu' ORDER BY r.heure",
			array( self::pack(), $d )
		)->fetchAll();
	}

	/** Message de rappel (SMS / WhatsApp) d'un rendez-vous. */
	public static function messageRappel( array $r, $etablissement = '' ) {
		return 'Bonjour ' . $r['patient'] . ', rappel de votre rendez-vous avec ' . $r['praticien'] . ' le '
			. date( 'd/m/Y', strtotime( $r['date'] ) ) . ' à ' . $r['heure'] . ( '' !== $etablissement ? ' (' . $etablissement . ')' : '' )
			. '. Merci de prévenir en cas d\'empêchement.';
	}

	public static function marquerRappel( $id ) {
		self::ensure();
		FKC_DB::q( "UPDATE sante_rdv SET rappel_at=datetime('now','localtime') WHERE id=? AND pack=?", array( (int) $id, self::pack() ) );
		return array( true, 'Rappel noté comme envoyé.' );
	}

	public static function annuler( $id ) {
		self::ensure();
		$r = self::find( $id );
		if ( ! $r ) { return array( false, 'Rendez-vous introuvable.' ); }
		if ( 'honore' === $r['statut'] ) { return array( false, 'Ce rendez-vous est déjà facturé.' ); }
		FKC_DB::q( "UPDATE sante_rdv SET statut='annule' WHERE id=?", array( (int) $id ) );
		return array( true, 'Rendez-vous annulé.' );
	}

	/**
	 * Facture une consultation : retrouve (ou crée) le dossier du patient,
	 * émet la pièce À LA DATE DU RENDEZ-VOUS dans le circuit standard
	 * (soumise + validée → comptabilisée) et marque le rendez-vous honoré.
	 * Idempotent (un RDV ne se facture qu'une fois).
	 * @return array{bool, string, mixed} ( ok, message, pieceId|null )
	 */
	public static function facturer( $id ) {
		self::ensure();
		$r = self::find( $id );
		if ( ! $r ) { return array( false, 'Rendez-vous introuvable.', null ); }
		if ( 'honore' === $r['statut'] ) { return array( false, 'Consultation déjà facturée.', null ); }
		if ( 'annule' === $r['statut'] ) { return array( false, 'Rendez-vous annulé : replanifier avant de facturer.', null ); }
		if ( (float) $r['montant'] <= 0 ) { return array( false, 'Montant de la consultation non défini.', null ); }
		// Un rendez-vous À VENIR n'est pas un service rendu : pas de produit constaté d'avance.
		if ( $r['date'] > date( 'Y-m-d' ) ) { return array( false, 'Rendez-vous à venir : il se facture une fois la consultation réalisée.', null ); }
		$type = self::typeConsultation();
		if ( '' === $type ) { return array( false, 'Aucun type de pièce disponible.', null ); }
		list( $ok, $msg, $did ) = FKC_SanteFacturation::dossierPatient( $r['patient'], (int) ( $r['dossier_id'] ?? 0 ) );
		if ( ! $ok ) { return array( false, 'Dossier patient : ' . $msg, null ); }
		$prat = FKC_SantePraticien::find( (int) $r['praticien_id'] );
		$libelle = 'Consultation ' . ( $prat ? $prat['nom'] : '' ) . ' du ' . $r['date'] . ( '' !== (string) $r['motif'] ? ' — ' . $r['motif'] : '' );
		list( $ok, $msg, $pid ) = FKC_SanteFacturation::emettrePiece( (int) $did, $type, (float) $r['montant'], $libelle, (string) $r['date'] );
		if ( ! $ok ) { return array( false, $msg, null ); }
		FKC_DB::q( "UPDATE sante_rdv SET statut='honore', piece_id=?, dossier_id=? WHERE id=?", array( (int) $pid, (int) $did, (int) $id ) );
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_rdv_facturer', 'RDV #' . $id . ' facturé (pièce #' . $pid . ')' ); }
		return array( true, 'Consultation facturée — ' . $msg, (int) $pid );
	}

	/** Rendez-vous d'une période (vue semaine). */
	public static function periode( $du, $au ) {
		self::ensure();
		return FKC_DB::q(
			"SELECT r.*, p.nom praticien FROM sante_rdv r JOIN sante_praticiens p ON p.id=r.praticien_id
			 WHERE r.pack=? AND r.date BETWEEN ? AND ? ORDER BY r.date, r.heure",
			array( self::pack(), (string) $du, (string) $au )
		)->fetchAll();
	}

	/** Compteurs du jour (pour KPI/assistant). */
	public static function compteursJour( $date = null ) {
		self::ensure();
		$d = $date ?: date( 'Y-m-d' );
		$rows = FKC_DB::q( 'SELECT statut, COUNT(*) n FROM sante_rdv WHERE pack=? AND date=? GROUP BY statut', array( self::pack(), $d ) )->fetchAll();
		$c = array( 'prevu' => 0, 'honore' => 0, 'annule' => 0, 'absent' => 0, 'total' => 0, 'actifs' => 0 );
		foreach ( $rows as $r ) { $c[ $r['statut'] ] = (int) $r['n']; $c['total'] += (int) $r['n']; }
		// « Consultations du jour » : un rendez-vous annulé n'en est pas une.
		$c['actifs'] = $c['prevu'] + $c['honore'];
		$c['facture'] = (float) FKC_DB::q( "SELECT COALESCE(SUM(montant),0) FROM sante_rdv WHERE pack=? AND date=? AND statut='honore'", array( self::pack(), $d ) )->fetchColumn();
		return $c;
	}
}
