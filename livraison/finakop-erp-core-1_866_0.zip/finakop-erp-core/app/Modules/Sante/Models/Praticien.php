<?php
/**
 * Praticiens — module Santé (packs Clinique & Hôpital).
 *
 * Registre des médecins et praticiens de l'établissement, avec le paramètre
 * financier clé du secteur : le taux de rétrocession (la part des honoraires
 * de consultation reversée au praticien). Le bordereau mensuel de
 * rétrocession se calcule depuis les consultations honorées du planning.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SantePraticien {

	/*
	 * 1.858.0 — mémorisé PAR BASE : un simple booléen déclarait les tables
	 * prêtes pour la première société ouverte dans le processus, et la
	 * suivante (bascule de société, harnais multi-dossiers) mourait sur
	 * « no such table ».
	 */
	protected static $ready = array();

	protected static function cleBase() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBase() ] ) ) { return; }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_praticiens(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				nom TEXT NOT NULL,
				specialite TEXT,
				tarif_consultation REAL NOT NULL DEFAULT 0,
				taux_retrocession REAL NOT NULL DEFAULT 50,
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_prat_pack ON sante_praticiens(pack, actif);
		" );
		// 1.858.0 — le praticien devient un fournisseur réglable (rétrocessions comptabilisées).
		$cols = array_column( FKC_DB::q( 'PRAGMA table_info(sante_praticiens)' )->fetchAll(), 'name' );
		if ( ! in_array( 'fournisseur_id', $cols, true ) ) {
			FKC_DB::conn()->exec( 'ALTER TABLE sante_praticiens ADD COLUMN fournisseur_id INTEGER' );
		}
		// 1.859.0 — durée d'un créneau de consultation (minutes), propre au praticien.
		if ( ! in_array( 'duree_creneau', $cols, true ) ) {
			FKC_DB::conn()->exec( 'ALTER TABLE sante_praticiens ADD COLUMN duree_creneau INTEGER NOT NULL DEFAULT 20' );
		}
		self::$ready[ self::cleBase() ] = true;
	}

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : ''; }

	/** @return array{bool, string, int|null} ( ok, message, id|null ) */
	public static function create( array $d ) {
		self::ensure();
		$nom = trim( (string) ( $d['nom'] ?? '' ) );
		if ( '' === $nom ) { return array( false, 'Le nom du praticien est requis.', null ); }
		$taux = max( 0, min( 100, (float) ( $d['taux_retrocession'] ?? 50 ) ) );
		FKC_DB::q(
			'INSERT INTO sante_praticiens(pack, nom, specialite, tarif_consultation, taux_retrocession, duree_creneau) VALUES(?,?,?,?,?,?)',
			array( self::pack(), $nom, trim( (string) ( $d['specialite'] ?? '' ) ), max( 0, (float) ( $d['tarif_consultation'] ?? 0 ) ), $taux, max( 5, min( 240, (int) ( $d['duree_creneau'] ?? 20 ) ?: 20 ) ) )
		);
		$id = (int) FKC_DB::conn()->lastInsertId();
		if ( class_exists( 'FKC_Security' ) ) { FKC_Security::audit( 'sante_praticien_create', 'Praticien #' . $id . ' ' . $nom ); }
		return array( true, 'Praticien enregistré.', $id );
	}

	public static function update( $id, array $d ) {
		self::ensure();
		$p = self::find( $id );
		if ( ! $p ) { return array( false, 'Praticien introuvable.' ); }
		FKC_DB::q(
			'UPDATE sante_praticiens SET nom=?, specialite=?, tarif_consultation=?, taux_retrocession=?, actif=?, duree_creneau=? WHERE id=? AND pack=?',
			array(
				trim( (string) ( $d['nom'] ?? $p['nom'] ) ), trim( (string) ( $d['specialite'] ?? $p['specialite'] ) ),
				max( 0, (float) ( $d['tarif_consultation'] ?? $p['tarif_consultation'] ) ),
				max( 0, min( 100, (float) ( $d['taux_retrocession'] ?? $p['taux_retrocession'] ) ) ),
				isset( $d['actif'] ) ? (int) (bool) $d['actif'] : (int) $p['actif'],
				max( 5, min( 240, (int) ( $d['duree_creneau'] ?? $p['duree_creneau'] ?? 20 ) ?: 20 ) ),
				(int) $id, self::pack(),
			)
		);
		return array( true, 'Praticien mis à jour.' );
	}

	public static function find( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_praticiens WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	public static function tous( $actifsSeuls = true ) {
		self::ensure();
		$sql = 'SELECT * FROM sante_praticiens WHERE pack=?' . ( $actifsSeuls ? ' AND actif=1' : '' ) . ' ORDER BY nom';
		return FKC_DB::q( $sql, array( self::pack() ) )->fetchAll();
	}

	/**
	 * Bordereau de rétrocession du mois : par praticien, honoraires des
	 * consultations honorées × taux de rétrocession = part à reverser.
	 * @return array de array( praticien, specialite, taux, nb, honoraires, retrocession, net_etablissement )
	 */
	public static function bordereauRetrocessions( $ym = null ) {
		self::ensure();
		if ( class_exists( 'FKC_SantePlanning' ) ) { FKC_SantePlanning::ensure(); }
		$m = $ym ?: date( 'Y-m' );
		$rows = FKC_DB::q(
			"SELECT p.id, p.nom, p.specialite, p.taux_retrocession taux,
				COUNT(r.id) nb, COALESCE(SUM(r.montant),0) honoraires
			 FROM sante_praticiens p
			 LEFT JOIN sante_rdv r ON r.praticien_id=p.id AND r.statut='honore' AND substr(r.date,1,7)=?
			 WHERE p.pack=? GROUP BY p.id HAVING nb > 0 OR p.actif=1 ORDER BY honoraires DESC",
			array( $m, self::pack() )
		)->fetchAll();
		$out = array();
		foreach ( $rows as $r ) {
			$retro = round( (float) $r['honoraires'] * (float) $r['taux'] / 100 );
			$out[] = array(
				'id' => (int) $r['id'], 'praticien' => $r['nom'], 'specialite' => (string) $r['specialite'],
				'taux' => (float) $r['taux'], 'nb' => (int) $r['nb'],
				'honoraires' => (float) $r['honoraires'], 'retrocession' => $retro,
				'net_etablissement' => (float) $r['honoraires'] - $retro,
				// 1.858.0 — part déjà passée en comptabilité (632460 / 401140).
				'constate' => class_exists( 'FKC_SanteFacturation' ) ? FKC_SanteFacturation::dejaConstate( self::pack(), $m, (int) $r['id'] ) : 0.0,
			);
		}
		return $out;
	}

	/** Total des rétrocessions dues sur le mois (pour KPI/alertes). */
	public static function totalRetrocessions( $ym = null ) {
		$t = 0.0;
		foreach ( self::bordereauRetrocessions( $ym ) as $l ) { $t += $l['retrocession']; }
		return $t;
	}
}
