<?php
/**
 * Santé Premium — DOSSIER MÉDICAL ÉLECTRONIQUE (DME).
 *
 * Le socle clinique (praticiens, RDV, lits) gère l'agenda et le séjour ; le
 * DME gère le SOIN lui-même :
 *
 *   PATIENT       — identité, données vitales de base, groupe sanguin.
 *   ANTÉCÉDENTS   — l'histoire médicale : chroniques, chirurgicaux, familiaux.
 *   ALLERGIES     — critiques : elles doivent SAUTER AUX YEUX avant toute
 *                   prescription (une allergie pénicilline non vue tue).
 *   CONSULTATIONS — chaque passage horodaté : motif, examen, diagnostic,
 *                   constantes (tension, poids, température).
 *   PRESCRIPTIONS — les médicaments prescrits lors d'une consultation ; le
 *                   moteur CROISE la prescription avec les allergies connues
 *                   du patient et alerte AVANT validation.
 *
 * Confidentialité : le DME est rattaché au pack actif (clinique|hôpital) et
 * cloisonné comme le reste des données de santé.
 *
 * @package FinaKop_ERP_Core
 */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );

class FKC_SanteDossier {

	/*
	 * 1.858.0 — mémorisé PAR BASE : un simple booléen déclarait les tables
	 * prêtes pour la première société ouverte dans le processus, et la
	 * suivante (bascule de société, harnais multi-dossiers) mourait sur
	 * « no such table ».
	 */
	protected static $ready = array();

	protected static function cleBase() { return method_exists( 'FKC_DB', 'file' ) ? (string) FKC_DB::file() : 'x'; }

	protected static function pack() { return class_exists( 'FKC_Packs' ) ? FKC_Packs::activeCode() : 'clinique'; }

	public static function ensure() {
		if ( isset( self::$ready[ self::cleBase() ] ) ) { return; }
		self::$ready[ self::cleBase() ] = true;
		// Le dossier référence les praticiens (consultations) : s'assurer que
		// leur table existe, même si le pack ne les a pas encore touchés.
		if ( class_exists( 'FKC_SantePraticien' ) ) { FKC_SantePraticien::ensure(); }
		FKC_DB::conn()->exec( "
			CREATE TABLE IF NOT EXISTS sante_patients(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				pack TEXT NOT NULL,
				code TEXT NOT NULL,
				nom TEXT NOT NULL,
				sexe TEXT DEFAULT '',
				date_naissance TEXT,
				telephone TEXT DEFAULT '',
				groupe_sanguin TEXT DEFAULT '',
				actif INTEGER NOT NULL DEFAULT 1,
				created_at TEXT DEFAULT(datetime('now','localtime')),
				UNIQUE(pack, code)
			);
			CREATE TABLE IF NOT EXISTS sante_antecedents(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				patient_id INTEGER NOT NULL,
				type TEXT NOT NULL DEFAULT 'chronique', -- chronique | chirurgical | familial | autre
				libelle TEXT NOT NULL,
				depuis TEXT DEFAULT '',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_allergies(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				patient_id INTEGER NOT NULL,
				substance TEXT NOT NULL,
				severite TEXT NOT NULL DEFAULT 'moderee', -- legere | moderee | severe
				note TEXT DEFAULT '',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_consultations(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				patient_id INTEGER NOT NULL,
				praticien_id INTEGER,
				date_consult TEXT NOT NULL,
				motif TEXT DEFAULT '',
				examen TEXT DEFAULT '',
				diagnostic TEXT DEFAULT '',
				tension TEXT DEFAULT '',
				poids REAL,
				temperature REAL,
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE TABLE IF NOT EXISTS sante_prescriptions(
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				consultation_id INTEGER NOT NULL,
				medicament TEXT NOT NULL,
				posologie TEXT DEFAULT '',
				duree TEXT DEFAULT '',
				created_at TEXT DEFAULT(datetime('now','localtime'))
			);
			CREATE INDEX IF NOT EXISTS idx_sante_pat_pack ON sante_patients(pack, actif);
			CREATE INDEX IF NOT EXISTS idx_sante_antec ON sante_antecedents(patient_id);
			CREATE INDEX IF NOT EXISTS idx_sante_allerg ON sante_allergies(patient_id);
			CREATE INDEX IF NOT EXISTS idx_sante_consult ON sante_consultations(patient_id, date_consult);
			CREATE INDEX IF NOT EXISTS idx_sante_presc ON sante_prescriptions(consultation_id);
		" );
		// 1.859.0 — journal d'accès au dossier médical (qui a lu ou écrit quoi, quand).
		FKC_DB::conn()->exec( "CREATE TABLE IF NOT EXISTS sante_acces(
			id INTEGER PRIMARY KEY AUTOINCREMENT, pack TEXT NOT NULL, patient_id INTEGER NOT NULL,
			user_id INTEGER, action TEXT NOT NULL, at TEXT DEFAULT(datetime('now','localtime')));
			CREATE INDEX IF NOT EXISTS idx_sante_acces ON sante_acces(patient_id, id);" );
		// 1.858.0 — le patient du DME connaît son dossier de FACTURATION.
		$cols = array_column( FKC_DB::q( 'PRAGMA table_info(sante_patients)' )->fetchAll(), 'name' );
		if ( ! in_array( 'dossier_id', $cols, true ) ) {
			FKC_DB::conn()->exec( 'ALTER TABLE sante_patients ADD COLUMN dossier_id INTEGER' );
		}
	}

	/* ── Patients ────────────────────────────────────────────────────────── */

	public static function nextCode() {
		self::ensure();
		/*
		 * 1.858.0 — le plus haut numéro attribué, pas le nombre de patients :
		 * un code saisi à la main (« PAT-00003 ») faisait échouer la création
		 * suivante sur « Code patient déjà utilisé », indéfiniment.
		 */
		$max = 0;
		foreach ( FKC_DB::q( "SELECT code FROM sante_patients WHERE pack=? AND code LIKE 'PAT-%'", array( self::pack() ) )->fetchAll() as $r ) {
			$max = max( $max, (int) substr( (string) $r['code'], 4 ) );
		}
		return 'PAT-' . str_pad( (string) ( $max + 1 ), 5, '0', STR_PAD_LEFT );
	}

	public static function creerPatient( array $d ) {
		self::ensure();
		$nom = trim( (string) ( $d['nom'] ?? '' ) );
		if ( '' === $nom ) { return array( false, 'Le nom du patient est obligatoire.', null ); }
		$code = trim( (string) ( $d['code'] ?? '' ) ) ?: self::nextCode();
		$dn = trim( (string) ( $d['date_naissance'] ?? '' ) );
		if ( '' !== $dn && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dn ) || $dn > date( 'Y-m-d' ) ) ) {
			return array( false, 'Date de naissance invalide.', null );
		}
		$d['date_naissance'] = '' !== $dn ? $dn : null;
		try {
			FKC_DB::q(
				'INSERT INTO sante_patients(pack, code, nom, sexe, date_naissance, telephone, groupe_sanguin) VALUES(?,?,?,?,?,?,?)',
				array( self::pack(), $code, $nom, (string) ( $d['sexe'] ?? '' ), $d['date_naissance'] ?? null,
					(string) ( $d['telephone'] ?? '' ), (string) ( $d['groupe_sanguin'] ?? '' ) )
			);
			return array( true, 'Patient créé.', (int) FKC_DB::conn()->lastInsertId() );
		} catch ( \Throwable $e ) { return array( false, 'Code patient déjà utilisé.', null ); }
	}

	public static function patients( $recherche = '' ) {
		self::ensure();
		$sql = 'SELECT * FROM sante_patients WHERE pack=? AND actif=1'; $a = array( self::pack() );
		if ( '' !== trim( (string) $recherche ) ) {
			$sql .= ' AND (nom LIKE ? OR code LIKE ?)';
			$like = '%' . trim( $recherche ) . '%'; $a[] = $like; $a[] = $like;
		}
		return FKC_DB::q( $sql . ' ORDER BY nom LIMIT 100', $a )->fetchAll();
	}

	public static function patient( $id ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_patients WHERE id=? AND pack=?', array( (int) $id, self::pack() ) )->fetch() ?: null;
	}

	public static function age( $patient ) {
		if ( empty( $patient['date_naissance'] ) ) { return null; }
		try { return ( new \DateTime( (string) $patient['date_naissance'] ) )->diff( new \DateTime( 'today' ) )->y; }
		catch ( \Throwable $e ) { return null; }
	}

	/**
	 * Dossier de FACTURATION du patient (moteur vertical) : celui déjà lié,
	 * sinon retrouvé ou ouvert à son nom, puis mémorisé. C'est le pont entre
	 * le soin (DME) et la créance (pièces, règlements, tiers payant).
	 * @return array{0: bool, 1: string, 2: int|null}
	 */
	public static function dossierFacturation( $patientId ) {
		$p = self::patient( $patientId );
		if ( ! $p ) { return array( false, 'Patient introuvable.', null ); }
		if ( ! class_exists( 'FKC_SanteFacturation' ) ) { return array( false, 'Facturation indisponible.', null ); }
		list( $ok, $msg, $did ) = FKC_SanteFacturation::dossierPatient( $p['nom'], (int) ( $p['dossier_id'] ?? 0 ) );
		if ( ! $ok ) { return array( false, $msg, null ); }
		FKC_DB::q( 'UPDATE sante_patients SET dossier_id=? WHERE id=?', array( (int) $did, (int) $p['id'] ) );
		return array( true, 'Dossier de facturation prêt.', (int) $did );
	}

	/* ── Antécédents & allergies ─────────────────────────────────────────── */

	public static function ajouterAntecedent( $patientId, $type, $libelle, $depuis = '' ) {
		self::ensure();
		if ( ! self::patient( $patientId ) ) { return array( false, 'Patient introuvable.' ); }
		if ( '' === trim( (string) $libelle ) ) { return array( false, 'Libellé obligatoire.' ); }
		$type = in_array( $type, array( 'chronique', 'chirurgical', 'familial', 'autre' ), true ) ? $type : 'autre';
		FKC_DB::q( 'INSERT INTO sante_antecedents(patient_id, type, libelle, depuis) VALUES(?,?,?,?)',
			array( (int) $patientId, $type, trim( $libelle ), trim( (string) $depuis ) ) );
		return array( true, 'Antécédent ajouté.' );
	}

	public static function antecedents( $patientId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_antecedents WHERE patient_id=? ORDER BY type, id', array( (int) $patientId ) )->fetchAll();
	}

	public static function ajouterAllergie( $patientId, $substance, $severite = 'moderee', $note = '' ) {
		self::ensure();
		if ( ! self::patient( $patientId ) ) { return array( false, 'Patient introuvable.' ); }
		if ( '' === trim( (string) $substance ) ) { return array( false, 'Substance obligatoire.' ); }
		$severite = in_array( $severite, array( 'legere', 'moderee', 'severe' ), true ) ? $severite : 'moderee';
		FKC_DB::q( 'INSERT INTO sante_allergies(patient_id, substance, severite, note) VALUES(?,?,?,?)',
			array( (int) $patientId, trim( $substance ), $severite, trim( (string) $note ) ) );
		return array( true, 'Allergie enregistrée.' );
	}

	public static function allergies( $patientId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_allergies WHERE patient_id=? ORDER BY (severite=\'severe\') DESC, substance', array( (int) $patientId ) )->fetchAll();
	}

	/* ── Consultations & prescriptions ───────────────────────────────────── */

	public static function creerConsultation( array $d ) {
		self::ensure();
		$patientId = (int) ( $d['patient_id'] ?? 0 );
		if ( ! self::patient( $patientId ) ) { return array( false, 'Patient introuvable.', null ); }
		$date = str_replace( 'T', ' ', trim( (string) ( $d['date_consult'] ?? '' ) ) ) ?: date( 'Y-m-d H:i' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2})?$/', $date ) ) { return array( false, 'Date de consultation invalide.', null ); }
		$d['date_consult'] = $date;
		if ( ! empty( $d['praticien_id'] ) && class_exists( 'FKC_SantePraticien' ) && ! FKC_SantePraticien::find( (int) $d['praticien_id'] ) ) { $d['praticien_id'] = null; }
		FKC_DB::q(
			'INSERT INTO sante_consultations(patient_id, praticien_id, date_consult, motif, examen, diagnostic, tension, poids, temperature) VALUES(?,?,?,?,?,?,?,?,?)',
			array( $patientId, ! empty( $d['praticien_id'] ) ? (int) $d['praticien_id'] : null,
				$d['date_consult'] ?? date( 'Y-m-d H:i' ), (string) ( $d['motif'] ?? '' ),
				(string) ( $d['examen'] ?? '' ), (string) ( $d['diagnostic'] ?? '' ),
				(string) ( $d['tension'] ?? '' ),
				'' !== ( $d['poids'] ?? '' ) ? (float) $d['poids'] : null,
				'' !== ( $d['temperature'] ?? '' ) ? (float) $d['temperature'] : null )
		);
		return array( true, 'Consultation enregistrée.', (int) FKC_DB::conn()->lastInsertId() );
	}

	public static function consultations( $patientId, $limit = 50 ) {
		self::ensure();
		return FKC_DB::q(
			'SELECT c.*, p.nom AS praticien FROM sante_consultations c LEFT JOIN sante_praticiens p ON p.id=c.praticien_id
			 WHERE c.patient_id=? ORDER BY c.date_consult DESC LIMIT ' . max( 1, (int) $limit ),
			array( (int) $patientId )
		)->fetchAll();
	}

	public static function prescriptions( $consultationId ) {
		self::ensure();
		return FKC_DB::q( 'SELECT * FROM sante_prescriptions WHERE consultation_id=? ORDER BY id', array( (int) $consultationId ) )->fetchAll();
	}

	/**
	 * Ajoute une prescription APRÈS avoir croisé le médicament avec les
	 * allergies connues du patient. Retourne l'alerte s'il y a correspondance
	 * (la prescription est tout de même enregistrée : c'est le praticien qui
	 * tranche, mais il est prévenu).
	 * @return array{ok: bool, alerte: string|null}
	 */
	public static function prescrire( $consultationId, $medicament, $posologie = '', $duree = '', $patientId = 0 ) {
		self::ensure();
		$c = FKC_DB::q( 'SELECT * FROM sante_consultations WHERE id=?', array( (int) $consultationId ) )->fetch();
		if ( ! $c ) { return array( 'ok' => false, 'alerte' => null ); }
		// 1.858.0 — la consultation doit appartenir au patient ouvert, et le patient au pack actif.
		if ( ! self::patient( (int) $c['patient_id'] ) ) { return array( 'ok' => false, 'alerte' => null ); }
		if ( (int) $patientId > 0 && (int) $c['patient_id'] !== (int) $patientId ) { return array( 'ok' => false, 'alerte' => null ); }
		if ( '' === trim( (string) $medicament ) ) { return array( 'ok' => false, 'alerte' => null ); }
		$alerte = self::verifierAllergie( (int) $c['patient_id'], $medicament );
		$inter  = self::verifierInteractions( (int) $c['patient_id'], $medicament );
		if ( $inter ) { $alerte = trim( ( $alerte ? $alerte . ' ' : '' ) . $inter ); }
		FKC_DB::q( 'INSERT INTO sante_prescriptions(consultation_id, medicament, posologie, duree) VALUES(?,?,?,?)',
			array( (int) $consultationId, trim( $medicament ), trim( (string) $posologie ), trim( (string) $duree ) ) );
		return array( 'ok' => true, 'alerte' => $alerte );
	}

	/**
	 * Familles thérapeutiques les plus impliquées dans les allergies
	 * médicamenteuses. Une allergie déclarée « pénicilline » ne se lit pas dans
	 * « Amoxicilline 1 g » par simple sous-chaîne : c'est pourtant LE cas qui
	 * tue. Aide à la vigilance, pas un référentiel : le praticien tranche.
	 */
	const FAMILLES = array(
		'penicilline'     => array( 'penicilline', 'amoxicilline', 'ampicilline', 'oxacilline', 'cloxacilline', 'benzathine', 'augmentin', 'extencilline' ),
		'cephalosporine'  => array( 'ceftriaxone', 'cefixime', 'cefuroxime', 'cefalexine', 'cefotaxime', 'cefadroxil', 'cefpodoxime' ),
		'sulfamide'       => array( 'sulfamethoxazole', 'cotrimoxazole', 'bactrim', 'sulfadoxine', 'fansidar' ),
		'ains'            => array( 'ibuprofene', 'diclofenac', 'ketoprofene', 'naproxene', 'aspirine', 'acetylsalicylique', 'piroxicam', 'indometacine' ),
		'aspirine'        => array( 'aspirine', 'acetylsalicylique', 'aspegic', 'kardegic' ),
		'quinine'         => array( 'quinine', 'quinimax' ),
		'iode'            => array( 'iode', 'povidone', 'betadine', 'amiodarone' ),
	);

	/** Minuscules sans accents, pour comparer « pénicilline » et « PENICILLINE ». */
	protected static function norm( $s ) {
		$s = mb_strtolower( trim( (string) $s ) );
		$t = @iconv( 'UTF-8', 'ASCII//TRANSLIT//IGNORE', $s );
		return preg_replace( '/[^a-z0-9 ]/', '', false !== $t ? $t : $s );
	}

	/**
	 * 1.859.0 — NOMS COMMERCIAUX → MOLÉCULE (DCI). Une allergie se déclare à
	 * la molécule ; l'ordonnance porte souvent la marque. « Augmentin » ne
	 * contient pas le mot « amoxicilline » : sans cette table, l'alerte
	 * pénicilline restait muette sur le premier antibiotique prescrit en
	 * Afrique de l'Ouest. Complétée, quand elle existe dans la base, par le
	 * catalogue de l'officine (ph_medicaments : libellé → DCI).
	 */
	const MARQUES = array(
		'augmentin' => 'amoxicilline', 'clamoxyl' => 'amoxicilline', 'hiconcil' => 'amoxicilline', 'amoxil' => 'amoxicilline',
		'totapen' => 'ampicilline', 'orbenine' => 'cloxacilline', 'extencilline' => 'benzathine',
		'rocephine' => 'ceftriaxone', 'oroken' => 'cefixime', 'zinnat' => 'cefuroxime', 'keforal' => 'cefalexine',
		'bactrim' => 'sulfamethoxazole', 'eusaprim' => 'sulfamethoxazole', 'fansidar' => 'sulfadoxine',
		'doliprane' => 'paracetamol', 'efferalgan' => 'paracetamol', 'dafalgan' => 'paracetamol', 'panadol' => 'paracetamol',
		'advil' => 'ibuprofene', 'nurofen' => 'ibuprofene', 'brufen' => 'ibuprofene', 'voltarene' => 'diclofenac', 'cataflam' => 'diclofenac',
		'profenid' => 'ketoprofene', 'aspegic' => 'aspirine', 'kardegic' => 'aspirine', 'feldene' => 'piroxicam', 'indocid' => 'indometacine',
		'coumadine' => 'warfarine', 'sintrom' => 'acenocoumarol', 'previscan' => 'fluindione',
		'zeclar' => 'clarithromycine', 'erythrocine' => 'erythromycine', 'zocor' => 'simvastatine', 'tahor' => 'atorvastatine',
		'ciflox' => 'ciprofloxacine', 'theostat' => 'theophylline', 'coartem' => 'artemether', 'quinimax' => 'quinine',
		'flagyl' => 'metronidazole', 'betadine' => 'povidone', 'cordarone' => 'amiodarone',
	);

	/**
	 * Interactions à risque (aide à la vigilance, non exhaustive) : deux
	 * groupes de molécules, et le risque. Vérifiées contre l'ordonnance en
	 * cours ET les prescriptions des 30 derniers jours du patient.
	 */
	const INTERACTIONS = array(
		array( array( 'ibuprofene', 'diclofenac', 'ketoprofene', 'naproxene', 'piroxicam', 'indometacine', 'aspirine' ), array( 'warfarine', 'acenocoumarol', 'fluindione' ), 'risque hémorragique (AINS / aspirine + anticoagulant)' ),
		array( array( 'ibuprofene', 'diclofenac', 'ketoprofene', 'naproxene', 'piroxicam', 'indometacine' ), array( 'ibuprofene', 'diclofenac', 'ketoprofene', 'naproxene', 'piroxicam', 'indometacine', 'aspirine' ), 'association de deux anti-inflammatoires : toxicité digestive et rénale' ),
		array( array( 'clarithromycine', 'erythromycine' ), array( 'simvastatine', 'atorvastatine' ), 'rhabdomyolyse (macrolide + statine)' ),
		array( array( 'ciprofloxacine' ), array( 'theophylline' ), 'surdosage en théophylline (fluoroquinolone)' ),
		array( array( 'artemether' ), array( 'quinine', 'amiodarone' ), 'allongement du QT (troubles du rythme)' ),
		array( array( 'metronidazole' ), array( 'warfarine', 'acenocoumarol', 'fluindione' ), 'potentialisation de l\'anticoagulant' ),
	);

	/** Molécules désignées par un libellé de prescription : le libellé lui-même, sa marque résolue, la DCI de l'officine. */
	public static function molecules( $medicament ) {
		$n = self::norm( $medicament );
		$out = array( $n );
		foreach ( self::MARQUES as $marque => $dci ) {
			if ( false !== strpos( $n, $marque ) ) { $out[] = $dci; }
		}
		try {
			$t = FKC_DB::q( "SELECT 1 FROM sqlite_master WHERE type='table' AND name='ph_medicaments'" )->fetchColumn();
			if ( $t ) {
				foreach ( FKC_DB::q( "SELECT libelle, dci FROM ph_medicaments WHERE dci<>''" )->fetchAll() as $m ) {
					$lib = self::norm( $m['libelle'] );
					if ( '' !== $lib && false !== strpos( $n, $lib ) ) { $out[] = self::norm( $m['dci'] ); }
				}
			}
		} catch ( \Throwable $e ) {}
		return array_values( array_unique( array_filter( $out ) ) );
	}

	/**
	 * Interactions entre un médicament et l'ordonnance en cours + les
	 * prescriptions des 30 derniers jours du patient.
	 * @return string|null
	 */
	public static function verifierInteractions( $patientId, $medicament ) {
		$nouv = implode( ' ', self::molecules( $medicament ) );
		$recentes = FKC_DB::q(
			"SELECT pr.medicament FROM sante_prescriptions pr JOIN sante_consultations c ON c.id=pr.consultation_id
			 WHERE c.patient_id=? AND date(c.date_consult) >= date('now','-30 day')",
			array( (int) $patientId )
		)->fetchAll();
		foreach ( $recentes as $r ) {
			$autre = implode( ' ', self::molecules( $r['medicament'] ) );
			if ( $autre === $nouv ) { continue; } // renouvellement du même produit : pas une association
			foreach ( self::INTERACTIONS as $it ) {
				$a = false; $b = false; $a2 = false; $b2 = false;
				foreach ( $it[0] as $m ) { if ( false !== strpos( $nouv, $m ) ) { $a = true; } if ( false !== strpos( $autre, $m ) ) { $a2 = true; } }
				foreach ( $it[1] as $m ) { if ( false !== strpos( $autre, $m ) ) { $b = true; } if ( false !== strpos( $nouv, $m ) ) { $b2 = true; } }
				if ( ( $a && $b ) || ( $a2 && $b2 ) ) {
					return sprintf( '⚠️ INTERACTION : « %s » avec « %s » — %s.', $medicament, $r['medicament'], $it[2] );
				}
			}
		}
		return null;
	}

	/** Trace un accès au dossier médical (lecture, écriture, impression). */
	public static function tracer( $patientId, $action ) {
		self::ensure();
		try {
			FKC_DB::q( 'INSERT INTO sante_acces(pack, patient_id, user_id, action) VALUES(?,?,?,?)',
				array( self::pack(), (int) $patientId, class_exists( 'FKC_Auth' ) ? FKC_Auth::id() : null, substr( (string) $action, 0, 60 ) ) );
		} catch ( \Throwable $e ) {}
	}

	/** Derniers accès au dossier, avec le nom de l'utilisateur. */
	public static function acces( $patientId, $limit = 12 ) {
		self::ensure();
		$rows = FKC_DB::q( 'SELECT * FROM sante_acces WHERE patient_id=? AND pack=? ORDER BY id DESC LIMIT ' . max( 1, (int) $limit ), array( (int) $patientId, self::pack() ) )->fetchAll();
		foreach ( $rows as &$r ) {
			$r['utilisateur'] = '—';
			if ( ! empty( $r['user_id'] ) && class_exists( 'FKC_Master' ) ) {
				try { $r['utilisateur'] = (string) ( FKC_Master::q( 'SELECT nom_complet FROM cabinet_users WHERE id=?', array( (int) $r['user_id'] ) )->fetchColumn() ?: '#' . $r['user_id'] ); } catch ( \Throwable $e ) {}
			}
		}
		return $rows;
	}

	/**
	 * Détecte si un médicament recoupe une allergie du patient : même
	 * substance (sans casse ni accents), ou même FAMILLE thérapeutique.
	 * @return string|null message d'alerte, null si rien.
	 */
	public static function verifierAllergie( $patientId, $medicament ) {
		$med = implode( ' ', self::molecules( $medicament ) );
		if ( '' === trim( $med ) ) { return null; }
		foreach ( self::allergies( $patientId ) as $a ) {
			$sub = self::norm( $a['substance'] );
			if ( '' === $sub ) { continue; }
			$touche = false !== strpos( $med, $sub ) || ( strlen( $med ) >= 4 && false !== strpos( $sub, $med ) );
			$famille = '';
			if ( ! $touche ) {
				foreach ( self::FAMILLES as $fam => $membres ) {
					$subDans = false !== strpos( $sub, $fam ) || in_array( $sub, $membres, true );
					if ( ! $subDans ) { foreach ( $membres as $m ) { if ( false !== strpos( $sub, $m ) ) { $subDans = true; break; } } }
					if ( ! $subDans ) { continue; }
					foreach ( $membres as $m ) {
						if ( false !== strpos( $med, $m ) ) { $touche = true; $famille = $fam; break 2; }
					}
				}
			}
			if ( $touche ) {
				return sprintf( '⚠️ ALLERGIE %s : « %s » recoupe l\'allergie connue « %s » du patient%s.',
					mb_strtoupper( $a['severite'] ), $medicament, $a['substance'],
					'' !== $famille ? ' (même famille : ' . $famille . ')' : '' );
			}
		}
		return null;
	}

	/** Résumé cliniquement utile pour l'en-tête du dossier (allergies d'abord). */
	public static function resume( $patientId ) {
		return array(
			'allergies' => self::allergies( $patientId ),
			'antecedents' => self::antecedents( $patientId ),
			'derniere_consult' => self::consultations( $patientId, 1 )[0] ?? null,
		);
	}
}
