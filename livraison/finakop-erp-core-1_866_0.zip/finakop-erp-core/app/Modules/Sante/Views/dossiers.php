<?php /** @var string $module @var array $patients @var string $q @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'dme' ) );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= $flash['ok'] ? 'ok' : 'err' ?>" role="status"><?= e( $flash['msg'] ) ?></div><?php endif; ?>
<div class="sa-grid-main">
	<div class="card card-flush">
		<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
			<h2>🩺 Dossiers médicaux</h2>
			<form method="get" action="<?= e( url( $module . '/dme' ) ) ?>" style="display:flex;gap:6px"><input name="q" value="<?= e( $q ) ?>" placeholder="Nom ou code…" aria-label="Rechercher un patient"><button class="btn btn-sm">Chercher</button></form>
		</div>
		<div class="sa-table-wrap"><table class="table"><thead><tr><th>Code</th><th>Patient</th><th>Âge</th><th>Sexe</th><th>Groupe</th><th></th></tr></thead><tbody>
		<?php if ( ! $patients ) : ?><tr><td colspan="6" class="empty">Aucun patient<?= $q ? ' pour « ' . e( $q ) . ' »' : '' ?>.</td></tr>
		<?php else : foreach ( $patients as $p ) : $age = FKC_SanteDossier::age( $p ); ?>
			<tr><td><code style="font-size:12px"><?= e( $p['code'] ) ?></code></td>
			<td><a href="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>"><strong><?= e( $p['nom'] ) ?></strong></a></td>
			<td class="muted"><?= null !== $age ? (int) $age . ' ans' : '—' ?></td>
			<td class="muted"><?= e( $p['sexe'] ?: '—' ) ?></td>
			<td><?= $p['groupe_sanguin'] ? '<span class="sa-badge err">' . e( $p['groupe_sanguin'] ) . '</span>' : '<span class="muted">—</span>' ?></td>
			<td style="text-align:right"><a class="btn btn-sm" href="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>">Ouvrir</a></td></tr>
		<?php endforeach; endif; ?>
		</tbody></table></div>
		<p class="sa-help" style="padding:0 16px 12px">Le dossier médical est confidentiel : il ne partage avec la facturation que le nom du patient. Les pièces et règlements vivent dans le dossier de facturation (« Facturation »).</p>
	</div>
	<div class="card">
		<div class="card-head"><h2>＋ Nouveau patient</h2></div>
		<div class="card-body"><form method="post" action="<?= e( url( $module . '/dme/creer' ) ) ?>"><?= FKC_Csrf::field() ?>
			<label class="fld"><span>Nom complet</span><input name="nom" required></label>
			<div style="display:flex;gap:8px"><label class="fld" style="flex:1"><span>Sexe</span><select name="sexe"><option value="">—</option><option>M</option><option>F</option></select></label>
			<label class="fld" style="flex:1"><span>Groupe</span><select name="groupe_sanguin"><option value="">—</option><?php foreach ( array( 'O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-' ) as $g ) : ?><option><?= e( $g ) ?></option><?php endforeach; ?></select></label></div>
			<label class="fld"><span>Naissance</span><input type="date" name="date_naissance" max="<?= e( date( 'Y-m-d' ) ) ?>"></label>
			<label class="fld"><span>Téléphone</span><input name="telephone" inputmode="tel"></label>
			<button class="btn btn-primary" type="submit">Créer le dossier</button>
		</form></div>
	</div>
</div>
