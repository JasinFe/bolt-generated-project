<?php /** @var string $module @var array $lits @var array $occupation @var array $sejours @var array $sorties @var float $dms @var array $services @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'hospitalisation' ) );
$litsLibres = array_values( array_filter( $lits, fn( $l ) => empty( $l['sejour_id'] ) ) );
// Occupation : saturée au-delà de 90 %, confortable entre 60 et 90, sous-utilisée en deçà.
$occCol = $occupation['taux'] >= 90 ? 'var(--danger)' : ( $occupation['taux'] >= 60 ? 'var(--ok)' : 'var(--warn)' );
$encours = 0.0;
foreach ( $sejours as $s ) {
	$n = (int) ( new DateTime( $s['facture_jusqu'] ?: $s['entree'] ) )->diff( new DateTime( 'today' ) )->days;
	if ( empty( $s['facture_jusqu'] ) ) { $n = max( 1, $n ); }
	$encours += $n * ( (float) $s['tarif_nuit'] + FKC_SanteHospit::forfaitService( $s['service'] ?? '' ) );
}
$servicesLits = array();
foreach ( $lits as $l ) { $servicesLits[ (string) ( $l['service'] ?: 'Sans service' ) ][] = $l; }
?>
<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>" role="status"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="sa-kpis">
	<div class="sa-kpi" style="--sa-c:<?= $occCol ?>"><div class="l">Occupation des lits</div><div class="v"><?= e( $occupation['taux'] ) ?> %</div>
		<div class="sa-gauge" style="--sa-c:<?= $occCol ?>"><span style="width:<?= min( 100, (float) $occupation['taux'] ) ?>%"></span></div>
		<div class="s"><?= (int) $occupation['occupes'] ?> / <?= (int) $occupation['lits'] ?> lits</div></div>
	<div class="sa-kpi" style="--sa-c:var(--ok)"><div class="l">Lits libres</div><div class="v"><?= count( $litsLibres ) ?></div><div class="s">prêts à l'admission</div></div>
	<div class="sa-kpi" style="--sa-c:var(--blue)"><div class="l">Durée moyenne de séjour</div><div class="v"><?= e( $dms ) ?> nuit<?= $dms > 1 ? 's' : '' ?></div><div class="s">sorties des 90 derniers jours</div></div>
	<div class="sa-kpi" style="--sa-c:var(--orange)"><div class="l">Séjours en cours à facturer</div><div class="v"><?= fkc_money( $encours ) ?> F</div><div class="s">nuitées non encore facturées × (tarif + forfait)</div></div>
</div>

<div class="card card-flush">
	<div class="card-head"><h2>🛏️ Tableau des lits</h2></div>
	<div class="card-body">
		<?php if ( ! $lits ) : ?>
			<div class="alert alert-warn">Aucun lit enregistré — commencez par déclarer vos lits ci-dessous.</div>
		<?php else : foreach ( $servicesLits as $svc => $ls ) : ?>
			<h3 style="font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);margin:10px 0 8px"><?= e( $svc ) ?> <span class="sa-badge"><?= count( array_filter( $ls, fn( $l ) => ! empty( $l['sejour_id'] ) ) ) ?>/<?= count( $ls ) ?></span></h3>
			<div class="sa-beds">
			<?php foreach ( $ls as $l ) : $occupe = ! empty( $l['sejour_id'] ); ?>
				<div class="sa-bed<?= $occupe ? ' busy' : '' ?>">
					<div style="display:flex;justify-content:space-between;align-items:center"><span class="n">Lit <?= e( $l['numero'] ) ?></span><span class="sa-badge <?= $occupe ? 'warn' : 'ok' ?>"><?= $occupe ? 'Occupé' : 'Libre' ?></span></div>
					<div class="s"><?= fkc_money( $l['tarif_nuit'] ) ?> F / nuit</div>
					<?php if ( $occupe ) : ?>
						<div class="p"><?= e( $l['patient_actuel'] ) ?></div>
						<div class="s">entré le <?= e( date( 'd/m/Y', strtotime( $l['entree'] ) ) ) ?></div>
						<form method="post" action="<?= e( url( $module . '/hospitalisation/sejour/' . (int) $l['sejour_id'] . '/sortir' ) ) ?>" onsubmit="return confirm('Clôturer le séjour et facturer les nuitées restantes ?');">
							<?= FKC_Csrf::field() ?>
							<input type="date" name="sortie" value="<?= e( date( 'Y-m-d' ) ) ?>" min="<?= e( $l['entree'] ) ?>" max="<?= e( date( 'Y-m-d' ) ) ?>" aria-label="Date de sortie">
							<button class="btn btn-primary btn-sm" type="submit">Sortie + facture</button>
						</form>
						<details style="margin-top:6px"><summary class="btn btn-ghost btn-sm">Plus…</summary>
							<form method="post" action="<?= e( url( $module . '/hospitalisation/sejour/' . (int) $l['sejour_id'] . '/facturer' ) ) ?>" style="margin-top:6px"><?= FKC_Csrf::field() ?>
								<button class="btn btn-ghost btn-sm" type="submit" title="Facturer les nuitées écoulées sans clore le séjour">🧾 Facture intermédiaire</button>
							</form>
							<?php if ( $litsLibres ) : ?>
							<form method="post" action="<?= e( url( $module . '/hospitalisation/sejour/' . (int) $l['sejour_id'] . '/transferer' ) ) ?>" style="margin-top:6px"><?= FKC_Csrf::field() ?>
								<select name="lit_id" aria-label="Lit de destination"><?php foreach ( $litsLibres as $ll ) : ?><option value="<?= (int) $ll['id'] ?>"><?= e( $ll['numero'] ) ?><?= $ll['service'] ? ' — ' . e( $ll['service'] ) : '' ?></option><?php endforeach; ?></select>
								<button class="btn btn-ghost btn-sm" type="submit">⇄ Transférer</button>
							</form>
							<?php endif; ?>
						</details>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
			</div>
		<?php endforeach; ?>
		<p class="sa-help" style="margin-top:12px">À la sortie, le séjour est facturé (nuitées calendaires × tarif du lit) dans le dossier du patient, puis validé : la part assurance du dossier part sur l'organisme payeur.</p>
		<?php endif; ?>
	</div>
</div>

<div class="sa-grid2" style="margin-top:18px">
	<div class="card card-flush">
		<div class="card-head"><h2>➕ Admettre un patient</h2></div>
		<div class="card-body">
			<?php if ( ! $litsLibres ) : ?>
				<div class="empty">Aucun lit libre.</div>
			<?php else : ?>
			<form method="post" action="<?= e( url( $module . '/hospitalisation/admettre' ) ) ?>" class="sa-form">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Lit</span><select name="lit_id"><?php foreach ( $litsLibres as $l ) : ?><option value="<?= (int) $l['id'] ?>"><?= e( $l['numero'] ) ?><?= $l['service'] ? ' — ' . e( $l['service'] ) : '' ?> (<?= fkc_money( $l['tarif_nuit'] ) ?> F)</option><?php endforeach; ?></select></label>
				<label class="fld"><span>Patient</span><input name="patient" required></label>
				<label class="fld"><span>Date d'entrée</span><input type="date" name="entree" value="<?= e( date( 'Y-m-d' ) ) ?>" max="<?= e( date( 'Y-m-d' ) ) ?>"></label>
				<button class="btn btn-primary" type="submit">Admettre</button>
			</form>
			<?php endif; ?>
		</div>
	</div>
	<div class="card card-flush">
		<div class="card-head"><h2>🛏️ Déclarer un lit</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url( $module . '/hospitalisation/lit' ) ) ?>" class="sa-form">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Numéro</span><input name="numero" required placeholder="A-101"></label>
				<label class="fld"><span>Service</span><input name="service" placeholder="Médecine, Maternité…"></label>
				<label class="fld"><span>Tarif par nuit (F)</span><input type="number" name="tarif_nuit" min="0" step="1000" value="25000"></label>
				<button class="btn btn-primary" type="submit">Enregistrer le lit</button>
			</form>
		</div>
	</div>
</div>

<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>🏷️ Forfaits journaliers par service</h2></div>
	<div class="card-body">
		<p class="sa-help">Ajoutés à chaque nuitée des lits du service (soins infirmiers, repas, surveillance), en plus du tarif du lit.</p>
		<?php if ( $services ) : ?><div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px"><?php foreach ( $services as $sv ) : ?><span class="sa-badge info"><?= e( $sv['service'] ) ?> : <?= fkc_money( $sv['forfait_jour'] ) ?> F/j</span><?php endforeach; ?></div><?php endif; ?>
		<form method="post" action="<?= e( url( $module . '/hospitalisation/forfait' ) ) ?>" class="sa-form"><?= FKC_Csrf::field() ?>
			<label class="fld"><span>Service</span><input name="service" required list="sa-services"><datalist id="sa-services"><?php foreach ( array_keys( $servicesLits ) as $sn ) : ?><option value="<?= e( $sn ) ?>"><?php endforeach; ?></datalist></label>
			<label class="fld"><span>Forfait par jour (F)</span><input type="number" name="forfait_jour" min="0" step="500" value="0"></label>
			<button class="btn btn-sm" type="submit">Enregistrer</button>
		</form>
	</div>
</div>

<?php if ( $sorties ) : ?>
<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>🚪 Dernières sorties</h2></div>
	<div class="sa-table-wrap"><table class="table">
		<thead><tr><th>Patient</th><th>Lit</th><th>Entrée</th><th>Sortie</th><th class="sa-right">Nuitées</th><th class="sa-right">Facturé</th><th></th></tr></thead>
		<tbody>
		<?php foreach ( $sorties as $s ) : ?>
			<tr>
				<td><?= e( $s['patient'] ) ?></td>
				<td class="muted"><?= e( $s['lit'] ) ?><?= $s['service'] ? ' · ' . e( $s['service'] ) : '' ?></td>
				<td><?= e( date( 'd/m/Y', strtotime( $s['entree'] ) ) ) ?></td>
				<td><?= e( $s['sortie'] ? date( 'd/m/Y', strtotime( $s['sortie'] ) ) : '—' ) ?></td>
				<td class="sa-right"><?= (int) $s['nuitees'] ?></td>
				<td class="sa-right"><?= fkc_money( (float) $s['facture'] ) ?> F</td>
				<td style="text-align:right"><?php if ( ! empty( $s['dossier_id'] ) ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/dossiers/' . (int) $s['dossier_id'] ) ) ?>">Dossier</a><?php endif; ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
</div>
<?php endif; ?>
