<?php /** @var string $module @var array $p @var int|null $age @var array $allergies @var array $antecedents @var array $consultations @var array $prescriptions @var array $praticiens @var array|null $facturation @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module . '/dme', 'backLabel' => 'Dossiers médicaux' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'dme' ) );
$stPiece = class_exists( 'FKC_VpPiece' ) ? FKC_VpPiece::statuts() : array();
$initiales = mb_strtoupper( implode( '', array_map( fn( $w ) => mb_substr( $w, 0, 1 ), array_slice( preg_split( '/\s+/', trim( (string) $p['nom'] ) ), 0, 2 ) ) ) );
$sevBadge = array( 'severe' => 'var(--danger)', 'moderee' => 'var(--warn)', 'legere' => 'var(--muted)' );
$typeAnt = array( 'chronique' => 'Chronique', 'chirurgical' => 'Chirurgical', 'familial' => 'Familial', 'autre' => 'Autre' );
?>
<?php if ( $flash ) : ?><div class="alert alert-<?= $flash['ok'] ? 'ok' : 'err' ?>"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="sa-patient">
	<div class="sa-avatar" aria-hidden="true"><?= e( $initiales ?: '?' ) ?></div>
	<div>
		<h1><?= e( $p['nom'] ) ?></h1>
		<div class="meta">
			<span class="sa-badge"><?= e( $p['code'] ) ?></span>
			<?php if ( null !== $age ) : ?><span class="sa-badge info"><?= (int) $age ?> ans</span><?php endif; ?>
			<?php if ( $p['sexe'] ) : ?><span class="sa-badge"><?= e( $p['sexe'] ) ?></span><?php endif; ?>
			<?php if ( $p['groupe_sanguin'] ) : ?><span class="sa-badge err">🩸 <?= e( $p['groupe_sanguin'] ) ?></span><?php endif; ?>
			<?php if ( $p['telephone'] ) : ?><span class="sa-badge">📞 <?= e( $p['telephone'] ) ?></span><?php endif; ?>
			<span class="sa-badge"><?= count( $consultations ) ?> consultation(s)</span>
		</div>
	</div>
	<form class="act" method="post" action="<?= e( url( $module . '/dme/' . (int) $p['id'] . '/facturation' ) ) ?>"><?= FKC_Csrf::field() ?>
		<button class="btn btn-ghost btn-sm" type="submit">🧾 <?= $facturation ? 'Dossier de facturation' : 'Ouvrir la facturation' ?></button>
	</form>
</div>

<?php if ( $allergies ) : ?>
	<div class="sa-allergy" role="alert">
		<span aria-hidden="true">⚠️</span>
		<div><strong>ALLERGIES :</strong>
		<?= e( implode( ' · ', array_map( fn( $a ) => $a['substance'] . ' (' . $a['severite'] . ')', $allergies ) ) ) ?>
		— vérifiez avant toute prescription.</div>
	</div>
<?php endif; ?>

<div class="sa-grid-main">
	<div class="card card-flush">
		<div class="card-head"><h2>Consultations</h2></div>
		<details style="border-bottom:1px solid var(--border)"<?= $consultations ? '' : ' open' ?>>
		<summary class="btn btn-primary btn-sm" style="margin:10px 16px">＋ Nouvelle consultation</summary>
		<form method="post" action="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>" style="padding:4px 16px 12px"><?= FKC_Csrf::field() ?>
			<input type="hidden" name="action" value="consultation">
			<div style="display:flex;gap:8px;flex-wrap:wrap">
				<label class="fld" style="flex:2;min-width:180px"><span>Motif</span><input name="motif" required></label>
				<label class="fld" style="flex:1"><span>Praticien</span><select name="praticien_id"><option value="">—</option><?php foreach ( $praticiens as $pr ) : ?><option value="<?= (int) $pr['id'] ?>"><?= e( $pr['nom'] ) ?></option><?php endforeach; ?></select></label>
			</div>
			<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
				<label class="fld" style="flex:1"><span>Tension</span><input name="tension" placeholder="12/8" style="width:80px"></label>
				<label class="fld" style="flex:1"><span>Poids (kg)</span><input class="num" name="poids" style="width:80px"></label>
				<label class="fld" style="flex:1"><span>Temp. (°C)</span><input class="num" name="temperature" style="width:80px"></label>
			</div>
			<label class="fld" style="margin-top:6px"><span>Examen clinique</span><textarea name="examen" rows="2"></textarea></label>
			<label class="fld" style="margin-top:6px"><span>Diagnostic</span><input name="diagnostic"></label>
			<button class="btn btn-sm" style="margin-top:6px">Enregistrer la consultation</button>
		</form>
		</details>
		<?php if ( ! $consultations ) : ?><div class="empty" style="padding:16px">Aucune consultation enregistrée.</div>
		<?php else : foreach ( $consultations as $c ) : ?>
			<div class="sa-consult">
				<div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">
					<strong><?= e( substr( (string) $c['date_consult'], 0, 16 ) ) ?> — <?= e( $c['motif'] ?: 'consultation' ) ?></strong>
					<span class="muted" style="font-size:12px"><?= e( $c['praticien'] ?: '' ) ?></span>
				</div>
				<?php if ( $c['examen'] ) : ?><div style="font-size:13px;margin-top:2px" class="muted">Examen : <?= e( $c['examen'] ) ?></div><?php endif; ?>
				<?php if ( $c['diagnostic'] ) : ?><div style="font-size:13px;margin-top:2px">Diagnostic : <strong><?= e( $c['diagnostic'] ) ?></strong></div><?php endif; ?>
				<?php if ( $c['tension'] || $c['poids'] || $c['temperature'] ) : ?>
					<div class="sa-vitals">
						<?php if ( $c['tension'] ) : ?><span class="sa-badge info">TA <?= e( $c['tension'] ) ?></span><?php endif; ?>
						<?php if ( $c['poids'] ) : ?><span class="sa-badge info"><?= e( $c['poids'] ) ?> kg</span><?php endif; ?>
						<?php if ( $c['temperature'] ) : ?><span class="sa-badge <?= (float) $c['temperature'] >= 38 ? 'err' : 'info' ?>"><?= e( $c['temperature'] ) ?> °C</span><?php endif; ?>
					</div>
				<?php endif; ?>
				<?php $pr = $prescriptions[ (int) $c['id'] ] ?? array(); ?>
				<?php if ( $pr ) : ?>
					<div style="margin-top:6px;font-size:13px"><strong>Ordonnance :</strong> <a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/dme/' . (int) $p['id'] . '/ordonnance/' . (int) $c['id'] ) ) ?>">🖨️ Imprimer</a>
						<ul style="margin:4px 0 0;padding-left:18px"><?php foreach ( $pr as $x ) : ?><li><?= e( $x['medicament'] ) ?><?= $x['posologie'] ? ' — ' . e( $x['posologie'] ) : '' ?><?= $x['duree'] ? ' (' . e( $x['duree'] ) . ')' : '' ?></li><?php endforeach; ?></ul>
					</div>
				<?php endif; ?>
				<details style="margin-top:6px"><summary class="btn btn-ghost btn-sm" style="display:inline-block">＋ Prescrire</summary>
					<form method="post" action="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>" style="display:flex;gap:6px;align-items:end;margin-top:6px;flex-wrap:wrap"><?= FKC_Csrf::field() ?>
						<input type="hidden" name="action" value="prescription"><input type="hidden" name="consultation_id" value="<?= (int) $c['id'] ?>">
						<input name="medicament" placeholder="Médicament" required style="flex:2">
						<input name="posologie" placeholder="Posologie" style="flex:1">
						<input name="duree" placeholder="Durée" style="flex:1">
						<button class="btn btn-sm">Ajouter</button>
					</form>
					<div class="muted" style="font-size:11px;margin-top:2px">Le médicament (marque ou molécule) est croisé avec les allergies du patient et ses prescriptions des 30 derniers jours (interactions).</div>
				</details>
			</div>
		<?php endforeach; endif; ?>
	</div>

	<div>
		<?php if ( $facturation ) : ?>
		<div class="card" style="margin-bottom:16px">
			<div class="card-head"><h2>🧾 Facturation</h2></div>
			<div class="card-body">
				<div style="font-size:13px;margin-bottom:6px">Total facturé (10 dernières) : <strong><?= fkc_money( $facturation['total'] ) ?> F</strong></div>
				<?php foreach ( $facturation['pieces'] as $pc ) : ?>
					<div style="display:flex;justify-content:space-between;gap:6px;font-size:12.5px;padding:3px 0;border-bottom:1px dashed var(--border)">
						<span><?= e( date( 'd/m/Y', strtotime( $pc['date_piece'] ) ) ) ?> · <?= e( $pc['libelle'] ) ?></span>
						<span class="sa-badge <?= 'comptabilisee' === $pc['statut'] ? 'ok' : 'warn' ?>"><?= e( $stPiece[ $pc['statut'] ] ?? $pc['statut'] ) ?></span>
					</div>
				<?php endforeach; ?>
				<a class="btn btn-ghost btn-sm" style="margin-top:8px" href="<?= e( url( $module . '/dossiers/' . (int) $facturation['dossier_id'] ) ) ?>">Ouvrir le dossier de facturation</a>
			</div>
		</div>
		<?php endif; ?>
		<div class="card" style="margin-bottom:16px">
			<div class="card-head"><h2>🚨 Allergies</h2></div>
			<div class="card-body">
				<?php if ( ! $allergies ) : ?><p class="muted" style="font-size:13px">Aucune allergie connue.</p>
				<?php else : foreach ( $allergies as $a ) : ?>
					<div style="font-size:13px;margin-bottom:4px"><span style="color:<?= $sevBadge[ $a['severite'] ] ?? 'var(--text)' ?>">●</span> <strong><?= e( $a['substance'] ) ?></strong> <span class="muted">(<?= e( $a['severite'] ) ?>)</span></div>
				<?php endforeach; endif; ?>
				<form method="post" action="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>" style="margin-top:8px"><?= FKC_Csrf::field() ?>
					<input type="hidden" name="action" value="allergie">
					<div style="display:flex;gap:6px"><input name="substance" placeholder="Substance" required style="flex:2"><select name="severite" style="flex:1"><option value="legere">Légère</option><option value="moderee" selected>Modérée</option><option value="severe">Sévère</option></select></div>
					<button class="btn btn-sm" style="margin-top:6px">Ajouter</button>
				</form>
			</div>
		</div>
		<div class="card">
			<div class="card-head"><h2>📋 Antécédents</h2></div>
			<div class="card-body">
				<?php if ( ! $antecedents ) : ?><p class="muted" style="font-size:13px">Aucun antécédent.</p>
				<?php else : foreach ( $antecedents as $a ) : ?>
					<div style="font-size:13px;margin-bottom:4px"><span class="tag"><?= e( $typeAnt[ $a['type'] ] ?? $a['type'] ) ?></span> <?= e( $a['libelle'] ) ?><?= $a['depuis'] ? ' <span class="muted">(' . e( $a['depuis'] ) . ')</span>' : '' ?></div>
				<?php endforeach; endif; ?>
				<form method="post" action="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>" style="margin-top:8px"><?= FKC_Csrf::field() ?>
					<input type="hidden" name="action" value="antecedent">
					<div style="display:flex;gap:6px"><select name="type" style="flex:1"><option value="chronique">Chronique</option><option value="chirurgical">Chirurgical</option><option value="familial">Familial</option><option value="autre">Autre</option></select><input name="libelle" placeholder="Libellé" required style="flex:2"></div>
					<button class="btn btn-sm" style="margin-top:6px">Ajouter</button>
				</form>
			</div>
		</div>
		<?php if ( ! empty( $acces ) ) : ?>
		<div class="card" style="margin-top:16px">
			<div class="card-head"><h2>🔐 Journal d'accès</h2></div>
			<div class="card-body" style="font-size:12.5px">
				<?php foreach ( $acces as $x ) : ?>
					<div style="display:flex;justify-content:space-between;gap:6px;padding:3px 0;border-bottom:1px dashed var(--border)"><span><?= e( $x['utilisateur'] ) ?> · <?= e( $x['action'] ) ?></span><span class="muted"><?= e( substr( (string) $x['at'], 0, 16 ) ) ?></span></div>
				<?php endforeach; ?>
				<p class="muted" style="margin-top:6px;font-size:11.5px">Secret médical : chaque ouverture et chaque saisie est tracée.</p>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
