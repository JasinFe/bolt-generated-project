<?php /** @var string $module @var array $p @var int|null $age @var array $c @var array $lignes @var string $etablissement */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
?>
<div class="sa-noprint" style="display:flex;gap:8px;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap">
	<a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/dme/' . (int) $p['id'] ) ) ?>">← Dossier médical</a>
	<button class="btn btn-primary btn-sm" type="button" onclick="window.print()">🖨️ Imprimer l'ordonnance</button>
</div>
<article class="sa-rx">
	<div class="en-tete">
		<div>
			<h1><?= e( $c['praticien'] ?: 'Praticien' ) ?></h1>
			<div><?= e( $c['specialite'] ?? '' ) ?></div>
			<div style="font-size:13px;color:#555"><?= e( $etablissement ) ?></div>
		</div>
		<div style="text-align:right;font-size:13px">
			Le <?= e( date( 'd/m/Y', strtotime( (string) $c['date_consult'] ) ) ) ?><br>
			<strong><?= e( $p['nom'] ) ?></strong><?= null !== $age ? ', ' . (int) $age . ' ans' : '' ?><br>
			<?= e( $p['code'] ) ?>
		</div>
	</div>
	<h2 style="font-size:16px;margin:0 0 10px">Ordonnance</h2>
	<?php if ( ! $lignes ) : ?>
		<p class="muted">Aucune prescription pour cette consultation.</p>
	<?php else : ?>
	<ol>
		<?php foreach ( $lignes as $l ) : ?>
			<li><strong><?= e( $l['medicament'] ) ?></strong><?= $l['posologie'] ? '<br>' . e( $l['posologie'] ) : '' ?><?= $l['duree'] ? ' — pendant ' . e( $l['duree'] ) : '' ?></li>
		<?php endforeach; ?>
	</ol>
	<?php endif; ?>
	<div class="sign">Signature et cachet</div>
</article>
