<?php /** @var string $module @var array $praticiens @var string $mois @var array $bordereau @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'praticiens' ) );
$totRetro = 0; $totHono = 0; $totConst = 0; $nb = 0;
foreach ( $bordereau as $l ) { $totRetro += $l['retrocession']; $totHono += $l['honoraires']; $totConst += $l['constate'] ?? 0; $nb += $l['nb']; }
$reste = max( 0, $totRetro - $totConst );
$actifs = count( array_filter( $praticiens, fn( $p ) => ! empty( $p['actif'] ) ) );
?>
<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>" role="status"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="sa-kpis">
	<div class="sa-kpi"><div class="l">Honoraires du mois</div><div class="v"><?= fkc_money( $totHono ) ?> F</div><div class="s"><?= (int) $nb ?> consultation(s) facturée(s)</div></div>
	<div class="sa-kpi" style="--sa-c:var(--orange)"><div class="l">Rétrocessions dues</div><div class="v"><?= fkc_money( $totRetro ) ?> F</div><div class="s">part des praticiens</div></div>
	<div class="sa-kpi" style="--sa-c:<?= $reste > 0 ? 'var(--warn)' : 'var(--ok)' ?>"><div class="l">À constater en compta</div><div class="v"><?= fkc_money( $reste ) ?> F</div><div class="s"><?= fkc_money( $totConst ) ?> F déjà passés</div></div>
	<div class="sa-kpi" style="--sa-c:var(--ok)"><div class="l">Net établissement</div><div class="v"><?= fkc_money( $totHono - $totRetro ) ?> F</div><div class="s"><?= (int) $actifs ?> praticien(s) actif(s)</div></div>
</div>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
		<h2>🩺 Bordereau de rétrocessions</h2>
		<div style="display:flex;gap:8px;flex-wrap:wrap">
			<form method="get" action="<?= e( url( $module . '/praticiens' ) ) ?>" style="display:flex;gap:8px;align-items:center">
				<input type="month" name="mois" value="<?= e( $mois ) ?>" aria-label="Mois">
				<button class="btn btn-ghost btn-sm" type="submit">Afficher</button>
			</form>
			<?php if ( $reste >= 1 ) : ?>
			<form method="post" action="<?= e( url( $module . '/praticiens/retrocessions' ) ) ?>" onsubmit="return confirm('Constater <?= e( fkc_money( $reste ) ) ?> F de rétrocessions pour <?= e( $mois ) ?> (632460 / 401140) ?');">
				<?= FKC_Csrf::field() ?><input type="hidden" name="mois" value="<?= e( $mois ) ?>">
				<button class="btn btn-primary btn-sm" type="submit">📒 Comptabiliser le bordereau</button>
			</form>
			<?php endif; ?>
		</div>
	</div>
	<div class="card-body">
		<p class="sa-help">Part des honoraires de consultation à reverser à chaque praticien — calculée sur les consultations facturées du planning. « Comptabiliser » constate la charge (632460) et la dette envers le praticien (401140, tiers fournisseur réglable depuis Règlements) ; un complément est passé si le mois s'enrichit ensuite.</p>
		<div class="sa-table-wrap"><table class="table">
			<thead><tr><th>Praticien</th><th>Spécialité</th><th class="sa-right">Consult.</th><th class="sa-right">Honoraires</th><th class="sa-right">Taux</th><th class="sa-right">À reverser</th><th class="sa-right">Constaté</th><th class="sa-right">Net établissement</th></tr></thead>
			<tbody>
			<?php if ( ! $bordereau ) : ?><tr><td colspan="8" class="empty">Aucun praticien.</td></tr><?php endif; ?>
			<?php foreach ( $bordereau as $l ) : $c = (float) ( $l['constate'] ?? 0 ); ?>
				<tr>
					<td><strong><?= e( $l['praticien'] ) ?></strong></td>
					<td class="muted"><?= e( $l['specialite'] ) ?></td>
					<td class="sa-right"><?= (int) $l['nb'] ?></td>
					<td class="sa-right"><?= fkc_money( $l['honoraires'] ) ?> F</td>
					<td class="sa-right"><?= e( $l['taux'] ) ?> %</td>
					<td class="sa-right" style="font-weight:700;color:var(--orange)"><?= fkc_money( $l['retrocession'] ) ?> F</td>
					<td class="sa-right"><?php if ( $l['retrocession'] <= 0 ) : ?>—<?php elseif ( $c + 1 > $l['retrocession'] ) : ?><span class="sa-badge ok">✓ passé</span><?php else : ?><span class="sa-badge warn"><?= fkc_money( $c ) ?> F</span><?php endif; ?></td>
					<td class="sa-right" style="color:var(--ok)"><?= fkc_money( $l['net_etablissement'] ) ?> F</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot><tr style="font-weight:700"><td colspan="3">Total</td><td class="sa-right"><?= fkc_money( $totHono ) ?> F</td><td></td><td class="sa-right" style="color:var(--orange)"><?= fkc_money( $totRetro ) ?> F</td><td class="sa-right"><?= fkc_money( $totConst ) ?> F</td><td class="sa-right" style="color:var(--ok)"><?= fkc_money( $totHono - $totRetro ) ?> F</td></tr></tfoot>
		</table></div>
	</div>
</div>

<div class="sa-grid2" style="margin-top:18px">
	<div class="card card-flush">
		<div class="card-head"><h2>👨‍⚕️ Équipe soignante</h2></div>
		<div class="card-body">
			<?php if ( ! $praticiens ) : ?><div class="empty">Aucun praticien enregistré.</div><?php endif; ?>
			<?php foreach ( $praticiens as $p ) : ?>
				<details style="border-bottom:1px solid var(--border);padding:8px 0">
					<summary style="cursor:pointer;display:flex;justify-content:space-between;gap:8px;align-items:center">
						<span><strong><?= e( $p['nom'] ) ?></strong> <span class="muted" style="font-size:12px"><?= e( $p['specialite'] ) ?></span></span>
						<span><span class="sa-badge"><?= fkc_money( $p['tarif_consultation'] ) ?> F · <?= e( $p['taux_retrocession'] ) ?> %</span> <?php if ( empty( $p['actif'] ) ) : ?><span class="sa-badge err">inactif</span><?php endif; ?></span>
					</summary>
					<form method="post" action="<?= e( url( $module . '/praticiens/' . (int) $p['id'] ) ) ?>" class="sa-form" style="margin-top:8px">
						<?= FKC_Csrf::field() ?>
						<label class="fld"><span>Spécialité</span><input name="specialite" value="<?= e( $p['specialite'] ) ?>"></label>
						<label class="fld"><span>Tarif (F)</span><input type="number" name="tarif_consultation" min="0" step="500" value="<?= e( (float) $p['tarif_consultation'] ) ?>"></label>
						<label class="fld"><span>Rétrocession (%)</span><input type="number" name="taux_retrocession" min="0" max="100" step="1" value="<?= e( (float) $p['taux_retrocession'] ) ?>"></label>
						<label class="fld"><span>Créneau (min)</span><input type="number" name="duree_creneau" min="5" max="240" step="5" value="<?= (int) ( $p['duree_creneau'] ?? 20 ) ?>"></label>
						<label class="fld"><span>Statut</span><select name="actif"><option value="1" <?= ! empty( $p['actif'] ) ? 'selected' : '' ?>>Actif</option><option value="0" <?= empty( $p['actif'] ) ? 'selected' : '' ?>>Inactif</option></select></label>
						<button class="btn btn-sm" type="submit">Mettre à jour</button>
					</form>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
	<div class="card card-flush">
		<div class="card-head"><h2>➕ Nouveau praticien</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url( $module . '/praticiens/creer' ) ) ?>" class="sa-form">
				<?= FKC_Csrf::field() ?>
				<label class="fld"><span>Nom</span><input name="nom" required placeholder="Dr Kouassi"></label>
				<label class="fld"><span>Spécialité</span><input name="specialite" placeholder="Généraliste"></label>
				<label class="fld"><span>Tarif consultation (F)</span><input type="number" name="tarif_consultation" min="0" step="500" value="10000"></label>
				<label class="fld"><span>Taux de rétrocession (%)</span><input type="number" name="taux_retrocession" min="0" max="100" step="1" value="50"></label>
				<label class="fld"><span>Créneau (min)</span><input type="number" name="duree_creneau" min="5" max="240" step="5" value="20"></label>
				<button class="btn btn-primary" type="submit">Enregistrer</button>
			</form>
			<p class="sa-help" style="margin-top:10px">💡 Le taux de rétrocession est la part des honoraires reversée au praticien (usuellement 40 à 60&nbsp;%). Le reste constitue la marge de l'établissement.</p>
		</div>
	</div>
</div>
