<?php /** @var string $module @var string $mois @var array $assureurs @var int $assureurId @var array $bordereau @var array $conventions @var array $rejets @var array $types @var bool $imprimer @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'assurances' ) );
$courant = null;
foreach ( $assureurs as $a ) { if ( (int) $a['id'] === (int) $assureurId ) { $courant = $a; } }
$lignes = $bordereau['lignes'];
$tot = array( 'ttc' => 0, 'pec' => 0, 'rej' => 0, 'du' => 0, 'hors' => 0 );
foreach ( $lignes as $l ) { $tot['ttc'] += $l['ttc']; $tot['pec'] += $l['montant']; $tot['rej'] += $l['rejete']; $tot['du'] += $l['du']; if ( $l['hors_delai'] ) { $tot['hors']++; } }
$totSolde = array_sum( array_map( fn( $a ) => (float) $a['solde'], $assureurs ) );
?>
<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>" role="status"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="sa-kpis">
	<div class="sa-kpi" style="--sa-c:var(--blue)"><div class="l">Créances tiers payant</div><div class="v"><?= fkc_money( $totSolde ) ?> F</div><div class="s"><?= count( $assureurs ) ?> organisme(s) · grand livre 411116</div></div>
	<div class="sa-kpi"><div class="l">Bordereau <?= e( $mois ) ?></div><div class="v"><?= fkc_money( $tot['du'] ) ?> F</div><div class="s"><?= count( $lignes ) ?> pièce(s) · <?= e( $courant['nom'] ?? '—' ) ?></div></div>
	<div class="sa-kpi" style="--sa-c:var(--danger)"><div class="l">Rejeté</div><div class="v"><?= fkc_money( $tot['rej'] ) ?> F</div><div class="s">sur le mois affiché</div></div>
	<div class="sa-kpi" style="--sa-c:<?= $tot['hors'] ? 'var(--warn)' : 'var(--ok)' ?>"><div class="l">Hors délai de production</div><div class="v"><?= (int) $tot['hors'] ?></div><div class="s"><?= $bordereau['delai'] ? 'délai ' . (int) $bordereau['delai'] . ' j' : 'délai non renseigné' ?></div></div>
</div>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
		<h2>🏦 Bordereau de tiers payant</h2>
		<form method="get" action="<?= e( url( $module . '/assurances' ) ) ?>" class="sa-noprint" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
			<select name="assureur" aria-label="Assureur"><?php foreach ( $assureurs as $a ) : ?><option value="<?= (int) $a['id'] ?>" <?= (int) $a['id'] === (int) $assureurId ? 'selected' : '' ?>><?= e( $a['nom'] ) ?> (<?= fkc_money( $a['solde'] ) ?> F)</option><?php endforeach; ?></select>
			<input type="month" name="mois" value="<?= e( $mois ) ?>" aria-label="Mois">
			<button class="btn btn-ghost btn-sm" type="submit">Afficher</button>
			<button class="btn btn-ghost btn-sm" type="button" onclick="window.print()">🖨️ Imprimer</button>
		</form>
	</div>
	<div class="card-body">
		<?php if ( ! $assureurs ) : ?>
			<div class="empty">Aucun organisme payeur : renseignez « Assurance / mutuelle » et son taux dans un dossier patient, ou déclarez une convention ci-dessous.</div>
		<?php else : ?>
		<p class="sa-help">Pièces comptabilisées du mois prises en charge par <strong><?= e( $courant['nom'] ?? '' ) ?></strong>. Le rejet (total ou partiel) remet le montant à la charge du patient ou le passe en pertes (651100) ; la créance de l'assureur est diminuée d'autant.</p>
		<div class="sa-table-wrap"><table class="table">
			<thead><tr><th>Date</th><th>Pièce</th><th>Patient</th><th class="sa-right">Facture TTC</th><th class="sa-right">Prise en charge</th><th class="sa-right">Rejeté</th><th class="sa-right">Dû</th><th>Âge</th><th class="sa-noprint"></th></tr></thead>
			<tbody>
			<?php if ( ! $lignes ) : ?><tr><td colspan="9" class="empty">Aucune prise en charge ce mois.</td></tr><?php endif; ?>
			<?php foreach ( $lignes as $l ) : ?>
				<tr>
					<td><?= e( date( 'd/m/Y', strtotime( $l['date_piece'] ) ) ) ?></td>
					<td><code style="font-size:12px"><?= e( $l['dossier'] ) ?></code> <?= e( $types[ $l['type'] ]['label'] ?? $l['type'] ) ?> n°<?= (int) $l['numero'] ?></td>
					<td><?= e( $l['patient_nom'] ?: '—' ) ?></td>
					<td class="sa-right"><?= fkc_money( $l['ttc'] ) ?></td>
					<td class="sa-right"><?= fkc_money( $l['montant'] ) ?></td>
					<td class="sa-right"><?= (float) $l['rejete'] > 0 ? '<span class="sa-badge err">' . fkc_money( $l['rejete'] ) . '</span>' : '—' ?></td>
					<td class="sa-right"><strong><?= fkc_money( $l['du'] ) ?></strong></td>
					<td><span class="sa-badge <?= $l['hors_delai'] ? 'warn' : '' ?>"><?= (int) $l['age'] ?> j<?= $l['hors_delai'] ? ' · hors délai' : '' ?></span></td>
					<td class="sa-noprint" style="text-align:right">
						<?php if ( $l['du'] > 0 ) : ?>
						<details><summary class="btn btn-ghost btn-sm">Rejet</summary>
							<form method="post" action="<?= e( url( $module . '/assurances' ) ) ?>" class="sa-form" style="margin-top:6px;min-width:260px">
								<?= FKC_Csrf::field() ?>
								<input type="hidden" name="action" value="rejet"><input type="hidden" name="pec_id" value="<?= (int) $l['id'] ?>">
								<input type="hidden" name="mois" value="<?= e( $mois ) ?>"><input type="hidden" name="assureur_id" value="<?= (int) $assureurId ?>">
								<label class="fld"><span>Montant</span><input class="num" name="montant" value="<?= e( $l['du'] ) ?>"></label>
								<label class="fld"><span>Motif</span><input name="motif" required placeholder="Acte non couvert…"></label>
								<label class="fld"><span>Imputation</span><select name="imputation"><option value="patient">À la charge du patient</option><option value="perte">Abandon (perte)</option></select></label>
								<button class="btn btn-sm" type="submit">Enregistrer</button>
							</form>
						</details>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<?php if ( $lignes ) : ?>
			<tfoot><tr style="font-weight:700"><td colspan="3">Total du bordereau</td><td class="sa-right"><?= fkc_money( $tot['ttc'] ) ?></td><td class="sa-right"><?= fkc_money( $tot['pec'] ) ?></td><td class="sa-right"><?= fkc_money( $tot['rej'] ) ?></td><td class="sa-right"><?= fkc_money( $tot['du'] ) ?> F</td><td colspan="2"></td></tr></tfoot>
			<?php endif; ?>
		</table></div>
		<?php endif; ?>
	</div>
</div>

<div class="sa-grid2 sa-noprint" style="margin-top:18px">
	<div class="card card-flush">
		<div class="card-head"><h2>📜 Conventions</h2></div>
		<div class="card-body">
			<p class="sa-help">La convention prime sur le taux du dossier : taux par nature de pièce (vide = toutes), franchise laissée au patient sur chaque acte, plafond annuel par assuré, délai de production.</p>
			<div class="sa-table-wrap"><table class="table">
				<thead><tr><th>Assureur</th><th>Nature</th><th class="sa-right">Taux</th><th class="sa-right">Franchise</th><th class="sa-right">Plafond / an</th><th class="sa-right">Délai</th><th></th></tr></thead>
				<tbody>
				<?php if ( ! $conventions ) : ?><tr><td colspan="7" class="empty">Aucune convention : le taux du dossier s'applique.</td></tr><?php endif; ?>
				<?php foreach ( $conventions as $c ) : ?>
					<tr>
						<td><?= e( $c['assureur'] ) ?></td>
						<td><?= '' === $c['type_piece'] ? '<span class="muted">toutes</span>' : e( $types[ $c['type_piece'] ]['label'] ?? $c['type_piece'] ) ?></td>
						<td class="sa-right"><?= e( (float) $c['taux'] ) ?> %</td>
						<td class="sa-right"><?= (float) $c['franchise'] > 0 ? fkc_money( $c['franchise'] ) . ' F' : '—' ?></td>
						<td class="sa-right"><?= (float) $c['plafond_annuel'] > 0 ? fkc_money( $c['plafond_annuel'] ) . ' F' : '—' ?></td>
						<td class="sa-right"><?= (int) $c['delai_jours'] > 0 ? (int) $c['delai_jours'] . ' j' : '—' ?></td>
						<td style="text-align:right"><form method="post" action="<?= e( url( $module . '/assurances' ) ) ?>" onsubmit="return confirm('Supprimer cette convention ?');"><?= FKC_Csrf::field() ?><input type="hidden" name="action" value="supprimer_convention"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><button class="btn btn-ghost btn-sm" type="submit">✕</button></form></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		</div>
	</div>
	<div class="card card-flush">
		<div class="card-head"><h2>➕ Déclarer une convention</h2></div>
		<div class="card-body">
			<form method="post" action="<?= e( url( $module . '/assurances' ) ) ?>" class="sa-form">
				<?= FKC_Csrf::field() ?><input type="hidden" name="action" value="convention">
				<label class="fld"><span>Assureur</span><input name="assureur" list="sa-assureurs" required placeholder="MUGEFCI, CNAM…">
					<datalist id="sa-assureurs"><?php foreach ( $assureurs as $a ) : ?><option value="<?= e( $a['nom'] ) ?>"><?php endforeach; ?></datalist></label>
				<label class="fld"><span>Nature de pièce</span><select name="type_piece"><option value="">Toutes</option><?php foreach ( $types as $k => $t ) : ?><option value="<?= e( $k ) ?>"><?= e( $t['label'] ?? $k ) ?></option><?php endforeach; ?></select></label>
				<label class="fld"><span>Taux (%)</span><input type="number" name="taux" min="0" max="100" step="1" value="80"></label>
				<label class="fld"><span>Franchise par acte (F)</span><input type="number" name="franchise" min="0" step="100" value="0"></label>
				<label class="fld"><span>Plafond annuel (F)</span><input type="number" name="plafond_annuel" min="0" step="1000" value="0"></label>
				<label class="fld"><span>Délai de production (j)</span><input type="number" name="delai_jours" min="0" step="1" value="90"></label>
				<button class="btn btn-primary" type="submit">Enregistrer</button>
			</form>
		</div>
	</div>
</div>

<?php if ( $rejets ) : ?>
<div class="card card-flush sa-noprint" style="margin-top:18px">
	<div class="card-head"><h2>⛔ Derniers rejets</h2></div>
	<div class="sa-table-wrap"><table class="table">
		<thead><tr><th>Date</th><th>Pièce</th><th class="sa-right">Montant</th><th>Motif</th><th>Imputation</th></tr></thead>
		<tbody>
		<?php foreach ( $rejets as $r ) : ?>
			<tr><td><?= e( substr( (string) $r['created_at'], 0, 10 ) ) ?></td><td>#<?= (int) $r['piece_id'] ?></td><td class="sa-right"><?= fkc_money( $r['montant'] ) ?> F</td><td><?= e( $r['motif'] ) ?></td><td><span class="sa-badge <?= 'perte' === $r['imputation'] ? 'err' : 'warn' ?>"><?= 'perte' === $r['imputation'] ? 'Perte (651100)' : 'Patient' ?></span></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table></div>
</div>
<?php endif; ?>
