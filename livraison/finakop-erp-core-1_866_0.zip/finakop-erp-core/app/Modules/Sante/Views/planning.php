<?php /** @var string $module @var string $date @var string $lundi @var array $rdvs @var array $semaine @var array $praticiens @var array $compteurs @var string $typePiece @var int $praticienFiltre @var array $rappels @var float $tauxAbsence @var string $etablissement @var array|null $flash */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
FKC_View::partial( '_modnav', array( 'module' => $module, 'back' => $module, 'backLabel' => 'Tableau de bord' ) );
FKC_View::partial( 'sante::_santenav', array( 'module' => $module, 'actif' => 'planning' ) );
$statuts = array( 'prevu' => array( 'Prévu', 'info' ), 'honore' => array( 'Facturé', 'ok' ), 'annule' => array( 'Annulé', '' ), 'absent' => array( 'Non honoré', 'err' ) );
$jours = array( 'lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim' );
$parJour = array();
foreach ( $semaine as $r ) { if ( 'annule' !== $r['statut'] ) { $parJour[ $r['date'] ] = ( $parJour[ $r['date'] ] ?? 0 ) + 1; } }
$typeLbl = (string) ( ( FKC_Packs::verticalConfig()['pieces'][ $typePiece ]['label'] ?? '' ) ?: $typePiece );
$aujourdhui = date( 'Y-m-d' );
?>
<?php if ( $flash ) : ?><div class="alert <?= $flash['ok'] ? 'alert-ok' : 'alert-err' ?>" role="status"><?= e( $flash['msg'] ) ?></div><?php endif; ?>

<div class="sa-kpis">
	<div class="sa-kpi"><div class="l">Consultations du jour</div><div class="v"><?= (int) $compteurs['actifs'] ?></div><div class="s"><?= (int) $compteurs['prevu'] ?> à venir</div></div>
	<div class="sa-kpi" style="--sa-c:var(--ok)"><div class="l">Facturées</div><div class="v"><?= (int) $compteurs['honore'] ?></div><div class="s"><?= fkc_money( $compteurs['facture'] ?? 0 ) ?> F</div></div>
	<div class="sa-kpi" style="--sa-c:<?= $tauxAbsence > 15 ? 'var(--danger)' : 'var(--muted2)' ?>"><div class="l">Non honorés (90 j)</div><div class="v"><?= e( $tauxAbsence ) ?> %</div><div class="s"><?= (int) $compteurs['absent'] ?> absent(s), <?= (int) $compteurs['annule'] ?> annulé(s) ce jour</div></div>
	<div class="sa-kpi" style="--sa-c:var(--blue)"><div class="l">Praticiens actifs</div><div class="v"><?= count( $praticiens ) ?></div><div class="s">pièce émise : <?= e( $typeLbl ) ?></div></div>
</div>

<div class="card card-flush">
	<div class="card-head" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
		<h2>🗓️ Planning — <?= e( date( 'd/m/Y', strtotime( $date ) ) ) ?></h2>
		<form method="get" action="<?= e( url( $module . '/planning' ) ) ?>" style="display:flex;gap:8px;align-items:center">
			<a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/planning?date=' . date( 'Y-m-d', strtotime( $lundi . ' -7 day' ) ) ) ) ?>" aria-label="Semaine précédente">‹</a>
			<input type="date" name="date" value="<?= e( $date ) ?>" aria-label="Jour affiché">
			<select name="praticien" aria-label="Agenda du praticien"><option value="0">Tous les praticiens</option><?php foreach ( $praticiens as $pp ) : ?><option value="<?= (int) $pp['id'] ?>" <?= (int) $pp['id'] === (int) $praticienFiltre ? 'selected' : '' ?>><?= e( $pp['nom'] ) ?></option><?php endforeach; ?></select>
			<button class="btn btn-ghost btn-sm" type="submit">Afficher</button>
			<a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/planning?date=' . date( 'Y-m-d', strtotime( $lundi . ' +7 day' ) ) ) ) ?>" aria-label="Semaine suivante">›</a>
			<?php if ( $date !== $aujourdhui ) : ?><a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/planning' ) ) ?>">Aujourd'hui</a><?php endif; ?>
		</form>
	</div>
	<div class="card-body">
		<div class="sa-week">
			<?php for ( $i = 0; $i < 7; $i++ ) : $j = date( 'Y-m-d', strtotime( $lundi . ' +' . $i . ' day' ) ); ?>
				<a href="<?= e( url( $module . '/planning?date=' . $j ) ) ?>" class="<?= $j === $date ? 'on' : '' ?>">
					<div class="j"><?= e( $jours[ $i ] ) ?><?= $j === $aujourdhui ? ' •' : '' ?></div>
					<div class="d"><?= (int) substr( $j, 8, 2 ) ?></div>
					<div class="n"><?= (int) ( $parJour[ $j ] ?? 0 ) ?> RDV</div>
				</a>
			<?php endfor; ?>
		</div>
		<?php if ( ! $rdvs ) : ?>
			<div class="empty">Aucun rendez-vous ce jour.</div>
		<?php else : ?>
		<div class="sa-table-wrap"><table class="table">
			<thead><tr><th>Heure</th><th>Praticien</th><th>Patient</th><th>Motif</th><th class="sa-right">Montant</th><th>Statut</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $rdvs as $r ) : $st = $statuts[ $r['statut'] ] ?? array( $r['statut'], '' ); ?>
				<tr<?= 'annule' === $r['statut'] ? ' style="opacity:.55"' : '' ?>>
					<td><strong><?= e( $r['heure'] ) ?></strong> <span class="muted" style="font-size:11px"><?= (int) ( $r['duree'] ?? 20 ) ?> min</span></td>
					<td><?= e( $r['praticien'] ) ?> <span class="muted" style="font-size:11px"><?= e( $r['specialite'] ) ?></span></td>
					<td><?= e( $r['patient'] ) ?></td>
					<td class="muted"><?= e( $r['motif'] ) ?></td>
					<td class="sa-right"><?= fkc_money( $r['montant'] ) ?> F</td>
					<td><span class="sa-badge <?= e( $st[1] ) ?>"><?= e( $st[0] ) ?></span></td>
					<td style="text-align:right;white-space:nowrap">
						<?php if ( 'prevu' === $r['statut'] ) : ?>
							<?php if ( $r['date'] <= $aujourdhui ) : ?>
							<form method="post" action="<?= e( url( $module . '/planning/rdv/' . (int) $r['id'] . '/facturer' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-primary btn-sm" type="submit">Facturer</button></form>
							<?php endif; ?>
							<?php if ( $r['date'] <= $aujourdhui ) : ?>
							<form method="post" action="<?= e( url( $module . '/planning/rdv/' . (int) $r['id'] . '/absent' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit" title="Patient non venu">Absent</button></form>
							<?php endif; ?>
							<form method="post" action="<?= e( url( $module . '/planning/rdv/' . (int) $r['id'] . '/annuler' ) ) ?>" style="display:inline" onsubmit="return confirm('Annuler ce rendez-vous ?');"><?= FKC_Csrf::field() ?><button class="btn btn-ghost btn-sm" type="submit">Annuler</button></form>
						<?php elseif ( 'honore' === $r['statut'] && ! empty( $r['dossier_id'] ) ) : ?>
							<a class="btn btn-ghost btn-sm" href="<?= e( url( $module . '/dossiers/' . (int) $r['dossier_id'] ) ) ?>">Dossier</a>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<?php endif; ?>
		<p class="sa-help" style="margin-top:10px">Facturer une consultation émet une pièce « <?= e( $typeLbl ) ?> » à la date du rendez-vous, dans le dossier du patient (retrouvé par son nom ou ouvert), puis la valide : l'écriture part en comptabilité, la part assurance sur l'organisme payeur, et la rétrocession du praticien s'alimente.</p>
	</div>
</div>

<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>➕ Nouveau rendez-vous</h2></div>
	<div class="card-body">
		<?php if ( ! $praticiens ) : ?>
			<div class="alert alert-warn">Aucun praticien actif — <a href="<?= e( url( $module . '/praticiens' ) ) ?>">créer un praticien</a> d'abord.</div>
		<?php else : ?>
		<form method="post" action="<?= e( url( $module . '/planning/rdv' ) ) ?>" class="sa-form">
			<?= FKC_Csrf::field() ?>
			<label class="fld"><span>Praticien</span><select name="praticien_id"><?php foreach ( $praticiens as $p ) : ?><option value="<?= (int) $p['id'] ?>"><?= e( $p['nom'] ) ?><?= $p['specialite'] ? ' — ' . e( $p['specialite'] ) : '' ?> (<?= fkc_money( $p['tarif_consultation'] ) ?> F)</option><?php endforeach; ?></select></label>
			<label class="fld"><span>Patient</span><input name="patient" required autocomplete="off"></label>
			<label class="fld"><span>Date</span><input type="date" name="date" value="<?= e( $date ) ?>" required></label>
			<label class="fld"><span>Heure</span><input type="time" name="heure" value="08:00" step="300" required></label>
			<label class="fld"><span>Durée (min) — vide = créneau du praticien</span><input type="number" name="duree" min="5" max="240" step="5"></label>
			<label class="fld"><span>Téléphone (rappel)</span><input name="telephone" inputmode="tel" placeholder="+225 07 00 00 00"></label>
			<label class="fld"><span>Motif</span><input name="motif"></label>
			<label class="fld"><span>Montant (F) — vide = tarif</span><input type="number" name="montant" min="0" step="500"></label>
			<button class="btn btn-primary" type="submit">Planifier</button>
		</form>
		<?php endif; ?>
	</div>
</div>

<div class="card card-flush" style="margin-top:18px">
	<div class="card-head"><h2>📨 Rappels de demain</h2></div>
	<div class="card-body">
		<p class="sa-help">Un rappel la veille coûte moins cher qu'une place perdue. Le message part par WhatsApp ou SMS depuis le téléphone de l'accueil ; notez-le envoyé pour ne pas rappeler deux fois.</p>
		<?php if ( ! $rappels ) : ?><div class="empty">Aucun rendez-vous prévu demain.</div><?php else : ?>
		<div class="sa-table-wrap"><table class="table">
			<thead><tr><th>Heure</th><th>Patient</th><th>Praticien</th><th>Téléphone</th><th></th></tr></thead>
			<tbody>
			<?php foreach ( $rappels as $r ) :
				$msg = FKC_SantePlanning::messageRappel( $r, $etablissement );
				$tel = preg_replace( '/[^0-9]/', '', (string) ( $r['telephone'] ?? '' ) ); ?>
				<tr>
					<td><?= e( $r['heure'] ) ?></td><td><?= e( $r['patient'] ) ?></td><td class="muted"><?= e( $r['praticien'] ) ?></td>
					<td><?= $tel ? e( $r['telephone'] ) : '<span class="muted">non renseigné</span>' ?></td>
					<td style="text-align:right;white-space:nowrap">
						<?php if ( $tel ) : ?>
						<a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="https://wa.me/<?= e( $tel ) ?>?text=<?= e( rawurlencode( $msg ) ) ?>">WhatsApp</a>
						<a class="btn btn-ghost btn-sm" href="sms:<?= e( $tel ) ?>?body=<?= e( rawurlencode( $msg ) ) ?>">SMS</a>
						<?php endif; ?>
						<?php if ( empty( $r['rappel_at'] ) ) : ?>
						<form method="post" action="<?= e( url( $module . '/planning/rdv/' . (int) $r['id'] . '/rappel' ) ) ?>" style="display:inline"><?= FKC_Csrf::field() ?><button class="btn btn-sm" type="submit">✓ Envoyé</button></form>
						<?php else : ?><span class="sa-badge ok">rappelé</span><?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
		<?php endif; ?>
	</div>
</div>
