<?php /** Sous-navigation santé. @var string $module @var string $actif */
defined( 'FKC_ROOT' ) || die( 'Accès direct interdit.' );
$actif = $actif ?? '';
/*
 * 1.858.0 — seuls les écrans RÉELLEMENT ouverts au pack s'affichent. La barre
 * proposait « Hospitalisation » et « Dossiers » à un cabinet, un laboratoire
 * ou un opticien : deux liens morts sur quatre. Et « Dossiers » distingue
 * enfin le dossier MÉDICAL (DME) du dossier de FACTURATION.
 */
$liens = array(
	'dme'             => array( '🩺', 'Dossiers médicaux' ),
	'planning'        => array( '🗓️', 'Planning' ),
	'praticiens'      => array( '👨‍⚕️', 'Praticiens' ),
	'hospitalisation' => array( '🛏️', 'Hospitalisation' ),
	'assurances'      => array( '🏦', 'Assurances' ),
);
$ouvertes = class_exists( 'FKC_Router' ) && method_exists( 'FKC_Router', 'litterales' ) ? FKC_Router::litterales( 'GET' ) : array();
?>
<nav class="sa-nav" aria-label="Navigation santé">
	<?php foreach ( $liens as $k => $l ) :
		if ( $ouvertes && ! in_array( $module . '/' . $k, $ouvertes, true ) ) { continue; } ?>
		<a href="<?= e( url( $module . '/' . $k ) ) ?>" class="<?= $actif === $k ? 'on' : '' ?>"<?= $actif === $k ? ' aria-current="page"' : '' ?>><span aria-hidden="true"><?= $l[0] ?></span><?= e( $l[1] ) ?></a>
	<?php endforeach; ?>
	<span class="sa-nav-sep"></span>
	<a href="<?= e( url( $module . '/dossiers' ) ) ?>"><span aria-hidden="true">🧾</span>Facturation</a>
	<a href="<?= e( url( $module . '/pieces' ) ) ?>"><span aria-hidden="true">📄</span>Pièces</a>
</nav>
