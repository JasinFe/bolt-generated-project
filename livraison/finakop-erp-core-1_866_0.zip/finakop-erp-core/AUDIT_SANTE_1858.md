# Audit — Famille « Santé » (1.858.0)

Base analysée : 1.857.0. Périmètre : la famille `sante` — Cabinet médical, Clinique, Hôpital, Laboratoire, Optique, Pharmacie — et son socle commun (`Modules/Sante` : planning, praticiens et rétrocessions, hospitalisation, dossier médical électronique ; brique verticale : dossiers, pièces, schémas d'écritures), ainsi que ses ponts vers la comptabilité, les règlements, la caisse et le pilotage.

Test de non-régression : `tests/sante_1858.php` — 89 vérifications sur les 6 packs, dont un parcours par les écrans.

---

## 1. Socle commun — défauts corrigés

| # | Gravité | Défaut | Correction |
|---|---|---|---|
| S-1 | **Sécurité** | Les routes santé (planning, praticiens, lits, dossiers médicaux) ne portaient que le contrôle de licence : servies **sans session**, et sans société active la base interrogée était celle du cabinet. | `auth` + `societe` comme tout écran métier. |
| S-2 | **Critique** | Clinique/Hôpital : seul le GET `/dossiers/{id}` avait été arbitré. Le POST restait au moteur vertical : chaque antécédent, allergie, consultation ou prescription **écrasait le dossier de facturation** de même numéro (libellé vidé, champs effacés, statut « ouvert ») et le soin n'était jamais enregistré ; la création patient idem. En sens inverse, un lien vers un dossier de facturation ouvrait le **dossier médical d'un autre patient**. | Le DME a son chemin propre `{pack}/dme…` ; `/dossiers` redevient la facturation pour tous les packs. Liens, menus (`UxIntentions`), tableau de bord et assistant mis à jour. |
| S-3 | Majeur | Créance patient **sans tiers**, sur un 411 collectif (411115/411118…) que l'écran Règlements ne crédite jamais (il crédite le compte du client, 411100) : le 411 du pack grossissait, 411100 devenait créditeur, personne n'était relançable. | Le patient devient un client (compte patients du pack), rattaché au dossier à la première facture ; la créance porte son tiers, le règlement la solde sur le même compte. |
| S-4 | Majeur | **Tiers payant** déclaré par tous les manifestes (« Assurance / mutuelle »), jamais appliqué : 100 % à la charge du patient ; la pièce « convention » débitait… le patient. | Nouveau champ « Taux de prise en charge (%) ». Chaque facture se scinde : part patient (son compte, son tiers) / part assurance (411116, client organisme dédoublonné par nom). « Convention » = 100 % assureur. « Aucune », « néant », « — » = sans assurance. Moteur : `'tiers' => 'payeur'`. |
| S-5 | Majeur | Planning : type de pièce faux (cabinet → « Actes » 706167 au lieu de « Consultation » 706166 ; optique → **vente de montures** 701120 pour un examen de vue) ; pièce datée du jour de facturation et non du RDV ; **nouveau dossier (et bientôt nouveau client) à chaque consultation** ; double réservation d'un créneau acceptée ; heure non contrôlée ; « comptabilisée » annoncé même si la validation échouait (droits). | Type par métier (consultation / soins / actes / bilan / examen) ; date du RDV ; dossier existant du patient retrouvé ; créneau unique ; RDV à venir non facturable ; statut réel restitué. |
| S-6 | Moyen | Hospitalisation : un patient pouvait occuper deux lits ; lits en doublon ; dates non contrôlées ; nuitées calculées en secondes (heure d'été) ; séjour facturé dans un dossier neuf. | Contrôles, nuitées calendaires, dossier du patient, dates futures refusées. |
| S-7 | Moyen (sécurité patient) | DME : l'alerte allergie ne voyait que les sous-chaînes exactes — « Amoxicilline » passait sous une allergie « Pénicilline » ; accents et casse bloquants ; code patient calculé sur le nombre de fiches (collision définitive après une saisie manuelle) ; antécédents/allergies/prescriptions sans contrôle d'appartenance au patient ni au pack. | Familles thérapeutiques (pénicillines, céphalosporines, sulfamides, AINS, aspirine, quinine, iode) sans accents ; code = plus haut attribué ; contrôles d'appartenance ; pont DME → dossier de facturation. |
| S-8 | Moyen | Rétrocessions : bordereau calculé, **jamais comptabilisé** — ni charge au compte de résultat, ni dette au bilan. | « Comptabiliser le bordereau » : 632460 / 401140 au nom du praticien (devenu fournisseur réglable), idempotent, complément si le mois s'enrichit. Origine comptable « achat » (politique de validation respectée). |
| S-9 | Technique | Caches `ensure()` booléens : tables déclarées prêtes pour la société précédente → « no such table » après bascule. | Cache par base (santé et officine). |
| S-10 | Pilotage | « Factures à recouvrer » comptait des **pièces en attente de validation** (une facture validée impayée n'y était pas) ; alerte « Dossiers sans facturation » déclenchée dès un patient non revu, avec « relancer les assurances ». | Créances patients / tiers payant lues au grand livre (KPI, alerte, assistant) ; « Pièces à valider » ; alerte retirée. |

## 2. Spécificités par pack

- **Cabinet médical** — consultation facturée en 706166 ; tiers payant ; convention à l'assureur ; rétrocessions comptabilisables ; comptes 411118/411116/632460/401140 déclarés au plan du pack.
- **Clinique** — DME réparé (S-2) ; séjours et consultations dans un même dossier patient ; libellés d'indicateurs corrigés.
- **Hôpital** — idem ; 411115 déclaré au plan du pack (il était créé « hors référentiel »).
- **Laboratoire** — prélèvement programmé facturé en « Bilan » ; convention à l'assureur ; alerte bruyante retirée.
- **Optique** — client débité sur son compte (411100) et non plus sur 411116 (assureurs) ; examen de vue facturé comme prestation (706107).
- **Pharmacie** — « Encaissement divers » : caisse (rôle TRÉSORERIE) / 707410 prestations, au lieu d'une créance anonyme en « ventes de médicaments » ; lot périmé ou sans numéro refusé (péremption « AAAA-MM » = fin de mois) ; créances tiers-payant limitées aux dispensations encaissées (tickets annulés / en cours exclus) ; organisme de tiers-payant rattaché à un client à la caisse et au règlement.

## 3. Ponts avec les autres modules

- **Comptabilité / Règlements** : créances au compte du client, tiers auxiliaire patient et assureur → balance âgée, relances et règlements fonctionnent ; bouton « Encaisser » sur le dossier.
- **Achats / Fournisseurs** : praticien = fournisseur, dette 401140 réglable.
- **Caisse** : tiers-payant officine au nom d'un client.
- **Pilotage / Assistant** : encours réels ; liens vers `comptabilite/clients/creances`.
- **Analytique** : inchangé (section du dossier sur les produits).

## 4. Design

Barre santé limitée aux écrans ouverts au pack (fin des liens morts « Hospitalisation » / « Dossiers » au cabinet, au labo, chez l'opticien) et séparant Dossiers médicaux / Facturation / Pièces ; bandeaux d'indicateurs sur chaque écran ; planning avec bande semaine et navigation ; tableau des lits par service (cartes), jauge d'occupation, DMS, encours de séjours, dernières sorties ; bordereau avec état « constaté » et équipe éditable ; fiche patient (avatar, badges, constantes colorées, fièvre signalée, bloc facturation) ; grilles adaptatives (mobile) ; annonce de la répartition tiers payant sur la saisie de pièce. Styles `sa-*` isolés dans `app.css`.

## 5. Recommandations (non faites dans ce lot)

1. **Stock des consommables** : la pièce « Pharmacie » de la clinique et les équipements d'optique ne sortent aucun stock (pas de coût des ventes). Brancher la brique stock (CUMP) sur ces deux packs comme en 1.857.0 pour le commerce.
2. **Bordereaux assureurs** : éditer un bordereau mensuel par organisme (factures, parts, délais de production) et suivre les rejets / écarts de prise en charge (avoir partiel).
3. **Plafonds et tickets modérateurs** : taux par acte, plafonds annuels, franchise ; aujourd'hui un taux unique par dossier.
4. **TVA optique** : l'examen de vue est taxé à 18 % comme la monture ; faire valider par le fiscaliste l'exonération éventuelle des prestations de santé (catégorie fiscale « nature » paramétrable).
5. **DME** : référentiel de médicaments (DCI) partagé avec l'officine pour des alertes par molécule plutôt que par libellé ; interactions ; ordonnance imprimable ; journal d'accès au dossier médical (qui a lu quoi).
6. **Planning** : durée des créneaux et agenda par praticien (chevauchements partiels), rappels SMS, taux de RDV non honorés.
7. **Hospitalisation** : facturation intermédiaire des longs séjours, transferts de lit, forfaits journaliers par service.
8. **Pharmacie** : rattacher les tiers-payant historiques (avant 1.858.0, sur 411100 sans tiers) par une écriture de reclassement assistée.

---

## 6. Recommandations appliquées (1.859.0)

| # | Recommandation | Réalisation |
|---|---|---|
| 1 | Stock des consommables | Brique stock pour Clinique et Optique ; pièce liée à un article : sortie au CUMP et coût des ventes à la comptabilisation (idempotent). |
| 2 | Bordereaux assureurs, rejets | Écran « Assurances » : bordereau mensuel imprimable (âge, délai de production), rejets totaux/partiels → patient ou pertes 651100. |
| 3 | Taux par acte, plafonds, franchise | Conventions par assureur × nature de pièce ; registre des prises en charge pour le plafond annuel par assuré. |
| 4 | TVA de l'examen de vue | Exonéré par défaut, paramétrable par nature de pièce (Fiscalité). |
| 5 | DME | Marques → molécule (et catalogue de l'officine), interactions à risque sur 30 jours, ordonnance imprimable, journal d'accès ; DME ouvert au cabinet médical. |
| 6 | Planning | Durée des créneaux et chevauchements, agenda par praticien, non-honorés et taux d'absence, rappels WhatsApp/SMS de la veille. |
| 7 | Hospitalisation | Facture intermédiaire, transfert de lit au bon tarif, forfaits journaliers par service. |
| 8 | Reclassement tiers-payant | Créances historiques 411100 sans tiers rattachées à l'organisme, une seule fois. |

Limites assumées : la table des interactions et des marques est une aide à la vigilance (non exhaustive, extensible dans `FKC_SanteDossier`) ; les rappels s'envoient depuis le téléphone de l'accueil (pas de passerelle SMS intégrée).
