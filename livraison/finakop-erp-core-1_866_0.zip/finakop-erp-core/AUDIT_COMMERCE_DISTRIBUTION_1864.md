# Audit — famille « Commerce & Distribution » — second passage, base 1.863.0

**Périmètre.** Les dix packs de la famille, comme en 1.857.0 :

| Sous-famille | Packs |
|--------------|-------|
| Proximité | Supérette, Retail |
| Spécialisé | Bazar, Cosmétiques, Prêt-à-porter, Quincaillerie, Téléphonie |
| Équipement | Électroménager |
| Gros & distribution | Distribution, Station-service |

Le socle commun est la brique verticale (`Modules/Vertical`) : stock, ventes, retours, commandes, acomptes, lots, séries, unités, tarifs et dépôts. S'y ajoutent les ponts vers la Facturation, le Centre d'Encaissement et le Recouvrement.

Le premier audit (1.857.0, `AUDIT_COMMERCE_DISTRIBUTION_1857.md`) avait rétabli le coût des ventes, les retours, les acomptes et le rapprochement stock / compte 31. Ce second passage cherche ce qui restait.

**Nouveau test** : `tests/commerce_distribution_1864.php` (32 contrôles, sept packs). Chaque défaut ci-dessous y est reproduit.

**Non-régression** :
- les 21 tests commerce existants ;
- les tests de facturation et d'encaissement ;
- la suite complète.

---

## 1. Le commun — défauts corrigés

| # | Gravité | Défaut | Correction |
|---|---|---|---|
| C-1 | Technique | **Tables créées pour une seule société.** Vingt-trois modèles de la famille gardaient en mémoire, sous forme d'un simple drapeau, que leurs tables étaient prêtes : 14 modèles du socle vertical, 7 de Retail, 2 de Distribution. Après un changement de société, la seconde base n'avait pas ses tables : erreur « no such table ». | Ce drapeau est maintenant tenu société par société. |
| C-2 | **Majeur** | **Nombres saisis mal lus, dans toute la famille.** Chaque quantité, prix ou montant passait par une conversion brute : « 1 500 » valait **1**, « 2,5 » valait **2**. Cela touchait les ventes, entrées, retours, commandes, acomptes, SAV, livraisons de tournée, la caisse Retail, les bons, consignes et fonds de caisse, ainsi que les prix des articles et des tarifs. | Nouvelle fonction partagée `fkc_nombre()` : espaces (y compris insécables), virgule décimale, points de milliers. Elle est employée par les 5 contrôleurs de la famille (26 saisies) et par les modèles (articles, tarifs, lignes de commande, facteurs d'unité). |
| C-3 | Majeur | **Unité de facteur inférieur à 1 mal valorisée.** Le prix n'était converti que pour les unités plus grandes que l'unité de base (carton). Pour un « demi-mètre » de facteur 0,5, 10 demis à 600 F faisaient 5 m à **600 F/m** au lieu de 1 200 : le CUMP était faux, la vente aussi. | Toute unité de facteur différent de 1 est convertie (entrée, vente comptant, vente à crédit). |
| C-4 | **Majeur** | **Prix affiché TTC : la TVA était ajoutée en plus.** Le prix de l'article était toujours traité comme HT. Un carburant à 875 F le litre à la pompe (prix homologué, TVA incluse) était vendu **1 032,50 F**. Même problème pour tout rayon étiqueté TTC. | Case « prix affiché TTC » par article : la TVA est alors extraite du prix, pas ajoutée. Réglage par commerce (« Passer en prix TTC / HT »), avec option d'application aux articles existants. **Station-service : TTC par défaut** (prix à la pompe). L'écran de vente indique la convention de l'article choisi. |
| C-5 | Majeur | **Promotions et tarifs jamais appliqués.** Le moteur de tarifs (promotion datée, palier de quantité, prix client) ne servait qu'à tracer l'écart après coup. Sans prix saisi, la vente prenait toujours le prix de l'article, et le formulaire le pré-remplissait : une promotion saisie ne s'appliquait jamais. | Sans prix saisi, le tarif applicable est retenu : promotion en cours, palier, prix spécial du client pour une vente à crédit ou un devis. L'écran pré-remplit le prix en vigueur. Un prix saisi reste prioritaire. |
| C-6 | Majeur | **Lots faux après un retour.** Un retour partiel rendait au lot **toute** la quantité vendue : 4 recrédités pour un retour de 1, et de nouveau 4 au retour suivant. Le retour d'une vente à crédit ne rendait **rien** au lot. Dans les deux cas, les lots ne correspondaient plus au rayon et le FEFO se trompait. | Seule la quantité retournée est rendue, dans la limite de ce qui n'a pas déjà été rendu. Le retour à crédit restitue aussi le lot. |
| C-7 | **Majeur** | **Commandes.**<br>1. La livraison était valorisée au **prix du catalogue** : le CA du tableau de bord était faux dès qu'un prix était négocié.<br>2. Un article à **IMEI / numéro de série** livré par commande gardait son numéro « en stock », donc revendable une seconde fois, et la **garantie** n'était pas ouverte.<br>3. L'acompte d'une commande **annulée** restait au 419, sans moyen de le rendre au client.<br>4. L'imputation de l'acompte créditait le 411 **général** au lieu du compte propre du client. | 1. Livraison au prix de la ligne de commande.<br>2. Numéros exigés à la livraison (champ par ligne), consommés, garantie ouverte au nom du client.<br>3. L'annulation rembourse l'avance non imputée, par le moyen choisi (schéma commun `vp_acompte_remboursement` : débit 419 client, crédit trésorerie).<br>4. Imputation sur `{compte_client}` (socle et Électroménager). |
| C-8 | Majeur | **Compte client auxiliaire absent du plan.** Soit un client doté de son propre compte (411150) pas encore créé au plan. Sa facture tombait sur 411100 pendant que ses acomptes et règlements visaient 411150 : le même client était débiteur sur un compte et créditeur sur l'autre. Un reçu à son nom échouait avec « compte introuvable ». | La facturation et le Centre d'Encaissement créent ce compte auxiliaire au besoin, comme le fait déjà le moteur d'écritures. |
| C-9 | Moyen | **Vente comptant non atomique.** Stock, mouvement, numéros de série, lots, dépôt et coût des ventes s'écrivaient séparément. Une erreur en cours de route laissait un stock diminué sans mouvement, ou un IMEI vendu sans vente. | Une seule transaction, comme la vente à crédit ; en cas d'échec, rien n'est écrit et le message le dit. |
| C-10 | Moyen | **Suivi par numéro de série activé sur un stock existant.** Les unités déjà en rayon devenaient invendables, puisque la vente exige un numéro par unité. | Refusé tant que du stock sans numéros existe, avec la marche à suivre. |
| C-11 | Amélioration | **Écart hérité stock / compte 31.** Il était mesuré depuis 1.857.0, mais sa correction demandait une écriture manuelle (recommandation n° 1 de 1.857.0). | Bouton « Régulariser » sur la carte de rapprochement : écriture d'inventaire (débit 603 / crédit 31, ou l'inverse), passée une seule fois. Le stock physique fait foi. |

## 2. Spécificités par pack

| Pack | Constats | Corrections |
|------|----------|-------------|
| **Distribution** | 1. **Double sortie de stock.** L'écran rouvre un arrêt « partiel » pour le compléter, mais la quantité saisie était traitée comme une nouvelle livraison : sur la sonde, 6 livrés puis complétés à 10 faisaient sortir 16 du dépôt.<br>2. Une livraison pouvait rendre le stock du dépôt **négatif**.<br>3. **Une livraison signée ne devenait jamais une vente** : la marchandise quittait le dépôt sans créance sur le revendeur (recommandation n° 3 de 1.857.0).<br>4. Facture de gros et commission sur le 411 général. | 1. Seule la différence avec le déjà-livré sort, de même pour les retours ; un arrêt livré ou refusé ne se ressaisit plus.<br>2. Stock du dépôt contrôlé avant la sortie.<br>3. **« Facturer le revendeur »** depuis l'arrêt signé : facture des quantités livrées nettes des retours, au prix de vente, au compte du revendeur (fiche client créée au besoin), comptabilisée et émise une seule fois.<br>4. `{compte_client}`. |
| **Station-service** | Carburant vendu TVA en sus d'un prix pompe déjà TTC (C-4). | Prix TTC par défaut pour les nouveaux articles ; bouton pour basculer les existants. |
| **Retail** | 1. Bons d'achat et coupons : créés à l'écran, **jamais utilisables**. Aucune fonction ne les consommait, alors que l'écran affirmait qu'ils étaient validés à l'encaissement par leur code.<br>2. Un bon à 0 F ou négatif était accepté.<br>3. Consommation non atomique : le même code présenté à deux caisses pouvait servir deux fois.<br>4. Saisies de caisse, consignes et fonds mal lus (C-2). | 1. Validation d'un bon par son code à l'écran « Bons » : existence, expiration, marquage utilisé, une seule fois ; le montant est ensuite déduit en remise.<br>2. Montant positif exigé.<br>3. Consommation atomique.<br>4. `fkc_nombre()`. |
| **Téléphonie, Électroménager** | IMEI et garanties oubliés sur les ventes par commande (C-7). | Numéros exigés et consommés, garantie ouverte. |
| **Supérette, Cosmétiques** | Lots faux après retour (C-6) ; promotions jamais appliquées (C-5). | Corrigés par le socle. |
| **Quincaillerie, Prêt-à-porter, Bazar** | Unités de facteur < 1 (demi-mètre, demi-lot) mal valorisées (C-3) ; saisie des prix (C-2). | Corrigés par le socle. |

## 3. Ponts avec les autres modules

| Pont | Avant | Maintenant |
|------|-------|-----------|
| **Distribution → Facturation → Recouvrement** | La tournée s'arrêtait à la signature. | Facture du revendeur depuis l'arrêt ; la créance suit ensuite le chemin normal (règlements, relances). |
| **Commandes → Trésorerie** | Avance d'une commande annulée bloquée au 419. | Remboursement par le moyen choisi (Wave, espèces…). |
| **Facturation / Encaissement ↔ compte client** | Un client doté d'un compte auxiliaire était éclaté entre deux comptes. | Un seul compte, créé au besoin. |
| **Tarifs → Ventes** | Tarifs purement indicatifs. | Tarif en vigueur appliqué par défaut, au comptoir comme au devis. |
| **Stock → Comptabilité** | Écart mesuré, correction manuelle. | Régularisation en un clic. |
| **Séries / Garanties → Commandes** | Ignorées à la livraison. | Consommées et ouvertes. |

## 4. Design

- Écran Stock :
  - bandeau « 🏷️ Prix de vente affichés TTC / saisis HT » avec bascule ;
  - bouton « Régulariser » sur la carte de rapprochement.
- Formulaire article : case « prix affiché TTC (TVA incluse) », clavier décimal sur mobile.
- Écran de vente :
  - convention de prix de l'article affichée ;
  - prix pré-rempli au tarif en vigueur ;
  - indication « vide = tarif en vigueur ».
- Commande :
  - champ « N° de série / IMEI livrés » sur les lignes suivies par série ;
  - annulation avec motif, moyen de remboursement et montant de l'acompte rendu.
- Tournée de distribution : bouton « 🧾 Facturer le revendeur » et badge « facturé » avec lien vers la facture ; les retours déjà saisis sont repris dans le formulaire.
- Retail · Bons : validation d'un bon par son code, texte d'aide exact.

Les grilles fixes des écrans de la famille se replient déjà sur mobile, grâce à la règle globale de `app.css` posée en 1.857.0 : il n'y avait pas de réécriture de masse à faire.

## 5. Recommandations (non faites dans ce lot)

1. **Bons Retail à la caisse centrale.** Saisir le code du bon ou du coupon directement au terminal de caisse, qui l'imputerait comme moyen de paiement. Constater l'émission d'un bon d'achat en dette (419) et son utilisation en règlement.
2. **Avoir partiel sur vente à crédit.** Le retour d'une vente facturée n'est accepté qu'en totalité ; un avoir au prorata des quantités rendues éviterait d'annuler toute la facture.
3. **Coût des ventes par lot.** Recommandation n° 2 de 1.857.0, toujours ouverte : valoriser la sortie au coût du lot consommé (FEFO) plutôt qu'au CUMP global, pour les packs à péremption.
4. **Station-service — jauges et index.** Relevé quotidien des cuves et des index de pompe, écarts de dépotage et de température (le cockpit « Écarts de cuve » n'a toujours pas de saisie dédiée).
5. **Téléphonie — float mobile money.** Suivi du solde électronique par opérateur et des commissions retenues à la source.
6. **Quincaillerie — devis chantier.** Devis multi-lignes, livraisons par étape de chantier et acomptes par étape.
7. **Unifier Supérette et Retail.** Deux stocks pour un même métier de proximité : un tableau de bord commun, puis une migration vers un seul catalogue.
8. **Électroménager — extension de garantie** vendue séparément, constatée en produits constatés d'avance (477) et étalée sur sa durée.
9. **Paliers de tarif au comptoir.** Le prix pré-rempli est celui d'une unité. Recalculer le palier à la saisie de la quantité (côté navigateur) éviterait d'avoir à vider le champ pour en bénéficier.

## 6. Recommandations appliquées (1.865.0)

Les neuf recommandations du § 5 sont livrées en 1.865.0. Test : `tests/commerce_recommandations_1865.php` (23 contrôles sur cinq packs).

| # | Recommandation | Ce qui change |
|---|---|---|
| R1 | Bons Retail à la caisse centrale | Bouton **🎟️ Bon** au terminal : le code est vérifié (existence, expiration, non utilisé), consommé de façon atomique et déduit de l'addition comme une remise (colonne `remise_bon`, TVA recalculée au prorata). Un seul bon par ticket ; un ticket annulé rend son bon (`FKC_PosBons`). |
| R2 | Avoir partiel | `FKC_Facture::createAvoirPartiel()` : n'est crédité que ce qui est rendu, ligne par ligne, sans jamais dépasser la quantité facturée ; plusieurs avoirs partiels peuvent se succéder. Le retour d'une vente à crédit accepte désormais une quantité partielle (numéros de série exigés pour les articles suivis). |
| R3 | Coût des ventes par lot | Le coût d'achat est mémorisé sur le lot ; une vente, une vente à crédit ou une livraison d'article suivi par lots est valorisée au coût des lots consommés (FEFO). Le CUMP du reste est réajusté, et un retour re-pondère le CUMP : le compte 31 reste égal au stock physique. |
| R4 | Station-service — cuves et index | Nouvel écran **⛽ Cuves & pompes** : relevé quotidien de la jauge, des index de pompe et de la température. Il calcule l'écart de cuve (jauge − stock théorique) et l'écart de pompe (litres aux index − litres vendus). La tolérance est paramétrable (0,5 % par défaut). Un écart hors tolérance se régularise en un clic, par un inventaire au CUMP, hors chiffre d'affaires. |
| R5 | Téléphonie — float mobile money | Nouvel écran **📲 Float mobile money** : approvisionnement, dépôt client, retrait client et commission, par opérateur. Chaque opération est comptabilisée entre la caisse et le compte de l'opérateur (552100, 552200…), la commission au 706143. Le solde du float s'affiche par opérateur ; un dépôt au-delà du float disponible est refusé. |
| R6 | Quincaillerie — devis chantier | Chaque ligne de devis peut appartenir à une **étape** (fondations, gros œuvre, toiture…). La commande affiche les étapes avec leur montant et leur avancement ; « Livrer l'étape » livre d'un coup tout son reste. L'acompte reste unique par commande (pas encore d'acompte par étape). |
| R7 | Supérette / Retail | Vue **Proximité** sur l'écran Stock quand un catalogue Retail coexiste : articles et valeur des deux catalogues, total, et **doublons** (même produit suivi dans les deux stocks), premier pas vers un catalogue unique. |
| R8 | Extension de garantie | Un article peut être une « extension de garantie » (durée en mois). Chaque vente est inscrite à un registre ; à la clôture, la part restant à courir passe en produits constatés d'avance (477100), avec un ajustement au solde cible compte par compte : elle revient d'elle-même en produit à l'échéance. |
| R9 | Paliers de tarif au comptoir | Le formulaire de vente reçoit les paliers valables aujourd'hui et recalcule le prix proposé à chaque saisie de quantité, tant que le vendeur n'a pas tapé son propre prix. |

**En plus : inventaire d'un article.** Le socle vertical n'avait aucun geste d'inventaire. `FKC_VpStock::inventorier()`, accessible depuis l'écran Stock (bloc « 📋 Inventaire »), ajuste le stock à la quantité comptée. Un manquant va en charge 658800 et un excédent en reprise, toujours hors chiffre d'affaires. C'est aussi ce geste que les relevés de cuve utilisent.

